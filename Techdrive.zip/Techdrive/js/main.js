(() => {
  // Accessible mega menu on desktop and a touch-friendly drawer on mobile.
  const nav = document.querySelector('#primaryNav');
  const hamburger = document.querySelector('.nav-hamburger');
  const mega = nav?.querySelector('.mega-nav');
  const megaToggle = nav?.querySelector('.mega-toggle');
  if (nav && hamburger && mega && megaToggle) {
    const header = hamburger.parentElement;
    const mobileQuery = window.matchMedia('(max-width: 900px)');
    const placeNavigation = () => {
      if (mobileQuery.matches) {
        document.body.appendChild(nav);
      } else if (header) {
        header.insertBefore(nav, hamburger);
      }
    };
    placeNavigation();
    mobileQuery.addEventListener('change', placeNavigation);

    let scrim = document.querySelector('.nav-scrim');
    if (!scrim) {
      scrim = document.createElement('div');
      scrim.className = 'nav-scrim';
      document.body.appendChild(scrim);
    }

    const setMega = open => {
      mega.classList.toggle('open', open);
      megaToggle.setAttribute('aria-expanded', String(open));
    };
    const closeMenu = () => {
      nav.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
      hamburger.setAttribute('aria-label', 'Open menu');
      scrim.classList.remove('open');
      document.body.classList.remove('nav-open');
      setMega(false);
    };

    hamburger.addEventListener('click', event => {
      event.stopPropagation();
      const willOpen = !nav.classList.contains('open');
      nav.classList.toggle('open', willOpen);
      hamburger.setAttribute('aria-expanded', String(willOpen));
      hamburger.setAttribute('aria-label', willOpen ? 'Close menu' : 'Open menu');
      scrim.classList.toggle('open', willOpen);
      document.body.classList.toggle('nav-open', willOpen);
      if (!willOpen) setMega(false);
    });
    megaToggle.addEventListener('click', event => {
      event.stopPropagation();
      setMega(!mega.classList.contains('open'));
    });
    scrim.addEventListener('click', closeMenu);
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
    document.addEventListener('click', event => {
      if (!mega.contains(event.target)) setMega(false);
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 900) {
        nav.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
        scrim.classList.remove('open');
        document.body.classList.remove('nav-open');
      }
    });

    const here = location.pathname.split('/').pop() || 'index.html';
    if (here === 'index.html' || here === '') {
      document.body.dataset.page = 'index';
      nav.querySelector('.nav-home')?.classList.add('active');
    }
    nav.querySelectorAll('.mega-menu a').forEach(link => {
      if (link.getAttribute('href') === here) {
        link.classList.add('active');
        megaToggle.classList.add('has-active');
      }
    });
  }


  // Keyboard navigation for mega menu links when open
  const megaMenuEl = document.querySelector('#megaMenu');
  const megaToggleEl = document.querySelector('.mega-toggle');
  if (megaMenuEl && megaToggleEl) {
    megaToggleEl.addEventListener('keydown', event => {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        megaMenuEl.classList.add('open');
        megaToggleEl.setAttribute('aria-expanded', 'true');
        megaMenuEl.querySelector('a')?.focus();
      }
    });
    megaMenuEl.addEventListener('keydown', event => {
      const links = [...megaMenuEl.querySelectorAll('a')];
      const i = links.indexOf(document.activeElement);
      if (i < 0) return;
      if (event.key === 'ArrowDown') { event.preventDefault(); links[(i + 1) % links.length].focus(); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); links[(i - 1 + links.length) % links.length].focus(); }
      else if (event.key === 'Home') { event.preventDefault(); links[0].focus(); }
      else if (event.key === 'End') { event.preventDefault(); links[links.length - 1].focus(); }
      else if (event.key === 'Escape') {
        megaMenuEl.classList.remove('open');
        megaToggleEl.setAttribute('aria-expanded', 'false');
        megaToggleEl.focus();
      }
    });
  }

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Smooth internal navigation.
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', event => {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    });
  });

  // Scroll reveal.
  const revealItems = document.querySelectorAll('.product-card, .feature-grid article, .retro-card, .status-row, .license-panel, .retro-release, .info-card, .metric-card, .architecture-card, .timeline-item, .tool-note, .live-panel');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add('is-visible'));
  }

  // Live site clock and rotating status ticker.
  const clock = document.querySelector('[data-live-clock]');
  const ticker = document.querySelector('[data-ticker]');
  const tickerItems = [
    'CORE CHANNEL // ONLINE',
    'CATALOGUE // 665 TOOL IMPLEMENTATIONS',
    'MODULE INDEX // 69 CATALOGUE MODULES',
    'RETRO CHANNEL // 95 + XP RELEASED',
    'TECHDRIVE 7 // HELD BACK / NOT RELEASED',
    'WEBSITE TELEMETRY // SIMULATED'
  ];
  let tickerIndex = 0;
  const tick = () => {
    if (clock) clock.textContent = new Intl.DateTimeFormat([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());
  };
  tick();
  setInterval(tick, 1000);
  if (ticker) {
    ticker.textContent = tickerItems[0];
    setInterval(() => {
      ticker.classList.remove('ticker-in');
      void ticker.offsetWidth;
      tickerIndex = (tickerIndex + 1) % tickerItems.length;
      ticker.textContent = tickerItems[tickerIndex];
      ticker.classList.add('ticker-in');
    }, 3200);
  }

  // Animated counters.
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = Number(el.dataset.count || 0);
    if (reduceMotion) { el.textContent = target.toLocaleString(); return; }
    let value = 0;
    const step = Math.max(1, Math.ceil(target / 45));
    const timer = setInterval(() => {
      value = Math.min(target, value + step);
      el.textContent = value.toLocaleString();
      if (value >= target) clearInterval(timer);
    }, 28);
  });

  // Small simulated telemetry panel. It is intentionally labelled as website/demo telemetry.
  const telemetry = document.querySelector('[data-telemetry]');
  if (telemetry) {
    const cpu = telemetry.querySelector('[data-cpu]');
    const memory = telemetry.querySelector('[data-memory]');
    const disk = telemetry.querySelector('[data-disk]');
    const net = telemetry.querySelector('[data-net]');
    const bars = telemetry.querySelectorAll('[data-bar]');
    let t = 0;
    const updateTelemetry = () => {
      t += 0.55;
      const values = [
        Math.round(28 + Math.sin(t) * 10 + Math.sin(t * .43) * 5),
        Math.round(54 + Math.sin(t * .72 + 1) * 8),
        Math.round(72 + Math.sin(t * .31 + 2) * 4),
        Math.round(31 + Math.abs(Math.sin(t * 1.17)) * 38)
      ];
      if (cpu) cpu.textContent = `${values[0]}%`;
      if (memory) memory.textContent = `${values[1]}%`;
      if (disk) disk.textContent = `${values[2]}%`;
      if (net) net.textContent = `${values[3]} Mbps`;
      bars.forEach((bar, i) => bar.style.width = `${Math.min(96, Math.max(8, values[i]))}%`);
    };
    updateTelemetry();
    if (!reduceMotion) setInterval(updateTelemetry, 1400);
  }

  // Live sparkline drawn with SVG points.
  document.querySelectorAll('[data-sparkline]').forEach(svg => {
    const path = svg.querySelector('polyline');
    if (!path || reduceMotion) return;
    let phase = Math.random() * 10;
    const draw = () => {
      phase += .18;
      const points = [];
      for (let x = 0; x <= 260; x += 13) {
        const y = 45 - (Math.sin(x * .07 + phase) * 11 + Math.sin(x * .17 + phase * .7) * 5);
        points.push(`${x},${y.toFixed(1)}`);
      }
      path.setAttribute('points', points.join(' '));
      requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);
  });

  // Catalogue search/filter.
  const search = document.querySelector('[data-tool-search]');
  const catalogue = document.querySelector('[data-catalogue]');
  const resultCount = document.querySelector('[data-result-count]');
  if (search && catalogue) {
    const cards = [...catalogue.querySelectorAll('article')];
    const filter = () => {
      const q = search.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {
        const hit = !q || card.textContent.toLowerCase().includes(q);
        card.hidden = !hit;
        if (hit) visible++;
      });
      if (resultCount) resultCount.textContent = `${visible} ${visible === 1 ? 'module' : 'modules'} visible`;
    };
    search.addEventListener('input', filter);
    filter();
  }

  // Interactive tilt on selected cards.
  if (!reduceMotion && window.matchMedia('(pointer:fine)').matches) {
    document.querySelectorAll('[data-tilt]').forEach(card => {
      card.addEventListener('pointermove', event => {
        const r = card.getBoundingClientRect();
        const x = (event.clientX - r.left) / r.width - .5;
        const y = (event.clientY - r.top) / r.height - .5;
        card.style.transform = `perspective(900px) rotateX(${(-y * 2.2).toFixed(2)}deg) rotateY(${(x * 2.8).toFixed(2)}deg) translateY(-2px)`;
      });
      card.addEventListener('pointerleave', () => card.style.transform = '');
    });
  }

  // Ambient network particles — reacts subtly to the cursor for a "live" feel.
  const canvas = document.querySelector('#ambient');
  if (canvas && !reduceMotion) {
    const ctx = canvas.getContext('2d');
    let w = canvas.width = innerWidth * devicePixelRatio;
    let h = canvas.height = innerHeight * devicePixelRatio;
    canvas.style.width = `${innerWidth}px`;
    canvas.style.height = `${innerHeight}px`;
    const count = Math.min(70, Math.max(30, Math.floor(innerWidth / 24)));
    const points = Array.from({ length: count }, () => ({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - .5) * .18 * devicePixelRatio,
      vy: (Math.random() - .5) * .18 * devicePixelRatio,
      r: (Math.random() * .7 + .7) * devicePixelRatio
    }));
    const mouse = { x: -9999, y: -9999, active: false };
    const resize = () => {
      w = canvas.width = innerWidth * devicePixelRatio;
      h = canvas.height = innerHeight * devicePixelRatio;
      canvas.style.width = `${innerWidth}px`;
      canvas.style.height = `${innerHeight}px`;
    };
    addEventListener('resize', resize);
    addEventListener('pointermove', event => {
      mouse.x = event.clientX * devicePixelRatio;
      mouse.y = event.clientY * devicePixelRatio;
      mouse.active = true;
    }, { passive: true });
    addEventListener('pointerleave', () => { mouse.active = false; });
    const reach = 170 * devicePixelRatio;
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      points.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (mouse.active) {
          const dx = p.x - mouse.x, dy = p.y - mouse.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < reach && d > 0.01) {
            const pull = (1 - d / reach) * .045;
            p.vx += (dx / d) * pull;
            p.vy += (dy / d) * pull;
          }
        }
        p.vx *= .992; p.vy *= .992;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        const near = mouse.active && Math.hypot(p.x - mouse.x, p.y - mouse.y) < reach;
        ctx.beginPath(); ctx.arc(p.x, p.y, near ? p.r * 1.8 : p.r, 0, Math.PI * 2);
        ctx.fillStyle = near ? 'rgba(143,197,255,.85)' : 'rgba(104,173,255,.32)';
        ctx.fill();
      });
      for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x, dy = points[i].y - points[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 150 * devicePixelRatio) {
          ctx.beginPath(); ctx.moveTo(points[i].x, points[i].y); ctx.lineTo(points[j].x, points[j].y);
          ctx.strokeStyle = `rgba(92,158,226,${(1 - d / (150 * devicePixelRatio)) * .10})`;
          ctx.stroke();
        }
      }
      if (mouse.active) {
        const glow = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, reach);
        glow.addColorStop(0, 'rgba(104,173,255,.05)');
        glow.addColorStop(1, 'rgba(104,173,255,0)');
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.arc(mouse.x, mouse.y, reach, 0, Math.PI * 2); ctx.fill();
      }
      requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);
  }
})();


(() => {
  const d=window.TD_SOURCE_DATA;if(!d)return;
  const role=p=>p==='techdrive.py'||p.endsWith('/techdrive.py')||p==='Application entry'?'Application entry point':p.startsWith('gui/')?'Desktop UI / shell':p.startsWith('techdrive_modules/')?'Tool or support module':p.startsWith('shared/')?'Shared service':p.startsWith('installer/')?'Installer definition':p.startsWith('tests/')?'Test / verification':'Support / build / audit';
  const m=document.querySelector('#doc-metrics');
  if(m)m.innerHTML=[['SOURCE FILES',d.stats.files],['SOURCE LINES',d.stats.lines.toLocaleString()],['FUNCTIONS',d.stats.functions.toLocaleString()],['CLASSES',d.stats.classes],['GUI FILES',d.stats.gui_files],['TOOL MODULE FILES',d.stats.tool_files],['CATALOGUE MODULES',d.stats.catalogue_modules],['CATALOGUE ENTRIES',d.stats.catalogue_entries]].map(x=>`<div class="metric-card"><small>${x[0]}</small><strong>${x[1]}</strong><p>static source index</p></div>`).join('');
  const rows=document.querySelector('#sourceRows'), search=document.querySelector('#sourceSearch'), scope=document.querySelector('#sourceScope'), sort=document.querySelector('#sourceSort'), stats=document.querySelector('#sourceStats');
  if(!rows)return;
  const render=()=>{let q=(search.value||'').toLowerCase(),s=scope.value,by=sort.value;let a=d.files.filter(x=>(s==='all'||x.path.startsWith(s)) && (!q||`${x.path} ${x.doc} ${x.imports.join(' ')}`.toLowerCase().includes(q)));a.sort((x,y)=>by==='lines'?y.lines-x.lines:by==='functions'?y.functions-x.functions:by==='classes'?y.classes-x.classes:x.path.localeCompare(y.path));rows.innerHTML=a.map(x=>`<tr><td>${x.path}</td><td>${x.lines.toLocaleString()}</td><td>${x.functions}</td><td>${x.classes}</td><td>${x.catalogue_count?`<span class="catalogue-badge">${x.catalogue_count} entries</span>`:'—'}</td><td class="role">${role(x.path)}</td></tr>`).join('')||'<tr><td colspan="6">No source files match this filter.</td></tr>';stats.innerHTML=`<span class="source-stat"><b>${a.length}</b> files shown</span><span class="source-stat"><b>${a.reduce((n,x)=>n+x.lines,0).toLocaleString()}</b> lines in view</span><span class="source-stat"><b>${d.stats.catalogue_entries}</b> catalogue entries total</span>`};
  [search,scope,sort].forEach(x=>x&&x.addEventListener('input',render));render();
})();


/* Theme glass intensity toggle */
(() => {
  const KEY = 'td-glass';
  const levels = ['default', 'solid', 'max'];
  const labels = { default: '◇', solid: '◆', max: '◈' };
  const root = document.documentElement;
  const btn = document.getElementById('themeToggle');
  let level = localStorage.getItem(KEY) || 'default';
  if (!levels.includes(level)) level = 'default';
  const apply = () => {
    if (level === 'default') root.removeAttribute('data-glass');
    else root.setAttribute('data-glass', level);
    if (btn) {
      btn.querySelector('.theme-toggle-icon').textContent = labels[level];
      btn.setAttribute('aria-label', `Glass intensity: ${level}. Click to cycle.`);
      btn.title = `Glass: ${level}`;
    }
  };
  apply();
  btn?.addEventListener('click', () => {
    level = levels[(levels.indexOf(level) + 1) % levels.length];
    localStorage.setItem(KEY, level);
    apply();
  });
})();

/* Register service worker (PWA) */
(() => {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
})();

/* Gallery lightbox */
(() => {
  const items = document.querySelectorAll('[data-gallery-item]');
  if (!items.length) return;
  const lb = document.createElement('div');
  lb.className = 'gallery-lightbox';
  lb.setAttribute('role', 'dialog');
  lb.setAttribute('aria-modal', 'true');
  lb.setAttribute('aria-label', 'Screenshot preview');
  lb.innerHTML = '<button type="button" aria-label="Close">&times;</button><img alt="">';
  document.body.appendChild(lb);
  const img = lb.querySelector('img');
  const closeBtn = lb.querySelector('button');
  const open = (src, alt) => {
    img.src = src;
    img.alt = alt || 'Screenshot';
    lb.classList.add('open');
    closeBtn.focus();
  };
  const close = () => {
    lb.classList.remove('open');
    img.removeAttribute('src');
  };
  items.forEach(el => {
    el.addEventListener('click', () => {
      const full = el.getAttribute('data-full') || el.querySelector('img')?.src;
      const alt = el.querySelector('img')?.alt || el.querySelector('figcaption')?.textContent;
      open(full, alt);
    });
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        el.click();
      }
    });
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    if (!el.hasAttribute('role')) el.setAttribute('role', 'button');
  });
  closeBtn.addEventListener('click', close);
  lb.addEventListener('click', e => { if (e.target === lb) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && lb.classList.contains('open')) close(); });
})();

/* Evolution Lab: compare + growth chart */
(() => {
  const data = window.TD_EVOLUTION;
  if (!data || !data.length) return;
  const chartHost = document.getElementById('evoBarChart');
  const compareHost = document.getElementById('evoCompare');
  if (chartHost) {
    const maxLines = Math.max(...data.map(d => d.lines));
    chartHost.innerHTML = '<div class="evo-chart-bars">' + data.map(d => {
      const pct = Math.round((d.lines / maxLines) * 100);
      return `<div class="evo-bar-row"><span>${d.version}</span><div class="evo-bar-track"><div class="evo-bar-fill" data-width="${pct}%"></div></div><span>${(d.lines/1000).toFixed(0)}k</span></div>`;
    }).join('') + '</div>';
    requestAnimationFrame(() => {
      chartHost.querySelectorAll('.evo-bar-fill').forEach(el => {
        el.style.width = el.getAttribute('data-width');
      });
    });
  }
  if (compareHost) {
    const opts = data.map((d, i) => `<option value="${i}">${d.label} (${d.version})</option>`).join('');
    compareHost.innerHTML = `
      <div class="evo-selects">
        <label>A <select id="evoA">${opts}</select></label>
        <label>B <select id="evoB">${opts}</select></label>
      </div>
      <div class="evo-compare" id="evoCompareCards"></div>`;
    const aSel = document.getElementById('evoA');
    const bSel = document.getElementById('evoB');
    aSel.value = '0';
    bSel.value = String(data.length - 1);
    const card = (d, tag) => {
      const tools = d.tools != null ? d.tools : (d.tool_modules || '—');
      return `<div class="evo-compare-card glass-surface">
        <p class="eyebrow">${tag}</p>
        <h3>${d.label} · ${d.version}</h3>
        <p style="color:var(--muted);font-size:13px;margin:0 0 8px">${d.role}. ${d.notes}</p>
        <div class="evo-stats">
          <div><small>LINES</small><b>${d.lines.toLocaleString()}</b></div>
          <div><small>FILES</small><b>${d.files}</b></div>
          <div><small>FUNCTIONS</small><b>${d.functions.toLocaleString()}</b></div>
          <div><small>GUI FILES</small><b>${d.gui}</b></div>
          <div><small>MODULES</small><b>${d.tool_modules}</b></div>
          <div><small>TOOLS</small><b>${tools}</b></div>
        </div>
        <ul style="margin:14px 0 0;padding-left:18px;color:var(--muted);font-size:12px">${d.highlights.map(h => `<li>${h}</li>`).join('')}</ul>
      </div>`;
    };
    const render = () => {
      const a = data[+aSel.value];
      const b = data[+bSel.value];
      document.getElementById('evoCompareCards').innerHTML = card(a, 'SNAPSHOT A') + card(b, 'SNAPSHOT B');
    };
    aSel.addEventListener('change', render);
    bSel.addEventListener('change', render);
    render();
  }
})();
