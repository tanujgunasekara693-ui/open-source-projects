@echo off
title TechDrive XP Edition
cd /d "%~dp0"

where python >nul 2>&1
if %errorlevel%==0 (
    python -c "import sys; v=sys.version_info; exit(0 if v[:2]==(3,4) else 1)" 2>nul
    if %errorlevel%==0 (
        python techdrive_xp.py
        goto :eof
    )
    echo.
    echo WARNING: Python found but it is not 3.4.x
    echo This edition is written for Python 3.4.4 on Windows XP.
    echo Continuing anyway...
    echo.
    python techdrive_xp.py
    goto :eof
)

if exist "%LOCALAPPDATA%\Programs\Python\Python34\python.exe" (
    "%LOCALAPPDATA%\Programs\Python\Python34\python.exe" techdrive_xp.py
    goto :eof
)
if exist "C:\Python34\python.exe" (
    "C:\Python34\python.exe" techdrive_xp.py
    goto :eof
)
if exist "C:\Python\python.exe" (
    "C:\Python\python.exe" techdrive_xp.py
    goto :eof
)

echo.
echo Could not find Python 3.4.
echo Install Python 3.4.4 from https://www.python.org/downloads/release/python-344/
echo and try again.
echo.
pause
