# -*- coding: utf-8 -*-
"""
Improved classic theme for TechDrive XP Edition.
Works with old Tcl/Tk on Windows XP + Python 3.4.
"""

import tkinter as tk
from tkinter import ttk

XP_BLUE       = "#0A246A"
XP_LIGHT_BLUE = "#3A6EA5"
XP_TITLE_BLUE = "#003399"
XP_BG         = "#ECE9D8"
XP_PANEL      = "#F5F4EA"
XP_WHITE      = "#FFFFFF"
XP_DARK       = "#1A1A1A"
XP_GRAY       = "#6B6B6B"
XP_GREEN      = "#006600"
XP_RED        = "#990000"
XP_ORANGE     = "#C06000"
XP_ACCENT     = "#316AC5"
XP_SEL        = "#316AC5"
XP_HEADER_BG  = "#2B579A"
XP_TREE_BG    = "#FFFFFF"
XP_OUT_BG     = "#FAFAF5"

CAT_ICONS = {
    "System Info": "\u2139",
    "Disk & Storage": "\u25A4",
    "Network": "\u2601",
    "Processes & Services": "\u2699",
    "File Tools": "\u2395",
    "System Repair": "\u2692",
    "Hardware": "\u2388",
    "Drivers": "\u25A6",
    "Security & Privacy": "\u26E8",
    "Backup & Recovery": "\u21BB",
    "Display & Audio": "\u25EB",
    "Accessibility": "\u267F",
    "Control Panel Launchers": "\u2699",
    "Monitoring": "\u25A6",
    "Developer / Terminal": "\u2318",
    "Utilities": "\u2726",
    "Advanced Recovery": "\u26A0",
    "Advanced Recovery & Cloning": "\u26A0",
    "Archive Tools": "\u25A7",
    "Audio Tools": "\u266B",
    "Backup Tools": "\u21BB",
    "BIOS Tools": "\u2328",
    "Cloud Tools": "\u2601",
    "CPU Tools": "\u25A6",
    "CPU Monitor": "\u25A6",
    "DLL Tools": "\u2699",
    "Gaming Tools": "\u25B6",
    "OS Tools": "\u25A3",
    "Registry Advanced": "\u2630",
    "Terminal Tools": "\u2318",
    "Wipe Tools": "\u2716",
    "WiFi Tools": "\u2601",
    "Volume Manager": "\u25A4",
    "Disk Structure Tools": "\u25A4",
    "Partition Tools": "\u25A4",
    "Storage Health": "\u25A4",
}

def cat_icon(name):
    for key, icon in CAT_ICONS.items():
        if key.lower() in name.lower() or name.lower() in key.lower():
            return icon
    return "\u25A1"

def apply_xp_theme(root):
    style = ttk.Style(root)
    available = list(style.theme_names())
    preferred = None
    for name in ("xpnative", "winnative", "clam", "classic", "default"):
        if name in available:
            preferred = name
            break
    if preferred:
        try:
            style.theme_use(preferred)
        except Exception:
            pass
    try:
        style.configure(".", background=XP_BG, foreground=XP_DARK, font=("Tahoma", 9))
        style.configure("TFrame", background=XP_BG)
        style.configure("TLabel", background=XP_BG, foreground=XP_DARK, font=("Tahoma", 9))
        style.configure("TButton", padding=(8, 3), font=("Tahoma", 9))
        style.configure("Header.TLabel",
                        background=XP_HEADER_BG, foreground=XP_WHITE,
                        font=("Tahoma", 12, "bold"))
        style.configure("Title.TLabel",
                        background=XP_BG, foreground=XP_TITLE_BLUE,
                        font=("Tahoma", 12, "bold"))
        style.configure("Status.TLabel",
                        background=XP_PANEL, foreground=XP_DARK,
                        font=("Tahoma", 8))
        style.configure("Sub.TLabel",
                        background=XP_BG, foreground=XP_GRAY,
                        font=("Tahoma", 8))
        style.configure("Tool.TButton", padding=(10, 4), font=("Tahoma", 9, "bold"))
        style.configure("Treeview",
                        background=XP_TREE_BG, fieldbackground=XP_TREE_BG,
                        foreground=XP_DARK, font=("Tahoma", 9), rowheight=26,
                        indent=18)
        style.configure("Treeview.Heading", font=("Tahoma", 9, "bold"))
        style.map("Treeview",
                  background=[("selected", XP_SEL)],
                  foreground=[("selected", XP_WHITE)])
    except Exception:
        pass
    try:
        root.configure(background=XP_BG)
    except Exception:
        pass
    return style
