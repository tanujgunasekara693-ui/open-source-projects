# -*- coding: utf-8 -*-
"""
gui/trial_popup.py - TechDrive XP Edition launch reminder popup
=================================================================
Shown once on every launch (unless opted out via Settings or the
checkbox on the popup itself). XP Edition has no license tiers -
this is just a lightweight informational reminder, same spirit as
the full TechDrive's WinRAR-style nag but simplified for old Tcl/Tk
on Windows XP + Python 3.4: no fancy skinning, nothing locked or
disabled either way.

Public API:
    show_trial_popup(app, on_close=None, on_dont_show_again=None,
                      icon_path=None)
"""

import os
import tkinter as tk
from tkinter import ttk, scrolledtext

try:
    from gui.theme import XP_BG, XP_HEADER_BG, XP_WHITE, XP_DARK, XP_PANEL, XP_TITLE_BLUE, XP_GRAY
except ImportError:
    XP_BG = "#ECE9D8"
    XP_HEADER_BG = "#2B579A"
    XP_WHITE = "#FFFFFF"
    XP_DARK = "#1A1A1A"
    XP_PANEL = "#F5F4EA"
    XP_TITLE_BLUE = "#003399"
    XP_GRAY = "#6B6B6B"

_NOTICE_TEXT = """\
Thanks for running TechDrive XP Edition!

This edition is free to use. Nothing here is locked or time-limited -
every tool works exactly the same every time you open it.

Supported systems:
  - Windows XP, 32-bit and 64-bit (SP2/SP3)
  - Windows Vista, 32-bit and 64-bit
  - Python 3.4.4 (recommended) or any 3.4.x

*** FIRST AND FINAL VERSION - PLEASE READ ***
This is the first and last release of TechDrive XP Edition. There
will be no further updates, bug fixes, feature additions, or
technical support of any kind for this edition, ever. What you have
right now is the complete and final build.

If you are on Windows 7, 8, 10, 11, or later, please use a modern
TechDrive edition instead - it is actively maintained, supported,
and far more capable than this legacy build. This XP/Vista edition
exists only to help keep old, unsupported machines useful, not as a
recommended choice on anything newer.

Ownership and license:
TechDrive XP Edition is owned and published by TechDrive. It is NOT
a community-made or third-party build. It was created as a small,
free contribution to the retro computing community - no payment is
needed, and it never will be.

Copying, redistributing, or modifying the source code of this
software is not allowed. See EULA_XP.txt, included with this
package, for the full terms. By using this software you agree to
those terms.
"""


def show_trial_popup(app, on_close=None, on_dont_show_again=None, icon_path=None):
    """on_close: optional zero-arg callable invoked after the popup is
    dismissed (any path).
    on_dont_show_again: optional zero-arg callable invoked if the user
    checks "Don't show this again" and dismisses the popup - the caller
    is responsible for persisting that preference.
    icon_path: optional path to a .ico file used as the popup's
    titlebar logo (best-effort, never fatal if it can't be applied)."""

    popup = tk.Toplevel(app)
    popup.title("TechDrive XP Edition")
    popup.geometry("480x480")
    popup.minsize(420, 360)
    popup.configure(bg=XP_BG)

    if icon_path:
        try:
            if os.path.isfile(icon_path):
                popup.iconbitmap(icon_path)
        except Exception:
            pass

    dont_show_var = tk.BooleanVar(value=False)

    def _dismiss():
        try:
            if dont_show_var.get() and on_dont_show_again is not None:
                on_dont_show_again()
        except Exception:
            pass
        try:
            popup.destroy()
        except Exception:
            pass
        if on_close is not None:
            try:
                on_close()
            except Exception:
                pass

    popup.protocol("WM_DELETE_WINDOW", _dismiss)
    popup.bind("<Escape>", lambda e: _dismiss())

    header = tk.Frame(popup, bg=XP_HEADER_BG, height=44)
    header.pack(side=tk.TOP, fill=tk.X)
    header.pack_propagate(False)
    tk.Label(header, text="  TechDrive XP Edition", bg=XP_HEADER_BG, fg=XP_WHITE,
             font=("Tahoma", 12, "bold"), anchor="w").pack(side=tk.LEFT, fill=tk.Y)

    body = tk.Frame(popup, bg=XP_BG)
    body.pack(fill=tk.BOTH, expand=True, padx=12, pady=(10, 6))

    text = scrolledtext.ScrolledText(body, wrap=tk.WORD, font=("Tahoma", 9),
                                     bg=XP_PANEL, fg=XP_DARK, relief=tk.SUNKEN,
                                     borderwidth=1, height=14)
    text.pack(fill=tk.BOTH, expand=True)
    text.insert(tk.END, _NOTICE_TEXT)
    try:
        text.tag_add("warn", "1.0", tk.END)
        # Bold the "FIRST AND FINAL VERSION" line specifically.
        start = _NOTICE_TEXT.find("*** FIRST")
        end = _NOTICE_TEXT.find("\n", start)
        if start != -1:
            line_no = _NOTICE_TEXT.count("\n", 0, start) + 1
            text.tag_add("bold_warn", "%d.0" % line_no, "%d.end" % line_no)
            text.tag_configure("bold_warn", font=("Tahoma", 9, "bold"), foreground=XP_TITLE_BLUE)
    except Exception:
        pass
    text.config(state=tk.DISABLED)

    footer = tk.Frame(popup, bg=XP_BG)
    footer.pack(side=tk.BOTTOM, fill=tk.X, padx=12, pady=(0, 10))

    chk = tk.Checkbutton(footer, text="Don't show this reminder again",
                         variable=dont_show_var, bg=XP_BG, font=("Tahoma", 9))
    chk.pack(anchor="w", pady=(4, 6))

    btn_row = tk.Frame(footer, bg=XP_BG)
    btn_row.pack(fill=tk.X)

    btn_style = {"font": ("Tahoma", 9), "relief": tk.RAISED, "bd": 1,
                 "bg": "#E8E4D4", "activebackground": "#D0CCB8", "padx": 10, "pady": 3}

    tk.Button(btn_row, text="OK", command=_dismiss, **btn_style).pack(side=tk.RIGHT, padx=2)

    popup.transient(app)
    popup.grab_set()
    popup.focus_set()
