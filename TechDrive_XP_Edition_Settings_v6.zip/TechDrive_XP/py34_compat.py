# -*- coding: utf-8 -*-
"""
TechDrive XP Compatibility Layer for Python 3.4.4 + Windows XP

This module provides polyfills and helpers so the rest of the codebase
can run on the last official Python that still supported Windows XP.

Python 3.4.4 was released 2015-12-21. Windows XP support ended 2014-04-08,
but the Python team kept 3.4 as the final XP-compatible series.
"""

from __future__ import print_function  # just in case someone runs under 2.x by mistake

import sys
import os
import platform
import subprocess
import traceback
import tempfile
import shutil
import time
import json
import re
import hashlib
import socket
import logging

# ---------------------------------------------------------------------------
# Version gate
# ---------------------------------------------------------------------------
PY_VERSION = sys.version_info[:2]

if PY_VERSION < (3, 4):
    raise RuntimeError(
        "TechDrive XP requires Python 3.4 or newer. "
        "You are running {0}.{1}".format(PY_VERSION[0], PY_VERSION[1])
    )

if PY_VERSION >= (3, 5):
    # Soft warning only – still allow running on newer Pythons for testing
    pass

# ---------------------------------------------------------------------------
# Platform helpers
# ---------------------------------------------------------------------------
IS_WINDOWS = platform.system() == "Windows"
IS_XP = False

if IS_WINDOWS:
    try:
        # Windows XP is version 5.1
        ver = sys.getwindowsversion()
        IS_XP = (ver.major == 5 and ver.minor == 1)
    except Exception:
        # Fallback: look at platform string
        rel = platform.release().lower()
        IS_XP = ("xp" in rel) or (rel == "5.1")

def is_xp():
    return IS_XP

def windows_version_string():
    if not IS_WINDOWS:
        return platform.platform()
    try:
        ver = sys.getwindowsversion()
        return "Windows {0}.{1} (build {2})".format(ver.major, ver.minor, ver.build)
    except Exception:
        return platform.platform()

# ---------------------------------------------------------------------------
# Safe subprocess for XP
# ---------------------------------------------------------------------------
def run_cmd(cmd, timeout=60, shell=False, capture=True):
    """
    Run a command and return (returncode, stdout, stderr).
    Compatible with Python 3.4 (no subprocess.run, no timeout= on Popen until 3.3 actually,
    but we implement a simple timeout ourselves for older edge cases).
    """
    if isinstance(cmd, str) and not shell:
        # On Windows XP it is often safer to pass a string with shell=True
        # for built-in commands, but we try list first.
        pass

    try:
        if capture:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=shell,
                universal_newlines=True  # text mode, Python 3.4 name
            )
        else:
            proc = subprocess.Popen(cmd, shell=shell)

        # Simple timeout implementation for 3.4
        start = time.time()
        while proc.poll() is None:
            if time.time() - start > timeout:
                try:
                    proc.kill()
                except Exception:
                    pass
                return -1, "", "Command timed out after {0} seconds".format(timeout)
            time.sleep(0.05)

        out, err = ("", "")
        if capture:
            out, err = proc.communicate()
            if out is None:
                out = ""
            if err is None:
                err = ""
        return proc.returncode, out, err
    except Exception as e:
        return -1, "", str(e)

def run_wmic(query, timeout=30):
    """Helper for WMIC which is present on XP."""
    cmd = 'wmic {0}'.format(query)
    return run_cmd(cmd, timeout=timeout, shell=True)

def run_systeminfo():
    return run_cmd("systeminfo", timeout=45, shell=True)

def run_ipconfig():
    return run_cmd("ipconfig /all", timeout=20, shell=True)

def run_tasklist():
    return run_cmd("tasklist /v", timeout=30, shell=True)

def run_sc_query():
    return run_cmd("sc query state= all", timeout=30, shell=True)

# ---------------------------------------------------------------------------
# Safe file / path helpers (avoid pathlib for maximum 3.4 friendliness)
# ---------------------------------------------------------------------------
def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass

def safe_join(*parts):
    return os.path.normpath(os.path.join(*parts))

def get_app_data_dir():
    """XP-friendly application data directory."""
    if IS_WINDOWS:
        base = os.environ.get("APPDATA") or os.environ.get("USERPROFILE") or os.path.expanduser("~")
        path = safe_join(base, "TechDriveXP")
    else:
        path = safe_join(os.path.expanduser("~"), ".techdrive_xp")
    ensure_dir(path)
    return path

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def setup_logging():
    log_dir = safe_join(get_app_data_dir(), "logs")
    ensure_dir(log_dir)
    log_file = safe_join(log_dir, "techdrive_xp.log")

    logger = logging.getLogger("TechDriveXP")
    if logger.handlers:
        return logger

    try:
        handler = logging.FileHandler(log_file, encoding="utf-8")
        handler.setFormatter(
            logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
        )
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    except Exception:
        # Never let logging break the app
        pass
    return logger

# ---------------------------------------------------------------------------
# JSON helpers (3.4 has json, but be careful with encoding)
# ---------------------------------------------------------------------------
def load_json(path, default=None):
    if default is None:
        default = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, data):
    try:
        ensure_dir(os.path.dirname(path))
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False

# ---------------------------------------------------------------------------
# Graceful feature detection
# ---------------------------------------------------------------------------
def has_powershell():
    """PowerShell was not part of base XP. It could be installed later."""
    code, out, err = run_cmd("powershell -Command \"echo ok\"", timeout=8, shell=True)
    return code == 0 and "ok" in (out or "")

def has_wmic():
    code, out, err = run_cmd("wmic os get caption", timeout=10, shell=True)
    return code == 0 and len(out or "") > 5

def feature_status():
    """Return a dict of what is available on this machine."""
    return {
        "python": "{0}.{1}.{2}".format(sys.version_info[0], sys.version_info[1], sys.version_info[2]),
        "platform": windows_version_string(),
        "is_xp": IS_XP,
        "wmic": has_wmic(),
        "powershell": has_powershell(),
        "is_windows": IS_WINDOWS,
    }

# ---------------------------------------------------------------------------
# Simple string formatting helper (avoid f-strings everywhere)
# ---------------------------------------------------------------------------
def fmt(template, *args, **kwargs):
    """Safe .format() wrapper."""
    try:
        return template.format(*args, **kwargs)
    except Exception:
        return template

# ---------------------------------------------------------------------------
# Exception helper
# ---------------------------------------------------------------------------
def format_exception():
    return traceback.format_exc()
