# Known Limitations – TechDrive XP Edition

## Language / Runtime
- Written for Python 3.4 syntax only (no f-strings, no variable annotations in many places, no pathlib-centric code).
- Tested conceptually against Python 3.4.4 behaviour. Cannot be fully executed in this modern sandbox.

## Windows XP specific
- PowerShell is treated as optional (it was never part of base XP).
- DISM, modern CBS logs, many newer WMI classes → not available.
- SFC is documented only; the tool does not launch it automatically.
- Event log dumping via WMIC NTEVENT is limited and can be slow.
- Aero / modern visual effects → disabled (classic theme only).
- UAC does not exist on XP; “elevated” simply means Administrator account.

## Tools intentionally reduced or missing
- Everything that depends on PowerShell scripts
- Disk imaging / cloning that needs modern VSS or newer APIs
- Most security / privacy tools that use newer crypto or Windows APIs
- Cloud / OneDrive / modern browser tools
- Advanced network security (firewall rules via modern netsh contexts)
- Anything that required Python packages (psutil, Pillow, cryptography, requests, wmi module, etc.)

## What you should still expect to work
- Basic system inventory via systeminfo + WMIC
- Disk free space and volume info
- Network configuration and netstat
- Process and service lists
- Simple cleanup and file size tools
- Hardware identification (CPU, RAM, BIOS, board)

If a tool fails on a real XP machine, the output area will usually show the error from the underlying command so you can diagnose it.
