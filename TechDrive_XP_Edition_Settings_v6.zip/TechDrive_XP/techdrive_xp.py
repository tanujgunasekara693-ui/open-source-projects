#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TechDrive XP Edition
====================
A reduced but still useful Windows PC diagnostic / repair toolkit
designed to run on Windows XP and Windows Vista (32-bit or 64-bit)
with Python 3.4.4 (the last official Python that supported XP).

This is a SEPARATE product from the modern TechDrive.
Many advanced tools that depend on post-XP Windows features are either
disabled or show a clear "Not available on Windows XP" message.

Owned and published by TechDrive. This is the first and final release
of this edition - no further updates or support are planned. Users on
Windows 7/8/10/11+ should use a modern, supported TechDrive edition
instead. Copying, redistributing, or modifying this source code is not
permitted - see EULA_XP.txt for the full license terms.

Target:
  - Windows XP SP2/SP3 or Windows Vista, 32-bit or 64-bit
    (and later Windows versions for testing)
  - Python 3.4.4 (recommended) or any 3.4.x

Usage:
  python techdrive_xp.py
"""

from __future__ import print_function

import os
import sys
import platform
import threading
import time
import re
import tempfile
import shutil
import socket
import hashlib
from datetime import datetime

# ---------------------------------------------------------------------------
# Local compatibility layer
# ---------------------------------------------------------------------------
try:
    from py34_compat import (
        IS_WINDOWS, IS_XP, run_cmd, run_wmic, run_systeminfo,
        run_ipconfig, run_tasklist, run_sc_query, get_app_data_dir,
        setup_logging, feature_status, fmt, ensure_dir, safe_join,
        has_powershell, has_wmic, windows_version_string, format_exception
    )
except ImportError:
    # Fallback if the compat module is missing
    IS_WINDOWS = platform.system() == "Windows"
    IS_XP = False
    def run_cmd(cmd, timeout=30, shell=False, capture=True):
        import subprocess
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 shell=shell, universal_newlines=True)
            out, err = p.communicate()
            return p.returncode, out or "", err or ""
        except Exception as e:
            return -1, "", str(e)
    def get_app_data_dir():
        return os.path.join(os.path.expanduser("~"), "TechDriveXP")
    def setup_logging():
        import logging
        return logging.getLogger("TechDriveXP")
    def feature_status():
        return {"python": sys.version, "is_xp": False}
    def fmt(t, *a, **k):
        return t.format(*a, **k)
    def ensure_dir(p):
        if not os.path.isdir(p):
            os.makedirs(p)
    def safe_join(*p):
        return os.path.join(*p)
    def windows_version_string():
        return platform.platform()
    def format_exception():
        import traceback
        return traceback.format_exc()
    def has_wmic():
        return True
    def has_powershell():
        return False
    def run_wmic(q, timeout=30):
        return run_cmd("wmic " + q, timeout=timeout, shell=True)
    def run_systeminfo():
        return run_cmd("systeminfo", timeout=45, shell=True)
    def run_ipconfig():
        return run_cmd("ipconfig /all", timeout=20, shell=True)
    def run_tasklist():
        return run_cmd("tasklist /v", timeout=30, shell=True)
    def run_sc_query():
        return run_cmd("sc query state= all", timeout=30, shell=True)

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

try:
    from gui.theme import (
        apply_xp_theme, cat_icon,
        XP_BG, XP_LIGHT_BLUE, XP_WHITE, XP_DARK, XP_HEADER_BG,
        XP_PANEL, XP_OUT_BG, XP_GREEN, XP_RED, XP_ORANGE, XP_GRAY, XP_TITLE_BLUE
    )
except ImportError:
    def apply_xp_theme(root):
        return ttk.Style(root)
    def cat_icon(name):
        return "*"
    XP_BG = "#ECE9D8"
    XP_LIGHT_BLUE = "#3A6EA5"
    XP_WHITE = "#FFFFFF"
    XP_DARK = "#404040"
    XP_HEADER_BG = "#2B579A"
    XP_PANEL = "#F5F4EA"
    XP_OUT_BG = "#FAFAF5"
    XP_GREEN = "#006600"
    XP_RED = "#990000"
    XP_ORANGE = "#C06000"
    XP_GRAY = "#6B6B6B"
    XP_TITLE_BLUE = "#003399"

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logger = setup_logging()

# ---------------------------------------------------------------------------
# Simple persisted settings (JSON file in the app data dir). Only one
# setting exists today - whether the launch reminder popup is shown - but
# this is written generically so more can be added later.
# ---------------------------------------------------------------------------
import json as _json

_SETTINGS_FILE = safe_join(get_app_data_dir(), "settings.json")
_DEFAULT_SETTINGS = {"show_launch_reminder": True, "sound_enabled": False}


def load_settings():
    try:
        with open(_SETTINGS_FILE, "r") as f:
            data = _json.load(f)
        if isinstance(data, dict):
            merged = dict(_DEFAULT_SETTINGS)
            merged.update(data)
            return merged
    except Exception:
        pass
    return dict(_DEFAULT_SETTINGS)


def save_settings(data):
    try:
        with open(_SETTINGS_FILE, "w") as f:
            _json.dump(data, f)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# Tool catalogue with XP compatibility status
# ---------------------------------------------------------------------------
try:
    from tool_status import XP_CATALOGUE, status_label, status_text
except ImportError:
    XP_CATALOGUE = [
        ("System Info", [
            ("System Summary", "WORKS"),
            ("OS Details (WMIC)", "WORKS"),
        ]),
        ("Utilities", [
            ("About TechDrive XP", "WORKS"),
            ("Feature Detection Report", "WORKS"),
        ]),
    ]
    def status_label(s):
        return "[OK]" if s == "WORKS" else ("[~]" if s == "LIMITED" else "[X]")
    def status_text(s):
        return s

# Drop tools marked "NO" (not available on XP), plus the small set of
# "LIMITED" catalogue entries below that never had a real implementation
# behind them (no dispatch function - they only ever showed a generic
# "limited support" placeholder message). Also drop any category left
# empty as a result - the XP edition should only list tools that
# actually do something on this OS, not placeholders.
STUB_ONLY_TOOLS = frozenset([
    "Adapter Info", "Archive Tools (zip)", "Audio Tools Device Info",
    "Audio Tools Driver Info", "Audio Tools Format Info",
    "Audio Tools Sound Card Info", "Batch Rename Preview",
    "Bios Tools Bios Info", "Bios Tools Settings Viewer",
    "Boot Tools Boot Info", "Cache Info", "Card Driver Info",
    "Cpu Tools Cache Info", "Cpu Tools Cpu Info", "DLL Info",
    "Disk Tools Disk Info", "Display Tools Display Info",
    "Dll Tools Dll Info", "Encryption Tools Disk Encryption Status",
    "Ethernet Tools Driver Info", "Ethernet Tools Ethernet Info",
    "Ethernet Tools Port Status", "File System Tools Exfat Info",
    "File System Tools Fat32 Info", "File System Tools Ntfs Info",
    "Full Driver Report", "Gaming Tools Directx Info",
    "Gaming Tools Overclock Info", "Gaming Tools Vulkan Info",
    "Gpu Monitor Gpu Info", "Gpu Process List", "Health Report",
    "Internet Tools Isp Info", "Memory Spd Xmp Info",
    "Motherboard Tools Chipset Info", "Motherboard Tools Dmi Table Info",
    "Motherboard Tools Motherboard Info", "Motherboard Tools Slot Information",
    "Network Tools Network Info", "OS Info", "Os Tools License Status",
    "Os Tools Os Info", "Partition Info", "Partition Table Viewer",
    "Password Tools Manager Status", "Printer Tools Driver Info",
    "Printer Tools Printer List", "Printer Tools Status",
    "Ram Tools Ram Info", "Ram Tools Slot Info", "Restore Tools Info",
    "SMART Status", "Security Network Encryption Status",
    "Security Network Firewall Status", "Security Network Vpn Status",
    "Signed Drivers (basic)", "Smart Info", "Storage Health Health Report",
    "Storage Health Smart Status", "Sysnote Full System Report",
    "Sysnote Gpu Info", "Sysnote Installed Software List",
    "Sysnote Motherboard Info", "Sysnote Network Info",
    "Sysnote Windows License Status", "Terminal Tools Log Viewer",
    "View Storage Pool Information", "Wifi Tools Adapter Info",
    "Wifi Tools Password Viewer", "Wifi Tools Wifi Info",
])
XP_CATALOGUE = [
    (cat, [(name, status) for name, status in tools
           if status != "NO" and name not in STUB_ONLY_TOOLS])
    for cat, tools in XP_CATALOGUE
]
XP_CATALOGUE = [(cat, tools) for cat, tools in XP_CATALOGUE if tools]

# ---------------------------------------------------------------------------
# Built-in Help and EULA text (embedded directly so both are always
# available from inside the app, with no dependency on external files).
# ---------------------------------------------------------------------------
HELP_TEXT = """TechDrive XP Edition - Help
===========================

GETTING STARTED
  1. Pick a category in the "Tools" list on the left (System Info,
     Disks, Network, Processes, etc.).
  2. Click a tool, then press "Run Tool" (or double-click the tool)
     to run it. Output appears in the panel on the right.

STATUS MARKERS
  [OK] WORKS    - Fully implemented using commands available on XP.
  [~]  LIMITED  - Partial result, or guidance rather than automation.
  [X]  NO       - Not available on Windows XP (hidden from this list;
                  see Utilities > Compatibility Matrix for the full
                  picture of what modern TechDrive can do elsewhere).

TOOLBAR
  Run Tool        Runs the currently selected tool.
  Clear           Clears the output panel.
  Copy            Copies the current output to the clipboard.
  Save Report...  Saves the current output to a text file.
  Settings...     Opens the Settings dialog (launch reminder, sounds).

FILTERING
  Use the "Filter" box above the tool list to quickly search by tool
  or category name.

SETTINGS
  Open Settings from the toolbar or the File menu to:
    - Turn the one-time launch reminder popup on or off.
    - Turn the startup sound on or off (off by default).
  Settings are stored locally and only affect this app - nothing is
  sent anywhere.

MORE INFORMATION
  - Help > License (EULA) shows the full license terms.
  - Help > About TechDrive XP shows edition and version details.
  - See docs/LIMITATIONS.md (bundled with this download) for a
    detailed breakdown of what is and is not available on XP/Vista.

SUPPORT
  This is a first-and-final release with no ongoing support channel.
  For the full, actively maintained experience, use a modern
  TechDrive edition on Windows 7 / 10 / 11.
"""

EULA_TEXT = """TechDrive XP Edition -- End User License Agreement (EULA)
===========================================================

Last updated: 2026

PLEASE READ THIS AGREEMENT CAREFULLY BEFORE INSTALLING OR USING
TECHDRIVE XP EDITION ("THE SOFTWARE"). BY INSTALLING, COPYING, OR
OTHERWISE USING THE SOFTWARE, YOU AGREE TO BE BOUND BY THE TERMS OF
THIS AGREEMENT.

1. Ownership
------------
TechDrive XP Edition is owned and published by TechDrive. It is
proprietary software, provided as a free, standalone tribute edition
for legacy Windows systems. It is NOT community-maintained, open
source, or a third-party build.

2. First and Final Version
---------------------------
This is the first and final release of TechDrive XP Edition. No
further updates, patches, bug fixes, feature additions, or technical
support will be provided for this edition, under any circumstances.
Use it as-is.

If you are running Windows 7, 8, 10, 11, or later, you are strongly
encouraged to use a currently maintained, modern TechDrive edition
instead of this legacy build.

3. License Grant
-----------------
Subject to the terms of this Agreement, TechDrive grants you a
personal, non-exclusive, non-transferable, royalty-free license to
install and use the Software, free of charge, on Windows XP and
Windows Vista systems (32-bit or 64-bit) for your own personal or
professional diagnostic and repair purposes.

4. Restrictions
----------------
You may NOT:

  a. Copy, reproduce, or redistribute the source code of the
     Software, in whole or in part, in any form.
  b. Modify, adapt, translate, reverse engineer, decompile, or
     disassemble the Software, or create derivative works based on
     the source code.
  c. Sell, rent, lease, sublicense, or otherwise transfer the
     Software or its source code to any third party.
  d. Remove or alter any copyright, trademark, or other proprietary
     notices contained in the Software.

You MAY freely copy and redistribute the compiled/packaged Software
(this .zip / folder, unmodified) to other people or machines at no
charge, for the purpose the Software was intended: helping keep old
hardware useful.

5. No Warranty
---------------
THE SOFTWARE IS PROVIDED "AS IS," WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
NON-INFRINGEMENT. TechDrive does not warrant that the Software will
be error-free, secure, or compatible with every Windows XP or Vista
configuration.

6. No Support
---------------
Because this is the first and final release, TechDrive is under no
obligation to provide maintenance, updates, bug fixes, or support of
any kind for this edition.

7. Limitation of Liability
----------------------------
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT WILL
TECHDRIVE BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF DATA, ARISING OUT
OF OR RELATED TO YOUR USE OF THE SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

8. No Cost, No Obligation
----------------------------
The Software is provided entirely free of charge as a contribution
to the retro computing community. No payment, subscription, or
license fee is required to use it, now or in the future.

9. Acceptance
--------------
By installing, copying, or running the Software, you acknowledge
that you have read this Agreement, understand it, and agree to be
bound by its terms.

---------------------------------------------------------------------
TechDrive XP Edition - free forever, source not for redistribution
or modification. Thank you for helping keep old hardware alive.
---------------------------------------------------------------------
"""

# ---------------------------------------------------------------------------
# Main Application
# ---------------------------------------------------------------------------
class TechDriveXPApp(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("TechDrive XP Edition")
        self.geometry("920x640")
        self.minsize(700, 480)

        self._icon_path = safe_join(os.path.dirname(os.path.abspath(__file__)), "techdrive_icon.ico")
        self._apply_icon(self)

        self.style = apply_xp_theme(self)
        self.status_var = tk.StringVar(value="Ready")
        self._current_tool = None
        self._worker = None

        self._build_ui()
        self._show_welcome()
        self._play_startup_sound()

        # Nag popup, shown once every launch. Never blocks the first paint.
        self._trial_job = self.after(300, self._maybe_show_trial_popup)

        logger.info("TechDrive XP started on %s", windows_version_string())

    def _maybe_show_trial_popup(self):
        self._trial_job = None
        try:
            settings = load_settings()
            if not settings.get("show_launch_reminder", True):
                return
            from gui.trial_popup import show_trial_popup

            def _opt_out():
                s = load_settings()
                s["show_launch_reminder"] = False
                save_settings(s)

            show_trial_popup(self, on_close=None, on_dont_show_again=_opt_out,
                             icon_path=self._icon_path)
        except Exception:
            # A bug in the reminder must never crash or block the app.
            pass

    def _apply_icon(self, window):
        """Sets the TechDrive logo/icon on a Toplevel or the root window.
        Best-effort - never fatal if the .ico is missing or Tk can't
        load it on this system."""
        try:
            if os.path.isfile(self._icon_path):
                window.iconbitmap(self._icon_path)
        except Exception:
            pass

    def _play_startup_sound(self):
        """Play bundled startup WAV, but only if the user has sounds enabled
        in Settings (off by default)."""
        try:
            settings = load_settings()
            if not settings.get("sound_enabled", False):
                return
            import winsound
            base = os.path.dirname(os.path.abspath(__file__))
            wav = safe_join(base, "gui", "assets", "sounds", "TechDrive_Startup_Improved.wav")
            if os.path.isfile(wav):
                winsound.PlaySound(wav, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_menu_bar(self):
        menubar = tk.Menu(self)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Settings...", command=self._show_settings_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Help", command=self._show_help_dialog)
        help_menu.add_command(label="License (EULA)", command=self._show_eula_dialog)
        help_menu.add_separator()
        help_menu.add_command(label="About TechDrive XP", command=self._show_about_dialog)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.config(menu=menubar)

    def _show_text_dialog(self, title, text, width=620, height=460):
        """Reusable scrollable read-only text popup, used for Help/EULA/About."""
        win = tk.Toplevel(self)
        win.title(title)
        win.geometry("{0}x{1}".format(width, height))
        win.configure(bg=XP_BG)
        win.transient(self)
        self._apply_icon(win)

        tk.Label(win, text=title, bg=XP_BG, fg=XP_TITLE_BLUE,
                 font=("Tahoma", 10, "bold")).pack(anchor="w", padx=12, pady=(12, 6))

        body = scrolledtext.ScrolledText(win, wrap=tk.WORD, font=("Consolas", 9),
                                         bg=XP_OUT_BG, fg="#202020", relief=tk.SUNKEN,
                                         borderwidth=1)
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 8))
        body.insert("1.0", text)
        body.configure(state="disabled")

        btn_style = {"font": ("Tahoma", 9), "relief": tk.RAISED, "bd": 1,
                     "bg": "#E8E4D4", "activebackground": "#D0CCB8", "padx": 10, "pady": 3}
        btn_row = tk.Frame(win, bg=XP_BG)
        btn_row.pack(side=tk.BOTTOM, fill=tk.X, padx=12, pady=10)
        tk.Button(btn_row, text="Close", command=win.destroy, **btn_style).pack(side=tk.RIGHT, padx=2)
        return win

    def _show_help_dialog(self):
        self._show_text_dialog("Help - TechDrive XP Edition", HELP_TEXT)

    def _show_eula_dialog(self):
        self._show_text_dialog("License (EULA) - TechDrive XP Edition", EULA_TEXT)

    def _show_about_dialog(self):
        self._show_text_dialog("About TechDrive XP", self.tool_about(), width=520, height=320)

    def _build_ui(self):
        self._build_menu_bar()
        # ===== Top header bar =====
        header = tk.Frame(self, bg=XP_HEADER_BG, height=48)
        header.pack(side=tk.TOP, fill=tk.X)
        header.pack_propagate(False)

        title = tk.Label(header, text="  TechDrive XP Edition",
                         bg=XP_HEADER_BG, fg=XP_WHITE,
                         font=("Tahoma", 14, "bold"), anchor="w")
        title.pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ver_lbl = tk.Label(header,
                           text="Python {0}  |  {1}  ".format(
                               platform.python_version(),
                               "Windows XP" if IS_XP else windows_version_string()),
                           bg=XP_HEADER_BG, fg="#B8D4F0",
                           font=("Tahoma", 8), anchor="e")
        ver_lbl.pack(side=tk.RIGHT, padx=10)

        # ===== Main paned =====
        paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # ----- Left panel (tool navigation) -----
        left = ttk.Frame(paned, width=300)
        paned.add(left, weight=0)
        # Without this, the frame shrinks to fit its narrowest child (the
        # Treeview's default column width) instead of honoring width=300,
        # which is what was collapsing the whole nav panel to a sliver.
        left.pack_propagate(False)

        left_hdr = tk.Frame(left, bg=XP_PANEL)
        left_hdr.pack(fill=tk.X)
        tk.Label(left_hdr, text="  Tools", bg=XP_PANEL, fg=XP_TITLE_BLUE,
                 font=("Tahoma", 11, "bold"), anchor="w").pack(side=tk.LEFT, pady=6)

        # Search box
        search_fr = ttk.Frame(left)
        search_fr.pack(fill=tk.X, padx=6, pady=(4, 2))
        tk.Label(search_fr, text="Filter:", bg=XP_BG, font=("Tahoma", 8)).pack(side=tk.LEFT)
        self._search_var = tk.StringVar()
        self._search_var.trace("w", self._on_search)
        search_ent = ttk.Entry(search_fr, textvariable=self._search_var, width=18)
        search_ent.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)

        # Expand/Collapse controls - a proper nav tree, not a flat compact list
        nav_btn_fr = ttk.Frame(left)
        nav_btn_fr.pack(fill=tk.X, padx=6, pady=(0, 4))
        nav_btn_style = {"font": ("Tahoma", 8), "relief": tk.RAISED, "bd": 1,
                         "bg": "#E8E4D4", "activebackground": "#D0CCB8", "padx": 6, "pady": 1}
        tk.Button(nav_btn_fr, text="Expand All", command=self._expand_all_tree,
                 **nav_btn_style).pack(side=tk.LEFT, padx=(0, 4))
        tk.Button(nav_btn_fr, text="Collapse All", command=self._collapse_all_tree,
                 **nav_btn_style).pack(side=tk.LEFT)

        tree_fr = ttk.Frame(left)
        tree_fr.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)

        self.tree = ttk.Treeview(tree_fr, show="tree", selectmode="browse")
        self.tree.column("#0", width=270, minwidth=200, stretch=True)
        vsb = ttk.Scrollbar(tree_fr, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        self._tool_status = {}
        self._cat_ids = {}
        self._build_tree("")

        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<Double-1>", lambda e: self._run_current_tool())

        # Legend
        leg = tk.Frame(left, bg=XP_PANEL)
        leg.pack(fill=tk.X, pady=2)
        tk.Label(leg, text=" [OK] Works   [~] Limited",
                 bg=XP_PANEL, fg=XP_GRAY, font=("Tahoma", 7), anchor="w").pack(padx=4, pady=3)

        # ----- Right panel -----
        right = ttk.Frame(paned)
        paned.add(right, weight=1)

        self.content_header = ttk.Label(right, text="Welcome", style="Title.TLabel")
        self.content_header.pack(anchor="w", padx=8, pady=(6, 2))

        self.content_sub = ttk.Label(right, text="", style="Sub.TLabel")
        self.content_sub.pack(anchor="w", padx=8)

        # Toolbar
        self.tool_bar = tk.Frame(right, bg=XP_BG)
        self.tool_bar.pack(fill=tk.X, padx=6, pady=4)

        btn_style = {"font": ("Tahoma", 9), "relief": tk.RAISED, "bd": 1,
                     "bg": "#E8E4D4", "activebackground": "#D0CCB8", "padx": 8, "pady": 3}

        self.run_btn = tk.Button(self.tool_bar, text="  Run Tool  ",
                                 command=self._run_current_tool, **btn_style)
        self.run_btn.pack(side=tk.LEFT, padx=2)

        self.clear_btn = tk.Button(self.tool_bar, text=" Clear ",
                                   command=self._clear_output, **btn_style)
        self.clear_btn.pack(side=tk.LEFT, padx=2)

        self.copy_btn = tk.Button(self.tool_bar, text=" Copy ",
                                  command=self._copy_output, **btn_style)
        self.copy_btn.pack(side=tk.LEFT, padx=2)

        self.save_btn = tk.Button(self.tool_bar, text=" Save Report... ",
                                  command=self._save_output, **btn_style)
        self.save_btn.pack(side=tk.LEFT, padx=2)

        self.settings_btn = tk.Button(self.tool_bar, text=" Settings... ",
                                      command=self._show_settings_dialog, **btn_style)
        self.settings_btn.pack(side=tk.LEFT, padx=2)

        # Output area
        out_frame = ttk.Frame(right)
        out_frame.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)

        self.output = scrolledtext.ScrolledText(
            out_frame, wrap=tk.WORD, font=("Consolas", 9),
            bg=XP_OUT_BG, fg="#202020", relief=tk.SUNKEN, borderwidth=1,
            insertbackground=XP_DARK
        )
        self.output.pack(fill=tk.BOTH, expand=True)

        # Tag colors for status in output
        try:
            self.output.tag_configure("ok", foreground=XP_GREEN)
            self.output.tag_configure("lim", foreground=XP_ORANGE)
            self.output.tag_configure("no", foreground=XP_RED)
            self.output.tag_configure("hdr", foreground=XP_TITLE_BLUE, font=("Consolas", 10, "bold"))
        except Exception:
            pass

        # Status bar
        status = ttk.Label(self, textvariable=self.status_var, style="Status.TLabel",
                           relief=tk.SUNKEN, anchor="w")
        status.pack(side=tk.BOTTOM, fill=tk.X)

    def _build_tree(self, filter_text):
        """(Re)build the tool tree, optional filter."""
        self.tree.delete(*self.tree.get_children())
        self._cat_ids = {}
        filter_text = (filter_text or "").strip().lower()
        for cat, tools in XP_CATALOGUE:
            # filter tools
            visible = []
            for tool_name, status in tools:
                if filter_text:
                    if filter_text not in tool_name.lower() and filter_text not in cat.lower():
                        continue
                visible.append((tool_name, status))
            if not visible:
                continue
            icon = cat_icon(cat)
            cat_id = self.tree.insert("", "end",
                                      text=" {0}  {1}".format(icon, cat),
                                      open=True)
            self._cat_ids[cat] = cat_id
            for tool_name, status in visible:
                label = "{0} {1}".format(status_label(status), tool_name)
                self.tree.insert(cat_id, "end", text=label,
                                 values=(tool_name, status))
                self._tool_status[tool_name] = status

    def _on_search(self, *args):
        try:
            self._build_tree(self._search_var.get())
        except Exception:
            pass

    def _expand_all_tree(self):
        try:
            for cat_id in self._cat_ids.values():
                self.tree.item(cat_id, open=True)
        except Exception:
            pass

    def _collapse_all_tree(self):
        try:
            for cat_id in self._cat_ids.values():
                self.tree.item(cat_id, open=False)
        except Exception:
            pass

    def _show_welcome(self):
        self.content_header.config(text="Welcome to TechDrive XP")
        try:
            self.content_sub.config(text="XP-compatible tools only  |  [OK] full support, [~] limited")
        except Exception:
            pass
        feats = feature_status()
        works = limited = no = 0
        for cat, tools in XP_CATALOGUE:
            for name, status in tools:
                if status == "WORKS":
                    works += 1
                elif status == "LIMITED":
                    limited += 1
                else:
                    no += 1
        msg = [
            "TechDrive XP Edition (improved)",
            "================================",
            "",
            "Separate edition for Windows XP + Python 3.4.4.",
            "Only tools that actually work on XP are listed - anything that",
            "needed newer Windows features has been left out.",
            "",
            "Detected environment:",
            "  Python     : {0}".format(feats.get("python", "?")),
            "  Platform   : {0}".format(feats.get("platform", "?")),
            "  Is XP      : {0}".format(feats.get("is_xp", "?")),
            "  WMIC       : {0}".format("Yes" if feats.get("wmic") else "No / failed"),
            "  PowerShell : {0}".format("Yes" if feats.get("powershell") else "No (normal on XP)"),
            "",
            "Tool status summary:",
            "  [OK] Works on XP     : {0}".format(works),
            "  [~]  Limited on XP   : {0}".format(limited),
            "",
            "Legend in the left tree:",
            "  [OK] = implemented and expected to work",
            "  [~]  = limited / guidance only",
            "",
            "Select a tool on the left, then click \"Run Tool\".",
            "Open \"Compatibility Matrix\" under Utilities for the full list.",
        ]
        self._set_output("\n".join(msg))

    # ------------------------------------------------------------------
    # Tree / tool selection
    # ------------------------------------------------------------------
    def _on_tree_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        item = sel[0]
        vals = self.tree.item(item, "values")
        if not vals:
            return
        tool_name = vals[0]
        status = vals[1] if len(vals) > 1 else self._tool_status.get(tool_name, "NO")
        self._current_tool = tool_name
        self._current_status = status
        self.content_header.config(text=tool_name)
        try:
            self.content_sub.config(text=status_text(status))
        except Exception:
            pass
        self.status_var.set("Selected: {0}  ({1})".format(tool_name, status_text(status)))

        self.output.config(state=tk.NORMAL)
        self.output.delete("1.0", tk.END)
        self.output.insert(tk.END, "Tool: " + tool_name + "\n", "hdr")
        tag = "ok" if status == "WORKS" else ("lim" if status == "LIMITED" else "no")
        self.output.insert(tk.END, "Status: " + status_text(status) + "\n\n", tag)
        if status == "NO":
            self.output.insert(tk.END,
                "This tool is not available on Windows XP.\n"
                "It requires features that only exist on later Windows versions\n"
                "(PowerShell 2+, DISM, modern WMI classes, etc.).\n\n"
                "Use the full TechDrive on Windows 7 / 10 / 11 for this tool.\n")
        elif status == "LIMITED":
            self.output.insert(tk.END,
                "This tool has limited support on Windows XP.\n"
                "Click \"Run Tool\" – some functions may be reduced or show guidance only.\n")
        else:
            self.output.insert(tk.END,
                "This tool is implemented for Windows XP.\n"
                "Click \"Run Tool\" to execute.\n\n"
                "Tip: double-click a tool in the tree to run it.\n")
        self.output.config(state=tk.NORMAL)

    def _run_current_tool(self):
        if not self._current_tool:
            messagebox.showinfo("TechDrive XP", "Please select a tool first.")
            return
        if self._worker and self._worker.is_alive():
            messagebox.showinfo("TechDrive XP", "A tool is already running. Please wait.")
            return

        self.status_var.set("Running: " + self._current_tool + " …")
        self.run_btn.config(state=tk.DISABLED)
        self._set_output("Running \"{0}\" …\nPlease wait.\n".format(self._current_tool))

        self._worker = threading.Thread(target=self._tool_worker, args=(self._current_tool,))
        self._worker.daemon = True
        self._worker.start()

    def _tool_worker(self, tool_name):
        try:
            result = self._dispatch_tool(tool_name)
        except Exception:
            result = "ERROR while running tool:\n\n" + format_exception()

        # Back to UI thread
        self.after(0, lambda: self._tool_finished(result))

    def _tool_finished(self, result):
        self._set_output(result)
        self.status_var.set("Ready")
        self.run_btn.config(state=tk.NORMAL)

    def _set_output(self, text):
        self.output.config(state=tk.NORMAL)
        self.output.delete("1.0", tk.END)
        self.output.insert(tk.END, text)
        self.output.config(state=tk.NORMAL)  # keep editable for copy
        self.output.see("1.0")

    def _clear_output(self):
        self._set_output("")

    def _copy_output(self):
        try:
            text = self.output.get("1.0", tk.END)
            self.clipboard_clear()
            self.clipboard_append(text)
            self.status_var.set("Output copied to clipboard")
        except Exception as e:
            messagebox.showerror("Copy", str(e))

    def _save_output(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="Save report"
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.output.get("1.0", tk.END))
            self.status_var.set("Saved: " + path)
        except Exception as e:
            messagebox.showerror("Save", str(e))

    def _show_settings_dialog(self):
        settings = load_settings()

        win = tk.Toplevel(self)
        win.title("TechDrive XP Settings")
        win.geometry("360x180")
        win.resizable(False, False)
        win.configure(bg=XP_BG)
        win.transient(self)
        win.grab_set()
        self._apply_icon(win)

        tk.Label(win, text="Settings", bg=XP_BG, fg=XP_TITLE_BLUE,
                 font=("Tahoma", 10, "bold")).pack(anchor="w", padx=12, pady=(12, 6))

        win.geometry("360x230")

        show_var = tk.BooleanVar(value=bool(settings.get("show_launch_reminder", True)))
        chk = tk.Checkbutton(win, text="Show reminder popup on launch",
                             variable=show_var, bg=XP_BG, font=("Tahoma", 9))
        chk.pack(anchor="w", padx=12, pady=4)

        tk.Label(win, text="(Purely informational - turning this off changes\nnothing else. Every tool keeps working the same.)",
                 bg=XP_BG, fg=XP_GRAY, font=("Tahoma", 8), justify="left").pack(anchor="w", padx=12, pady=(0, 8))

        sound_var = tk.BooleanVar(value=bool(settings.get("sound_enabled", False)))
        snd_chk = tk.Checkbutton(win, text="Play startup sound", variable=sound_var,
                                 bg=XP_BG, font=("Tahoma", 9))
        snd_chk.pack(anchor="w", padx=12, pady=4)

        tk.Label(win, text="(Off by default. Turn on to play the bundled\nstartup chime the next time you launch the app.)",
                 bg=XP_BG, fg=XP_GRAY, font=("Tahoma", 8), justify="left").pack(anchor="w", padx=12, pady=(0, 12))

        btn_style = {"font": ("Tahoma", 9), "relief": tk.RAISED, "bd": 1,
                     "bg": "#E8E4D4", "activebackground": "#D0CCB8", "padx": 10, "pady": 3}

        def _save_and_close():
            settings["show_launch_reminder"] = bool(show_var.get())
            settings["sound_enabled"] = bool(sound_var.get())
            save_settings(settings)
            win.destroy()

        btn_row = tk.Frame(win, bg=XP_BG)
        btn_row.pack(side=tk.BOTTOM, fill=tk.X, padx=12, pady=10)
        tk.Button(btn_row, text="Save", command=_save_and_close, **btn_style).pack(side=tk.RIGHT, padx=2)
        tk.Button(btn_row, text="Cancel", command=win.destroy, **btn_style).pack(side=tk.RIGHT, padx=2)


    # ------------------------------------------------------------------
    # Tool dispatcher
    # ------------------------------------------------------------------
    def _dispatch_tool(self, name):
        status = getattr(self, "_current_status", None) or self._tool_status.get(name, "NO")
        if status == "NO":
            return (
                "=== {0} ===\n\n"
                "Status: Not available on Windows XP\n\n"
                "This tool requires modern Windows features that do not exist\n"
                "on XP (PowerShell 2+, DISM, newer WMI classes, etc.).\n\n"
                "Please use the full TechDrive on Windows 7 / 10 / 11."
            ).format(name)

        dispatch = {
            "System Summary": self.tool_system_summary,
            "OS Details (WMIC)": self.tool_os_details,
            "Installed Hotfixes": self.tool_hotfixes,
            "Environment Variables": self.tool_env_vars,
            "Computer Name & Domain": self.tool_computer_name,
            "Uptime": self.tool_uptime,
            "System Overview": self.tool_system_summary,
            "Install Date": self.tool_os_details,
            "License / Product Key": self.tool_product_key,
            "Logged On Users": self.tool_logged_users,
            "Time Zone & Locale": self.tool_timezone,
            "Logical Disks": self.tool_logical_disks,
            "Physical Disks": self.tool_physical_disks,
            "Volume Info": self.tool_volume_info,
            "Check Disk (read-only)": self.tool_chkdsk_readonly,
            "Free Space Report": self.tool_free_space,
            "Disk Info": self.tool_logical_disks,
            "Space Analyzer (basic)": self.tool_large_files,
            "Defrag (launch)": self.tool_defrag,
            "Disk Cleanup (launch)": self.tool_disk_cleanup,
            "SMART Health": self.tool_smart,
            "IP Configuration": self.tool_ipconfig,
            "Network Adapters (WMIC)": self.tool_net_adapters,
            "Active Connections (netstat)": self.tool_netstat,
            "Hosts File Viewer": self.tool_hosts,
            "Ping Test": self.tool_ping,
            "DNS Cache": self.tool_dns_cache,
            "ARP Table": self.tool_arp,
            "Routing Table": self.tool_route,
            "Shared Folders": self.tool_shares,
            "Firewall Status (XP)": self.tool_firewall,
            "Winsock Reset (guidance)": self.tool_winsock,
            "WiFi Info": self.tool_wifi,
            "Running Processes": self.tool_processes,
            "Services List": self.tool_services,
            "Startup Programs": self.tool_startup,
            "Kill Process (by name)": self.tool_kill_process,
            "Service Start/Stop": self.tool_service_control,
            "Scheduled Tasks (basic)": self.tool_schtasks,
            "Temp Folder Cleaner": self.tool_temp_cleaner,
            "Find Large Files": self.tool_large_files,
            "Folder Size Calculator": self.tool_folder_size,
            "Open Command Prompt Here": self.tool_cmd_here,
            "Open CMD": self.tool_cmd_here,
            "Recycle Bin (guidance)": self.tool_recycle,
            "SFC /scannow (XP)": self.tool_sfc,
            "Event Log Viewer (basic)": self.tool_eventlog,
            "Registry Query Helper": self.tool_reg_query,
            "Registry Export (backup)": self.tool_reg_export,
            "System File Checker Status": self.tool_sfc_status,
            "System Restore (launch)": self.tool_sysrestore,
            "CPU Info": self.tool_cpu,
            "Memory Info": self.tool_memory,
            "BIOS Info": self.tool_bios,
            "Motherboard": self.tool_motherboard,
            "GPU / Video Controller": self.tool_gpu,
            "Monitor / Display": self.tool_monitor,
            "Battery Info": self.tool_battery,
            "Printers": self.tool_printers,
            "USB / PnP Devices": self.tool_pnp,
            "Sound Devices": self.tool_sound,
            "Screen Resolution (info)": self.tool_monitor,
            "Driver List (driverquery)": self.tool_drivers,
            "Device Manager (launch)": self.tool_devmgmt,
            "Local Users": self.tool_users,
            "Simple Folder Copy": self.tool_folder_copy,
            "Volume Control (launch)": self.tool_volume,
            "Magnifier (launch)": self.tool_magnifier,
            "On-Screen Keyboard (launch)": self.tool_osk,
            "System Properties (launch)": self.tool_sysdm,
            "Control Panel (launch)": self.tool_control,
            "Feature Detection Report": self.tool_features,
            "About TechDrive XP": self.tool_about,
            "Help": self.tool_help,
            "License (EULA)": self.tool_eula,
            "Open App Data Folder": self.tool_open_appdata,
            "Export System Report": self.tool_export_report,
            "Compatibility Matrix": self.tool_compat_matrix,
            "Installed Programs": self.tool_installed_programs,
            "MAC Addresses": self.tool_getmac,
            "Who Am I": self.tool_whoami,
            "Page File": self.tool_pagefile,
            "Shares (WMIC)": self.tool_shares_wmic,
            "Mapped Drives": self.tool_netuse,
            "NetBIOS Names": self.tool_nbtstat,
            "FSUTIL Volume Info": self.tool_fsutil,
            "Open Files": self.tool_openfiles,
            "Services MMC": self.tool_services_msc,
            "Event Viewer (MMC)": self.tool_eventvwr,
            "Disk Management (MMC)": self.tool_diskmgmt,
            "Computer Management": self.tool_compmgmt,
            "Add/Remove Programs": self.tool_appwiz,
            "Display Properties": self.tool_desk,
            "Date and Time": self.tool_timedate,
            "Power Options": self.tool_powercfg,
            "Windows Firewall CPL": self.tool_firewall_cpl,
            "Local Users and Groups": self.tool_lusrmgr,
            "MSConfig": self.tool_msconfig,
            "DirectX Diagnostic": self.tool_dxdiag,
            "Performance Monitor": self.tool_perfmon,
            "Task Manager": self.tool_taskmgr,
            "Notepad": self.tool_notepad,
            "Calculator": self.tool_calc,
            "IP Release/Renew (guidance)": self.tool_ip_release_renew,
            "Wipe Free Space (cipher)": self.tool_cipher_wipe,
            "NTFS Compression": self.tool_compact,
            "Version / Build": self.tool_os_details,
            "Architecture": self.tool_os_details,
            "License Status": self.tool_product_key,
            "Product Key": self.tool_product_key,
            "Manufacturer": self.tool_bios,
            "Version Check": self.tool_bios,
            "Registry Editor (regedit)": self.tool_regedit,
            "Zip / Unzip (guidance)": self.tool_zip_guide,
            "DLL Info (guidance)": self.tool_dll_guide,
            "Register / Unregister": self.tool_dll_guide,
            "Virtualization Check": self.tool_virt_check,
            "Device Info": self.tool_sound,
            "Sticky Keys (guidance)": self.tool_access_guide,
            "Filter Keys (guidance)": self.tool_access_guide,
            "High Contrast (guidance)": self.tool_access_guide,

        }
        func = dispatch.get(name)
        if func is None:
            if status == "LIMITED":
                return (
                    "=== {0} ===\n\n"
                    "Status: Limited support on Windows XP\n\n"
                    "A full implementation is not present in this XP edition.\n"
                    "Guidance: many of these functions can be done with classic\n"
                    "XP tools (Control Panel, Device Manager, System Properties,\n"
                    "Command Prompt, etc.)."
                ).format(name)
            return "Tool \"{0}\" is not implemented in this XP edition.".format(name)
        return func()

    # ------------------------------------------------------------------
    # Individual tools
    # ------------------------------------------------------------------
    def tool_system_summary(self):
        lines = []
        lines.append("=== System Summary ===")
        lines.append("Generated : " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        lines.append("Platform  : " + windows_version_string())
        lines.append("Python    : " + platform.python_version())
        lines.append("Machine   : " + platform.machine())
        lines.append("Processor : " + platform.processor())
        lines.append("Node      : " + platform.node())
        lines.append("")

        if IS_WINDOWS:
            code, out, err = run_systeminfo()
            if code == 0 and out:
                lines.append("--- systeminfo ---")
                lines.append(out)
            else:
                lines.append("systeminfo failed: " + (err or "unknown error"))
        else:
            lines.append("(Not running on Windows)")
        return "\n".join(lines)

    def tool_os_details(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("os get Caption,Version,BuildNumber,OSArchitecture,CSDVersion,InstallDate /format:list")
        if code != 0:
            return "WMIC failed:\n" + (err or out or "unknown")
        return "=== OS Details (WMIC) ===\n\n" + out

    def tool_hotfixes(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("qfe list brief")
        if code != 0:
            # Older XP sometimes prefers different syntax
            code2, out2, err2 = run_wmic("qfe get HotFixID,Description,InstalledOn")
            if code2 == 0:
                return "=== Installed Hotfixes ===\n\n" + out2
            return "Could not list hotfixes.\n" + (err or err2 or "")
        return "=== Installed Hotfixes ===\n\n" + out

    def tool_env_vars(self):
        lines = ["=== Environment Variables ===\n"]
        for k in sorted(os.environ.keys()):
            lines.append("{0} = {1}".format(k, os.environ[k]))
        return "\n".join(lines)

    def tool_computer_name(self):
        lines = ["=== Computer Name & Domain ===\n"]
        lines.append("Hostname (platform.node): " + platform.node())
        if IS_WINDOWS:
            code, out, err = run_cmd("hostname", shell=True)
            if code == 0:
                lines.append("hostname command     : " + out.strip())
            code, out, err = run_wmic("computersystem get Name,Domain,Workgroup,UserName /format:list")
            if code == 0:
                lines.append("\n--- WMIC ComputerSystem ---")
                lines.append(out)
        return "\n".join(lines)

    def tool_logical_disks(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("logicaldisk get DeviceID,FileSystem,Size,FreeSpace,VolumeName /format:list")
        if code != 0:
            return "WMIC logicaldisk failed:\n" + (err or out)
        return "=== Logical Disks ===\n\n" + out

    def tool_physical_disks(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("diskdrive get Index,Model,Size,InterfaceType,MediaType,Status /format:list")
        if code != 0:
            return "WMIC diskdrive failed:\n" + (err or out)
        return "=== Physical Disks ===\n\n" + out

    def tool_volume_info(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("volume get DriveLetter,Label,FileSystem,Capacity,FreeSpace /format:list")
        if code != 0:
            # volume class may be limited on some XP installs
            return "WMIC volume failed (common on some XP installs).\nTrying logicaldisk instead…\n\n" + self.tool_logical_disks()
        return "=== Volume Info ===\n\n" + out

    def tool_chkdsk_readonly(self):
        if not IS_WINDOWS:
            return "Windows only."
        # Read-only style check – we just query volume status, we do NOT run chkdsk /f
        lines = [
            "=== Check Disk (read-only status) ===",
            "",
            "NOTE: This edition does NOT run a full chkdsk /f or /r",
            "because those require exclusive access and a reboot on XP.",
            "Instead we show current volume status via WMIC.",
            ""
        ]
        code, out, err = run_wmic("volume get DriveLetter,Label,DirtyBitSet,FileSystem /format:list")
        if code == 0:
            lines.append(out)
        else:
            lines.append("Could not query volume dirty bit.")
            lines.append(err or out)
        lines.append("")
        lines.append("To run a real chkdsk you must open an elevated command prompt")
        lines.append("and type e.g.:  chkdsk C: /f")
        return "\n".join(lines)

    def tool_free_space(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("logicaldisk get DeviceID,FreeSpace,Size /format:list")
        if code != 0:
            return "Failed:\n" + (err or out)
        # Try to make a nicer human report
        lines = ["=== Free Space Report ===\n"]
        current = {}
        for line in out.splitlines():
            line = line.strip()
            if not line:
                if current:
                    dev = current.get("DeviceID", "?")
                    try:
                        free = int(current.get("FreeSpace", 0))
                        size = int(current.get("Size", 0))
                        if size > 0:
                            pct = (100.0 * free) / size
                            lines.append("{0}  Free: {1:.1f} GB / {2:.1f} GB  ({3:.1f}% free)".format(
                                dev, free / (1024.0**3), size / (1024.0**3), pct))
                        else:
                            lines.append(dev + "  (size unknown)")
                    except Exception:
                        lines.append(str(current))
                    current = {}
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                current[k.strip()] = v.strip()
        if not lines[1:]:
            lines.append(out)
        return "\n".join(lines)

    def tool_ipconfig(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_ipconfig()
        if code != 0:
            return "ipconfig failed:\n" + (err or out)
        return "=== IP Configuration ===\n\n" + out

    def tool_net_adapters(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("nicconfig get Description,MACAddress,IPAddress,IPSubnet,DefaultIPGateway,DHCPEnabled /format:list")
        if code != 0:
            return "WMIC nicconfig failed:\n" + (err or out)
        return "=== Network Adapters ===\n\n" + out

    def tool_netstat(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("netstat -ano", timeout=20, shell=True)
        if code != 0:
            return "netstat failed:\n" + (err or out)
        return "=== Active Connections (netstat -ano) ===\n\n" + out

    def tool_hosts(self):
        hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
        if not os.path.isfile(hosts_path):
            # Try alternative for some XP installs
            hosts_path = r"C:\WINDOWS\system32\drivers\etc\hosts"
        lines = ["=== Hosts File ===", "Path: " + hosts_path, ""]
        try:
            with open(hosts_path, "r") as f:
                content = f.read()
            lines.append(content)
        except Exception as e:
            lines.append("Could not read hosts file: " + str(e))
        return "\n".join(lines)

    def tool_ping(self):
        # Simple interactive-ish: we just ping a few common targets
        targets = ["127.0.0.1", "192.168.1.1", "8.8.8.8"]
        lines = ["=== Ping Test ===", ""]
        for t in targets:
            lines.append("--- Pinging {0} ---".format(t))
            code, out, err = run_cmd("ping -n 2 " + t, timeout=15, shell=True)
            lines.append(out or err or "(no output)")
            lines.append("")
        return "\n".join(lines)

    def tool_dns_cache(self):
        if not IS_WINDOWS:
            return "Windows only."
        # ipconfig /displaydns exists on XP
        code, out, err = run_cmd("ipconfig /displaydns", timeout=15, shell=True)
        if code != 0:
            return "ipconfig /displaydns failed (may be empty or unsupported):\n" + (err or out)
        # Limit size
        if len(out) > 30000:
            out = out[:30000] + "\n\n… (truncated)"
        return "=== DNS Cache ===\n\n" + out

    def tool_processes(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_tasklist()
        if code != 0:
            return "tasklist failed:\n" + (err or out)
        return "=== Running Processes ===\n\n" + out

    def tool_services(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_sc_query()
        if code != 0:
            # fallback
            code2, out2, err2 = run_cmd("net start", shell=True)
            return "sc query failed, showing net start instead:\n\n" + (out2 or err2)
        return "=== Services (sc query) ===\n\n" + out

    def tool_startup(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== Startup Programs (basic) ===", ""]
        # Common XP startup locations
        locations = [
            r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run",
            r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
            r"HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnce",
            r"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        ]
        for loc in locations:
            lines.append("--- " + loc + " ---")
            code, out, err = run_cmd('reg query "{0}"'.format(loc), timeout=10, shell=True)
            if code == 0:
                lines.append(out)
            else:
                lines.append("(empty or access denied)")
            lines.append("")
        # Startup folder
        startup = os.path.join(os.environ.get("APPDATA", ""),
                               r"Microsoft\Windows\Start Menu\Programs\Startup")
        lines.append("--- User Startup Folder ---")
        lines.append(startup)
        if os.path.isdir(startup):
            for name in os.listdir(startup):
                lines.append("  " + name)
        else:
            lines.append("(folder not found)")
        return "\n".join(lines)

    def tool_temp_cleaner(self):
        lines = ["=== Temp Folder Cleaner ===", ""]
        targets = []
        if IS_WINDOWS:
            targets.append(os.environ.get("TEMP", ""))
            targets.append(os.environ.get("TMP", ""))
            targets.append(r"C:\Windows\Temp")
            targets.append(os.path.join(os.environ.get("USERPROFILE", ""), "Local Settings", "Temp"))
        else:
            targets.append("/tmp")

        total_files = 0
        total_bytes = 0
        errors = 0

        for t in targets:
            if not t or not os.path.isdir(t):
                continue
            lines.append("Scanning: " + t)
            for root, dirs, files in os.walk(t):
                for f in files:
                    path = os.path.join(root, f)
                    try:
                        sz = os.path.getsize(path)
                        os.remove(path)
                        total_files += 1
                        total_bytes += sz
                    except Exception:
                        errors += 1
                # do not remove directories aggressively on XP

        lines.append("")
        lines.append("Removed {0} files ({1:.1f} MB)".format(
            total_files, total_bytes / (1024.0 * 1024.0)))
        if errors:
            lines.append("Could not delete {0} files (in use or access denied)".format(errors))
        lines.append("")
        lines.append("NOTE: Only files were removed. Locked files are left alone.")
        return "\n".join(lines)

    def tool_large_files(self):
        # Very basic: look under user profile for files > 50 MB
        lines = ["=== Find Large Files (basic) ===", ""]
        root = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        lines.append("Scanning under: " + root)
        lines.append("Looking for files larger than 50 MB (may take a while)…")
        lines.append("")

        found = []
        try:
            for dirpath, dirnames, filenames in os.walk(root):
                # skip some heavy / system dirs
                dirnames[:] = [d for d in dirnames if d.lower() not in
                               ("appdata", "application data", "local settings",
                                "cookies", "recent", "temp", "temporary internet files")]
                for fn in filenames:
                    path = os.path.join(dirpath, fn)
                    try:
                        sz = os.path.getsize(path)
                        if sz > 50 * 1024 * 1024:
                            found.append((sz, path))
                    except Exception:
                        pass
                if len(found) > 80:
                    break
        except Exception as e:
            lines.append("Scan error: " + str(e))

        found.sort(reverse=True)
        if not found:
            lines.append("No large files found (or scan limited).")
        else:
            for sz, path in found[:40]:
                lines.append("{0:8.1f} MB  {1}".format(sz / (1024.0 * 1024.0), path))
        return "\n".join(lines)

    def tool_folder_size(self):
        # Ask user for a folder
        folder = filedialog.askdirectory(title="Select folder to measure")
        if not folder:
            return "Cancelled."
        lines = ["=== Folder Size ===", "Folder: " + folder, ""]
        total = 0
        count = 0
        try:
            for dirpath, dirnames, filenames in os.walk(folder):
                for fn in filenames:
                    try:
                        total += os.path.getsize(os.path.join(dirpath, fn))
                        count += 1
                    except Exception:
                        pass
        except Exception as e:
            lines.append("Error: " + str(e))
        lines.append("Files : {0}".format(count))
        lines.append("Size  : {0:.2f} MB ({1} bytes)".format(total / (1024.0 * 1024.0), total))
        return "\n".join(lines)

    def tool_cmd_here(self):
        if not IS_WINDOWS:
            return "Windows only."
        # Open a new cmd window in the user profile
        cwd = os.environ.get("USERPROFILE") or "C:\\"
        try:
            os.startfile("cmd.exe")  # simple
            return "Opened a new Command Prompt window.\n(Working directory depends on the system.)"
        except Exception:
            code, out, err = run_cmd('start cmd.exe /k "cd /d {0}"'.format(cwd), shell=True)
            return "Attempted to open Command Prompt.\n" + (out or err or "")

    def tool_sfc(self):
        lines = [
            "=== System File Checker (SFC) ===",
            "",
            "On Windows XP the classic command is:",
            "",
            "    sfc /scannow",
            "",
            "This requires the original XP CD in many cases and must be run",
            "from an elevated (Administrator) command prompt.",
            "",
            "This XP edition will NOT launch sfc automatically because it can",
            "take a long time and needs the installation media.",
            "",
            "To run it yourself:",
            "  1. Click Start → Run → type  cmd  → OK",
            "  2. Type:  sfc /scannow",
            "  3. Insert the XP CD if asked.",
            "",
        ]
        # Try to see if sfc exists
        code, out, err = run_cmd("sfc", timeout=5, shell=True)
        lines.append("sfc executable presence check:")
        lines.append(out or err or "(no output)")
        return "\n".join(lines)

    def tool_eventlog(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = [
            "=== Event Log (basic) ===",
            "",
            "Full Event Viewer is a MMC snap-in on XP.",
            "We can dump a short summary via WMIC NTEVENT (limited).",
            ""
        ]
        # WMIC NTEVENT can be very slow / large; limit it
        code, out, err = run_cmd(
            'wmic ntevent where "LogFile=\'System\'" get EventCode,SourceName,TimeGenerated /format:list',
            timeout=25, shell=True
        )
        if code == 0 and out and len(out) > 20:
            if len(out) > 25000:
                out = out[:25000] + "\n\n… (truncated)"
            lines.append(out)
        else:
            lines.append("WMIC NTEVENT query failed or returned nothing.")
            lines.append("You can open Event Viewer manually:  eventvwr.msc")
            lines.append(err or out or "")
        return "\n".join(lines)

    def tool_reg_query(self):
        lines = [
            "=== Registry Query Helper ===",
            "",
            "This is a simple helper. Enter a key path in the dialog that appears.",
            ""
        ]
        # We need a simple dialog – use tkinter simpledialog if available
        try:
            from tkinter import simpledialog
            key = simpledialog.askstring(
                "Registry Query",
                "Enter registry key path\n(example: HKLM\\Software\\Microsoft\\Windows\\CurrentVersion)",
                parent=self
            )
        except Exception:
            key = None

        if not key:
            return "Cancelled or no key entered."

        code, out, err = run_cmd('reg query "{0}"'.format(key), timeout=15, shell=True)
        lines.append("Query: " + key)
        lines.append("")
        if code == 0:
            lines.append(out)
        else:
            lines.append("Failed:\n" + (err or out))
        return "\n".join(lines)

    def tool_sfc_status(self):
        return (
            "=== System File Checker Status ===\n\n"
            "Windows XP does not keep a modern CBS log the way Vista+ does.\n"
            "SFC results are usually written to:\n"
            "  %SystemRoot%\\Windows\\Logs\\CBS\\  (on later systems)\n"
            "or shown interactively when you run sfc /scannow.\n\n"
            "On pure XP the best way is still to run sfc /scannow from an\n"
            "Administrator command prompt with the XP CD available.\n"
        )

    def tool_cpu(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("cpu get Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,Manufacturer /format:list")
        if code != 0:
            return "WMIC cpu failed:\n" + (err or out)
        return "=== CPU Info ===\n\n" + out

    def tool_memory(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== Memory Info ===\n"]
        code, out, err = run_wmic("ComputerSystem get TotalPhysicalMemory /format:list")
        if code == 0:
            lines.append(out)
        code, out, err = run_wmic("memphysical get MaxCapacity,MemoryDevices /format:list")
        if code == 0:
            lines.append(out)
        code, out, err = run_wmic("memorychip get Capacity,Speed,Manufacturer,PartNumber /format:list")
        if code == 0:
            lines.append("--- Memory Chips ---")
            lines.append(out)
        return "\n".join(lines)

    def tool_bios(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("bios get Manufacturer,Name,Version,ReleaseDate,SerialNumber /format:list")
        if code != 0:
            return "WMIC bios failed:\n" + (err or out)
        return "=== BIOS Info ===\n\n" + out

    def tool_motherboard(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("baseboard get Manufacturer,Product,Version,SerialNumber /format:list")
        if code != 0:
            return "WMIC baseboard failed:\n" + (err or out)
        return "=== Motherboard ===\n\n" + out

    def tool_features(self):
        feats = feature_status()
        lines = ["=== Feature Detection Report ===\n"]
        for k in sorted(feats.keys()):
            lines.append("  {0:15}: {1}".format(k, feats[k]))
        lines.append("")
        lines.append("IS_WINDOWS = {0}".format(IS_WINDOWS))
        lines.append("IS_XP      = {0}".format(IS_XP))
        return "\n".join(lines)

    def tool_about(self):
        return (
            "TechDrive XP Edition\n"
            "====================\n\n"
            "A separate, reduced toolkit built for Windows XP + Python 3.4.4.\n\n"
            "This edition deliberately avoids modern Python syntax (f-strings,\n"
            "type annotations, pathlib-heavy code, etc.) and modern Windows\n"
            "APIs so it can still run on the last official Python that\n"
            "supported Windows XP.\n\n"
            "Many tools from the full TechDrive are missing or show a clear\n"
            "\"not available on XP\" message because they depend on features\n"
            "that simply do not exist on XP (PowerShell 2+, DISM, modern WMI\n"
            "classes, etc.).\n\n"
            "Use the modern TechDrive on Windows 7 / 10 / 11 for the full\n"
            "experience.\n"
        )

    def tool_help(self):
        return HELP_TEXT

    def tool_eula(self):
        return EULA_TEXT

    def tool_open_appdata(self):
        path = get_app_data_dir()
        ensure_dir(path)
        if IS_WINDOWS:
            try:
                os.startfile(path)
                return "Opened: " + path
            except Exception as e:
                return "Could not open folder:\n{0}\n\nPath: {1}".format(e, path)
        return "App data folder: " + path

    def tool_export_report(self):
        lines = []
        lines.append("TechDrive XP – Full System Report")
        lines.append("Generated: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        lines.append("=" * 60)
        for tool in [
            "System Summary", "OS Details (WMIC)", "Logical Disks",
            "IP Configuration", "CPU Info", "Memory Info", "BIOS Info"
        ]:
            lines.append("\n\n##### " + tool + " #####\n")
            try:
                # force WORKS path
                old = getattr(self, "_current_status", None)
                self._current_status = "WORKS"
                lines.append(self._dispatch_tool(tool))
                self._current_status = old
            except Exception:
                lines.append(format_exception())
        report = "\n".join(lines)
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            title="Save full system report"
        )
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(report)
                return report + "\n\n--- Also saved to: " + path + " ---"
            except Exception as e:
                return report + "\n\nCould not save file: " + str(e)
        return report

    def tool_uptime(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("net statistics workstation", timeout=15, shell=True)
        lines = ["=== Uptime / Statistics ===\n"]
        if code == 0:
            lines.append(out)
        else:
            lines.append("net statistics failed, trying WMIC last boot…")
            code2, out2, err2 = run_wmic("os get LastBootUpTime /format:list")
            lines.append(out2 or err2 or "")
        return "\n".join(lines)

    def tool_defrag(self):
        lines = [
            "=== Defrag (launch) ===",
            "",
            "On Windows XP the classic defragmenter is:",
            "  dfrg.msc   or   defrag.exe",
            "",
            "This edition will try to open the GUI defragmenter.",
            ""
        ]
        if IS_WINDOWS:
            try:
                os.startfile("dfrg.msc")
                lines.append("Launched dfrg.msc")
            except Exception as e:
                lines.append("Could not launch dfrg.msc: " + str(e))
                lines.append("You can run:  defrag C: -a   (analyze only)")
        return "\n".join(lines)

    def tool_recycle(self):
        lines = ["=== Wipe Recycle Bin (limited) ===", ""]
        if not IS_WINDOWS:
            return "Windows only."
        # XP-era approach is limited; we just try to empty known locations
        paths = []
        for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            p = drive + ":\\RECYCLER"
            if os.path.isdir(p):
                paths.append(p)
            p2 = drive + ":\\$Recycle.Bin"
            if os.path.isdir(p2):
                paths.append(p2)
        if not paths:
            lines.append("No Recycle Bin folders found.")
            return "\n".join(lines)
        lines.append("Found: " + ", ".join(paths))
        lines.append("")
        lines.append("For safety this XP edition does NOT auto-delete recycle bin")
        lines.append("contents. Open the Recycle Bin icon on the desktop and")
        lines.append("empty it manually, or use:  rd /s /q <path>  from an")
        lines.append("Administrator command prompt.")
        return "\n".join(lines)

    def tool_compat_matrix(self):
        lines = [
            "=== TechDrive XP – Compatibility Matrix ===",
            "",
            "Legend:",
            "  [OK]  = Works on Windows XP + Python 3.4",
            "  [~]   = Limited / partial support",
            "",
            "(Tools that don't work on XP have been removed from this",
            "edition entirely - this list is only what's actually usable.)",
            "",
        ]
        works = limited = 0
        for cat, tools in XP_CATALOGUE:
            lines.append(cat)
            lines.append("-" * len(cat))
            for name, status in tools:
                lines.append("  {0}  {1}".format(status_label(status), name))
                if status == "WORKS":
                    works += 1
                elif status == "LIMITED":
                    limited += 1
            lines.append("")
        lines.append("Summary:  {0} works,  {1} limited".format(works, limited))
        return "\n".join(lines)

    # ----- newly expanded tools -----

    def tool_product_key(self):
        lines = ["=== License / Product Key (limited) ===\n"]
        if not IS_WINDOWS:
            return "Windows only."
        # XP-era: try wmic + OA3 style keys are rare; often only partial
        code, out, err = run_wmic("os get SerialNumber /format:list")
        if code == 0:
            lines.append(out)
        code, out, err = run_cmd(
            'reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion" /v ProductId',
            shell=True)
        if code == 0:
            lines.append(out)
        lines.append("")
        lines.append("Note: Full OEM product key decoding is limited on XP.")
        lines.append("You can also try:  wmic path softwarelicensingservice get OA3xOriginalProductKey")
        lines.append("(often empty on classic XP).")
        return "\n".join(lines)

    def tool_logged_users(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("query user", shell=True)
        if code != 0:
            code, out, err = run_wmic("computersystem get UserName /format:list")
        return "=== Logged On Users ===\n\n" + (out or err or "")

    def tool_timezone(self):
        lines = ["=== Time Zone & Locale ===\n"]
        lines.append("Python locale/time info:")
        try:
            import time as _t
            lines.append("  Local time : " + _t.strftime("%Y-%m-%d %H:%M:%S %Z"))
            lines.append("  UTC offset : " + str(_t.timezone))
        except Exception as e:
            lines.append(str(e))
        if IS_WINDOWS:
            code, out, err = run_cmd("tzutil /g", shell=True)
            if code == 0:
                lines.append("\ntzutil: " + out.strip())
            else:
                code, out, err = run_wmic("timezone get Description,StandardName /format:list")
                lines.append(out or err or "")
            code, out, err = run_cmd("chcp", shell=True)
            if code == 0:
                lines.append("Code page: " + out.strip())
        return "\n".join(lines)

    def tool_disk_cleanup(self):
        lines = ["=== Disk Cleanup (launch) ===\n"]
        if IS_WINDOWS:
            try:
                os.startfile("cleanmgr.exe")
                lines.append("Launched cleanmgr.exe")
            except Exception as e:
                lines.append("Could not launch: " + str(e))
                lines.append("Run manually:  cleanmgr")
        return "\n".join(lines)

    def tool_smart(self):
        lines = [
            "=== SMART Health (limited) ===",
            "",
            "Classic XP does not ship a full SMART viewer.",
            "Attempting WMIC disk status…",
            ""
        ]
        code, out, err = run_wmic("diskdrive get Model,Status,Size,MediaType /format:list")
        if code == 0:
            lines.append(out)
        else:
            lines.append(err or "WMIC failed")
        lines.append("")
        lines.append("For real SMART attributes on XP you need a 3rd-party tool")
        lines.append("(CrystalDiskInfo older builds, smartmontools, etc.).")
        return "\n".join(lines)

    def tool_arp(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("arp -a", shell=True)
        return "=== ARP Table ===\n\n" + (out or err or "")

    def tool_route(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("route print", shell=True)
        return "=== Routing Table ===\n\n" + (out or err or "")

    def tool_shares(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("net share", shell=True)
        return "=== Shared Folders ===\n\n" + (out or err or "")

    def tool_firewall(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== Firewall Status (XP-era netsh) ===\n"]
        # XP used "netsh firewall", Vista+ uses "netsh advfirewall"
        code, out, err = run_cmd("netsh firewall show state", shell=True)
        if code == 0 and out:
            lines.append(out)
        else:
            code2, out2, err2 = run_cmd("netsh firewall show opmode", shell=True)
            lines.append(out2 or err2 or err or "Could not query firewall")
        return "\n".join(lines)

    def tool_winsock(self):
        return (
            "=== Winsock Reset (guidance) ===\n\n"
            "On Windows XP the usual commands are:\n\n"
            "  netsh winsock reset\n"
            "  netsh int ip reset resetlog.txt\n\n"
            "Run them from an Administrator command prompt, then reboot.\n"
            "This edition does not run the reset automatically."
        )

    def tool_wifi(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== WiFi Info (limited on XP) ===\n"]
        code, out, err = run_cmd("netsh wlan show interfaces", shell=True)
        if code == 0 and out and "not recognized" not in out.lower():
            lines.append(out)
        else:
            lines.append("netsh wlan is limited or missing on pure XP.")
            lines.append("Trying WMIC NIC list instead…\n")
            code, out, err = run_wmic("nic where NetEnabled=true get Name,MACAddress,Speed /format:list")
            lines.append(out or err or "")
        return "\n".join(lines)

    def tool_kill_process(self):
        if not IS_WINDOWS:
            return "Windows only."
        try:
            from tkinter import simpledialog
            name = simpledialog.askstring("Kill Process", "Enter process name (e.g. notepad.exe):", parent=self)
        except Exception:
            name = None
        if not name:
            return "Cancelled."
        name = name.strip()
        if not name.lower().endswith(".exe"):
            name = name + ".exe"
        code, out, err = run_cmd('taskkill /IM "{0}" /F'.format(name), shell=True)
        return "=== Kill Process ===\n\nCommand: taskkill /IM {0} /F\n\n{1}".format(name, out or err or "")

    def tool_service_control(self):
        if not IS_WINDOWS:
            return "Windows only."
        try:
            from tkinter import simpledialog
            svc = simpledialog.askstring(
                "Service Control",
                "Enter service name (e.g. Spooler)\nThen we show status. Start/Stop needs care.",
                parent=self)
        except Exception:
            svc = None
        if not svc:
            return "Cancelled."
        code, out, err = run_cmd('sc query "{0}"'.format(svc.strip()), shell=True)
        lines = ["=== Service: {0} ===\n".format(svc), out or err or ""]
        lines.append("\nTo start:  sc start \"{0}\"".format(svc.strip()))
        lines.append("To stop:   sc stop \"{0}\"".format(svc.strip()))
        lines.append("(Run from Administrator command prompt.)")
        return "\n".join(lines)

    def tool_schtasks(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("schtasks /query /fo LIST", timeout=25, shell=True)
        if code != 0:
            return "schtasks failed (may need XP SP2+):\n" + (err or out or "")
        if len(out) > 40000:
            out = out[:40000] + "\n\n… (truncated)"
        return "=== Scheduled Tasks ===\n\n" + out

    def tool_reg_export(self):
        if not IS_WINDOWS:
            return "Windows only."
        path = filedialog.asksaveasfilename(
            defaultextension=".reg",
            filetypes=[("Registry files", "*.reg")],
            title="Export registry key to…"
        )
        if not path:
            return "Cancelled."
        try:
            from tkinter import simpledialog
            key = simpledialog.askstring(
                "Registry Export",
                "Key to export (example: HKLM\\Software\\Microsoft\\Windows\\CurrentVersion)",
                parent=self)
        except Exception:
            key = "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion"
        if not key:
            return "Cancelled."
        code, out, err = run_cmd('reg export "{0}" "{1}" /y'.format(key, path), shell=True)
        if code == 0:
            return "Exported {0}\nto {1}\n\n{2}".format(key, path, out or "OK")
        return "Export failed:\n" + (err or out or "")

    def tool_sysrestore(self):
        lines = ["=== System Restore (launch) ===\n"]
        if IS_WINDOWS:
            try:
                os.startfile("rstrui.exe")
                lines.append("Launched rstrui.exe")
            except Exception as e:
                lines.append("Could not launch rstrui.exe: " + str(e))
                lines.append("On XP: Start → All Programs → Accessories → System Tools → System Restore")
        return "\n".join(lines)

    def tool_gpu(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic(
            "path win32_VideoController get Name,DriverVersion,AdapterRAM,VideoProcessor,Status /format:list")
        return "=== GPU / Video Controller ===\n\n" + (out or err or "")

    def tool_monitor(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== Monitor / Display ===\n"]
        code, out, err = run_wmic(
            "desktopmonitor get ScreenHeight,ScreenWidth,Name,Status /format:list")
        if code == 0:
            lines.append(out)
        code, out, err = run_wmic(
            "path Win32_DisplayConfiguration get DeviceName,BitsPerPel,PelsWidth,PelsHeight /format:list")
        if code == 0:
            lines.append(out)
        return "\n".join(lines)

    def tool_battery(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic(
            "path Win32_Battery get Name,EstimatedChargeRemaining,BatteryStatus,DesignCapacity /format:list")
        if code != 0 or not (out or "").strip():
            return "=== Battery Info ===\n\nNo battery detected (desktop?) or WMIC failed.\n" + (err or "")
        return "=== Battery Info ===\n\n" + out

    def tool_printers(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("printer get Name,PortName,DriverName,Shared /format:list")
        return "=== Printers ===\n\n" + (out or err or "")

    def tool_pnp(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic(
            "path Win32_PnPEntity get Name,Status,DeviceID /format:list", timeout=40)
        if len(out or "") > 50000:
            out = out[:50000] + "\n\n… (truncated)"
        return "=== USB / PnP Devices ===\n\n" + (out or err or "")

    def tool_sound(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic(
            "sounddev get Name,Manufacturer,Status /format:list")
        return "=== Sound Devices ===\n\n" + (out or err or "")

    def tool_drivers(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("driverquery /v", timeout=40, shell=True)
        if code != 0:
            code, out, err = run_cmd("driverquery", shell=True)
        if len(out or "") > 50000:
            out = out[:50000] + "\n\n… (truncated)"
        return "=== Driver List ===\n\n" + (out or err or "")

    def tool_devmgmt(self):
        if IS_WINDOWS:
            try:
                os.startfile("devmgmt.msc")
                return "Launched Device Manager (devmgmt.msc)"
            except Exception as e:
                return "Could not launch: " + str(e)
        return "Windows only."

    def tool_users(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("net user", shell=True)
        return "=== Local Users ===\n\n" + (out or err or "")

    def tool_folder_copy(self):
        src = filedialog.askdirectory(title="Source folder")
        if not src:
            return "Cancelled."
        dst = filedialog.askdirectory(title="Destination folder")
        if not dst:
            return "Cancelled."
        lines = ["=== Simple Folder Copy ===", "From: " + src, "To:   " + dst, ""]
        try:
            # Python 3.4 has shutil.copytree
            target = os.path.join(dst, os.path.basename(src.rstrip("\\/")))
            if os.path.exists(target):
                return "Target already exists:\n" + target + "\nChoose another destination."
            shutil.copytree(src, target)
            lines.append("Copy finished.")
            lines.append("Created: " + target)
        except Exception as e:
            lines.append("Error: " + str(e))
        return "\n".join(lines)

    def tool_volume(self):
        if IS_WINDOWS:
            try:
                os.startfile("sndvol32.exe")
                return "Launched Volume Control (sndvol32.exe)"
            except Exception:
                try:
                    os.startfile("sndvol.exe")
                    return "Launched sndvol.exe"
                except Exception as e:
                    return "Could not launch volume control: " + str(e)
        return "Windows only."

    def tool_magnifier(self):
        if IS_WINDOWS:
            try:
                os.startfile("magnify.exe")
                return "Launched Magnifier (magnify.exe)"
            except Exception as e:
                return "Could not launch: " + str(e)
        return "Windows only."

    def tool_osk(self):
        if IS_WINDOWS:
            try:
                os.startfile("osk.exe")
                return "Launched On-Screen Keyboard (osk.exe)"
            except Exception as e:
                return "Could not launch: " + str(e)
        return "Windows only."

    def tool_sysdm(self):
        if IS_WINDOWS:
            try:
                os.startfile("sysdm.cpl")
                return "Launched System Properties (sysdm.cpl)"
            except Exception as e:
                return "Could not launch: " + str(e)
        return "Windows only."

    def tool_control(self):
        if IS_WINDOWS:
            try:
                os.startfile("control.exe")
                return "Launched Control Panel"
            except Exception as e:
                return "Could not launch: " + str(e)
        return "Windows only."



    def tool_installed_programs(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== Installed Programs (WMIC product) ===", "",
                 "This can take a while on XP…", ""]
        code, out, err = run_wmic("product get Name,Version /format:list", timeout=90)
        if code == 0:
            if len(out) > 60000:
                out = out[:60000] + "\n\n… (truncated)"
            lines.append(out)
        else:
            lines.append(err or out or "Failed (some XP systems lack the product provider)")
        return "\n".join(lines)

    def tool_getmac(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("getmac /v /fo list", shell=True)
        return "=== MAC Addresses ===\n\n" + (out or err or "")

    def tool_whoami(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("whoami", shell=True)
        lines = ["=== Who Am I ===\n", out or err or ""]
        code, out, err = run_cmd("whoami /groups", shell=True)
        if code == 0:
            lines.append("\n--- Groups ---\n")
            lines.append(out)
        return "\n".join(lines)

    def tool_pagefile(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("pagefileset get Name,InitialSize,MaximumSize /format:list")
        return "=== Page File ===\n\n" + (out or err or "")

    def tool_shares_wmic(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("share get Name,Path,Description /format:list")
        return "=== Shares (WMIC) ===\n\n" + (out or err or "")

    def tool_netuse(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("net use", shell=True)
        return "=== Mapped Drives (net use) ===\n\n" + (out or err or "")

    def tool_nbtstat(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("nbtstat -n", shell=True)
        return "=== NetBIOS Names ===\n\n" + (out or err or "")

    def tool_fsutil(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== FSUTIL info ===\n"]
        for drv in "CDEF":
            p = drv + ":\\"
            if os.path.exists(p):
                code, out, err = run_cmd("fsutil fsinfo volumeinfo " + drv + ":", shell=True)
                lines.append("--- " + drv + ": ---")
                lines.append(out or err or "")
                lines.append("")
        return "\n".join(lines)

    def tool_openfiles(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_cmd("openfiles /query /fo list", timeout=20, shell=True)
        return "=== Open Files ===\n\n" + (out or err or "May need: openfiles /local on  (then reboot)")

    def tool_services_msc(self):
        if IS_WINDOWS:
            try:
                os.startfile("services.msc")
                return "Launched services.msc"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_eventvwr(self):
        if IS_WINDOWS:
            try:
                os.startfile("eventvwr.msc")
                return "Launched Event Viewer (eventvwr.msc)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_diskmgmt(self):
        if IS_WINDOWS:
            try:
                os.startfile("diskmgmt.msc")
                return "Launched Disk Management (diskmgmt.msc)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_compmgmt(self):
        if IS_WINDOWS:
            try:
                os.startfile("compmgmt.msc")
                return "Launched Computer Management (compmgmt.msc)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_appwiz(self):
        if IS_WINDOWS:
            try:
                os.startfile("appwiz.cpl")
                return "Launched Add/Remove Programs (appwiz.cpl)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_desk(self):
        if IS_WINDOWS:
            try:
                os.startfile("desk.cpl")
                return "Launched Display Properties (desk.cpl)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_timedate(self):
        if IS_WINDOWS:
            try:
                os.startfile("timedate.cpl")
                return "Launched Date and Time (timedate.cpl)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_powercfg(self):
        if IS_WINDOWS:
            try:
                os.startfile("powercfg.cpl")
                return "Launched Power Options (powercfg.cpl)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_firewall_cpl(self):
        if IS_WINDOWS:
            try:
                os.startfile("firewall.cpl")
                return "Launched Windows Firewall (firewall.cpl)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_lusrmgr(self):
        if IS_WINDOWS:
            try:
                os.startfile("lusrmgr.msc")
                return "Launched Local Users and Groups (lusrmgr.msc)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_msconfig(self):
        if IS_WINDOWS:
            try:
                os.startfile("msconfig.exe")
                return "Launched System Configuration (msconfig.exe)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_dxdiag(self):
        if IS_WINDOWS:
            try:
                os.startfile("dxdiag.exe")
                return "Launched DirectX Diagnostic (dxdiag.exe)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_perfmon(self):
        if IS_WINDOWS:
            try:
                os.startfile("perfmon.msc")
                return "Launched Performance Monitor (perfmon.msc)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_taskmgr(self):
        if IS_WINDOWS:
            try:
                os.startfile("taskmgr.exe")
                return "Launched Task Manager (taskmgr.exe)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_notepad(self):
        if IS_WINDOWS:
            try:
                os.startfile("notepad.exe")
                return "Launched Notepad"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_calc(self):
        if IS_WINDOWS:
            try:
                os.startfile("calc.exe")
                return "Launched Calculator"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_ip_release_renew(self):
        return (
            "=== IP Release / Renew (guidance) ===\n\n"
            "From an Administrator command prompt:\n\n"
            "  ipconfig /release\n"
            "  ipconfig /renew\n"
            "  ipconfig /flushdns\n\n"
            "This edition does not run these automatically (they drop network briefly)."
        )

    def tool_cipher_wipe(self):
        return (
            "=== Wipe Free Space (cipher guidance) ===\n\n"
            "On XP Pro you can use:\n\n"
            "  cipher /w:C:\\folder\n\n"
            "This overwrites free space. It takes a long time.\n"
            "Not run automatically for safety."
        )

    def tool_compact(self):
        if not IS_WINDOWS:
            return "Windows only."
        lines = ["=== NTFS Compression (compact) ===\n"]
        code, out, err = run_cmd("compact /?", shell=True)
        lines.append("compact.exe is available on XP.")
        lines.append("Example:  compact /c /s:C:\\folder")
        lines.append("")
        lines.append(out[:1500] if out else "")
        return "\n".join(lines)



    def tool_regedit(self):
        if IS_WINDOWS:
            try:
                os.startfile("regedit.exe")
                return "Launched Registry Editor (regedit.exe)"
            except Exception as e:
                return str(e)
        return "Windows only."

    def tool_zip_guide(self):
        return (
            "=== Zip / Unzip (guidance) ===\n\n"
            "Windows XP has limited built-in ZIP support (Compressed Folders).\n"
            "Right-click a folder → Send To → Compressed (zipped) Folder.\n"
            "Or install 7-Zip / WinZip classic builds that still support XP."
        )

    def tool_dll_guide(self):
        return (
            "=== DLL Register / Unregister ===\n\n"
            "From an Administrator command prompt:\n\n"
            "  regsvr32 mydll.dll\n"
            "  regsvr32 /u mydll.dll\n\n"
            "Use with care."
        )

    def tool_virt_check(self):
        if not IS_WINDOWS:
            return "Windows only."
        code, out, err = run_wmic("cpu get VirtualizationFirmwareEnabled,SecondLevelAddressTranslationExtensions /format:list")
        lines = ["=== Virtualization Check (limited on XP) ===\n", out or err or ""]
        lines.append("\nFull Hyper-V / SLAT checks need newer Windows.")
        return "\n".join(lines)

    def tool_access_guide(self):
        return (
            "=== Accessibility (guidance) ===\n\n"
            "On XP:\n"
            "  Control Panel → Accessibility Options\n"
            "  or run:  access.cpl\n\n"
            "Magnifier: magnify.exe\n"
            "On-Screen Keyboard: osk.exe"
        )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    if not IS_WINDOWS:
        print("Warning: TechDrive XP is intended for Windows. Continuing anyway…")

    app = TechDriveXPApp()
    app.mainloop()


if __name__ == "__main__":
    main()
