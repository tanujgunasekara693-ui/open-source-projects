#!/usr/bin/env python3
"""
gui/onboarding_tour_canvas.py — First-run welcome tour (classic, in-window)
==================================================
A short, animated, slide-based welcome tour in the spirit of the old
"Discover Windows" first-run tours — but entirely original: no Microsoft
artwork, icons, fonts, or copy, just plain Tkinter Canvas shapes/emoji
and TechDrive's own duck mascot (already used by Duck Assistant
elsewhere in the app).

Styled with the same design tokens as the rest of the shell (gui.fluent)
so it matches the app's dark, neon-cyan-accented look instead of carrying
its own separate hardcoded palette — and follows the user's current
theme (dark/light) rather than always forcing dark.

Shown automatically once per install (tracked via shared.database's
settings table, key "onboarding_tour_shown"), and re-playable any time
from Settings → "Replay Welcome Tour".

Public API:
    maybe_show(app)       — shows the tour only if it's never been shown
    show(app)             — always shows it (used by the Settings replay button)
"""

import math
import random
import tkinter as tk
import tkinter.font as tkfont

from shared import database as db
from gui import fluent as fl
from gui.widgets import round_rect

_CATEGORY_CARDS = [
    ("partition", "Partition Tools"),
    ("clone", "Cloning & Imaging"),
    ("bench", "Benchmarking"),
    ("monitor", "Live Monitoring"),
    ("security", "Security & Wipe"),
]

# -- easing ----------------------------------------------------------------
# Small, dependency-free easing curves so every animation accelerates /
# decelerates instead of moving at a robotic constant speed.


def _ease_out_cubic(t):
    return 1 - (1 - t) ** 3


def _ease_out_back(t, overshoot=1.7):
    t -= 1
    return 1 + (overshoot + 1) * t ** 3 + overshoot * t ** 2


def _ease_in_out_sine(t):
    return -(math.cos(math.pi * t) - 1) / 2


class _Tour:
    def __init__(self, app):
        self.app = app
        self.theme = getattr(app, "theme", fl.DARK)
        th = self.theme
        self.bg = th["BG"]
        self.card_bg = th["CARD_BG"]
        self.fg = th["FG"]
        self.muted = th["MUTED"]
        self.accent = th["ACCENT"]
        self.accent_glow = th["ACCENT_GLOW"]
        # Category cards cycle through the same accent ramp used by the
        # dashboard's metric cards, so the tour reads as part of the app
        # rather than a separately-themed splash screen.
        self._card_colors = [self.accent, th.get("ACCENT3", self.accent),
                             fl.METRIC_COLORS["gpu"], th.get("ACCENT2", self.accent),
                             fl.BAD]

        self._closing = False
        self._anim_jobs = []  # every pending `after` id, cancelled on transition/close

        self.win = tk.Toplevel(app)
        self.win.title("Welcome to TechDrive")
        self.win.geometry("680x480")
        self.win.resizable(False, False)
        self.win.configure(bg=self.bg)
        self.win.transient(app)
        self.win.protocol("WM_DELETE_WINDOW", self._finish)
        self.win.grab_set()
        try:
            self.win.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self._center()

        # Thin neon top rule — matches the app's Fluent header treatment.
        tk.Frame(self.win, bg=self.accent, height=3).pack(fill="x")

        # Small "TD" brand badge + wordmark, echoing the topbar/app icon.
        brand = tk.Frame(self.win, bg=self.bg)
        brand.pack(fill="x", padx=24, pady=(16, 0))
        badge = tk.Canvas(brand, width=30, height=30, bg=self.bg,
                          highlightthickness=0)
        badge.pack(side="left")
        round_rect(badge, 1, 1, 29, 29, r=8,
                   fill=fl.mix(self.bg, "#050a12", 0.7), outline=self.accent, width=1)
        badge.create_text(15, 14, text="TD", fill="#ffffff", font=fl.font(9, "bold", True))
        badge.create_line(8, 22, 21, 21, fill=self.accent, width=2)
        tk.Label(brand, text="TechDrive", bg=self.bg, fg=self.fg,
                font=fl.font(11, "bold", True)).pack(side="left", padx=(8, 0))

        self.canvas = tk.Canvas(self.win, width=680, height=352, bg=self.bg,
                                highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=0, pady=(8, 0))

        nav = tk.Frame(self.win, bg=self.bg)
        nav.pack(fill="x", pady=(12, 18), padx=20)

        self.dots_frame = tk.Frame(nav, bg=self.bg)
        self.dots_frame.pack(side="left")
        self.dot_labels = []

        self.skip_btn = tk.Button(nav, text="Skip", command=self._finish, bg=self.bg,
                                  fg=self.muted, relief="flat", bd=0, font=fl.font(9),
                                  cursor="hand2", activebackground=self.bg,
                                  activeforeground=self.fg)
        self.skip_btn.pack(side="right")

        self.next_canvas = tk.Canvas(nav, width=150, height=34, bg=self.bg,
                                     highlightthickness=0, cursor="hand2")
        self.next_canvas.pack(side="right", padx=(0, 10))
        self.next_canvas.bind("<Button-1>", lambda _e: self._next())
        self.next_canvas.bind("<Enter>", lambda _e: self._set_next_hover(True))
        self.next_canvas.bind("<Leave>", lambda _e: self._set_next_hover(False))
        self._next_hover = False

        self.back_btn = tk.Button(nav, text="◀  Back", command=self._back, bg=self.bg,
                                  fg=self.muted, relief="flat", bd=0, font=fl.font(9),
                                  cursor="hand2", activebackground=self.bg,
                                  activeforeground=self.fg)
        self.back_btn.pack(side="right", padx=(0, 14))

        self.slides = [self._slide_welcome, self._slide_promise, self._slide_benchmark,
                      self._slide_partition, self._slide_categories, self._slide_enable_disable_tools,
                      self._slide_network, self._slide_gaming, self._slide_monitor,
                      self._slide_safety, self._slide_assistant, self._slide_shortcuts,
                      self._slide_ready]
        self._build_dots()
        self.index = 0
        self._orbit_running = False

        # Soft drifting glow orbs behind every slide — continuous, subtle,
        # and never cleared between slides so the background never
        # visibly "resets" on a transition.
        self._orbs = self._make_orbs()

        self._render(transition=False)
        self._fade_window_in()
        self._drift_orbs()

    # -- window-level entrance / exit --------------------------------------
    def _fade_window_in(self, n=0, steps=10):
        if not self.win.winfo_exists():
            return
        alpha = _ease_out_cubic(n / steps)
        try:
            self.win.attributes("-alpha", alpha)
        except tk.TclError:
            return
        if n < steps:
            self._track(self.win.after(14, lambda: self._fade_window_in(n + 1, steps)))

    def _center(self):
        self.win.update_idletasks()
        x = self.app.winfo_x() + (self.app.winfo_width() - 680) // 2
        y = self.app.winfo_y() + (self.app.winfo_height() - 480) // 2
        self.win.geometry(f"+{max(0, x)}+{max(0, y)}")

    # -- job bookkeeping ----------------------------------------------------
    def _track(self, job_id):
        self._anim_jobs.append(job_id)
        return job_id

    def _cancel_pending(self):
        for job in self._anim_jobs:
            for widget in (self.canvas, self.win):
                try:
                    widget.after_cancel(job)
                except tk.TclError:
                    pass
        self._anim_jobs = []

    # -- ambient background --------------------------------------------------
    def _make_orbs(self):
        specs = []
        for i in range(4):
            color = self._card_colors[i % len(self._card_colors)]
            specs.append({
                "cx": random.uniform(90, 590),
                "cy": random.uniform(60, 300),
                "r": random.uniform(70, 130),
                "color": color,
                "phase": random.uniform(0, math.tau),
                "speed": random.uniform(0.010, 0.020),
                "item": None,
            })
        return specs

    def _drift_orbs(self, t=0.0):
        if not self.win.winfo_exists() or self._closing:
            return
        c = self.canvas
        for orb in self._orbs:
            x = orb["cx"] + 26 * math.sin(t * orb["speed"] * 60 + orb["phase"])
            y = orb["cy"] + 16 * math.cos(t * orb["speed"] * 78 + orb["phase"])
            r = orb["r"]
            fill = fl.mix(self.bg, orb["color"], 0.07)
            try:
                if orb["item"] is None:
                    orb["item"] = c.create_oval(x - r, y - r, x + r, y + r,
                                                fill=fill, outline="")
                else:
                    c.coords(orb["item"], x - r, y - r, x + r, y + r)
                c.tag_lower(orb["item"])
            except tk.TclError:
                return
        self.canvas.after(45, lambda: self._drift_orbs(t + 1))

    def _set_next_hover(self, hover):
        self._next_hover = hover
        self._draw_next_button()

    def _build_dots(self):
        for w in self.dots_frame.winfo_children():
            w.destroy()
        self.dot_labels = []
        for i in range(len(self.slides)):
            lbl = tk.Label(self.dots_frame, text="●", bg=self.bg,
                           fg=fl.mix(self.bg, self.fg, 0.25), font=("Segoe UI", 12))
            lbl.pack(side="left", padx=2)
            self.dot_labels.append(lbl)

    def _update_dots(self):
        for i, lbl in enumerate(self.dot_labels):
            lbl.config(fg=self.accent if i == self.index else fl.mix(self.bg, self.fg, 0.25))

    def _draw_next_button(self):
        c = self.next_canvas
        c.delete("all")
        label = "Get Started" if self.index == len(self.slides) - 1 else "Next  ›"
        fill = fl.mix(self.bg, self.accent, 0.85) if self._next_hover else self.accent
        font = fl.font(10, "bold", True)

        # Size the pill to the actual rendered text, not a hardcoded pixel
        # width — the label ("Next ›" vs "Get Started") and its rendered
        # width both change with the user's Font Size setting, so a fixed
        # width clips at larger scales or on the longer "Get Started" label.
        text_w = tkfont.Font(font=font).measure(label)
        pad_x = 22
        btn_w = max(150, text_w + pad_x * 2)
        btn_h = 34

        if int(c["width"]) != btn_w:
            c.config(width=btn_w)

        round_rect(c, 1, 1, btn_w - 1, btn_h - 1, r=17, fill=fill, outline="")
        c.create_text(btn_w / 2, btn_h / 2, text=label, fill=self.theme["ON_ACCENT"],
                      font=font)

    # -- slide transitions ----------------------------------------------------
    def _render(self, transition=True):
        self._cancel_pending()
        self._stop_orbit()
        self._update_dots()
        self.back_btn.config(state="normal" if self.index > 0 else "disabled")
        self._draw_next_button()

        orb_ids = {orb["item"] for orb in self._orbs}
        for item in self.canvas.find_all():
            if item not in orb_ids:
                self.canvas.delete(item)

        self.slides[self.index]()

        if transition:
            fg_items = [i for i in self.canvas.find_all() if i not in orb_ids]
            self._crossfade_in(fg_items)

    def _crossfade_in(self, items, steps=7, delay=15):
        """Fades the newly-built slide's content in rather than snapping
        straight to it, so switching slides reads as a soft dissolve."""
        for item in items:
            try:
                self.canvas.itemconfig(item, state="hidden")
            except tk.TclError:
                pass

        def step(n=0):
            if not self.canvas.winfo_exists() or self._closing:
                return
            if n == 0:
                for item in items:
                    try:
                        self.canvas.itemconfig(item, state="normal")
                    except tk.TclError:
                        return
            if n < steps:
                self._track(self.win.after(delay, lambda: step(n + 1)))
        step()

    def _next(self):
        if self.index == len(self.slides) - 1:
            self._finish()
            return
        self.index += 1
        self._render()

    def _back(self):
        if self.index > 0:
            self.index -= 1
            self._render()

    def _finish(self):
        if self._closing:
            return
        self._closing = True
        self._cancel_pending()
        db.set_setting("onboarding_tour_shown", True)
        self._fade_window_out()

    def _fade_window_out(self, n=0, steps=8):
        if not self.win.winfo_exists():
            return
        alpha = 1 - _ease_out_cubic(n / steps)
        try:
            self.win.attributes("-alpha", max(0.0, alpha))
        except tk.TclError:
            self._destroy()
            return
        if n < steps:
            self.win.after(12, lambda: self._fade_window_out(n + 1, steps))
        else:
            self._destroy()

    def _destroy(self):
        try:
            self.win.grab_release()
        except Exception:
            pass
        try:
            self.win.destroy()
        except Exception:
            pass

    # -- animation helpers ------------------------------------------------------
    def _slide_in(self, item, target_x, y, steps=18, delay=14, ease=_ease_out_cubic):
        """Slides a canvas item in from the right along an eased curve
        (decelerating into place) instead of a linear one."""
        start_x = target_x + 220

        def step(n=0):
            if not self.canvas.winfo_exists() or self._closing:
                return
            t = ease(n / steps)
            x = start_x + (target_x - start_x) * t
            try:
                self.canvas.coords(item, x, y)
            except tk.TclError:
                return
            if n < steps:
                self._track(self.canvas.after(delay, lambda: step(n + 1)))
        step()

    def _pop_in(self, items, cx, cy, steps=14, delay=14):
        """Scales a group of items up from nothing with a slight
        overshoot ("pop"), anchored at (cx, cy)."""
        for item in items:
            try:
                self.canvas.scale(item, cx, cy, 0.001, 0.001)
            except tk.TclError:
                return

        def step(n=0, prev=0.0):
            if not self.canvas.winfo_exists() or self._closing:
                return
            t = _ease_out_back(n / steps)
            factor = (1 + t) / (1 + prev) if (1 + prev) else 1
            for item in items:
                try:
                    self.canvas.scale(item, cx, cy, factor, factor)
                except tk.TclError:
                    return
            if n < steps:
                self._track(self.canvas.after(delay, lambda: step(n + 1, t)))
        step()

    def _fade_text(self, item, colors, delay=32):
        """Simulated fade-in by stepping through a color ramp toward the final color."""
        def step(i=0):
            if not self.canvas.winfo_exists() or self._closing:
                return
            try:
                self.canvas.itemconfig(item, fill=colors[i])
            except tk.TclError:
                return
            if i < len(colors) - 1:
                self._track(self.canvas.after(delay, lambda: step(i + 1)))
        step()

    def _rise_fade(self, item, target_y, colors, rise=16, steps=12, delay=16):
        """Moves an item up into place while stepping its fill through a
        color ramp — a combined slide+fade entrance for headline text."""
        try:
            self.canvas.coords(item, self.canvas.coords(item)[0], target_y + rise)
            self.canvas.itemconfig(item, fill=colors[0])
        except tk.TclError:
            return

        def step(n=0):
            if not self.canvas.winfo_exists() or self._closing:
                return
            t = _ease_out_cubic((n + 1) / steps)
            y = target_y + rise * (1 - t)
            color_i = min(len(colors) - 1, int(t * (len(colors) - 1)))
            try:
                x = self.canvas.coords(item)[0]
                self.canvas.coords(item, x, y)
                self.canvas.itemconfig(item, fill=colors[color_i])
            except tk.TclError:
                return
            if n < steps - 1:
                self._track(self.canvas.after(delay, lambda: step(n + 1)))
        step()

    # -- hero badge: a drawn vector mark (no emoji) used in place of the
    # old duck mascot, with orbiting particles and a soft pulse glow --------
    def _bolt_points(self, cx, cy, s):
        pts = [(0.16, -0.92), (-0.34, 0.06), (0.02, 0.06),
               (-0.16, 0.92), (0.34, -0.14), (0.02, -0.14)]
        coords = []
        for dx, dy in pts:
            coords.extend((cx + dx * s, cy + dy * s))
        return coords

    def _hero_badge(self, cx, cy, r=46):
        c = self.canvas
        glow = c.create_oval(cx - r - 22, cy - r - 22, cx + r + 22, cy + r + 22,
                             fill=fl.mix(self.bg, self.accent, 0.14), outline="")
        ring = c.create_oval(cx - r - 12, cy - r - 12, cx + r + 12, cy + r + 12,
                             outline=fl.mix(self.bg, self.accent, 0.5), width=1.5)
        badge = round_rect(c, cx - r, cy - r, cx + r, cy + r, r=20,
                           fill=self.accent, outline="")
        rim = round_rect(c, cx - r, cy - r, cx + r, cy + r, r=20,
                         fill="", outline=fl.mix(self.accent, "#ffffff", 0.35), width=1.5)
        bolt = c.create_polygon(self._bolt_points(cx, cy, r * 0.5),
                                fill=self.theme["ON_ACCENT"], outline="")
        # orbiting particles — small dots that continuously circle the badge
        orbit_items = []
        n_particles = 6
        for i in range(n_particles):
            color = self._card_colors[i % len(self._card_colors)]
            d = c.create_oval(0, 0, 6, 6, fill=color, outline="")
            orbit_items.append({"item": d, "angle": (math.tau / n_particles) * i,
                               "radius": r + 32, "speed": 0.045})
        self._orbit_particles = orbit_items
        self._orbit_center = (cx, cy)
        self._orbit_running = True
        self._spin_orbit()
        for item in (glow, ring, badge, rim, bolt):
            self.canvas.scale(item, cx, cy, 0.001, 0.001)
        self._pop_in([glow, ring, badge, rim, bolt], cx, cy, steps=16)
        return [glow, ring, badge, rim, bolt]

    def _spin_orbit(self, t=0.0):
        if (not self.canvas.winfo_exists() or self._closing
                or not getattr(self, "_orbit_running", False)):
            return
        cx, cy = self._orbit_center
        for p in self._orbit_particles:
            ang = p["angle"] + t * p["speed"]
            x = cx + math.cos(ang) * p["radius"]
            y = cy + math.sin(ang) * p["radius"] * 0.5
            try:
                self.canvas.coords(p["item"], x - 3, y - 3, x + 3, y + 3)
            except tk.TclError:
                return
        self._track(self.canvas.after(30, lambda: self._spin_orbit(t + 1)))

    def _stop_orbit(self):
        self._orbit_running = False

    def _neon_text(self, x, y, text, font, base_color, glow_color, justify="center", width=None):
        """Draws text twice — a few dim, offset copies behind a crisp
        foreground copy — to fake a soft neon glow without needing image
        filters on a plain Tk canvas."""
        c = self.canvas
        halo = fl.mix(self.bg, glow_color, 0.55)
        for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            c.create_text(x + ox, y + oy, text=text, font=font, fill=halo,
                         justify=justify, width=width)
        return c.create_text(x, y, text=text, font=font, fill=base_color,
                             justify=justify, width=width)

    def _chip(self, cx, y, text, color):
        """Small pill-shaped label — used for the feature-chip row on the
        welcome slide."""
        c = self.canvas
        pad_x = 14
        w = 13 + len(text) * 6.4 + pad_x * 2
        h = 26
        pill = round_rect(c, cx - w / 2, y - h / 2, cx + w / 2, y + h / 2, r=h / 2,
                          fill=fl.mix(self.bg, color, 0.16), outline=color, width=1)
        dot = c.create_oval(cx - w / 2 + 11, y - 3, cx - w / 2 + 17, y + 3,
                            fill=color, outline="")
        label = c.create_text(cx + 5, y, text=text, font=fl.font(9, "bold"),
                              fill=fl.mix(color, self.fg, 0.35))
        return [pill, dot, label], w

    def _category_icon(self, cx, cy, key, color, s=17):
        """Small drawn glyphs (no emoji) for each tool category."""
        c = self.canvas
        items = []
        if key == "partition":
            for i, dx in enumerate((-1.15, 0, 1.15)):
                w = s * 0.85
                h = s * 1.5 if i != 1 else s * 1.9
                items.append(c.create_rectangle(cx + dx * s - w / 2, cy - h / 2,
                                                cx + dx * s + w / 2, cy + h / 2,
                                                outline=color, width=2,
                                                fill=fl.mix(self.bg, color, 0.18)))
        elif key == "clone":
            r = round_rect(c, cx - s * 1.6, cy - s * 1.0, cx - s * 0.2, cy + s * 1.0,
                           r=6, outline=color, width=2, fill=fl.mix(self.bg, color, 0.18))
            r2 = round_rect(c, cx + s * 0.2, cy - s * 1.0, cx + s * 1.6, cy + s * 1.0,
                            r=6, outline=color, width=2, fill=fl.mix(self.bg, color, 0.10))
            arrow = c.create_line(cx - s * 0.1, cy, cx + s * 0.15, cy,
                                  fill=color, width=2, arrow="last")
            items += [r, r2, arrow]
        elif key == "bench":
            items.append(c.create_arc(cx - s * 1.5, cy - s * 1.2, cx + s * 1.5, cy + s * 1.2,
                                      start=200, extent=140, style="arc",
                                      outline=color, width=3))
            ang = math.radians(300)
            nx, ny = cx + math.cos(ang) * s * 1.05, cy - math.sin(ang) * s * 1.05
            items.append(c.create_line(cx, cy, nx, ny, fill=color, width=2, capstyle="round"))
            items.append(c.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=color, outline=""))
        elif key == "monitor":
            pts = [cx - s * 1.5, cy + s * 0.6, cx - s * 0.7, cy - s * 0.2,
                  cx - s * 0.1, cy + s * 0.4, cx + s * 0.6, cy - s * 1.1,
                  cx + s * 1.5, cy - s * 0.1]
            items.append(c.create_line(*pts, fill=color, width=2.5, joinstyle="round",
                                       capstyle="round", smooth=False))
        elif key == "security":
            pts = [cx, cy - s * 1.3, cx + s * 1.1, cy - s * 0.7, cx + s * 1.1, cy + s * 0.3,
                  cx, cy + s * 1.4, cx - s * 1.1, cy + s * 0.3, cx - s * 1.1, cy - s * 0.7]
            items.append(c.create_polygon(*pts, outline=color, width=2,
                                          fill=fl.mix(self.bg, color, 0.18)))
            items.append(c.create_line(cx - s * 0.4, cy, cx - s * 0.05, cy + s * 0.4,
                                       fill=color, width=2.5, capstyle="round"))
            items.append(c.create_line(cx - s * 0.05, cy + s * 0.4, cx + s * 0.55, cy - s * 0.4,
                                       fill=color, width=2.5, capstyle="round"))
        return items


    def _slide_welcome(self):
        c = self.canvas
        self._hero_badge(340, 70, r=40)

        title = self._neon_text(340, 158, "Welcome to TechDrive",
                        fl.font(23, "bold", True), self.fg, self.accent)
        ramp = [fl.mix(self.bg, self.accent, k / 7) for k in range(8)]
        ramp[-1] = self.fg
        self._rise_fade(title, 158, ramp, rise=14, steps=13)

        subtitle = c.create_text(340, 196, text="Your all-in-one PC repair toolkit — built for\n"
                                     "speed, precision, and real results.",
                     font=fl.font(11), fill=self.muted, justify="center")
        self._rise_fade(subtitle, 196, [fl.mix(self.bg, self.muted, k / 6) for k in range(7)],
                        rise=12, steps=13, delay=18)

        # feature chip row — small staggered pop-ins
        chip_defs = [("Partitions", self.accent), ("Cloning", self._card_colors[1]),
                    ("Benchmarks", self._card_colors[2]), ("Monitoring", self._card_colors[3])]
        widths = []
        built = []
        for text, color in chip_defs:
            items, w = self._chip(0, 248, text, color)
            widths.append(w)
            built.append(items)
        gap = 10
        total_w = sum(widths) + gap * (len(widths) - 1)
        start_x = 340 - total_w / 2
        x = start_x
        for i, (w, items) in enumerate(zip(widths, built)):
            cx = x + w / 2
            for item in items:
                c.move(item, cx, 0)
            x += w + gap
            self._track(self.win.after(300 + 90 * i, lambda items=items, cx=cx:
                        self._pop_in(items, cx, 248, steps=11)))

        c.create_text(340, 300, text="This quick tour takes about 20 seconds.",
                     font=fl.font(9, "italic"), fill=fl.mix(self.bg, self.muted, 0.7))

    def _terminal_panel(self, x, y, w, h):
        """Draws a mac-style terminal chrome — dot controls, title bar,
        dark console body — as the stage for the typed command sequence."""
        c = self.canvas
        items = []
        panel = round_rect(c, x, y, x + w, y + h, r=12,
                           fill=fl.mix(self.bg, "#050a12", 0.6),
                           outline=fl.mix(self.bg, self.fg, 0.14), width=1)
        items.append(panel)
        bar_h = 26
        bar = c.create_rectangle(x + 1, y + 1, x + w - 1, y + bar_h,
                                 fill=fl.mix(self.bg, "#050a12", 0.75), outline="")
        c.tag_raise(bar)
        items.append(bar)
        for i, col in enumerate((fl.BAD, "#f5b942", fl.GOOD)):
            dot = c.create_oval(x + 14 + i * 16, y + 9, x + 22 + i * 16, y + 17,
                                fill=col, outline="")
            items.append(dot)
        title = c.create_text(x + w / 2, y + bar_h / 2 + 1, text="clone-disk0 — techdrive",
                              font=fl.font(8), fill=self.muted)
        items.append(title)
        return items, bar_h

    def _type_lines(self, x, y, line_h, lines, on_all_done=None, char_delay=14, line_pause=260):
        """Types a sequence of console lines one character at a time, with
        a blinking block cursor — a small "screen capture" of a real
        command run rather than a static icon."""
        c = self.canvas
        text_items = [c.create_text(x, y + i * line_h, text="", anchor="w",
                                    font=fl.font(9, mono=True), fill=self.fg)
                     for i in range(len(lines))]
        cursor = c.create_text(x, y, text="▌", anchor="w",
                               font=fl.font(9, mono=True), fill=self.accent)

        def blink(n=0, visible=True):
            if not c.winfo_exists() or self._closing:
                return
            try:
                c.itemconfig(cursor, state="normal" if visible else "hidden")
            except tk.TclError:
                return
            self._track(c.after(380, lambda: blink(n + 1, not visible)))

        def place_cursor(line_i, char_i):
            full = lines[line_i]
            try:
                bbox = c.bbox(text_items[line_i])
                cx = (bbox[2] if bbox else x) if char_i else x
                c.coords(cursor, cx + 2, y + line_i * line_h)
            except tk.TclError:
                pass

        def type_line(line_i=0, char_i=0):
            if not c.winfo_exists() or self._closing:
                return
            if line_i >= len(lines):
                try:
                    c.itemconfig(cursor, state="hidden")
                except tk.TclError:
                    pass
                if on_all_done:
                    on_all_done()
                return
            full = lines[line_i]
            color = fl.GOOD if full.startswith("✓") else self.fg
            try:
                c.itemconfig(text_items[line_i], text=full[:char_i], fill=color)
            except tk.TclError:
                return
            place_cursor(line_i, char_i)
            if char_i < len(full):
                self._track(c.after(char_delay, lambda: type_line(line_i, char_i + 1)))
            else:
                self._track(c.after(line_pause, lambda: type_line(line_i + 1, 0)))

        blink()
        type_line()
        return text_items

    def _progress_bar(self, x, y, w, h, on_done=None, duration_steps=40, delay=16):
        c = self.canvas
        track = round_rect(c, x, y, x + w, y + h, r=h / 2,
                           fill=fl.mix(self.bg, self.fg, 0.08), outline="")
        fill = round_rect(c, x, y, x, y + h, r=h / 2, fill=self.accent, outline="")
        pct_label = c.create_text(x + w, y - 12, text="0%", anchor="e",
                                  font=fl.font(8, mono=True), fill=self.muted)

        def step(n=0):
            if not c.winfo_exists() or self._closing:
                return
            t = _ease_out_cubic(n / duration_steps)
            try:
                c.coords(fill, x, y, x + w * t, y + h)
                c.itemconfig(pct_label, text=f"{int(t * 100)}%")
            except tk.TclError:
                return
            if n < duration_steps:
                self._track(c.after(delay, lambda: step(n + 1)))
            elif on_done:
                on_done()
        step()
        return track, fill, pct_label

    def _slide_promise(self):
        c = self.canvas
        c.create_text(340, 40, text="Real tools. No placeholders.",
                     font=fl.font(18, "bold", True), fill=self.fg)

        panel_x, panel_y, panel_w, panel_h = 130, 68, 420, 200
        _, bar_h = self._terminal_panel(panel_x, panel_y, panel_w, panel_h)

        text_x = panel_x + 18
        text_y = panel_y + bar_h + 20
        line_h = 22
        lines = [
            "$ diskpart /s clone_script.txt",
            "  Scanning Disk 0 — 512GB NVMe",
            "  Cloning sectors to Disk 1 ...",
            "✓ Verified — 0 errors, 4m 12s",
        ]

        def start_progress():
            self._progress_bar(text_x, panel_y + panel_h - 34, panel_w - 36, 6)

        self._type_lines(text_x, text_y, line_h, lines, on_all_done=start_progress)

        c.create_text(340, 292, text="Every button runs a real command — diskpart, PowerShell,\n"
                                     "raw disk access — not a demo.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _bench_bar(self, x, y, w, max_h, target_frac, color, label, value_text,
                   delay=0, steps=26):
        """A single vertical bar that grows up from the baseline, with a
        label underneath and a live count-up value above it — used by the
        benchmark slide's mini results panel."""
        c = self.canvas
        base_y = y + max_h
        track = round_rect(c, x, y, x + w, base_y, r=5,
                           fill=fl.mix(self.bg, self.fg, 0.06), outline="")
        bar = round_rect(c, x, base_y, x + w, base_y, r=5, fill=color, outline="")
        val_label = c.create_text(x + w / 2, y - 12, text="0", anchor="s",
                                  font=fl.font(10, "bold", True, mono=True), fill=color)
        c.create_text(x + w / 2, base_y + 16, text=label, font=fl.font(8),
                     fill=self.muted, justify="center", width=w + 16)

        def step(n=0):
            if not c.winfo_exists() or self._closing:
                return
            t = _ease_out_cubic(n / steps)
            h = max_h * target_frac * t
            try:
                c.coords(bar, x, base_y - h, x + w, base_y)
                c.itemconfig(val_label, text=value_text(t))
            except tk.TclError:
                return
            if n < steps:
                self._track(c.after(16, lambda: step(n + 1)))
        self._track(self.win.after(delay, step))
        return track, bar, val_label

    def _slide_benchmark(self):
        c = self.canvas
        c.create_text(340, 32, text="See exactly how your drive performs",
                     font=fl.font(15, "bold", True), fill=self.fg)

        panel_x, panel_y, panel_w, panel_h = 150, 62, 380, 200
        panel_items, bar_h = self._terminal_panel(panel_x, panel_y, panel_w, panel_h)

        chart_top = panel_y + bar_h + 26
        chart_h = 108
        bars = [
            ("Sequential Read", 512, 0.93, "MB/s", self.accent),
            ("Sequential Write", 401, 0.78, "MB/s", self._card_colors[1]),
            ("Random 4K IOPS", 68400, 0.60, "", fl.METRIC_COLORS["gpu"]),
        ]
        n = len(bars)
        gap = 46
        bar_w = 46
        total_w = n * bar_w + (n - 1) * gap
        start_x = panel_x + (panel_w - total_w) // 2

        for i, (label, peak, frac, unit, color) in enumerate(bars):
            x = start_x + i * (bar_w + gap)
            def make_fmt(peak=peak, unit=unit):
                def fmt(t):
                    v = int(peak * t)
                    return f"{v:,}{(' ' + unit) if unit else ''}"
                return fmt
            self._bench_bar(x, chart_top, bar_w, chart_h, frac, color, label,
                            make_fmt(), delay=140 * i)

        c.create_text(340, 292, text="Live numbers from the built-in benchmark suite —\n"
                                     "not stock marketing figures.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _slide_partition(self):
        c = self.canvas
        c.create_text(340, 32, text="Resize and manage partitions with a drag",
                     font=fl.font(15, "bold", True), fill=self.fg)

        track_x, track_y, track_w, track_h = 130, 140, 420, 54
        round_rect(c, track_x, track_y, track_x + track_w, track_y + track_h, r=10,
                  fill=fl.mix(self.bg, self.fg, 0.06),
                  outline=fl.mix(self.bg, self.fg, 0.18), width=1)

        unalloc_w = track_w * 0.12
        unalloc_x = track_x + track_w - unalloc_w
        unalloc = c.create_rectangle(unalloc_x, track_y + 2, track_x + track_w - 2,
                                     track_y + track_h - 2,
                                     fill=fl.mix(self.bg, self.fg, 0.10), outline="")

        c_seg = c.create_rectangle(track_x + 2, track_y + 2, track_x + 2, track_y + track_h - 2,
                                   fill=self.accent, outline="")
        d_seg = c.create_rectangle(unalloc_x, track_y + 2, unalloc_x, track_y + track_h - 2,
                                   fill=self._card_colors[1], outline="")

        c_label = c.create_text(track_x + 60, track_y + track_h / 2, text="C:  Windows",
                                font=fl.font(9, "bold"), fill=self.theme["ON_ACCENT"])
        d_label = c.create_text(0, track_y + track_h / 2, text="D:  Data",
                                font=fl.font(9, "bold"), fill=self.fg)
        c.itemconfig(d_label, state="hidden")

        c_pct = c.create_text(track_x + 60, track_y - 14, text="",
                              font=fl.font(9, "bold", mono=True), fill=self.accent)
        d_pct = c.create_text(0, track_y - 14, text="",
                              font=fl.font(9, "bold", mono=True), fill=self._card_colors[1])
        c.itemconfig(d_pct, state="hidden")

        handle = round_rect(c, 0, track_y - 6, 0, track_y + track_h + 6, r=3,
                           fill=self.fg, outline="")

        start_frac, end_frac = 0.66, 0.42
        avail_w = unalloc_x - track_x

        def step(n=0, steps=40):
            if not c.winfo_exists() or self._closing:
                return
            t = _ease_out_cubic(n / steps)
            frac = start_frac + (end_frac - start_frac) * t
            div_x = track_x + avail_w * frac
            try:
                c.coords(c_seg, track_x + 2, track_y + 2, div_x, track_y + track_h - 2)
                c.coords(d_seg, div_x, track_y + 2, unalloc_x, track_y + track_h - 2)
                c.coords(handle, div_x - 2, track_y - 6, div_x + 2, track_y + track_h + 6)
                c.coords(c_label, track_x + (div_x - track_x) / 2, track_y + track_h / 2)
                c.coords(c_pct, track_x + (div_x - track_x) / 2, track_y - 14)
                c.itemconfig(c_pct, text=f"{int(frac * 100)}%")
                d_mid = div_x + (unalloc_x - div_x) / 2
                c.coords(d_label, d_mid, track_y + track_h / 2)
                c.coords(d_pct, d_mid, track_y - 14)
                c.itemconfig(d_pct, text=f"{int((1 - frac) * (unalloc_x - track_x) / avail_w * 100)}%")
                if (unalloc_x - div_x) > 46:
                    c.itemconfig(d_label, state="normal")
                    c.itemconfig(d_pct, state="normal")
            except tk.TclError:
                return
            if n < steps:
                self._track(self.win.after(16, lambda: step(n + 1)))
        self._track(self.win.after(300, step))

        c.create_text(unalloc_x + unalloc_w / 2, track_y + track_h / 2, text="Unallocated",
                     font=fl.font(7), fill=fl.mix(self.bg, self.muted, 0.6),
                     justify="center", width=unalloc_w - 4)

        c.create_text(340, 260, text="Shrink, extend, create, or delete partitions live —\n"
                                     "changes apply without a reboot.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _slide_categories(self):
        c = self.canvas
        c.create_text(340, 32, text="Everything's organized by category",
                     font=fl.font(15, "bold", True), fill=self.fg)
        card_w, card_h = 114, 100
        gap = 10
        total_w = len(_CATEGORY_CARDS) * card_w + (len(_CATEGORY_CARDS) - 1) * gap
        start_x = (680 - total_w) // 2
        y = 178
        top, bottom = y - card_h // 2 - 10, y + card_h // 2 + 10

        cards = []
        for i, (key, name) in enumerate(_CATEGORY_CARDS):
            color = self._card_colors[i % len(self._card_colors)]
            x = start_x + i * (card_w + gap)
            cx = x + card_w // 2
            card = round_rect(c, x, y - card_h // 2, x + card_w, y + card_h // 2,
                              r=14, fill=self.card_bg, outline=color, width=2)
            glyph = self._category_icon(cx, y - 22, key, color, s=14)
            label = c.create_text(cx, y + 30, text=name,
                                  font=fl.font(9, "bold"), fill=color,
                                  width=card_w - 12, justify="center")
            items = [card, *glyph, label]
            for it in items:
                c.itemconfig(it, state="hidden")
            cards.append({"cx": cx, "items": items, "revealed": False})

        # a bright scan beam sweeps left-to-right; each card "detects"
        # and pops in the moment the beam crosses it, like a radar readout.
        beam_x0, beam_x1 = start_x - 30, start_x + total_w + 30
        beam = c.create_rectangle(beam_x0, top, beam_x0 + 3, bottom,
                                  fill=self.accent_glow, outline="")
        beam_glow = c.create_rectangle(beam_x0 - 10, top, beam_x0 + 13, bottom,
                                       fill=fl.mix(self.bg, self.accent, 0.16), outline="")
        c.tag_lower(beam_glow)

        def sweep(n=0, steps=54):
            if not c.winfo_exists() or self._closing:
                return
            t = n / steps
            bx = beam_x0 + (beam_x1 - beam_x0) * t
            try:
                c.coords(beam, bx, top, bx + 3, bottom)
                c.coords(beam_glow, bx - 10, top, bx + 13, bottom)
            except tk.TclError:
                return
            for card in cards:
                if not card["revealed"] and bx >= card["cx"] - 4:
                    card["revealed"] = True
                    for it in card["items"]:
                        c.itemconfig(it, state="normal")
                    self._pop_in(card["items"], card["cx"], y, steps=11)
            if n < steps:
                self._track(c.after(13, lambda: sweep(n + 1, steps)))
            else:
                for item in (beam, beam_glow):
                    try:
                        c.itemconfig(item, state="hidden")
                    except tk.TclError:
                        pass
        sweep()

        c.create_text(340, 310, text="…plus recovery, security, virtual disks, and more.",
                     font=fl.font(9, "italic"), fill=fl.mix(self.bg, self.muted, 0.7))

    def _plugin_card(self, x, y, w, h, name, category, color, installed):
        """A small Core Module Manager card — icon chip, name, category tag, and
        an Install/Installed button — echoing the real store's card grid
        so the tour reads as a preview of the actual tab, not a mockup."""
        c = self.canvas
        items = []
        card = round_rect(c, x, y, x + w, y + h, r=12,
                          fill=self.card_bg, outline=fl.mix(self.bg, self.fg, 0.14), width=1)
        items.append(card)

        chip = round_rect(c, x + 12, y + 12, x + 36, y + 36, r=8,
                         fill=fl.mix(self.bg, color, 0.20), outline=color, width=1)
        dot = c.create_oval(x + 20, y + 20, x + 28, y + 28, fill=color, outline="")
        items += [chip, dot]

        items.append(c.create_text(x + 46, y + 18, text=name, anchor="w",
                                   font=fl.font(9, "bold"), fill=self.fg))
        items.append(c.create_text(x + 46, y + 34, text=category, anchor="w",
                                   font=fl.font(8), fill=self.muted))

        btn_w, btn_h = w - 24, 24
        btn_x, btn_y = x + 12, y + h - btn_h - 12
        if installed:
            btn = round_rect(c, btn_x, btn_y, btn_x + btn_w, btn_y + btn_h, r=btn_h / 2,
                            fill=fl.mix(self.bg, fl.GOOD, 0.18), outline=fl.GOOD, width=1)
            label = c.create_text(btn_x + btn_w / 2, btn_y + btn_h / 2, text="✓ Installed",
                                  font=fl.font(8, "bold"), fill=fl.GOOD)
        else:
            btn = round_rect(c, btn_x, btn_y, btn_x + btn_w, btn_y + btn_h, r=btn_h / 2,
                            fill=self.accent, outline="")
            label = c.create_text(btn_x + btn_w / 2, btn_y + btn_h / 2, text="Enable",
                                  font=fl.font(8, "bold"), fill=self.theme["ON_ACCENT"])
        items += [btn, label]
        return items, btn, label

    def _slide_enable_disable_tools(self):
        c = self.canvas
        c.create_text(340, 32, text="Manage TechDrive Core modules",
                     font=fl.font(15, "bold", True), fill=self.fg)
        c.create_text(340, 54, text="TechDrive ships with its Core modules ready to use.\n"
                                     "Enable or disable optional modules without downloads.",
                     font=fl.font(9), fill=self.muted, justify="center")

        # search + category bar, echoing the real Core Module Manager controls
        bar_x, bar_y, bar_w, bar_h = 170, 76, 340, 26
        round_rect(c, bar_x, bar_y, bar_x + bar_w * 0.62, bar_y + bar_h, r=13,
                  fill=fl.mix(self.bg, self.fg, 0.06), outline=fl.mix(self.bg, self.fg, 0.18))
        c.create_text(bar_x + 14, bar_y + bar_h / 2, text="⌕  Search Core Modules…", anchor="w",
                     font=fl.font(8), fill=self.muted)
        cat_x = bar_x + bar_w * 0.62 + 8
        round_rect(c, cat_x, bar_y, bar_x + bar_w, bar_y + bar_h, r=13,
                  fill=fl.mix(self.bg, self.fg, 0.06), outline=fl.mix(self.bg, self.fg, 0.18))
        c.create_text(cat_x + (bar_x + bar_w - cat_x) / 2, bar_y + bar_h / 2, text="All ▾",
                     font=fl.font(8), fill=self.fg)

        cards_def = [
            ("IDE Toolkit", "Editors & terminal", self.accent, False),
            ("Live Monitoring", "Real-time metrics", self._card_colors[1], True),
            ("Business Suite", "Invoicing & reports", fl.METRIC_COLORS["gpu"], False),
        ]
        card_w, card_h = 140, 96
        gap = 14
        total_w = len(cards_def) * card_w + (len(cards_def) - 1) * gap
        start_x = 340 - total_w / 2
        y = 126

        install_targets = []
        for i, (name, category, color, installed) in enumerate(cards_def):
            x = start_x + i * (card_w + gap)
            items, btn, label = self._plugin_card(x, y, card_w, card_h, name, category,
                                                   color, installed)
            for it in items:
                c.itemconfig(it, state="hidden")
            cx = x + card_w / 2
            self._track(self.win.after(150 * i, lambda items=items, cx=cx, y=y + card_h / 2:
                        (([c.itemconfig(it, state="normal") for it in items]),
                         self._pop_in(items, cx, y, steps=11))))
            if not installed:
                install_targets.append((btn, label, color))

        def flip_install(n=0):
            if not c.winfo_exists() or self._closing or n >= len(install_targets):
                return
            btn, label, color = install_targets[n]
            try:
                c.itemconfig(btn, fill=fl.mix(self.bg, fl.GOOD, 0.18), outline=fl.GOOD)
                c.itemconfig(label, text="✓ Installed", fill=fl.GOOD)
            except tk.TclError:
                return
            self._track(self.win.after(500, lambda: flip_install(n + 1)))

        self._track(self.win.after(900, flip_install))

        c.create_text(340, 300, text="Install, uninstall, and search — the sidebar updates\n"
                                     "instantly, and your picks are remembered next launch.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _signal_bars(self, cx, cy, n, color, active):
        """A small drawn signal-strength glyph (ascending bars) — no
        emoji, matching the app's hand-drawn icon convention."""
        c = self.canvas
        items = []
        bar_w = 6
        gap = 3
        total_w = n * bar_w + (n - 1) * gap
        x0 = cx - total_w / 2
        for i in range(n):
            h = 8 + i * 6
            x = x0 + i * (bar_w + gap)
            on = i < active
            items.append(c.create_rectangle(x, cy - h, x + bar_w, cy,
                        fill=color if on else fl.mix(self.bg, self.fg, 0.10),
                        outline=""))
        return items

    def _slide_network(self):
        c = self.canvas
        c.create_text(340, 32, text="Diagnose the network without leaving the app",
                     font=fl.font(15, "bold", True), fill=self.fg)

        net_color = fl.METRIC_COLORS["network"]
        panel_x, panel_y, panel_w, panel_h = 150, 60, 380, 168
        round_rect(c, panel_x, panel_y, panel_x + panel_w, panel_y + panel_h, r=12,
                  fill=fl.mix(self.bg, "#050a12", 0.55),
                  outline=fl.mix(self.bg, self.fg, 0.14), width=1)

        # left: adapter card
        card_x, card_y, card_w, card_h = panel_x + 16, panel_y + 16, 150, 136
        round_rect(c, card_x, card_y, card_x + card_w, card_y + card_h, r=10,
                  fill=self.card_bg, outline=fl.mix(self.bg, self.fg, 0.14), width=1)
        bars = self._signal_bars(card_x + 30, card_y + 34, 4, net_color, 0)
        c.create_text(card_x + 56, card_y + 30, text="Ethernet 1", anchor="w",
                     font=fl.font(9, "bold"), fill=self.fg)
        c.create_text(card_x + 56, card_y + 46, text="1.0 Gbps", anchor="w",
                     font=fl.font(8), fill=self.muted)

        rows = [("IPv4", "192.168.1.42"), ("Gateway", "192.168.1.1"),
               ("DNS", "1.1.1.1")]
        row_y = card_y + 70
        for label, val in rows:
            c.create_text(card_x + 12, row_y, text=label, anchor="w",
                         font=fl.font(7), fill=self.muted)
            c.create_text(card_x + card_w - 12, row_y, text=val, anchor="e",
                         font=fl.font(7, mono=True), fill=self.fg)
            row_y += 20

        def light_up(n=0):
            if not c.winfo_exists() or self._closing or n > 4:
                return
            for i, item in enumerate(bars):
                try:
                    c.itemconfig(item, fill=net_color if i < n else
                                fl.mix(self.bg, self.fg, 0.10))
                except tk.TclError:
                    return
            self._track(self.win.after(220, lambda: light_up(n + 1)))
        self._track(self.win.after(300, light_up))

        # right: live ping trace + speed test readout
        trace_x = card_x + card_w + 16
        trace_w = panel_x + panel_w - 16 - trace_x
        trace_top, trace_h = card_y + 4, 70
        for i in range(3):
            gy = trace_top + i * trace_h / 2
            c.create_line(trace_x, gy, trace_x + trace_w, gy,
                         fill=fl.mix(self.bg, self.fg, 0.08), width=1)
        n_points = 30
        xs = [trace_x + trace_w * i / (n_points - 1) for i in range(n_points)]
        ys = [trace_top + trace_h * 0.6 for _ in range(n_points)]
        trace = c.create_line(*[v for p in zip(xs, ys) for v in p],
                              fill=net_color, width=2, smooth=True, joinstyle="round")
        ping_label = c.create_text(trace_x, trace_top - 12, anchor="w", text="Ping  — ms",
                                   font=fl.font(8, "bold", mono=True), fill=net_color)

        state = {"t": 0.0}

        def animate(n=0):
            if not c.winfo_exists() or self._closing:
                return
            state["t"] += 0.5
            ys.pop(0)
            jitter = abs(math.sin(state["t"]) * 14) + random.uniform(0, 5)
            ys.append(trace_top + trace_h * 0.75 - jitter)
            try:
                c.coords(trace, *[v for p in zip(xs, ys) for v in p])
                ms = 8 + jitter
                c.itemconfig(ping_label, text=f"Ping  {ms:.0f} ms")
            except tk.TclError:
                return
            self._track(c.after(60, lambda: animate(n + 1)))
        animate()

        chip_items, w = self._chip(0, trace_top + trace_h + 22, "↓ 940 Mbps  ↑ 880 Mbps", net_color)
        for it in chip_items:
            c.move(it, trace_x + w / 2, 0)
        for it in chip_items:
            c.itemconfig(it, state="hidden")
        self._track(self.win.after(400, lambda: (
            [c.itemconfig(it, state="normal") for it in chip_items],
            self._pop_in(chip_items, trace_x + w / 2, trace_top + trace_h + 22, steps=11))))

        c.create_text(340, 292, text="Ping, traceroute, speed test, and adapter details —\n"
                                     "all live, no separate app.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _fps_glyph(self, cx, cy, s, color):
        """A small drawn controller-ish/perf glyph — a speedometer-style
        arc with a needle, reused visual language from the benchmark
        slide's dial so gaming feels like a sibling feature, not a
        separate app."""
        c = self.canvas
        items = [c.create_arc(cx - s, cy - s, cx + s, cy + s, start=200, extent=140,
                             style="arc", outline=color, width=3)]
        ang = math.radians(255)
        items.append(c.create_line(cx, cy, cx + math.cos(ang) * s * 0.8,
                                   cy - math.sin(ang) * s * 0.8,
                                   fill=color, width=2, capstyle="round"))
        items.append(c.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=color, outline=""))
        return items

    def _slide_gaming(self):
        c = self.canvas
        c.create_text(340, 32, text="One click to squeeze out extra frames",
                     font=fl.font(15, "bold", True), fill=self.fg)

        gcolor = self._card_colors[2]
        panel_x, panel_y, panel_w, panel_h = 170, 60, 340, 168
        round_rect(c, panel_x, panel_y, panel_x + panel_w, panel_y + panel_h, r=14,
                  fill=self.card_bg, outline=fl.mix(self.bg, self.fg, 0.14), width=1)

        dial_cx, dial_cy = panel_x + 90, panel_y + 84
        dial_items = self._fps_glyph(dial_cx, dial_cy, 44, gcolor)
        for it in dial_items:
            c.scale(it, dial_cx, dial_cy, 0.001, 0.001)
        self._pop_in(dial_items, dial_cx, dial_cy, steps=13)
        fps_label = c.create_text(dial_cx, dial_cy + 24, text="0 FPS",
                                  font=fl.font(11, "bold", True, mono=True), fill=gcolor)

        def count_fps(n=0, steps=30):
            if not c.winfo_exists() or self._closing:
                return
            t = _ease_out_cubic(n / steps)
            try:
                c.itemconfig(fps_label, text=f"{int(58 + 46 * t)} FPS")
            except tk.TclError:
                return
            if n < steps:
                self._track(self.win.after(24, lambda: count_fps(n + 1)))
        self._track(self.win.after(350, count_fps))

        toggles = [("Game Mode", True), ("Background Apps Trimmed", True),
                  ("GPU Scheduling", True)]
        tx = panel_x + 190
        ty = panel_y + 30
        for i, (label, on) in enumerate(toggles):
            y = ty + i * 34
            track = round_rect(c, tx, y, tx + 40, y + 18, r=9,
                              fill=fl.mix(self.bg, self.fg, 0.10), outline="")
            knob = c.create_oval(tx + 2, y + 2, tx + 18, y + 16, fill=self.muted, outline="")
            text = c.create_text(tx + 50, y + 9, text=label, anchor="w",
                                 font=fl.font(8), fill=self.muted)
            for it in (track, knob, text):
                c.itemconfig(it, state="hidden")

            def flip(track=track, knob=knob, text=text, label=label, y=y, delay=280 * i):
                def do_flip():
                    if not c.winfo_exists() or self._closing:
                        return
                    for it in (track, knob, text):
                        try:
                            c.itemconfig(it, state="normal")
                        except tk.TclError:
                            return
                    try:
                        c.itemconfig(track, fill=fl.mix(self.bg, gcolor, 0.35))
                        c.coords(knob, tx + 24, y + 2, tx + 40 - 2, y + 16)
                        c.itemconfig(knob, fill=gcolor)
                        c.itemconfig(text, fill=self.fg)
                    except tk.TclError:
                        return
                self._track(self.win.after(700 + delay, do_flip))
            flip()

        c.create_text(340, 292, text="Game Mode trims background load and prioritizes the\n"
                                     "foreground game — reversible with one more click.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _warning_glyph(self, cx, cy, s, color):
        """A drawn caution-triangle glyph (no emoji) for the safety slide."""
        c = self.canvas
        pts = [cx, cy - s, cx + s * 0.92, cy + s * 0.78, cx - s * 0.92, cy + s * 0.78]
        items = [c.create_polygon(*pts, outline=color, width=2, joinstyle="round",
                                  fill=fl.mix(self.bg, color, 0.16))]
        items.append(c.create_line(cx, cy - s * 0.28, cx, cy + s * 0.18,
                                   fill=color, width=3, capstyle="round"))
        items.append(c.create_oval(cx - 1.6, cy + s * 0.4, cx + 1.6, cy + s * 0.46,
                                   fill=color, outline=""))
        return items

    def _slide_monitor(self):
        c = self.canvas
        c.create_text(340, 32, text="Watch your hardware in real time",
                     font=fl.font(15, "bold", True), fill=self.fg)

        panel_x, panel_y, panel_w, panel_h = 150, 60, 380, 150
        round_rect(c, panel_x, panel_y, panel_x + panel_w, panel_y + panel_h, r=12,
                  fill=fl.mix(self.bg, "#050a12", 0.55),
                  outline=fl.mix(self.bg, self.fg, 0.14), width=1)

        grid_pad = 16
        for i in range(3):
            gy = panel_y + grid_pad + i * (panel_h - grid_pad * 2) / 2
            c.create_line(panel_x + grid_pad, gy, panel_x + panel_w - grid_pad, gy,
                         fill=fl.mix(self.bg, self.fg, 0.08), width=1)

        gx0 = panel_x + grid_pad
        gx1 = panel_x + panel_w - grid_pad
        gy_mid = panel_y + panel_h / 2
        n_points = 42
        xs = [gx0 + (gx1 - gx0) * i / (n_points - 1) for i in range(n_points)]
        ys = [gy_mid for _ in range(n_points)]
        line = c.create_line(*[c for pair in zip(xs, ys) for c in pair],
                             fill=self.accent, width=2, smooth=True, joinstyle="round")

        state = {"t": 0.0}

        def animate(n=0):
            if not c.winfo_exists() or self._closing:
                return
            state["t"] += 0.14
            ys.pop(0)
            wobble = math.sin(state["t"]) * 22 + math.sin(state["t"] * 2.7) * 8
            ys.append(gy_mid - wobble)
            try:
                c.coords(line, *[coord for pair in zip(xs, ys) for coord in pair])
            except tk.TclError:
                return
            self._track(c.after(45, lambda: animate(n + 1)))
        animate()

        chip_defs = [("CPU  41C", fl.GOOD), ("Disk  62%", self._card_colors[1]),
                    ("Read  340 MB/s", self.accent)]
        widths = []
        built = []
        for text, color in chip_defs:
            items, w = self._chip(0, 246, text, color)
            widths.append(w)
            built.append(items)
        gap = 12
        total_w = sum(widths) + gap * (len(widths) - 1)
        x = 340 - total_w / 2
        for i, (w, items) in enumerate(zip(widths, built)):
            cx = x + w / 2
            for item in items:
                c.move(item, cx, 0)
            x += w + gap
            self._track(self.win.after(200 + 100 * i, lambda items=items, cx=cx:
                        self._pop_in(items, cx, 246, steps=11)))

        c.create_text(340, 292, text="Temperatures, usage, and throughput update live —\n"
                                     "no need to alt-tab to a separate tool.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _slide_safety(self):
        c = self.canvas
        c.create_text(340, 32, text="Destructive actions never happen by accident",
                     font=fl.font(15, "bold", True), fill=self.fg)

        panel_x, panel_y, panel_w, panel_h = 190, 66, 300, 168
        round_rect(c, panel_x, panel_y, panel_x + panel_w, panel_y + panel_h, r=14,
                  fill=self.card_bg, outline=fl.mix(self.bg, self.fg, 0.14), width=1)

        warn_cx, warn_cy = panel_x + panel_w / 2, panel_y + 40
        warn_items = self._warning_glyph(warn_cx, warn_cy, 20, fl.BAD)
        for it in warn_items:
            c.scale(it, warn_cx, warn_cy, 0.001, 0.001)
        self._pop_in(warn_items, warn_cx, warn_cy, steps=12)

        c.create_text(panel_x + panel_w / 2, panel_y + 74,
                     text="Wipe Disk 1 — 1TB SATA SSD",
                     font=fl.font(11, "bold"), fill=self.fg)
        c.create_text(panel_x + panel_w / 2, panel_y + 94,
                     text="This cannot be undone. All data will be lost.",
                     font=fl.font(9), fill=self.muted, justify="center", width=panel_w - 40)

        check_y = panel_y + 118
        check_text = c.create_text(panel_x + 24, check_y, anchor="w", text="",
                                   font=fl.font(9, mono=True), fill=self.fg)

        def type_confirm(i=0, phrase="I understand — wipe it"):
            if not c.winfo_exists() or self._closing:
                return
            try:
                c.itemconfig(check_text, text=phrase[:i])
            except tk.TclError:
                return
            if i < len(phrase):
                self._track(c.after(28, lambda: type_confirm(i + 1)))
            else:
                self._track(self.win.after(260, lambda: confirm_btn_pulse()))

        btn_y = panel_y + panel_h - 26
        btn = round_rect(c, panel_x + panel_w / 2 - 70, btn_y - 13,
                        panel_x + panel_w / 2 + 70, btn_y + 13, r=13,
                        fill=fl.mix(self.bg, fl.BAD, 0.35), outline=fl.BAD, width=1)
        btn_label = c.create_text(panel_x + panel_w / 2, btn_y, text="Confirm Wipe",
                                  font=fl.font(9, "bold"), fill=self.fg)

        def confirm_btn_pulse(n=0):
            if not c.winfo_exists() or self._closing or n >= 2:
                return
            grown = fl.mix(self.bg, fl.BAD, 0.55)
            try:
                c.itemconfig(btn, fill=grown)
            except tk.TclError:
                return
            self._track(self.win.after(140, lambda: revert(n)))

        def revert(n):
            try:
                c.itemconfig(btn, fill=fl.mix(self.bg, fl.BAD, 0.35))
            except tk.TclError:
                return
            self._track(self.win.after(260, lambda: confirm_btn_pulse(n + 1)))

        self._track(self.win.after(500, type_confirm))

        c.create_text(340, 260, text="Every wipe, format, or overwrite asks you to type a\n"
                                     "confirmation phrase first — no accidental clicks.",
                     font=fl.font(11), fill=self.muted, justify="center")
        c.create_text(340, 300, text="Read-only scans and benchmarks never ask — only\n"
                                     "operations that change data on disk do.",
                     font=fl.font(9, "italic"), fill=fl.mix(self.bg, self.muted, 0.7),
                     justify="center")

    def _duck_glyph(self, cx, cy, s, color):
        """A simple drawn helper-mascot glyph (rounded body + beak) — no
        emoji, consistent with the app's existing hand-drawn icon style."""
        c = self.canvas
        items = []
        items.append(c.create_oval(cx - s, cy - s * 0.75, cx + s * 0.7, cy + s * 0.85,
                                   fill=color, outline=""))
        items.append(c.create_oval(cx - s * 0.15, cy - s * 1.25, cx + s * 0.85, cy - s * 0.25,
                                   fill=color, outline=""))
        beak = [cx + s * 0.6, cy - s * 0.72, cx + s * 1.25, cy - s * 0.55,
               cx + s * 0.55, cy - s * 0.42]
        items.append(c.create_polygon(*beak, fill=fl.mix(color, "#ffffff", 0.5), outline=""))
        items.append(c.create_oval(cx + s * 0.25, cy - s * 1.02, cx + s * 0.39, cy - s * 0.88,
                                   fill=self.bg, outline=""))
        return items

    def _slide_assistant(self):
        c = self.canvas
        c.create_text(340, 32, text="Stuck? The assistant is always one click away",
                     font=fl.font(15, "bold", True), fill=self.fg)

        duck_cx, duck_cy = 210, 170
        duck_items = self._duck_glyph(duck_cx, duck_cy, 30, self.accent)
        for it in duck_items:
            c.scale(it, duck_cx, duck_cy, 0.001, 0.001)
        self._pop_in(duck_items, duck_cx, duck_cy, steps=13)

        bubble_x, bubble_y, bubble_w, bubble_h = 300, 108, 260, 90
        round_rect(c, bubble_x, bubble_y, bubble_x + bubble_w, bubble_y + bubble_h, r=14,
                  fill=self.card_bg, outline=fl.mix(self.bg, self.accent, 0.4), width=1)
        tail = c.create_polygon(bubble_x + 6, bubble_y + bubble_h - 4,
                               bubble_x - 14, bubble_y + bubble_h + 14,
                               bubble_x + 26, bubble_y + bubble_h - 4,
                               fill=self.card_bg, outline="")

        text_x, text_y = bubble_x + 16, bubble_y + 18
        lines = ["Try asking:", '"Benchmark my SSD"', '"Clone Disk 0 to Disk 1"']
        self._type_lines(text_x, text_y, 22, lines, char_delay=16, line_pause=240)

        c.create_text(340, 300, text="It lives in the corner of every screen and knows\n"
                                     "which tool you're looking at.",
                     font=fl.font(11), fill=self.muted, justify="center")

    def _slide_shortcuts(self):
        c = self.canvas
        c.create_text(340, 32, text="A few shortcuts worth knowing",
                     font=fl.font(15, "bold", True), fill=self.fg)

        shortcuts = [
            ("Ctrl + N", "Start a new scan"),
            ("Ctrl + D", "Duplicate the current task"),
            ("F1", "Open the assistant"),
            ("Ctrl + ,", "Open Settings"),
        ]
        row_h = 46
        top = 80
        row_w = 400
        row_x = 340 - row_w / 2

        for i, (keys, desc) in enumerate(shortcuts):
            y = top + i * row_h
            row_items = []
            key_pill = round_rect(c, row_x, y - 14, row_x + 96, y + 14, r=8,
                                 fill=fl.mix(self.bg, self.fg, 0.08),
                                 outline=fl.mix(self.bg, self.fg, 0.2), width=1)
            key_label = c.create_text(row_x + 48, y, text=keys,
                                      font=fl.font(9, "bold", mono=True), fill=self.fg)
            desc_label = c.create_text(row_x + 116, y, text=desc, anchor="w",
                                       font=fl.font(10), fill=self.muted)
            row_items = [key_pill, key_label, desc_label]
            for it in row_items:
                c.itemconfig(it, state="hidden")
            self._track(self.win.after(120 * i, lambda items=row_items:
                        [c.itemconfig(it, state="normal") for it in items]))

        c.create_text(340, top + len(shortcuts) * row_h + 20,
                     text="The full list is in Settings → Keyboard Shortcuts.",
                     font=fl.font(9, "italic"), fill=fl.mix(self.bg, self.muted, 0.7))

    def _slide_ready(self):
        c = self.canvas
        self._hero_badge(340, 66, r=34)
        title = self._neon_text(340, 122, "You're all set", fl.font(20, "bold", True),
                        self.fg, self.accent)

        panel_x, panel_y, panel_w, panel_h = 190, 150, 300, 108
        _, bar_h = self._terminal_panel(panel_x, panel_y, panel_w, panel_h)
        text_x = panel_x + 16
        text_y = panel_y + bar_h + 14
        lines = [
            "  Modules loaded: 92/92",
            "  Assistant: online",
            "✓ Ready to launch",
        ]
        self._type_lines(text_x, text_y, 19, lines, char_delay=12, line_pause=200)

        c.create_text(340, 278, text="Look for the assistant in the corner if you get stuck.",
                     font=fl.font(10), fill=self.muted)
        colors = self._card_colors
        dots = []
        for _ in range(24):
            x = random.randint(90, 590)
            color = random.choice(colors)
            size = random.uniform(4, 7)
            d = c.create_oval(x, -10, x + size, -4 + size, fill=color, outline="")
            dots.append({"item": d, "fall": random.uniform(1.6, 3.8),
                        "drift": random.uniform(-0.6, 0.6), "phase": random.uniform(0, math.tau)})

        def fall(n=0):
            if not c.winfo_exists() or self._closing or n >= 90:
                return
            for d in dots:
                try:
                    c.move(d["item"], d["drift"] + math.sin(n * 0.15 + d["phase"]) * 0.8, d["fall"])
                except tk.TclError:
                    return
            self._track(c.after(28, lambda: fall(n + 1)))
        fall()


def maybe_show(app):
    """Shows the tour once, ever, per install — no-op after that."""
    if db.get_setting("onboarding_tour_shown", False):
        return
    _Tour(app)


def show(app):
    """Always shows the tour — used by the Settings 'Replay' button."""
    _Tour(app)
