#!/usr/bin/env python3
"""
gui/live_activity.py — Dynamic Island–style live status pill
=============================================================
A compact pill in the top bar that shows live CPU / RAM (and scan state).
Click to expand into a richer mini-panel; click again or outside to collapse.
Uses spring motion for expand/collapse.
"""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.motion import tween, spring, motion_enabled
from gui.widgets import round_rect

try:
    import psutil
except ImportError:
    psutil = None


class LiveActivityPill(tk.Canvas):
    """Compact ↔ expanded live status island."""

    COLLAPSED_W = 148
    COLLAPSED_H = 28
    EXPANDED_W = 260
    EXPANDED_H = 72

    def __init__(self, parent, app, theme=None, aero=False, bg=None):
        self.app = app
        self.theme = theme or getattr(app, "theme", fl.DARK)
        self.aero = aero
        self._bg = bg or parent["bg"]
        self._expanded = False
        self._cpu = 0.0
        self._ram = 0.0
        self._scan = False
        self._job = None
        self._anim = None
        self._w = self.COLLAPSED_W
        self._h = self.COLLAPSED_H

        super().__init__(
            parent,
            width=self.COLLAPSED_W,
            height=self.COLLAPSED_H,
            bg=self._bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.bind("<Button-1>", self._toggle)
        self.bind("<Configure>", lambda e: self._draw())
        self._draw()
        self._tick()

    # -- public ------------------------------------------------------------
    def set_theme(self, theme, aero=False, bg=None):
        self.theme = theme
        self.aero = aero
        if bg:
            self._bg = bg
            self.configure(bg=bg)
        self._draw()

    def destroy(self):
        self._stop()
        try:
            super().destroy()
        except Exception:
            pass

    # -- sampling ----------------------------------------------------------
    def _tick(self):
        if not self.winfo_exists():
            return
        try:
            if psutil:
                self._cpu = float(psutil.cpu_percent(interval=None))
                self._ram = float(psutil.virtual_memory().percent)
            self._scan = bool(getattr(self.app, "_active_scan_count", 0))
        except Exception:
            pass
        self._draw()
        self._job = self.after(1500, self._tick)

    def _stop(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None

    # -- expand / collapse -------------------------------------------------
    def _toggle(self, _e=None):
        self._expanded = not self._expanded
        target_w = self.EXPANDED_W if self._expanded else self.COLLAPSED_W
        target_h = self.EXPANDED_H if self._expanded else self.COLLAPSED_H
        start_w, start_h = self._w, self._h

        def update(t):
            self._w = start_w + (target_w - start_w) * t
            self._h = start_h + (target_h - start_h) * t
            try:
                self.configure(width=int(self._w), height=int(self._h))
            except Exception:
                pass
            self._draw()

        if self._anim:
            self._anim()
        self._anim = tween(self, 320, update, easing=spring)

    # -- drawing -----------------------------------------------------------
    def _draw(self):
        self.delete("all")
        w = max(int(self._w), 4)
        h = max(int(self._h), 4)
        th = self.theme

        # Island body — near-black pill with subtle stroke
        fill = fl.mix(th.get("CARD_BG", "#1c1c1e"), "#000000", 0.35)
        if self.aero:
            fill = fl.glass(th, "CARD_BG", True, 0.20)
        stroke = th.get("STROKE", "#333")
        round_rect(self, 1, 1, w - 2, h - 2, r=min(h // 2, 16),
                   fill=fill, outline=stroke, width=1)

        cpu_c = self._bar_color(self._cpu)
        ram_c = self._bar_color(self._ram)

        if not self._expanded:
            # Compact: "CPU 12%  ·  RAM 48%" or scan badge
            if self._scan:
                text = "● Scanning…"
                color = th.get("ACCENT", "#0a84ff")
            else:
                text = f"CPU {self._cpu:.0f}%  ·  RAM {self._ram:.0f}%"
                color = th.get("FG", "#fff")
            self.create_text(
                w / 2, h / 2, text=text, fill=color,
                font=("Segoe UI", 9, "bold"),
            )
            # tiny status dots
            self.create_oval(8, h / 2 - 3, 14, h / 2 + 3, fill=cpu_c, outline="")
            return

        # Expanded
        self.create_text(
            16, 16, text="Live Activity", anchor="w",
            fill=th.get("MUTED", "#98989d"), font=("Segoe UI", 9),
        )
        if self._scan:
            self.create_text(
                w - 16, 16, text="Scanning", anchor="e",
                fill=th.get("ACCENT", "#0a84ff"), font=("Segoe UI", 9, "bold"),
            )

        # CPU row
        self.create_text(
            16, 38, text="CPU", anchor="w",
            fill=th.get("FG", "#fff"), font=("Segoe UI", 10, "bold"),
        )
        self._meter(16, 48, w - 80, 6, self._cpu / 100.0, cpu_c, fill)
        self.create_text(
            w - 16, 50, text=f"{self._cpu:.0f}%", anchor="e",
            fill=cpu_c, font=("Segoe UI", 10, "bold"),
        )

        # RAM row
        self.create_text(
            16, 62, text="RAM", anchor="w",
            fill=th.get("FG", "#fff"), font=("Segoe UI", 10, "bold"),
        )
        # second meter slightly lower — keep compact in 72px height
        # Actually draw RAM text on right of first meter area for density
        self.create_text(
            w / 2 + 20, 50, text=f"RAM {self._ram:.0f}%", anchor="w",
            fill=ram_c, font=("Segoe UI", 10),
        )

    def _meter(self, x, y, width, height, t, color, track):
        t = max(0.0, min(1.0, t))
        round_rect(self, x, y, x + width, y + height, r=height // 2,
                   fill=fl.mix(track, "#ffffff", 0.08), outline="")
        if t > 0.02:
            round_rect(self, x, y, x + max(height, width * t), y + height,
                       r=height // 2, fill=color, outline="")

    def _bar_color(self, pct):
        th = self.theme
        if pct >= 85:
            return getattr(fl, "BAD", "#ff453a")
        if pct >= 65:
            return getattr(fl, "WARN", "#ffd60a")
        return th.get("ACCENT", "#0a84ff")


def attach_live_activity(topbar, app):
    """Pack a LiveActivityPill into the TopBar (center-right)."""
    theme = getattr(app, "theme", fl.DARK)
    aero = False
    if hasattr(app, "is_aero_enabled"):
        try:
            aero = bool(app.is_aero_enabled())
        except Exception:
            pass
    bg = topbar["bg"] if "bg" in topbar.keys() else theme.get("SURFACE", "#1c1c1e")
    pill = LiveActivityPill(topbar, app, theme=theme, aero=aero, bg=bg)
    # Place between brand (left) and right-side controls
    pill.pack(side="left", padx=(20, 8), pady=8)
    topbar.live_activity = pill
    app.live_activity = pill
    return pill
