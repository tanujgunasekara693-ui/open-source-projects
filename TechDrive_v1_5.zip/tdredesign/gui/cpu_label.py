#!/usr/bin/env python3
"""
gui/cpu_label.py — Apple "About This Mac" style CPU description
================================================================
Turns a raw processor brand string into a short, readable label:

    "Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz", 4 cores
        -> "3.1 GHz Quad-Core Intel Core i5"

Pure string logic with no GUI or OS dependencies, so it can be unit
tested anywhere.
"""

import re

_CORE_WORDS = {
    1: "Single-Core",
    2: "Dual-Core",
    3: "Triple-Core",
    4: "Quad-Core",
    6: "Six-Core",
    8: "Eight-Core",
    10: "Ten-Core",
    12: "Twelve-Core",
    14: "Fourteen-Core",
    16: "Sixteen-Core",
    24: "24-Core",
    32: "32-Core",
}

_INTEL_FAMILY = re.compile(
    r"\b(Core\s+Ultra\s+\d|Core\s+i[3579]|Core\s+m\d|Core\s+2(?:\s+(?:Duo|Quad))?"
    r"|Xeon|Pentium|Celeron|Atom)\b",
    re.IGNORECASE,
)
_AMD_FAMILY = re.compile(
    r"\b(Ryzen\s+Threadripper(?:\s+PRO)?|Ryzen\s+\d|Athlon|Phenom|EPYC|Opteron)\b",
    re.IGNORECASE,
)
_BASE_GHZ = re.compile(r"@\s*([\d.]+)\s*GHz", re.IGNORECASE)


def _core_word(count):
    if not count or count < 1:
        return ""
    return _CORE_WORDS.get(count, f"{count}-Core")


def _vendor(brand):
    lowered = brand.lower()
    if "intel" in lowered or "genuineintel" in lowered:
        return "Intel"
    if "amd" in lowered or "authenticamd" in lowered:
        return "AMD"
    return ""


def _strip_marks(brand):
    """Drop (R) / (TM) trademark markers: 'Core(TM) i5' -> 'Core i5'."""
    return " ".join(re.sub(r"\((R|TM|tm|r)\)", "", brand).split())


def _family(brand):
    """Return e.g. 'Core i5', 'Core Ultra 7', 'Xeon', 'Ryzen 7'."""
    brand = _strip_marks(brand)
    for pattern in (_INTEL_FAMILY, _AMD_FAMILY):
        match = pattern.search(brand)
        if match:
            # Collapse internal whitespace: "Core  i5" -> "Core i5".
            return " ".join(match.group(1).split())
    return ""


def _speed(brand, fallback_ghz=None):
    """Prefer the base clock in the brand string ('@ 3.10GHz'), else the
    supplied fallback (e.g. max frequency from psutil)."""
    match = _BASE_GHZ.search(brand)
    if match:
        return f"{float(match.group(1)):.1f} GHz"
    if fallback_ghz:
        return f"{float(fallback_ghz):.1f} GHz"
    return ""


def _cleanup(brand):
    """Last-resort readable version of the raw brand string."""
    text = re.sub(r"\((R|TM|tm|r)\)", "", brand)
    text = re.sub(r"@.*$", "", text)
    text = re.sub(r"\bCPU\b", "", text)
    text = re.sub(r"\bProcessor\b", "", text, flags=re.IGNORECASE)
    return " ".join(text.split()).strip()


def format_cpu_label(brand, physical_cores=None, max_ghz=None):
    """Format a CPU brand string the way About This Mac does.

    brand           raw brand string (may be empty or generic)
    physical_cores  number of physical cores, or None if unknown
    max_ghz         fallback clock in GHz (used only if the brand has none)
    """
    brand = (brand or "").strip()
    if not brand:
        return "Processor"

    speed = _speed(brand, max_ghz)
    cores = _core_word(physical_cores)
    vendor = _vendor(brand)
    family = _family(brand)

    if family:
        parts = [speed, cores, vendor, family]
        return " ".join(p for p in parts if p)
    if vendor:
        # Generic "Intel Processor" style string: keep the word Processor.
        parts = [speed, cores, vendor, "Processor"]
        return " ".join(p for p in parts if p)

    # Unrecognised vendor: keep the cleaned brand, still add speed and cores.
    cleaned = _cleanup(brand)
    parts = [speed, cores, cleaned]
    return " ".join(p for p in parts if p) or "Processor"
