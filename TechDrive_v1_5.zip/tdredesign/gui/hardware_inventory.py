#!/usr/bin/env python3
"""
TechDrive Hardware Inventory
============================

Collects a complete Windows hardware inventory from fixed native CIM,
Storage, and NetAdapter queries.  The collected JSON is retained for export;
the on-screen report is formatted from that same JSON and never uses sample
hardware values.
"""

import json
import platform
import subprocess
import tkinter as tk
from gui.tk_dialogs import filedialog, messagebox

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard


IS_WINDOWS = platform.system() == "Windows"


INVENTORY_SCRIPT = r"""
function Read-InventorySection([scriptblock] $Query) {
    try {
        return @(& $Query)
    } catch {
        return @([ordered]@{ Error = $_.Exception.Message })
    }
}

$system = Read-InventorySection {
    [ordered]@{
        ComputerName = $env:COMPUTERNAME
        OperatingSystem = @(Get-CimInstance Win32_OperatingSystem -ErrorAction Stop |
            Select-Object Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime)
        BaseBoard = @(Get-CimInstance Win32_BaseBoard -ErrorAction Stop |
            Select-Object Manufacturer,Product,Version,SerialNumber)
        BIOS = @(Get-CimInstance Win32_BIOS -ErrorAction Stop |
            Select-Object Manufacturer,Name,Version,SMBIOSBIOSVersion,ReleaseDate)
    }
}

$cpu = Read-InventorySection {
    Get-CimInstance Win32_Processor -ErrorAction Stop |
        Select-Object Name,Manufacturer,DeviceID,SocketDesignation,
        NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,
        CurrentClockSpeed,L2CacheSize,L3CacheSize
}

$gpu = Read-InventorySection {
    Get-CimInstance Win32_VideoController -ErrorAction Stop |
        Select-Object Name,AdapterRAM,VideoProcessor,DriverVersion,
        DriverDate,CurrentHorizontalResolution,CurrentVerticalResolution,
        CurrentRefreshRate,Status
}

$memory = Read-InventorySection {
    Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop |
        Select-Object BankLabel,DeviceLocator,Capacity,Speed,
        ConfiguredClockSpeed,Manufacturer,PartNumber,SerialNumber,
        FormFactor,MemoryType,TypeDetail
}

$storage = Read-InventorySection {
    Get-PhysicalDisk -ErrorAction Stop |
        Select-Object FriendlyName,SerialNumber,MediaType,BusType,
        HealthStatus,OperationalStatus,Size,FirmwareVersion
}

$network = Read-InventorySection {
    Get-NetAdapter -Physical -ErrorAction Stop |
        Select-Object Name,InterfaceDescription,Status,MacAddress,
        LinkSpeed,MediaType,ifIndex,DriverInformation
}

[ordered]@{
    GeneratedAt = (Get-Date).ToString('o')
    SYSTEM = $system
    CPU = @($cpu)
    GPU = @($gpu)
    MEMORY = @($memory)
    STORAGE = @($storage)
    NETWORK = @($network)
} | ConvertTo-Json -Depth 8 -Compress
"""


def _run_argv(argv, timeout=90):
    try:
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()
        output = "\n".join(part for part in (stdout, stderr) if part)
        return {
            "ok": result.returncode == 0,
            "stdout": stdout,
            "output": output or f"(no output, exit code {result.returncode})",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "stdout": "", "output": "Command timed out."}
    except FileNotFoundError:
        return {
            "ok": False,
            "stdout": "",
            "output": f"{argv[0]} is not available on this PC.",
        }
    except Exception as exc:
        return {
            "ok": False,
            "stdout": "",
            "output": f"{type(exc).__name__}: {exc}",
        }


def _collect_inventory():
    if not IS_WINDOWS:
        return {
            "ok": False,
            "output": (
                "Windows-only inventory. No hardware collection command was "
                "executed on this operating system."
            ),
        }
    return _run_argv(
        [
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            INVENTORY_SCRIPT,
        ],
        timeout=120,
    )


def _format_bytes(value):
    try:
        size = float(value)
    except (TypeError, ValueError):
        return str(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def _display_value(key, value):
    if value is None or value == "":
        return "—"
    if key.lower() in {"capacity", "size", "adapterram"}:
        return f"{_format_bytes(value)} ({value} bytes)"
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _report_text(data):
    lines = [
        "TECHDRIVE HARDWARE INVENTORY",
        "=" * 30,
        f"Generated: {data.get('GeneratedAt', '—')}",
        "",
    ]
    for section in ("SYSTEM", "CPU", "GPU", "MEMORY", "STORAGE", "NETWORK"):
        lines.extend([section, "-" * len(section)])
        records = data.get(section)
        if isinstance(records, dict):
            records = [records]
        if not records:
            lines.append("No records returned.")
        else:
            for index, record in enumerate(records, start=1):
                if index > 1:
                    lines.append("")
                if not isinstance(record, dict):
                    lines.append(str(record))
                    continue
                if len(records) > 1:
                    lines.append(f"Device {index}")
                for key, value in record.items():
                    if key == "OperatingSystem" and isinstance(value, list):
                        lines.append("OperatingSystem:")
                        for nested in value:
                            for nested_key, nested_value in nested.items():
                                lines.append(
                                    f"  {nested_key}: {_display_value(nested_key, nested_value)}"
                                )
                    elif key in {"BaseBoard", "BIOS"} and isinstance(value, list):
                        lines.append(f"{key}:")
                        for nested in value:
                            for nested_key, nested_value in nested.items():
                                lines.append(
                                    f"  {nested_key}: {_display_value(nested_key, nested_value)}"
                                )
                    else:
                        lines.append(f"{key}: {_display_value(key, value)}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


class HardwareInventoryPage(tk.Frame):
    """Real Windows hardware inventory with JSON and text export."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.inventory = None
        self.report = ""
        self._build()

    def _build(self):
        _, root = make_scrollable(self, self.theme["BG"])
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 12))
        tk.Label(
            header,
            text="HARDWARE INVENTORY",
            bg=self.theme["BG"],
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
        ).pack(anchor="w")
        row = tk.Frame(header, bg=self.theme["BG"])
        row.pack(fill="x", pady=(4, 3))
        tk.Label(
            row,
            text="Hardware Inventory",
            bg=self.theme["BG"],
            fg=self.theme["FG"],
            font=fl.F_TITLE(),
        ).pack(side="left")
        self.collect_button = tk.Button(
            row,
            text="Collect Inventory",
            command=self._collect,
            bg=self.theme["ACCENT"],
            fg=self.theme["ON_ACCENT"],
            activebackground=self.theme["ACCENT_GLOW"],
            activeforeground=self.theme["ON_ACCENT"],
            relief="flat",
            padx=14,
            pady=7,
            cursor="hand2",
        )
        self.collect_button.pack(side="right", padx=(8, 0))
        self.export_button = tk.Button(
            row,
            text="Export Inventory",
            command=self._export,
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            activebackground=self.theme["SELECTION"],
            activeforeground=self.theme["FG"],
            relief="flat",
            padx=14,
            pady=7,
            cursor="hand2",
            state=tk.DISABLED,
        )
        self.export_button.pack(side="right")
        tk.Label(
            header,
            text=(
                "Collects CPU, GPU, DIMM, storage, network, OS, motherboard, "
                "and BIOS details from this Windows machine."
            ),
            bg=self.theme["BG"],
            fg=self.theme["MUTED"],
            font=fl.F_BODY(),
            wraplength=850,
            justify="left",
        ).pack(anchor="w")

        notice = GlassCard(root, self.theme, aero=self.aero, accent=fl.GOOD)
        notice.pack(fill="x", padx=24, pady=(0, 14))
        notice_body = notice.body
        tk.Label(
            notice_body,
            text="REAL HARDWARE DATA",
            bg=notice.fill,
            fg=fl.GOOD,
            font=fl.F_CARD_TITLE(),
        ).pack(anchor="w", padx=14, pady=(12, 3))
        tk.Label(
            notice_body,
            text=(
                "The inventory is collected from fixed Windows CIM, Storage, "
                "and NetAdapter queries. If Windows cannot expose a value, "
                "the report shows that limitation instead of inventing one."
            ),
            bg=notice.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
            wraplength=850,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 12))

        self.status_var = tk.StringVar(value="No inventory collected yet.")
        tk.Label(
            root,
            textvariable=self.status_var,
            bg=self.theme["BG"],
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        ).pack(anchor="w", padx=24, pady=(0, 8))
        self.output = tk.Text(
            root,
            height=32,
            wrap="word",
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            insertbackground=self.theme["FG"],
            font=fl.F_MONO(),
            relief="flat",
            padx=12,
            pady=10,
            state="disabled",
        )
        self.output.pack(fill="both", expand=True, padx=24, pady=(0, 24))

        if not IS_WINDOWS:
            self.collect_button.configure(state=tk.DISABLED)
            tk.Label(
                root,
                text="Preview only: run TechDrive on Windows to collect the real inventory.",
                bg=self.theme["BG"],
                fg=fl.WARN,
                font=fl.F_SMALL(),
            ).pack(anchor="w", padx=24, pady=(0, 8))

    def _write_report(self, text):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)
        self.output.configure(state="disabled")

    def _collect(self):
        if not IS_WINDOWS:
            return
        self.collect_button.configure(state=tk.DISABLED)
        self.export_button.configure(state=tk.DISABLED)
        self.status_var.set("Collecting real Windows hardware data…")

        def done(result):
            self.collect_button.configure(state=tk.NORMAL)
            if not isinstance(result, dict) or not result.get("ok"):
                output = result.get("output", str(result)) if isinstance(result, dict) else str(result)
                self.status_var.set("Inventory collection failed.")
                self._write_report(output)
                return
            try:
                data = json.loads(result.get("stdout", ""))
            except (TypeError, ValueError) as exc:
                self.status_var.set("Windows returned invalid inventory JSON.")
                self._write_report(f"Could not parse inventory: {exc}\n\n{result.get('output', '')}")
                return
            self.inventory = data
            self.report = _report_text(data)
            self._write_report(self.report)
            system = data.get("SYSTEM", {}) if isinstance(data, dict) else {}
            if isinstance(system, list):
                system = system[0] if system else {}
            if not isinstance(system, dict):
                system = {}
            self.status_var.set(
                f"Inventory collected for {system.get('ComputerName', 'this PC')}. "
                "Choose Export Inventory to save JSON or TXT."
            )
            self.export_button.configure(state=tk.NORMAL)

        self.app._run_bg(_collect_inventory, done)

    def _export(self):
        if not self.inventory:
            messagebox.showinfo("Collect inventory first", "Collect the hardware inventory before exporting it.")
            return
        path = filedialog.asksaveasfilename(
            title="Export TechDrive Hardware Inventory",
            defaultextension=".json",
            filetypes=[
                ("JSON inventory", "*.json"),
                ("Technician text report", "*.txt"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return
        try:
            if path.lower().endswith(".txt"):
                with open(path, "w", encoding="utf-8") as handle:
                    handle.write(self.report)
            else:
                with open(path, "w", encoding="utf-8") as handle:
                    json.dump(self.inventory, handle, indent=2, ensure_ascii=False)
                    handle.write("\n")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))
            return
        self.status_var.set(f"Inventory exported to {path}")
        messagebox.showinfo("Inventory exported", f"Saved hardware inventory:\n{path}")
