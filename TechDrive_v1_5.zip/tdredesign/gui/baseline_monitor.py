#!/usr/bin/env python3
"""TechDrive Core — Baseline Monitor. Stores real local measurements and detects deviation."""
import json, os, platform, subprocess, threading, time, tkinter as tk
from gui.tk_dialogs import messagebox
try: import psutil
except ImportError: psutil=None
from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton
from shared import database as db

PS=r'''$ErrorActionPreference='SilentlyContinue'
$cpuT=@(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature | Select-Object InstanceName,CurrentTemperature)
$disk=0
try{$c=Get-Counter '\PhysicalDisk(_Total)\Avg. Disk sec/Transfer' -SampleInterval 1 -MaxSamples 1; $disk=[math]::Round($c.CounterSamples[0].CookedValue*1000,3)}catch{}
$g=@()
try{$g=@(Get-CimInstance -ClassName Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion)}catch{}
[ordered]@{CpuTempC=if($cpuT){[math]::Round((($cpuT|Measure-Object CurrentTemperature -Average).Average/10)-273.15,1)}else{$null};DiskLatencyMs=$disk;GPU=$g;GeneratedAt=(Get-Date).ToString('o')}|ConvertTo-Json -Depth 5 -Compress'''

def measure():
    if platform.system()!='Windows' or psutil is None:return {'ok':False,'error':'Baseline Monitor requires Windows and psutil.'}
    try:
        r=subprocess.run(['powershell','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',PS],capture_output=True,text=True,errors='replace',timeout=30); d=json.loads((r.stdout or '').strip() or '{}')
        vm=psutil.virtual_memory(); d['RamUsagePct']=round(vm.percent,1); d['CpuUsagePct']=round(psutil.cpu_percent(interval=.8),1); d['GeneratedAt']=time.time(); return {'ok':True,'data':d}
    except Exception as e:return {'ok':False,'error':f'{type(e).__name__}: {e}'}

def fmt(v,unit=''):
    return 'Unavailable' if v is None else f'{v}{unit}'

def deviations(base,cur):
    out=[]
    for key,label,unit in [('CpuTempC','CPU temperature','°C'),('RamUsagePct','RAM usage','%'),('DiskLatencyMs','Disk latency',' ms'),('CpuUsagePct','CPU usage','%')]:
        b=base.get(key); c=cur.get(key)
        if isinstance(b,(int,float)) and isinstance(c,(int,float)):
            threshold=max(abs(b)*.35,5 if key!='DiskLatencyMs' else .75)
            if abs(c-b)>=threshold: out.append((label,b,c,unit))
    return out

class BaselineMonitorPage(tk.Frame):
    def __init__(self,parent,app):
        super().__init__(parent,bg=app.theme['BG']); self.app=app; self.theme=app.theme; self.aero=app.is_aero_enabled(); self.base=db.get_baseline(); self.cur=None
        _,self.body=make_scrollable(self,self.theme['BG']); self._build()
    def _build(self):
        h=tk.Frame(self.body,bg=self.theme['BG']); h.pack(fill='x',padx=24,pady=(22,8)); tk.Label(h,text='TECHDRIVE CORE  /  BASELINE MONITOR',bg=self.theme['BG'],fg=self.theme['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w'); tk.Label(h,text='Baseline Monitor',bg=self.theme['BG'],fg=self.theme['FG'],font=fl.F_TITLE()).pack(anchor='w'); tk.Label(h,text='Learn what healthy looks like on this machine, then flag meaningful changes against that personal baseline.',bg=self.theme['BG'],fg=self.theme['MUTED'],font=fl.F_SMALL(),wraplength=850,justify='left').pack(anchor='w')
        bar=tk.Frame(self.body,bg=self.theme['BG']); bar.pack(fill='x',padx=24,pady=8)
        FluentButton(bar,'CAPTURE BASELINE',command=self.capture,theme=self.theme,aero=self.aero,kind='accent',width=170,height=34,backdrop=self.theme['BG']).pack(side='left')
        FluentButton(bar,'CHECK CURRENT',command=self.check,theme=self.theme,aero=self.aero,kind='standard',width=140,height=34,backdrop=self.theme['BG']).pack(side='left',padx=8)
        self.status=tk.Label(bar,text='No baseline captured yet.' if not self.base else 'Baseline available.',bg=self.theme['BG'],fg=self.theme['MUTED'],font=fl.F_SMALL()); self.status.pack(side='left',padx=10)
        self.result=tk.Frame(self.body,bg=self.theme['BG']); self.result.pack(fill='both',expand=True,padx=24,pady=8); self.render()
    def capture(self): self._measure(True)
    def check(self): self._measure(False)
    def _measure(self,setbase):
        self.status.config(text='Measuring live system telemetry…')
        def worker():
            r=measure(); self.app._post_ui(lambda r=r,setbase=setbase: self.finish(r,setbase))
        threading.Thread(target=worker,daemon=True).start()
    def finish(self,r,setbase):
        if not r['ok']: self.status.config(text=r['error']); return
        self.cur=r['data']
        if setbase: self.base=self.cur; db.set_baseline(self.base); self.status.config(text='Healthy baseline captured locally.')
        else:self.status.config(text='Current measurements compared with your saved baseline.')
        self.render()
    def render(self):
        self.result.destroy(); self.result=tk.Frame(self.body,bg=self.theme['BG']); self.result.pack(fill='both',expand=True,padx=24,pady=8)
        if not self.base:
            c=GlassCard(self.result,self.theme,aero=self.aero,accent=self.theme['ACCENT']); c.pack(fill='x',pady=6); tk.Label(c.body,text='BASELINE NOT SET',bg=c.fill,fg=self.theme['ACCENT_GLOW'],font=fl.F_CARD_TITLE()).pack(anchor='w',padx=16,pady=(16,4)); tk.Label(c.body,text='Capture a baseline after the computer is in a normal, healthy state. TechDrive will store the measurements locally.',bg=c.fill,fg=self.theme['MUTED'],font=fl.F_SMALL(),wraplength=800,justify='left').pack(anchor='w',padx=16,pady=(0,16)); return
        c=GlassCard(self.result,self.theme,aero=self.aero,accent=self.theme['ACCENT']); c.pack(fill='x',pady=6); grid=tk.Frame(c.body,bg=c.fill); grid.pack(fill='x',padx=14,pady=14)
        vals=[('CPU temp','CpuTempC','°C'),('RAM usage','RamUsagePct','%'),('Disk latency','DiskLatencyMs',' ms'),('CPU usage','CpuUsagePct','%')]
        for title,k,u in vals:
            tk.Label(grid,text=f'{title}\n{fmt(self.base.get(k),u)}',bg=c.fill,fg=self.theme['FG'],font=fl.F_CARD_TITLE(),justify='center',width=18).pack(side='left')
        if self.cur:
            dev=deviations(self.base,self.cur); c2=GlassCard(self.result,self.theme,aero=self.aero,accent=fl.WARN if dev else fl.GOOD); c2.pack(fill='x',pady=6); tk.Label(c2.body,text='DEVIATION DETECTED' if dev else 'WITHIN BASELINE RANGE',bg=c2.fill,fg=fl.WARN if dev else fl.GOOD,font=fl.F_CARD_TITLE()).pack(anchor='w',padx=16,pady=(14,4));
            text='\n'.join(f'{x[0]}: baseline {fmt(x[1],x[3])} → current {fmt(x[2],x[3])}  ⚠' for x in dev) if dev else 'No configured metric moved far enough from its baseline to trigger an alert.'
            tk.Label(c2.body,text=text,bg=c2.fill,fg=self.theme['FG'],font=fl.F_SMALL(),justify='left',wraplength=820).pack(anchor='w',padx=16,pady=(0,14))
