"""Thread-safe proxies for Tk's native dialog modules.

Tk dialogs must be created on the Tk main thread.  These proxies preserve the
normal filedialog/messagebox/simpledialog APIs while transparently marshalling
calls made by TechDrive worker threads through ui_dispatch.call_sync().
"""
from __future__ import annotations

import tkinter.filedialog as _filedialog
import tkinter.messagebox as _messagebox
import tkinter.simpledialog as _simpledialog

from .ui_dispatch import call_sync


class _DialogProxy:
    def __init__(self, module):
        self._module = module

    def __getattr__(self, name):
        value = getattr(self._module, name)
        if not callable(value):
            return value

        def invoke(*args, **kwargs):
            return call_sync(lambda: value(*args, **kwargs))

        invoke.__name__ = getattr(value, "__name__", name)
        invoke.__doc__ = getattr(value, "__doc__", None)
        return invoke


filedialog = _DialogProxy(_filedialog)
messagebox = _DialogProxy(_messagebox)
simpledialog = _DialogProxy(_simpledialog)

__all__ = ["filedialog", "messagebox", "simpledialog"]
