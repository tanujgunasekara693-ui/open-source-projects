"""Best-effort live hardware facts for the optional startup POST screen."""

import os
import platform
import shutil
import subprocess


def _emit_phase(callback, message):
    if callback:
        callback(message)


def collect_post_info(cpu_name_provider=None, on_phase=None):
    """Collect current CPU, RAM, and mounted-drive information.

    Values are read from the running OS; this is an informational startup
    report, not a firmware-level diagnostic or a change to BIOS settings.
    """
    report = {
        "platform": platform.platform(),
        "cpu_name": "",
        "logical_cpus": os.cpu_count(),
        "memory_total": None,
        "memory_available": None,
        "drives": [],
    }

    _emit_phase(on_phase, "Reading processor identity...")
    try:
        name = cpu_name_provider() if cpu_name_provider else ""
    except Exception:
        name = ""
    report["cpu_name"] = (
        str(name or platform.processor() or platform.machine() or "Unavailable")
        .replace("\r", " ")
        .replace("\n", " ")
        .strip()
    )

    _emit_phase(on_phase, "Reading installed and available memory...")
    psutil = None
    try:
        import psutil

        memory = psutil.virtual_memory()
        report["memory_total"] = memory.total
        report["memory_available"] = memory.available
    except Exception:
        pass

    if report["memory_total"] is None:
        _collect_memory_fallback(report)

    _emit_phase(on_phase, "Enumerating mounted storage...")
    if psutil:
        try:
            partitions = psutil.disk_partitions(all=False)
        except Exception:
            partitions = []
        seen = set()
        for partition in partitions:
            mountpoint = getattr(partition, "mountpoint", "") or ""
            if not mountpoint or mountpoint in seen:
                continue
            seen.add(mountpoint)
            try:
                usage = psutil.disk_usage(mountpoint)
            except Exception:
                continue
            report["drives"].append({
                "label": (getattr(partition, "device", "") or mountpoint)
                .replace("\r", " ")
                .replace("\n", " "),
                "mountpoint": mountpoint,
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
            })
        report["drives"].sort(
            key=lambda drive: (
                0 if drive["mountpoint"].lower().startswith(
                    (os.environ.get("SystemDrive", "C:") + os.sep).lower()
                ) else 1,
                drive["mountpoint"].lower(),
            )
        )
        report["drives"] = report["drives"][:5]
    if not report["drives"]:
        report["drives"] = _collect_drive_fallback()

    _emit_phase(on_phase, "Startup report ready.")
    return report


def _collect_memory_fallback(report):
    if os.name == "nt":
        try:
            import ctypes

            class MemoryStatus(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            status = MemoryStatus()
            status.dwLength = ctypes.sizeof(MemoryStatus)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                report["memory_total"] = status.ullTotalPhys
                report["memory_available"] = status.ullAvailPhys
                return
        except Exception:
            pass

    if os.path.exists("/proc/meminfo"):
        try:
            values = {}
            with open("/proc/meminfo", encoding="ascii") as source:
                for line in source:
                    key, value = line.split(":", 1)
                    if key in {"MemTotal", "MemAvailable"}:
                        values[key] = int(value.strip().split()[0]) * 1024
            report["memory_total"] = values.get("MemTotal")
            report["memory_available"] = values.get("MemAvailable")
            if report["memory_total"] is not None:
                return
        except (OSError, ValueError, IndexError):
            pass

    try:
        page_size = os.sysconf("SC_PAGE_SIZE")
        total_pages = os.sysconf("SC_PHYS_PAGES")
        available_pages = os.sysconf("SC_AVPHYS_PAGES")
        report["memory_total"] = page_size * total_pages
        report["memory_available"] = page_size * available_pages
    except (AttributeError, OSError, ValueError):
        pass


def _collect_drive_fallback():
    roots = []
    if os.name == "nt":
        try:
            import ctypes

            mask = ctypes.windll.kernel32.GetLogicalDrives()
            for index in range(26):
                if mask & (1 << index):
                    root = f"{chr(ord('A') + index)}:\\"
                    try:
                        if ctypes.windll.kernel32.GetDriveTypeW(root) == 3:
                            roots.append(root)
                    except Exception:
                        roots.append(root)
        except Exception:
            system_drive = os.environ.get("SystemDrive", "C:") + "\\"
            roots = [system_drive]
    else:
        roots = [os.path.abspath(os.sep)]

    drives = []
    for root in roots:
        try:
            usage = shutil.disk_usage(root)
        except OSError:
            continue
        drives.append({
            "label": root,
            "mountpoint": root,
            "total": usage.total,
            "used": usage.used,
            "free": usage.free,
        })
    return drives[:5]


def format_bytes(value):
    if value is None:
        return "Unavailable"
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024