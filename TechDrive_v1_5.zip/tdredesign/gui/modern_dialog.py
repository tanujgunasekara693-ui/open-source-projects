#!/usr/bin/env python3
"""
gui/modern_dialog.py — TechDrive's own informational dialog
=============================================================
Standard tkinter.messagebox popups look like Windows 95. This module
draws a small Fluent/Aero-styled Toplevel using the exact same tokens
and widgets as the rest of the app (gui.fluent + gui.widgets), so a
"No administrator privileges" notice looks like it belongs next to the
dashboard instead of like a stray OS dialog.

This is for *non-critical, informational* popups only — a heads-up, a
confirmation, a "here's what happened" message. It is not a replacement
for native file/save dialogs (see gui.tk_dialogs for those), and it does
not try to reproduce every tkinter.messagebox feature.

Usage
-----
    from gui.modern_dialog import info, warning, error, question

    info(self, "Saved", "Your snapshot was saved successfully.")
    warning(self, "Attention",
            "No administrator privileges are currently available.")
    if question(self, "Remove tool?", "This can't be undone."):
        ...

Every function accepts any live widget as the first argument (a card,
a frame, a button — anything with a working winfo_toplevel()) and reads
the app's current theme/Aero state from it, exactly like the rest of
the tool modules do. Safe to call from a background worker thread; the
dialog itself is always built on the Tk main thread.
"""
from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.widgets import FluentButton, GlassCard, round_rect
from gui.ui_dispatch import call_sync

_ICONS = {
    "info": ("\u2139", None),          # ℹ
    "warning": ("\u26A0", fl.WARN),    # ⚠
    "error": ("\u2715", fl.BAD),       # ✕
    "success": ("\u2713", fl.GOOD),    # ✓
    "question": ("?", None),
}


def _theme_and_aero(widget):
    root = widget.winfo_toplevel()
    theme = getattr(root, "theme", fl.DARK)
    aero = False
    is_aero = getattr(root, "is_aero_enabled", None)
    if callable(is_aero):
        try:
            aero = bool(is_aero())
        except Exception:
            aero = False
    return theme, aero


class _ModernDialog(tk.Toplevel):
    """Small centered card: icon, title, message, one or two buttons."""

    def __init__(self, parent, kind, title, message, buttons):
        root = parent.winfo_toplevel()
        super().__init__(root)
        self.result = None
        self.theme, self.aero = _theme_and_aero(parent)
        th = self.theme

        self.withdraw()
        self.title(title or "TechDrive")
        self.configure(bg=th["BG"])
        self.transient(root)
        try:
            from gui.motion import sheet_present
            sheet_present(self, duration_ms=280, from_y=18)
        except Exception:
            pass
        try:
            from gui.acrylic import apply_acrylic
            apply_acrylic(self, opacity=185)
        except Exception:
            pass
        self.resizable(False, False)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass

        glyph, accent_key = _ICONS.get(kind, _ICONS["info"])
        accent = accent_key or th["ACCENT"]

        outer = GlassCard(self, th, aero=self.aero, backdrop=th["BG"],
                          accent=accent, padding=22)
        outer.pack(fill="both", expand=True, padx=16, pady=16)
        body = outer.body
        body.configure(bg=outer.fill)

        header = tk.Frame(body, bg=outer.fill)
        header.pack(fill="x")

        icon_size = 40
        icon_cv = tk.Canvas(header, width=icon_size, height=icon_size,
                            bg=outer.fill, highlightthickness=0, bd=0)
        icon_cv.pack(side="left", padx=(0, 14))
        round_rect(icon_cv, 1, 1, icon_size - 1, icon_size - 1,
                   r=icon_size // 2, fill=fl.mix(outer.fill, accent, 0.18),
                   outline=accent, width=1)
        icon_cv.create_text(icon_size / 2, icon_size / 2, text=glyph,
                            fill=accent, font=fl.font(16, "bold"))

        title_lbl = tk.Label(header, text=title, bg=outer.fill,
                             fg=th["FG"], font=fl.F_SUBTITLE(),
                             anchor="w", justify="left")
        title_lbl.pack(side="left", fill="x", expand=True, anchor="w")

        msg_lbl = tk.Label(body, text=message, bg=outer.fill,
                           fg=th["TEXT_FG"], font=fl.F_BODY(),
                           anchor="w", justify="left", wraplength=320)
        msg_lbl.pack(fill="x", pady=(14, 20))

        btn_row = tk.Frame(body, bg=outer.fill)
        btn_row.pack(fill="x")

        for i, label in enumerate(buttons):
            is_primary = i == len(buttons) - 1
            btn = FluentButton(
                btn_row, label,
                command=lambda v=label: self._finish(v),
                theme=th, aero=self.aero,
                kind="accent" if is_primary else "standard",
                backdrop=outer.fill, height=32,
            )
            btn.pack(side="right", padx=(8, 0))

        self.bind("<Return>", lambda e: self._finish(buttons[-1]))
        self.bind("<Escape>", lambda e: self._finish(buttons[0]))
        self.protocol("WM_DELETE_WINDOW", lambda: self._finish(buttons[0]))

        self.update_idletasks()
        self._center_on(root)
        self.deiconify()
        self.grab_set()
        self.focus_set()

    def _center_on(self, root):
        self.update_idletasks()
        w = max(self.winfo_reqwidth(), 360)
        h = self.winfo_reqheight()
        try:
            rx, ry = root.winfo_rootx(), root.winfo_rooty()
            rw, rh = root.winfo_width(), root.winfo_height()
            x = rx + (rw - w) // 2
            y = ry + (rh - h) // 2
        except tk.TclError:
            x, y = 200, 200
        self.geometry(f"{w}x{h}+{max(0, x)}+{max(0, y)}")

    def _finish(self, value):
        self.result = value
        self.grab_release()
        self.destroy()


def _run(parent, kind, title, message, buttons):
    def build():
        dlg = _ModernDialog(parent, kind, title, message, buttons)
        dlg.wait_window()
        return dlg.result
    return call_sync(build)


def info(parent, title, message):
    """Non-critical heads-up. Returns None."""
    _run(parent, "info", title, message, ("OK",))


def success(parent, title, message):
    _run(parent, "success", title, message, ("OK",))


def warning(parent, title, message):
    _run(parent, "warning", title, message, ("OK",))


def error(parent, title, message):
    _run(parent, "error", title, message, ("OK",))


def question(parent, title, message):
    """Yes/No confirmation. Returns True if the affirmative button was
    pressed, False otherwise (including if the dialog was dismissed)."""
    result = _run(parent, "question", title, message, ("Cancel", "Yes"))
    return result == "Yes"


__all__ = ["info", "success", "warning", "error", "question"]
