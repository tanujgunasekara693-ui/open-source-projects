#!/usr/bin/env python3
"""
gui/module_gallery.py — focused, searchable All Tools browser
===============================================================

The catalogue is deliberately presented as one browse surface rather than a
long page containing every category section at once.  Users can search across
tool names/categories, narrow to a top-level group, pin favorites, and open a
tool without losing the existing catalogue/plugin callbacks.
"""

import tkinter as tk

from gui import fluent as fl
from gui.widgets import card_label
from gui.icons import load_photo


_TOOL_ICON_HINTS = [
    ("wipe", "⌁"), ("erase", "⌁"), ("clean", "⌁"),
    ("test", "◇"), ("benchmark", "◆"), ("stress", "△"),
    ("recover", "✚"), ("restore", "⟳"), ("undelete", "✚"),
    ("clone", "⌬"), ("image", "▧"), ("mirror", "◫"),
    ("encrypt", "◆"), ("decrypt", "◇"), ("password", "◆"),
    ("backup", "▣"), ("sync", "⟳"),
    ("scan", "⌕"), ("search", "⌕"), ("find", "⌕"),
    ("monitor", "▥"), ("snapshot", "▧"), ("report", "▤"),
    ("rename", "◇"), ("batch", "▤"),
    ("network", "◎"), ("ethernet", "⌁"), ("wifi", "⌁"),
    ("boot", "↯"), ("bios", "⚒"), ("firmware", "⚒"),
    ("privacy", "◇"), ("security", "⬢"), ("firewall", "⬢"),
    ("cpu", "◉"), ("ram", "◇"), ("memory", "◇"), ("gpu", "▦"),
    ("disk", "▤"), ("drive", "▤"), ("volume", "▤"),
    ("partition", "△"), ("format", "△"),
    ("prank", "◇"), ("threat", "◇"),
    ("motherboard", "⚒"), ("driver", "▣"),
    ("os ", "▣"), ("system", "▣"),
]


def _icon_for(tool_name, fallback_icon):
    low = tool_name.lower()
    for key, icon in _TOOL_ICON_HINTS:
        if key in low:
            return icon
    return fallback_icon or "▣"


class _ToolCard(tk.Frame):
    _ICON_CACHE = {}
    """A generous, keyboard-readable tool card with a separate favorite hitbox."""

    def __init__(self, parent, theme, aero, icon, name, category,
                 accent, on_click, starred, on_star):
        bg = fl.glass(theme, "CARD_BG", aero)
        super().__init__(
            parent, bg=bg, highlightbackground=theme["STROKE"],
            highlightthickness=1, bd=0, width=220, height=120,
            takefocus=True,
        )
        self.pack_propagate(False)
        self.grid_propagate(False)
        self.theme = theme
        self.base_bg = bg
        self.accent = accent

        pad = tk.Frame(self, bg=bg)
        pad.pack(fill="both", expand=True, padx=11, pady=10)

        header = tk.Frame(pad, bg=bg)
        header.pack(fill="x")
        photo = load_photo(self, category, name, 32, _ToolCard._ICON_CACHE)
        if photo is not None:
            badge = tk.Label(header, image=photo, bg=fl.mix(bg, accent, 0.22), fg=accent, width=32, height=32)
            badge.image = photo
        else:
            badge = tk.Label(header, text=icon, bg=fl.mix(bg, accent, 0.22), fg=accent,
                             font=fl.font(13), width=2, height=1)
        badge.pack(side="left")
        star = tk.Label(
            header, text="★" if starred else "☆", bg=bg,
            fg=fl.WARN if starred else theme["MUTED"],
            font=fl.font(12), cursor="hand2",
        )
        star.pack(side="right", padx=(4, 0))

        title = card_label(
            pad, name, theme, fl.font(10, "bold"), anchor="w",
            justify="left", wraplength=178,
        )
        title.pack(fill="x", anchor="w", pady=(8, 2))
        meta = tk.Frame(pad, bg=bg)
        meta.pack(fill="x")
        category_lbl = card_label(
            meta, category, theme, fl.F_TINY(), fg_key="MUTED",
            anchor="w", justify="left", wraplength=178,
        )
        category_lbl.pack(side="left", fill="x", expand=True, anchor="w")
        open_lbl = tk.Label(
            meta, text="Open  ›", bg=bg, fg=accent,
            font=fl.F_TINY(), cursor="hand2",
        )
        open_lbl.pack(side="right", padx=(6, 0))

        def favorite(_event=None):
            on_star()
            return "break"

        star.bind("<Button-1>", favorite)
        clickable = (self, pad, header, badge, title, meta, category_lbl, open_lbl)
        for widget in clickable:
            widget.bind("<Button-1>", lambda _e: on_click())
            widget.bind("<Enter>", lambda _e: self._hover(True))
            widget.bind("<Leave>", lambda _e: self._hover(False))
            widget.configure(cursor="hand2")
        self.bind("<Return>", lambda _e: on_click())
        star.bind("<Enter>", lambda _e: self._hover(True))
        star.bind("<Leave>", lambda _e: self._hover(False))

    def _hover(self, active):
        color = fl.mix(self.base_bg, self.accent, 0.14) if active else self.base_bg
        self.configure(
            bg=color,
            highlightbackground=self.accent if active else self.theme["STROKE"],
        )
        self._paint_children(self, color)

    def _paint_children(self, widget, color):
        for child in widget.winfo_children():
            try:
                child.configure(bg=color)
            except tk.TclError:
                pass
            self._paint_children(child, color)


class _Pager(tk.Frame):
    """Fixed footer controls so pagination stays reachable above the fold."""

    def __init__(self, parent, theme, on_prev, on_next):
        super().__init__(parent, bg=parent["bg"])
        self.theme = theme
        self.info = tk.Label(
            self, text="", bg=parent["bg"], fg=theme["MUTED"],
            font=fl.F_SMALL(),
        )
        self.info.pack(side="left")
        controls = tk.Frame(self, bg=parent["bg"])
        controls.pack(side="right")
        self.prev_btn = self._button(controls, "‹  Previous", on_prev)
        self.prev_btn.pack(side="left", padx=(0, 6))
        self.page_lbl = tk.Label(
            controls, text="1", bg=fl.mix(parent["bg"], theme["FG"], 0.08),
            fg=theme["FG"], font=fl.font(9, "bold"), width=3, pady=4,
        )
        self.page_lbl.pack(side="left", padx=(0, 6))
        self.next_btn = self._button(controls, "Next  ›", on_next)
        self.next_btn.pack(side="left")

    def _button(self, parent, label, command):
        button = tk.Label(
            parent, text=label,
            bg=fl.mix(parent["bg"], self.theme["FG"], 0.06),
            fg=self.theme["FG"], font=fl.F_SMALL(), padx=9, pady=4,
            cursor="hand2",
        )
        button.bind("<Button-1>", lambda _e: command())
        return button

    def update(self, page, page_size, total):
        pages = max(1, -(-total // page_size))
        if total:
            start = page * page_size + 1
            end = min(total, (page + 1) * page_size)
            self.info.config(text=f"Showing {start}–{end} of {total} tools")
        else:
            self.info.config(text="No tools match this view")
        self.page_lbl.config(text=f"{page + 1} / {pages}")
        dim = fl.mix(self.theme["MUTED"], self.theme["BG"], 0.45)
        self.prev_btn.config(
            fg=self.theme["FG"] if page > 0 else dim,
            cursor="hand2" if page > 0 else "arrow",
        )
        self.next_btn.config(
            fg=self.theme["FG"] if page < pages - 1 else dim,
            cursor="hand2" if page < pages - 1 else "arrow",
        )


class ModuleGalleryPage(tk.Frame):
    """Responsive All Tools browser backed by the live plugin catalogue."""

    def __init__(self, parent, theme, catalogue, category_colors,
                 on_open_tool, is_favorite, toggle_favorite, aero=False,
                 tool_groups=None, group_labels=None,
                 get_recent=None, clear_recent=None,
                 on_favorites_changed=None):
        super().__init__(parent, bg=theme["BG"])
        self.theme = theme
        self.aero = aero
        self.catalogue = catalogue
        self.category_colors = category_colors
        self.on_open_tool = on_open_tool
        self.is_favorite = is_favorite
        self.toggle_favorite = toggle_favorite
        # Recently-used tools are optional: callers that don't pass these
        # simply lose the "Recently Used" rail entry, nothing else breaks.
        self.get_recent = get_recent
        self.clear_recent = clear_recent
        # Optional hook so other surfaces (e.g. the dashboard's Quick
        # Access / Pinned Tools card) can stay in sync when a star is
        # toggled from inside this gallery.
        self.on_favorites_changed = on_favorites_changed
        self.tool_groups = tool_groups or {
            "All": [category for category, _icon, _tools in catalogue]
        }
        self.group_labels = group_labels or {"All": ("▣", "All Tools")}
        self.view = ("all", None)
        self.query = ""
        self.sort_mode = "recommended"
        self.page = 0
        self.columns = 3
        self._last_grid_width = 0
        self._rail_rows = {}
        self._cards = []
        self._icon_cache = {}
        self._build()

    # ------------------------------------------------------------------
    # Catalogue and view helpers
    # ------------------------------------------------------------------
    def _cat_lookup(self):
        return {category: (icon, tools)
                for category, icon, tools in self.catalogue}

    def _all_tools(self):
        return [
            (category, icon, tool)
            for category, icon, tools in self.catalogue
            for tool in tools
        ]

    def _group_tools(self, group):
        categories = set(self.tool_groups.get(group, []))
        return [
            (category, icon, tool)
            for category, icon, tools in self.catalogue
            if category in categories
            for tool in tools
        ]

    # Compatibility helpers retained for callers and plugin code that used
    # the previous grouped gallery implementation.
    def tools_for(self, category):
        _icon, tools = self._cat_lookup().get(category, ("▣", []))
        return list(tools)

    def categories_in_group(self, group):
        lookup = self._cat_lookup()
        return [category for category in self.tool_groups.get(group, [])
                if category in lookup]

    def total_tools(self):
        return self._all_tools_count()

    def _favorites(self):
        return [
            item for item in self._all_tools()
            if self.is_favorite(item[0], item[2])
        ]

    def _recent_tools(self, limit=10):
        """Most-recently-opened tools, newest first, deduped, skipping
        anything that's since been removed/disabled from the catalogue."""
        if not self.get_recent:
            return []
        lookup = self._cat_lookup()
        seen = set()
        recents = []
        for row in self.get_recent(limit=max(limit, 25)):
            category, tool = row[0], row[1]
            key = (category, tool)
            if key in seen:
                continue
            icon, category_tools = lookup.get(category, ("▣", []))
            if tool not in category_tools:
                continue
            seen.add(key)
            recents.append((category, icon, tool))
            if len(recents) >= limit:
                break
        return recents

    def _visible_tools(self):
        kind, value = self.view
        if kind == "group":
            tools = self._group_tools(value)
        elif kind == "category":
            icon, category_tools = self._cat_lookup().get(value, ("▣", []))
            tools = [(value, icon, tool) for tool in category_tools]
        elif kind == "multi_category":
            selected = set(value or [])
            tools = [(category, icon, tool) for category, icon, category_tools in self.catalogue
                     if category in selected for tool in category_tools]
        elif kind == "favorites":
            tools = self._favorites()
        elif kind == "recent":
            tools = list(self._recent_tools())
            # Recency order is the point of this view - keep it unless the
            # user explicitly picked a different sort below.
            if self.sort_mode == "recommended":
                return self._filter_by_query(tools)
        else:
            tools = self._all_tools()

        return self._filter_by_query(tools)

    def _filter_by_query(self, tools):
        query = self.query.strip().lower()
        if query:
            tools = [
                item for item in tools
                if query in item[2].lower() or query in item[0].lower()
            ]
        if self.sort_mode == "name":
            tools.sort(key=lambda item: item[2].lower())
        elif self.sort_mode == "category":
            tools.sort(key=lambda item: (item[0].lower(), item[2].lower()))
        elif self.sort_mode == "favorites":
            tools.sort(
                key=lambda item: (
                    not self.is_favorite(item[0], item[2]),
                    item[2].lower(),
                )
            )
        return tools

    def _view_title(self):
        kind, value = self.view
        if kind == "group":
            return self.group_labels.get(value, ("▣", value))[1]
        if kind == "category":
            return value
        if kind == "multi_category":
            return "Core Module Tools"
        if kind == "favorites":
            return "Pinned Favorites"
        if kind == "recent":
            return "Recently Used"
        return "All Tools"

    def _view_subtitle(self, total):
        if self.query:
            return f'{total} result{"s" if total != 1 else ""} for “{self.query}”'
        if self.view[0] == "favorites":
            return "Your one-click tools, kept close at hand"
        if self.view[0] == "recent":
            return "The last tools you opened, most recent first"
        return "Find the right utility without digging through every category"

    def _suggestions_for_empty_search(self, limit=6):
        """A handful of clickable fallbacks shown when a search or filter
        comes up empty, so the user isn't stuck staring at a dead end."""
        seen = set()
        pool = self._recent_tools(limit=limit) + self._favorites() + self._all_tools()
        suggestions = []
        for item in pool:
            key = (item[0], item[2])
            if key in seen:
                continue
            seen.add(key)
            suggestions.append(item)
            if len(suggestions) >= limit:
                break
        return suggestions

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def _build(self):
        outer = tk.Frame(self, bg=self.theme["BG"])
        outer.pack(fill="both", expand=True)
        self._build_rail(outer)

        content = tk.Frame(outer, bg=self.theme["BG"])
        content.pack(side="left", fill="both", expand=True)
        self._build_header(content)

        canvas_wrap = tk.Frame(content, bg=self.theme["BG"])
        canvas_wrap.pack(fill="both", expand=True, padx=fl.PAD_PAGE, pady=(0, 6))
        self.canvas = tk.Canvas(
            canvas_wrap, bg=self.theme["BG"], highlightthickness=0, bd=0,
        )
        scrollbar = tk.Scrollbar(
            canvas_wrap, orient="vertical", command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.body = tk.Frame(self.canvas, bg=self.theme["BG"])
        self._window = self.canvas.create_window(
            (0, 0), window=self.body, anchor="nw",
        )
        self.body.bind(
            "<Configure>",
            lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self._resize_body(event.width),
        )
        for sequence, delta in (
            ("<MouseWheel>", lambda event: int(-event.delta / 120)),
            ("<Button-4>", lambda _event: -1),
            ("<Button-5>", lambda _event: 1),
        ):
            self.canvas.bind(
                sequence,
                lambda event, get_delta=delta:
                self.canvas.yview_scroll(get_delta(event), "units"),
            )

        self.pager = _Pager(
            content, self.theme,
            on_prev=lambda: self._change_page(-1),
            on_next=lambda: self._change_page(1),
        )
        self.pager.pack(fill="x", padx=fl.PAD_PAGE, pady=(0, fl.PAD_PAGE))
        self.show_all()

    def _build_header(self, parent):
        th = self.theme
        header = tk.Frame(parent, bg=th["BG"])
        header.pack(fill="x", padx=fl.PAD_PAGE, pady=(fl.PAD_PAGE, 8))

        title_col = tk.Frame(header, bg=th["BG"])
        title_col.pack(side="left", fill="x", expand=True)
        self.title_lbl = tk.Label(
            title_col, text="All Tools", bg=th["BG"],
            fg=fl.glow_color(th, self.aero), font=fl.F_TITLE(),
        )
        self.title_lbl.pack(side="left", anchor="w")
        self.beta_badge = tk.Label(
            title_col, text="BETA v1.1", bg=fl.mix(th["BG"], th["ACCENT"], 0.16),
            fg=th["ACCENT"], font=fl.font(8, "bold"), padx=7, pady=3,
        )
        self.beta_badge.pack(side="left", padx=(10, 0), pady=(2, 0))
        self.subtitle_lbl = tk.Label(
            title_col, text="", bg=th["BG"], fg=th["MUTED"],
            font=fl.F_SMALL(), anchor="w",
        )
        self.subtitle_lbl.pack(anchor="w", pady=(2, 0))

        self.count_badge = tk.Label(
            header, text="", bg=fl.mix(th["ACCENT"], th["BG"], 0.78),
            fg=th["ACCENT_GLOW"], font=fl.font(9, "bold"),
            padx=10, pady=5,
        )
        self.count_badge.pack(side="right", padx=(8, 0))

        search_wrap = tk.Frame(
            parent, bg=fl.glass(th, "CARD_BG", self.aero),
            highlightbackground=th["STROKE"], highlightthickness=1,
        )
        search_wrap.pack(fill="x", padx=fl.PAD_PAGE, pady=(0, 10))
        tk.Label(
            search_wrap, text="⌕", bg=search_wrap["bg"], fg=th["ACCENT"],
            font=fl.font(16),
        ).pack(side="left", padx=(10, 5))
        self.search_var = tk.StringVar()
        self._search_hint = "Search by tool name or category…"
        self._search_hint_active = True
        self.search_entry = tk.Entry(
            search_wrap, textvariable=self.search_var,
            bg=search_wrap["bg"], fg=th["FG"], insertbackground=th["FG"],
            relief="flat", bd=0, font=fl.F_BODY(),
        )
        self.search_entry.pack(
            side="left", fill="x", expand=True, padx=(0, 8), ipady=7,
        )
        self.search_entry.insert(0, self._search_hint)
        self.search_entry.config(fg=th["MUTED"])
        self.search_entry.bind("<FocusIn>", lambda _e: self._search_focus_in())
        self.search_entry.bind("<FocusOut>", lambda _e: self._search_focus_out())
        self.search_entry.bind("<Escape>", lambda _e: self._clear_search())
        self.search_var.trace_add("write", lambda *_args: self._on_search())
        clear = tk.Label(
            search_wrap, text="Clear", bg=search_wrap["bg"],
            fg=th["ACCENT"], font=fl.F_SMALL(), cursor="hand2",
        )
        clear.pack(side="right", padx=10)
        clear.bind("<Button-1>", lambda _e: self._clear_search())
        self.sort_btn = tk.Label(
            search_wrap, text="Sort: Recommended  ▾", bg=search_wrap["bg"],
            fg=th["MUTED"], font=fl.F_SMALL(), cursor="hand2",
        )
        self.sort_btn.pack(side="right", padx=(8, 2))
        self.sort_btn.bind("<Button-1>", lambda _e: self._open_sort_menu())

    def _build_rail(self, parent):
        th = self.theme
        bg = fl.glass(th, "BG_LIGHT", self.aero, 0.16)
        rail = tk.Frame(
            parent, bg=bg, width=238,
            highlightbackground=th["STROKE_SOFT"], highlightthickness=1,
        )
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        self.rail = rail

        brand = tk.Frame(rail, bg=bg)
        brand.pack(fill="x", padx=14, pady=(16, 12))
        tk.Label(
            brand, text="TOOL LIBRARY", bg=bg, fg=th["MUTED"],
            font=fl.font(9, "bold"),
        ).pack(anchor="w")
        tk.Label(
            brand, text="Pick a lane. Get to work.", bg=bg, fg=th["FG"],
            font=fl.font(11, "bold"),
        ).pack(anchor="w", pady=(3, 0))

        tk.Label(
            rail, text="BROWSE", bg=bg, fg=th["MUTED"],
            font=fl.font(8, "bold"),
        ).pack(anchor="w", padx=14, pady=(4, 6))
        self.all_row = self._rail_item(
            rail, "⌘", "All Tools", self._all_tools_count(),
            lambda: self.show_all(),
        )
        self.all_row.pack(fill="x", padx=8, pady=2)
        self.favorites_row = self._rail_item(
            rail, "★", "Pinned Favorites", len(self._favorites()),
            lambda: self.show_favorites(),
        )
        self.favorites_row.pack(fill="x", padx=8, pady=2)
        if self.get_recent:
            self.recent_row = self._rail_item(
                rail, "◷", "Recently Used", len(self._recent_tools()),
                lambda: self.show_recent(),
            )
            self.recent_row.pack(fill="x", padx=8, pady=2)
        else:
            self.recent_row = None

        tk.Frame(rail, bg=th["STROKE"], height=1).pack(
            fill="x", padx=14, pady=13,
        )
        tk.Label(
            rail, text="CATEGORIES", bg=bg, fg=th["MUTED"],
            font=fl.font(8, "bold"),
        ).pack(anchor="w", padx=14, pady=(0, 6))
        self.groups_holder = tk.Frame(rail, bg=bg)
        self.groups_holder.pack(fill="x")
        self._refresh_group_rows()

        hint = tk.Frame(rail, bg=fl.mix(bg, th["ACCENT"], 0.08))
        hint.pack(side="bottom", fill="x", padx=10, pady=12)
        tk.Label(
            hint, text="TIP", bg=hint["bg"], fg=th["ACCENT_GLOW"],
            font=fl.font(8, "bold"),
        ).pack(anchor="w", padx=10, pady=(9, 2))
        tk.Label(
            hint, text="Use the search box to find a tool by name or category.",
            bg=hint["bg"], fg=th["MUTED"], font=fl.F_TINY(),
            wraplength=195, justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 9))

    def _rail_item(self, parent, icon, text, count, command):
        th = self.theme
        row = tk.Frame(parent, bg=parent["bg"], cursor="hand2", height=32)
        row.pack_propagate(False)
        icon_lbl = tk.Label(
            row, text=icon, bg=row["bg"], fg=th["MUTED"], font=fl.font(11),
        )
        icon_lbl.pack(side="left", padx=(9, 7))
        name_lbl = tk.Label(
            row, text=text, bg=row["bg"], fg=th["FG"],
            font=fl.F_SMALL(), anchor="w",
        )
        name_lbl.pack(side="left", fill="x", expand=True)
        count_lbl = tk.Label(
            row, text=str(count), bg=row["bg"], fg=th["MUTED"],
            font=fl.F_TINY(),
        )
        count_lbl.pack(side="right", padx=9)
        row._labels = (icon_lbl, name_lbl, count_lbl)
        for widget in (row, icon_lbl, name_lbl, count_lbl):
            widget.bind("<Button-1>", lambda _e: command())
            widget.bind("<Enter>", lambda _e, r=row: self._rail_hover(r, True))
            widget.bind("<Leave>", lambda _e, r=row: self._rail_hover(r, False))
        return row

    def _rail_hover(self, row, active):
        if row is self._rail_rows.get("selected"):
            return
        color = fl.mix(self.rail["bg"], self.theme["ACCENT"], 0.10) if active else self.rail["bg"]
        row.configure(bg=color)
        for label in getattr(row, "_labels", ()):
            label.configure(bg=color)

    def _refresh_group_rows(self):
        for child in self.groups_holder.winfo_children():
            child.destroy()
        self._rail_rows = {}
        for key, (icon, label) in self.group_labels.items():
            count = len(self._group_tools(key))
            row = self._rail_item(
                self.groups_holder, icon, label, count,
                lambda group=key: self.show_group(group),
            )
            row.pack(fill="x", padx=8, pady=2)
            self._rail_rows[key] = row
        self._sync_rail_selection()

    def _sync_rail_selection(self):
        selected_key = None
        if self.view[0] == "all":
            selected_key = "__all__"
        elif self.view[0] == "favorites":
            selected_key = "__favorites__"
        elif self.view[0] == "recent":
            selected_key = "__recent__"
        elif self.view[0] == "group":
            selected_key = self.view[1]
        rows = {
            "__all__": getattr(self, "all_row", None),
            "__favorites__": getattr(self, "favorites_row", None),
            "__recent__": getattr(self, "recent_row", None),
            **self._rail_rows,
        }
        for key, row in rows.items():
            if row is None:
                continue
            selected = key == selected_key
            color = fl.mix(self.rail["bg"], self.theme["ACCENT"], 0.26) if selected else self.rail["bg"]
            row.configure(bg=color)
            for label in getattr(row, "_labels", ()):
                label.configure(
                    bg=color,
                    fg=self.theme["ACCENT_GLOW"] if selected and label is not row._labels[2]
                    else self.theme["MUTED"] if label is row._labels[2]
                    else self.theme["FG"],
                )
        self._rail_rows["selected"] = rows.get(selected_key)

    # ------------------------------------------------------------------
    # Interaction and rendering
    # ------------------------------------------------------------------
    def _search_focus_in(self):
        if not self._search_hint_active:
            return
        self._search_hint_active = False
        self.search_entry.delete(0, "end")
        self.search_entry.config(fg=self.theme["FG"])

    def _search_focus_out(self):
        if self.search_entry.get().strip():
            return
        self._search_hint_active = True
        self.search_entry.delete(0, "end")
        self.search_entry.insert(0, self._search_hint)
        self.search_entry.config(fg=self.theme["MUTED"])

    def _open_sort_menu(self):
        labels = {
            "recommended": "Recommended",
            "name": "Name A–Z",
            "category": "Category",
            "favorites": "Favorites first",
        }
        menu = tk.Menu(
            self, tearoff=0, bg=self.theme["CARD_BG"],
            fg=self.theme["FG"], activebackground=self.theme["ACCENT"],
            activeforeground=self.theme["ON_ACCENT"],
        )
        for mode, label in labels.items():
            prefix = "✓  " if mode == self.sort_mode else "    "
            menu.add_command(
                label=prefix + label,
                command=lambda selected=mode: self._set_sort(selected),
            )
        try:
            menu.tk_popup(
                self.sort_btn.winfo_rootx(),
                self.sort_btn.winfo_rooty() + self.sort_btn.winfo_height(),
            )
        finally:
            menu.grab_release()

    def _set_sort(self, mode):
        self.sort_mode = mode
        labels = {
            "recommended": "Recommended",
            "name": "Name A–Z",
            "category": "Category",
            "favorites": "Favorites first",
        }
        self.sort_btn.config(text=f"Sort: {labels.get(mode, 'Recommended')}  ▾")
        self.page = 0
        self._render()

    def _all_tools_count(self):
        return sum(len(tools) for _category, _icon, tools in self.catalogue)

    def _on_search(self):
        if self._search_hint_active:
            return
        self.query = self.search_var.get().strip()
        self.page = 0
        self._render()

    def _clear_search(self):
        self.search_entry.delete(0, "end")
        self._search_hint_active = False
        self.search_var.set("")
        self._search_focus_out()
        self.search_entry.focus_set()

    def show_categories(self, categories):
        """Show tools from multiple catalogue categories (used by Core Modules)."""
        categories = set(categories or [])
        self.view = ("multi_category", categories)
        self.page = 0
        self._render()

    def show_all(self):
        self.view = ("all", None)
        self.page = 0
        self._render()

    def show_favorites(self):
        self.view = ("favorites", None)
        self.page = 0
        self._render()

    def show_recent(self):
        self.view = ("recent", None)
        self.page = 0
        self._render()

    def show_group(self, key):
        self.view = ("group", key)
        self.page = 0
        self._render()

    def drill_into(self, category):
        self.view = ("category", category)
        self.page = 0
        self._render()

    def _change_page(self, delta):
        tools = self._visible_tools()
        page_size = self.columns * 4
        pages = max(1, -(-len(tools) // page_size))
        new_page = max(0, min(pages - 1, self.page + delta))
        if new_page != self.page:
            self.page = new_page
            self._render()
            self.canvas.yview_moveto(0)

    def _resize_body(self, width):
        if width <= 0:
            return
        self.canvas.itemconfigure(self._window, width=width)
        if width < 640:
            columns = 2
        elif width < 930:
            columns = 3
        else:
            columns = 4
        if columns != self.columns or abs(width - self._last_grid_width) > 80:
            self.columns = columns
            self._last_grid_width = width
            self.after_idle(self._render)

    def _render(self):
        if not hasattr(self, "body"):
            return
        for child in self.body.winfo_children():
            child.destroy()
        tools = self._visible_tools()
        total = len(tools)
        page_size = self.columns * 4
        pages = max(1, -(-total // page_size))
        self.page = min(self.page, pages - 1)
        start = self.page * page_size
        page_tools = tools[start:start + page_size]

        self.title_lbl.config(text=self._view_title())
        self.subtitle_lbl.config(text=self._view_subtitle(total))
        self.count_badge.config(text=f"{total} tool{'s' if total != 1 else ''}")
        self._sync_rail_selection()
        self.all_row._labels[2].config(text=str(self._all_tools_count()))
        self.favorites_row._labels[2].config(text=str(len(self._favorites())))
        if self.recent_row is not None:
            self.recent_row._labels[2].config(text=str(len(self._recent_tools())))

        for column in range(self.columns):
            self.body.columnconfigure(column, weight=1, uniform="tool-grid")
        self._cards = []
        for index, (category, icon, tool) in enumerate(page_tools):
            row, column = divmod(index, self.columns)
            accent = self.category_colors.get(category, self.theme["ACCENT"])
            card = _ToolCard(
                self.body, self.theme, self.aero, _icon_for(tool, icon), tool,
                category, accent,
                on_click=lambda c=category, t=tool: self._open_tool(c, t),
                starred=self.is_favorite(category, tool),
                on_star=lambda c=category, t=tool: self._flip_star(c, t),
            )
            card.grid(
                row=row, column=column, sticky="nsew",
                padx=(0 if column == 0 else 6, 0),
                pady=(0 if row == 0 else 8, 0),
            )
            self._cards.append(card)
        self._wire_keyboard_nav()
        if not page_tools:
            empty = tk.Frame(self.body, bg=self.theme["BG"])
            empty.grid(row=0, column=0, columnspan=self.columns, sticky="ew", pady=36)
            tk.Label(
                empty, text="No tools found", bg=empty["bg"],
                fg=self.theme["FG"], font=fl.F_SUBTITLE(),
            ).pack()
            tk.Label(
                empty, text="Try a different search or choose another category.",
                bg=empty["bg"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            ).pack(pady=(6, 0))
            suggestions = self._suggestions_for_empty_search()
            if suggestions:
                chips = tk.Frame(empty, bg=self.theme["BG"])
                chips.pack(pady=(14, 0))
                tk.Label(
                    chips, text="Try one of these instead:", bg=self.theme["BG"],
                    fg=self.theme["MUTED"], font=fl.F_SMALL(),
                ).pack(anchor="w", pady=(0, 6))
                row_frame = tk.Frame(chips, bg=self.theme["BG"])
                row_frame.pack()
                for category, icon, tool in suggestions:
                    chip_bg = fl.mix(self.theme["BG"], self.theme["ACCENT"], 0.14)
                    chip = tk.Label(
                        row_frame, text=f"{_icon_for(tool, icon)}  {tool}",
                        bg=chip_bg, fg=self.theme["FG"], font=fl.F_SMALL(),
                        padx=9, pady=5, cursor="hand2",
                    )
                    chip.pack(side="left", padx=4, pady=4)
                    chip.bind(
                        "<Button-1>",
                        lambda _e, c=category, t=tool: self._open_tool(c, t),
                    )
        self.pager.update(self.page, page_size, total)

    def _open_tool(self, category, tool):
        """Open a tool, then quietly refresh the Recently Used rail entry
        (and its list, if the user is currently looking at it) so the MRU
        view reflects what was just opened without a manual re-open."""
        self.on_open_tool(category, tool)
        if self.recent_row is None:
            return
        self.recent_row._labels[2].config(text=str(len(self._recent_tools())))
        if self.view[0] == "recent":
            self._render()

    # ------------------------------------------------------------------
    # Keyboard navigation - arrow keys move between cards in the grid,
    # Enter opens the focused card (bound in _ToolCard itself).
    # ------------------------------------------------------------------
    def _wire_keyboard_nav(self):
        count = len(self._cards)
        for index, card in enumerate(self._cards):
            card.bind("<Up>", lambda _e, i=index: self._move_focus(i, -self.columns))
            card.bind("<Down>", lambda _e, i=index: self._move_focus(i, self.columns))
            card.bind("<Left>", lambda _e, i=index: self._move_focus(i, -1))
            card.bind("<Right>", lambda _e, i=index: self._move_focus(i, 1))
        if count and hasattr(self, "search_entry"):
            self.search_entry.bind("<Down>", lambda _e: self._focus_card(0))

    def _move_focus(self, index, delta):
        target = index + delta
        self._focus_card(target)
        return "break"

    def _focus_card(self, index):
        if 0 <= index < len(self._cards):
            self._cards[index].focus_set()
        return "break"

    def _flip_star(self, category, tool):
        self.toggle_favorite(category, tool)
        self._refresh_group_rows()
        self._render()
        if self.on_favorites_changed:
            self.on_favorites_changed()

    def refresh_catalogue(self, catalogue):
        self.catalogue = catalogue
        self.page = 0
        self._refresh_group_rows()
        self._render()

    def show(self):
        self._render()