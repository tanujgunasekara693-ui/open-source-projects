"""
TechDrive Security Center
=========================

Defensive, read-only Windows security posture audit.  This page explains
what it observed and what the owner should review; it never silently changes
firewall, Defender, account, update, network, or privacy settings.
"""

import datetime as _datetime
import json
import platform
import subprocess
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton, HealthRing
from shared import database as db


IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = (
    subprocess.CREATE_NO_WINDOW
    if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW")
    else 0
)


def _powershell_json(script, timeout=30):
    """Run a fixed read-only PowerShell query and decode its JSON result."""
    if not IS_WINDOWS:
        return None, "This audit runs on the target Windows PC."
    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                script,
            ],
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
            creationflags=NO_WINDOW,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip()
        if result.returncode != 0:
            return None, output or f"PowerShell exited with code {result.returncode}."
        if not output:
            return None, "The Windows query returned no data."
        try:
            return json.loads(output), None
        except json.JSONDecodeError as exc:
            return None, f"Windows returned an unreadable result: {exc}"
    except subprocess.TimeoutExpired:
        return None, "The Windows query timed out."
    except FileNotFoundError:
        return None, "powershell.exe is not available on this PC."
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def _as_list(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _finding(key, label, status, score, title, explanation, recommendation,
             evidence="", weight=1):
    return {
        "key": key,
        "label": label,
        "status": status,
        "score": score,
        "title": title,
        "explanation": explanation,
        "recommendation": recommendation,
        "evidence": evidence,
        "weight": weight,
    }


def _unavailable(key, label, error, weight=1):
    return _finding(
        key,
        label,
        "info",
        None,
        f"{label} could not be measured",
        f"TechDrive did not receive a trustworthy result from the Windows "
        f"security provider: {error}",
        "Review this area directly in Windows Settings or Windows Security. "
        "No change was made automatically.",
        weight=weight,
    )


def _audit_firewall():
    data, error = _powershell_json(
        "@(Get-NetFirewallProfile -ErrorAction Stop | "
        "Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction) "
        "| ConvertTo-Json -Depth 4 -Compress"
    )
    profiles = _as_list(data)
    if error or not profiles:
        return _unavailable("firewall", "Windows Firewall", error or "No profiles returned.", 25)
    enabled = [item for item in profiles if item.get("Enabled") is True]
    if len(enabled) == len(profiles):
        status, score = "good", 100
        title = "Windows Firewall is enabled"
        explanation = (
            "Every firewall profile returned by Windows is enabled. "
            "This is a configuration signal, not proof that every application "
            "or rule is appropriate."
        )
        recommendation = "Keep the firewall enabled and review unusual inbound rules when troubleshooting exposure."
    elif enabled:
        status, score = "warn", 60
        title = "Some firewall profiles are disabled"
        explanation = (
            f"Windows reported {len(enabled)} of {len(profiles)} firewall "
            "profiles enabled. A device can change profiles as its network changes."
        )
        recommendation = "Open Firewall & network protection and review the disabled profile before using an untrusted network."
    else:
        status, score = "bad", 20
        title = "Windows Firewall is disabled"
        explanation = "No returned Windows firewall profile was enabled."
        recommendation = "Review Firewall & network protection and enable the appropriate profile unless managed policy explains the state."
    evidence = ", ".join(
        f"{item.get('Name', 'Profile')}: {'On' if item.get('Enabled') else 'Off'}"
        for item in profiles
    )
    return _finding("firewall", "Windows Firewall", status, score, title,
                    explanation, recommendation, evidence, 25)


def _audit_defender():
    data, error = _powershell_json(
        "Get-MpComputerStatus -ErrorAction Stop | "
        "Select-Object AMServiceEnabled,AntivirusEnabled,"
        "AntispywareEnabled,RealTimeProtectionEnabled,IsTamperProtected,"
        "AntivirusSignatureLastUpdated,AntivirusSignatureAge | "
        "ConvertTo-Json -Compress",
        timeout=35,
    )
    if error or not isinstance(data, dict):
        return _unavailable("defender", "Defender status", error or "No Defender status returned.", 25)
    required = [
        bool(data.get("AMServiceEnabled")),
        bool(data.get("AntivirusEnabled")),
        bool(data.get("AntispywareEnabled")),
        bool(data.get("RealTimeProtectionEnabled")),
    ]
    enabled_count = sum(required)
    if enabled_count == len(required):
        status, score = "good", 100
        title = "Defender protection is enabled"
        explanation = "Windows Defender reported its service, antivirus, antispyware, and real-time protection as enabled."
        recommendation = "Keep protection enabled and allow signatures to update. Tamper protection is shown in the evidence."
    elif enabled_count:
        status, score = "warn", 65
        title = "Defender protection is incomplete"
        explanation = f"Windows confirmed {enabled_count} of {len(required)} core Defender protections."
        recommendation = "Open Windows Security and determine whether another managed antivirus or policy explains the missing protections."
    else:
        status, score = "bad", 20
        title = "Defender protection was not confirmed"
        explanation = "Windows did not report the core Defender protections as enabled."
        recommendation = "Review Windows Security before assuming the PC is protected. Do not disable another antivirus to force Defender on."
    updated = data.get("AntivirusSignatureLastUpdated") or "not returned"
    tamper = "on" if data.get("IsTamperProtected") else "off or not returned"
    evidence = f"{enabled_count}/4 core protections; signatures: {updated}; tamper protection: {tamper}"
    return _finding("defender", "Defender status", status, score, title,
                    explanation, recommendation, evidence, 25)


def _audit_updates():
    data, error = _powershell_json(
        "$session = New-Object -ComObject Microsoft.Update.Session; "
        "$searcher = $session.CreateUpdateSearcher(); "
        "$result = $searcher.Search(\"IsInstalled=0 and Type='Software'\"); "
        "[pscustomobject]@{ "
        "Pending=[int]$result.Updates.Count; "
        "Mandatory=[int]@($result.Updates | Where-Object IsMandatory).Count "
        "} | ConvertTo-Json -Compress",
        timeout=90,
    )
    if error or not isinstance(data, dict):
        return _unavailable("updates", "Security updates", error or "No update result returned.", 15)
    pending = int(data.get("Pending") or 0)
    mandatory = int(data.get("Mandatory") or 0)
    if pending == 0:
        status, score = "good", 100
        title = "No pending software updates were returned"
        explanation = "The Windows Update Agent returned no uninstalled software updates in this read-only search."
        recommendation = "Continue allowing Windows Update to run; this check does not replace update history or restart requirements."
    elif mandatory:
        status, score = "bad", 35
        title = f"{pending} pending update(s), including mandatory updates"
        explanation = f"Windows Update returned {pending} pending software update(s), {mandatory} marked mandatory."
        recommendation = "Review Windows Update and schedule installation when the device can restart. Do not ignore mandatory security updates."
    else:
        status, score = "warn", 70 if pending <= 5 else 55
        title = f"{pending} pending software update(s)"
        explanation = "Pending updates may include security fixes, quality updates, or other software updates."
        recommendation = "Open Windows Update, review the update names, and install them during an appropriate maintenance window."
    return _finding(
        "updates", "Security updates", status, score, title, explanation,
        recommendation, f"Pending: {pending}; mandatory: {mandatory}", 15
    )


def _audit_accounts():
    data, error = _powershell_json(
        "$path = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System'; "
        "$policy = Get-ItemProperty -Path $path -ErrorAction Stop; "
        "$admin = Get-CimInstance Win32_UserAccount -Filter "
        "\"LocalAccount=True AND Name='Administrator'\" -ErrorAction SilentlyContinue; "
        "[pscustomobject]@{ "
        "UacEnabled=([int]$policy.EnableLUA -eq 1); "
        "AdminAccountEnabled=([bool]($admin.Enabled -eq $true)); "
        "PromptBehavior=[int]$policy.ConsentPromptBehaviorAdmin "
        "} | ConvertTo-Json -Compress"
    )
    if error or not isinstance(data, dict):
        return _unavailable("accounts", "Account configuration", error or "No account policy returned.", 15)
    uac = bool(data.get("UacEnabled"))
    admin_enabled = bool(data.get("AdminAccountEnabled"))
    if uac and not admin_enabled:
        status, score = "good", 100
        title = "UAC is enabled and the built-in Administrator is disabled"
        explanation = "The local policy query found a strong baseline for elevation prompts and the built-in Administrator account."
        recommendation = "Keep using standard user accounts where practical and review local administrators periodically."
    elif uac:
        status, score = "good", 85
        title = "UAC is enabled"
        explanation = "Elevation prompts are enabled. The built-in Administrator account is also enabled or could not be distinguished from policy output."
        recommendation = "Confirm that the built-in Administrator account is intentionally enabled and has a strong password."
    else:
        status, score = "bad", 35
        title = "UAC is disabled or was not confirmed"
        explanation = "The Windows policy query did not confirm User Account Control as enabled."
        recommendation = "Review User Account Control settings. Do not lower prompts simply to make an application work."
    return _finding(
        "accounts", "Account configuration", status, score, title,
        explanation, recommendation,
        f"UAC: {'enabled' if uac else 'not enabled'}; built-in Administrator: "
        f"{'enabled' if admin_enabled else 'disabled or not returned'}",
        15,
    )


def _audit_exposure():
    data, error = _powershell_json(
        "$profiles = @(Get-NetFirewallProfile -ErrorAction Stop); "
        "$listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue); "
        "$public = @(Get-NetConnectionProfile -ErrorAction SilentlyContinue | "
        "Where-Object NetworkCategory -eq 'Public'); "
        "$nonLoopback = @($listeners | Where-Object { "
        "$_.LocalAddress -notin @('127.0.0.1','::1') }); "
        "[pscustomobject]@{ "
        "FirewallEnabled=[bool](@($profiles | Where-Object Enabled).Count -eq $profiles.Count); "
        "Listening=[int]$listeners.Count; "
        "NonLoopbackListening=[int]$nonLoopback.Count; "
        "PublicNetwork=[bool]($public.Count -gt 0) "
        "} | ConvertTo-Json -Compress"
    )
    if error or not isinstance(data, dict):
        return _unavailable("exposure", "Network exposure", error or "No exposure result returned.", 10)
    firewall = bool(data.get("FirewallEnabled"))
    public = bool(data.get("PublicNetwork"))
    listeners = int(data.get("NonLoopbackListening") or 0)
    if not firewall:
        status, score = "bad", 25
        title = "Network exposure needs review"
        explanation = "The firewall was not confirmed enabled while reviewing listening TCP endpoints."
        recommendation = "Review firewall profiles and listening services before using public or untrusted networks."
    elif public and listeners:
        status, score = "warn", 60
        title = "Listening services are present on a public network"
        explanation = f"Windows reported {listeners} non-loopback listening endpoint(s) while a Public network profile is active. Listening is not automatically a vulnerability."
        recommendation = "Identify each listening service and allow only the inbound rules you recognize; do not close ports blindly."
    elif listeners:
        status, score = "warn", 78
        title = "Listening services should be understood"
        explanation = f"Windows reported {listeners} non-loopback listening endpoint(s). The audit does not label them malicious."
        recommendation = "Review services and firewall rules for anything you do not recognize, especially before changing network category."
    else:
        status, score = "good", 100
        title = "No non-loopback listeners were returned"
        explanation = "The firewall was enabled and this snapshot found no non-loopback TCP listeners."
        recommendation = "No action is indicated by this check. Re-run after installing a server, remote-access tool, or similar service."
    return _finding(
        "exposure", "Network exposure", status, score, title, explanation,
        recommendation,
        f"Firewall all profiles enabled: {firewall}; non-loopback listeners: "
        f"{listeners}; public network: {public}",
        10,
    )


def _audit_privacy():
    data, error = _powershell_json(
        "$base = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore'; "
        "function Read-Consent($name) { "
        "$item = Get-ItemProperty -Path (Join-Path $base $name) -Name Value -ErrorAction SilentlyContinue; "
        "if ($null -eq $item) { return 'Not returned' }; return [string]$item.Value "
        "}; "
        "[pscustomobject]@{ Location=Read-Consent 'location'; "
        "Camera=Read-Consent 'webcam'; Microphone=Read-Consent 'microphone' } | "
        "ConvertTo-Json -Compress"
    )
    if error or not isinstance(data, dict):
        return _unavailable("privacy", "Privacy settings", error or "No privacy result returned.", 10)
    values = [str(data.get(key) or "Not returned") for key in ("Location", "Camera", "Microphone")]
    returned = [value for value in values if value.lower() != "not returned"]
    if not returned:
        return _unavailable("privacy", "Privacy settings", "Windows did not return the selected consent values.", 10)
    broad = [value for value in returned if value.lower() == "allow"]
    if broad:
        status, score = "warn", 75
        title = "Some privacy capabilities are broadly allowed"
        explanation = "At least one selected capability is allowed at the user consent-store level; this does not identify which apps currently use it."
        recommendation = "Review per-app permissions for location, camera, and microphone in Windows Privacy settings."
    else:
        status, score = "good", 95
        title = "No broad privacy capability access was returned"
        explanation = "The selected user consent values were not broadly set to Allow."
        recommendation = "Review per-app permissions if an application unexpectedly requests access."
    evidence = " • ".join(
        f"{label}: {data.get(key) or 'Not returned'}"
        for label, key in (("Location", "Location"), ("Camera", "Camera"), ("Microphone", "Microphone"))
    )
    return _finding("privacy", "Privacy settings", status, score, title,
                    explanation, recommendation, evidence, 10)


def run_security_audit():
    """Run the complete defensive audit without changing the PC."""
    if not IS_WINDOWS:
        findings = [
            _unavailable(key, label, "TechDrive Security Center requires Windows.", weight)
            for key, label, weight in (
                ("firewall", "Windows Firewall", 25),
                ("defender", "Defender status", 25),
                ("updates", "Security updates", 15),
                ("accounts", "Account configuration", 15),
                ("exposure", "Network exposure", 10),
                ("privacy", "Privacy settings", 10),
            )
        ]
        return {
            "timestamp": _datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "status": "WINDOWS ONLY",
            "score": None,
            "limited": True,
            "findings": findings,
        }

    findings = [
        _audit_firewall(),
        _audit_defender(),
        _audit_updates(),
        _audit_accounts(),
        _audit_exposure(),
        _audit_privacy(),
    ]
    measured = [item for item in findings if item["score"] is not None]
    weight_total = sum(item["weight"] for item in measured)
    score = (
        round(sum(item["score"] * item["weight"] for item in measured) / weight_total)
        if weight_total else None
    )
    status = (
        "SECURE" if score is not None and score >= 85
        else "REVIEW NEEDED" if score is not None and score >= 60
        else "AT RISK" if score is not None
        else "UNAVAILABLE"
    )
    return {
        "timestamp": _datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "status": status,
        "score": score,
        "limited": score is None,
        "findings": findings,
    }


def _status_color(status):
    return {
        "good": fl.GOOD,
        "warn": fl.WARN,
        "bad": fl.BAD,
        "info": "#7eb8ff",
    }.get(status, "#7eb8ff")


class SecurityCenterPage(tk.Frame):
    """Security posture audit with explanatory findings and local history."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._running = False
        _, self.content = make_scrollable(self, self.theme["BG"])
        self._build()

    def _build(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  SECURITY CENTER",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        title_row = tk.Frame(header, bg=self.theme["BG"])
        title_row.pack(fill="x", pady=(4, 2))
        tk.Label(title_row, text="Security Center", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(side="left")
        tk.Label(
            header,
            text="A defensive Windows security audit that explains findings "
                 "instead of pretending every issue can be fixed automatically.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=850, justify="left",
        ).pack(anchor="w")

        hero = GlassCard(root, self.theme, aero=self.aero, gradient=True,
                         accent=self.theme["ACCENT2"])
        hero.pack(fill="x", padx=24, pady=(8, 14))
        self.hero_body = hero.body
        top = tk.Frame(hero.body, bg=hero.fill)
        top.pack(fill="x", padx=18, pady=(16, 16))
        self.ring = HealthRing(top, self.theme, size=132, aero=self.aero,
                               bg=hero.fill)
        self.ring.pack(side="left")
        copy = tk.Frame(top, bg=hero.fill)
        copy.pack(side="left", fill="x", expand=True, padx=(18, 12))
        self.hero_status = tk.StringVar(value="READY")
        tk.Label(copy, textvariable=self.hero_status, bg=hero.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TITLE()).pack(anchor="w")
        self.hero_detail = tk.StringVar(
            value="Run a read-only audit to inspect Windows security posture."
        )
        tk.Label(copy, textvariable=self.hero_detail, bg=hero.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=560, justify="left").pack(anchor="w", pady=(4, 0))
        self.run_button = FluentButton(
            top, "RUN SECURITY AUDIT", command=self.start_audit,
            theme=self.theme, aero=self.aero, kind="accent", icon="◆",
            width=205, height=42, backdrop=hero.fill,
        )
        self.run_button.pack(side="right")

        self.summary = tk.Frame(root, bg=self.theme["BG"])
        self.summary.pack(fill="x", padx=24, pady=(0, 14))
        self.body = tk.Frame(root, bg=self.theme["BG"])
        self.body.pack(fill="x", padx=24, pady=(0, 14))

        latest = db.get_security_audit_history(limit=1)
        report = latest[0].get("report") if latest else None
        if not isinstance(report, dict) or not report.get("findings"):
            report = None
        self._render_report(report)

    def start_audit(self):
        if self._running:
            return
        self._running = True
        self.run_button.configure(state="disabled")
        self.hero_status.set("AUDITING…")
        self.hero_detail.set("Reading firewall, Defender, updates, account, exposure, and privacy posture.")
        self.app._run_bg(run_security_audit, self._finish_audit)

    def _finish_audit(self, report):
        self._running = False
        self.run_button.configure(state="normal")
        if hasattr(report, "message"):
            self.hero_status.set("FAILED SAFELY")
            self.hero_detail.set(str(report))
            return
        try:
            db.add_security_audit(report)
        except Exception:
            pass
        self._render_report(report)

    def _render_report(self, report):
        for child in self.summary.winfo_children():
            child.destroy()
        for child in self.body.winfo_children():
            child.destroy()
        if report is None:
            self.hero_status.set("READY")
            self.hero_detail.set("Run a read-only audit to inspect Windows security posture.")
            self.ring.set_score(0, "READY")
            self._render_empty()
            return
        score = report.get("score")
        score_text = f"{score}/100" if score is not None else "—"
        self.hero_status.set(report.get("status", "UNAVAILABLE"))
        self.hero_detail.set(
            f"Last checked {report.get('timestamp', 'unknown')} • "
            "No security settings were changed."
        )
        self.ring.set_score(score or 0, score_text)
        self._render_summary_cards(report)
        self._render_findings(report)

    def _render_empty(self):
        card = GlassCard(self.body, self.theme, aero=self.aero,
                         accent=self.theme["ACCENT2"])
        card.pack(fill="x", pady=(0, 14))
        tk.Label(card.body, text="NO AUDIT SNAPSHOT", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(
            card.body,
            text="The first audit will read current Windows settings and "
                 "explain what deserves review. It will not make changes.",
            bg=card.fill, fg=self.theme["FG"], font=fl.F_SUBTITLE(),
            wraplength=820, justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 16))

    def _render_summary_cards(self, report):
        findings = report.get("findings", [])
        for column in range(3):
            self.summary.grid_columnconfigure(column, weight=1, uniform="security_summary")
        for index, finding in enumerate(findings):
            color = _status_color(finding.get("status"))
            card = GlassCard(self.summary, self.theme, aero=self.aero,
                             accent=color)
            card.grid(
                row=index // 3,
                column=index % 3,
                sticky="nsew",
                padx=(0 if index % 3 == 0 else 6, 6 if index % 3 < 2 else 0),
                pady=(0, 8),
            )
            body = card.body
            top = tk.Frame(body, bg=card.fill)
            top.pack(fill="x", padx=14, pady=(13, 2))
            tk.Label(top, text=finding["label"].upper(), bg=card.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY()).pack(side="left")
            tk.Label(top, text="✓" if finding["status"] == "good"
                     else "⚠" if finding["status"] == "warn"
                     else "✕" if finding["status"] == "bad" else "·",
                     bg=card.fill, fg=color, font=fl.F_CARD_TITLE()).pack(side="right")
            tk.Label(body, text=finding["title"], bg=card.fill,
                     fg=self.theme["FG"], font=fl.F_BODY(),
                     wraplength=240, justify="left").pack(
                         anchor="w", padx=14, pady=(3, 2))
            tk.Label(body, text=finding["status"].upper(), bg=card.fill,
                     fg=color, font=fl.F_TINY()).pack(
                         anchor="w", padx=14, pady=(0, 13))

    def _render_findings(self, report):
        findings_card = GlassCard(self.body, self.theme, aero=self.aero,
                                  accent=self.theme["ACCENT"])
        findings_card.pack(fill="x", pady=(0, 14))
        tk.Label(findings_card.body, text="EXPLAINED FINDINGS", bg=findings_card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(findings_card.body, text="What TechDrive observed and what to review",
                 bg=findings_card.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE()).pack(anchor="w", padx=18, pady=(0, 10))
        for index, finding in enumerate(report.get("findings", [])):
            self._render_finding(findings_card, finding, index)
        tk.Label(
            findings_card.body,
            text="TechDrive reports posture; it does not replace Windows "
                 "Security, managed policy, or an administrator's review.",
            bg=findings_card.fill, fg=self.theme["MUTED"], font=fl.F_TINY(),
            wraplength=820, justify="left",
        ).pack(anchor="w", padx=18, pady=(8, 16))

        history_card = GlassCard(self.body, self.theme, aero=self.aero,
                                accent=self.theme["ACCENT2"])
        history_card.pack(fill="x")
        tk.Label(history_card.body, text="AUDIT HISTORY", bg=history_card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(history_card.body, text="Recent Security Center snapshots",
                 bg=history_card.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE()).pack(anchor="w", padx=18, pady=(0, 8))
        history = db.get_security_audit_history(limit=6)
        if not history:
            tk.Label(history_card.body, text="No Security Center audits saved yet.",
                     bg=history_card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
            return
        for entry in history:
            score = entry.get("score")
            report_score = (entry.get("report") or {}).get("score")
            shown_score = (
                f"{report_score}/100" if report_score is not None
                else "—"
            )
            color = fl.GOOD if score and score >= 85 else fl.WARN if score and score >= 60 else fl.MUTED
            when = _datetime.datetime.fromtimestamp(
                float(entry.get("occurred_at", 0))
            ).strftime("%b %d, %H:%M")
            row = tk.Frame(history_card.body, bg=history_card.fill)
            row.pack(fill="x", padx=18, pady=3)
            tk.Label(row, text=when, bg=history_card.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY()).pack(side="left")
            tk.Label(row, text=f"{shown_score}  {entry.get('summary', '')}",
                     bg=history_card.fill, fg=color,
                     font=fl.F_CARD_TITLE()).pack(side="right")
        tk.Frame(history_card.body, bg=history_card.fill, height=10).pack()

    def _render_finding(self, card, finding, index):
        color = _status_color(finding.get("status"))
        row = tk.Frame(card.body, bg=card.fill)
        row.pack(fill="x", padx=18, pady=(3, 8 if index < 5 else 0))
        rail = tk.Frame(row, bg=card.fill, width=8)
        rail.pack(side="left", fill="y", padx=(0, 12))
        rail.pack_propagate(False)
        tk.Frame(rail, bg=color, width=3).pack(fill="y", padx=2)
        detail = tk.Frame(row, bg=card.fill)
        detail.pack(side="left", fill="x", expand=True)
        top = tk.Frame(detail, bg=card.fill)
        top.pack(fill="x")
        tk.Label(top, text=finding["title"], bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_CARD_TITLE()).pack(side="left")
        tk.Label(top, text=finding["status"].upper(), bg=card.fill,
                 fg=color, font=fl.F_TINY()).pack(side="right")
        tk.Label(detail, text=finding["explanation"], bg=card.fill,
                 fg=self.theme["TEXT_FG"], font=fl.F_SMALL(),
                 wraplength=800, justify="left").pack(anchor="w", pady=(3, 0))
        tk.Label(detail, text=f"REVIEW: {finding['recommendation']}",
                 bg=card.fill, fg=self.theme["MUTED"], font=fl.F_TINY(),
                 wraplength=800, justify="left").pack(anchor="w", pady=(3, 0))
        if finding.get("evidence"):
            tk.Label(detail, text=f"Evidence: {finding['evidence']}",
                     bg=card.fill, fg=self.theme["MUTED"], font=fl.F_TINY(),
                     wraplength=800, justify="left").pack(anchor="w", pady=(2, 0))