#!/usr/bin/env python3
"""
gui/live_chart.py - Real-time line charts + a background sampling loop.
=======================================================================
Pure Tkinter Canvas (no matplotlib / no extra dependency). Designed for
the TechDrive tool panels: create a LiveChart, then start a LiveSampler
that calls a plain data-gathering function on a worker thread and hands
the result back on the UI thread.

    chart = LiveChart(frame, app.theme, [("CPU", "#00e5ff")], y_suffix="%")
    def sample():
        return {"CPU": psutil.cpu_percent()}
    LiveSampler(app, frame, 1000, sample, chart.push).start()

The sampler stops itself as soon as the panel's frame is destroyed (tab
closed), so nothing keeps polling in the background.
"""

import queue
import threading
import time
import tkinter as tk

from shared import database as db
from gui.theme import FONT_UI, FONT_UI_BOLD

try:
    import psutil
except ImportError:
    psutil = None

_METRIC_CACHE = {"at": 0.0, "cpu": 0.0, "ram": 0.0}


def _system_metrics():
    now = time.monotonic()
    if now - _METRIC_CACHE["at"] > 0.8:
        try:
            if psutil is not None:
                _METRIC_CACHE["cpu"] = float(psutil.cpu_percent(interval=None))
                _METRIC_CACHE["ram"] = float(psutil.virtual_memory().percent)
        except Exception:
            pass
        _METRIC_CACHE["at"] = now
    return _METRIC_CACHE["cpu"], _METRIC_CACHE["ram"]


class LiveChart(tk.Frame):
    """Scrolling multi-series line chart.

    series      : list of (name, color)
    history     : how many samples are kept on screen
    y_max       : fixed upper bound, or None to auto-scale
    y_min       : fixed lower bound (default 0)
    y_suffix    : unit drawn on the axis labels / legend ("%", "C", "MB/s")
    """

    def __init__(self, parent, theme, series, history=120, y_max=100,
                 y_min=0, y_suffix="%", height=190, title=None):
        super().__init__(parent, bg=theme["CARD_BG"], highlightthickness=1,
                         highlightbackground=theme["CARD_BORDER"])
        self.base_theme = dict(theme)
        self.theme = dict(theme)
        self.base_series = list(series)
        self.series = list(series)
        self.skin = "standard"
        self.history = history
        self.y_max_fixed = y_max
        self.y_min = y_min
        self.y_suffix = y_suffix
        self.data = {name: [] for name, _ in self.series}
        self._last = {}

        if title:
            tk.Label(self, text=title, bg=theme["CARD_BG"], fg=theme["FG"],
                     font=FONT_UI_BOLD).pack(anchor="w", padx=10, pady=(8, 0))

        self.legend = tk.Frame(self, bg=theme["CARD_BG"])
        self.legend.pack(fill="x", padx=10, pady=(6, 2))
        self.legend_labels = {}
        self.legend_markers = {}
        for name, color in self.series:
            cell = tk.Frame(self.legend, bg=theme["CARD_BG"])
            cell.pack(side="left", padx=(0, 14))
            marker = tk.Canvas(cell, width=10, height=10, bg=color, highlightthickness=0)
            marker.pack(side="left", pady=1)
            self.legend_markers[name] = marker
            lbl = tk.Label(cell, text=f"{name}: --", bg=theme["CARD_BG"],
                           fg=theme["FG"], font=FONT_UI)
            lbl.pack(side="left", padx=(5, 0))
            self.legend_labels[name] = lbl

        self.equalizer = tk.Canvas(self.legend, width=104, height=34,
                                   bg=theme["CARD_BG"], highlightthickness=0)
        self.equalizer.pack(side="right", padx=(4, 0))
        self.canvas = tk.Canvas(self, bg=theme["SURFACE"], height=height,
                                highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=(2, 10))
        self.canvas.bind("<Configure>", lambda e: self._redraw())
        self.set_visual_skin(db.get_setting("monitor_visual_skin", "standard"))

    def set_visual_skin(self, skin):
        if skin not in ("standard", "crt", "winamp"):
            skin = "standard"
        self.skin = skin
        palette = dict(self.base_theme)
        if skin == "crt":
            palette.update({
                "CARD_BG": "#031009", "SURFACE": "#020803",
                "CARD_BORDER": "#17542a", "FG": "#9bffad",
                "MUTED": "#4db568", "ACCENT": "#7dff91",
            })
        elif skin == "winamp":
            palette.update({
                "CARD_BG": "#07101b", "SURFACE": "#030811",
                "CARD_BORDER": "#28445f", "FG": "#d6ecff",
                "MUTED": "#8aa8bd", "ACCENT": "#45ff70",
            })
        self.theme = palette
        self.series = []
        for index, (name, original_color) in enumerate(self.base_series):
            color = original_color
            if skin == "crt":
                color = ("#8dff9f", "#51da74", "#b4ffb9")[index % 3]
            elif skin == "winamp":
                lowered = name.lower()
                if any(part in lowered for part in ("ram", "memory", "swap")):
                    color = "#d8ff38"
                elif any(part in lowered for part in ("temp", "write", "upload")):
                    color = "#ff9b38"
                else:
                    color = "#39ff65"
            self.series.append((name, color))

        self.configure(bg=palette["CARD_BG"],
                       highlightbackground=palette["CARD_BORDER"])
        self.legend.configure(bg=palette["CARD_BG"])
        for child in self.legend.winfo_children():
            try:
                child.configure(bg=palette["CARD_BG"])
            except tk.TclError:
                pass
        self.equalizer.configure(bg=palette["CARD_BG"])
        self.canvas.configure(bg=palette["SURFACE"])
        for name, color in self.series:
            self.legend_markers[name].configure(bg=color)
            self.legend_labels[name].configure(bg=palette["CARD_BG"],
                                               fg=palette["FG"])
        if skin == "winamp":
            self.equalizer.pack(side="right", padx=(4, 0))
        else:
            self.equalizer.pack_forget()
        self._redraw()

    def _draw_equalizer(self):
        c = self.equalizer
        if self.skin != "winamp" or not c.winfo_exists():
            return
        c.delete("all")
        cpu, ram = _system_metrics()
        w, h = 104, 34
        c.create_text(18, 4, text="CPU", fill="#8aa8bd",
                      font=("Segoe UI", 6, "bold"))
        c.create_text(72, 4, text="RAM", fill="#8aa8bd",
                      font=("Segoe UI", 6, "bold"))
        for group, value in enumerate((cpu, ram)):
            start_x = 5 + group * 53
            for bar in range(5):
                bar_level = max(0.04, min(1.0, value / 100.0
                                          * (0.72 + 0.28 * ((bar + 2) % 5) / 4)))
                bar_height = bar_level * 21
                color = "#39ff65" if bar_level < 0.65 else (
                    "#d8ff38" if bar_level < 0.88 else "#ff9b38")
                x1 = start_x + bar * 8
                c.create_rectangle(x1, h - 2 - bar_height, x1 + 5, h - 2,
                                   fill=color, outline="")

    # -- data ---------------------------------------------------------
    def push(self, values):
        """values: {series_name: float|None}. None keeps the line but marks
        a gap (sensor temporarily unavailable) instead of drawing a fake 0."""
        for name, _ in self.series:
            v = values.get(name)
            buf = self.data[name]
            buf.append(v)
            if len(buf) > self.history:
                del buf[0:len(buf) - self.history]
            if v is not None:
                self._last[name] = v
        self._draw_equalizer()
        self._redraw()

    def reset(self):
        for name in self.data:
            self.data[name] = []
        self._last = {}
        self._redraw()

    # -- drawing ------------------------------------------------------
    def _bounds(self):
        vals = [v for buf in self.data.values() for v in buf if v is not None]
        if self.y_max_fixed is not None:
            return self.y_min, self.y_max_fixed
        if not vals:
            return self.y_min, 10.0
        hi = max(vals)
        lo = min(min(vals), self.y_min)
        if hi - lo < 1e-6:
            hi = lo + 1.0
        pad = (hi - lo) * 0.15
        return lo, hi + pad

    def _redraw(self):
        c = self.canvas
        if not c.winfo_exists():
            return
        c.delete("all")
        w = c.winfo_width() or 400
        h = c.winfo_height() or 180
        pad_l, pad_r, pad_t, pad_b = 52, 8, 8, 16
        plot_w = max(10, w - pad_l - pad_r)
        plot_h = max(10, h - pad_t - pad_b)
        lo, hi = self._bounds()
        grid = self.theme["CARD_BORDER"]
        muted = self.theme["MUTED"]

        for i in range(5):
            y = pad_t + plot_h * i / 4
            c.create_line(pad_l, y, pad_l + plot_w, y, fill=grid)
            val = hi - (hi - lo) * i / 4
            label = f"{val:.0f}{self.y_suffix}" if abs(val) >= 10 else f"{val:.1f}{self.y_suffix}"
            c.create_text(pad_l - 6, y, text=label, anchor="e", fill=muted, font=FONT_UI)
        for i in range(1, 6):
            x = pad_l + plot_w * i / 6
            c.create_line(x, pad_t, x, pad_t + plot_h, fill=grid)

        if self.skin == "crt":
            for y in range(pad_t + 2, pad_t + plot_h, 4):
                c.create_line(pad_l, y, pad_l + plot_w, y, fill="#06140a")

        def to_xy(idx, val, n):
            x = pad_l + (plot_w * idx / max(1, self.history - 1))
            frac = (val - lo) / (hi - lo) if hi > lo else 0
            y = pad_t + plot_h * (1 - min(1.0, max(0.0, frac)))
            return x, y

        for name, color in self.series:
            buf = self.data[name]
            if not buf:
                continue

            def draw_segment(coords):
                if len(coords) <= 3:
                    return
                if self.skin in ("crt", "winamp"):
                    halo = "#0a3a17" if self.skin == "crt" else "#123a20"
                    c.create_line(coords, fill=halo, width=6, smooth=True)
                c.create_line(coords, fill=color, width=2, smooth=True)

            offset = self.history - len(buf)
            segment = []
            for i, v in enumerate(buf):
                if v is None:
                    draw_segment(segment)
                    segment = []
                    continue
                segment.extend(to_xy(offset + i, v, len(buf)))
            if len(segment) == 2:
                c.create_oval(segment[0] - 2, segment[1] - 2,
                              segment[0] + 2, segment[1] + 2, fill=color, outline=color)
            else:
                draw_segment(segment)
            last = self._last.get(name)
            if last is not None:
                suffix = self.y_suffix
                text = f"{name}: {last:.1f}{suffix}" if abs(last) < 100 else f"{name}: {last:.0f}{suffix}"
                self.legend_labels[name].config(text=text)
            else:
                self.legend_labels[name].config(text=f"{name}: n/a")


class LiveSampler:
    """Calls `sample()` on a worker thread every `interval_ms` and passes
    the result to `on_sample(result)` on the Tk main thread. Dies with the
    widget it's bound to."""

    def __init__(self, app, widget, interval_ms, sample, on_sample):
        self.app = app
        self.widget = widget
        self.interval = interval_ms
        self.sample = sample
        self.on_sample = on_sample
        self.paused = False
        self._q = queue.Queue()
        self._stop = threading.Event()
        self._thread = None

    def start(self):
        if self._thread is not None:
            return self
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self.app.after(120, self._drain)
        try:
            self.widget.bind("<Destroy>", self._on_destroy, add="+")
        except Exception:
            pass
        return self

    def stop(self):
        self._stop.set()

    def toggle_pause(self):
        self.paused = not self.paused
        return self.paused

    def _on_destroy(self, event):
        if event.widget is self.widget:
            self.stop()

    def _loop(self):
        while not self._stop.is_set():
            if not self.paused:
                try:
                    self._q.put(self.sample())
                except Exception as e:
                    self._q.put({"__error__": f"{type(e).__name__}: {e}"})
            self._stop.wait(self.interval / 1000.0)

    def _drain(self):
        if self._stop.is_set():
            return
        try:
            if not self.widget.winfo_exists():
                self.stop()
                return
        except Exception:
            self.stop()
            return
        latest = None
        while True:
            try:
                latest = self._q.get_nowait()
            except queue.Empty:
                break
        if latest is not None:
            try:
                self.on_sample(latest)
            except Exception:
                pass
        self.app.after(150, self._drain)
