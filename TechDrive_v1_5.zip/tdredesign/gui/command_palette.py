#!/usr/bin/env python3
"""Spotlight-grade Command Palette 2.0 for TechDrive.

Ctrl+K opens a springy sheet that searches:
  • Tools (catalogue)
  • Actions (dashboard, settings, control center, focus modes, scans)
  • Recent tools
  • Theme / focus switches
"""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.motion import tween, spring, sheet_present
from gui.widgets import round_rect

try:
    from gui.search import ToolSearchIndex
except Exception:
    ToolSearchIndex = None


class CommandPalette(tk.Toplevel):
    def __init__(self, app, catalogue):
        super().__init__(app)
        self.app = app
        self.theme = app.theme
        self.catalogue = catalogue or []
        self.index = ToolSearchIndex(catalogue) if ToolSearchIndex else None
        self.rows = []  # list of dicts
        self.selected = 0
        self.title("Command Palette")
        self.overrideredirect(True)
        self.configure(bg=self.theme.get("STROKE", "#333"))
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.geometry(self._geometry())
        self.transient(app)
        self._build()
        self.bind("<Escape>", lambda e: self.close())
        self.bind("<Down>", lambda e: self.move(1))
        self.bind("<Up>", lambda e: self.move(-1))
        self.bind("<Return>", lambda e: self.launch())
        self.bind("<Control-k>", lambda e: self.close())
        self.bind("<Control-K>", lambda e: self.close())
        self.after(10, self._focus)
        try:
            from gui.motion import sheet_present
            sheet_present(self, duration_ms=320, from_y=24)
        except Exception:
            pass
        try:
            from gui.acrylic import apply_acrylic
            apply_acrylic(self, opacity=170)
        except Exception:
            pass
        try:
            from gui import haptics
            haptics.sheet_open()
        except Exception:
            pass
        # fade-ish entrance
        # Entrance handled by sheet_present
        pass

    def _fade_in(self):
        steps = [0.2, 0.45, 0.7, 0.9, 1.0]

        def go(i=0):
            if i >= len(steps):
                return
            try:
                self.attributes("-alpha", steps[i])
            except tk.TclError:
                return
            self.after(20, lambda: go(i + 1))

        go()

    def _geometry(self):
        w, h = 720, 480
        try:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        except Exception:
            sw, sh = 1280, 800
        x = max(8, (sw - w) // 2)
        y = max(48, int(sh * 0.12))
        return f"{w}x{h}+{x}+{y}"

    def _focus(self):
        try:
            self.entry.focus_set()
            self.entry.selection_range(0, "end")
        except Exception:
            pass
        self.refresh("")

    def _build(self):
        th = self.theme
        outer = tk.Frame(self, bg=th.get("LAYER_1", th["BG"]), bd=0)
        outer.pack(fill="both", expand=True, padx=2, pady=2)

        tk.Label(
            outer, text="SEARCH ANYTHING", bg=outer["bg"], fg=th["MUTED"],
            font=fl.font(8, "bold") if hasattr(fl, "font") else ("Segoe UI", 8, "bold"),
            anchor="w",
        ).pack(fill="x", padx=16, pady=(14, 6))

        row = tk.Frame(outer, bg=outer["bg"])
        row.pack(fill="x", padx=12)
        self.entry = tk.Entry(
            row, bg=th.get("LAYER_2", th["CARD_BG"]), fg=th["FG"],
            insertbackground=th["FG"], relief="flat", bd=0,
            font=fl.F_TITLE3() if hasattr(fl, "F_TITLE3") else fl.F_SUBTITLE(),
        )
        self.entry.pack(fill="x", ipady=10)
        self.entry.bind("<KeyRelease>", lambda e: self.refresh(self.entry.get()))

        self.listbox = tk.Listbox(
            outer, bg=th.get("LAYER_1", th["BG"]), fg=th["FG"],
            selectbackground=th.get("LAYER_3", th["ACCENT"]),
            selectforeground=th.get("ON_ACCENT", th["FG"]),
            relief="flat", bd=0, highlightthickness=0, activestyle="none",
            font=fl.F_BODY(),
        )
        self.listbox.pack(fill="both", expand=True, padx=12, pady=(10, 8))
        self.listbox.bind("<ButtonRelease-1>", lambda e: self.launch())
        self.listbox.bind("<Double-Button-1>", lambda e: self.launch())

        tk.Label(
            outer,
            text="↑↓ navigate   ·   Enter run   ·   Esc close   ·   type to filter tools, actions, focus…",
            bg=outer["bg"], fg=th["MUTED"],
            font=fl.F_TINY() if hasattr(fl, "F_TINY") else ("Segoe UI", 8),
        ).pack(pady=(0, 12))

    def _static_actions(self):
        """Built-in actions always available."""
        app = self.app
        actions = [
            ("action", "Open Dashboard", "Go to dashboard",
             lambda: getattr(app, "show_dashboard", lambda: None)()),
            ("action", "All Tools", "Browse full tool gallery",
             lambda: getattr(app, "open_all_tools_tab", lambda: None)()),
            ("action", "Control Center", "Quick toggles & appearance",
             lambda: getattr(app, "control_center", None) and app.control_center.show()),
            ("action", "Settings", "Preferences",
             lambda: getattr(app, "open_settings_tab", lambda: None)()),
            ("action", "Notification Center", "Alerts and history",
             lambda: getattr(app, "open_notifications", lambda: None)()),
            ("action", "Quick Scan", "Run quick system scan",
             lambda: getattr(app, "run_quick_scan", lambda: None)()),
            ("action", "Health Center", "System health overview",
             lambda: getattr(app, "open_health_center_tab",
                             getattr(app, "show_dashboard", lambda: None))()),
            ("action", "Toggle Theme", "Switch dark / light",
             lambda: getattr(app, "toggle_theme", lambda: None)()),
            ("action", "OLED Pure Black", "True black theme",
             lambda: getattr(app, "apply_theme_choice", lambda *_: None)("oled")),
            ("action", "Toggle Aero Glass", "Windows glass effect",
             lambda: getattr(app, "toggle_aero_glass", lambda: None)()),
            ("action", "Stage Manager", "Pin up to 3 tools side by side",
             lambda: getattr(app, "open_stage_manager", lambda: None)()),
            ("action", "Mission Control", "Overview of open tabs",
             lambda: getattr(app, "open_mission_control_view", lambda: None)()),
            ("action", "Snap Layouts", "Stage snap templates",
             lambda: __import__("gui.snap_layouts", fromlist=["show_snap_layouts"]).show_snap_layouts(app)),
            ("action", "Larger Text", "Increase UI font scale",
             lambda: __import__("gui.accessibility", fromlist=["larger_text"]).larger_text(app)),
            ("action", "Smaller Text", "Decrease UI font scale",
             lambda: __import__("gui.accessibility", fromlist=["smaller_text"]).smaller_text(app)),
            ("action", "Genius Tip", "Offline contextual advice",
             lambda: getattr(app, "show_genius_tip", lambda: None)("default")),
        ]
        # Focus modes
        try:
            from gui.focus_modes import MODES, set_mode
            for mid, cfg in MODES.items():
                actions.append((
                    "focus",
                    f"Focus: {cfg['label']}",
                    cfg.get("desc", ""),
                    lambda m=mid: set_mode(m, app),
                ))
        except Exception:
            pass
        return actions

    def _recent_rows(self):
        rows = []
        try:
            from gui import tool_resume
            for sess in tool_resume.last_sessions(6):
                cat, tool = sess.get("category"), sess.get("tool")
                if cat and tool:
                    rows.append((
                        "recent", tool, f"Continue · {cat}",
                        lambda c=cat, t=tool: self.app.open_tool(c, t),
                    ))
        except Exception:
            pass
        try:
            recent = self.app.get_recent_tools(8) if hasattr(self.app, "get_recent_tools") else []
            seen = {r[1] for r in rows}
            for cat, tool in recent:
                if tool in seen:
                    continue
                rows.append((
                    "recent", tool, f"Recent · {cat}",
                    lambda c=cat, t=tool: self.app.open_tool(c, t),
                ))
        except Exception:
            pass
        return rows

    def refresh(self, query):
        q = (query or "").strip().lower()
        rows = []

        # Actions + focus + recent
        for kind, title, subtitle, cmd in self._static_actions() + self._recent_rows():
            blob = f"{title} {subtitle}".lower()
            if not q or q in blob:
                rows.append({
                    "kind": kind,
                    "title": title,
                    "subtitle": subtitle,
                    "cmd": cmd,
                })

        # Tools from catalogue index
        if self.index is not None:
            try:
                matches = self.index.search(query or "")[:60]
                for cat, _icon, tool, _spans in matches:
                    rows.append({
                        "kind": "tool",
                        "title": tool,
                        "subtitle": cat,
                        "cmd": lambda c=cat, t=tool: self.app.open_tool(c, t),
                    })
            except Exception:
                pass
        else:
            # Fallback: scan catalogue
            for cat, _icon, tools in self.catalogue:
                for tool in tools:
                    if not q or q in tool.lower() or q in cat.lower():
                        rows.append({
                            "kind": "tool",
                            "title": tool,
                            "subtitle": cat,
                            "cmd": lambda c=cat, t=tool: self.app.open_tool(c, t),
                        })

        # Prefer actions when query empty
        if not q:
            actions = [r for r in rows if r["kind"] in ("action", "focus")]
            recent = [r for r in rows if r["kind"] == "recent"]
            tools = [r for r in rows if r["kind"] == "tool"][:25]
            rows = actions[:12] + recent[:6] + tools

        self.rows = rows[:80]
        self.listbox.delete(0, "end")
        for r in self.rows:
            prefix = {
                "action": "⚡",
                "focus": "◎",
                "recent": "↺",
                "tool": "▸",
            }.get(r["kind"], "·")
            self.listbox.insert("end", f"  {prefix}  {r['title']}    ·    {r['subtitle']}")
        self.selected = 0
        if self.rows:
            self.listbox.selection_set(0)
            self.listbox.activate(0)

    def move(self, delta):
        if not self.rows:
            return "break"
        self.selected = (self.selected + delta) % len(self.rows)
        self.listbox.selection_clear(0, "end")
        self.listbox.selection_set(self.selected)
        self.listbox.activate(self.selected)
        self.listbox.see(self.selected)
        return "break"

    def launch(self):
        if not self.rows:
            return "break"
        row = self.rows[self.selected]
        self.close()
        try:
            cmd = row.get("cmd")
            if callable(cmd):
                cmd()
        except Exception:
            pass
        return "break"

    def close(self):
        try:
            self.destroy()
        except tk.TclError:
            pass


def toggle(app):
    existing = getattr(app, "_command_palette", None)
    try:
        if existing is not None and existing.winfo_exists():
            existing.close()
            app._command_palette = None
            return "break"
    except tk.TclError:
        pass
    try:
        from techdrive import CATALOGUE
    except Exception:
        CATALOGUE = getattr(app, "catalogue", None) or []
        if not CATALOGUE:
            try:
                CATALOGUE = app.topbar.catalogue if hasattr(app, "topbar") else []
            except Exception:
                CATALOGUE = []
    win = CommandPalette(app, CATALOGUE)
    app._command_palette = win
    return "break"
