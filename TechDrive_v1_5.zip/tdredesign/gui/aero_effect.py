#!/usr/bin/env python3
r"""
gui/aero_effect.py - Aero Glass Effect
=========================================
A real, visible translucent "frosted glass" window backdrop on Windows,
tuned to actually look like Windows 7's Aero Glass rather than Windows
10/11's grainier "Acrylic" material - two different things that are easy
to mix up since they use overlapping APIs.

The difference that matters: Windows 10's SetWindowCompositionAttribute
offers ACCENT_ENABLE_BLURBEHIND (a clean blur, no texture - what Aero
actually looked like) *and* ACCENT_ENABLE_ACRYLICBLURBEHIND (the same
blur plus Fluent Design's signature noise/grain, introduced well after
Aero was gone). This uses BLURBEHIND specifically, with a light,
milky Aero-blue tint rather than a dark one - real Aero stayed pale
blue-white even over dark wallpapers, which is a big part of why it
reads as "glass" instead of just "a see-through window".

On Windows 11 there's no BLURBEHIND-equivalent DWM backdrop type, so
this uses the documented Acrylic system backdrop there (the closest
official option) plus the documented DWMWA_WINDOW_CORNER_PREFERENCE
API for real rounded window corners - genuinely rounded via DWM, not a
window-shape hack that could break on resize.

Off by default. If any of this fails (older Windows, no compositor,
remote desktop session, etc.) it leaves the window fully opaque and
reports that back rather than pretending it worked.

Public API:
    is_supported()   -> bool, True only on Windows
    enable(window)    -> (ok: bool, method: str) turns the effect on
    disable(window)   -> turns it back off (solid, fully opaque)
"""

import ctypes
import platform

IS_WINDOWS = platform.system() == "Windows"

if IS_WINDOWS:
    from ctypes import wintypes

# --- documented Windows 11 API (DWM system backdrop + rounded corners) --
_DWMWA_SYSTEMBACKDROP_TYPE = 38
_DWMWA_USE_IMMERSIVE_DARK_MODE = 20
_DWMWA_WINDOW_CORNER_PREFERENCE = 33
_DWMSBT_NONE = 1
_DWMSBT_TRANSIENTWINDOW = 3  # "Acrylic" - closest official Win11 equivalent
_DWMWCP_ROUND = 2

# Genuine Aero-blue - a pale, milky blue-white. Real Aero glass kept this
# tone even over dark taskbars/wallpapers; a dark tint just looks like a
# dim window, not glass.
AERO_BLUE = (196, 224, 246)  # public - other modules (e.g. the header sheen) reuse this

_DEFAULT_TINT_OPACITY = 150  # default accent-blur tint strength (0..255)

# --- undocumented but long-stable Windows 10 path ------------------------
_ACCENT_DISABLED = 0
_ACCENT_ENABLE_BLURBEHIND = 3          # clean blur - what Aero actually was
_ACCENT_ENABLE_ACRYLICBLURBEHIND = 4   # blur + grain - Fluent Design, not Aero
_WCA_ACCENT_POLICY = 19



if IS_WINDOWS:
    # Without explicit argtypes, ctypes guesses a plain 32-bit c_int for
    # every Python int argument - including window handles. On 64-bit
    # Windows a HWND is a full pointer-sized value, so that guess silently
    # truncates it on some processes/handle ranges. The call doesn't
    # raise, it just operates on a corrupted handle - GetAncestor() can
    # return a bogus value that no longer resolves to our own window, or
    # SetWindowCompositionAttribute()/DwmSetWindowAttribute() can silently
    # no-op or affect the wrong window. That's what made the accent-blur
    # tint call look like it was failing and falling back to the
    # untinted backdrop path even after reordering it to go first -
    # this is the actual root cause, not just call order.
    _user32 = ctypes.windll.user32
    _dwmapi = ctypes.windll.dwmapi

    _user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    _user32.GetAncestor.restype = wintypes.HWND

    _user32.SetWindowCompositionAttribute.argtypes = [wintypes.HWND, ctypes.c_void_p]
    _user32.SetWindowCompositionAttribute.restype = wintypes.BOOL

    _dwmapi.DwmSetWindowAttribute.argtypes = [
        wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
    _dwmapi.DwmSetWindowAttribute.restype = ctypes.c_long  # HRESULT


class _ACCENT_POLICY(ctypes.Structure):
    _fields_ = [
        ("AccentState", ctypes.c_int),
        ("AccentFlags", ctypes.c_int),
        ("GradientColor", ctypes.c_uint),  # ABGR
        ("AnimationId", ctypes.c_int),
    ]


class _WINDOWCOMPOSITIONATTRIBDATA(ctypes.Structure):
    _fields_ = [
        ("Attribute", ctypes.c_int),
        ("Data", ctypes.POINTER(_ACCENT_POLICY)),
        ("SizeOfData", ctypes.c_size_t),
    ]


def is_supported():
    """Return whether this implementation has a supported DWM compositor.
    The accent blur API used here is available on Windows 10/11; Windows 7/8
    should not be told that TechDrive has Aero enabled when this code cannot
    actually provide the effect.
    """
    if not IS_WINDOWS:
        return False
    try:
        return int(getattr(__import__("sys").getwindowsversion(), "major", 0)) >= 10
    except Exception:
        return False


def _hwnd_for(window):
    """The real top-level HWND for a Tk window - winfo_id() can return a
    child handle on some Tk builds, so walk up via GetAncestor to be sure
    we're targeting the actual top-level frame."""
    window.update_idletasks()
    child_hwnd = wintypes.HWND(window.winfo_id())
    try:
        GA_ROOT = 2
        root_hwnd = _user32.GetAncestor(child_hwnd, GA_ROOT)
        return root_hwnd or child_hwnd
    except Exception:
        return child_hwnd


def _try_round_corners(hwnd, enable):
    """Windows 11 only - real DWM-rounded corners, documented API. Safe
    no-op (returns False) on Windows 10, where the attribute doesn't
    exist."""
    try:
        value = ctypes.c_int(_DWMWCP_ROUND if enable else 0)
        hr = _dwmapi.DwmSetWindowAttribute(
            hwnd, _DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(value), ctypes.sizeof(value))
        return hr == 0
    except Exception:
        return False


def _try_dwm_backdrop(hwnd, enable, dark=True):
    """Modern, documented path (Windows 11 22H2+). Returns True only if
    the call actually succeeded - DwmSetWindowAttribute returns a
    non-zero HRESULT on older Windows where this attribute doesn't
    exist, which we treat as 'not supported' rather than silently
    pretending it worked."""
    try:
        value = ctypes.c_int(_DWMSBT_TRANSIENTWINDOW if enable else _DWMSBT_NONE)
        hr = _dwmapi.DwmSetWindowAttribute(
            hwnd, _DWMWA_SYSTEMBACKDROP_TYPE, ctypes.byref(value), ctypes.sizeof(value))
        if hr != 0:
            return False
        dark_value = ctypes.c_int(1 if dark else 0)
        _dwmapi.DwmSetWindowAttribute(
            hwnd, _DWMWA_USE_IMMERSIVE_DARK_MODE, ctypes.byref(dark_value),
            ctypes.sizeof(dark_value))
        _try_round_corners(hwnd, enable)
        return True
    except Exception:
        return False


def _try_accent_blur(hwnd, enable, tint_rgb=AERO_BLUE, opacity=_DEFAULT_TINT_OPACITY):
    """Windows 10 fallback - clean BLURBEHIND (real Aero look), not the
    grainy ACRYLICBLURBEHIND Fluent Design uses. Returns True only on an
    actual successful call."""
    try:
        accent = _ACCENT_POLICY()
        accent.AccentState = _ACCENT_ENABLE_BLURBEHIND if enable else _ACCENT_DISABLED
        r, g, b = tint_rgb
        accent.GradientColor = (opacity << 24) | (b << 16) | (g << 8) | r
        accent.AccentFlags = 2
        accent.AnimationId = 0

        data = _WINDOWCOMPOSITIONATTRIBDATA()
        data.Attribute = _WCA_ACCENT_POLICY
        data.SizeOfData = ctypes.sizeof(accent)
        data.Data = ctypes.pointer(accent)

        result = _user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
        return bool(result)
    except Exception:
        return False


# Two presets rather than one fixed look:
# - "light" (the default): barely-there translucency. Readable over any
#   wallpaper, which the heavier setting genuinely was not - text over a
#   busy background became illegible, a real usability regression a
#   previous version of this shipped by chasing authenticity too hard.
# - "classic": the full, heavily see-through Windows 7 Aero look. Opt-in
#   only, since it can make text hard to read depending on wallpaper -
#   that trade-off is the user's call to make, not a surprise default.
INTENSITY_PRESETS = {
    # ``opacity`` belongs to the DWM accent backdrop itself.  Higher means
    # a denser Aero-blue wash; the Tk client remains opaque and readable.
    # Keep Light restrained and Classic visibly stronger.
    "light": {"opacity": 105},
    "classic": {"opacity": 180},
}


def enable(window, tint_rgb=AERO_BLUE, intensity="light", dark=True):
    """Enable the most reliable native glass backend for the current OS.

    Windows 10 uses the long-standing accent blur API because it accepts a
    TechDrive-controlled tint. Windows 11 prefers its documented DWM system
    backdrop API; mixing both policies on the same HWND can produce flicker,
    stale blur, or a backdrop that survives after Aero is disabled.
    """
    if not IS_WINDOWS:
        return False, None
    preset = INTENSITY_PRESETS.get(intensity, INTENSITY_PRESETS["light"])
    hwnd = _hwnd_for(window)
    try:
        winver = __import__("sys").getwindowsversion()
        major = int(getattr(winver, "major", 0))
        build = int(getattr(winver, "build", 0))
    except Exception:
        major, build = 0, 0

    # Windows 11 continues to report Windows major version 10 to most
    # applications; the build number (22000+) is the reliable discriminator.
    is_win11 = major == 10 and build >= 22000

    # Clear the opposite backend first. This makes toggling Aero repeatedly
    # deterministic instead of accumulating DWM state.
    if is_win11:
        _try_accent_blur(hwnd, False, tint_rgb, preset["opacity"])
        if _try_dwm_backdrop(hwnd, True, dark=dark):
            _try_round_corners(hwnd, True)
            return True, "backdrop"
        # Some Insider/older Win11 builds expose the OS version but reject
        # the system-backdrop attribute. Fall through to the proven accent
        # path rather than leaving the window in a half-enabled state.
        if _try_accent_blur(hwnd, True, tint_rgb, preset["opacity"]):
            _try_round_corners(hwnd, True)
            return True, "accent"
        return False, None

    if major == 10:
        _try_dwm_backdrop(hwnd, False, dark=dark)
        if _try_accent_blur(hwnd, True, tint_rgb, preset["opacity"]):
            return True, "accent"
        return False, None

    return False, None


def disable(window):
    """Reverts to a fully solid, opaque window with square corners."""
    if not IS_WINDOWS:
        return False
    hwnd = _hwnd_for(window)
    ok1 = _try_dwm_backdrop(hwnd, False)
    _try_round_corners(hwnd, False)
    ok2 = _try_accent_blur(hwnd, False)
    return ok1 or ok2
