#!/usr/bin/env python3
"""
gui/search.py — tool search index
===================================
Plain-Python search over the CATALOGUE (list of (category, icon, tools))
that techdrive.py already builds. Deliberately has zero Tk imports so it
can be unit tested without a display - gui/sidebar.py is what wires this
into the actual search box + tree widgets.
"""


class ToolSearchIndex:
    """Case-insensitive substring search across tool names and their
    parent category name. Rebuild once per CATALOGUE (it doesn't change
    at runtime), then call .search(query) as often as you like - it's a
    simple linear scan, plenty fast for a few hundred/thousand entries."""

    def __init__(self, catalogue):
        # catalogue: list of (category_name, icon, [tool_name, ...])
        self._entries = []
        for cat, icon, tools in catalogue:
            for tool in tools:
                self._entries.append((cat, icon, tool))

    def search(self, query):
        """Returns a list of (category, icon, tool, match_spans) for every
        entry where `query` appears (case-insensitively) in the tool name
        or its category name. match_spans is a list of (start, end)
        character ranges into `tool` for highlighting - empty if the match
        was only in the category name.

        An empty/whitespace-only query returns every entry with no spans,
        i.e. "no filter applied"."""
        query = (query or "").strip().lower()
        if not query:
            return [(cat, icon, tool, []) for cat, icon, tool in self._entries]

        results = []
        for cat, icon, tool in self._entries:
            spans = list(_find_all(tool.lower(), query))
            cat_hit = query in cat.lower()
            if spans or cat_hit:
                results.append((cat, icon, tool, spans))
        return results

    def categories_with_matches(self, query):
        """Returns the set of category names that have at least one
        matching tool for `query` - used by the sidebar to decide which
        categories to auto-expand while searching."""
        return {cat for cat, _icon, _tool, _spans in self.search(query)}


def _find_all(haystack, needle):
    """Yield (start, end) for every non-overlapping occurrence of `needle`
    in `haystack`. Both are assumed already lowercased by the caller."""
    if not needle:
        return
    start = 0
    while True:
        idx = haystack.find(needle, start)
        if idx == -1:
            return
        yield (idx, idx + len(needle))
        start = idx + len(needle)
