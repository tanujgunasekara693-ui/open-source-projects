#!/usr/bin/env python3
"""
gui/scroll_utils.py — Shared mouse-wheel scrolling for the dashboard and
every tool panel
=================================================================

Two small pieces glue together to make "hover anywhere over a scrollable
area and just scroll" work everywhere in the app, not just when the
cursor happens to be over bare canvas background:

1. make_scrollable(parent, bg) - builds a Canvas + vertical Scrollbar +
   inner content Frame, wires up the usual scrollregion/width-fit
   bindings, and flags the canvas as wheel-scrollable.

2. install_global_mousewheel(root) - installs ONE app-wide wheel handler
   (Windows <MouseWheel>, plus X11 <Button-4>/<Button-5>) on the root
   window. Because every widget's real Tk parent is still its visual
   container (Tk's window hierarchy doesn't change just because a widget
   is drawn via canvas.create_window), the handler can always walk up
   from whatever widget is directly under the cursor - a label, a stat
   row, a card - through .master until it finds a flagged canvas, and
   scroll that one. This works no matter how deeply nested the widget
   under the pointer is, so individual labels/frames never need their
   own wheel bindings.
"""

import tkinter as tk

from gui.motion import motion_enabled


def make_scrollable(parent, bg):
    """Build a scrollable Canvas+Scrollbar+content Frame inside `parent`.

    Returns (canvas, content_frame). The content_frame is where callers
    should place their actual UI - it stretches to the canvas width and
    grows the scrollregion automatically as content is added/removed.
    """
    parent.grid_rowconfigure(0, weight=1)
    parent.grid_columnconfigure(0, weight=1)

    canvas = tk.Canvas(parent, bg=bg, highlightthickness=0, bd=0)
    canvas.grid(row=0, column=0, sticky="nsew")
    scrollbar = tk.Scrollbar(
        parent, orient="vertical", command=canvas.yview, width=8,
        relief="flat", bd=0, highlightthickness=0,
        bg=bg, troughcolor=bg, activebackground=bg,
    )
    scrollbar.grid(row=0, column=1, sticky="ns")

    def _sync_scrollbar(first, last):
        # Hide the rail when the page fits; show it only when scrolling is
        # actually possible. This removes the distracting empty scrollbar
        # seen on short/simple tool pages while preserving full scrolling.
        try:
            if float(first) <= 0.001 and float(last) >= 0.999:
                scrollbar.grid_remove()
            else:
                scrollbar.grid()
            scrollbar.set(first, last)
        except tk.TclError:
            return

    canvas.configure(yscrollcommand=_sync_scrollbar)

    content = tk.Frame(canvas, bg=bg)
    content_window = canvas.create_window((0, 0), window=content, anchor="nw")

    def _on_content_configure(_e=None):
        # Measure the content window only - NOT bbox("all").  A page may
        # paint decorative items straight onto this canvas (the dashboard's
        # backdrop glow starts at y=-170); bbox("all") counted them, which
        # stretched the scroll region upward and left a ~190px empty band
        # above the first widget.
        box = canvas.bbox(content_window)
        if box:
            canvas.configure(scrollregion=(0, 0, box[2], box[3]))

    def _on_canvas_configure(event):
        canvas.itemconfigure(content_window, width=event.width)

    content.bind("<Configure>", _on_content_configure)
    canvas.bind("<Configure>", _on_canvas_configure)

    # Flag this canvas so the app-wide wheel router (installed once in
    # TechDriveApp.__init__) knows it's a scroll target.
    canvas._wheel_scrollable = True

    return canvas, content


def _do_scroll(canvas, units):
    try:
        if not units:
            return
        canvas.yview_scroll(units, "units")
    except tk.TclError:
        pass  # canvas destroyed mid-scroll (e.g. tab just closed)


def install_global_mousewheel(root):
    """Install one app-wide mouse-wheel handler on `root`.

    Safe to call exactly once per app instance. Handles the Windows/macOS
    <MouseWheel> event (delta multiples of 120 on Windows) as well as the
    X11 <Button-4>/<Button-5> wheel events used when the app is run/
    inspected under Linux, so scrolling behaves the same everywhere the
    app runs.
    """
    if getattr(root, "_global_wheel_installed", False):
        return
    root._global_wheel_installed = True
    wheel_remainder = {}
    momentum = {"canvas": None, "velocity": 0.0, "job": None}

    def _find_canvas(widget):
        depth = 0
        while widget is not None and depth < 60:
            if isinstance(widget, tk.Canvas) and getattr(widget, "_wheel_scrollable", False):
                return widget
            widget = widget.master
            depth += 1
        return None

    def _on_mousewheel(event):
        canvas = _find_canvas(event.widget)
        if canvas is not None:
            # High-resolution touchpads often emit deltas smaller than 120.
            # Accumulate the fractional wheel movement so those events still
            # scroll smoothly instead of being rounded to zero.
            key = str(canvas)
            total = wheel_remainder.get(key, 0.0) + (-event.delta / 120.0)
            units = int(total)
            wheel_remainder[key] = total - units
            if units:
                if not motion_enabled():
                    _do_scroll(canvas, units)
                    return "break"
                momentum["canvas"] = canvas
                momentum["velocity"] = max(-9.0, min(9.0, momentum["velocity"] + units * 1.8))
                if momentum["job"] is None:
                    def glide():
                        target = momentum["canvas"]
                        velocity = momentum["velocity"]
                        if target is None or abs(velocity) < 0.35:
                            momentum.update(canvas=None, velocity=0.0, job=None)
                            return
                        _do_scroll(target, 1 if velocity > 0 else -1)
                        momentum["velocity"] *= 0.76
                        momentum["job"] = root.after(16, glide)
                    glide()
            return "break"

    def _on_button4(event):
        canvas = _find_canvas(event.widget)
        if canvas is not None:
            _do_scroll(canvas, -3)

    def _on_button5(event):
        canvas = _find_canvas(event.widget)
        if canvas is not None:
            _do_scroll(canvas, 3)

    root.bind_all("<MouseWheel>", _on_mousewheel, add="+")
    root.bind_all("<Button-4>", _on_button4, add="+")
    root.bind_all("<Button-5>", _on_button5, add="+")
