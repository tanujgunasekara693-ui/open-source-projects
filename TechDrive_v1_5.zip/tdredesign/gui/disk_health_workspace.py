#!/usr/bin/env python3
"""
gui/disk_health_workspace.py — Disk Health, rebuilt as a workspace
====================================================================

Previously `tool_disk_health_check` in techdrive.py was a single WMIC
dump in a Text box. This rebuilds it on top of gui.workspace_panel so
the tool matches the "tool workspace" concept:

    Overview | Drives | SMART | History

  * Overview  - one line per drive, good/attention/unknown at a glance.
  * Drives    - capacity/used/free per drive with a usage meter.
  * SMART     - the raw per-drive SMART/WMIC status TechDrive can read.
  * History   - past Disk Health scans (shared.database.get_disk_history),
                same pattern already used by Diagnostic History.

Read-only, like the rest of Health Center: this never repairs, formats,
or changes anything - it only reports what it finds.
"""

import datetime as _datetime
import platform
import subprocess
import tkinter as tk

from gui import fluent as fl
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO
from gui.widgets import GlassCard, MeterBar
from gui.workspace_panel import WorkspacePanel
from shared import database as db

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

IS_WINDOWS = platform.system() == "Windows"


def _run_argv(argv, timeout=20):
    try:
        result = subprocess.run(argv, shell=False, capture_output=True, text=True,
                                 timeout=timeout, errors="replace")
        out = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "Command timed out."
    except FileNotFoundError:
        return False, f"{argv[0]} is not available."
    except Exception as exc:
        return False, str(exc)


def _relative_time(epoch_seconds):
    try:
        then = _datetime.datetime.fromtimestamp(float(epoch_seconds))
    except (TypeError, ValueError, OSError):
        return "Unknown time"
    delta = _datetime.datetime.now() - then
    seconds = delta.total_seconds()
    if seconds < 60:
        return "Just now"
    if seconds < 3600:
        return f"{int(seconds // 60)} min ago"
    if seconds < 86400:
        return f"{int(seconds // 3600)} hr ago"
    return then.strftime("%b %d")


# --- data gathering ---------------------------------------------------

def _smart_by_serial():
    """Best-effort per-drive SMART/model/status via WMIC (Windows only).
    Returns list of dicts: model, serial, status. Empty off Windows or on
    failure - callers must treat that as 'not available' rather than
    'unhealthy'."""
    if not IS_WINDOWS:
        return []
    ok, out = _run_argv(
        ["wmic", "diskdrive", "get", "Model,Status,SerialNumber", "/format:list"],
        timeout=25,
    )
    if not ok or not out:
        return []
    drives, current = [], {}
    for line in out.splitlines():
        line = line.strip()
        if not line:
            if current:
                drives.append(current)
                current = {}
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            current[key.strip().lower()] = value.strip()
    if current:
        drives.append(current)
    return drives


def gather_disk_report():
    """Collect the full Disk Health snapshot used by every tab at once,
    so 'Scan Drives' is one background job instead of four."""
    volumes = []
    if psutil:
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
            except (PermissionError, OSError):
                continue
            volumes.append({
                "device": part.device,
                "mountpoint": part.mountpoint,
                "fstype": part.fstype,
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": usage.percent,
            })

    smart_rows = _smart_by_serial()

    drives = []
    for vol in volumes:
        if vol["percent"] >= 95:
            status, note = "bad", "Almost full — free up space soon."
        elif vol["percent"] >= 85:
            status, note = "warn", "Getting full."
        else:
            status, note = "good", "Plenty of free space."
        drives.append({
            "name": vol["device"],
            "mountpoint": vol["mountpoint"],
            "fstype": vol["fstype"],
            "total": vol["total"],
            "used": vol["used"],
            "free": vol["free"],
            "percent": vol["percent"],
            "status": status,
            "note": note,
        })

    bad = sum(1 for d in drives if d["status"] == "bad")
    warn = sum(1 for d in drives if d["status"] == "warn")
    if bad:
        overall = "critical"
    elif warn:
        overall = "warning"
    else:
        overall = "healthy"
    score = 100 - bad * 30 - warn * 12
    score = max(0, min(100, score))

    return {
        "status": overall,
        "score": score,
        "drives": drives,
        "smart_rows": smart_rows,
        "smart_available": IS_WINDOWS,
    }


# --- rendering ----------------------------------------------------------

_STATUS_LABEL = {"good": ("● Healthy", None), "warn": ("⚠ Attention", None),
                  "bad": ("✕ Critical", None), "unknown": ("? Unknown", None)}


def _status_color(theme, status):
    return {"good": fl.GOOD, "warn": fl.WARN, "bad": fl.BAD}.get(status, theme["MUTED"])


def _fmt_bytes(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} TB"


def build(frame, theme, aero, run_bg):
    """Build the Disk Health workspace into *frame*.

    `run_bg(fn, on_done)` is the host app's existing background-thread
    helper (kept as a parameter instead of importing techdrive.py, which
    would create a circular import - techdrive.py imports this module,
    not the other way around).
    """
    ws = WorkspacePanel(
        frame, theme, aero=aero, icon="❤", title="Disk Health",
        subtitle="Per-drive status, SMART data, and scan history",
        on_refresh=lambda: run_scan(),
    )

    overview = ws.add_tab("Overview")
    drives_tab = ws.add_tab("Drives")
    smart_tab = ws.add_tab("SMART")
    history_tab = ws.add_tab("History")

    def render_overview(report):
        for child in overview.winfo_children():
            child.destroy()
        drives = report["drives"]
        if not drives:
            tk.Label(overview, text="No readable drives found.", bg=theme["BG"],
                      fg=theme["MUTED"], font=FONT_UI).pack(anchor="w", padx=16, pady=16)
            return
        for d in drives:
            card = GlassCard(overview, theme, aero=aero)
            card.pack(fill="x", padx=14, pady=(0, 10))
            row = tk.Frame(card.body, bg=card.fill)
            row.pack(fill="x", padx=14, pady=10)
            tk.Label(row, text=f"Drive {d['name']}", bg=card.fill, fg=theme["FG"],
                      font=FONT_UI_BOLD).pack(side="left")
            label, _ = _STATUS_LABEL.get(d["status"], _STATUS_LABEL["unknown"])
            tk.Label(row, text=label, bg=card.fill, fg=_status_color(theme, d["status"]),
                      font=FONT_UI_BOLD).pack(side="right")
            tk.Label(card.body, text=d["note"], bg=card.fill, fg=theme["MUTED"],
                      font=fl.F_SMALL()).pack(anchor="w", padx=14, pady=(0, 10))

    def render_drives(report):
        for child in drives_tab.winfo_children():
            child.destroy()
        drives = report["drives"]
        if not drives:
            tk.Label(drives_tab, text="No readable drives found.", bg=theme["BG"],
                      fg=theme["MUTED"], font=FONT_UI).pack(anchor="w", padx=16, pady=16)
            return
        for d in drives:
            card = GlassCard(drives_tab, theme, aero=aero)
            card.pack(fill="x", padx=14, pady=(0, 10))
            head = tk.Frame(card.body, bg=card.fill)
            head.pack(fill="x", padx=14, pady=(10, 2))
            tk.Label(head, text=f"{d['name']}  ({d['fstype'] or 'unknown fs'})",
                      bg=card.fill, fg=theme["FG"], font=FONT_UI_BOLD).pack(side="left")
            tk.Label(head, text=f"{d['percent']:.0f}% used", bg=card.fill,
                      fg=_status_color(theme, d["status"]), font=fl.F_SMALL()).pack(side="right")
            meter = MeterBar(card.body, theme, color=_status_color(theme, d["status"]),
                               bg=card.fill)
            meter.pack(fill="x", padx=14, pady=(4, 4))
            meter.set_value(d["percent"] / 100.0)
            tk.Label(card.body,
                      text=f"{_fmt_bytes(d['used'])} used  /  "
                           f"{_fmt_bytes(d['free'])} free  /  "
                           f"{_fmt_bytes(d['total'])} total",
                      bg=card.fill, fg=theme["MUTED"], font=fl.F_SMALL(),
                      ).pack(anchor="w", padx=14, pady=(0, 10))

    def render_smart(report):
        for child in smart_tab.winfo_children():
            child.destroy()
        if not report.get("smart_available"):
            tk.Label(smart_tab, text="Run TechDrive on Windows to read SMART status.",
                      bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI,
                      wraplength=640, justify="left").pack(anchor="w", padx=16, pady=16)
            return
        rows = report.get("smart_rows") or []
        if not rows:
            tk.Label(smart_tab, text="SMART data was not available for any drive.",
                      bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI).pack(
                          anchor="w", padx=16, pady=16)
            return
        for row in rows:
            card = GlassCard(smart_tab, theme, aero=aero)
            card.pack(fill="x", padx=14, pady=(0, 10))
            status_text = row.get("status", "Unknown")
            color = fl.GOOD if status_text.upper() == "OK" else fl.BAD
            head = tk.Frame(card.body, bg=card.fill)
            head.pack(fill="x", padx=14, pady=(10, 2))
            tk.Label(head, text=row.get("model", "Unknown drive"), bg=card.fill,
                      fg=theme["FG"], font=FONT_UI_BOLD).pack(side="left")
            tk.Label(head, text=status_text, bg=card.fill, fg=color,
                      font=FONT_UI_BOLD).pack(side="right")
            serial = row.get("serialnumber", "").strip()
            if serial:
                tk.Label(card.body, text=f"Serial: {serial}", bg=card.fill,
                          fg=theme["MUTED"], font=FONT_MONO).pack(
                              anchor="w", padx=14, pady=(0, 10))

    def render_history(_event=None):
        for child in history_tab.winfo_children():
            child.destroy()
        rows = db.get_disk_history(limit=30)
        if not rows:
            tk.Label(history_tab, text="No scans yet — click Scan Drives to run one.",
                      bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI).pack(
                          anchor="w", padx=16, pady=16)
            return
        for entry in rows:
            report = entry.get("report") or {}
            status = report.get("status", "unknown")
            color = {"healthy": fl.GOOD, "warning": fl.WARN,
                      "critical": fl.BAD}.get(status, theme["MUTED"])
            card = GlassCard(history_tab, theme, aero=aero, accent=color)
            card.pack(fill="x", padx=14, pady=(0, 8))
            top = tk.Frame(card.body, bg=card.fill)
            top.pack(fill="x", padx=14, pady=(10, 2))
            tk.Label(top, text=entry.get("title", "Disk Health scan"), bg=card.fill,
                      fg=theme["FG"], font=FONT_UI_BOLD).pack(side="left", fill="x", expand=True)
            tk.Label(top, text=_relative_time(entry.get("occurred_at")), bg=card.fill,
                      fg=theme["MUTED"], font=fl.F_TINY()).pack(side="right")
            tk.Label(card.body, text=entry.get("summary", ""), bg=card.fill,
                      fg=theme["MUTED"], font=fl.F_SMALL(), wraplength=640,
                      justify="left").pack(anchor="w", padx=14, pady=(0, 10))

    # History only needs to be loaded once (and again after each scan);
    # no reason to rebuild it every single time the user just glances
    # at the tab, so it's wired through render_history() directly
    # rather than on_tab_shown (whose one-shot semantics don't fit a
    # tab that should refresh after every new scan).
    render_history()

    def run_scan():
        ws.set_status("Scanning drives…", "busy")

        def on_done(report):
            render_overview(report)
            render_drives(report)
            render_smart(report)
            try:
                db.add_disk_scan(report)
            except Exception:
                pass  # history logging is best-effort, never blocks the scan result
            render_history()
            ws.set_status("Ready", "done")

        run_bg(gather_disk_report, on_done)

    # Populate Overview/Drives/SMART with a first pass immediately so the
    # workspace isn't empty before the user clicks anything.
    run_scan()

    return ws
