#!/usr/bin/env python3
"""Accessibility pass — Dynamic Type, focus rings, contrast helpers."""

from __future__ import annotations

from shared import database as db


def get_font_scale():
    try:
        return float(db.get_setting("font_scale", 1.0) or 1.0)
    except Exception:
        return 1.0


def set_font_scale(scale, app=None):
    scale = max(0.85, min(1.5, float(scale)))
    db.set_setting("font_scale", scale)
    try:
        from gui import fluent as fl
        fl.set_font_scale(scale)
    except Exception:
        pass
    if app is not None and hasattr(app, "apply_theme_choice"):
        try:
            app.apply_theme_choice(getattr(app, "theme_id", "dark"))
        except Exception:
            pass
    return scale


def larger_text(app=None):
    return set_font_scale(get_font_scale() + 0.1, app)


def smaller_text(app=None):
    return set_font_scale(get_font_scale() - 0.1, app)


def increase_contrast_enabled():
    return bool(db.get_setting("increase_contrast", False))


def set_increase_contrast(enabled, app=None):
    db.set_setting("increase_contrast", bool(enabled))
    if enabled and app is not None and hasattr(app, "apply_theme_choice"):
        # Prefer high_contrast theme when available
        try:
            from gui.fluent import THEMES
            if "high_contrast" in THEMES:
                app.apply_theme_choice("high_contrast")
        except Exception:
            pass
    elif app is not None and hasattr(app, "apply_theme_choice"):
        try:
            app.apply_theme_choice("dark")
        except Exception:
            pass


def apply_focus_ring(widget, theme=None):
    """Stronger focus ring for keyboard navigation."""
    try:
        from gui import fluent as fl
        th = theme or fl.DARK
        glow = th.get("ACCENT_GLOW", th.get("ACCENT", "#0a84ff"))
        widget.configure(highlightthickness=2, highlightcolor=glow, highlightbackground=glow)
    except Exception:
        pass


def bootstrap(app):
    """Apply saved a11y settings at startup."""
    try:
        from gui import fluent as fl
        fl.set_font_scale(get_font_scale())
    except Exception:
        pass
