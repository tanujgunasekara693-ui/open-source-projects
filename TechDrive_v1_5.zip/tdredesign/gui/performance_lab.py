#!/usr/bin/env python3
"""
TechDrive Performance Lab
=========================

Evidence-based Windows performance measurements.  Each metric uses a fixed
native Windows command or a fixed local workload, displays its raw output,
and contributes to the score only after it has actually run.
"""

import datetime as _datetime
import os
import platform
import re
import subprocess
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard
from shared import database as db


IS_WINDOWS = platform.system() == "Windows"
POWERSHELL = (
    "powershell -NoProfile -NonInteractive "
    "-ExecutionPolicy Bypass -Command"
)


def _run_argv(argv, timeout=90):
    """Run fixed argv without a shell and return a serialisable result."""
    try:
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip()
        return {
            "ok": result.returncode == 0,
            "output": output or f"(no output, exit code {result.returncode})",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "output": "Command timed out."}
    except FileNotFoundError:
        return {"ok": False, "output": f"{argv[0]} is not available on this PC."}
    except Exception as exc:
        return {"ok": False, "output": f"{type(exc).__name__}: {exc}"}


def _powershell(script, timeout=90):
    return _run_argv(
        [
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            script,
        ],
        timeout=timeout,
    )


def _winsat(args, timeout=180):
    return _run_argv(["winsat", *args, "-v"], timeout=timeout)


def _unavailable():
    return {
        "ok": False,
        "output": (
            "Windows-only measurement. No performance command was executed "
            "on this operating system."
        ),
    }


def _boot_duration():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$event = Get-WinEvent -FilterHashtable @{"
        "LogName='Microsoft-Windows-Diagnostics-Performance/Operational';"
        "Id=100} -MaxEvents 1 -ErrorAction Stop; "
        "$event | Select-Object TimeCreated,Id,Message | Format-List",
        timeout=45,
    )


def _startup_apps():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-CimInstance Win32_StartupCommand -ErrorAction Stop); "
        "if ($items.Count -eq 0) { "
        "  Write-Output 'No startup applications were returned.'; exit 2 "
        "}; "
        "$items | Select-Object Name,Command,Location,User | "
        "Format-Table -Wrap -AutoSize | Out-String -Width 240",
        timeout=45,
    )


def _boot_events():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "Get-WinEvent -FilterHashtable @{"
        "LogName='Microsoft-Windows-Diagnostics-Performance/Operational';"
        "Id=100,101,102,103,106,107,108,109,110} -MaxEvents 12 "
        "-ErrorAction Stop | Select-Object TimeCreated,Id,LevelDisplayName,"
        "Message | Format-List",
        timeout=45,
    )


def _cpu_benchmark():
    if not IS_WINDOWS:
        return _unavailable()
    return _winsat(["cpu", "-compression", "-time", "5"], timeout=120)


def _cpu_thermal():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-CimInstance -Namespace 'root/wmi' "
        "-ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue); "
        "if ($items.Count -eq 0) { "
        "  Write-Output 'Windows exposed no ACPI thermal sensors.'; exit 2 "
        "}; "
        "$items | Select-Object InstanceName,CurrentTemperature,"
        "CriticalTripPoint,PassiveTripPoint | Format-Table -AutoSize | "
        "Out-String -Width 220; "
        "Write-Output 'Temperature values are reported in tenths of Kelvin "
        "by this Windows provider.'",
        timeout=45,
    )


def _cpu_clock():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "Get-CimInstance Win32_Processor -ErrorAction Stop | "
        "Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,"
        "CurrentClockSpeed,MaxClockSpeed,LoadPercentage | "
        "Format-Table -AutoSize | Out-String -Width 240",
        timeout=45,
    )


def _gpu_benchmark():
    if not IS_WINDOWS:
        return _unavailable()
    return _winsat(["dwm"], timeout=180)


def _gpu_vram():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-CimInstance Win32_VideoController "
        "-ErrorAction Stop); "
        "if ($items.Count -eq 0) { "
        "  Write-Output 'No Windows video controller was returned.'; exit 2 "
        "}; "
        "$items | Select-Object Name,AdapterRAM,VideoModeDescription,"
        "DriverVersion,CurrentRefreshRate | Format-Table -AutoSize | "
        "Out-String -Width 240",
        timeout=45,
    )


def _gpu_thermal():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-CimInstance -Namespace 'root/wmi' "
        "-ClassName MSAcpi_ThermalZoneTemperature "
        "-ErrorAction SilentlyContinue); "
        "if ($items.Count -eq 0) { "
        "  Write-Output 'Windows exposed no thermal-zone sensor. "
        "A GPU-specific temperature sensor is not guaranteed by Windows.'; "
        "  exit 2 "
        "}; "
        "$items | Select-Object InstanceName,CurrentTemperature,"
        "CriticalTripPoint | Format-Table -AutoSize | Out-String -Width 220; "
        "Write-Output 'These are ACPI thermal zones; Windows may not identify "
        "a GPU sensor separately.'",
        timeout=45,
    )


def _ram_diagnostics():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$memory = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop | "
        "Select-Object TotalVisibleMemorySize,FreePhysicalMemory; "
        "$events = @(Get-WinEvent -LogName System -MaxEvents 200 "
        "-ErrorAction SilentlyContinue | Where-Object {$_.ProviderName "
        "-eq 'Microsoft-Windows-MemoryDiagnostics-Results'} | Select-Object "
        "-First 5 TimeCreated,Id,LevelDisplayName,Message); "
        "$memory | Format-List; "
        "if ($events.Count -gt 0) {$events | Format-List} "
        "else {Write-Output 'No MemoryDiagnostics-Results events were found.'}",
        timeout=60,
    )


def _ram_bandwidth():
    if not IS_WINDOWS:
        return _unavailable()
    return _winsat(["mem"], timeout=180)


def _system_drive():
    drive = os.environ.get("SystemDrive", "C:").rstrip(":").upper()
    return drive if re.fullmatch(r"[A-Z]", drive) else "C"


def _storage_throughput():
    if not IS_WINDOWS:
        return _unavailable()
    drive = _system_drive()
    read_result = _winsat(
        ["disk", "-drive", drive, "-seq", "-read", "-count", "2"],
        timeout=240,
    )
    write_result = _winsat(
        ["disk", "-drive", drive, "-seq", "-write", "-count", "2"],
        timeout=240,
    )
    return {
        "ok": read_result["ok"] and write_result["ok"],
        "output": (
            f"System drive: {drive}:\n\n"
            f"SEQUENTIAL READ\n{read_result['output']}\n\n"
            f"SEQUENTIAL WRITE\n{write_result['output']}"
        ),
    }


def _storage_latency():
    if not IS_WINDOWS:
        return _unavailable()
    return _winsat(
        ["disk", "-drive", _system_drive(), "-ran", "-read", "-count", "2"],
        timeout=240,
    )


def _storage_health():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$disks = @(Get-PhysicalDisk -ErrorAction Stop | "
        "Select-Object FriendlyName,MediaType,HealthStatus,"
        "OperationalStatus,Size); "
        "if ($disks.Count -eq 0) { "
        "  Write-Output 'No physical disks were returned.'; exit 2 "
        "}; "
        "$disks | Format-Table -AutoSize | Out-String -Width 240; "
        "$bad = @($disks | Where-Object {$_.HealthStatus -ne 'Healthy'}); "
        "if ($bad.Count -gt 0) { exit 2 }",
        timeout=60,
    )


def _metric_specs():
    return [
        {
            "category": "BOOT",
            "key": "boot_duration",
            "title": "Boot duration",
            "description": "Reads the latest Windows Diagnostics-Performance boot event.",
            "command": (
                f"{POWERSHELL} Get-WinEvent "
                "-FilterHashtable {LogName='Microsoft-Windows-Diagnostics-Performance/Operational';Id=100} "
                "-MaxEvents 1"
            ),
            "run": _boot_duration,
            "weight": 10,
        },
        {
            "category": "BOOT",
            "key": "startup_apps",
            "title": "Startup applications",
            "description": "Lists programs registered to start with Windows.",
            "command": (
                f"{POWERSHELL} Get-CimInstance Win32_StartupCommand "
                "| Select Name,Command,Location,User"
            ),
            "run": _startup_apps,
            "weight": 3,
        },
        {
            "category": "BOOT",
            "key": "boot_events",
            "title": "Boot events",
            "description": "Reads recent boot and startup degradation events.",
            "command": (
                f"{POWERSHELL} Get-WinEvent "
                "-LogName Microsoft-Windows-Diagnostics-Performance/Operational "
                "-MaxEvents 12"
            ),
            "run": _boot_events,
            "weight": 2,
        },
        {
            "category": "CPU",
            "key": "cpu_benchmark",
            "title": "Benchmark",
            "description": "Runs the Windows System Assessment Tool CPU compression test.",
            "command": "winsat cpu -compression -time 5 -v",
            "run": _cpu_benchmark,
            "weight": 10,
        },
        {
            "category": "CPU",
            "key": "cpu_thermal",
            "title": "Thermal behavior",
            "description": "Reads ACPI thermal sensors exposed by Windows.",
            "command": (
                f"{POWERSHELL} Get-CimInstance -Namespace root/wmi "
                "-ClassName MSAcpi_ThermalZoneTemperature"
            ),
            "run": _cpu_thermal,
            "weight": 8,
        },
        {
            "category": "CPU",
            "key": "cpu_clock",
            "title": "Clock behavior",
            "description": "Reports current and maximum processor clock speed and load.",
            "command": f"{POWERSHELL} Get-CimInstance Win32_Processor",
            "run": _cpu_clock,
            "weight": 7,
        },
        {
            "category": "GPU",
            "key": "gpu_benchmark",
            "title": "Benchmark",
            "description": "Runs the native Windows desktop composition assessment.",
            "command": "winsat dwm -v",
            "run": _gpu_benchmark,
            "weight": 8,
        },
        {
            "category": "GPU",
            "key": "gpu_vram",
            "title": "VRAM",
            "description": "Reads video adapter memory and driver information.",
            "command": f"{POWERSHELL} Get-CimInstance Win32_VideoController",
            "run": _gpu_vram,
            "weight": 6,
        },
        {
            "category": "GPU",
            "key": "gpu_thermal",
            "title": "Thermals",
            "description": "Reads Windows thermal zones and reports sensor limitations explicitly.",
            "command": (
                f"{POWERSHELL} Get-CimInstance -Namespace root/wmi "
                "-ClassName MSAcpi_ThermalZoneTemperature"
            ),
            "run": _gpu_thermal,
            "weight": 6,
        },
        {
            "category": "RAM",
            "key": "ram_diagnostics",
            "title": "Memory diagnostics",
            "description": "Reports current memory totals and recent Windows memory-test events.",
            "command": (
                f"{POWERSHELL} Get-CimInstance Win32_OperatingSystem "
                "+ Get-WinEvent -LogName System"
            ),
            "run": _ram_diagnostics,
            "weight": 10,
        },
        {
            "category": "RAM",
            "key": "ram_bandwidth",
            "title": "Bandwidth",
            "description": "Runs the Windows System Assessment Tool memory test.",
            "command": "winsat mem -v",
            "run": _ram_bandwidth,
            "weight": 10,
        },
        {
            "category": "STORAGE",
            "key": "storage_throughput",
            "title": "Throughput",
            "description": "Measures sequential read and write throughput on the system drive.",
            "command": (
                f"winsat disk -drive {_system_drive()} -seq -read -count 2 -v; "
                f"winsat disk -drive {_system_drive()} -seq -write -count 2 -v"
            ),
            "run": _storage_throughput,
            "weight": 8,
        },
        {
            "category": "STORAGE",
            "key": "storage_latency",
            "title": "Latency",
            "description": "Measures random read behavior on the system drive.",
            "command": (
                f"winsat disk -drive {_system_drive()} -ran -read -count 2 -v"
            ),
            "run": _storage_latency,
            "weight": 6,
        },
        {
            "category": "STORAGE",
            "key": "storage_health",
            "title": "Health",
            "description": "Reads physical disk health and operational status.",
            "command": f"{POWERSHELL} Get-PhysicalDisk",
            "run": _storage_health,
            "weight": 6,
        },
    ]


class PerformanceLabPage(tk.Frame):
    """Real Windows performance measurements grouped by hardware area."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.specs = _metric_specs()
        self.states = {
            spec["key"]: {"busy": False, "ran": False, "ok": False}
            for spec in self.specs
        }
        self.score_var = tk.StringVar(value="Performance Score: —/100")
        self.score_detail_var = tk.StringVar(
            value="Run all measurements to calculate a score from real results."
        )
        self._build()

    def _build(self):
        from gui.workspace_panel import WorkspacePanel
        self.ws = WorkspacePanel(
            self, self.theme, aero=self.aero, icon="↯", title="Performance Lab",
            subtitle="Real Windows measurements for boot, CPU, GPU, RAM, and "
                     "storage. Some tests can take several minutes.",
        )
        overview = self.ws.add_tab("Overview")

        row = tk.Frame(overview, bg=self.theme["BG"])
        row.pack(fill="x", padx=18, pady=(14, 2))
        self.run_all_button = tk.Button(
            row,
            text="Run Full Performance Lab",
            command=self._run_all,
            bg=self.theme["ACCENT"],
            fg=self.theme["ON_ACCENT"],
            activebackground=self.theme["ACCENT_GLOW"],
            activeforeground=self.theme["ON_ACCENT"],
            relief="flat",
            padx=14,
            pady=7,
            cursor="hand2",
        )
        self.run_all_button.pack(side="left")

        if not IS_WINDOWS:
            tk.Label(
                overview,
                text="Preview only: run TechDrive on Windows to execute these real measurements.",
                bg=self.theme["BG"],
                fg=fl.WARN,
                font=fl.F_SMALL(),
            ).pack(anchor="w", padx=18, pady=(0, 8))
            self.run_all_button.configure(state=tk.DISABLED)

        score = GlassCard(overview, self.theme, aero=self.aero, accent=self.theme["ACCENT"])
        score.pack(fill="x", padx=18, pady=(10, 14))
        score_body = score.body
        tk.Label(
            score_body,
            textvariable=self.score_var,
            bg=score.fill,
            fg=self.theme["FG"],
            font=fl.F_TITLE(),
        ).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(
            score_body,
            textvariable=self.score_detail_var,
            bg=score.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        ).pack(anchor="w", padx=14, pady=(0, 12))

        categories = []
        for spec in self.specs:
            if spec["category"] not in categories:
                categories.append(spec["category"])
        self._category_tabs = {}
        _tab_titles = {"BOOT": "Boot", "CPU": "CPU", "GPU": "GPU",
                       "RAM": "RAM", "STORAGE": "Storage"}
        for category in categories:
            tab = self.ws.add_tab(_tab_titles.get(category, category.title()))
            self._category_tabs[category] = tab
            self._build_category(tab, category)

        self.history_tab = self.ws.add_tab("History")
        self._render_history()

    def _build_category(self, root, category):
        card = GlassCard(root, self.theme, aero=self.aero, accent=self.theme["ACCENT"])
        card.pack(fill="x", padx=18, pady=(14, 6))
        body = card.body
        tk.Label(
            body,
            text=category,
            bg=card.fill,
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_CARD_TITLE(),
        ).pack(anchor="w", padx=14, pady=(12, 8))
        for spec in [item for item in self.specs if item["category"] == category]:
            self._build_metric(body, card.fill, spec)

    def _render_history(self):
        for child in self.history_tab.winfo_children():
            child.destroy()
        rows = db.get_performance_history(limit=20)
        if not rows:
            tk.Label(self.history_tab, text="No full runs yet — click "
                     "\"Run Full Performance Lab\" to save one.",
                     bg=self.theme["BG"], fg=self.theme["MUTED"],
                     font=fl.F_BODY()).pack(anchor="w", padx=18, pady=16)
            return
        for entry in rows:
            score = int(entry.get("score") or 0)
            color = fl.GOOD if score >= 80 else fl.WARN if score >= 50 else fl.BAD
            card = GlassCard(self.history_tab, self.theme, aero=self.aero, accent=color)
            card.pack(fill="x", padx=18, pady=(0, 8))
            top = tk.Frame(card.body, bg=card.fill)
            top.pack(fill="x", padx=14, pady=(10, 2))
            tk.Label(top, text=entry.get("title", "Performance Lab run"), bg=card.fill,
                     fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                         side="left", fill="x", expand=True)
            tk.Label(top, text=f"{score}/100", bg=card.fill, fg=color,
                     font=fl.F_CARD_TITLE()).pack(side="right")
            when = _datetime.datetime.fromtimestamp(
                float(entry.get("occurred_at", 0))
            ).strftime("%b %d, %H:%M")
            tk.Label(card.body, text=f"{when} — {entry.get('summary', '')}",
                     bg=card.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
                     wraplength=640, justify="left").pack(
                         anchor="w", padx=14, pady=(0, 10))

    def _build_metric(self, body, fill, spec):
        row = tk.Frame(body, bg=fill)
        row.pack(fill="x", padx=14, pady=(0, 12))
        title = tk.Frame(row, bg=fill)
        title.pack(fill="x")
        tk.Label(
            title,
            text=spec["title"],
            bg=fill,
            fg=self.theme["FG"],
            font=fl.F_SUBTITLE(),
        ).pack(side="left")
        status_var = tk.StringVar(value="Not run")
        status_label = tk.Label(
            title,
            textvariable=status_var,
            bg=fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        )
        status_label.pack(side="right")
        tk.Label(
            row,
            text=spec["description"],
            bg=fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
            wraplength=820,
            justify="left",
        ).pack(anchor="w", pady=(2, 3))
        tk.Label(
            row,
            text=f"Command: {spec['command']}",
            bg=fill,
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
            wraplength=820,
            justify="left",
        ).pack(anchor="w", pady=(0, 5))
        output = tk.Text(
            row,
            height=4,
            wrap="word",
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            insertbackground=self.theme["FG"],
            font=fl.F_MONO(),
            relief="flat",
            padx=10,
            pady=7,
            state="disabled",
        )
        output.pack(fill="x", pady=(0, 5))
        run_button = tk.Button(
            row,
            text="Run measurement",
            command=lambda item=spec: self._run_one(item),
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            activebackground=self.theme["SELECTION"],
            activeforeground=self.theme["FG"],
            relief="flat",
            padx=11,
            pady=5,
            cursor="hand2",
        )
        run_button.pack(anchor="w")
        if not IS_WINDOWS:
            run_button.configure(state=tk.DISABLED)
        self.states[spec["key"]].update(
            output=output,
            status_var=status_var,
            status_label=status_label,
            run_button=run_button,
        )

    @staticmethod
    def _write_output(widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _update_metric(self, spec, result):
        state = self.states[spec["key"]]
        state["busy"] = False
        state["ran"] = True
        ok = bool(result.get("ok")) if isinstance(result, dict) else False
        output = result.get("output", str(result)) if isinstance(result, dict) else str(result)
        state["ok"] = ok
        state["status_var"].set("Passed" if ok else "Needs review")
        state["status_label"].configure(fg=fl.GOOD if ok else fl.BAD)
        self._write_output(state["output"], output)
        state["run_button"].configure(state=tk.NORMAL)
        self._update_score()

    def _update_score(self):
        if not all(self.states[spec["key"]]["ran"] for spec in self.specs):
            complete = sum(1 for spec in self.specs if self.states[spec["key"]]["ran"])
            self.score_var.set("Performance Score: —/100")
            self.score_detail_var.set(
                f"{complete}/{len(self.specs)} measurements complete; run all to calculate the score."
            )
            return
        score = sum(
            spec["weight"]
            for spec in self.specs
            if self.states[spec["key"]]["ok"]
        )
        passed = sum(1 for spec in self.specs if self.states[spec["key"]]["ok"])
        self.score_var.set(f"Performance Score: {score}/100")
        self.score_detail_var.set(
            f"{passed}/{len(self.specs)} measurements passed. Score is calculated from actual results."
        )

    def _run_one(self, spec):
        state = self.states[spec["key"]]
        if state["busy"] or not IS_WINDOWS:
            return
        state["busy"] = True
        state["run_button"].configure(state=tk.DISABLED)
        state["status_var"].set("Running…")
        self.app._run_bg(spec["run"], lambda result: self._update_metric(spec, result))

    def _run_all(self):
        if not IS_WINDOWS:
            return
        self.run_all_button.configure(state=tk.DISABLED)
        for spec in self.specs:
            state = self.states[spec["key"]]
            state["busy"] = True
            state["run_button"].configure(state=tk.DISABLED)
            state["status_var"].set("Queued…")

        def run_all():
            results = []
            for spec in self.specs:
                results.append((spec, spec["run"]()))
            return results

        def done(results):
            if not isinstance(results, list):
                results = [
                    (
                        spec,
                        {
                            "ok": False,
                            "output": f"Performance Lab failed before completing: {results}",
                        },
                    )
                    for spec in self.specs
                ]
            for spec, result in results:
                self._update_metric(spec, result)
            self.run_all_button.configure(state=tk.NORMAL)
            score = sum(spec["weight"] for spec, result in results
                        if isinstance(result, dict) and result.get("ok"))
            passed = sum(1 for spec, result in results
                         if isinstance(result, dict) and result.get("ok"))
            try:
                db.add_performance_run({
                    "score": score, "passed": passed, "total": len(self.specs),
                })
            except Exception:
                pass  # history logging is best-effort, never blocks the run result
            self._render_history()

        self.app._run_bg(run_all, done)