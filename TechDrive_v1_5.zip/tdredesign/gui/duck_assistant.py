#!/usr/bin/env python3
"""
gui/duck_assistant.py — Duck Assistant
=========================================
A small floating ⚒ button that opens a chat-style window answering common
PC-repair questions from a local, hand-written knowledge base. No network
calls of any kind - matching, formatting, and every answer live entirely
in this file.

Wired up from techdrive.py as:

    self.duck_assistant = DuckAssistant(self, theme=self.theme)

and toggled from Settings via .show() / .hide() (see gui/settings.py's
Duck Assistant section).
"""

import re
import math
import threading
import tkinter as tk
from tkinter import ttk

from gui import fluent as fl
from gui.widgets import round_rect
from gui.duck_multilang_data import MULTILANG_GREETING_WORDS, MULTILANG_BADWORD_RESPONSES

from shared import database as db
from techdrive_modules import ai_provider


# ---------------------------------------------------------------------------
# Knowledge base: each entry is (keywords, answer). Checked in order, first
# match wins - keep more specific entries before broader ones.
# ---------------------------------------------------------------------------
KNOWLEDGE_BASE = [
    (
        ["slow wifi", "slow internet speed"],
        "Before blaming the ISP: run a speed test over Ethernet if possible to rule out "
        "Wi-Fi interference, check how many devices are actively streaming/downloading, and "
        "make sure the router isn't overheating or years past its firmware update. 2.4GHz "
        "Wi-Fi is far more congested than 5GHz in apartment buildings - switching bands often "
        "helps immediately."
    ),
    (
        ["browser slow", "chrome slow", "edge slow"],
        "A slow browser is almost always too many extensions or too many open tabs eating "
        "RAM - check Task Manager (Shift+Esc inside Chrome/Edge shows per-tab/extension "
        "usage) to find the actual culprit rather than guessing. Clearing cached data "
        "(Ctrl+Shift+Delete) helps if a specific site feels sluggish."
    ),
    (
        ["takes long to boot", "slow startup", "boot time slow"],
        "Task Manager's Startup tab is the first stop - too many high-impact startup "
        "programs is the most common cause. A fast SSD as the boot drive fixes slow-boot "
        "issues on any system still running its OS off a spinning HDD more than almost "
        "anything else."
    ),
    (
        ["bios boot order", "boot from usb"],
        "To boot from USB, enter BIOS/UEFI setup (usually Del, F2, F10, or F12 right after "
        "power-on - check your manufacturer's key) and either change the boot order or use "
        "the one-time boot menu key to pick the USB drive directly without a permanent "
        "change."
    ),
    (
        ["clicking noise hard drive", "hard drive making noise"],
        "A clicking or grinding noise from a spinning hard drive is a serious warning sign of "
        "imminent failure, not something to ignore - back up everything on it immediately and "
        "stop normal use, since continuing to run a clicking drive risks losing data entirely."
    ),
    (
        ["upgrade ram", "add more ram", "how much ram do i need"],
        "Check Task Manager's Performance → Memory tab during normal use first - if it's "
        "regularly near full, more RAM will help; if usage stays well below the total "
        "installed, adding more won't speed anything up. Also confirm your motherboard/laptop "
        "supports the amount and speed you're planning to add before buying."
    ),
    (
        ["upgrade to ssd", "hdd to ssd", "should i get an ssd"],
        "An SSD is the single biggest everyday-speed upgrade for any system still running an "
        "HDD as its boot drive - boot times, app launches, and file operations all improve "
        "dramatically. TechDrive's Clone Disk tool can migrate the existing Windows "
        "installation directly onto a new SSD without a fresh install."
    ),
    (
        ["blue screen", "bsod", "crash screen", "stop code"],
        "A Blue Screen of Death (BSOD) means Windows hit an error it couldn't "
        "recover from and had to restart.\n\n"
        "Common causes: faulty/overheating RAM, failing hard drive, a bad "
        "driver (especially after a recent update), or corrupted system files.\n\n"
        "What to check:\n"
        "1. Note the stop code (e.g. MEMORY_MANAGEMENT, IRQL_NOT_LESS_OR_EQUAL) "
        "shown on the blue screen — it points to the likely cause.\n"
        "2. Open Event Viewer → Windows Logs → System, and look for Critical "
        "or Error entries around the crash time.\n"
        "3. If it started after installing a driver or update, that's the "
        "first suspect.\n\n"
        "✦ Use TechDrive's BSOD Crash Analyzer to pull the stop code and "
        "recent crash dumps automatically."
    ),
    (
        ["slow", "sluggish", "lagging", "freezing", "freeze", "hangs", "laggy"],
        "A slow PC is almost always one (or more) of these:\n\n"
        "1. Too many programs launching at startup\n"
        "2. Low free RAM, or a nearly-full hard drive\n"
        "3. Malware, adware, or bundled bloatware\n"
        "4. Overheating causing the CPU to throttle itself\n"
        "5. A failing/aging hard drive (especially a spinning HDD, not SSD)\n\n"
        "What to check first: Task Manager → Startup tab (disable anything you "
        "don't recognize or need at boot), and Task Manager → Performance tab "
        "to see if CPU, RAM, or Disk is pegged at 100%.\n\n"
        "✦ Use TechDrive's Startup Manager + Disk Cleanup to tackle the two "
        "most common causes in a couple of clicks."
    ),
    (
        ["hard drive", "hdd", "ssd", "disk health", "smart data", "chkdsk", "disk failing"],
        "Hard drive health is usually checked via SMART data — a set of "
        "self-reported health attributes every modern drive tracks "
        "(reallocated sectors, pending sectors, temperature, power-on hours).\n\n"
        "Warning signs: rising 'Reallocated Sector Count' or 'Pending Sector "
        "Count', unusual clicking/grinding noises (HDDs only), or Windows "
        "reporting errors when reading/writing files.\n\n"
        "Windows' built-in `chkdsk` can scan for and attempt to fix file-system "
        "errors, but it can't fix a physically failing drive — if SMART shows "
        "reallocated sectors climbing, back up your data and plan to replace "
        "the drive.\n\n"
        "✦ Use TechDrive's Disk Health Check for a plain-language SMART "
        "summary instead of raw attribute numbers."
    ),
    (
        ["boot", "won't start", "wont start", "startup loop", "black screen at startup", "not booting"],
        "Boot issues generally come from one of:\n\n"
        "1. A corrupted boot sector or boot configuration data (BCD)\n"
        "2. A failing hard drive that can no longer be read reliably\n"
        "3. A bad Windows Update that didn't finish installing cleanly\n"
        "4. A recently added driver or piece of hardware conflicting at startup\n\n"
        "First things to try: boot into Safe Mode (hold Shift while clicking "
        "Restart, or interrupt boot 3 times to trigger Automatic Repair) — if "
        "Safe Mode works, the problem is software, not hardware. From there, "
        "System Restore to a point before the issue started is often the "
        "fastest fix.\n\n"
        "✦ Use TechDrive's Boot Repair Tool + System Restore Manager to "
        "walk through both without hunting for the right menus."
    ),
    (
        ["ram", "memory problem", "memory error", "memtest", "reseat"],
        "RAM problems can look like almost anything: random BSODs, programs "
        "crashing unpredictably, or a PC that won't boot at all.\n\n"
        "To test: Windows has a built-in Memory Diagnostic (search "
        "'Windows Memory Diagnostic' in the Start menu) - it reboots and runs "
        "a scan before Windows loads. For a more thorough test, MemTest86 run "
        "overnight is the gold standard.\n\n"
        "If you're comfortable opening the case: reseating the RAM sticks "
        "(remove and firmly reinsert them) fixes a surprising number of "
        "'random crash' issues caused by a stick working loose.\n\n"
        "✦ Use TechDrive's RAM Info tool to confirm what's installed before "
        "you go shopping for a replacement stick."
    ),
    (
        ["windows update", "update stuck", "update failed", "update loop", "won't update"],
        "Windows Update problems usually fall into: updates stuck "
        "downloading/installing, updates that fail and roll back repeatedly, "
        "or a PC stuck in an update loop on restart.\n\n"
        "The standard fix order:\n"
        "1. Run the built-in Windows Update Troubleshooter (Settings → "
        "Troubleshoot → Other troubleshooters)\n"
        "2. If that doesn't help, a DISM + SFC repair often clears corrupted "
        "update components\n"
        "3. As a last resort, resetting the Windows Update components "
        "(stopping the service and clearing the SoftwareDistribution folder) "
        "fixes most stubborn cases\n\n"
        "✦ Use TechDrive's DISM Tool + SFC Scanner to run steps 2-3 without "
        "typing commands manually."
    ),
    (
        ["recover", "deleted file", "recover file", "lost file", "undelete", "file recovery"],
        "If you deleted a file and it's not in the Recycle Bin: stop saving "
        "new files to that drive immediately. Deleted files aren't actually "
        "erased right away - the space is just marked reusable, so anything "
        "you save afterward can overwrite the data you're trying to recover.\n\n"
        "From there, a file-recovery scan looking for recoverable file "
        "signatures on the drive is your best shot - success depends heavily "
        "on how much has been written to the drive since the deletion.\n\n"
        "✦ Use TechDrive's File Explorer's recovery scan to search for "
        "recoverable files without installing anything else."
    ),
    (
        ["dll missing", "dll not found", "vcruntime", "msvcp"],
        "A missing DLL error usually means a program's runtime library didn't install "
        "correctly. Reinstalling the affected program first is the safest fix; if several "
        "unrelated programs all complain about DLLs, installing the latest Microsoft Visual "
        "C++ Redistributable (x64 and x86) covers most of them at once."
    ),
    (
        ["0x80070057", "0x8007000d", "windows update error code"],
        "Most Windows Update error codes starting with 0x8007 point to corrupted update "
        "files or a permissions problem in the update cache. Clearing the SoftwareDistribution "
        "folder and re-running Windows Update is the standard fix - TechDrive's DISM Tool + "
        "SFC Scanner automate the repair steps around it."
    ),
    (
        ["safe mode", "boot into safe mode"],
        "To boot into Safe Mode: hold Shift while clicking Restart from the Start menu, then "
        "choose Troubleshoot → Advanced options → Startup Settings → Restart, and press 4 (or "
        "F4) for plain Safe Mode. If Windows won't boot at all, interrupting startup three "
        "times in a row (holding the power button) usually triggers Automatic Repair, which "
        "offers the same menu."
    ),
    (
        ["system restore", "restore point"],
        "System Restore rolls Windows system files and settings back to an earlier snapshot "
        "without touching your personal files - it's the fastest fix when something broke "
        "right after an update or driver install. Find it via Control Panel → Recovery → "
        "Open System Restore, or search 'Create a restore point' in the Start menu."
    ),
    (
        ["sfc scannow", "system file checker", "corrupted system files"],
        "`sfc /scannow` checks protected Windows system files against a known-good copy and "
        "repairs any that are corrupted. If it reports errors it couldn't fix, run "
        "`DISM /Online /Cleanup-Image /RestoreHealth` first (it repairs the underlying repair "
        "image SFC pulls from), then run SFC again."
    ),
    (
        ["reset this pc", "factory reset", "reinstall windows"],
        "'Reset this PC' (Settings → System → Recovery) reinstalls Windows while optionally "
        "keeping your personal files - it's less drastic than a full reinstall and fixes most "
        "deep software corruption. Choose 'Keep my files' first; only go to 'Remove everything' "
        "if the problem survives that."
    ),
    (
        ["task manager", "end task", "unresponsive program"],
        "Task Manager (Ctrl+Shift+Esc) is the fastest way to force-close a frozen program - "
        "select it under Processes and click End Task. The Performance tab there also shows "
        "live CPU/RAM/disk/GPU usage, which is the quickest way to spot what's actually "
        "bogging the system down."
    ),
    (
        ["device manager", "yellow exclamation", "unknown device"],
        "A yellow exclamation mark in Device Manager means Windows can't fully communicate "
        "with that device - almost always a missing or outdated driver. Right-click it → "
        "Update driver → Search automatically; if that fails, look up the exact hardware ID "
        "(Details tab → Property → Hardware Ids) and search for that instead of the generic "
        "device name."
    ),
    (
        ["disk cleanup", "free up space", "low disk space"],
        "Disk Cleanup (search for it in the Start menu) removes temp files, old Windows "
        "Update leftovers, and Recycle Bin contents in a few clicks. For a bigger win, check "
        "'Clean up system files' in the same tool - it can reclaim 10-20GB from old update "
        "backups (Windows.old) that regular cleanup skips."
    ),
    (
        ["page file", "virtual memory", "out of memory"],
        "The page file is disk space Windows uses as overflow when physical RAM fills up - "
        "'out of memory' errors despite having free disk space usually mean the page file is "
        "set too small or disabled. Settings are under System Properties → Advanced → "
        "Performance Settings → Advanced → Virtual memory; 'Automatically manage' is right "
        "for almost everyone."
    ),
    (
        ["startup programs", "too many programs at startup", "disable startup"],
        "Task Manager's Startup tab (Ctrl+Shift+Esc) lists everything set to launch when "
        "Windows boots, with a rough 'Startup impact' rating. Disabling anything you don't "
        "recognize or don't need immediately is one of the single biggest wins for boot "
        "speed."
    ),
    (
        ["windows activation", "not activated", "activate windows"],
        "An unactivated Windows license still works, just with a watermark and a few "
        "personalization features locked. Settings → System → Activation shows the current "
        "status; if a genuine license stopped activating after a hardware change, the "
        "built-in Activation Troubleshooter usually re-links it automatically."
    ),
    (
        ["registry editor", "regedit", "edit registry"],
        "The Registry Editor (regedit) holds low-level Windows and app settings - it's "
        "powerful but has no undo, so always export the key you're about to change first "
        "(File → Export) in case something goes wrong."
    ),
    (
        ["group policy", "gpedit"],
        "Local Group Policy Editor (gpedit.msc) exposes deeper Windows settings than the "
        "regular Settings app, mostly around security, updates, and restrictions - it's only "
        "available on Pro/Enterprise editions, not Home."
    ),
    (
        ["event viewer", "windows logs"],
        "Event Viewer (search 'Event Viewer' in Start) logs everything significant Windows "
        "does, including the exact cause of crashes and failed services. Windows Logs → "
        "System is the first place to look after a crash; filter by 'Critical' and 'Error' "
        "to cut the noise."
    ),
    (
        ["wifi keeps dropping", "wifi disconnecting", "wireless keeps disconnecting"],
        "Random Wi-Fi drops are usually a driver power-saving setting - Device Manager → "
        "Network adapters → your Wi-Fi card → Properties → Power Management, and untick "
        "'Allow the computer to turn off this device to save power'. If it persists, updating "
        "the Wi-Fi driver directly from the laptop/card manufacturer (not just Windows Update) "
        "often clears it."
    ),
    (
        ["no internet access", "limited connectivity", "cant connect to internet"],
        "'No internet' with Wi-Fi/Ethernet showing connected usually means the connection to "
        "the router is fine but something's wrong past it - try `ipconfig /release` then "
        "`ipconfig /renew` in an admin Command Prompt, or `ipconfig /flushdns` if specific "
        "sites won't load while others do."
    ),
    (
        ["ip address conflict", "duplicate ip"],
        "An IP conflict happens when two devices on the network grab the same address - "
        "usually from a static IP colliding with the router's DHCP range. Switching that "
        "device back to 'Obtain an IP address automatically' (Network adapter properties → "
        "IPv4) almost always fixes it."
    ),
    (
        ["dns not working", "dns server not responding"],
        "'DNS server not responding' means your PC can reach the internet but can't translate "
        "website names to addresses. Try switching to a public DNS like 1.1.1.1 or 8.8.8.8 in "
        "the adapter's IPv4 settings, and run `ipconfig /flushdns` to clear any stale cached "
        "entries."
    ),
    (
        ["router won't connect", "modem not working", "no lights on router"],
        "Start with a full power cycle: unplug both the modem and router, wait 30 seconds, "
        "plug the modem back in first and let it fully reconnect, then the router. If a "
        "router's lights are all off, check the power adapter with a different outlet before "
        "assuming the router itself is dead."
    ),
    (
        ["vpn not connecting", "vpn keeps disconnecting"],
        "VPN connection failures are usually blocked ports (some networks block VPN traffic "
        "outright), an expired/incorrect login, or a Windows Firewall rule getting in the "
        "way. Switching the VPN's protocol (e.g. from UDP to TCP, or to a different port like "
        "443) in its settings gets past most network-level blocks."
    ),
    (
        ["ethernet not detected", "ethernet cable not working", "no ethernet connection"],
        "If Ethernet shows 'not connected' with the cable plugged in, try a different cable "
        "and port first - both fail more often than the network adapter itself. If neither "
        "helps, Device Manager → Network adapters → uninstall the adapter and let Windows "
        "reinstall it on reboot."
    ),
    (
        ["network adapter missing", "no network adapters found"],
        "A vanished network adapter almost always means the driver got removed or corrupted, "
        "not that the hardware died. Device Manager → Action menu → 'Scan for hardware "
        "changes' often brings it back; if not, downloading the driver directly from the "
        "manufacturer's site on another device and installing it manually will."
    ),
    (
        ["port forwarding", "open ports"],
        "Port forwarding tells your router to send specific incoming traffic to one device on "
        "your network - needed for hosting game servers, some security cameras, or remote "
        "access tools. It's configured in the router's admin page (usually 192.168.1.1 or "
        "192.168.0.1), not on the PC itself."
    ),
    (
        ["mac address", "find mac address"],
        "A device's MAC address (its unique network hardware ID) shows up in Windows via "
        "`ipconfig /all` in Command Prompt, under 'Physical Address' for the relevant "
        "adapter."
    ),
    (
        ["bluetooth not working", "bluetooth won't turn on", "bluetooth missing"],
        "If Bluetooth has vanished from Settings entirely, it's almost always a driver issue - "
        "Device Manager → Bluetooth → uninstall the adapter, then reboot so Windows "
        "reinstalls it. If it's present but won't pair anything, forgetting the device on "
        "both ends and re-pairing from scratch clears most stuck-pairing states."
    ),
    (
        ["mouse not working", "mouse lagging", "mouse cursor freezing"],
        "For a wireless mouse: try a fresh battery and a different USB port for the receiver "
        "first (USB 3.0 ports can cause interference with 2.4GHz receivers - a USB 2.0 port "
        "or a short extension cable often fixes stuttering). For a wired mouse, a different "
        "cable/port rules out the easy causes fast."
    ),
    (
        ["keyboard not typing", "keys not working", "keyboard unresponsive"],
        "If only some keys fail, it's usually a physical/debris issue; if the whole keyboard "
        "stops, check Device Manager for a driver conflict first. For laptops, an accidental "
        "Fn-lock or a stuck Num Lock can make it look like keys 'aren't working' when they're "
        "just typing something unexpected."
    ),
    (
        ["usb device not recognized", "usb not detected"],
        "'USB Device Not Recognized' usually means a driver glitch, not dead hardware - try "
        "the device in a different port first, then Device Manager → Universal Serial Bus "
        "controllers → uninstall every 'USB Root Hub' entry and reboot to force Windows to "
        "rebuild the USB stack from scratch."
    ),
    (
        ["webcam not working", "camera not detected"],
        "Camera issues are frequently a privacy-setting problem, not a hardware fault - check "
        "Settings → Privacy & security → Camera and make sure both 'Camera access' and access "
        "for the specific app are turned on. If it's genuinely not detected at all, check "
        "Device Manager → Cameras for a driver error."
    ),
    (
        ["headphones not working", "no sound from headphones"],
        "If headphones show as connected but produce no sound, right-click the speaker icon → "
        "Sound settings, and make sure the headphones (not the built-in speakers) are "
        "selected as the output device. For 3.5mm jacks, some laptops need the sound driver "
        "to detect the jack insertion correctly, which a driver reinstall usually fixes."
    ),
    (
        ["microphone not working", "mic not detected"],
        "Check Settings → Privacy & security → Microphone first - Windows blocks app "
        "microphone access by default in some configurations, which looks identical to a "
        "hardware fault. If access is already allowed, make sure the right input device is "
        "selected under Sound settings → Input."
    ),
    (
        ["printer not printing", "printer offline", "printer not responding"],
        "A printer showing 'Offline' when it's physically on almost always means Windows lost "
        "track of its connection - Settings → Bluetooth & devices → Printers & scanners, "
        "remove it, then re-add it fresh. Clearing a stuck print queue (services.msc → Print "
        "Spooler → Stop, delete files in "
        "C:\\Windows\\System32\\spool\\PRINTERS, then Start again) fixes jobs that won't print."
    ),
    (
        ["scanner not working", "cant scan document"],
        "Scanner problems are usually driver-related even when the device shows up fine in "
        "Windows Scan - installing the full manufacturer software package (not just the "
        "driver) often unlocks features the generic driver doesn't support."
    ),
    (
        ["external hard drive not showing up", "external drive not detected"],
        "First check Disk Management (right-click Start → Disk Management) - if the drive "
        "shows up there but not in File Explorer, it likely just needs a drive letter "
        "assigned or has an unsupported file system. If it doesn't show in Disk Management "
        "at all, try a different USB cable/port before suspecting the drive itself."
    ),
    (
        ["screen flickering", "monitor flickering"],
        "Flickering is most often a refresh rate mismatch or an outdated GPU driver - check "
        "Settings → Display → Advanced display and confirm it's set to your monitor's native "
        "refresh rate, then update the graphics driver directly from NVIDIA/AMD/Intel rather "
        "than relying on Windows Update."
    ),
    (
        ["black screen", "monitor no signal"],
        "'No signal' means the monitor and PC aren't communicating at all - check the cable "
        "is fully seated and try a different port/cable, and if you have a dedicated GPU, "
        "make sure the monitor cable is plugged into the graphics card, not the motherboard's "
        "built-in output."
    ),
    (
        ["resolution wrong", "screen resolution stuck"],
        "If Windows won't offer your monitor's actual native resolution, it's almost always "
        "an outdated or generic driver - Settings → Display → Advanced display will show "
        "what Windows thinks the monitor supports; installing the correct GPU driver usually "
        "unlocks the full list."
    ),
    (
        ["dual monitor not working", "second monitor not detected"],
        "Windows+P opens the quick display-mode switcher (Extend/Duplicate/Second screen "
        "only) - if the second monitor still isn't detected, click 'Detect' in Settings → "
        "Display, and confirm the cable is connected to the GPU's output, not an unused "
        "motherboard port on a system with a dedicated graphics card."
    ),
    (
        ["screen tearing", "graphics stuttering"],
        "Screen tearing happens when the frame rate and monitor refresh rate fall out of "
        "sync - enabling V-Sync in the game/app, or G-Sync/FreeSync in the GPU control panel "
        "if your monitor supports it, fixes it directly."
    ),
    (
        ["graphics driver crashed", "display driver stopped responding"],
        "'Display driver stopped responding and has recovered' means the GPU driver crashed "
        "and Windows restarted it - occasional occurrences under heavy load usually mean an "
        "outdated driver or an overclock that's slightly too aggressive; frequent crashes at "
        "idle point to a driver reinstall (clean install via DDU) being needed."
    ),
    (
        ["color calibration", "colors look wrong", "screen colors off"],
        "Windows' built-in color calibration wizard (search 'Calibrate display color') walks "
        "through gamma, brightness, and contrast in a few minutes and covers most everyday "
        "cases - for accurate color work, a hardware calibrator is worth it since software-only "
        "calibration can't measure your specific panel."
    ),
    (
        ["dead pixel", "stuck pixel"],
        "A stuck pixel (showing one color constantly) can sometimes be revived by gently "
        "massaging that spot on the screen while it's off, or by displaying rapidly-cycling "
        "colors over it for a few minutes. A truly dead pixel (showing no color at all) is "
        "permanent hardware failure with no software fix."
    ),
    (
        ["no sound", "audio not working", "sound not working"],
        "Start with the basics that get missed: check the volume mixer (right-click the "
        "speaker icon → Open Volume mixer) for an app muted individually, and confirm the "
        "correct playback device is selected as default. If both check out, Settings → System "
        "→ Sound → Troubleshoot catches most driver-level issues automatically."
    ),
    (
        ["audio crackling", "sound distorted", "crackling sound"],
        "Crackling audio is usually one of: an outdated audio driver, the sample "
        "rate/bit-depth set higher than the hardware handles well (try 16-bit 44100Hz under "
        "playback device properties → Advanced), or audio enhancements causing conflicts - "
        "turning those off is worth trying first since it takes ten seconds."
    ),
    (
        ["bluetooth audio lag", "bluetooth speaker delay"],
        "Bluetooth audio lag is a codec limitation, not a bug - SBC (the default fallback "
        "codec) has noticeable delay, while aptX Low Latency or AAC (on supported "
        "hardware/apps) cut it dramatically. There's no fix for SBC lag beyond switching to "
        "wired or a device supporting a lower-latency codec."
    ),
    (
        ["realtek audio", "audio driver update"],
        "Most desktop and many laptop motherboards use Realtek audio chips - for the most "
        "reliable driver, get it from the motherboard/laptop manufacturer's support page "
        "rather than Realtek's generic site, since manufacturers customize the driver for "
        "their specific hardware."
    ),
    (
        ["laptop won't turn on", "laptop not powering on"],
        "First isolate power vs. display: hold the power button 10+ seconds to force a full "
        "shutdown, then try powering on plugged in with the battery removed if possible (or "
        "just plugged in if it's not removable). If fans spin and lights turn on but the "
        "screen stays black, that points to a display/GPU issue rather than a dead board."
    ),
    (
        ["battery draining fast", "battery not holding charge", "battery health"],
        "Right-click Start → Terminal (Admin) and run `powercfg /batteryreport` - it "
        "generates an HTML report showing design capacity vs. current full-charge capacity, "
        "which tells you objectively how much the battery has degraded rather than guessing "
        "from how it 'feels'."
    ),
    (
        ["laptop overheating", "fan loud", "fan running constantly"],
        "Constant loud fans usually mean dust-clogged vents restricting airflow, or thermal "
        "paste that's dried out on an older laptop. Compressed air through the vents (with "
        "the laptop off) is the easy first step; if it's still hot after that, the paste "
        "likely needs reapplying, which is a bigger job."
    ),
    (
        ["laptop not charging", "plugged in not charging"],
        "'Plugged in, not charging' with the charger connected is a known Windows/driver "
        "quirk on many laptops, not always a hardware fault - try a full shutdown (not "
        "restart) then power back on, and check Device Manager → Batteries for a driver "
        "error on the Microsoft ACPI-compliant control method battery entry."
    ),
    (
        ["power plan", "balanced vs performance", "power saver mode"],
        "Windows' power plans trade performance for battery life - Balanced suits most daily "
        "use, Best Performance uncaps CPU boost behavior for demanding tasks at the cost of "
        "battery/heat, and Power Saver caps things down for maximum runtime. Find them under "
        "Settings → System → Power & battery."
    ),
    (
        ["sleep mode issues", "wont wake from sleep", "random wake ups"],
        "A PC waking itself up randomly is usually a device set to allow wake timers - "
        "`powercfg /lastwake` in Command Prompt shows what caused the most recent wake, and "
        "Device Manager → device properties → Power Management lets you stop specific devices "
        "(network adapters are common culprits) from waking the system."
    ),
    (
        ["virus", "malware", "infected"],
        "Windows Security (built into Windows 10/11, formerly Windows Defender) is a fully "
        "capable antivirus on its own for most people - run a full scan under Virus & threat "
        "protection first. If something's actively blocking Windows Security itself from "
        "running, that's a strong sign of a real infection needing a scan from a bootable "
        "rescue disk instead."
    ),
    (
        ["ransomware", "files encrypted", "ransom note"],
        "If files are encrypted with a ransom note demanding payment: disconnect from the "
        "network immediately to stop it spreading, don't pay (there's no guarantee of "
        "recovery and it funds more attacks), and check nomoreransom.org - free decryption "
        "tools exist for many older ransomware families."
    ),
    (
        ["popup ads", "browser hijacked", "redirected to strange sites"],
        "Constant pop-ups or browser redirects usually mean adware, not a serious virus - "
        "check installed browser extensions for anything unfamiliar and remove it, then check "
        "Windows' installed apps list for anything you don't recognize that was installed "
        "around when the problem started."
    ),
    (
        ["windows firewall", "firewall blocking"],
        "Windows Firewall blocks unsolicited incoming connections by default, which "
        "occasionally breaks things like local multiplayer games or file sharing between "
        "PCs - allowing a specific app through it (Settings → Privacy & security → Windows "
        "Security → Firewall & network protection → Allow an app) is safer than disabling the "
        "firewall entirely."
    ),
    (
        ["forgot windows password", "locked out of windows", "cant log in"],
        "If it's a Microsoft account password, resetting it via account.live.com/password/reset "
        "from another device unlocks it immediately once you're back online. For a local "
        "account with no recovery set up, a password-reset disk made in advance is the only "
        "clean fix - without one, it typically requires a reinstall."
    ),
    (
        ["two factor authentication", "2fa", "authenticator app"],
        "Two-factor authentication adds a second proof of identity (usually a code from an "
        "app like Microsoft/Google Authenticator) beyond just your password - if you lose "
        "access to the authenticator, most services provide backup codes generated at setup "
        "time specifically for this situation, so it's worth saving those somewhere safe."
    ),
    (
        ["encrypt files", "encryption", "bitlocker"],
        "BitLocker (built into Windows Pro/Enterprise) encrypts an entire drive so its "
        "contents are unreadable without the recovery key or the account it's tied to - "
        "TechDrive's BitLocker Manager (Volume Manager category) handles enabling, locking, "
        "and unlocking it."
    ),
    (
        ["vpn what is it", "what does a vpn do"],
        "A VPN routes your internet traffic through an encrypted tunnel to another server, "
        "hiding your traffic from your local network/ISP and masking your apparent location - "
        "it doesn't make you anonymous online by itself, since the VPN provider can still see "
        "your traffic, and websites can still identify you through logins/cookies."
    ),
    (
        ["browser crashing", "chrome keeps crashing", "tab crashed"],
        "A single tab crashing ('Aw, Snap!' in Chrome) is usually that page's fault, not the "
        "browser - reload it. If the whole browser crashes repeatedly, disable extensions one "
        "by one (start with ad blockers and anything recently added) since a bad extension is "
        "the most common cause."
    ),
    (
        ["clear cache", "clear browsing data", "cookies"],
        "Ctrl+Shift+Delete opens the clear-browsing-data dialog in every major browser - "
        "clearing 'Cached images and files' fixes most 'site looks broken/outdated' problems "
        "without logging you out of anything, while clearing cookies will sign you out "
        "everywhere."
    ),
    (
        ["default browser", "change default browser"],
        "Settings → Apps → Default apps → search for your browser and set it as default for "
        "web links and HTML files - Windows sometimes resets this back to Edge after a major "
        "update, which is worth checking if links suddenly open in the 'wrong' browser."
    ),
    (
        ["extension not working", "browser extension broken"],
        "A misbehaving extension is often fixed by disabling and re-enabling it, or removing "
        "and reinstalling from the store - extensions occasionally get corrupted during a "
        "browser update in ways a simple toggle won't fix."
    ),
    (
        ["file wont delete", "cant delete file", "file in use"],
        "'File is in use by another program' means something still has it open, even if you "
        "can't see what - Task Manager won't show this directly, but restarting Explorer "
        "(right-click the taskbar → Task Manager → find Windows Explorer → Restart) releases "
        "most stuck file locks without a full reboot."
    ),
    (
        ["compress files", "zip files", "extract zip"],
        "Windows can create and extract .zip files natively - right-click a file/folder → "
        "Send to → Compressed (zipped) folder to create one, or right-click a .zip → Extract "
        "All to unpack it. For other formats (.rar, .7z), a dedicated tool like 7-Zip is "
        "needed since Windows doesn't handle those natively."
    ),
    (
        ["file explorer crashing", "explorer.exe not responding"],
        "If File Explorer freezes or crashes repeatedly, clearing its cache "
        "(Folder Options → View → Clear File Explorer History) fixes a surprising number of "
        "cases, especially if it's tied to browsing a specific folder with corrupted "
        "thumbnails."
    ),
    (
        ["change file associations", "wrong program opens file"],
        "Right-click any file → Open with → Choose another app, and check 'Always use this "
        "app' to fix it permanently - or manage all associations at once under Settings → "
        "Apps → Default apps → search by file type."
    ),
    (
        ["hidden files", "show hidden files"],
        "File Explorer → View → Show → Hidden items reveals files/folders marked hidden - "
        "useful for troubleshooting, but be cautious about deleting anything unfamiliar there "
        "since some are hidden specifically because Windows needs them."
    ),
    (
        ["long path names", "path too long", "filename too long"],
        "Windows historically capped file paths at 260 characters, which shows up as a "
        "confusing 'path too long' error on deeply nested folders - enabling long path "
        "support (Group Policy: Computer Configuration → Administrative Templates → System → "
        "Filesystem → Enable Win32 long paths, Pro edition only) removes the limit."
    ),
    (
        ["shadow copy", "previous versions", "restore previous version"],
        "Right-click a file or folder → Properties → Previous Versions shows snapshots taken "
        "automatically by Windows (via File History or System Restore points) - it's a quick "
        "way to recover an earlier version of a file you overwrote, if the feature was "
        "enabled beforehand."
    ),
    (
        ["app wont install", "installation failed", "setup error"],
        "A failed install is often a permissions or leftover-files issue from a previous "
        "attempt - run the installer as Administrator (right-click → Run as administrator), "
        "and if a previous install was interrupted, fully uninstall any remnants first via "
        "Settings → Apps before trying again."
    ),
    (
        ["app wont uninstall", "cant remove program"],
        "If a program refuses to uninstall through Settings → Apps, Microsoft's own "
        "'Program Install and Uninstall Troubleshooter' (search Microsoft support for it) "
        "cleans up broken uninstall entries that the normal path can't handle."
    ),
    (
        ["office not activating", "microsoft office error"],
        "Office activation problems usually stem from a stale sign-in token - fully sign out "
        "of all Office apps and Windows' own Microsoft account (Settings → Accounts → Email & "
        "accounts), then sign back in fresh before retrying activation."
    ),
    (
        ["excel not responding", "word crashing"],
        "Office apps freezing often trace back to a corrupted add-in - launch in Safe Mode "
        "(hold Ctrl while opening the app) which skips loading add-ins, and if that runs "
        "fine, disable add-ins one by one under File → Options → Add-ins to find the culprit."
    ),
    (
        ["adobe not opening", "pdf wont open"],
        "If PDFs won't open at all, check which app is actually set as the default for .pdf "
        "files (Settings → Apps → Default apps) - it's easy to end up with a broken or "
        "half-uninstalled reader still claiming the file association."
    ),
    (
        ["java not working", "java update"],
        "Most modern software has moved away from needing a separate Java install, so if an "
        "app suddenly complains about missing Java, it likely needs the specific runtime "
        "version it was built against - check the app's own documentation rather than just "
        "installing the latest Java version, which isn't always compatible."
    ),
    (
        [".net framework", "net framework missing"],
        ".NET Framework errors mean an app needs a specific version Windows doesn't have "
        "installed - Windows Features (search 'Turn Windows features on or off') lets you "
        "enable older .NET Framework versions directly without a separate download in most "
        "cases."
    ),
    (
        ["app data corrupted", "settings reset", "preferences lost"],
        "Many apps store their settings/data under %AppData% or %LocalAppData% - if an app's "
        "settings mysteriously reset, that folder for the app may have gotten corrupted or "
        "wiped, which a reinstall alone won't always fix since installers often skip "
        "recreating that data."
    ),
    (
        ["low fps", "game running slow", "frame rate drops"],
        "Start by confirming what's actually the bottleneck - Task Manager's Performance tab "
        "during gameplay shows if CPU, GPU, or RAM is maxed out. Updating the GPU driver, "
        "closing background apps (especially browsers with many tabs), and checking the game "
        "isn't set to a resolution/settings beyond what the hardware handles are the first "
        "things to try."
    ),
    (
        ["game crashing", "game keeps crashing to desktop"],
        "Crash-to-desktop with no error is most often an outdated GPU driver or corrupted "
        "game files - verifying game file integrity (right-click the game in Steam/Epic → "
        "Properties → verify) catches corruption, and a clean GPU driver reinstall via DDU "
        "rules out driver conflicts."
    ),
    (
        ["controller not detected", "gamepad not working"],
        "Windows → Settings → Bluetooth & devices → Devices shows if a controller is paired "
        "at all before troubleshooting further. For wired controllers, a different USB port "
        "and cable rule out the easy causes; for wireless, re-pairing from scratch clears "
        "most stuck connections."
    ),
    (
        ["steam not launching", "steam wont open"],
        "If Steam won't launch at all, deleting its cache (delete the 'appcache' folder "
        "inside the Steam install directory, not the whole folder) forces it to rebuild "
        "clean without touching your installed games."
    ),
    (
        ["mouse input lag", "keyboard input lag gaming"],
        "For gaming, high polling rate mice (1000Hz) and disabling any pointer "
        "acceleration/smoothing in Windows (Control Panel → Mouse → Pointer Options → uncheck "
        "'Enhance pointer precision') reduce perceived input lag more than almost anything "
        "else software-side."
    ),
    (
        ["overclocking", "how to overclock"],
        "Overclocking pushes CPU/GPU/RAM beyond rated speeds for more performance at the cost "
        "of heat and stability - always change one setting at a time and stress-test after "
        "each change (TechDrive's System Stability Test works well for this), since crashes "
        "from an unstable overclock can be subtle rather than immediate."
    ),
    (
        ["shutting down automatically", "random restarts", "pc restarts by itself"],
        "Unexpected restarts are most often overheating (the CPU protecting itself) or a "
        "driver crash configured to auto-restart instead of showing a blue screen - check "
        "Event Viewer's System log around the restart time, and disable 'Automatically "
        "restart' under System Properties → Startup and Recovery to actually see the crash "
        "screen next time instead of just a reboot."
    ),
    (
        ["fast startup", "hybrid shutdown"],
        "Fast Startup (enabled by default) hibernates the kernel session on shutdown for a "
        "quicker next boot - it occasionally causes odd issues after driver/hardware changes "
        "since the system isn't truly starting fresh; disabling it (Control Panel → Power "
        "Options → Choose what the power buttons do) is a common troubleshooting step."
    ),
    (
        ["stuck on windows logo", "stuck at loading screen"],
        "Stuck at the spinning-dots/logo screen for more than a few minutes usually means a "
        "driver or startup service is hanging - force a shutdown, then boot and let Windows "
        "try Automatic Repair, or boot into Safe Mode to isolate whether a third-party driver "
        "is the cause."
    ),
    (
        ["secure boot", "tpm error", "windows 11 requirements"],
        "Secure Boot and TPM 2.0 are Windows 11's hardware security requirements - both are "
        "toggled in BIOS/UEFI settings (often under a 'Security' tab), and most PCs made "
        "since roughly 2016 have the hardware, just with these features switched off by "
        "default."
    ),
    (
        ["motherboard beep codes", "computer beeping"],
        "Beep codes vary by BIOS manufacturer (AMI, Award, Phoenix all differ), but the "
        "general pattern is: one short beep on a successful boot, and longer or repeated "
        "patterns for hardware failures - checking the motherboard manual for its specific "
        "beep code table is the only reliable way to decode it."
    ),
    (
        ["cpu temperature high", "cpu overheating"],
        "Idle temps above roughly 50°C or load temps consistently above 85-90°C (varies by "
        "CPU model) suggest a cooling problem - reapplying thermal paste and confirming the "
        "cooler is properly seated fixes most cases on systems more than a couple of years "
        "old."
    ),
    (
        ["gpu temperature high", "graphics card overheating"],
        "Modern GPUs are designed to run hot (70-83°C under load is often normal, check your "
        "specific model's spec), but if it's throttling performance or shutting down, cleaning "
        "dust from the fans/heatsink and confirming case airflow isn't blocked are the first "
        "checks before assuming the card itself is failing."
    ),
    (
        ["thermal paste", "reapply thermal paste"],
        "Thermal paste dries out and loses effectiveness over 2-5 years - if temps have crept "
        "up gradually on an otherwise-unchanged system, that's the classic sign. A pea-sized "
        "dot in the center of the CPU is enough; the cooler's pressure spreads it, so more "
        "isn't better."
    ),
    (
        ["power supply failing", "psu problems"],
        "A failing PSU shows up as random shutdowns under load, failure to power on at all, "
        "or burning smells (stop using it immediately if you smell that) - it's one of the "
        "few components worth replacing preemptively if it's old and underpowered for a "
        "recently-upgraded GPU, since it can damage other components on failure."
    ),
    (
        ["cmos battery", "bios settings reset"],
        "If BIOS settings (date/time, boot order) keep resetting to default every time the "
        "PC is unplugged, the small CMOS battery on the motherboard (usually a CR2032 coin "
        "cell) has likely died - it's inexpensive and easy to replace on desktop "
        "motherboards."
    ),
    (
        ["new pc build wont post", "no post", "no display on boot"],
        "'No POST' (no display, no beeps, but fans spin) on a new build is almost always one "
        "of: RAM not fully seated, the CPU power cable not connected, or the GPU not fully "
        "seated in its slot - reseat each one individually, and try booting with just one "
        "RAM stick if you have multiple."
    ),
    (
        ["taskbar not working", "start menu not opening", "start button not responding"],
        "An unresponsive Start menu or taskbar is usually Windows Explorer crashing quietly - "
        "restart it via Task Manager (find Windows Explorer, click Restart) before trying "
        "anything more drastic. If it keeps happening, a corrupted user profile or a stuck "
        "update is worth checking next."
    ),
    (
        ["search not working", "windows search broken"],
        "If Windows Search stops returning results, rebuilding the search index (Settings → "
        "Search → Searching Windows → Advanced indexing options → Rebuild) fixes the vast "
        "majority of cases - it just takes time to complete for large drives."
    ),
    (
        ["notifications not working", "action center not showing"],
        "Check Settings → System → Notifications first for a global toggle, then the "
        "per-app list further down - apps can be individually blocked from sending "
        "notifications even when the global setting is on."
    ),
    (
        ["night light", "blue light filter"],
        "Night Light (Settings → System → Display → Night light) shifts the screen toward "
        "warmer tones on a schedule to reduce blue light in the evening - it can be scheduled "
        "automatically by sunset/sunrise or set to fixed times."
    ),
    (
        ["dark mode", "light mode", "windows theme"],
        "Settings → Personalization → Colors lets you set light or dark mode separately for "
        "Windows and individual apps - not every app respects the system setting, especially "
        "older desktop software, so some may need their own theme toggle found in their own "
        "settings."
    ),
    (
        ["clipboard history", "copy paste history"],
        "Windows+V opens clipboard history, letting you paste from several previous "
        "copies instead of just the last one - it needs to be turned on first under Settings "
        "→ System → Clipboard if it doesn't open immediately."
    ),
    (
        ["snap layouts", "window snapping"],
        "Dragging a window to the edge of the screen (or hovering the maximize button on "
        "Windows 11) offers Snap Layouts for quickly arranging multiple windows side by side "
        "- Windows key + arrow keys does the same thing without touching the mouse."
    ),
    (
        ["virtual desktops", "multiple desktops"],
        "Windows+Tab opens Task View, where you can create separate virtual desktops "
        "(Windows+Ctrl+D for a new one, Windows+Ctrl+Left/Right to switch) - handy for "
        "keeping work and personal apps completely separated without extra monitors."
    ),
    (
        ["accessibility settings", "narrator", "magnifier"],
        "Windows' built-in accessibility tools (Settings → Accessibility) include Narrator "
        "(screen reader, Windows+Ctrl+Enter), Magnifier (Windows++), and high-contrast themes "
        "- all work without installing anything extra."
    ),
    (
        ["language pack", "change display language"],
        "Settings → Time & language → Language & region lets you add a display language and "
        "switch the whole system to it - the keyboard layout and display language are "
        "separate settings, so adding a language pack doesn't automatically change how your "
        "keyboard types."
    ),
    (
        ["onedrive not syncing", "onedrive sync issues"],
        "A stuck OneDrive sync is often fixed by pausing and resuming it (click the OneDrive "
        "icon in the system tray → pause syncing, wait a moment, then resume) - if that "
        "doesn't help, 'Reset OneDrive' (search for the exact reset command in Microsoft's "
        "support docs) rebuilds the sync database without touching your actual files."
    ),
    (
        ["microsoft account vs local account", "switch to local account"],
        "A Microsoft account syncs settings across devices and enables cloud features "
        "(OneDrive, Store apps); a local account stays entirely on that one PC. You can "
        "switch either direction under Settings → Accounts → Your info without losing files "
        "already on the machine."
    ),
    (
        ["family safety", "parental controls"],
        "Microsoft Family Safety (family.microsoft.com) manages screen time, app/game "
        "restrictions, and content filtering for child accounts across Windows, Xbox, and "
        "mobile - it's set up online, then applies automatically once the child signs into "
        "their linked account on the device."
    ),
    (
        ["sync settings across devices", "windows settings sync"],
        "Settings → Accounts → Windows backup (or 'Sync your settings' on older builds) "
        "controls which preferences (theme, passwords, language) sync to other Windows "
        "devices signed into the same Microsoft account."
    ),
    (
        ["not enough memory to complete this operation"],
        "This error can appear even with free RAM available if it's actually a page file "
        "problem, a 32-bit app hitting its memory ceiling, or fragmented virtual memory - "
        "closing other memory-heavy apps first, and confirming the page file is set to "
        "'Automatically manage', resolves most cases."
    ),
    (
        ["access is denied", "administrator permission required"],
        "'Access is denied' usually means the action needs Administrator rights - "
        "right-click the app/file and choose 'Run as administrator', or check the file/folder "
        "Properties → Security tab if it's about permissions on a specific file rather than "
        "an app needing elevation."
    ),
    (
        ["the parameter is incorrect", "invalid parameter"],
        "On external drives, this often means the drive's file system or partition table got "
        "corrupted - check it with `chkdsk /f` first; if the drive won't even show its "
        "properties, TechDrive's Check Partition Table Errors tool can confirm whether the "
        "table itself is damaged."
    ),
    (
        ["this app cant run on your pc"],
        "This means the installer doesn't match your Windows architecture (32-bit vs "
        "64-bit) or edition - check System → About for '64-bit operating system' vs the "
        "installer you downloaded, since a 32-bit-only installer won't run '64-bit "
        "required' software and vice versa in some cases."
    ),
    (
        ["critical process died", "kernel security check failure"],
        "These blue screens point to a corrupted system file or a failing driver interfering "
        "with a core Windows process - `sfc /scannow` and a DISM repair are the first steps; "
        "if it started right after a driver/hardware change, rolling that back first is "
        "faster."
    ),
    (
        ["disk read error", "disk boot failure"],
        "'A disk read error occurred' at boot points to the boot drive's partition table or "
        "boot files, not necessarily drive failure - TechDrive's Windows Boot Repair tool "
        "(bootrec sequence) rebuilds the boot configuration; if the drive also shows SMART "
        "warnings, back up first since the underlying disk may genuinely be failing."
    ),
    (
        ["operating system not found"],
        "This means the BIOS/UEFI can't find a valid boot partition - check the boot order "
        "hasn't switched to a USB drive or network boot by mistake first, since that's the "
        "most common innocent cause; if the actual drive is missing from BIOS entirely, that "
        "points to a cable, connection, or drive failure."
    ),
    (
        ["backup strategy", "how often should i backup", "3-2-1 backup"],
        "The 3-2-1 rule is the standard: 3 copies of anything important, on 2 different types "
        "of storage, with 1 copy off-site (cloud, or a drive kept somewhere else entirely) - "
        "it protects against drive failure, theft, and local disasters all at once, which any "
        "single backup method alone doesn't."
    ),
    (
        ["file history", "windows backup feature"],
        "File History (Settings → System → Storage → Advanced storage settings → Backup "
        "options, or search 'File History') automatically backs up versions of your files to "
        "a chosen drive on a schedule - it's built into Windows and needs no third-party "
        "software, just an external or network drive to save to."
    ),
    (
        ["cloud storage full", "onedrive storage full", "google drive full"],
        "Cloud storage filling up usually means old backups or large media files "
        "accumulating unnoticed - most services show a breakdown by file type in their web "
        "interface, which is faster for finding what to clean up than scrolling through "
        "folders manually."
    ),
    (
        ["how to backup before reinstalling windows"],
        "Before a reinstall: back up your Documents/Desktop/Pictures folders, export browser "
        "bookmarks, note down any software license keys, and check for anything stored only "
        "locally in specific apps (like email clients storing mail on-disk) that cloud sync "
        "wouldn't have caught."
    ),
    (
        ["how to take a screenshot", "screenshot windows"],
        "Windows+Shift+S opens the Snipping Tool overlay for capturing a specific area "
        "(copies to clipboard automatically); Windows+PrtScn saves a full-screen shot "
        "straight to the Pictures\\Screenshots folder without any extra steps."
    ),
    (
        ["how to record screen", "screen recording windows"],
        "Windows+Alt+R starts/stops the built-in Xbox Game Bar screen recorder (works for "
        "most apps, not just games) - Windows+G opens the full Game Bar if you need audio "
        "source options or a webcam overlay first."
    ),
    (
        ["task scheduler", "schedule a task"],
        "Task Scheduler (search 'Task Scheduler' in Start) runs a program or script "
        "automatically on a schedule or trigger (like at login, or when idle) - it's the "
        "built-in way to automate routine maintenance without third-party software."
    ),
    (
        ["command prompt vs powershell"],
        "PowerShell is the modern successor to Command Prompt - both still ship with "
        "Windows, but PowerShell supports far more powerful scripting and is what most "
        "current system administration guides assume you're using; Command Prompt remains "
        "for legacy batch scripts and simple commands."
    ),
    (
        ["run as administrator shortcut"],
        "To always run a specific shortcut elevated: right-click it → Properties → Advanced "
        "→ check 'Run as administrator' - saves having to right-click and choose it manually "
        "every single time for tools you always need elevated."
    ),
    (
        ["environment variables", "path variable"],
        "Environment variables (like PATH) are system-wide settings many programs read at "
        "startup - edit them via 'Edit the system environment variables' (search Start), then "
        "Environment Variables button; changes only take effect in newly-opened programs, not "
        "ones already running."
    ),
    (
        ["product key lost", "find windows product key"],
        "If Windows came pre-installed and was never reinstalled, the license is usually "
        "tied digitally to your Microsoft account or the motherboard itself rather than "
        "needing a physical key at all - `wmic path softwarelicensingservice get "
        "OA3xOriginalProductKey` in an admin Command Prompt can recover a key embedded in the "
        "firmware on OEM machines."
    ),
    (
        ["laptop battery replacement", "how to replace laptop battery"],
        "Whether a battery is user-replaceable varies hugely by model - some laptops have a "
        "single external release latch, others require opening the entire chassis. Checking "
        "the manufacturer's official service manual for the specific model before attempting "
        "it avoids voiding warranty or damaging other components."
    ),
]

FALLBACK_ANSWER = (
    "I'm not sure about that one! I can help with: Blue Screen of Death, "
    "slow PC performance, hard drive health, boot issues, RAM problems, "
    "Windows Update troubles, and recovering deleted files. Try asking "
    "about one of those! ✦"
)

QUICK_QUESTIONS = [
    "What's a blue screen?",
    "Why is my PC slow?",
    "How to check hard drive health?",
    "How to fix boot issues?",
    "How do I test my RAM?",
    "Windows Update is stuck",
]


# ---------------------------------------------------------------------------
# Chit-chat: casual conversation (greetings, thanks, small talk) - separate
# from the technical KNOWLEDGE_BASE above, and the one place where each
# personality mode gets genuinely different wording rather than just a tone
# wrapper, since these are short and hand-written per mode anyway.
# ---------------------------------------------------------------------------
CHITCHAT = [
    (["hi", "hello", "hey", "yo", "sup", "howdy"], {
        "funny": "✦ Hey there! What's broken today?",
        "normal": "Hi there! What can I help you with?",
        "corporate": "Greetings. How may I be of assistance today?",
    }),
    (["good morning"], {
        "funny": "✦ Morning! Ready when you are — what's up?",
        "normal": "Good morning! What can I help with?",
        "corporate": "Good morning. Please let me know how I can assist you.",
    }),
    (["good night", "goodnight"], {
        "funny": "✦ Good night! Don't let the blue screens bite. ☾",
        "normal": "Good night! Come back anytime.",
        "corporate": "Good night. This assistant remains available at your convenience.",
    }),
    (["how are you", "how's it going", "hows it going"], {
        "funny": "✦ Living the dream — floating in the corner of your screen, "
                 "waiting for someone to ask about blue screens. Living my best life. You?",
        "normal": "Doing well, thanks for asking! How can I help?",
        "corporate": "Operating within normal parameters. How may I assist you today?",
    }),
    (["who are you", "what are you"], {
        "funny": "✦ I'm your Assistant — part rubber-duck debugging buddy, part PC "
                 "repair encyclopedia.",
        "normal": "I'm your Assistant, TechDrive's built-in help - I answer PC repair "
                  "questions from a knowledge base, fully offline.",
        "corporate": "I am the TechDrive Assistant, an offline knowledge-base tool "
                     "for PC repair guidance.",
    }),
    (["are you real", "are you ai", "are you a robot", "are you human"], {
        "funny": "✦ I'm not a live AI unless you've connected one in Settings — "
                 "otherwise I'm just a built-in offline knowledge base.",
        "normal": "I'm a simple offline lookup tool, not a live AI - just a built-in "
                  "knowledge base of PC repair answers.",
        "corporate": "This is an offline, rule-based assistant. No live AI model or "
                     "internet connection is involved.",
    }),
    (["thanks", "thank you", "thx", "ty"], {
        "funny": "✦ Anytime! Go forth and fix that PC.",
        "normal": "You're welcome! Let me know if anything else comes up.",
        "corporate": "You are welcome. Please reach out if further assistance is required.",
    }),
    (["bye", "goodbye", "see ya", "see you", "later"], {
        "funny": "✦ Bye! I'll be here, floating, judging your startup programs silently.",
        "normal": "Bye! Come back anytime you need help.",
        "corporate": "Goodbye. This assistant remains available for future inquiries.",
    }),
    (["sorry", "my bad", "oops"], {
        "funny": "✦ No worries — I've seen way worse than whatever you just did.",
        "normal": "No worries at all!",
        "corporate": "No apology necessary.",
    }),
    (["lol", "haha", "lmao", "funny"], {
        "funny": "✦ Glad someone appreciates the humor. I've been workshopping material.",
        "normal": "Glad that helped!",
        "corporate": "Acknowledged.",
    }),
    (["nice", "cool", "awesome", "great job", "good job"], {
        "funny": "✦ *takes a bow, nearly falls over*",
        "normal": "Thanks! Happy to help.",
        "corporate": "Thank you for the feedback.",
    }),
    (["what can you do", "help me", "what do you know"], {
        "funny": "✦ I know a suspicious amount about blue screens, slow PCs, boot "
                 "issues, RAM, Windows Update disasters, and file recovery. Try me!",
        "normal": "I can help with things like blue screens, slow PCs, boot issues, "
                  "RAM problems, Windows Update, and file recovery. Just ask!",
        "corporate": "This assistant provides guidance on common PC issues, including "
                     "system errors, performance, boot failures, memory diagnostics, "
                     "update failures, and data recovery.",
        }),
]

_EMOJI_PATTERN = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF]+"
)


def _strip_emoji(text):
    return _EMOJI_PATTERN.sub("", text).strip()


def _apply_mode(answer, mode):
    """Technical KNOWLEDGE_BASE answers stay factually identical across
    modes on purpose - only the tone wrapper changes. Rewriting all ~150
    technical answers three different ways would either balloon the file
    into mostly-duplicated content or risk introducing inaccuracies in
    two of the three copies - not worth it for a tone setting. Corporate
    mode strips emoji and drops the flourish; funny mode adds a short one;
    normal mode (the default) is unchanged."""
    if mode == "corporate":
        return _strip_emoji(answer)
    if mode == "funny":
        return answer + "\n\n✦ (That's the technical term.)"
    return answer


_MULTILANG_GREETING_REPLY = "Hello! I'm your offline computer assistant. How can I help you today?"


def get_answer(question, mode="normal"):
    """Pure function, no Tk dependency - easy to unit test on its own.
    Uses word-boundary matching (not raw substring) so short keywords
    like 'ram' don't false-positive inside unrelated words like
    'parameter' - a real bug that showed up once the knowledge base grew
    past a couple dozen entries.

    mode: 'funny' | 'normal' | 'corporate' - see _apply_mode's docstring
    for what actually changes per mode and what deliberately doesn't.

    Check order: bad-language redirect first (regardless of language),
    then chit-chat/greetings (English + the multilingual greeting list),
    then the technical knowledge base, then the fallback.

    Returns None (instead of a string) when nothing but the technical
    KNOWLEDGE_BASE would have matched and the caller has an AI provider
    configured - callers should treat None as "ask the AI provider
    instead of guessing from keywords." Bad-language, chit-chat, and
    greeting replies are still returned directly since those aren't
    things the AI provider should be handling anyway."""
    q = (question or "").lower().strip()

    for trigger, response in MULTILANG_BADWORD_RESPONSES:
        if re.search(r"\b" + re.escape(trigger.lower()) + r"\b", q):
            return _apply_mode(response, mode)

    for keywords, replies in CHITCHAT:
        if any(re.search(r"\b" + re.escape(kw) + r"\b", q) for kw in keywords):
            return replies.get(mode, replies["normal"])

    if any(re.search(r"\b" + re.escape(word) + r"\b", q) for word in MULTILANG_GREETING_WORDS):
        return _apply_mode(_MULTILANG_GREETING_REPLY, mode)

    if ai_provider.is_configured():
        return None

    for keywords, answer in KNOWLEDGE_BASE:
        if any(re.search(r"\b" + re.escape(kw) + r"\b", q) for kw in keywords):
            return _apply_mode(answer, mode)

    return _apply_mode(FALLBACK_ANSWER, mode)


class AssistantIcon(tk.Canvas):
    """Custom-drawn '</>' code badge for the floating assistant launcher.

    Pure canvas vector art (no image files) so it matches the rest of the
    Fluent/Aero chrome exactly: a soft outer glow, a blue->violet gradient
    ring (built from angular pie-slice bands, same trick used for the
    "Quick Scan" gradient button), an Aero glass highlight arc across the
    top, and a "</>" code glyph standing in for "Assistant" — deliberately
    generic/code-themed rather than any third-party logo.
    """

    def __init__(self, parent, theme, aero=True, size=54, command=None):
        self.theme = theme
        self.aero = aero
        self.size = size
        self.command = command
        self.backdrop = parent["bg"]
        self._t = 0.0          # hover glow progress 0..1
        self._pressed = False
        self._anim = None
        super().__init__(parent, width=size, height=size, bg=self.backdrop,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._animate(1.0))
        self.bind("<Leave>", lambda e: self._animate(0.0))
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self._draw()

    # -- drawing ---------------------------------------------------------
    def _draw(self):
        self.delete("all")
        s = self.size
        cx = cy = s / 2
        g_start, g_end = fl.ACCENT_GRAD
        if self._t:
            g_start = fl.mix(g_start, fl.lighten(g_start, 0.20), self._t)
            g_end = fl.mix(g_end, fl.lighten(g_end, 0.20), self._t)
        if self._pressed:
            g_start, g_end = fl.darken(g_start, 0.10), fl.darken(g_end, 0.10)

        # --- outer soft glow (a few fading rings, brighter on hover) ----
        glow_layers = 4
        base_glow = 0.10 + (0.14 if self.aero else 0.0) + 0.10 * self._t
        for i in range(glow_layers, 0, -1):
            t = base_glow * (glow_layers - i + 1) / glow_layers
            r = s / 2 - 1 + i * 2.4
            color = fl.mix(self.backdrop, self.theme["ACCENT_GLOW"], t)
            self.create_oval(cx - r, cy - r, cx + r, cy + r,
                             fill=color, outline="")

        # --- gradient ring badge (angular pie-slice sweep) --------------
        ring_r = s / 2 - 2
        bands = 48
        for i in range(bands):
            a0 = i * 360 / bands
            a1 = (i + 1) * 360 / bands
            # Sweep 0->1->0 across the circle so the ring reads as a single
            # smooth blue->violet->blue gradient with no hard seam.
            phase = i / bands
            frac = phase * 2 if phase < 0.5 else (1 - phase) * 2
            color = fl.mix(g_start, g_end, frac)
            self.create_arc(cx - ring_r, cy - ring_r, cx + ring_r, cy + ring_r,
                            start=a0, extent=(a1 - a0) + 0.6,
                            fill=color, outline="", style="pieslice")

        # --- inner glass face (leaves a slim gradient ring visible) -----
        inner_r = ring_r - 4
        face = fl.glass(self.theme, "CARD_BG", self.aero, 0.30 + 0.15 * self._t)
        self.create_oval(cx - inner_r, cy - inner_r, cx + inner_r, cy + inner_r,
                         fill=face, outline="")

        # --- Aero glass highlight: bright arc across the top ------------
        if self.aero:
            hi_r = inner_r - 3
            self.create_arc(cx - hi_r, cy - hi_r * 1.35, cx + hi_r, cy + hi_r * 0.35,
                            start=25, extent=130,
                            fill=fl.mix(face, "#ffffff", 0.22), outline="",
                            style="chord")

        # --- chat-bubble + sparkle glyph, centered, faint accent-glow twin
        # A rounded speech bubble (drawn from primitives, no image file)
        # reads immediately as "assistant/chat" rather than "code editor",
        # with a small 4-point sparkle to signal it can reach an AI
        # provider when one's configured in Settings.
        bub_w, bub_h = s * 0.46, s * 0.34
        bx0, by0 = cx - bub_w / 2, cy - bub_h / 2 - s * 0.03
        bx1, by1 = cx + bub_w / 2, cy + bub_h / 2 - s * 0.03
        rad = bub_h * 0.42

        def _bubble(offset_x, offset_y, fill):
            ox0, oy0, ox1, oy1 = bx0 + offset_x, by0 + offset_y, bx1 + offset_x, by1 + offset_y
            self.create_oval(ox0, oy0, ox0 + 2 * rad, oy0 + 2 * rad, fill=fill, outline="")
            self.create_oval(ox1 - 2 * rad, oy0, ox1, oy0 + 2 * rad, fill=fill, outline="")
            self.create_oval(ox0, oy1 - 2 * rad, ox0 + 2 * rad, oy1, fill=fill, outline="")
            self.create_oval(ox1 - 2 * rad, oy1 - 2 * rad, ox1, oy1, fill=fill, outline="")
            self.create_rectangle(ox0 + rad, oy0, ox1 - rad, oy1, fill=fill, outline="")
            self.create_rectangle(ox0, oy0 + rad, ox1, oy1 - rad, fill=fill, outline="")
            # small tail pointing down-left, like a speech bubble
            tail_x, tail_y = ox0 + bub_w * 0.30, oy1
            self.create_polygon(tail_x - rad * 0.55, tail_y - rad * 0.3,
                                tail_x + rad * 0.35, tail_y - rad * 0.3,
                                tail_x - rad * 0.15, tail_y + rad * 1.1,
                                fill=fill, outline="")

        _bubble(0, 1, fl.mix(g_start, g_end, 0.5))   # faint accent-glow twin
        _bubble(0, 0, "#ffffff")

        # sparkle (4-point star) at the upper-right of the bubble
        spx, spy = cx + bub_w * 0.30, cy - bub_h * 0.62
        sp_r = s * 0.085
        pts = []
        for i in range(8):
            ang = i * 3.14159 / 4
            r = sp_r if i % 2 == 0 else sp_r * 0.35
            pts.append(spx + r * math.sin(ang))
            pts.append(spy - r * math.cos(ang))
        self.create_polygon(*pts, fill=fl.mix(g_start, g_end, 0.3), outline="")

    # -- motion ------------------------------------------------------------
    def _animate(self, target):
        if self._anim:
            self.after_cancel(self._anim)
            self._anim = None
        step = (target - self._t) / fl.HOVER_STEPS

        def frame(i=0):
            self._t = min(1.0, max(0.0, self._t + step))
            self._draw()
            if i + 1 < fl.HOVER_STEPS:
                self._anim = self.after(fl.HOVER_INTERVAL, frame, i + 1)
            else:
                self._t = target
                self._anim = None
                self._draw()

        frame()

    def _on_press(self, _e):
        self._pressed = True
        self._draw()

    def _on_release(self, _e):
        self._pressed = False
        self._draw()
        if self.command:
            self.command()

    def set_aero(self, aero):
        self.aero = aero
        self._draw()


class DuckAssistant:
    """Floating ⚒ button + chat window. Clean, obvious affordances:
    a real "Send →" button that's always visible (not just Enter-to-send),
    disabled while the entry is empty, plus a short "typing…" beat before
    each answer so it doesn't feel like a dead lookup table."""

    def __init__(self, parent, theme, host=None):
        self.parent = parent
        self.theme = theme
        self.chat_window = None
        self.chat_display = None
        self.question_entry = None
        self.send_button = None
        self._placeholder_active = False
        self._answer_job = None
        self._destroyed = False

        try:
            aero = bool(parent.is_aero_enabled())
        except Exception:
            aero = True
        # Keep the AI chat launcher in the Ribbon chrome instead of floating
        # over the dashboard. `parent` remains the main app for callbacks.
        self._launcher_host = host or parent
        self._launcher_size = 32 if host is not None else 54
        self.button = AssistantIcon(self._launcher_host, theme, aero=aero,
                                    size=self._launcher_size, command=self.toggle_chat)
        if host is not None:
            self.button.pack(side="right", padx=(4, 8), pady=2)
        else:
            self.button.place(relx=0.97, rely=0.94, anchor="se",
                              width=self._launcher_size, height=self._launcher_size)

    # ------------------------------------------------------------------
    @staticmethod
    def _mix(hex_color, amount=18):
        """Nudge a hex color slightly lighter, for a subtle hover effect."""
        try:
            h = hex_color.lstrip("#")
            r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
            r, g, b = (min(255, c + amount) for c in (r, g, b))
            return f"#{r:02x}{g:02x}{b:02x}"
        except Exception:
            return hex_color

    def _ensure_chat_window(self):
        if self.chat_window is not None and self.chat_window.winfo_exists():
            return
        theme = self.theme
        self.chat_window = tk.Toplevel(self.parent)
        self.chat_window.title("Assistant")
        self.chat_window.geometry("460x660")
        self.chat_window.minsize(380, 520)
        self.chat_window.configure(bg=theme["SURFACE"])
        self.chat_window.protocol("WM_DELETE_WINDOW", self.hide_chat)
        self.chat_window.transient(self.parent)

        # ---- header -----------------------------------------------------
        header = tk.Frame(self.chat_window, bg=theme["BG_LIGHT"])
        header.pack(fill="x")
        title_box = tk.Frame(header, bg=theme["BG_LIGHT"])
        title_box.pack(side="left", padx=12, pady=8, fill="x", expand=True)
        tk.Label(title_box, text="✦ Assistant", font=("Segoe UI", 12, "bold"),
                 bg=theme["BG_LIGHT"], fg=theme["FG"], anchor="w").pack(fill="x")
        tk.Label(title_box, text="Offline PC-repair helper — no internet needed",
                 font=("Segoe UI", 8), bg=theme["BG_LIGHT"], fg=theme["MUTED"],
                 anchor="w").pack(fill="x")
        close_btn = tk.Button(header, text="✕", command=self.hide_chat, bg=theme["BG_LIGHT"],
                              fg=theme["MUTED"], activebackground=theme["BG_LIGHT"],
                              relief="flat", bd=0, font=("Segoe UI", 11), cursor="hand2")
        close_btn.pack(side="right", padx=10)
        close_btn.bind("<Enter>", lambda e: close_btn.config(fg="#e74c3c"))
        close_btn.bind("<Leave>", lambda e: close_btn.config(fg=theme["MUTED"]))

        # ---- chat transcript (with a visible scrollbar) ------------------
        chat_frame = tk.Frame(self.chat_window, bg=theme["SURFACE"])
        # NOTE: packed at the very end of this method, on purpose. Tk's packer
        # hands out space in packing order, so a tall expanding transcript
        # packed first can squeeze the input row + Send button clean off the
        # bottom of the window (which is exactly what used to happen).
        scrollbar = ttk.Scrollbar(chat_frame)
        scrollbar.pack(side="right", fill="y")
        self.chat_display = tk.Text(chat_frame, bg=theme["SURFACE"], fg=theme["FG"],
                                    font=("Segoe UI", 10), wrap="word", height=8,
                                    state="disabled", relief="flat", bd=0, padx=6, pady=4,
                                    yscrollcommand=scrollbar.set, spacing3=6)
        self.chat_display.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.chat_display.yview)

        # Bubble-ish styling: right-aligned accent bubble for the user,
        # left-aligned quieter bubble for the duck. lmargin/rmargin keep
        # each bubble from touching the window edge.
        self.chat_display.tag_config("duck_bubble", background=theme["BG_LIGHT"],
                                     foreground=theme["FG"], font=("Segoe UI", 10),
                                     lmargin1=4, lmargin2=4, rmargin=60,
                                     spacing1=2, spacing3=8, wrap="word",
                                     justify="left")
        self.chat_display.tag_config("user_bubble", background=theme["ACCENT"],
                                     foreground="white", font=("Segoe UI", 10),
                                     lmargin1=60, lmargin2=60, rmargin=4,
                                     spacing1=2, spacing3=8, wrap="word",
                                     justify="right")
        self.chat_display.tag_config("duck_label", foreground="#f39c12",
                                     font=("Segoe UI", 8, "bold"), lmargin1=4, spacing3=1)
        self.chat_display.tag_config("user_label", foreground=theme["MUTED"],
                                     font=("Segoe UI", 8, "bold"), rmargin=4, justify="right",
                                     spacing3=1)
        self.chat_display.tag_config("typing", foreground=theme["MUTED"],
                                     font=("Segoe UI", 10, "italic"), lmargin1=4, spacing3=8)

        # ---- bottom-anchored rows: input row, then quick questions -------
        input_frame = tk.Frame(self.chat_window, bg=theme["SURFACE"])
        input_frame.pack(side="bottom", fill="x", padx=10, pady=(6, 10))

        # ---- quick questions ---------------------------------------------
        quick_frame = tk.Frame(self.chat_window, bg=theme["SURFACE"])
        quick_frame.pack(side="bottom", fill="x", padx=10, pady=(0, 4))
        tk.Label(quick_frame, text="✦ Quick questions", bg=theme["SURFACE"],
                 fg=theme["MUTED"], font=("Segoe UI", 8, "bold")).pack(anchor="w")
        qbox = tk.Frame(quick_frame, bg=theme["SURFACE"])
        qbox.pack(fill="x", pady=(3, 0))
        for i, q in enumerate(QUICK_QUESTIONS):
            b = tk.Button(qbox, text=q, command=lambda q=q: self.ask_question(q),
                         bg=theme["BG_LIGHT"], fg=theme["ACCENT"], activebackground=theme["BG_LIGHT"],
                         relief="flat", bd=0, anchor="w", padx=8, pady=4,
                         font=("Segoe UI", 8), cursor="hand2")
            b.grid(row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)
        qbox.grid_columnconfigure(0, weight=1)
        qbox.grid_columnconfigure(1, weight=1)

        # ---- input row + Send button --------------------------------------
        self.send_button = tk.Button(
            input_frame, text="Send  →", command=self._send,
            bg=theme["ACCENT"], fg="white", activebackground=theme["ACCENT"],
            disabledforeground=theme["MUTED"], relief="flat", bd=0,
            font=("Segoe UI", 10, "bold"), padx=18, pady=9, cursor="hand2",
        )
        self.send_button.pack(side="right")

        entry_wrap = tk.Frame(input_frame, bg=theme["BG_LIGHT"],
                              highlightthickness=1,
                              highlightbackground=theme["CARD_BORDER"],
                              highlightcolor=theme["ACCENT"])
        entry_wrap.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.question_entry = tk.Entry(entry_wrap, bg=theme["BG_LIGHT"], fg=theme["MUTED"],
                                       font=("Segoe UI", 10), relief="flat",
                                       insertbackground=theme["FG"], bd=0)
        self.question_entry.pack(fill="x", expand=True, ipady=10, padx=10)
        self._set_placeholder()
        self.question_entry.bind("<FocusIn>", self._clear_placeholder)
        self.question_entry.bind("<FocusOut>", self._restore_placeholder_if_empty)
        self.question_entry.bind("<Return>", lambda e: self._send())
        self.question_entry.bind("<KeyRelease>", lambda e: self._update_send_state())

        self._update_send_state()

        chat_frame.pack(side="top", fill="both", expand=True, padx=10, pady=(8, 4))

        mode = db.get_setting("duck_personality_mode", "normal")
        greetings = {
            "funny": "✦ Assistant reporting for duty! Ask me anything about "
                    "PC repair, Windows, or TechDrive.",
            "normal": "Hi! I'm your Assistant. Ask me anything about "
                     "PC repair, Windows, or TechDrive — everything I know "
                     "is built in, so this works fully offline, or connect "
                     "an AI provider in Settings for live answers too. ✦",
            "corporate": "Welcome. This assistant provides offline guidance on PC repair, "
                        "Windows, and TechDrive. No internet connection is required or used.",
        }
        self.add_message("✦", greetings.get(mode, greetings["normal"]))
        self.chat_window.withdraw()

    # ------------------------------------------------------------------
    # Placeholder text handling for the entry box
    # ------------------------------------------------------------------
    _PLACEHOLDER = "Ask me anything…"

    def _set_placeholder(self):
        self.question_entry.delete(0, "end")
        self.question_entry.insert(0, self._PLACEHOLDER)
        self.question_entry.config(fg=self.theme["MUTED"])
        self._placeholder_active = True

    def _clear_placeholder(self, event=None):
        if self._placeholder_active:
            self.question_entry.delete(0, "end")
            self.question_entry.config(fg=self.theme["FG"])
            self._placeholder_active = False

    def _restore_placeholder_if_empty(self, event=None):
        if not self.question_entry.get().strip():
            self._set_placeholder()
        self._update_send_state()

    def _current_text(self):
        return "" if self._placeholder_active else self.question_entry.get().strip()

    def _update_send_state(self):
        has_text = bool(self._current_text())
        self.send_button.config(
            state="normal" if has_text else "disabled",
            bg=self.theme["ACCENT"] if has_text else self.theme["BG_LIGHT"],
            fg="white" if has_text else self.theme["MUTED"],
            cursor="hand2" if has_text else "arrow",
        )

    def _send(self):
        text = self._current_text()
        if text:
            self.ask_question(text)

    # ------------------------------------------------------------------
    def toggle_chat(self):
        self._ensure_chat_window()
        if self.chat_window.winfo_viewable():
            self.hide_chat()
        else:
            self.show_chat()

    def show_chat(self):
        self._ensure_chat_window()
        self.chat_window.deiconify()
        self.chat_window.lift()
        self.chat_window.focus_force()
        self.question_entry.focus_set()

    def hide_chat(self):
        if self.chat_window is not None and self.chat_window.winfo_exists():
            self.chat_window.withdraw()

    def add_message(self, sender, message):
        self.chat_display.config(state="normal")
        if sender == "✦":
            self.chat_display.insert("end", "✦ Assistant\n", "duck_label")
            self.chat_display.insert("end", f"{message}\n", "duck_bubble")
        else:
            self.chat_display.insert("end", "You\n", "user_label")
            self.chat_display.insert("end", f"{message}\n", "user_bubble")
        self.chat_display.insert("end", "\n")
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")

    def _show_typing(self):
        self.chat_display.config(state="normal")
        self.chat_display.insert("end", "✦ is typing…\n", "typing")
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")

    def _hide_typing(self):
        self.chat_display.config(state="normal")
        self.chat_display.delete("end-2l", "end-1l")
        self.chat_display.config(state="disabled")

    def ask_question(self, question):
        if not question or not question.strip():
            return
        self._ensure_chat_window()
        self._clear_placeholder()
        self.question_entry.delete(0, "end")
        self._update_send_state()
        self.add_message("●", question)
        self._show_typing()
        # A short, honest beat before the answer lands - the knowledge base
        # lookup itself is instant, so without this it can read as if the
        # duck didn't actually "hear" the question.
        if self._answer_job is not None:
            try:
                self.chat_window.after_cancel(self._answer_job)
            except Exception:
                pass
        try:
            self._answer_job = self.chat_window.after(350, lambda: self._answer(question))
        except tk.TclError:
            self._answer_job = None

    def _answer(self, question):
        self._hide_typing()
        mode = db.get_setting("duck_personality_mode", "normal")
        local_answer = get_answer(question, mode)

        # get_answer returns None when nothing but keyword-matched KB
        # entries would have applied and an AI provider is configured -
        # in that case go straight to the AI instead of risking a wrong
        # or irrelevant keyword-matched offline answer.
        if local_answer is None:
            self._show_typing()
            self._ask_ai_provider(question)
        else:
            self.add_message("✦", local_answer)

    def _ask_ai_provider(self, question):
        """Runs the network call off the Tk main thread so the UI never
        freezes, then hands the result back via `after()`."""
        def worker():
            ok, text = ai_provider.ask(question)
            if not ok:
                text = (
                    "I couldn't find that in my offline knowledge base, and the "
                    f"online AI assistant hit a problem: {text}"
                )
            self.parent._post_ui(lambda text=text: self._deliver_ai_answer(text))

        threading.Thread(target=worker, daemon=True).start()

    def _deliver_ai_answer(self, text):
        if self._destroyed:
            return
        try:
            if self.chat_window is None or not self.chat_window.winfo_exists():
                return
        except tk.TclError:
            return
        self._hide_typing()
        self.add_message("✦", text)

    # ------------------------------------------------------------------
    def show(self):
        if self._launcher_host is not self.parent:
            self.button.pack(side="right", padx=(4, 8), pady=2)
        else:
            self.button.place(relx=0.97, rely=0.94, anchor="se",
                              width=self._launcher_size, height=self._launcher_size)

    def hide(self):
        self.button.pack_forget()
        self.button.place_forget()
        self.hide_chat()

    def destroy(self):
        self._destroyed = True
        if self._answer_job is not None and self.chat_window is not None:
            try:
                self.chat_window.after_cancel(self._answer_job)
            except Exception:
                pass
            self._answer_job = None
        if self.chat_window is not None and self.chat_window.winfo_exists():
            self.chat_window.destroy()
        if self.button.winfo_exists():
            self.button.destroy()
