#!/usr/bin/env python3
"""
TechDrive Diagnostic Engine
===========================

Turns a plain-language symptom into a small, evidence-first diagnostic
workflow.  The engine deliberately calls the same real, read-only checks
used by Health Center instead of inventing a diagnosis from the text alone:

    symptom -> targeted tests -> evidence -> likely area -> safe next action

It does not repair, delete, disable, or change anything on the PC.
"""

import datetime as _datetime
import os
import platform
import re
import tempfile
import time
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton, MeterBar
from shared import database as db
from gui.health_center import (
    _check_cpu,
    _check_drivers,
    _check_event_logs,
    _check_gpu,
    _check_network,
    _check_ram,
    _check_security,
    _check_windows_services as _check_services,
    _check_smart,
    _check_startup,
    _check_storage,
    _check_system_files,
    _check_updates,
    _is_windows,
    _item,
    _result,
)

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


def _check_storage_latency():
    """Measure a tiny local write + flush, without touching user files."""
    if not psutil:
        return _result("storage_latency", "Storage latency", 78, [_item(
            "Storage latency could not be measured",
            "psutil is not installed, so TechDrive cannot correlate the "
            "timing sample with disk I/O counters.",
            "Install the TechDrive runtime dependencies and run this test "
            "again when the symptom is present.",
            "info",
        )])
    path = None
    try:
        started = time.perf_counter()
        with tempfile.NamedTemporaryFile(prefix="techdrive_health_",
                                         suffix=".tmp", delete=False) as handle:
            path = handle.name
            handle.write(b"\0" * (256 * 1024))
            handle.flush()
            os.fsync(handle.fileno())
        elapsed = time.perf_counter() - started
        if elapsed <= 0.05:
            score, severity, label = 100, "good", "Storage write/flush latency is normal"
        elif elapsed <= 0.20:
            score, severity, label = 78, "warn", "Storage write/flush latency is elevated"
        else:
            score, severity, label = 52, "bad", "Storage write/flush latency is unusually high"
        return _result("storage_latency", "Storage latency", score, [_item(
            label,
            f"A 256 KB temporary write and flush took {elapsed * 1000:.0f} ms. "
            "This is a point-in-time signal and can be affected by antivirus, "
            "background updates, or another busy application.",
            "Repeat the diagnosis while the freeze is happening. If it stays "
            "high, back up important files and continue with Drive Health + "
            "SMART Analysis.",
            severity,
        )])
    except Exception as exc:
        return _result("storage_latency", "Storage latency", 72, [_item(
            "Storage latency test was inconclusive",
            f"TechDrive could not complete its temporary write/flush sample: {exc}",
            "Close applications that are actively writing and run the test "
            "again. No user file was modified.",
            "info",
        )])
    finally:
        if path:
            try:
                os.remove(path)
            except OSError:
                pass


def _check_disk_warnings():
    """Look for recent disk/filesystem provider warnings on Windows."""
    if not _is_windows():
        return _result("disk_warnings", "Disk event warnings", 82, [_item(
            "Windows disk providers were not queried",
            "Disk, Ntfs, storahci, iaStorA, and volmgr provider names are "
            "Windows Event Log sources.",
            "Run this diagnosis on the affected Windows PC to inspect the "
            "actual System log.",
            "info",
        )])
    from gui.health_center import _powershell
    script = (
        "$providers='disk','Ntfs','storahci','iaStorA','volmgr'; "
        "$start=(Get-Date).AddDays(-7); "
        "$events=@(Get-WinEvent -FilterHashtable "
        "@{LogName='System';Level=1,2;StartTime=$start} "
        "-ErrorAction SilentlyContinue | "
        "Where-Object {$providers -contains $_.ProviderName}); "
        "'COUNT=' + $events.Count; "
        "$events | Select-Object -First 3 -ExpandProperty Message"
    )
    ok, output = _powershell(script, timeout=35)
    match = re.search(r"COUNT=(\d+)", output or "", re.I)
    if match:
        count = int(match.group(1))
        if count == 0:
            return _result("disk_warnings", "Disk event warnings", 100, [_item(
                "No recent disk-provider warnings found",
                "Windows returned zero critical/error events from the common "
                "disk and filesystem providers in the last seven days.",
                "No action needed. Keep the timestamp if the freeze returns "
                "so a future event can be matched to it.",
            )])
        return _result("disk_warnings", "Disk event warnings",
                       65 if count < 5 else 42, [_item(
            f"{count} recent disk-provider warning(s) found",
            output[-1000:] if output else "Windows returned disk-provider events.",
            "Back up important files, then inspect the matching Event Viewer "
            "events before attempting repairs or replacing a drive.",
            "warn" if count < 5 else "bad",
        )])
    return _result("disk_warnings", "Disk event warnings", 74, [_item(
        "Disk-provider event query was inconclusive",
        output or "Windows returned no readable provider count.",
        "Open Event Viewer and review System events around the time of the "
        "freeze. TechDrive did not clear or alter the log.",
        "info",
    )])


def _check_temperature():
    """Read available thermal sensors; no stress test is started."""
    readings = []
    if psutil and hasattr(psutil, "sensors_temperatures"):
        try:
            for source, entries in (psutil.sensors_temperatures() or {}).items():
                for entry in entries:
                    if entry.current is not None:
                        readings.append((f"{source} {entry.label}".strip(),
                                         float(entry.current)))
        except Exception:
            pass
    if not readings and _is_windows():
        from gui.health_center import _powershell
        ok, output = _powershell(
            "Get-CimInstance MSAcpi_ThermalZoneTemperature "
            "-ErrorAction SilentlyContinue | "
            "ForEach-Object { '{0}|{1}' -f $_.InstanceName,"
            "([math]::Round(($_.CurrentTemperature / 10) - 273.15,1)) }",
            timeout=25,
        )
        for line in output.splitlines() if ok else []:
            if "|" in line:
                name, raw = line.split("|", 1)
                try:
                    readings.append((name.strip(), float(raw.strip())))
                except ValueError:
                    pass
    if not readings:
        return _result("temperature", "Temperature", 78, [_item(
            "No compatible thermal sensor was exposed",
            "TechDrive did not receive a readable CPU or ACPI temperature "
            "sensor from this machine. No stress test was started.",
            "Check the motherboard or laptop manufacturer's monitoring tool "
            "if overheating is the symptom.",
            "info",
        )])
    hottest_name, hottest = max(readings, key=lambda pair: pair[1])
    if hottest < 75:
        score, severity, title = 100, "good", "Available temperatures are normal"
    elif hottest < 90:
        score, severity, title = 76, "warn", "An available temperature is elevated"
    else:
        score, severity, title = 48, "bad", "An available temperature is high"
    return _result("temperature", "Temperature", score, [_item(
        f"{title}: {hottest:.1f}°C",
        f"Hottest exposed sensor: {hottest_name}. TechDrive read {len(readings)} "
        "sensor value(s) without starting a load test.",
        "Check airflow and fan operation, clear dust safely, and repeat the "
        "reading while the symptom is present. Avoid opening a power supply.",
        severity,
    )])


PROFILES = [
    {
        "name": "Freezes and hangs",
        "terms": ("freeze", "freezes", "freezing", "hang", "hangs", "stuck",
                  "locks up", "not responding", "randomly"),
        "area": "Storage subsystem",
        "tests": [
            ("CPU load", _check_cpu),
            ("RAM pressure", _check_ram),
            ("Storage usage", _check_storage),
            ("Storage latency", _check_storage_latency),
            ("SMART / physical disk", _check_smart),
            ("Disk event warnings", _check_disk_warnings),
            ("System event logs", _check_event_logs),
        ],
        "next_test": "Drive Health + SMART Analysis",
        "actions": [
            "Save a backup of important files before attempting any disk repair.",
            "Repeat the diagnosis while the freeze is happening so the evidence "
            "can be compared with a normal baseline.",
            "If disk warnings or latency remain elevated, use Drive Health + "
            "SMART Analysis before running a repair.",
        ],
    },
    {
        "name": "Slow performance",
        "terms": ("slow", "slower", "lag", "lags", "performance", "stutter",
                  "stutters", "takes forever", "high usage"),
        "area": "Performance pressure",
        "tests": [
            ("CPU load", _check_cpu),
            ("RAM pressure", _check_ram),
            ("Storage usage", _check_storage),
            ("Storage latency", _check_storage_latency),
            ("Startup programs", _check_startup),
        ],
        "next_test": "CPU, RAM + Startup Analysis",
        "actions": [
            "Use Task Manager to identify the process consuming the most CPU "
            "or memory before closing anything.",
            "Review Startup apps and disable only software you recognize and "
            "do not need at sign-in.",
            "Repeat the scan after closing heavy applications.",
        ],
    },
    {
        "name": "Crashes and blue screens",
        "terms": ("crash", "crashes", "blue screen", "bsod", "restarts",
                  "reboot", "reboots", "unexpected shutdown"),
        "area": "Windows, drivers, or memory",
        "tests": [
            ("RAM pressure", _check_ram),
            ("Drivers", _check_drivers),
            ("System files", _check_system_files),
            ("System event logs", _check_event_logs),
            ("Windows updates", _check_updates),
        ],
        "next_test": "Driver Problem + Event Log Analysis",
        "actions": [
            "Record the exact crash time and stop code if Windows shows one.",
            "Inspect Device Manager for warning icons instead of installing a "
            "random driver updater.",
            "Back up important files before running any repair command.",
        ],
    },
    {
        "name": "Network and internet problems",
        "terms": ("internet", "network", "wifi", "wi-fi", "ethernet", "online",
                  "connection", "dns", "website", "disconnect"),
        "area": "Network adapter or local connectivity",
        "tests": [
            ("Network adapters", _check_network),
            ("Windows services", _check_services),
            ("System event logs", _check_event_logs),
        ],
        "next_test": "Network Adapter + DNS Analysis",
        "actions": [
            "Check whether the affected device is Wi-Fi, Ethernet, or all "
            "connections before resetting anything.",
            "Run a targeted ping/DNS test and compare it with another device "
            "on the same network.",
            "Avoid a network reset until the adapter and router evidence is "
            "captured.",
        ],
    },
    {
        "name": "Overheating and fan noise",
        "terms": ("hot", "overheat", "overheating", "temperature", "fan",
                  "loud", "thermal"),
        "area": "Thermal subsystem",
        "tests": [
            ("Temperature sensors", _check_temperature),
            ("CPU load", _check_cpu),
            ("GPU inventory", _check_gpu),
        ],
        "next_test": "Thermal Sensor + CPU/GPU Monitor",
        "actions": [
            "Check vents and fans for dust while the PC is powered off.",
            "Repeat the temperature reading during the workload that causes "
            "the fan noise.",
            "Do not open a power supply or continue a workload if temperatures "
            "remain dangerously high.",
        ],
    },
    {
        "name": "Storage and drive problems",
        "terms": ("disk", "drive", "storage", "ssd", "hdd", "smart",
                  "corrupt", "file error", "slow drive"),
        "area": "Storage subsystem",
        "tests": [
            ("Storage usage", _check_storage),
            ("Storage latency", _check_storage_latency),
            ("SMART / physical disk", _check_smart),
            ("Disk event warnings", _check_disk_warnings),
            ("System files", _check_system_files),
        ],
        "next_test": "Drive Health + SMART Analysis",
        "actions": [
            "Back up irreplaceable files before testing or repairing a drive.",
            "Compare SMART status with disk-provider warnings; one green result "
            "does not guarantee a healthy drive.",
            "Only run a repair after the data is backed up and the evidence is "
            "saved.",
        ],
    },
    {
        "name": "Startup and boot problems",
        "terms": ("boot", "startup", "start", "login", "log in", "won't turn",
                  "takes too long"),
        "area": "Startup configuration or Windows boot",
        "tests": [
            ("Startup programs", _check_startup),
            ("Drivers", _check_drivers),
            ("System files", _check_system_files),
            ("Windows updates", _check_updates),
            ("System event logs", _check_event_logs),
        ],
        "next_test": "Startup + System File Analysis",
        "actions": [
            "Review Startup apps in Task Manager and disable only recognized "
            "nonessential entries.",
            "Keep the device connected to power while Windows updates are "
            "being reviewed.",
            "Capture the exact boot or login timestamp for Event Viewer.",
        ],
    },
]


def _select_profile(symptom):
    text = symptom.lower()
    best = None
    best_hits = 0
    for profile in PROFILES:
        hits = sum(1 for term in profile["terms"] if term in text)
        if hits > best_hits:
            best, best_hits = profile, hits
    if best:
        return best
    return {
        "name": "General PC problem",
        "area": "General system health",
        "tests": [
            ("CPU load", _check_cpu),
            ("RAM pressure", _check_ram),
            ("Storage usage", _check_storage),
            ("Network adapters", _check_network),
            ("System event logs", _check_event_logs),
            ("Security configuration", _check_security),
        ],
        "next_test": "Health Center full scan",
        "actions": [
            "Repeat the diagnosis with the symptom's exact time and any error "
            "message included.",
            "Run the recommended focused test next instead of opening tools "
            "at random.",
        ],
    }


def diagnose(symptom, progress=None):
    """Run a symptom-specific, evidence-backed diagnostic workflow."""
    symptom = " ".join((symptom or "").split())
    if not symptom:
        raise ValueError("Describe the problem before starting a diagnosis.")
    profile = _select_profile(symptom)
    tests = []
    for label, checker in profile["tests"]:
        if progress:
            progress(f"Running {label.lower()}…")
        try:
            result = checker()
        except Exception as exc:
            result = _result(label.lower().replace(" ", "_"), label, 55, [_item(
                f"{label} test stopped safely",
                f"TechDrive caught an error while reading this signal: {exc}",
                "Run the focused tool separately and keep the error details "
                "for troubleshooting.",
                "info",
            )])
        tests.append({"label": label, "result": result})

    evidence = []
    for test in tests:
        for finding in test["result"].get("items", []):
            evidence.append({
                "test": test["label"],
                "title": finding["title"],
                "explanation": finding["explanation"],
                "severity": finding["severity"],
            })
    scores = [test["result"]["score"] for test in tests]
    overall = round(sum(scores) / max(1, len(scores)))
    flagged = [test for test in tests if test["result"]["score"] < 85]
    likely_area = profile["area"]
    if flagged:
        likely_area += " — supported by " + ", ".join(
            test["label"] for test in flagged[:3])
    else:
        likely_area += " — no abnormal signal found in this snapshot"
    session_id = "TD-" + _datetime.datetime.now().strftime("%H%M%S%f")[-5:]
    return {
        "session_id": session_id,
        "symptom": symptom,
        "profile": profile["name"],
        "overall": overall,
        "status": "Evidence found" if flagged else "No abnormal signal found",
        "tests": tests,
        "evidence": evidence,
        "likely_area": likely_area,
        "actions": profile["actions"],
        "next_test": profile["next_test"],
        "timestamp": _datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "limited": not _is_windows(),
    }


class DiagnosticEnginePage(tk.Frame):
    """UI for describing a symptom and running the targeted workflow."""

    def __init__(self, parent, app):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        super().__init__(parent, bg=self.theme["BG"])
        self._running = False
        _canvas, self.content = make_scrollable(self, self.theme["BG"])
        self._build()

    def _build(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  DIAGNOSTIC ENGINE",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        tk.Label(header, text="Diagnostic Engine", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(anchor="w",
                                                               pady=(4, 2))
        tk.Label(
            header,
            text="Describe the symptom. TechDrive chooses focused tests, "
                 "collects evidence, and explains the next safe move.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=780, justify="left",
        ).pack(anchor="w")

        request = GlassCard(root, self.theme, aero=self.aero,
                            accent=self.theme["ACCENT"])
        request.pack(fill="x", padx=24, pady=(8, 14))
        body = request.body
        tk.Label(body, text="What is happening?", bg=request.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text="Use your own words, for example: My PC freezes "
                 "randomly when I open large files.", bg=request.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(
                     anchor="w", padx=18, pady=(0, 8))
        self.symptom = tk.Text(body, height=3, wrap="word",
                               bg=self.theme["LAYER_2"], fg=self.theme["FG"],
                               insertbackground=self.theme["FG"],
                               relief="flat", bd=0, font=fl.F_BODY())
        self.symptom.pack(fill="x", padx=18, pady=(0, 10))
        controls = tk.Frame(body, bg=request.fill)
        controls.pack(fill="x", padx=18, pady=(0, 16))
        self.run_button = FluentButton(
            controls, "RUN DIAGNOSTICS", command=self.start,
            theme=self.theme, aero=self.aero, kind="accent", icon="◉",
            width=205, height=44, backdrop=request.fill,
        )
        self.run_button.pack(side="left")
        self.status_var = tk.StringVar(
            value="Workflow: Symptoms → Tests → Evidence → Likely causes → Actions")
        tk.Label(controls, textvariable=self.status_var, bg=request.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=560, justify="left").pack(side="left", padx=16)

        self.results = tk.Frame(root, bg=self.theme["BG"])
        self.results.pack(fill="x", padx=24, pady=(0, 14))
        self._render_idle()

    def _render_idle(self):
        for child in self.results.winfo_children():
            child.destroy()
        card = GlassCard(self.results, self.theme, aero=self.aero,
                         accent=fl.GOOD)
        card.pack(fill="x")
        tk.Label(card.body, text="Evidence-first diagnosis", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(16, 4))
        tk.Label(
            card.body,
            text="The engine will run real local checks selected from the "
                 "symptom you enter. It will not guess a cause from text alone "
                 "and it will not apply a repair.",
            bg=card.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=780, justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 16))

    def start(self):
        if self._running:
            return
        symptom = self.symptom.get("1.0", "end").strip()
        if not symptom:
            self.status_var.set("Describe a symptom first; no diagnostics ran.")
            self.symptom.focus_set()
            return
        self._running = True
        self.run_button.configure(state="disabled")
        self.status_var.set("Selecting focused tests…")
        self.app._run_bg(
            lambda: diagnose(symptom, progress=self._set_progress),
            self._finish,
        )

    def _set_progress(self, text):
        try:
            self.app._post_ui(lambda text=text: self.status_var.set(text))
        except tk.TclError:
            pass

    def _finish(self, report):
        self._running = False
        self.run_button.configure(state="normal")
        if hasattr(report, "message"):
            self.status_var.set("Diagnosis stopped safely.")
            self._render_error(str(report))
            return
        suffix = " • Windows-only evidence is limited on this OS" if report["limited"] else ""
        try:
            db.add_diagnostic_session(report)
        except Exception:
            # The evidence report is still valid if history storage is
            # temporarily unavailable.
            pass
        self.status_var.set(f"Completed {report['session_id']} at "
                            f"{report['timestamp']}{suffix}")
        self._render_report(report)

    def _render_error(self, message):
        for child in self.results.winfo_children():
            child.destroy()
        card = GlassCard(self.results, self.theme, aero=self.aero, accent=fl.BAD)
        card.pack(fill="x")
        tk.Label(card.body, text="Diagnosis stopped safely", bg=card.fill,
                 fg=fl.BAD, font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(16, 4))
        tk.Label(card.body, text=message, bg=card.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=780, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 16))

    def _render_report(self, report):
        for child in self.results.winfo_children():
            child.destroy()
        score_color = fl.GOOD if report["overall"] >= 80 else \
            fl.WARN if report["overall"] >= 55 else fl.BAD
        summary = GlassCard(self.results, self.theme, aero=self.aero,
                            accent=score_color)
        summary.pack(fill="x", pady=(0, 14))
        body = summary.body
        tk.Label(body, text=f"Diagnostic Session #{report['session_id']}",
                 bg=summary.fill, fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text=report["symptom"], bg=summary.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE(),
                 wraplength=780, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 8))
        tk.Label(body, text=f"{report['status']}  •  Diagnostic confidence "
                 f"snapshot: {report['overall']}/100",
                 bg=summary.fill, fg=score_color,
                 font=fl.F_CARD_TITLE()).pack(anchor="w", padx=18)
        tk.Label(body, text=f"Likely area: {report['likely_area']}",
                 bg=summary.fill, fg=self.theme["TEXT_FG"],
                 font=fl.F_SMALL(), wraplength=780,
                 justify="left").pack(anchor="w", padx=18, pady=(6, 0))
        self._section(summary, "Tests performed", report["tests"])
        self._section(summary, "Evidence collected", report["evidence"])
        self._actions(summary, report)

    def _section(self, card, title, records):
        tk.Label(card.body, text=title, bg=card.fill, fg=self.theme["FG"],
                 font=fl.F_CARD_TITLE()).pack(anchor="w", padx=18, pady=(16, 6))
        for record in records:
            if "result" in record:
                result = record["result"]
                score = result["score"]
                color = fl.GOOD if score >= 85 else fl.WARN if score >= 55 else fl.BAD
                row = tk.Frame(card.body, bg=card.fill)
                row.pack(fill="x", padx=18, pady=3)
                tk.Label(row, text="✓" if score >= 85 else "⚠",
                         bg=card.fill, fg=color, font=fl.F_BODY()).pack(side="left")
                tk.Label(row, text=record["label"], bg=card.fill,
                         fg=self.theme["FG"], font=fl.F_BODY()).pack(
                             side="left", padx=(7, 0))
                tk.Label(row, text=f"{score}/100", bg=card.fill,
                         fg=color, font=fl.F_BODY()).pack(side="right")
                meter = MeterBar(card.body, self.theme, color=color, height=6,
                                 aero=self.aero, bg=card.fill)
                meter.pack(fill="x", padx=18, pady=(0, 5))
                meter.set_value(score / 100)
            else:
                color = {
                    "good": fl.GOOD, "warn": fl.WARN, "bad": fl.BAD,
                    "info": "#7ea7d9",
                }.get(record["severity"], "#7ea7d9")
                row = tk.Frame(card.body, bg=card.fill)
                row.pack(fill="x", padx=18, pady=(2, 7))
                tk.Label(row, text="●", bg=card.fill, fg=color,
                         font=fl.F_SMALL()).pack(side="left")
                text = tk.Frame(row, bg=card.fill)
                text.pack(side="left", fill="x", expand=True, padx=(7, 0))
                tk.Label(text, text=f"{record['test']}: {record['title']}",
                         bg=card.fill, fg=self.theme["FG"],
                         font=fl.F_BODY()).pack(anchor="w")
                tk.Label(text, text=record["explanation"], bg=card.fill,
                         fg=self.theme["MUTED"], font=fl.F_TINY(),
                         wraplength=740, justify="left").pack(anchor="w")

    def _actions(self, card, report):
        tk.Label(card.body, text="Recommended actions", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_CARD_TITLE()).pack(
                     anchor="w", padx=18, pady=(16, 6))
        for action in report["actions"]:
            tk.Label(card.body, text=f"• {action}", bg=card.fill,
                     fg=self.theme["TEXT_FG"], font=fl.F_SMALL(),
                     wraplength=780, justify="left").pack(
                         anchor="w", padx=18, pady=2)
        next_card = tk.Frame(card.body, bg=fl.mix(card.fill, self.theme["ACCENT"], 0.12))
        next_card.pack(fill="x", padx=18, pady=(12, 16))
        tk.Label(next_card, text="RECOMMENDED NEXT TEST", bg=next_card["bg"],
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=12, pady=(9, 2))
        tk.Label(next_card, text=report["next_test"], bg=next_card["bg"],
                 fg=self.theme["FG"], font=fl.F_CARD_TITLE()).pack(
                     anchor="w", padx=12, pady=(0, 9))