#!/usr/bin/env python3
"""
gui/feedback_widget.py — Beta feedback, built into the GUI
=============================================================

    BETA v1.1
    Found something?
    [ Send Feedback ]
    [ Report Bug ]   [ Suggest Feature ]

This module never sends anything by itself. It only ever does one of
two things when the user clicks a send action, and both require the
user to take one more explicit step in an app they control:

  * "Copy Report"      - puts the report text on the clipboard.
  * "Open Email Draft" - opens the user's own default mail client with
                          a prefilled draft (via a mailto: link); the
                          user still has to review and click Send there.

TechDrive has no telemetry backend, so there is no "auto-send" button
to build here even in principle - which is also exactly what makes it
safe to attach non-sensitive diagnostics automatically, since the user
sees the full report text before doing either of the above and can
edit or clear it first. What's included is deliberately narrow:

    TechDrive version
    Windows version
    Tool name (whichever tab was open / erroring)
    Error category (exception type, only set after a real tool error)

No file paths, drive contents, usernames, license keys, or any other
per-machine/per-user data are ever added - if a future contributor is
tempted to add more "useful" diagnostics here, that's the line not to
cross without a very deliberate, separate opt-in.
"""

import platform
import tkinter as tk
from tkinter import ttk

from gui import fluent as fl
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO

APP_VERSION = "1.1.0 (Beta)"


def _windows_version():
    try:
        if platform.system() == "Windows":
            release = platform.release() or ""
            version = platform.version() or ""
            return f"Windows {release} (build {version})".strip()
        return f"{platform.system()} {platform.release()}".strip()
    except Exception:
        return "Unknown"


def _current_tool_name(app):
    """Best-effort name of whichever tool tab is currently open/active -
    never anything from inside that tool (no file paths, no scan
    results), just the tab's own title."""
    try:
        from gui.closable_notebook import ClosableNotebook
        notebook = getattr(app, "notebook", None)
        if not isinstance(notebook, ClosableNotebook):
            return "N/A"
        current = notebook.select()
        if not current:
            return "N/A"
        text = notebook.tab(current, "text")
        return notebook._display_title(text) or "N/A"
    except Exception:
        return "N/A"


def build_diagnostics(app, error_category=None):
    """The exact, small set of fields described in the module docstring.
    error_category is optional and only ever an exception *type* name
    (e.g. 'PermissionError') supplied by the caller - never the
    exception message, which could echo a path or other local detail."""
    return {
        "TechDrive version": APP_VERSION,
        "Windows version": _windows_version(),
        "Tool name": _current_tool_name(app),
        "Error category": error_category or "None",
    }


class FeedbackDialog(tk.Toplevel):
    """Modal Report Bug / Suggest Feature composer."""

    def __init__(self, parent, app, theme, aero=False, kind="bug", error_category=None):
        super().__init__(parent)
        self.app = app
        self.theme = theme
        th = theme
        self.title("Send Feedback")
        self.configure(bg=th["BG"])
        self.geometry("460x520")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self._diagnostics = build_diagnostics(app, error_category)
        self._kind_var = tk.StringVar(value=kind)

        tk.Label(self, text="◇ Send Feedback", bg=th["BG"], fg=fl.glow_color(th, aero),
                  font=fl.F_TITLE()).pack(anchor="w", padx=18, pady=(16, 2))
        tk.Label(self, text="TechDrive is in beta — tell us what happened.",
                  bg=th["BG"], fg=th["MUTED"], font=fl.F_SMALL()).pack(
                      anchor="w", padx=18, pady=(0, 10))

        # -- kind toggle ---------------------------------------------
        kind_row = tk.Frame(self, bg=th["BG"])
        kind_row.pack(fill="x", padx=18, pady=(0, 10))
        for value, label in (("bug", "◇ Report Bug"), ("feature", "✦ Suggest Feature")):
            tk.Radiobutton(
                kind_row, text=label, value=value, variable=self._kind_var,
                bg=th["BG"], fg=th["FG"], selectcolor=th["BG_LIGHT"],
                activebackground=th["BG"], font=FONT_UI, indicatoron=True,
            ).pack(side="left", padx=(0, 16))

        # -- message ---------------------------------------------------
        tk.Label(self, text="What happened? (optional but helpful)", bg=th["BG"],
                  fg=th["MUTED"], font=FONT_UI).pack(anchor="w", padx=18)
        self._message_box = tk.Text(self, height=8, bg=th["SURFACE"], fg=th["FG"],
                                      insertbackground=th["FG"], font=FONT_UI, wrap="word",
                                      relief="flat")
        self._message_box.pack(fill="x", padx=18, pady=(4, 12))

        # -- diagnostics preview -----------------------------------------
        diag_head = tk.Frame(self, bg=th["BG"])
        diag_head.pack(fill="x", padx=18)
        tk.Label(diag_head, text="Diagnostic info", bg=th["BG"], fg=th["FG"],
                  font=FONT_UI_BOLD).pack(side="left")
        self._include_var = tk.BooleanVar(value=True)
        tk.Checkbutton(diag_head, text="Include with report", variable=self._include_var,
                         bg=th["BG"], fg=th["MUTED"], selectcolor=th["BG_LIGHT"],
                         activebackground=th["BG"], font=fl.F_SMALL()).pack(side="right")

        diag_box = tk.Frame(self, bg=th["SURFACE"])
        diag_box.pack(fill="x", padx=18, pady=(6, 4))
        for key, value in self._diagnostics.items():
            row = tk.Frame(diag_box, bg=th["SURFACE"])
            row.pack(fill="x", padx=10, pady=2)
            tk.Label(row, text=key, bg=th["SURFACE"], fg=th["MUTED"], font=fl.F_SMALL(),
                      width=17, anchor="w").pack(side="left")
            tk.Label(row, text=value, bg=th["SURFACE"], fg=th["FG"], font=FONT_MONO,
                      anchor="w").pack(side="left", fill="x", expand=True)

        tk.Label(self, text="No files, drive contents, or other personal data are ever "
                             "attached — only what's shown above.",
                  bg=th["BG"], fg=th["MUTED"], font=fl.F_TINY(), wraplength=420,
                  justify="left").pack(anchor="w", padx=18, pady=(6, 10))

        # -- actions ----------------------------------------------------
        actions = tk.Frame(self, bg=th["BG"])
        actions.pack(fill="x", padx=18, pady=(4, 16), side="bottom")
        tk.Button(actions, text="Cancel", command=self.destroy, bg=th["BG_LIGHT"],
                    fg=th["FG"], relief="flat", padx=10, pady=6).pack(side="right")
        tk.Button(actions, text="Open Email Draft", command=self._open_email,
                    bg=th["ACCENT"], fg=th.get("ON_ACCENT", "#ffffff"), relief="flat",
                    padx=10, pady=6).pack(side="right", padx=(0, 8))
        tk.Button(actions, text="Copy Report", command=self._copy_report, bg=th["BG_LIGHT"],
                    fg=th["FG"], relief="flat", padx=10, pady=6).pack(side="right", padx=(0, 8))

    # -- report composition ------------------------------------------
    def _report_text(self):
        kind_label = "Bug Report" if self._kind_var.get() == "bug" else "Feature Suggestion"
        message = self._message_box.get("1.0", "end").strip() or "(no message entered)"
        lines = [f"[{kind_label}]", "", message]
        if self._include_var.get():
            lines += ["", "Diagnostic info:"]
            lines += [f"{key}: {value}" for key, value in self._diagnostics.items()]
        return "\n".join(lines)

    def _copy_report(self):
        text = self._report_text()
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self._notify("Report copied to clipboard.")
        except tk.TclError:
            self._notify("Could not copy to clipboard.", kind="error")

    def _open_email(self):
        import urllib.parse
        import webbrowser
        kind_label = "Bug Report" if self._kind_var.get() == "bug" else "Feature Suggestion"
        subject = urllib.parse.quote(f"TechDrive Beta {kind_label}")
        body = urllib.parse.quote(self._report_text())
        try:
            webbrowser.open(f"mailto:?subject={subject}&body={body}")
            self._notify("Opened your email client with a draft.")
        except Exception:
            self._notify("Could not open an email client. Try Copy Report instead.",
                           kind="error")

    def _notify(self, message, kind="info"):
        try:
            self.app.show_toast(message, kind=kind)
        except Exception:
            pass


class FeedbackBadge(tk.Frame):
    """Compact 'BETA v1.1 / Send Feedback' cluster for the top bar."""

    def __init__(self, parent, app, theme, aero=False, bg=None):
        self.app = app
        self.theme = theme
        self.aero = aero
        bg = bg or parent["bg"]
        super().__init__(parent, bg=bg)

        tk.Label(self, text="BETA v1.1", bg=fl.mix(bg, theme["ACCENT"], 0.18),
                  fg=theme["ACCENT"], font=fl.font(8, "bold"), padx=6, pady=2,
                  ).pack(side="left")

        feedback_btn = tk.Label(self, text="▰ Send Feedback", bg=bg, fg=theme["FG"],
                                  font=fl.F_SMALL(), cursor="hand2", padx=6)
        feedback_btn.pack(side="left", padx=(6, 0))
        hover = fl.glass(theme, "LAYER_3", aero, 0.2)
        feedback_btn.bind("<Enter>", lambda _e: feedback_btn.config(bg=hover))
        feedback_btn.bind("<Leave>", lambda _e: feedback_btn.config(bg=bg))
        feedback_btn.bind("<Button-1>", lambda _e: self.open_dialog(
            "bug", error_category=getattr(app, "_last_error_category", None)))

    def open_dialog(self, kind="bug", error_category=None):
        FeedbackDialog(self.winfo_toplevel(), self.app, self.theme, aero=self.aero,
                         kind=kind, error_category=error_category)
