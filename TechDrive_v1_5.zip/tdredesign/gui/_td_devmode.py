#!/usr/bin/env python3
"""
gui/_td_devmode.py — quiet little easter egg
=============================================
Not wired into any menu, settings panel, help screen, or About box on
purpose. The only way in is the secret gesture registered by whoever
calls `arm()` (see gui/topbar.py). Nothing here is imported or
referenced by name anywhere else, so it won't show up in a search of
the UI strings either.

Trigger: click the little "TD" logo chip in the top bar 7 times within
2 seconds of each other. Miss the window once and the counter resets.
No tooltip, no visual feedback until the 7th click.
"""

import os
import random
import tkinter as tk

from gui import fluent as fl

try:
    from PIL import Image, ImageTk
except ImportError:                                  # graceful degradation
    Image = ImageTk = None

_ASSET_DIR = os.path.join(os.path.dirname(__file__), "assets", "_eggpix")
_PHOTO_MAX = (360, 260)

_JOKES = [
    "There are only 10 kinds of people: those who understand binary\nand those who don't.",
    "!false\nIt's funny because it's true.",
    "A SQL query walks into a bar, walks up to two tables and asks:\n\"Can I join you?\"",
    "Why do programmers prefer dark mode?\nBecause light attracts bugs.",
    "99 little bugs in the code, 99 little bugs...\ntake one down, patch it around,\n127 little bugs in the code.",
    "It works on my machine.\n\u2014 every developer, ever",
    "Developer note: keep this easter-egg message intentionally lightweight.",
]

_MISSION = [
    "Write code", "Break code", "Fix code", "Break code again",
    "Google the error", "Copy-paste from Stack Overflow",
    "It works! Don't touch it.", "Commit and push", "Repeat tomorrow",
]


def arm(widget, theme, aero, clicks=7, window_ms=2000, button="<Button-1>"):
    """Attach a secret click-counter to any widget. Call it from
    somewhere nobody's going to go looking — a logo chip, a decorative
    ring, a footer label. People interact with these expecting nothing
    to happen, which is exactly what happens until the last click.

    Each call gets its own independent counter/state, so the same
    module can be armed on several unrelated widgets around the app
    without them interfering with each other."""
    state = {"count": 0, "after_id": None}

    def _reset():
        state["count"] = 0
        state["after_id"] = None

    def _click(_evt=None):
        state["count"] += 1
        if state["after_id"] is not None:
            widget.after_cancel(state["after_id"])
        state["after_id"] = widget.after(window_ms, _reset)
        if state["count"] >= clicks:
            _reset()
            if state["after_id"] is not None:
                widget.after_cancel(state["after_id"])
                state["after_id"] = None
            _open(widget, theme, aero)

    widget.bind(button, _click, add="+")


def _load_egg_photos():
    """Loads whatever images live in gui/assets/_eggpix, scaled down to
    fit the popup. Returns [] quietly if Pillow or the folder is
    missing, so the joke box still works stand-alone either way."""
    if Image is None or not os.path.isdir(_ASSET_DIR):
        return []
    out = []
    for name in sorted(os.listdir(_ASSET_DIR)):
        if not name.lower().endswith((".jpg", ".jpeg", ".png")):
            continue
        try:
            im = Image.open(os.path.join(_ASSET_DIR, name))
            im.thumbnail(_PHOTO_MAX)
            out.append(ImageTk.PhotoImage(im))
        except Exception:
            continue
    return out


def _open(parent, theme, aero):
    win = tk.Toplevel(parent)
    win.title("Developer Insider Edition")
    win.resizable(False, False)
    win.configure(bg="#c0c0c0")
    try:
        win.attributes("-toolwindow", True)
    except tk.TclError:
        pass

    # a plain, deliberately unfancy Windows-98-ish chrome — no Aero
    # glass, no accent colours, on purpose. It should look like it
    # wandered in from a completely different, much older program.
    titlebar = tk.Frame(win, bg="#000080", height=22)
    titlebar.pack(fill="x")
    tk.Label(titlebar, text="\U0001F5A5  Developer Insider [Build 2608.17-BETA]",
             bg="#000080", fg="white",
             font=("Segoe UI", 9, "bold")).pack(side="left", padx=6)
    tk.Button(titlebar, text="\u2715", command=win.destroy, bg="#c0c0c0",
              relief="raised", bd=1, width=2, font=("Segoe UI", 8)
              ).pack(side="right", padx=2, pady=2)
    titlebar.bind("<ButtonPress-1>", lambda e: _start_drag(win, e))
    titlebar.bind("<B1-Motion>", lambda e: _do_drag(win, e))

    body = tk.Frame(win, bg="#c0c0c0", padx=14, pady=12)
    body.pack(fill="both", expand=True)

    tk.Label(body, text="You found it.", bg="#c0c0c0",
             font=("Segoe UI", 11, "bold")).pack(anchor="w")
    tk.Label(body, text="Nobody was supposed to click that seven times.",
             bg="#c0c0c0", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 8))

    joke_var = tk.StringVar(value=random.choice(_JOKES))
    joke_box = tk.Label(body, textvariable=joke_var, bg="#ffffff",
                        fg="#000000", justify="left", anchor="w",
                        relief="sunken", bd=1, padx=8, pady=8,
                        font=("Consolas", 9), width=44, height=4,
                        wraplength=320)
    joke_box.pack(fill="x", pady=(0, 8))

    mission_var = tk.StringVar(value=random.choice(_MISSION))
    tk.Label(body, textvariable=mission_var, bg="#c0c0c0",
             font=("Segoe UI", 9, "italic")).pack(anchor="w", pady=(0, 10))

    btn_row = tk.Frame(body, bg="#c0c0c0")
    btn_row.pack(fill="x")

    def _reroll():
        joke_var.set(random.choice(_JOKES))
        mission_var.set(random.choice(_MISSION))

    def _classic_button(row, text, cmd):
        return tk.Button(row, text=text, command=cmd, bg="#c0c0c0",
                         relief="raised", bd=2, font=("Segoe UI", 9),
                         padx=10, pady=3)

    _classic_button(btn_row, "Another one", _reroll).pack(side="left")

    photos = _load_egg_photos()
    if photos:
        pic_state = {"i": 0}
        pic_label = tk.Label(body, bg="#000000", relief="sunken", bd=1)
        pic_label.pack(pady=(10, 6))

        def _show(i):
            pic_state["i"] = i % len(photos)
            img = photos[pic_state["i"]]
            pic_label.configure(image=img)
            pic_label.image = img       # keep a live reference

        nav_row = tk.Frame(body, bg="#c0c0c0")
        nav_row.pack(fill="x")
        _classic_button(nav_row, "\u2039 Prev",
                        lambda: _show(pic_state["i"] - 1)).pack(side="left")
        _classic_button(nav_row, "Next \u203a",
                        lambda: _show(pic_state["i"] + 1)).pack(side="left", padx=6)
        _classic_button(nav_row, "OK", win.destroy).pack(side="right")
        _show(0)
    else:
        _classic_button(btn_row, "OK", win.destroy).pack(side="right")

    win.update_idletasks()
    px = parent.winfo_rootx() + 40
    py = parent.winfo_rooty() + 40
    win.geometry(f"+{px}+{py}")
    win.transient(parent.winfo_toplevel())


def _start_drag(win, event):
    win._drag_x = event.x
    win._drag_y = event.y


def _do_drag(win, event):
    x = win.winfo_x() + event.x - getattr(win, "_drag_x", 0)
    y = win.winfo_y() + event.y - getattr(win, "_drag_y", 0)
    win.geometry(f"+{x}+{y}")
