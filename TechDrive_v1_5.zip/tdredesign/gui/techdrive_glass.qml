import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: window
    width: 1120
    height: 760
    minimumWidth: 760
    minimumHeight: 560
    visible: true
    title: "TechDrive — Liquid Glass Dashboard"
    color: "#050608"

    property bool fullGlass: !((Qt.application.arguments.indexOf("--light-glass") >= 0) ||
                               (Qt.application.arguments.indexOf("--software") >= 0))
    property string cpuText: "—"
    property string ramText: "—"
    property string diskText: "—"
    property string hostText: "Reading system information…"

    Connections {
        target: systemBridge
        function onMetricsChanged(cpu, ram, disk, host) {
            window.cpuText = cpu
            window.ramText = ram
            window.diskText = disk
            window.hostText = host
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "#050608"
        // Restrained ambient color stays behind the black base.
        Rectangle { width: 420; height: 280; radius: 140; x: parent.width - 430; y: -160; color: "#101b30"; opacity: 0.34 }
        Rectangle { width: 300; height: 220; radius: 110; x: -180; y: parent.height - 240; color: "#10242a"; opacity: 0.22 }
    }

    ScrollView {
        anchors.fill: parent
        clip: true
        ScrollBar.vertical.policy: ScrollBar.AsNeeded
        ColumnLayout {
            width: Math.max(window.width - 64, 680)
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 18

            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 28
                Label { text: "TECHDRIVE"; color: "#9ba8bc"; font.pixelSize: 12; font.bold: true; font.letterSpacing: 3 }
                Label { text: " /  SYSTEM PULSE"; color: "#596578"; font.pixelSize: 11; font.letterSpacing: 1.5 }
                Item { Layout.fillWidth: true }
                Rectangle { radius: 12; color: "#14251f"; border.color: "#315b48"; border.width: 1; implicitWidth: statusLabel.implicitWidth + 22; implicitHeight: 28
                    Label { id: statusLabel; anchors.centerIn: parent; text: "●  LIVE MONITORING"; color: "#79d6a3"; font.pixelSize: 10; font.bold: true }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 152
                radius: 24
                color: "#0a0d13"
                border.color: "#29313e"
                border.width: 1
                gradient: Gradient { GradientStop { position: 0; color: "#111925" } GradientStop { position: 0.58; color: "#0a0d13" } GradientStop { position: 1; color: "#080a0e" } }
                Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#ffffff"; border.width: 1; opacity: 0.055 }
                Rectangle { x: 18; y: 18; width: 4; height: parent.height - 36; radius: 2; color: "#78a9ff"; opacity: 0.85 }
                ColumnLayout { anchors.left: parent.left; anchors.leftMargin: 42; anchors.verticalCenter: parent.verticalCenter; spacing: 8
                    Label { text: "Your system, at a glance"; color: "#f2f5fb"; font.pixelSize: 26; font.bold: true }
                    Label { text: window.hostText; color: "#9ba8bc"; font.pixelSize: 13; elide: Text.ElideRight }
                    Label { text: window.fullGlass ? "LIQUID GLASS  ·  ENHANCED VISUALS" : "LIQUID GLASS  ·  LIGHTWEIGHT MODE"; color: "#8eb9ff"; font.pixelSize: 10; font.bold: true; font.letterSpacing: 1.1 }
                }
                // A moving specular sheen gives depth without forcing a blur pass.
                Rectangle { visible: window.fullGlass; width: 240; height: parent.height * 2; rotation: 22; x: parent.width - 290; y: -48; opacity: 0.08; gradient: Gradient { orientation: Gradient.Horizontal; GradientStop { position: 0; color: "transparent" } GradientStop { position: 0.5; color: "#b9dcff" } GradientStop { position: 1; color: "transparent" } } }
            }

            GridLayout {
                Layout.fillWidth: true
                columns: width < 820 ? 2 : 4
                columnSpacing: 14; rowSpacing: 14
                Repeater {
                    model: [ {name:"CPU LOAD", val:window.cpuText, sub:"Processor utilization", accent:"#83b5ff"}, {name:"MEMORY",val:window.ramText,sub:"Physical memory",accent:"#8be0bd"}, {name:"SYSTEM DRIVE",val:window.diskText,sub:"Used space",accent:"#d3adff"}, {name:"RENDER MODE",val:window.fullGlass?"Enhanced":"Lightweight",sub:"Graphics presentation",accent:"#ffc98c"} ]
                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true; Layout.preferredHeight: 142
                        radius: 20
                        color: window.fullGlass ? "#151b25" : "#101217"
                        border.color: window.fullGlass ? "#526176" : "#2a2e36"
                        border.width: 1
                        Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#ffffff"; border.width: 1; opacity: window.fullGlass ? 0.12 : 0.035 }
                        Rectangle { x: 15; y: 14; width: 42; height: 3; radius: 2; color: modelData.accent; opacity: 0.9 }
                        ColumnLayout { anchors.fill: parent; anchors.margins: 17; spacing: 8
                            Label { text: modelData.name; color: "#9ba8bc"; font.pixelSize: 10; font.bold: true; font.letterSpacing: 1.2 }
                            Label { text: modelData.val; color: "#f3f6fc"; font.pixelSize: 25; font.bold: true; elide: Text.ElideRight }
                            Label { text: modelData.sub; color: "#707d90"; font.pixelSize: 11 }
                        }
                        // Fine upper-edge reflection; static on lightweight mode.
                        Rectangle { visible: window.fullGlass; x: 12; y: 1; width: parent.width - 24; height: 1; radius: 1; color: "#e4f2ff"; opacity: 0.28 }
                    }
                }
            }

            RowLayout { Layout.fillWidth: true; spacing: 14
                Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 210; radius: 20; color: "#0d1016"; border.color: "#29313e"; border.width: 1
                    ColumnLayout { anchors.fill: parent; anchors.margins: 20; spacing: 12
                        Label { text: "VISUAL MODE"; color: "#9ba8bc"; font.pixelSize: 10; font.bold: true; font.letterSpacing: 1.4 }
                        Label { text: window.fullGlass ? "Enhanced glass" : "Lightweight glass"; color: "#f2f5fb"; font.pixelSize: 20; font.bold: true }
                        Label { Layout.fillWidth: true; wrapMode: Text.WordWrap; text: window.fullGlass ? "Layered surfaces, glossy highlights and subtle depth. Effects are kept restrained for integrated graphics." : "Reduced visual layers and no costly shader-based distortion, for older or software-rendered systems."; color: "#8995a7"; font.pixelSize: 12 }
                        Item { Layout.fillHeight: true }
                        RowLayout { spacing: 8
                            Button { text: "Enhanced"; onClicked: window.fullGlass = true }
                            Button { text: "Lightweight"; onClicked: window.fullGlass = false }
                        }
                    }
                }
                Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 210; radius: 20; color: "#0d1016"; border.color: "#29313e"; border.width: 1
                    ColumnLayout { anchors.fill: parent; anchors.margins: 20; spacing: 10
                        Label { text: "ABOUT THIS BUILD"; color: "#9ba8bc"; font.pixelSize: 10; font.bold: true; font.letterSpacing: 1.4 }
                        Label { text: "A QML dashboard preview"; color: "#f2f5fb"; font.pixelSize: 18; font.bold: true }
                        Label { Layout.fillWidth: true; wrapMode: Text.WordWrap; text: "This dashboard runs as an optional companion window. Your existing TechDrive Tkinter tools and navigation remain unchanged."; color: "#8995a7"; font.pixelSize: 12 }
                        Item { Layout.fillHeight: true }
                        Label { text: "BLACK BACKGROUND  ·  LIVE SYSTEM METRICS"; color: "#68778c"; font.pixelSize: 9; font.bold: true }
                    }
                }
            }
            Item { Layout.preferredHeight: 22 }
        }
    }
}
