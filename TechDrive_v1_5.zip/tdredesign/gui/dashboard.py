#!/usr/bin/env python3
"""
gui/dashboard.py — TechDrive dashboard page
===========================================
The first screen of the redesigned app. It is *presentation only*: every
button routes into a tool that already exists in techdrive.py's
CATALOGUE via app.open_tool(), so no feature is duplicated or faked.

Sections
--------
  metric cards   CPU / RAM / GPU / Storage / Network with live value + sparkline
  System Overview   OS, motherboard, uptime, user, power plan …
  Live Performance  multi-series chart (CPU/RAM/Disk/Network)
  Quick Actions     shortcuts into real TechDrive tools
  Recent Tools      last tools the user actually opened
  Storage (All Drives)  per-drive usage bars
  System Health     donut score derived from live samples

Sampling runs on one shared `after()` timer (default 1.5 s) and reuses
psutil's cheap counters, so the dashboard stays light on memory and CPU.
"""

import importlib.util
import os
import platform
import time
import subprocess
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont
from datetime import datetime

from gui import fluent as fl
from gui.hand_icons import icon_photo, has_icon, CODE_TO_ICON
from gui.motion import (
    motion_enabled, tween, spring, ease_out_quint, page_enter, cascade,
)
from i18n import t
from shared import database as db
from gui.smart_suggestions import SuggestionsStrip
from gui.live_cards import LiveUpdateStrip
from gui.widgets import (GlassCard, FluentButton, Sparkline, LineChart,
                         HealthRing, MeterBar, card_label, round_rect,
                         paint_panel, attach_tooltip)

try:
    import psutil
except ImportError:                                  # graceful degradation
    psutil = None


def hand_icon_label(parent, name, size, color, bg, **kw):
    """Label showing one of TechDrive's own hand-drawn icons (falls back to
    plain text if images are unavailable)."""
    photo = icon_photo(parent, name, size, color)
    if photo is None:
        return tk.Label(parent, text=name[:1].upper(), bg=bg, fg=color, **kw)
    lbl = tk.Label(parent, image=photo, bg=bg, bd=0, **kw)
    lbl.image = photo           # keep a reference
    return lbl


def set_icon_color(label, name, size, color):
    photo = icon_photo(label, name, size, color)
    if photo is not None:
        label.configure(image=photo)
        label.image = photo


REFRESH_MS = 1500


def _refresh_interval_ms():
    """Return the user-selected monitor interval, with safe bounds.

    Low-power mode deliberately slows live sampling so TechDrive does not
    spend more CPU monitoring the machine than necessary.
    """
    try:
        from shared import database as db
        value = int(db.get_setting("monitor_refresh_ms", REFRESH_MS))
        value = max(500, min(5000, value))
        if db.get_setting("low_power_mode", False):
            value = max(value, 5000)
        return value
    except Exception:
        return REFRESH_MS


def _activity_time(ts):
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%H:%M")
    except (TypeError, ValueError, OSError):
        return "--:--"


def get_activity_log(limit=6):
    """Merge real Recent Tools, Health Center, and Diagnostic Engine rows
    into one chronological log, matching the dashboard mockup's "Recent
    Activity" list. No demo/seed rows - each entry is something that
    actually happened on this machine, and status is derived from the
    real saved score (Health Center / Diagnostic Engine) rather than
    always showing "Completed"."""
    entries = []
    try:
        for category, tool, opened_at in db.get_recent(limit):
            entries.append((opened_at, tool, category, "Completed"))
    except Exception:
        pass
    try:
        for row in db.get_health_history(limit):
            status = "Warning" if row["score"] < ACTIVITY_WARNING_SCORE else "Completed"
            entries.append((row["occurred_at"], "Health Scan", "Health Center", status))
    except Exception:
        pass
    try:
        for row in db.get_diagnostic_history(limit):
            status = "Warning" if row["score"] < ACTIVITY_WARNING_SCORE else "Completed"
            entries.append((row["occurred_at"], row["title"], "Diagnostic Engine", status))
    except Exception:
        pass
    entries.sort(key=lambda item: item[0] or 0, reverse=True)
    return entries[:limit]

# (label, icon, subtitle) — tiles link to the Core Module Manager; these tools
# are bundled Core modules, not external downloads. Order/wording matches the
# concept mockup's Quick Actions list.
QUICK_ACTIONS = [
    ("FIX MY PC", "FX", "Diagnose first, recommend next"),
    ("System Scan", "SC", "Run a full diagnostic pass"),
    ("Disk Health", "HD", "Check disk status"),
    ("Event Logs", "EV", "Review Windows event history"),
    ("Disk Cleanup", "CL", "Free up space"),
    ("Startup Manager", "ST", "Manage startup apps"),
    ("Process Manager", "PR", "View running processes"),
    ("Speed Test", "NW", "Test your internet speed"),
    ("File Search", "FS", "Find files and folders"),
]

# Recent history is stored as category/tool pairs.  Keep the history real, but
# give the second line a useful action instead of exposing an internal
# category name that does not help the user decide what to open next.
RECENT_TOOL_ACTIONS = {
    "Disk Cleanup": "Free up space",
    "Disk Health": "Check disk status",
    "Startup Manager": "Manage startup apps",
    "Process Manager": "View running processes",
    "Speed Test": "Test your connection",
    "File Search": "Find files and folders",
    "System Overview": "Review system details",
    "System Summary": "Review system details",
    "Storage Health": "Check drive condition",
    "Network Monitor": "Inspect network activity",
    "RAM Monitor": "Inspect memory usage",
    "CPU Monitor": "Inspect processor load",
}
TOOLBOX_LINKS = [
    "Duplicate File Finder",
    "Space Analyzer",
    "Registry Cleaner",
    "Driver Updater",
    "Process Manager",
]

# Friendly action labels that don't literally appear inside a real catalogue
# tool name (unlike "Disk Health" / "Disk Cleanup" which substring-match on
# their own). Mapped to the actual tool that already ships in the catalogue,
# so Quick Actions never fabricates a feature that doesn't exist.
QUICK_ACTION_ALIASES = {
    "system scan": "Diagnostic Engine",
    "event logs": "Event Log Analyzer",
}

# A scan/session is only flagged "Warning" in the Recent Activity log when
# its real saved score drops below this line - keeps the log honest instead
# of a fixed "Completed" everywhere.
ACTIVITY_WARNING_SCORE = 70


class HeroBanner(tk.Frame):
    """Welcome banner: soft full-bleed artwork, greeting, one status line and
    a compact live System Pulse readout. Deliberately minimal - the artwork
    carries the colour; nothing else decorates the banner."""

    HEIGHT = 120

    def __init__(self, parent, theme, aero=False):
        self.theme = theme
        self.aero = aero
        super().__init__(parent, bg=theme["BG"], height=self.HEIGHT)
        self.pack_propagate(False)
        self.canvas = tk.Canvas(self, bg=theme["BG"], highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._redraw)
        # Artwork ships inside the build (gui/assets/hero_banner.jpg), so the
        # hero never depends on the network. It is cover-fitted to the banner
        # size with PIL and cached per size.
        self._art = None
        self._art_photo = None
        self._art_key = None
        try:
            from pathlib import Path
            from PIL import Image
            art_path = Path(__file__).parent / "assets" / "hero_banner.jpg"
            if art_path.exists():
                self._art = Image.open(art_path).convert("RGB")
        except Exception:
            self._art = None
        self._greeting = ""
        self._status = "Checking system\u2026"
        self._status_color = fl.WARN
        self._telemetry = {"CPU": "--", "RAM": "--", "DISK": "--", "NET": "--"}

    def set_greeting(self, text):
        self._greeting = text
        self._redraw()

    def set_status(self, text, color):
        self._status = text
        self._status_color = color
        self._redraw()

    def set_telemetry(self, **values):
        """Update the compact live System Pulse readout in the hero banner."""
        for key, value in values.items():
            key = str(key).upper()
            if key in self._telemetry:
                self._telemetry[key] = str(value)
        self._redraw()

    def _artwork(self, w, h, radius):
        """Cover-fit the artwork to w x h, add a left-side scrim for text
        legibility and round the corners (alpha-masked onto the page BG)."""
        key = (w, h, radius, self.theme["BG"])
        if self._art_key == key and self._art_photo is not None:
            return self._art_photo
        from PIL import Image, ImageDraw, ImageTk
        art = self._art
        scale = max(w / art.width, h / art.height)
        nw, nh = max(w, int(art.width * scale)), max(h, int(art.height * scale))
        img = art.resize((nw, nh), Image.LANCZOS)
        left, top = (nw - w) // 2, int((nh - h) * 0.5)
        img = img.crop((left, top, left + w, top + h))
        # Scrim: dark on the left (where the copy sits), clear on the right.
        scrim = Image.new("L", (w, 1))
        for x in range(w):
            t = min(1.0, x / max(1, w * 0.62))
            scrim.putpixel((x, 0), int(150 * (1.0 - t) ** 1.4 + 22))
        scrim = scrim.resize((w, h))
        dark = Image.new("RGB", (w, h), (10, 10, 14))
        img = Image.composite(dark, img, scrim)
        # Rounded corners over the page background.
        mask = Image.new("L", (w * 2, h * 2), 0)
        ImageDraw.Draw(mask).rounded_rectangle(
            (0, 0, w * 2 - 1, h * 2 - 1), radius=radius * 2, fill=255)
        mask = mask.resize((w, h), Image.LANCZOS)
        bg = Image.new("RGB", (w, h), fl.hex_to_rgb(self.theme["BG"]))
        img = Image.composite(img, bg, mask)
        self._art_photo = ImageTk.PhotoImage(img, master=self.canvas)
        self._art_key = key
        return self._art_photo

    def _redraw(self, event=None):
        c = self.canvas
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        if w < 4 or h < 4:
            return
        th = self.theme
        radius = fl.RADIUS_CARD + 4
        if self._art is not None:
            try:
                c.create_image(0, 0, image=self._artwork(w, h, radius), anchor="nw")
            except Exception:
                self._art = None
        if self._art is None:
            round_rect(c, 0, 0, w - 1, h - 1, r=radius,
                       fill=fl.mix(th["BG"], th["ACCENT"], 0.18), outline="")
        round_rect(c, 0, 0, w - 1, h - 1, r=radius, fill="",
                   outline=fl.mix("#ffffff", th["BG"], 0.80), width=1)

        # --- left: glass badge + greeting + one status line ---------------
        pad = 24
        cx, cy, r = pad + 22, h / 2, 22
        c.create_oval(cx - r, cy - r, cx + r, cy + r,
                      fill=fl.mix("#ffffff", "#000000", 0.78),
                      outline=fl.mix("#ffffff", "#000000", 0.45), width=1)
        self._hex_photo = icon_photo(c, "hexagon", 26, "#ffffff")
        if self._hex_photo is not None:
            c.create_image(cx, cy, image=self._hex_photo)

        tx = cx + r + 16
        # Right-hand pulse readout width decides how much room the copy has.
        pulse_items = [("CPU", "CPU"), ("RAM", "RAM"), ("DISK", "Disk"),
                       ("NET", "Net")]
        readout_w = 0
        if w >= 640:
            readout_w = 300
        text_w = max(120, w - tx - readout_w - pad)

        greeting = self._greeting.strip()
        if "," in greeting:
            first, second = greeting.split(",", 1)
            first, second = first.strip() + ",", second.strip()
        else:
            first, second = "", greeting
        if first:
            c.create_text(tx, h * 0.26, text=first,
                          fill=fl.mix("#ffffff", th["BG"], 0.20),
                          font=fl.F_CALLOUT(), anchor="w", width=text_w)
        c.create_text(tx, h * 0.50, text=second, fill="#ffffff",
                      font=fl.F_TITLE(), anchor="w", width=text_w)
        # Status: dot + text, no box (the pill used to overlap the pulse).
        dot_y = h * 0.76
        c.create_oval(tx, dot_y - 4, tx + 8, dot_y + 4,
                      fill=self._status_color, outline="")
        c.create_text(tx + 16, dot_y, text=self._status,
                      fill=fl.mix("#ffffff", th["BG"], 0.12),
                      font=fl.F_SMALL(), anchor="w", width=text_w - 16)

        # --- right: one glass capsule with the live readout ---------------
        if readout_w:
            font_v = fl.font(11, "bold")
            font_k = fl.F_TINY()
            cell = 66
            cap_w = cell * len(pulse_items) + 20
            x1 = w - pad
            x0 = x1 - cap_w
            y0, y1 = h / 2 - 25, h / 2 + 25
            round_rect(c, x0, y0, x1, y1, r=25,
                       fill=fl.mix("#000000", th["BG"], 0.35),
                       outline=fl.mix("#ffffff", "#000000", 0.62), width=1)
            for i, (key, label) in enumerate(pulse_items):
                mx = x0 + 10 + cell * i + cell / 2
                c.create_text(mx, y0 + 17, text=self._telemetry[key],
                              fill="#ffffff", font=font_v)
                c.create_text(mx, y0 + 35, text=label,
                              fill=fl.mix("#ffffff", th["BG"], 0.35),
                              font=font_k)


def _clip_word(font, word, max_width):
    """Shorten one over-long word with an ellipsis so it fits on a line."""
    if font.measure(word) <= max_width:
        return word
    while word and font.measure(word + "\u2026") > max_width:
        word = word[:-1]
    return word + "\u2026"


def _fit_wrapped_text(font, text, max_width, max_lines=2):
    """Return `text`, ellipsized if it would wrap to more than `max_lines`.

    Tk wraps a Label's text onto as many lines as it needs; in a card with
    a fixed number of text lines the extra ones are simply chopped off
    mid-word.  This simulates the word wrap and, when the text is too long,
    keeps whole words and ends the last line with "\u2026" instead.
    Text that already fits is returned untouched.
    """
    text = str(text or "")
    if max_width < 24 or not text.strip():
        return text
    lines = []                       # each line is a list of words
    for paragraph in text.split("\n"):
        current = []
        for word in paragraph.split():
            word = _clip_word(font, word, max_width)
            if current and font.measure(" ".join(current + [word])) > max_width:
                lines.append(current)
                current = [word]
            else:
                current.append(word)
        lines.append(current)
    if len(lines) <= max_lines:
        return text
    keep = [" ".join(line) for line in lines[:max_lines - 1]]
    rest = [word for line in lines[max_lines - 1:] for word in line]
    last = []
    for word in rest:
        if font.measure(" ".join(last + [word]) + "\u2026") <= max_width:
            last.append(word)
        else:
            break
    return "\n".join(keep + [" ".join(last) + "\u2026"])


class MetricGlyph(tk.Label):
    """Hand-drawn icon for a metric card (cpu / ram / storage / gpu / network)."""

    SIZE = 24

    def __init__(self, parent, key, color, bg):
        photo = icon_photo(parent, key, self.SIZE, color)
        super().__init__(parent, image=photo, bg=bg, bd=0)
        self.image = photo


class MetricCard(GlassCard):
    """Icon + title + big live value + supporting text + sparkline.

    Clicking anywhere on the card (it's not just decorative) drills into
    the matching detailed monitor tool via `on_open`, same as every other
    click-through on the dashboard — no bespoke navigation path.
    """

    def __init__(self, parent, theme, key, icon, title, aero=False,
                 on_open=None):
        color = fl.METRIC_COLORS.get(key, theme["ACCENT"])
        # Neutral card chrome - the metric colour only appears in the data.
        super().__init__(parent, theme, aero=aero)
        self.key = key
        self.color = color
        self._last_sample = None
        self._on_open = on_open

        head = tk.Frame(self.body, bg=self.fill)
        head.pack(fill="x", pady=(2, 0))
        glyph = MetricGlyph(head, key, color, self.fill)
        glyph.pack(side="left")
        card_label(head, title, theme, fl.font(12, "bold")).pack(side="left",
                                                                  padx=8)
        self.open_hint = tk.Label(
            head, text="\u203a", bg=self.fill, fg=theme["MUTED"],
            font=fl.font(14), padx=4, takefocus=1,
            highlightthickness=1, highlightbackground=self.fill,
            highlightcolor=color,
        )
        if on_open:
            self.open_hint.pack(side="right")
            attach_tooltip(self.open_hint, f"Open the full {title} monitor")
            self.open_hint.bind("<Return>", lambda _e: self._on_open())
            self.open_hint.bind("<space>", lambda _e: self._on_open())

        self._fonts = {}
        self._value_size = None
        self._sub_text = ""

        # Value + trend share one row, so the subtitle below can use the
        # card's FULL width.  (The trend label used to sit beside the
        # subtitle and steal ~60px, so wrapped lines were wider than the
        # space the label really had and got cut off on the right.)
        value_row = tk.Frame(self.body, bg=self.fill)
        value_row.pack(fill="x", pady=(5, 0))
        self.value_lbl = tk.Label(value_row, text="--", bg=self.fill,
                                  fg=theme["FG"], font=fl.F_METRIC(),
                                  anchor="w")
        self.value_lbl.pack(side="left")
        self.trend_lbl = tk.Label(
            value_row, text="", bg=self.fill, fg=color,
            font=fl.F_TINY(), anchor="e",
        )
        self.trend_lbl.pack(side="right", anchor="s", padx=(4, 0), pady=(0, 6))
        attach_tooltip(self.trend_lbl, "Change since the last reading")
        # Always two text lines tall so cards never jump between ticks;
        # _fit_subtitle() ellipsizes anything longer instead of clipping.
        self.sub_lbl = tk.Label(self.body, text="", bg=self.fill,
                                fg=theme["MUTED"], font=fl.F_SMALL(),
                                anchor="nw", justify="left", wraplength=140,
                                height=2)
        self.sub_lbl.pack(fill="x")
        self.spark = Sparkline(self.body, color, theme, height=30, bg=self.fill)
        self.spark.pack(fill="x", side="bottom", pady=(4, 0))

        clickable = (
            self.body, head, glyph, self.open_hint, self.value_lbl, value_row,
            self.sub_lbl, self.trend_lbl, self.spark,
        )
        if on_open:
            for widget in clickable:
                widget.configure(cursor="hand2")
                widget.bind("<Button-1>", lambda _e: self._on_open(), add="+")
        self.body.bind("<Configure>", lambda _e: self._refresh_text())

    # -- text fitting ---------------------------------------------------
    def _font(self, spec):
        f = self._fonts.get(spec)
        if f is None:
            f = self._fonts[spec] = tkfont.Font(root=self, font=spec)
        return f

    def _refresh_text(self):
        width = self.body.winfo_width()
        if width < 40:                      # not laid out yet
            self.sub_lbl.config(text=self._sub_text)
            return
        try:
            self._fit_value(width)
            self._fit_subtitle(width)
        except tk.TclError:
            return
        self._schedule_autofit()

    def _fit_value(self, width):
        """Largest value font that fits next to the trend label, so
        strings such as "Connected" never run outside the card."""
        text = self.value_lbl.cget("text") or "--"
        tiny = self._font(fl.F_TINY())
        reserve = max(tiny.measure("\u2022 STEADY"),
                      tiny.measure("\u25b2 100%")) + 12
        cap = 30 if width >= 190 else 25 if width >= 155 else 21
        sizes = [sz for sz in (30, 25, 21, 18, 15) if sz <= cap]
        chosen = sizes[-1]
        for size in sizes:
            if self._font(fl.font(size, "bold")).measure(text) + reserve <= width:
                chosen = size
                break
        if chosen != self._value_size:
            self._value_size = chosen
            self.value_lbl.config(font=fl.font(chosen, "bold"))

    def _fit_subtitle(self, width):
        wrap = max(60, width - 4)
        shown = _fit_wrapped_text(self._font(fl.F_SMALL()), self._sub_text,
                                  wrap - 8, 2)
        self.sub_lbl.config(wraplength=wrap, text=shown)

    def _redraw(self, event=None):
        # Flat, neutral surface with a hairline border; lifts slightly on hover.
        canvas = self.canvas
        width, height = canvas.winfo_width(), canvas.winfo_height()
        if width < 4 or height < 4:
            return
        outline = self.theme["STROKE_SOFT"]
        if self._hovered or self._hover_t > 0:
            outline = fl.mix(outline, self.theme["ACCENT"],
                             0.35 if self._hovered else 0.35 * self._hover_t)
        paint_panel(
            canvas, width, height, self.fill, outline,
            radius=fl.RADIUS_CARD, shadow=self.theme["SHADOW"],
            backdrop=self.backdrop,
        )
        canvas.tag_lower("panel")

    def update_metric(self, value_text, subtitle, sample=None):
        prev = self.value_lbl.cget("text")
        self.value_lbl.config(text=value_text)
        # Soft pulse when value changes (not on first "--")
        if (
            motion_enabled()
            and prev
            and prev != value_text
            and prev != "--"
            and getattr(self, "_anim_busy", False) is False
        ):
            self._anim_busy = True
            def update(t):
                # quick hover edge flash
                peak = 0.4
                self._hover_t = peak * (1.0 - abs(1.0 - 2.0 * t))
                try:
                    self._redraw()
                except Exception:
                    pass
            def done():
                self._hover_t = 0.0
                self._anim_busy = False
                try:
                    self._redraw()
                except Exception:
                    pass
            try:
                tween(self, 420, update, complete=done, easing=ease_out_quint)
            except Exception:
                self._anim_busy = False
        self._sub_text = subtitle or ""
        if isinstance(sample, (int, float)):
            # No "LIVE" / "STEADY" badges: calm metrics show no status text.
            # Only a meaningful change gets a small, muted arrow.
            if self._last_sample is None:
                self.trend_lbl.config(text="")
            else:
                delta = sample - self._last_sample
                if abs(delta) < 0.5:
                    self.trend_lbl.config(text="")
                elif delta > 0:
                    self.trend_lbl.config(text=f"▲ {abs(delta):.0f}%")
                else:
                    self.trend_lbl.config(text=f"▼ {abs(delta):.0f}%")
            self._last_sample = sample
        else:
            self.trend_lbl.config(text="")
        self._refresh_text()
        if sample is not None:
            self.spark.push(sample)


class MiniDashboardOverlay(tk.Toplevel):
    """Compact always-on-top telemetry overlay backed by DashboardPage data."""

    def __init__(self, dashboard):
        super().__init__(dashboard)
        self.dashboard = dashboard
        self.theme = dashboard.theme
        self.aero = dashboard.aero
        self.title("TechDrive — Mini Performance")
        self.configure(bg=self.theme["BG"])
        self.resizable(False, False)
        try:
            self.attributes("-topmost", True)
        except Exception:
            pass
        self.protocol("WM_DELETE_WINDOW", self.close)

        header = tk.Frame(self, bg=self.theme["SURFACE"], height=30)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="TECHDRIVE  /  LIVE OVERLAY", bg=header["bg"],
                 fg=self.theme["FG"], font=fl.font(8, "bold")).pack(side="left", padx=9)
        close = tk.Label(header, text="×", bg=header["bg"], fg=self.theme["MUTED"],
                         font=fl.font(13, "bold"), cursor="hand2")
        close.pack(side="right", padx=9)
        close.bind("<Button-1>", lambda _e: self.close())

        holder = tk.Frame(self, bg=self.theme["BG"], padx=6, pady=6)
        holder.pack(fill="both", expand=True)
        self.cards = {}
        specs = [("cpu", "CPU", "CPU"), ("ram", "RAM", "RAM"),
                 ("storage", "SSD", "Storage"), ("gpu", "GPU", "GPU"),
                 ("network", "NET", "Network")]
        for key, icon, title in specs:
            card = MetricCard(
                holder, self.theme, key, icon, title, aero=self.aero,
                on_open=lambda key=key: dashboard._open_metric_monitor(key),
            )
            card.pack(side="left", fill="both", padx=3)
            card.configure(width=154, height=122)
            card.pack_propagate(False)
            self.cards[key] = card

        self.update_idletasks()
        # Fit five metric cards into a genuinely compact overlay while still
        # leaving their values and sparklines readable on older displays.
        self.geometry("830x162")
        self._position_bottom_right()
        self.bind("<Configure>", self._keep_on_top, add="+")

    def _position_bottom_right(self):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        w = max(1, self.winfo_width())
        h = max(1, self.winfo_height())
        self.geometry(f"{w}x{h}+{max(8, sw - w - 18)}+{max(8, sh - h - 55)}")

    def _keep_on_top(self, _event=None):
        try:
            self.attributes("-topmost", True)
        except Exception:
            pass

    def update_metrics(self, s, gpu_value, gpu_sub, gpu_sample):
        if not self.winfo_exists():
            return
        cpu = s.get("cpu")
        if cpu is not None:
            self.cards["cpu"].update_metric(f"{cpu:.0f}%", self.dashboard.app.get_cpu_name(), cpu)
            self.cards["ram"].update_metric(f"{s.get('ram', 0):.0f}%", s.get("ram_text", ""), s.get("ram"))
            self.cards["storage"].update_metric(f"{s.get('storage', 0):.0f}%", s.get("storage_text", ""), s.get("storage"))
            self.cards["gpu"].update_metric(gpu_value, gpu_sub, gpu_sample)
            down = s.get("net_down", 0) / 125000.0
            up = s.get("net_up", 0) / 125000.0
            network_label = "Online" if self.dashboard._net_last is not None else "—"
            self.cards["network"].update_metric(network_label,
                f"↓ {down:.1f} Mbps    ↑ {up:.1f} Mbps", s.get("network", 0))

    def close(self):
        if getattr(self.dashboard, "_mini_overlay", None) is self:
            self.dashboard._mini_overlay = None
        try:
            self.destroy()
        except tk.TclError:
            pass


class DashboardPage(tk.Frame):
    """Composable dashboard; `app` is the TechDriveApp instance."""

    def __init__(self, parent, app):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        super().__init__(parent, bg=self.theme["BG"])

        self._job = None
        self._destroyed = False
        self._net_last = None
        self._net_time = None
        self._disk_last = None
        self._build_scroll_shell()
        self._build()
        self._tick()
        self.bind("<Destroy>", self._on_destroy)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def _build_scroll_shell(self):
        """Keep the dashboard usable below the reference height.

        The dashboard has several live surfaces, so a short window should
        scroll vertically rather than crop the System Health or storage
        cards.  The canvas window is always fitted to the viewport width,
        which prevents a horizontal scrollbar or sideways overflow.
        """
        from gui.scroll_utils import make_scrollable
        self._dashboard_canvas, self._content = make_scrollable(
            self, self.theme["BG"])
        self._dashboard_canvas.bind(
            "<Configure>", self._draw_dashboard_backdrop, add="+")

        # Wheel scrolling itself is handled app-wide (see
        # gui/scroll_utils.install_global_mousewheel, installed once in
        # TechDriveApp.__init__) - it works no matter which child widget
        # under the canvas the cursor is over, not just bare canvas
        # background, so no per-widget bindings are needed here.

    def _draw_dashboard_backdrop(self, event=None):
        """Paint a quiet technical grid behind the live cards.

        It is intentionally low contrast: the background should make the
        dashboard feel dimensional without competing with telemetry values.
        """
        canvas = self._dashboard_canvas
        canvas.delete("dashboard-backdrop")
        width = max(1, canvas.winfo_width())
        height = max(1, canvas.winfo_height())
        th = self.theme
        grid = fl.mix(th["BG"], th["FG"], 0.035)
        for x in range(24, width, 120):
            canvas.create_line(
                x, 0, x, height, fill=grid, width=1,
                tags="dashboard-backdrop",
            )
        for y in range(22, height, 82):
            canvas.create_line(
                0, y, width, y, fill=grid, width=1,
                tags="dashboard-backdrop",
            )
        glow = fl.mix(th["BG"], th["ACCENT"], 0.08)
        canvas.create_oval(
            width - 330, -170, width + 110, 260,
            fill=glow, outline="", tags="dashboard-backdrop",
        )
        self._draw_corner_mascot(canvas, width, tags="dashboard-backdrop")
        canvas.tag_lower("dashboard-backdrop")

    def _draw_corner_mascot(self, canvas, width, tags):
        """A tiny hidden easter egg: a friendly pixel-drive mascot floating
        in the empty glow up in the top-right corner. Purely decorative and
        drawn with plain canvas shapes so it costs nothing extra to ship -
        most people will scroll right past it, and that's the fun of it."""
        th = self.theme
        mx, my = width - 96, 34
        body = fl.mix(th["ACCENT"], "#ffffff", 0.22)
        edge = fl.mix(th["ACCENT2"], "#ffffff", 0.30)
        # Rounded little disk-drive body.
        round_rect(canvas, mx - 26, my - 17, mx + 26, my + 17, r=8,
                    fill=body, outline=edge, width=1, tags=tags)
        # Two blinking "eyes" (LED slots).
        for ex in (mx - 10, mx + 10):
            canvas.create_oval(ex - 3, my - 4, ex + 3, my + 2,
                                fill="#ffffff", outline="", tags=tags)
        # Small closed-eye smile.
        canvas.create_arc(mx - 9, my - 2, mx + 9, my + 12, start=200,
                           extent=140, style="arc",
                           outline="#ffffff", width=2, tags=tags)
        # A little activity light that "blinks" via the theme accent color.
        canvas.create_oval(mx + 17, my + 9, mx + 21, my + 13,
                            fill=fl.mix(th["ACCENT_GLOW"], "#ffffff", 0.15),
                            outline="", tags=tags)

    ABOUT_TITLE = "TechDrive"
    ABOUT_TAGLINE = "All-in-one PC repair & diagnostics"
    ABOUT_TEXT = (
        "TechDrive is an all-in-one PC repair and diagnostic utility. Watch "
        "CPU, memory, storage, GPU and network live, run a one-click health "
        "scan, and open disk, network, security and repair tools from a "
        "single place \u2014 every tool is one click away."
    )

    def _build_about_card(self, host, th, pad):
        """Liquid-glass description card shown above the hero banner.

        The text is drawn straight onto the card's canvas (and the opaque
        body frame is dropped) so the whole pane - gradient, refracted
        glow and rim - stays visible behind the copy instead of only
        around its edges."""
        card = GlassCard(host, th, aero=self.aero, backdrop=th["BG"],
                         accent=th["ACCENT"], padding=14)
        card.pack(fill="x", padx=pad, pady=(pad, fl.GAP))
        card.pack_propagate(False)
        card.body.place_forget()
        card.configure(height=104)
        cv = card.canvas
        left, top = 20, 14

        def _layout(_e=None):
            w = cv.winfo_width()
            if w < 80:
                return
            cv.delete("about")
            title = cv.create_text(
                left, top, text=self.ABOUT_TITLE, anchor="nw",
                fill=th["FG"], font=fl.font(13, "bold", True), tags="about")
            tb = cv.bbox(title)
            cv.create_text(
                tb[2] + 10, top + 4, text="\u2022  " + self.ABOUT_TAGLINE,
                anchor="nw", fill=th["ACCENT_GLOW"],
                font=fl.font(9, "bold"), tags="about")
            desc = cv.create_text(
                left, tb[3] + 6, text=self.ABOUT_TEXT, anchor="nw",
                fill=th["TEXT_FG"], font=fl.F_SMALL(),
                width=max(160, w - left - 18), tags="about")
            db_ = cv.bbox(desc)
            need = db_[3] + 14 + fl.SHADOW_LAYERS
            cv.tag_raise("about")
            if abs(int(card.cget("height")) - need) > 1:
                card.configure(height=need)

        # Runs after GlassCard's own redraw (bound first), so the text always
        # lands on top of a freshly painted pane.
        cv.bind("<Configure>", lambda e: card.after_idle(_layout), add="+")
        card.after(80, _layout)
        self.about_card = card

    def _build(self):
        th = self.theme
        pad = fl.PAD_PAGE
        host = self._content
        self._entrance_cards = []

        # --- hero banner ----------------------------------------------------
        # Gradient welcome card (hexagon glyph + greeting + live status
        # pill), matching the concept mockup. The clock/date now live only
        # in the top bar (gui/topbar.py) rather than being duplicated here.
        # System Pulse hero sits at the very top of the dashboard, in the
        # empty space above the TechDrive description card.
        self.hero = HeroBanner(host, th, aero=self.aero)
        self.hero.pack(fill="x", padx=pad, pady=(fl.GAP, fl.GAP))
        self.hero.set_greeting(self._greeting_text())

        # --- TechDrive description (directly below the hero) ----------------
        self._build_about_card(host, th, pad)
        # The about card's own top offset is no longer needed under the hero.
        self.about_card.pack_configure(pady=(0, fl.GAP))

        # --- metric cards span the complete content width --------------------
        # The reference keeps telemetry visually independent from the
        # overview/actions split below it. Keeping this row outside `main`
        # also prevents the right column from stealing card width.
        telemetry_bar = tk.Frame(host, bg=th["BG"])
        self._telemetry_bar = telemetry_bar
        telemetry_bar.pack(fill="x", padx=pad, pady=(0, 8))
        tk.Label(
            telemetry_bar, text="Live telemetry", bg=th["BG"],
            fg=th["FG"], font=fl.F_SUBTITLE(),
        ).pack(side="left")
        FluentButton(
            telemetry_bar, "Mini Mode", theme=th, aero=self.aero,
            kind="subtle", icon="mini", height=24, backdrop=th["BG"],
            font_=fl.F_TINY(), command=self.toggle_mini_mode,
        ).pack(side="right", padx=(0, 8))
        FluentButton(
            telemetry_bar, "Liquid Glass", theme=th, aero=self.aero,
            kind="subtle", icon="drop", height=24, backdrop=th["BG"],
            font_=fl.F_TINY(), command=self.open_qml_dashboard,
        ).pack(side="right", padx=(0, 8))
        FluentButton(
            telemetry_bar, "Refresh", theme=th, aero=self.aero,
            kind="subtle", icon="refresh", height=24, backdrop=th["BG"],
            font_=fl.F_TINY(), command=self._manual_refresh,
        ).pack(side="right", padx=(0, 8))

        # Give the telemetry strip a real, bounded height.  The card canvas
        # uses a generous natural requested height for standalone tool pages;
        # letting that request determine this dashboard row makes the five
        # compact cards push the workspace far below the fold.  The row is
        # deliberately fixed so the dashboard stays dense and predictable.
        cards_holder = tk.Frame(host, bg=th["BG"])
        cards_holder.pack(fill="x", padx=pad, pady=(0, fl.GAP))
        cards_row = tk.Frame(cards_holder, bg=th["BG"])
        cards_row.pack(fill="both", expand=True)
        cards_row.grid_rowconfigure(0, weight=1)
        self.cards = {}
        specs = [("cpu", "CPU", "CPU"), ("ram", "RAM", "RAM"),
                 ("storage", "SSD", "Storage"), ("gpu", "GPU", "GPU"),
                 ("network", "NET", "Network")]
        for i, (key, icon, title) in enumerate(specs):
            cards_row.columnconfigure(i, weight=1, uniform="metric")
            card = MetricCard(
                cards_row, th, key, icon, title, aero=self.aero,
                on_open=lambda key=key: self._open_metric_monitor(key),
            )
            card.grid(row=0, column=i, sticky="nsew",
                      padx=(0 if i == 0 else fl.GAP // 2, 0), pady=0)
            # Height follows the content (value, 2-line subtitle, sparkline)
            # instead of a fixed pixel guess that clipped text and hid the
            # sparkline whenever fonts / DPI differed.
            card.enable_autofit()
            self.cards[key] = card
            self._entrance_cards.append(card)

        workspace_bar = tk.Frame(host, bg=th["BG"])
        self._workspace_bar = workspace_bar
        workspace_bar.pack(fill="x", padx=pad, pady=(fl.GAP // 2, 6))
        tk.Label(
            workspace_bar, text="Overview", bg=th["BG"],
            fg=th["FG"], font=fl.F_SUBTITLE(),
        ).pack(side="left")

        # --- main workspace | right actions rail ----------------------------
        # Keep the established TechDrive layout: overview/performance in the
        # main column, with Quick Actions, System Health, and storage in the
        # right rail.  The dashboard canvas above handles short windows
        # without clipping these sections.
        split = tk.Frame(host, bg=th["BG"])
        split.pack(fill="both", expand=True, padx=pad, pady=(0, pad))
        split.grid_rowconfigure(0, weight=1)
        split.grid_columnconfigure(0, weight=1, minsize=0)
        split.grid_columnconfigure(1, weight=0, minsize=0)
        main = tk.Frame(split, bg=th["BG"])
        main.grid(row=0, column=0, sticky="nsew")
        side = tk.Frame(split, bg=th["BG"], width=270)
        side.grid(row=0, column=1, sticky="nsew", padx=(fl.GAP, 0))
        side.pack_propagate(False)
        side.grid_propagate(False)
        self._dashboard_split = split
        self._dashboard_main = main
        self._dashboard_side = side
        split.bind("<Configure>", self._resize_split)

        # --- overview + chart -----------------------------------------------
        mid = tk.Frame(main, bg=th["BG"])
        mid.pack(fill="both", expand=True, pady=(fl.GAP, 0))
        mid.columnconfigure(0, weight=3, uniform="mid", minsize=0)
        mid.columnconfigure(1, weight=4, uniform="mid", minsize=0)
        mid.rowconfigure(0, weight=1)

        self._build_overview(mid)
        self._build_performance(mid)

        # Smart Suggestions strip
        try:
            self._live = LiveUpdateStrip(main, self.app, th, aero=self.aero)
            self._live.pack(fill="x", pady=(fl.GAP, 0))
        except Exception:
            self._live = None
        try:
            self._suggestions = SuggestionsStrip(main, self.app, th, aero=self.aero)
            self._suggestions.pack(fill="x", pady=(fl.GAP, 0))
        except Exception:
            self._suggestions = None
        self._build_recent(main)
        self._build_activity(main)
        self._build_pinned(main)
        self._build_quick_actions(side)
        self._build_health(side)
        self._build_storage(side)
        self._build_footer(host)
        self._play_entrance_cascade()

    def _play_entrance_cascade(self):
        """Full-dashboard entrance: hero, metrics, workspace, side rail."""
        if not motion_enabled():
            return
        stagger_ms = 48
        # 1) Hero soft settle
        try:
            if getattr(self, "hero", None) is not None:
                page_enter(self.hero, duration_ms=360, direction="up", distance=18)
        except Exception:
            pass
        for bar_name, delay in (("_telemetry_bar", 40), ("_workspace_bar", 120)):
            bar = getattr(self, bar_name, None)
            if bar is not None:
                try:
                    self.after(
                        delay,
                        lambda b=bar: page_enter(b, duration_ms=280, direction="up", distance=10),
                    )
                except Exception:
                    pass
        # 2) Metric cards + all GlassCards already registered
        for index, card in enumerate(self._entrance_cards):
            try:
                card.play_entrance(delay=80 + index * stagger_ms, duration=340)
            except Exception:
                pass
        # 3) Live strip + suggestions after metrics
        delay_live = 80 + max(len(self._entrance_cards), 5) * stagger_ms
        def _anim_block(widget, extra=0):
            try:
                if widget is not None and widget.winfo_exists():
                    self.after(
                        delay_live + extra,
                        lambda w=widget: page_enter(w, duration_ms=320, direction="up", distance=14),
                    )
            except Exception:
                pass
        _anim_block(getattr(self, "_live", None), 0)
        _anim_block(getattr(self, "_suggestions", None), 70)
        # 4) Workspace bar pulse label
        try:
            for child in self.winfo_children():
                pass
        except Exception:
            pass

    def _build_footer(self, parent):
        """Quiet status rail that gives the dashboard a finished bottom edge."""
        th = self.theme
        footer = tk.Frame(parent, bg=th["BG"])
        footer.pack(fill="x", padx=fl.PAD_PAGE, pady=(0, fl.PAD_PAGE))
        rule = tk.Frame(
            footer, bg=fl.mix(th["BG"], th["FG"], 0.10), height=1,
        )
        rule.pack(fill="x", pady=(0, 7))
        self.footer_sample = tk.Label(
            footer, text="Updated \u2014",
            bg=th["BG"], fg=th["MUTED"], font=fl.F_CAPTION(),
        )
        self.footer_sample.pack(side="left")
        tk.Label(
            footer, text="\u25cf  Live \u00b7 auto-refresh",
            bg=th["BG"], fg=fl.GOOD, font=fl.F_CAPTION(),
        ).pack(side="right")

    def _card(self, parent, title, accent=None, meta=None, **grid):
        """Create a titled GlassCard and return its body frame."""
        card = GlassCard(
            parent, self.theme, aero=self.aero, gradient=True, accent=accent,
        )
        if grid:
            card.grid(**grid)
        else:
            card.pack(fill="both", expand=True, pady=(fl.GAP, 0))
        header = tk.Frame(card.body, bg=card.body["bg"])
        header.pack(fill="x")
        card_label(
            header, title, self.theme, fl.F_SUBTITLE(),
        ).pack(side="left")
        if meta:
            tk.Label(
                header, text=meta,
                bg=fl.mix(card.body["bg"], accent or self.theme["FG"], 0.08),
                fg=accent or self.theme["MUTED"], font=fl.F_TINY(),
                padx=6, pady=3,
            ).pack(side="right")
        self._header_rule(card.body, accent)
        self._entrance_cards.append(card)
        card.enable_autofit()
        return card.body, card

    def _header_rule(self, body, accent=None):
        """Thin accent-tinted divider under a card header. Small detail,
        but it's what makes every panel read as one consistent, finished
        design system instead of a stack of ad-hoc frames."""
        rule = tk.Frame(
            body, bg=fl.mix(body["bg"], self.theme["FG"], 0.10),
            height=1,
        )
        rule.pack(fill="x", pady=(6, 8))
        return rule

    def _build_overview(self, parent):
        body, _ = self._card(
            parent, t("dashboard.system_overview"),
            accent=fl.METRIC_COLORS["cpu"], meta="Live",
            row=0, column=0,
            sticky="nsew", padx=(0, fl.GAP // 2),
        )
        self.overview_rows = {}
        row_accents = [
            self.theme["ACCENT"], fl.METRIC_COLORS["cpu"],
            fl.METRIC_COLORS["network"], fl.METRIC_COLORS["gpu"],
            fl.METRIC_COLORS["storage"], fl.METRIC_COLORS["ram"],
        ]
        fields = [("Operating System", "monitor"), ("Processor", "cpu"),
                  ("Uptime", "clock"), ("User", "user"),
                  ("System Type", "layers"), ("Power Plan", "battery")]
        for index, (label, icon) in enumerate(fields):
            row_bg = fl.mix(body["bg"], self.theme["FG"], 0.025)
            accent = row_accents[index % len(row_accents)]
            row = tk.Frame(
                body, bg=row_bg,
                highlightbackground=fl.mix(row_bg, self.theme["FG"], 0.08),
                highlightthickness=1,
            )
            row.pack(fill="x", pady=2)
            row.columnconfigure(1, weight=1)
            badge = hand_icon_label(row, icon, 18, accent,
                                    fl.mix(row_bg, accent, 0.16), padx=4, pady=3)
            badge.grid(row=0, column=0, padx=(6, 7), pady=4, sticky="w")
            tk.Label(
                row, text=label, bg=row_bg, fg=self.theme["MUTED"],
                font=fl.F_SMALL(), anchor="w",
            ).grid(row=0, column=1, sticky="ew", pady=4)
            value = tk.Label(row, text="—", bg=row_bg, fg=self.theme["FG"],
                             font=fl.F_SMALL(), anchor="e", justify="right",
                             wraplength=130)
            value.grid(row=0, column=2, padx=(6, 8), sticky="e", pady=4)
            row.bind(
                "<Configure>",
                lambda _e, value=value, row=row: value.config(
                    wraplength=max(78, row.winfo_width() * 2 // 5 - 8)
                ),
            )
            self.overview_rows[label] = value
        self._fill_static_overview()

    # Time-range options for the Live Performance chart: (label, seconds).
    CHART_WINDOWS = [("60s", 60), ("5 min", 300), ("15 min", 900)]

    def _build_performance(self, parent):
        body, _ = self._card(
            parent, "Live Performance",
            accent=fl.METRIC_COLORS["network"],
            row=0, column=1,
            sticky="nsew", padx=fl.GAP // 2,
        )
        legend = tk.Frame(body, bg=body["bg"])
        legend.pack(fill="x", pady=(4, 2))
        series = [("cpu", "CPU", fl.METRIC_COLORS["cpu"]),
                  ("ram", "RAM", fl.METRIC_COLORS["ram"]),
                  ("disk", "Disk", fl.METRIC_COLORS["disk"]),
                  ("network", "Network", fl.METRIC_COLORS["network"])]
        self._chart_legend_chips = {}
        saved_hidden = set(db.get_setting("dashboard_chart_hidden_series", []))

        def _toggle_series(key):
            visible = key in getattr(self.chart, "hidden", set())
            self.chart.set_series_visible(key, visible)
            self._refresh_legend_chip(key)
            db.set_setting("dashboard_chart_hidden_series",
                           sorted(self.chart.hidden))

        for key, label, color in series:
            chip = tk.Frame(legend, bg=body["bg"], cursor="hand2")
            chip.pack(side="left", padx=(0, 12))
            swatch = tk.Canvas(
                chip, width=10, height=10, bg=body["bg"],
                highlightthickness=0, bd=0, cursor="hand2",
            )
            swatch.pack(side="left", pady=2)
            swatch.create_oval(2, 2, 8, 8, fill=color, outline="")
            name_lbl = tk.Label(
                chip, text=label, bg=body["bg"], fg=self.theme["MUTED"],
                font=fl.F_TINY(), cursor="hand2", takefocus=1,
                highlightthickness=1, highlightbackground=body["bg"],
                highlightcolor=color,
            )
            name_lbl.pack(side="left", padx=4)
            self._chart_legend_chips[key] = (chip, swatch, name_lbl, color)
            # Click a legend chip to solo/hide that series on the chart -
            # handy when a low-value series like Network is buried under
            # CPU/RAM. Click again to bring it back. The label is also
            # keyboard-focusable (Tab) and toggles on Enter/Space, since
            # the swatch/frame click targets are mouse-only.
            for widget in (chip, swatch, name_lbl):
                widget.bind("<Button-1>", lambda _e, key=key:
                           _toggle_series(key))
            name_lbl.bind("<Return>", lambda _e, key=key: _toggle_series(key))
            name_lbl.bind("<space>", lambda _e, key=key: _toggle_series(key))
            attach_tooltip(swatch, f"Click to hide/show {label} on the chart")
            attach_tooltip(name_lbl, f"Click to hide/show {label} on the chart")
        self._build_chart_range_toggle(legend)
        # capacity/sample_interval_s stay in lockstep with REFRESH_MS so
        # "5 min" always means five real minutes of samples, not 5 min of
        # ticks at some other cadence.
        saved_window = db.get_setting("dashboard_chart_window_s", 60)
        capacity = max(2, round(saved_window / (REFRESH_MS / 1000.0)))
        self.chart = LineChart(body, self.theme, series, aero=self.aero,
                               bg=body["bg"], capacity=capacity,
                               sample_interval_s=REFRESH_MS / 1000.0)
        self.chart.hidden = {k for k in saved_hidden
                             if k in self.chart.data}
        for key in self._chart_legend_chips:
            self._refresh_legend_chip(key)
        self.chart.pack(fill="both", expand=True)
        self._set_chart_window(saved_window, persist=False)

    def _refresh_legend_chip(self, key):
        """Dim a chart legend chip's label when its series is hidden, so
        the toggle state is visible at a glance (not just inferable from
        the chart itself)."""
        entry = getattr(self, "_chart_legend_chips", {}).get(key)
        if not entry:
            return
        _chip, swatch, name_lbl, color = entry
        hidden = key in getattr(self.chart, "hidden", set())
        fg = fl.mix(self.theme["MUTED"], self.chart["bg"], 0.55) if hidden \
            else self.theme["MUTED"]
        name_lbl.config(fg=fg, font=fl.F_TINY())
        swatch.itemconfig("all",
                          fill=fl.mix(color, self.chart["bg"], 0.6)
                          if hidden else color)

    def _build_chart_range_toggle(self, parent):
        """Segmented Last-60s / 5-min / 15-min control for the chart."""
        th = self.theme
        # Own row under the legend chips: beside them there wasn't room in
        # a narrow card, and the buttons were cut off ("60s m").
        toggle = tk.Frame(parent.master, bg=parent["bg"])
        toggle.pack(fill="x", anchor="e", after=parent)
        spacer = tk.Frame(toggle, bg=parent["bg"])
        spacer.pack(side="left", expand=True)
        self._chart_range_buttons = {}
        for label, seconds in self.CHART_WINDOWS:
            btn = tk.Label(
                toggle, text=label, bg=parent["bg"], fg=th["MUTED"],
                font=fl.F_TINY(), padx=8, pady=3, cursor="hand2",
            )
            btn.pack(side="right", padx=(2, 0))
            btn.bind("<Button-1>", lambda _e, seconds=seconds:
                     self._set_chart_window(seconds))
            self._chart_range_buttons[seconds] = btn

    def _set_chart_window(self, seconds, persist=True):
        """Switch the Live Performance chart's visible time range."""
        if getattr(self, "chart", None) is not None:
            self.chart.set_window_seconds(seconds)
        self._chart_window_s = seconds
        for win_seconds, btn in getattr(self, "_chart_range_buttons", {}).items():
            active = win_seconds == seconds
            btn.config(
                bg=fl.mix(btn.master["bg"], fl.METRIC_COLORS["network"],
                          0.22 if active else 0),
                fg=fl.METRIC_COLORS["network"] if active else self.theme["MUTED"],
            )
        if persist:
            db.set_setting("dashboard_chart_window_s", seconds)

    def _ordered_quick_actions(self):
        """QUICK_ACTIONS re-sorted by whatever order the user last
        dragged them into (persisted via db.set_setting), falling back
        to the built-in order for anything not in the saved list -
        covers both first launch and any future action being added to
        QUICK_ACTIONS later."""
        saved = db.get_setting("quick_actions_order", None)
        if not saved:
            return list(QUICK_ACTIONS)
        by_label = {label: (label, icon, sub) for label, icon, sub in QUICK_ACTIONS}
        ordered = [by_label[label] for label in saved if label in by_label]
        remaining = [item for item in QUICK_ACTIONS if item[0] not in saved]
        return ordered + remaining

    def _build_quick_actions(self, parent):
        card = GlassCard(
            parent, self.theme, aero=self.aero, gradient=True,
            accent=self.theme["ACCENT2"],
        )
        # Quick Actions is a vertical command list. Give it a stable natural
        # height so a compact responsive rail cannot collapse it to 1px.
        card.pack(fill="x")
        card.enable_autofit(on_change=self._schedule_rail_fit)
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(
            header, t("dashboard.quick_actions"), self.theme,
            fl.F_SUBTITLE(),
        ).pack(side="left")
        tk.Label(
            header, text=f"{len(QUICK_ACTIONS)} SHORTCUTS",
            bg=fl.mix(body["bg"], self.theme["FG"], 0.08),
            fg=self.theme["MUTED"], font=fl.F_TINY(), padx=6, pady=3,
        ).pack(side="right")
        self._header_rule(body, self.theme["ACCENT2"])
        tk.Label(
            body, text="Drag the dots to pin your favorites at the top",
            bg=body["bg"], fg=self.theme["MUTED"], font=fl.F_TINY(),
        ).pack(anchor="w", pady=(0, 4))
        # Keep the established vertical action rail.  The labels are allowed
        # to wrap to the current rail width instead of being clipped.
        list_frame = tk.Frame(body, bg=body["bg"])
        list_frame.pack(fill="x", pady=(2, 0))
        self._qa_list_frame = list_frame
        self._qa_rows = []       # [(label, row_frame), ...] current order
        self._qa_drag = {"active": False, "row": None}
        action_colors = (
            fl.METRIC_COLORS["cpu"], fl.METRIC_COLORS["storage"],
            fl.METRIC_COLORS["gpu"], fl.METRIC_COLORS["ram"],
            fl.METRIC_COLORS["network"], self.theme["ACCENT2"],
        )
        for index, (label, icon, subtitle) in enumerate(self._ordered_quick_actions()):
            row = self._action_row(list_frame, icon, label, subtitle,
                             lambda label=label: self._open_named_tool(label),
                             accent=action_colors[index % len(action_colors)])
            self._qa_rows.append((label, row))
        link = tk.Label(body, text="View all actions  →", bg=body["bg"],
                        fg=self.theme["ACCENT"], font=fl.F_SMALL(),
                        cursor="hand2")
        link.pack(anchor="e", pady=(4, 0))
        link.bind("<Button-1>", lambda _e: self._open_enable_disable_tools())
        self._entrance_cards.append(card)

    # -- Quick Actions drag-to-reorder ("pinning") -----------------------
    def _qa_drag_start(self, row):
        self._qa_drag = {"active": True, "row": row}
        row.configure(highlightbackground=self.theme["ACCENT2"],
                     highlightthickness=2)

    def _qa_drag_motion(self, _event=None):
        drag = getattr(self, "_qa_drag", None)
        if not drag or not drag.get("active"):
            return
        row = drag["row"]
        rows = self._qa_rows
        current_index = next(
            (i for i, (_label, r) in enumerate(rows) if r is row), None)
        if current_index is None or not row.winfo_exists():
            return
        list_frame = self._qa_list_frame
        pointer_y = list_frame.winfo_pointery() - list_frame.winfo_rooty()
        target_index = current_index
        for i, (_label, r) in enumerate(rows):
            if not r.winfo_exists():
                continue
            top = r.winfo_y()
            if top <= pointer_y < top + r.winfo_height():
                target_index = i
                break
        if target_index != current_index:
            item = rows.pop(current_index)
            rows.insert(target_index, item)
            for _label, r in rows:
                r.pack_forget()
            for _label, r in rows:
                r.pack(fill="x", pady=2)

    def _qa_drag_end(self):
        drag = getattr(self, "_qa_drag", {})
        row = drag.get("row")
        if row is not None and row.winfo_exists():
            row.configure(
                highlightbackground=fl.mix(row["bg"], self.theme["FG"], 0.08),
                highlightthickness=1)
        self._qa_drag = {"active": False, "row": None}
        order = [label for label, r in self._qa_rows if r.winfo_exists()]
        if order:
            db.set_setting("quick_actions_order", order)
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Quick Actions order saved", kind="success")

    def _action_row(self, parent, icon, title, subtitle, command,
                    accent=None):
        """One Quick-Actions row: drag grip, pill icon badge, title/subtitle
        stack, trailing chevron. Reused for every action in QUICK_ACTIONS.
        Returns the row frame so callers can track/reorder it (pinning)."""
        bg = parent["bg"]
        accent = accent or self.theme["ACCENT"]
        normal_stroke = fl.mix(bg, self.theme["FG"], 0.08)
        row = tk.Frame(
            parent, bg=bg,
            highlightbackground=normal_stroke,
            highlightthickness=1,
        )
        row.pack(fill="x", pady=2)

        # Drag handle - reordering only starts from here, so the rest of
        # the row keeps its original "click opens the tool" behavior with
        # no ambiguity between a click and the start of a drag.
        grip = hand_icon_label(row, "grip", 16, self.theme["MUTED"], bg,
                               cursor="fleur")
        grip.pack(side="left", padx=(3, 0), pady=2)
        grip.bind("<ButtonPress-1>", lambda _e, row=row: self._qa_drag_start(row))
        grip.bind("<B1-Motion>", self._qa_drag_motion)
        grip.bind("<ButtonRelease-1>", lambda _e: self._qa_drag_end())

        badge_bg = fl.glass(self.theme, "LAYER_2", self.aero, 0.16)
        badge = hand_icon_label(row, CODE_TO_ICON.get(icon, icon), 20, accent,
                                badge_bg, padx=6, pady=4)
        badge.pack(side="left", padx=(6, 8), pady=2)
        text_col = tk.Frame(row, bg=bg)
        text_col.pack(side="left", fill="x", expand=True)
        title_lbl = tk.Label(text_col, text=title, bg=bg, fg=self.theme["FG"],
                             font=fl.F_BODY(), anchor="w", justify="left",
                             wraplength=140)
        title_lbl.pack(fill="x", anchor="w")
        sub_lbl = tk.Label(text_col, text=subtitle, bg=bg, fg=self.theme["MUTED"],
                           font=fl.F_SMALL(), anchor="w", justify="left",
                           wraplength=140)
        sub_lbl.pack(fill="x", anchor="w")
        chev = tk.Label(row, text="›", bg=bg, fg=self.theme["MUTED"],
                        font=fl.F_BODY())
        chev.pack(side="right", padx=(4, 2))

        hover_bg = fl.glass(self.theme, "LAYER_2", self.aero, 0.12)

        def _resize_text(_e=None):
            available = max(72, row.winfo_width() - 72)
            title_lbl.config(wraplength=available)
            sub_lbl.config(wraplength=available)

        row.bind("<Configure>", _resize_text)

        def _enter(_e=None):
            for w in (row, text_col):
                w.config(bg=hover_bg)
            row.config(highlightbackground=fl.mix(accent, "#ffffff", 0.12))
            title_lbl.config(bg=hover_bg)
            sub_lbl.config(bg=hover_bg)
            chev.config(bg=hover_bg, fg=accent)

        def _leave(_e=None):
            for w in (row, text_col):
                w.config(bg=bg)
            row.config(highlightbackground=normal_stroke)
            title_lbl.config(bg=bg)
            sub_lbl.config(bg=bg)
            chev.config(bg=bg, fg=self.theme["MUTED"])

        for w in (row, badge, text_col, title_lbl, sub_lbl, chev):
            w.bind("<Enter>", _enter)
            w.bind("<Leave>", _leave)
            w.bind("<Button-1>", lambda _e: command())
            w.configure(cursor="hand2")
        return row

    def _build_recent(self, parent):
        card = GlassCard(parent, self.theme, aero=self.aero,
                         accent=fl.METRIC_COLORS["gpu"])
        card.pack(fill="x", pady=(fl.GAP, 0))
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(header, "Recent Tools", self.theme,
                   fl.F_SUBTITLE()).pack(side="left")
        tk.Label(
            header, text="Last 5",
            bg=fl.mix(body["bg"], self.theme["FG"], 0.08),
            fg=self.theme["MUTED"], font=fl.F_TINY(), padx=6, pady=3,
        ).pack(side="right", padx=(8, 8))
        FluentButton(
            header, "Clear", theme=self.theme, aero=self.aero,
            kind="subtle", height=24, width=52, backdrop=body["bg"],
            font_=fl.F_TINY(), command=self._clear_recent,
        ).pack(side="right", padx=(8, 0))
        self._header_rule(body, fl.METRIC_COLORS["gpu"])
        self.recent_row = tk.Frame(body, bg=body["bg"], height=116)
        self.recent_row.pack(fill="x", pady=(8, 0))
        # Reserve enough height for an icon, a wrapped tool name, and its
        # action line.  The old 44px strip was the source of the visible
        # clipping when real tool names were longer than one line.
        self.recent_row.configure(height=116)
        self.recent_row.pack_propagate(False)
        self.recent_row.grid_rowconfigure(0, weight=1)
        self._entrance_cards.append(card)
        self.refresh_recent()

    def refresh_recent(self):
        """Rebuild the Recent Tools strip from the app's real history, as
        icon + title/category tiles matching the mockup (rather than the
        old plain "◷ tool name" buttons)."""
        for child in self.recent_row.winfo_children():
            child.destroy()
        recents = self.app.get_recent_tools()[:5]
        if not recents:
            tk.Label(self.recent_row,
                     text="Tools you open will appear here for one-click access.",
                     bg=self.recent_row["bg"], fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w")
            return
        # Keep the original Recent Tools strip, but give every tile enough
        # height for the real tool name and its useful action description.
        for i in range(len(recents)):
            self.recent_row.columnconfigure(i, weight=1, uniform="recent")
        recent_colors = (
            fl.METRIC_COLORS["cpu"], fl.METRIC_COLORS["ram"],
            fl.METRIC_COLORS["network"], fl.METRIC_COLORS["gpu"],
            fl.METRIC_COLORS["storage"],
        )
        for i, (cat, tool) in enumerate(recents[:5]):
            tile = self._recent_tile(
                self.recent_row, "↗", tool,
                RECENT_TOOL_ACTIONS.get(tool, f"Open {cat} tool"),
                                     lambda cat=cat, tool=tool:
                                     self.app.open_tool(cat, tool),
                                     accent=recent_colors[i % len(recent_colors)])
            tile.grid(row=0, column=i, sticky="nsew",
                      padx=(0 if i == 0 else 6, 0))

    def _build_activity(self, parent):
        """RECENT ACTIVITY log card from the concept mockup: a compact
        timestamp / tool / status list, separate from the Recent Tools
        tiles above (those are shortcuts; this is a history log)."""
        card = GlassCard(parent, self.theme, aero=self.aero,
                         accent=fl.METRIC_COLORS["network"])
        card.pack(fill="x", pady=(fl.GAP, 0))
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(header, "Recent Activity", self.theme,
                   fl.F_SUBTITLE()).pack(side="left")
        self._entrance_cards.append(card)
        self._header_rule(body, fl.METRIC_COLORS["network"])
        self.activity_list = tk.Frame(body, bg=body["bg"])
        self.activity_list.pack(fill="x", pady=(2, 0))
        self.refresh_activity()

    def refresh_activity(self):
        for child in self.activity_list.winfo_children():
            child.destroy()
        rows = get_activity_log()
        if not rows:
            tk.Label(self.activity_list,
                     text="Completed scans and opened tools will show up here.",
                     bg=self.activity_list["bg"], fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w")
            return
        status_color = {"Completed": fl.GOOD, "Warning": fl.WARN}
        for occurred_at, title, _source, status in rows:
            row = tk.Frame(self.activity_list, bg=self.activity_list["bg"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=_activity_time(occurred_at), bg=row["bg"],
                     fg=self.theme["MUTED"], font=fl.font(9, mono=True),
                     width=6, anchor="w").pack(side="left")
            tk.Label(row, text=title, bg=row["bg"], fg=self.theme["FG"],
                     font=fl.F_SMALL(), anchor="w").pack(
                         side="left", fill="x", expand=True)
            tk.Label(row, text=status, bg=row["bg"],
                     fg=status_color.get(status, self.theme["MUTED"]),
                     font=fl.font(9, "bold")).pack(side="right")

    def _recent_tile(self, parent, icon, title, subtitle, command,
                     accent=None):
        bg = parent["bg"]
        accent = accent or self.theme["ACCENT"]
        tile = tk.Frame(parent, bg=bg, cursor="hand2")
        tile_bg = fl.glass(self.theme, "LAYER_1", self.aero, 0.16)
        inner = tk.Frame(tile, bg=tile_bg)
        inner.pack(fill="both", expand=True)
        accent_line = tk.Frame(inner, bg=accent, height=2)
        accent_line.pack(fill="x", side="top")
        pad = tk.Frame(inner, bg=inner["bg"])
        pad.pack(fill="both", expand=True, padx=8, pady=6)
        badge_bg = fl.glass(self.theme, "LAYER_2", self.aero, 0.18)
        badge = hand_icon_label(pad, {"\u2197": "open", "\u2605": "star"}.get(icon, icon),
                                20, accent, badge_bg, padx=5, pady=4)
        badge.pack(anchor="w")
        title_lbl = tk.Label(pad, text=title, bg=pad["bg"],
                             fg=self.theme["FG"], font=fl.F_BODY(),
                             anchor="w", justify="left", wraplength=120)
        title_lbl.pack(fill="x", anchor="w", pady=(4, 0))
        sub_lbl = tk.Label(pad, text=subtitle, bg=pad["bg"],
                           fg=self.theme["MUTED"], font=fl.F_SMALL(),
                           anchor="w", justify="left", wraplength=120)
        sub_lbl.pack(fill="x", anchor="w")

        def _resize_tile_text(_e=None):
            width = max(68, tile.winfo_width() - 20)
            title_lbl.config(wraplength=width)
            sub_lbl.config(wraplength=width)

        tile.bind("<Configure>", _resize_tile_text)

        hover_bg = fl.mix(tile_bg, accent, 0.12)

        def _enter(_e=None):
            for widget in (tile, inner, pad, title_lbl, sub_lbl):
                widget.configure(bg=hover_bg)
            accent_line.configure(bg=fl.mix(accent, "#ffffff", 0.20))
            badge.configure(bg=fl.mix(hover_bg, accent, 0.20))

        def _leave(_e=None):
            tile.configure(bg=bg)
            for widget in (inner, pad, title_lbl, sub_lbl):
                widget.configure(bg=tile_bg)
            accent_line.configure(bg=accent)
            badge.configure(bg=badge_bg)

        widgets = [tile, inner, pad, badge, title_lbl, sub_lbl]
        for w in widgets:
            w.bind("<Button-1>", lambda _e: command())
            w.bind("<Enter>", _enter)
            w.bind("<Leave>", _leave)
            w.configure(cursor="hand2")
        return tile

    def _build_pinned(self, parent):
        """Quick Access: the tools the user has starred in the All Tools
        gallery, one click away from the dashboard instead of buried in
        the Pinned Favorites view - probably the highest-value nav
        shortcut on this page."""
        card = GlassCard(parent, self.theme, aero=self.aero,
                         accent=fl.METRIC_COLORS["storage"])
        card.pack(fill="x", pady=(fl.GAP, 0))
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(header, "Quick Access", self.theme,
                   fl.F_SUBTITLE()).pack(side="left")
        self.pinned_count_lbl = tk.Label(
            header, text="0 PINNED",
            bg=fl.mix(body["bg"], self.theme["FG"], 0.08),
            fg=self.theme["MUTED"], font=fl.F_TINY(), padx=6, pady=3,
        )
        self.pinned_count_lbl.pack(side="right", padx=(8, 8))
        FluentButton(
            header, "Manage", theme=self.theme, aero=self.aero,
            kind="subtle", height=24, width=64, backdrop=body["bg"],
            font_=fl.F_TINY(), command=self._open_pinned_manager,
        ).pack(side="right", padx=(8, 0))
        self._header_rule(body, fl.METRIC_COLORS["storage"])
        self.pinned_row = tk.Frame(body, bg=body["bg"], height=116)
        self.pinned_row.pack(fill="x", pady=(8, 0))
        self.pinned_row.pack_propagate(False)
        self.pinned_row.grid_rowconfigure(0, weight=1)
        self._entrance_cards.append(card)
        self.refresh_pinned()

    def refresh_pinned(self):
        """Rebuild the Quick Access strip from the app's real favorites,
        so pinning/unpinning a tool anywhere (this card or the All Tools
        gallery's star) shows up here without restarting the app."""
        for child in self.pinned_row.winfo_children():
            child.destroy()
        pinned = self.app.get_pinned_tools() if hasattr(self.app, "get_pinned_tools") else []
        self.pinned_count_lbl.config(text=f"{len(pinned)} PINNED")
        if not pinned:
            tk.Label(self.pinned_row,
                     text="Star a tool in All Tools to pin it here for one-click access.",
                     bg=self.pinned_row["bg"], fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w")
            return
        shown = pinned[:5]
        for i in range(len(shown)):
            self.pinned_row.columnconfigure(i, weight=1, uniform="pinned")
        pinned_colors = (
            fl.METRIC_COLORS["storage"], fl.METRIC_COLORS["cpu"],
            fl.METRIC_COLORS["ram"], fl.METRIC_COLORS["network"],
            fl.METRIC_COLORS["gpu"],
        )
        for i, (cat, tool) in enumerate(shown):
            tile = self._recent_tile(
                self.pinned_row, "★", tool,
                RECENT_TOOL_ACTIONS.get(tool, f"Open {cat} tool"),
                lambda cat=cat, tool=tool: self.app.open_tool(cat, tool),
                accent=pinned_colors[i % len(pinned_colors)],
            )
            tile.grid(row=0, column=i, sticky="nsew",
                      padx=(0 if i == 0 else 6, 0))

    def _open_pinned_manager(self):
        """\"Manage\" routes to the full Pinned Favorites view in All Tools,
        where every star can be toggled - this card is a shortcut, not a
        second place to maintain the pin list."""
        if hasattr(self.app, "open_tool_group_tab"):
            self.app.open_all_tools_tab()
            if getattr(self.app, "_all_tools_page", None):
                self.app._all_tools_page.show_favorites()

    def _build_health(self, parent):
        card = GlassCard(parent, self.theme, aero=self.aero, gradient=True,
                         accent=self.theme["ACCENT_GLOW"])
        card.pack(fill="x", pady=(fl.GAP, 0))
        card.enable_autofit(on_change=self._schedule_rail_fit)
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(
            header, "System Health", self.theme, fl.F_SUBTITLE(),
        ).pack(side="left")
        self.health_live_label = tk.Label(
            header, text="Live score",
            bg=fl.mix(body["bg"], self.theme["ACCENT"], 0.10),
            fg=self.theme["ACCENT"], font=fl.F_TINY(), padx=6, pady=3,
        )
        self.health_live_label.pack(side="right", pady=3)
        gear = hand_icon_label(header, "gear", 18, self.theme["MUTED"],
                               body["bg"], cursor="hand2")
        gear.pack(side="right", padx=(0, 6))
        gear.bind("<Button-1>", lambda _e: self._open_health_threshold_editor())
        self._header_rule(body, self.theme["ACCENT_GLOW"])
        self.ring = HealthRing(body, self.theme, size=122, aero=self.aero,
                               bg=body["bg"])
        self.ring.pack(pady=(4, 3))
        try:
            from gui._td_devmode import arm as _arm_devmode
            _arm_devmode(self.ring, self.theme, self.aero,
                        clicks=5, button="<Button-3>")
        except Exception:
            pass
        self.health_note = tk.Label(body, text="Measuring…", bg=body["bg"],
                                    fg=self.theme["MUTED"], font=fl.F_SMALL(),
                                    wraplength=210, justify="center",
                                    anchor="center")
        self.health_note.pack(fill="x", pady=(0, 2))
        self.health_meta = tk.Label(
            body, text="Live score · CPU, memory, and storage pressure",
            bg=body["bg"], fg=self.theme["MUTED"], font=fl.F_TINY(),
            wraplength=220, justify="center", anchor="center")
        self.health_meta.pack(fill="x")
        parent.bind(
            "<Configure>",
            lambda _e: (
                self.health_note.config(
                    wraplength=max(120, parent.winfo_width() - 34)),
                self.health_meta.config(
                    wraplength=max(120, parent.winfo_width() - 34)),
            ),
            add="+",
        )
        self._entrance_cards.append(card)

    def _build_storage(self, parent):
        card = GlassCard(parent, self.theme, aero=self.aero,
                         accent=fl.WARN)
        card.pack(fill="both", expand=True, pady=(fl.GAP, 0))
        body = card.body
        header = tk.Frame(body, bg=body["bg"])
        header.pack(fill="x")
        card_label(
            header, "Storage", self.theme, fl.F_SUBTITLE(),
        ).pack(side="left")
        tk.Label(
            header, text="Live",
            bg=fl.mix(body["bg"], self.theme["ACCENT"], 0.10),
            fg=self.theme["ACCENT"], font=fl.F_TINY(), padx=6, pady=3,
        ).pack(side="right")
        self.storage_summary = tk.Label(
            header, text="DRIVES —", bg=body["bg"],
            fg=self.theme["MUTED"], font=fl.F_TINY(),
        )
        self.storage_summary.pack(side="right", padx=(0, 8))
        self._header_rule(body, fl.WARN)
        self.storage_holder = tk.Frame(body, bg=body["bg"])
        self.storage_holder.pack(fill="x", pady=(6, 0))
        self.storage_widgets = {}
        FluentButton(body, "Get Disk Tools", theme=self.theme, aero=self.aero,
                     kind="subtle", height=32, backdrop=body["bg"],
                     font_=fl.F_SMALL(),
                     command=self._open_enable_disable_tools
                     ).pack(fill="x", side="bottom", pady=(8, 0))
        self._entrance_cards.append(card)
        self._storage_card = card
        card.enable_autofit(on_change=self._schedule_rail_fit)

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------
    def open_qml_dashboard(self):
        """Launch the optional Qt Quick Liquid Glass companion window."""
        try:
            if importlib.util.find_spec("PySide6") is None:
                from tkinter import messagebox
                messagebox.showinfo(
                    "Liquid Glass needs PySide6",
                    "Install the optional Qt Quick dependency with:\n\n"
                    "python -m pip install -r requirements-qml.txt",
                    parent=self.winfo_toplevel())
                return
            script = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                  "gui", "qml_dashboard.py")
            subprocess.Popen([sys.executable, script],
                             cwd=os.path.dirname(os.path.dirname(__file__)),
                             close_fds=True)
        except Exception as exc:
            try:
                from tkinter import messagebox
                messagebox.showerror(
                    "Liquid Glass unavailable", f"Could not launch dashboard: {exc}",
                    parent=self.winfo_toplevel())
            except Exception:
                pass

    def toggle_mini_mode(self):
        overlay = getattr(self, "_mini_overlay", None)
        try:
            if overlay is not None and overlay.winfo_exists():
                overlay.close()
                return
        except tk.TclError:
            pass
        try:
            self._mini_overlay = MiniDashboardOverlay(self)
            self._mini_overlay.lift()
        except Exception as exc:
            self._mini_overlay = None
            try:
                self.app.show_toast(f"Mini Mode unavailable: {exc}", kind="error")
            except Exception:
                pass

    def _manual_refresh(self):
        """Run one immediate sample without creating duplicate timers."""
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        self._tick()

    def _greeting_text(self):
        hour = datetime.now().hour
        part = "morning" if hour < 12 else ("afternoon" if hour < 18 else "evening")
        return f"Good {part}, {self.app.get_user_name()}!"

    def _fill_static_overview(self):
        rows = self.overview_rows
        rows["Operating System"].config(
            text=f"{platform.system()} {platform.release()}")
        rows["Processor"].config(text=(platform.processor() or "—")[:34])
        rows["User"].config(text=self.app.get_user_name())
        rows["System Type"].config(
            text=f"{platform.machine()} · {platform.architecture()[0]}")
        rows["Power Plan"].config(text=self.app.get_power_plan())

    @staticmethod
    def _fmt_bytes(n):
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if n < 1024 or unit == "TB":
                return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
            n /= 1024.0
        return f"{n:.1f} TB"

    def _sample(self):
        """One cheap pass over psutil; returns a dict the widgets consume."""
        out = {}
        if psutil is None:
            return out
        try:
            out["cpu"] = psutil.cpu_percent(interval=None)
            vm = psutil.virtual_memory()
            out["ram"] = vm.percent
            out["ram_text"] = (f"{self._fmt_bytes(vm.used)} / "
                               f"{self._fmt_bytes(vm.total)} "
                               f"· {self._fmt_bytes(vm.available)} free")
            usage = psutil.disk_usage("C:\\" if platform.system() == "Windows" else "/")
            out["storage"] = usage.percent
            out["storage_text"] = (f"{self._fmt_bytes(usage.used)} / "
                                   f"{self._fmt_bytes(usage.total)} "
                                   f"· {self._fmt_bytes(usage.free)} free")
            # Disk + network throughput need deltas between samples.
            now = time.time()
            io = psutil.disk_io_counters()
            if io and self._disk_last:
                delta = (io.read_bytes + io.write_bytes) - self._disk_last
                out["disk"] = min(100.0, delta / (20 * 1024 * 1024) * 100)
            if io:
                self._disk_last = io.read_bytes + io.write_bytes
            net = psutil.net_io_counters()
            if net and self._net_last and self._net_time:
                span = max(0.5, now - self._net_time)
                down = (net.bytes_recv - self._net_last[0]) / span
                up = (net.bytes_sent - self._net_last[1]) / span
                out["net_down"], out["net_up"] = down, up
                out["network"] = min(100.0, (down + up) / (12.5 * 1024 * 1024) * 100)
            if net:
                self._net_last = (net.bytes_recv, net.bytes_sent)
                self._net_time = now
            boot = psutil.boot_time()
            secs = int(max(0, time.time() - boot))
            out["uptime"] = (f"{secs // 86400}d {secs % 86400 // 3600}h "
                             f"{secs % 3600 // 60}m")
        except Exception:
            pass
        return out

    def _tick(self):
        if self._destroyed:
            return
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        s = self._sample()
        footer_sample = getattr(self, "footer_sample", None)
        if footer_sample is not None:
            footer_sample.config(
                text=f"Updated {datetime.now().strftime('%H:%M:%S')}",
            )
        cpu = s.get("cpu")
        if cpu is not None:
            self.cards["cpu"].update_metric(
                f"{cpu:.0f}%", self.app.get_cpu_name(), cpu)
            self.cards["ram"].update_metric(
                f"{s.get('ram', 0):.0f}%", s.get("ram_text", ""), s.get("ram"))
            self.cards["storage"].update_metric(
                f"{s.get('storage', 0):.0f}%", s.get("storage_text", ""),
                s.get("storage"))
            gpu_value, gpu_sub, gpu_sample = self.app.get_gpu_snapshot()
            self.cards["gpu"].update_metric(gpu_value, gpu_sub, gpu_sample)
            overlay = getattr(self, "_mini_overlay", None)
            try:
                if overlay is not None and overlay.winfo_exists():
                    overlay.update_metrics(s, gpu_value, gpu_sub, gpu_sample)
                else:
                    self._mini_overlay = None
            except tk.TclError:
                self._mini_overlay = None
            down = s.get("net_down", 0) / 125000.0     # bytes/s -> Mbps
            up = s.get("net_up", 0) / 125000.0
            network_label = "Connected" if self._net_last is not None else "—"
            # Keep the status word inside compact metric cards; the detailed
            # Network Monitor still exposes the full connection state.
            if self.cards["network"].body.winfo_width() < 175 and network_label == "Connected":
                network_label = "Online"
            self.cards["network"].update_metric(
                network_label,
                f"↓ {down:.1f} Mbps    ↑ {up:.1f} Mbps",
                s.get("network", 0))
            self.chart.push({k: s[k] for k in ("cpu", "ram", "disk", "network")
                             if k in s})
            self.hero.set_telemetry(
                CPU=f"{cpu:.0f}%",
                RAM=f"{s.get('ram', 0):.0f}%",
                DISK=f"{s.get('storage', 0):.0f}%",
                NET="ON" if self._net_last is not None else "--",
            )
            self.overview_rows["Uptime"].config(text=s.get("uptime", "—"))
            self._update_health(s)
        self._update_storage()

        self._job = self.after(_refresh_interval_ms(), self._tick)

    # Fallback CPU/RAM % thresholds when the user hasn't customized them.
    # "Fair" triggers once either metric crosses the fair threshold;
    # "At risk" once either crosses the risk threshold.
    DEFAULT_HEALTH_THRESHOLDS = {"fair_cpu": 70, "risk_cpu": 90,
                                 "fair_ram": 75, "risk_ram": 90}

    def _health_thresholds(self):
        saved = db.get_setting("dashboard_health_thresholds", None)
        thresholds = dict(self.DEFAULT_HEALTH_THRESHOLDS)
        if isinstance(saved, dict):
            thresholds.update({k: v for k, v in saved.items()
                               if k in thresholds})
        return thresholds

    def _update_health(self, sample):
        """Score for the ring is still the smooth CPU/RAM/disk blend (it
        needs a continuous number), but the Good/Fair/At-risk *caption* —
        and therefore every notice/color driven off it — now comes from
        the user's own configurable CPU/RAM thresholds instead of a
        hardcoded score cut-off."""
        cpu = sample.get("cpu", 0)
        ram = sample.get("ram", 0)
        disk = sample.get("storage", 0)
        score = 100 - (cpu * 0.25 + ram * 0.30 + max(0, disk - 60) * 0.6)
        score = max(0, min(100, score))
        t = self._health_thresholds()
        if cpu >= t["risk_cpu"] or ram >= t["risk_ram"]:
            caption = "At risk"
        elif cpu >= t["fair_cpu"] or ram >= t["fair_ram"]:
            caption = "Fair"
        else:
            caption = "Good"
        self.ring.set_score(score, caption)
        notes = {
            "Good": "Your system is in good condition.",
            "Fair": "Some resources are under pressure — use a cleanup tool.",
            "At risk": "High load or low free space. Enable optional tools from Core Module Manager.",
        }
        hero_status = {
            "Good": ("System is healthy  •  Everything looks good.", fl.GOOD),
            "Fair": ("System needs attention  •  Some resources are under pressure.", fl.WARN),
            "At risk": ("System at risk  •  High load or low free space.", fl.BAD),
        }
        status_text, status_color = hero_status[caption]
        self.health_note.config(text=notes[caption], fg=status_color)
        self.health_live_label.config(
            text=caption.upper(), fg=status_color,
            bg=fl.mix(self.health_live_label.master["bg"], status_color, 0.10),
        )
        self.health_meta.config(
            text=f"Score {score:.0f}/100  ·  CPU, memory, storage pressure",
        )
        self.hero.set_status(status_text, status_color)

        # Edge-triggered: log to the Notification Center only when the
        # caption actually gets worse, not on every sample - otherwise a
        # machine sitting at "At risk" would spam a new entry every poll.
        prev = getattr(self, "_last_health_caption", None)
        rank = {"Good": 0, "Fair": 1, "At risk": 2}
        if hasattr(self.app, "notify") and prev is not None and rank[caption] > rank[prev]:
            which = ("CPU" if cpu >= t.get("risk_cpu", t.get("fair_cpu", 0))
                     or cpu >= t.get("fair_cpu", 0) else
                     "RAM" if ram >= t.get("risk_ram", t.get("fair_ram", 0))
                     or ram >= t.get("fair_ram", 0) else "storage")
            level = "error" if caption == "At risk" else "warning"
            self.app.notify(
                "Disk health warning" if which == "storage" else f"{which} usage warning",
                f"{which.title()} reported elevated activity — system is now \"{caption}\".",
                kind=level, source="Dashboard",
            )
        self._last_health_caption = caption

    def _open_health_threshold_editor(self):
        """Small dialog letting the user set what CPU/RAM % counts as
        'Fair' vs 'At risk', replacing the old hardcoded cut-offs."""
        th = self.theme
        current = self._health_thresholds()
        win = tk.Toplevel(self)
        win.title("Health alert thresholds")
        win.configure(bg=th["BG"])
        win.transient(self.winfo_toplevel())
        win.resizable(False, False)

        tk.Label(
            win, text="Set what CPU/RAM usage counts as Fair vs At risk",
            bg=th["BG"], fg=th["FG"], font=fl.F_SUBTITLE(),
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=14, pady=(14, 8))

        vars_ = {}
        rows = [
            ("CPU %", "fair_cpu", "risk_cpu"),
            ("RAM %", "fair_ram", "risk_ram"),
        ]
        tk.Label(win, text="", bg=th["BG"]).grid(row=1, column=0)
        tk.Label(win, text="Fair at ≥", bg=th["BG"], fg=th["MUTED"],
                 font=fl.F_SMALL()).grid(row=1, column=1, padx=8)
        tk.Label(win, text="At risk at ≥", bg=th["BG"], fg=th["MUTED"],
                 font=fl.F_SMALL()).grid(row=1, column=2, padx=8)
        for i, (label, fair_key, risk_key) in enumerate(rows, start=2):
            tk.Label(win, text=label, bg=th["BG"], fg=th["FG"],
                     font=fl.F_SMALL()).grid(row=i, column=0, sticky="w",
                                             padx=14, pady=4)
            fair_var = tk.IntVar(value=int(current[fair_key]))
            risk_var = tk.IntVar(value=int(current[risk_key]))
            vars_[fair_key] = fair_var
            vars_[risk_key] = risk_var
            tk.Spinbox(win, from_=1, to=100, textvariable=fair_var,
                      width=5).grid(row=i, column=1, padx=8)
            tk.Spinbox(win, from_=1, to=100, textvariable=risk_var,
                      width=5).grid(row=i, column=2, padx=8)

        error_lbl = tk.Label(win, text="", bg=th["BG"], fg=fl.BAD,
                             font=fl.F_TINY())
        error_lbl.grid(row=4, column=0, columnspan=3, sticky="w",
                        padx=14)

        def _save():
            values = {k: v.get() for k, v in vars_.items()}
            for _label, fair_key, risk_key in rows:
                if not (1 <= values[fair_key] <= 100 and
                        1 <= values[risk_key] <= 100):
                    error_lbl.config(text="Thresholds must be between 1 and 100.")
                    return
                if values[fair_key] > values[risk_key]:
                    error_lbl.config(
                        text="'Fair at' can't be higher than 'At risk at'.")
                    return
            db.set_setting("dashboard_health_thresholds", values)
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Health thresholds updated", kind="success")
            win.destroy()

        btn_row = tk.Frame(win, bg=th["BG"])
        btn_row.grid(row=5, column=0, columnspan=3, sticky="e",
                     padx=14, pady=(6, 14))
        FluentButton(btn_row, "Cancel", theme=th, aero=self.aero,
                     kind="subtle", height=30, command=win.destroy,
                     ).pack(side="right", padx=(8, 0))
        FluentButton(btn_row, "Save", theme=th, aero=self.aero,
                     kind="accent", height=30, command=_save,
                     ).pack(side="right")
        win.grab_set()

    def _update_storage(self):
        if psutil is None:
            return
        try:
            parts = [p for p in psutil.disk_partitions(all=False)
                     if "cdrom" not in p.opts]
        except Exception:
            return
        if getattr(self, "storage_summary", None) is not None:
            self.storage_summary.config(text=f"DRIVES {len(parts)}")
        for part in parts[:4]:
            try:
                usage = psutil.disk_usage(part.mountpoint)
            except Exception:
                continue
            widgets = self.storage_widgets.get(part.device)
            if widgets is None:
                holder = tk.Frame(
                    self.storage_holder, bg=self.storage_holder["bg"],
                    highlightbackground=fl.mix(
                        self.storage_holder["bg"], self.theme["FG"], 0.08),
                    highlightthickness=1, cursor="hand2",
                )
                holder.pack(fill="x", pady=4)
                head = tk.Frame(holder, bg=holder["bg"])
                head.pack(fill="x", padx=6, pady=(4, 0))
                name = tk.Label(head, text=f"  {part.device}", bg=holder["bg"],
                                fg=self.theme["FG"], font=fl.F_SMALL(),
                                image=icon_photo(head, "drive", 16, self.theme["MUTED"]),
                                compound="left")
                name.image = icon_photo(head, "drive", 16, self.theme["MUTED"])
                name.pack(side="left")
                chev = tk.Label(head, text="›", bg=holder["bg"],
                                fg=self.theme["MUTED"], font=fl.F_SMALL())
                chev.pack(side="right")
                info = tk.Label(head, text="", bg=holder["bg"],
                                fg=self.theme["MUTED"], font=fl.F_TINY())
                info.pack(side="right", padx=(0, 6))
                bar = MeterBar(holder, self.theme, aero=self.aero,
                               bg=holder["bg"])
                bar.pack(fill="x", padx=6, pady=(3, 4))
                actions = tk.Frame(holder, bg=holder["bg"])
                actions.pack(fill="x", padx=6, pady=(0, 5))
                health_lbl = tk.Label(
                    actions, text=" Disk Health", bg=holder["bg"],
                    fg=self.theme["ACCENT"], font=fl.F_TINY(), cursor="hand2",
                    image=icon_photo(actions, "heart", 14, self.theme["ACCENT"]),
                    compound="left",
                )
                health_lbl.image = icon_photo(actions, "heart", 14, self.theme["ACCENT"])
                health_lbl.pack(side="left")
                clean_lbl = tk.Label(
                    actions, text=" Disk Cleanup", bg=holder["bg"],
                    fg=self.theme["ACCENT"], font=fl.F_TINY(), cursor="hand2",
                    image=icon_photo(actions, "broom", 14, self.theme["ACCENT"]),
                    compound="left",
                )
                clean_lbl.image = icon_photo(actions, "broom", 14, self.theme["ACCENT"])
                clean_lbl.pack(side="left", padx=(14, 0))

                def _open_health(_e=None, device=part.device):
                    self._open_drive_tool(device, "Disk Health")

                def _open_cleanup(_e=None, device=part.device):
                    self._open_drive_tool(device, "Disk Cleanup")

                health_lbl.bind("<Button-1>", _open_health)
                clean_lbl.bind("<Button-1>", _open_cleanup)
                # Clicking anywhere else on the row goes to Disk Health,
                # the more common "what's wrong with this drive" action.
                for w in (holder, head, name, chev, info, bar):
                    w.bind("<Button-1>", _open_health)
                widgets = (info, bar)
                self.storage_widgets[part.device] = widgets
            info, bar = widgets
            color = (fl.GOOD if usage.percent < 75 else
                     fl.WARN if usage.percent < 90 else fl.BAD)
            info.config(text=f"{usage.percent:.0f}%  ·  "
                             f"{self._fmt_bytes(usage.used)} / "
                             f"{self._fmt_bytes(usage.total)}",
                        fg=color)
            bar.set_value(usage.percent / 100.0, color)
        card = getattr(self, "_storage_card", None)
        if card is not None and len(self.storage_widgets) != getattr(
                self, "_storage_rows_seen", -1):
            self._storage_rows_seen = len(self.storage_widgets)
            card._schedule_autofit()

    # ------------------------------------------------------------------
    def _schedule_rail_fit(self):
        if getattr(self, "_rail_job", None) is None:
            try:
                self._rail_job = self.after_idle(self._fit_side_rail)
            except tk.TclError:
                self._rail_job = None

    def _fit_side_rail(self):
        """Give the right rail the height its cards need, so Quick Actions,
        Health and Storage are never squeezed or cut off by the main column."""
        self._rail_job = None
        side = getattr(self, "_dashboard_side", None)
        if side is None:
            return
        try:
            kids = side.pack_slaves()
            need = (sum(k.winfo_reqheight() for k in kids)
                    + fl.GAP * max(0, len(kids) - 1))
            if need < 50:
                return
            self._rail_need = int(need)
            side.configure(height=self._rail_need)
        except tk.TclError:
            pass

    def _resize_split(self, _event=None):
        """Responsive dashboard split.

        Wide windows use the two-column command-center layout. On compact
        windows the right rail moves below the main workspace instead of
        squeezing the overview/chart into an unreadably narrow column.
        """
        split = getattr(self, "_dashboard_split", None)
        main = getattr(self, "_dashboard_main", None)
        side = getattr(self, "_dashboard_side", None)
        if split is None or side is None or main is None:
            return
        available = split.winfo_width()
        if available <= 1:
            return
        compact = available < 900
        if compact:
            if getattr(self, "_split_compact", False):
                return
            self._split_compact = True
            try:
                main.grid_configure(row=0, column=0, sticky="nsew", padx=0)
                side.grid_forget()
                side.grid_propagate(False)
                side.configure(width=0, height=getattr(self, "_rail_need", 800))
                split.grid_columnconfigure(0, weight=1, minsize=0)
                split.grid_columnconfigure(1, weight=0, minsize=0)
                split.grid_rowconfigure(0, weight=0)
                split.grid_rowconfigure(1, weight=0)
                side.grid(row=1, column=0, sticky="ew", pady=(fl.GAP, 0))
            except tk.TclError:
                return
        else:
            if not getattr(self, "_split_compact", True):
                # Already in wide mode; just refresh its width below.
                pass
            self._split_compact = False
            try:
                side.grid_forget()
                split.grid_rowconfigure(0, weight=1)
                split.grid_rowconfigure(1, weight=0)
                split.grid_columnconfigure(0, weight=1, minsize=0)
                split.grid_columnconfigure(1, weight=0, minsize=0)
                main.grid_configure(row=0, column=0, sticky="nsew", padx=0)
                side.grid(row=0, column=1, sticky="nsew", padx=(fl.GAP, 0))
                side.grid_propagate(False)
                side.configure(width=290, height=getattr(self, "_rail_need", 1))
            except tk.TclError:
                return
            gap = fl.GAP
            min_main, min_side, max_side = 500, 240, 290
            if available < min_main + gap + min_side:
                side_width = max(164, available - gap - min_main)
            else:
                side_width = min(max_side, max(min_side,
                                               available - gap - min_main))
            side.configure(width=int(side_width))

    def _open_enable_disable_tools(self):
        try:
            self.app.open_enable_disable_tools_tab()
        except Exception:
            pass

    # Which detailed monitor tool each metric card drills into. Names match
    # the real catalogue tools (see techdrive_modules) rather than inventing
    # a parallel navigation scheme.
    METRIC_MONITOR_TOOLS = {
        "cpu": "CPU Monitor",
        "ram": "RAM Monitor",
        "gpu": "GPU Monitor",
        "network": "Network Monitor",
        "storage": "Storage Health",
    }

    def _open_metric_monitor(self, key):
        tool = self.METRIC_MONITOR_TOOLS.get(key)
        if tool:
            self._open_named_tool(tool)

    def _open_drive_tool(self, device, tool_label):
        """Per-drive click-through from the Storage card.

        The underlying tools take (frame) only, with no drive parameter,
        so we record which drive the user drilled in from — on
        `self.app.selected_drive` — for the opened tool to read, and make
        it visible in the status bar/toast so the click clearly did
        something drive-specific rather than opening a generic panel.
        """
        self.app.selected_drive = device
        if hasattr(self.app, "show_toast"):
            self.app.show_toast(f"{tool_label}: {device}", kind="info")
        self._open_named_tool(tool_label)

    def _open_named_tool(self, label):
        """Open the real catalogue entry when the friendly action label
        matches one; otherwise fall back to the existing Core Module Manager."""
        needle = label.casefold()
        if needle == "fix my pc":
            self.app.open_fix_my_pc_tab()
            return
        needle = QUICK_ACTION_ALIASES.get(needle, label).casefold()
        for category, _icon, tool in getattr(self.app, "flat_tools", []):
            if needle == tool.casefold() or needle in tool.casefold():
                self.app.open_tool(category, tool)
                return
        self._open_enable_disable_tools()

    def _clear_recent(self):
        try:
            db.clear_recent()
            self.refresh_recent()
            if hasattr(self, "activity_list"):
                self.refresh_activity()
            self.status_text = getattr(self.app, "status_text", None)
            if self.status_text is not None:
                self.status_text.set("Recent tools cleared")
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Recent tools cleared", kind="success")
        except Exception:
            pass

    def _on_destroy(self, event):
        if event.widget is self:
            self._destroyed = True
            overlay = getattr(self, "_mini_overlay", None)
            if overlay is not None:
                try:
                    overlay.destroy()
                except Exception:
                    pass
                self._mini_overlay = None
            if self._job:
                try:
                    self.after_cancel(self._job)
                except Exception:
                    pass
                self._job = None

    def destroy(self):
        # Cancel the live sampler before Tk tears down the widget command.
        self._destroyed = True
        overlay = getattr(self, "_mini_overlay", None)
        if overlay is not None:
            try:
                overlay.destroy()
            except Exception:
                pass
            self._mini_overlay = None
        if getattr(self, "_job", None):
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        super().destroy()
