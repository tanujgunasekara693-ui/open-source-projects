#!/usr/bin/env python3
"""
gui/core_picker.py — TechDrive Core tool picker
================================================

A small, independent, closeable window (its own titlebar + close button,
not a tab) listing the first-party TechDrive Core surfaces so the user can
pick which one to open instead of it opening automatically.

Picking a tool opens it as a normal tab in the main window (same
open_*_tab() methods used by the sidebar) and closes this picker.

Public API:
    show_core_picker(app)
"""

import tkinter as tk

from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton
from gui.scroll_utils import make_scrollable

# (label, icon, description, app-method-name)
_CORE_TOOLS = [
    ("Health Center", "△",
     "Run a full scan and get an overall health score for this PC.",
     "open_health_center_tab"),
    ("Diagnostic Engine", "◉",
     "Describe a symptom and get a guided investigation.",
     "open_diagnostic_engine_tab"),
    ("Diagnostic History", "▥",
     "Browse saved Health Center scans and Diagnostic Engine sessions.",
     "open_diagnostic_history_tab"),
    ("Report Generator", "▤",
     "Build a technician-ready report from the latest diagnostics.",
     "open_report_generator_tab"),
    ("Repair Center", "⚒",
     "Preview, confirm, execute, and verify safe Windows repairs.",
     "open_repair_center_tab"),
    ("Troubleshooting Wizard", "◇",
     "Run real read-only Internet problem checks on Windows.",
     "open_troubleshooting_wizard_tab"),
    ("Performance Lab", "↯",
     "Measure boot, CPU, GPU, RAM, and storage performance on Windows.",
     "open_performance_lab_tab"),
    ("Hardware Inventory", "▣",
     "Collect and export real CPU, GPU, memory, storage, and network data.",
     "open_hardware_inventory_tab"),
    ("Network Lab", "◎",
     "See live connection status, latency, adapters, tests, and saved runs.",
     "open_network_lab_tab"),
    ("Security Center", "◆",
     "Audit Windows protection posture and understand what needs review.",
     "open_security_center_tab"),
    ("Snapshot Manager", "▣",
     "Create, compare, and explicitly restore named machine baselines.",
     "open_snapshot_manager_tab"),
    ("Technician Workspace", "▣",
     "Export privacy-approved local diagnostics for a technician to review.",
     "open_technician_workspace_tab"),
    ("Explain This PC", "✦",
     "Translate live Windows telemetry into a plain-English explanation of this computer.",
     "open_explain_this_pc_tab"),
    ("Event Log Analyzer", "◉",
     "Analyze real Windows System and Application events, find patterns, and inspect the original event details.",
     "open_event_log_analyzer_tab"),
    ("Baseline Monitor", "▥",
     "Capture this PC's normal telemetry and detect meaningful deviations from its own baseline.",
     "open_baseline_monitor_tab"),
    ("TechDrive Vault", "○",
     "Open the harmless TechDrive developer vault and its hidden diagnostics/easter eggs.",
     "open_techdrive_vault_tab"),
    ("TechDrive Terminal", "▣",
     "Run Windows command-line diagnostics from inside TechDrive with captured output.",
     "open_techdrive_terminal_tab"),
    ("FIX MY PC", "↯",
     "Run a guided diagnostic pass and turn the findings into safe next steps.",
     "open_fix_my_pc_tab"),
]


def show_core_picker(app):
    """Open (or refocus) the TechDrive Core tool picker window."""
    existing = getattr(app, "_core_picker_win", None)
    if existing is not None and existing.winfo_exists():
        existing.deiconify()
        existing.lift()
        existing.focus_force()
        return existing

    theme = app.theme
    aero = app.is_aero_enabled()

    win = tk.Toplevel(app)
    app._core_picker_win = win
    win.title("TechDrive Core")
    win.geometry("460x800")
    win.minsize(420, 680)
    win.configure(bg=theme["BG"])
    # A real, independently closeable window: standard titlebar/close
    # button via protocol, plus Escape as a shortcut. Not a modal dialog
    # (no grab_set) so the main window stays usable behind it.
    win.transient(app)

    def _close():
        win.destroy()
        app._core_picker_win = None

    win.protocol("WM_DELETE_WINDOW", _close)
    win.bind("<Escape>", lambda e: _close())

    header = tk.Frame(win, bg=theme["BG"])
    header.pack(fill="x", padx=20, pady=(18, 8))
    tk.Label(header, text="TECHDRIVE CORE", bg=theme["BG"],
             fg=theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(anchor="w")
    tk.Label(header, text="Choose a tool", bg=theme["BG"], fg=theme["FG"],
             font=fl.F_TITLE()).pack(anchor="w", pady=(2, 2))
    tk.Label(header, text="Pick one of the first-party diagnostic tools "
             "below. It opens in its own tab; this window stays open so "
             "you can launch another.",
             bg=theme["BG"], fg=theme["MUTED"], font=fl.F_SMALL(),
             wraplength=410, justify="left").pack(anchor="w")

    body_holder = tk.Frame(win, bg=theme["BG"])
    body_holder.pack(fill="both", expand=True, padx=20, pady=(4, 8))
    _, body = make_scrollable(body_holder, theme["BG"])

    def _pick(method_name):
        action = getattr(app, method_name, None)
        if callable(action):
            action()
        _close()

    for label, icon, desc, method_name in _CORE_TOOLS:
        card = GlassCard(body, theme, aero=aero, accent=theme["ACCENT"])
        card.pack(fill="x", pady=6)
        row = tk.Frame(card.body, bg=card.fill)
        row.pack(fill="x", padx=14, pady=12)
        icon_lbl = tk.Label(row, text=icon, bg=card.fill,
                             fg=theme["ACCENT"], font=fl.F_TITLE())
        icon_lbl.pack(side="left", padx=(0, 12))
        text_col = tk.Frame(row, bg=card.fill)
        text_col.pack(side="left", fill="x", expand=True)
        tk.Label(text_col, text=label, bg=card.fill, fg=theme["FG"],
                 font=fl.F_CARD_TITLE()).pack(anchor="w")
        tk.Label(text_col, text=desc, bg=card.fill, fg=theme["MUTED"],
                 font=fl.F_TINY(), wraplength=260,
                 justify="left").pack(anchor="w", pady=(2, 0))
        FluentButton(row, "OPEN", command=lambda m=method_name: _pick(m),
                     theme=theme, aero=aero, kind="accent",
                     width=84, height=32,
                     backdrop=card.fill).pack(side="right")

    footer = tk.Frame(win, bg=theme["BG"])
    footer.pack(fill="x", padx=20, pady=(0, 16))
    FluentButton(footer, "CLOSE", command=_close, theme=theme, aero=aero,
                 kind="standard", width=100, height=32,
                 backdrop=theme["BG"]).pack(side="right")

    return win
