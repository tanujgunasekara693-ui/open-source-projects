"""Live, file-based scan map shared by TechDrive's disk scanning tools.

The tiles represent files visited during the current scan, not physical disk
sectors or a fragmentation measurement.
"""

import os
import time
import tkinter as tk

from gui import fluent as fl
from gui import ui_dispatch


class DiskBlockMap(tk.Frame):
    """A compact, theme-aware grid that fills as a scan visits files."""

    COLUMNS = 20
    ROWS = 6

    def __init__(self, parent, theme, title="Disk scan map"):
        super().__init__(parent, bg=theme["CARD_BG"], padx=12, pady=10)
        self.theme = theme
        self.title = title
        self._cell_count = self.COLUMNS * self.ROWS
        self._page = 0
        self._last_index = -1
        self._cells = []

        self.pending = fl.mix(theme["CARD_BG"], theme["MUTED"], 0.24)
        self.reading = theme.get("ACCENT_GLOW", "#65c8ff")
        self.checked = fl.GOOD
        self.issue = fl.BAD

        heading = tk.Frame(self, bg=theme["CARD_BG"])
        heading.pack(fill="x")
        self.heading = tk.Label(
            heading, text=title.upper(), bg=theme["CARD_BG"],
            fg=theme["FG"], font=fl.F_SMALL(bold=True),
        )
        self.heading.pack(side="left")
        self.page_label = tk.Label(
            heading, text="PAGE 1", bg=theme["CARD_BG"],
            fg=theme["MUTED"], font=fl.F_TINY(),
        )
        self.page_label.pack(side="right")

        self.canvas = tk.Canvas(
            self, height=82, bg=theme["CARD_BG"],
            highlightthickness=0, bd=0,
        )
        self.canvas.pack(fill="x", pady=(7, 4))
        self._draw_cells()

        self.status = tk.Label(
            self, text="Waiting for a scan", bg=theme["CARD_BG"],
            fg=theme["FG"], font=fl.F_SMALL(), anchor="w",
        )
        self.status.pack(fill="x")
        self.note = tk.Label(
            self,
            text="Tiles show files visited in this session, not physical disk sectors.",
            bg=theme["CARD_BG"], fg=theme["MUTED"], font=fl.F_TINY(),
            anchor="w",
        )
        self.note.pack(fill="x", pady=(2, 0))
        self._draw_legend()

    def _draw_cells(self):
        gap_x, gap_y = 5, 4
        cell_w, cell_h = 20, 9
        for row in range(self.ROWS):
            for col in range(self.COLUMNS):
                x1 = 2 + col * (cell_w + gap_x)
                y1 = 2 + row * (cell_h + gap_y)
                item = self.canvas.create_rectangle(
                    x1, y1, x1 + cell_w, y1 + cell_h,
                    fill=self.pending, outline=self.theme["CARD_BORDER"],
                    width=1,
                )
                self._cells.append(item)

    def _draw_legend(self):
        legend = tk.Frame(self, bg=self.theme["CARD_BG"])
        legend.pack(fill="x", pady=(5, 0))
        for color, label in (
            (self.pending, "Not visited"),
            (self.reading, "In progress"),
            (self.checked, "Checked"),
            (self.issue, "Read issue"),
        ):
            entry = tk.Frame(legend, bg=self.theme["CARD_BG"])
            entry.pack(side="left", padx=(0, 14))
            swatch = tk.Canvas(
                entry, width=10, height=10, bg=self.theme["CARD_BG"],
                highlightthickness=0,
            )
            swatch.pack(side="left", padx=(0, 4))
            swatch.create_rectangle(1, 1, 9, 9, fill=color, outline="")
            tk.Label(
                entry, text=label, bg=self.theme["CARD_BG"],
                fg=self.theme["MUTED"], font=fl.F_TINY(),
            ).pack(side="left")

    def reset(self):
        """Clear the grid before a new scan."""
        self._page = 0
        self._last_index = -1
        self.page_label.config(text="PAGE 1")
        self.heading.config(text=self.title.upper())
        self.status.config(text="Waiting for a scan")
        for cell in self._cells:
            self.canvas.itemconfigure(
                cell, fill=self.pending, outline=self.theme["CARD_BORDER"], width=1,
            )

    def set_running(self, label):
        if not self.winfo_exists():
            return
        self.heading.config(text=(label or self.title).upper())
        self.status.config(text="Scan running · each tile is one visited file")

    def update_scan(self, index, state, files_read, bytes_read, current_path):
        """Apply one progress snapshot on Tk's main thread."""
        if not self.winfo_exists():
            return

        index = max(0, int(index))
        page = index // self._cell_count
        first_index = page * self._cell_count
        if page != self._page:
            self._page = page
            self._last_index = first_index - 1
            self.page_label.config(text=f"PAGE {page + 1}")
            for cell in self._cells:
                self.canvas.itemconfigure(
                    cell, fill=self.pending, outline=self.theme["CARD_BORDER"], width=1,
                )

        last_visible_index = min(index, first_index + self._cell_count - 1)
        for visited in range(max(self._last_index + 1, first_index), last_visible_index):
            self.canvas.itemconfigure(
                self._cells[visited - first_index],
                fill=self.checked, outline=self.checked, width=1,
            )

        cell_index = index - first_index
        is_active = state in ("reading", "scanning")
        color = {
            "reading": self.reading,
            "scanning": self.reading,
            "issue": self.issue,
            "checked": self.checked,
        }.get(state, self.pending)
        if 0 <= cell_index < self._cell_count:
            self.canvas.itemconfigure(
                self._cells[cell_index],
                fill=color, outline=self.theme["FG"] if is_active else color,
                width=2 if is_active else 1,
            )
        self._last_index = max(self._last_index, last_visible_index)

        filename = os.path.basename(current_path) if current_path else ""
        if len(filename) > 42:
            filename = filename[:19] + "…" + filename[-20:]
        state_text = {
            "reading": f"Reading {filename or 'file'}",
            "scanning": f"Scanning {filename or 'file'}",
            "checked": f"Checked {filename or 'file'}",
            "issue": f"Read issue · {filename or 'file'}",
        }.get(state, "Scan running")
        self.status.config(
            text=f"{state_text}   ·   {files_read:,} file(s) checked   ·   "
                 f"{_bytes_fmt(bytes_read)} processed",
        )

    def finish_scan(self):
        if self.winfo_exists():
            current = self.status.cget("text")
            parts = [part.strip() for part in current.split("·")]
            summary = " · ".join(parts[-2:]) if len(parts) >= 3 else "Scan ended"
            self.status.config(text=f"Scan finished   ·   {summary}")


def ensure_disk_map(panel, theme, holder, title):
    """Return a live map, recreating it if the result view cleared the panel."""
    widget = holder.get("widget")
    try:
        if widget is not None and widget.winfo_exists():
            widget.reset()
            return widget
    except Exception:
        pass
    widget = DiskBlockMap(panel.body, theme, title=title)
    widget.pack(fill="x", padx=4, pady=(7, 10))
    holder["widget"] = widget
    return widget


def _queue_scan_activity(app, active):
    """Keep the app's scan counter and top-bar orb updates on the UI thread."""
    def update():
        count = getattr(app, "_active_scan_count", 0)
        count = max(0, count + (1 if active else -1))
        app._active_scan_count = count
        topbar = getattr(app, "topbar", None)
        if topbar is not None:
            try:
                if topbar.winfo_exists():
                    topbar.set_scan_activity(count > 0)
            except Exception:
                pass

    ui_dispatch.post(update)


class DiskScanProgress:
    """Throttle worker progress and safely post compact snapshots to Tk."""

    def __init__(self, app, block_map, label):
        self.app = app
        self.block_map = block_map
        self.label = label
        self.started = False
        self._last_post = 0.0
        self._latest = None

    def start(self):
        if self.started:
            return
        self.started = True
        ui_dispatch.post(lambda: self.block_map.set_running(self.label))
        _queue_scan_activity(self.app, True)

    def update(self, index, state, files_read, bytes_read, current_path):
        if not self.started:
            return
        snapshot = (index, state, files_read, bytes_read, current_path)
        self._latest = snapshot
        now = time.monotonic()
        if state != "issue" and now - self._last_post < 0.09:
            return
        self._last_post = now
        ui_dispatch.post(lambda snapshot=snapshot: self.block_map.update_scan(*snapshot))

    def finish(self):
        if not self.started:
            return
        if self._latest is not None:
            snapshot = self._latest
            ui_dispatch.post(lambda snapshot=snapshot: self.block_map.update_scan(*snapshot))
        ui_dispatch.post(self.block_map.finish_scan)
        _queue_scan_activity(self.app, False)
        self.started = False


def _bytes_fmt(value):
    value = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PB"