#!/usr/bin/env python3
"""gui/fix_my_pc.py — "FIX MY PC" guided triage workflow.

Central, symptom-first entry point: instead of asking the user to know
which diagnostic tool they need, they pick what's wrong ("PC is slow",
"Apps crash", ...) and TechDrive runs a short, read-only diagnostic pass
for that symptom, then recommends the relevant existing tools.

Safety model (unchanged from the original Fix My PC page, and applied
to every symptom branch below): this page only ever *reads* system
state (psutil counters, read-only PowerShell/WMI queries, etc). It
never repairs, deletes, resets, disables, or otherwise changes
anything. Recommended-tool buttons only *navigate* to the relevant
existing tool tab — they do not trigger any action themselves. Any
actual repair happens only inside those tools, under their own
confirmation flows.
"""
import os, platform, subprocess, threading, tkinter as tk
try: import psutil
except Exception: psutil = None
from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton


def _ps(script, timeout=20):
    """Run a small read-only PowerShell snippet, return stdout (or '')."""
    try:
        r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
                            capture_output=True, text=True, errors='replace', timeout=timeout)
        return (r.stdout or '').strip()
    except Exception:
        return ''


def _windows_only():
    return [], ['FIX MY PC diagnostics rely on Windows-native tools (WMI/PowerShell) '
                 'and are unavailable on this OS.']


# ---------------------------------------------------------------------
# Symptom-specific probes. Each returns (findings, details):
#   findings -> list of (title, message) worth flagging
#   details  -> list of raw evidence lines shown in the "Evidence" panel
# Every probe is strictly read-only.
# ---------------------------------------------------------------------

def _probe_general():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    if psutil:
        try:
            ram = psutil.virtual_memory(); cpu = psutil.cpu_percent(interval=.8)
            details += [f'CPU usage: {cpu:.0f}%', f'RAM usage: {ram.percent:.0f}%']
            if ram.percent >= 85:
                findings.append(('High memory pressure', f'RAM usage is {ram.percent:.0f}%. Inspect memory-heavy processes before changing anything.'))
            if cpu >= 90:
                findings.append(('High CPU pressure', f'CPU usage is {cpu:.0f}% during the sample. Inspect running processes before changing anything.'))
        except Exception: pass
        try:
            for p in psutil.disk_partitions(all=False):
                if os.path.exists(p.mountpoint):
                    u = psutil.disk_usage(p.mountpoint); details.append(f'{p.mountpoint}: {u.percent:.0f}% used')
                    if u.percent >= 90:
                        findings.append(('Low free disk space', f'{p.mountpoint} is {u.percent:.0f}% full. Free space before large updates or repairs.'))
        except Exception: pass
    try:
        ps = r'''$e=Get-WinEvent -FilterHashtable @{LogName='System';StartTime=(Get-Date).AddDays(-1)} -MaxEvents 500 -ErrorAction SilentlyContinue; ($e | Where-Object {$_.LevelDisplayName -in @('Error','Critical')}).Count'''
        n = int((_ps(ps, 30) or '0') or 0); details.append(f'System errors/critical events in last 24h: {n}')
        if n >= 10:
            findings.append(('Recent System errors', f'Windows recorded {n} Error/Critical System events in the last 24 hours. Event Log Analyzer can show the actual evidence.'))
    except Exception: pass
    if not findings:
        findings.append(('No immediate red flags', 'The first-pass checks did not find a clear problem. That does not prove every subsystem is healthy; use the Core diagnostics for deeper inspection.'))
    return findings[:6], details


def _probe_slow():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    if psutil:
        try:
            cpu = psutil.cpu_percent(interval=.8); ram = psutil.virtual_memory()
            details += [f'CPU usage: {cpu:.0f}%', f'RAM usage: {ram.percent:.0f}% of {ram.total/1e9:.1f} GB']
            if cpu >= 80: findings.append(('High CPU usage', f'CPU is at {cpu:.0f}% right now. A runaway or heavy process may be slowing everything down.'))
            if ram.percent >= 85: findings.append(('High memory usage', f'RAM usage is {ram.percent:.0f}%. Low free memory causes paging and general sluggishness.'))
        except Exception: pass
        try:
            procs = []
            for p in psutil.process_iter(['name', 'cpu_percent', 'memory_percent']):
                try: procs.append(p.info)
                except Exception: pass
            top_cpu = sorted(procs, key=lambda d: d.get('cpu_percent') or 0, reverse=True)[:5]
            details.append('Top CPU processes (sample): ' + ', '.join(f"{d.get('name')} ({d.get('cpu_percent') or 0:.0f}%)" for d in top_cpu if d.get('name')))
            top_mem = sorted(procs, key=lambda d: d.get('memory_percent') or 0, reverse=True)[:5]
            details.append('Top memory processes (sample): ' + ', '.join(f"{d.get('name')} ({d.get('memory_percent') or 0:.0f}%)" for d in top_mem if d.get('name')))
        except Exception: pass
        try:
            for p in psutil.disk_partitions(all=False):
                if os.path.exists(p.mountpoint):
                    u = psutil.disk_usage(p.mountpoint)
                    if u.percent >= 90: findings.append(('Low free disk space', f'{p.mountpoint} is {u.percent:.0f}% full. A nearly-full system drive slows Windows down.'))
        except Exception: pass
    try:
        n = _ps("(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Measure-Object).Count", 20)
        if n: details.append(f'Startup programs registered: {n}')
        if n and n.isdigit() and int(n) >= 15:
            findings.append(('Many startup programs', f'{n} programs are set to launch at sign-in. A heavy startup list slows boot and early responsiveness.'))
    except Exception: pass
    if not findings:
        findings.append(('No obvious cause found', 'CPU, memory, disk space, and startup load all look reasonable in this quick sample. Performance Lab can watch these over time to catch an intermittent slowdown.'))
    return findings[:6], details


def _probe_crashes():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    try:
        ps = r'''$e=Get-WinEvent -FilterHashtable @{LogName='Application';StartTime=(Get-Date).AddDays(-3)} -MaxEvents 1000 -ErrorAction SilentlyContinue; $err=$e | Where-Object {$_.LevelDisplayName -in @('Error','Critical')}; "$($err.Count)|" + (($err | Group-Object ProviderName | Sort-Object Count -Descending | Select-Object -First 5 | ForEach-Object {"$($_.Name):$($_.Count)"}) -join ',')'''
        out = _ps(ps, 30)
        if out:
            count_part, _, sources_part = out.partition('|')
            count = int(count_part) if count_part.strip().isdigit() else 0
            details.append(f'Application errors/critical events in last 3 days: {count}')
            if sources_part: details.append('Top sources: ' + sources_part)
            if count >= 15:
                findings.append(('Frequent application errors', f'Windows logged {count} Application Error/Critical events in the last 3 days. Event Log Analyzer can show exactly which app and when.'))
            if sources_part and any(':' in s for s in sources_part.split(',')):
                top = sources_part.split(',')[0].split(':')[0]
                if top: findings.append(('Recurring source', f'"{top}" appears most often in the recent error events — a good place to start looking.'))
    except Exception: pass
    try:
        wer = _ps("(Get-ChildItem 'C:\\ProgramData\\Microsoft\\Windows\\WER\\ReportQueue' -ErrorAction SilentlyContinue | Measure-Object).Count", 15)
        if wer and wer.isdigit():
            details.append(f'Pending Windows Error Reporting reports: {wer}')
            if int(wer) >= 5: findings.append(('Unsent crash reports queued', f'{wer} crash reports are queued locally, consistent with recent app crashes.'))
    except Exception: pass
    if not findings:
        findings.append(('No clear crash pattern found', 'No unusually high rate of Application errors turned up in this quick sample. If crashes are recent or rare, Event Log Analyzer can search a wider window.'))
    return findings[:6], details


def _probe_internet():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    try:
        gw = _ps("(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty NextHop)", 15)
        if gw: details.append(f'Default gateway: {gw}')
        else: findings.append(('No default gateway found', 'Windows has no default route configured, which would block all internet access.'))
    except Exception: pass
    try:
        r = subprocess.run(['ping', '-n', '2', '1.1.1.1'], capture_output=True, text=True, timeout=15)
        ok = r.returncode == 0
        details.append('Ping 1.1.1.1 (by IP): ' + ('reachable' if ok else 'unreachable'))
        if not ok: findings.append(('No general internet reachability', 'A ping to a public IP failed. This points to a connectivity or routing problem rather than DNS.'))
    except Exception: pass
    try:
        r = subprocess.run(['ping', '-n', '2', 'www.microsoft.com'], capture_output=True, text=True, timeout=15)
        ok = r.returncode == 0
        details.append('Ping www.microsoft.com (by name): ' + ('reachable' if ok else 'unreachable'))
        if not ok and 'No general internet reachability' not in [f[0] for f in findings]:
            findings.append(('DNS name resolution may be failing', 'The IP ping worked but the name-based ping did not (or both failed) — DNS is a likely culprit.'))
    except Exception: pass
    try:
        n = _ps("(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Up'} | Measure-Object).Count", 15)
        if n: details.append(f'Network adapters currently up: {n}')
        if n == '0': findings.append(('No active network adapter', 'No network adapter is currently reporting an "Up" status.'))
    except Exception: pass
    if not findings:
        findings.append(('Basic connectivity looks fine', 'Gateway, IP reachability, and name resolution all checked out. If a specific site or app is affected, Network Lab has deeper tracing tools.'))
    return findings[:6], details


def _probe_storage():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    if psutil:
        try:
            for p in psutil.disk_partitions(all=False):
                if os.path.exists(p.mountpoint):
                    u = psutil.disk_usage(p.mountpoint)
                    details.append(f'{p.mountpoint} ({p.fstype}): {u.percent:.0f}% used, {u.free/1e9:.1f} GB free')
                    if u.percent >= 95: findings.append(('Drive almost full', f'{p.mountpoint} is {u.percent:.0f}% full with only {u.free/1e9:.1f} GB free. This can cause update failures and slowdowns.'))
                    elif u.percent >= 90: findings.append(('Low free space', f'{p.mountpoint} is {u.percent:.0f}% full ({u.free/1e9:.1f} GB free).'))
        except Exception: pass
    try:
        out = _ps("Get-PhysicalDisk -ErrorAction SilentlyContinue | Select-Object FriendlyName,HealthStatus,OperationalStatus | ForEach-Object {\"$($_.FriendlyName)|$($_.HealthStatus)|$($_.OperationalStatus)\"}", 20)
        if out:
            for line in out.splitlines():
                parts = line.split('|')
                if len(parts) == 3:
                    name, health, op = parts
                    details.append(f'Disk "{name}": health={health}, status={op}')
                    if health and health.strip().lower() not in ('healthy', ''):
                        findings.append(('Disk health warning', f'"{name}" reports health status "{health.strip()}" — back up important data and check Repair Center / Hardware Inventory.'))
    except Exception: pass
    if not findings:
        findings.append(('No storage problems found', 'Free space and reported disk health look fine in this quick pass. For SMART detail or cloning/imaging, use Repair Center and Hardware Inventory.'))
    return findings[:6], details


def _probe_display():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    try:
        out = _ps("Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Select-Object Name,Status,DriverVersion,CurrentHorizontalResolution,CurrentVerticalResolution | ForEach-Object {\"$($_.Name)|$($_.Status)|$($_.DriverVersion)|$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)\"}", 20)
        if out:
            for line in out.splitlines():
                parts = line.split('|')
                if len(parts) == 4:
                    name, status, driver, res = parts
                    details.append(f'GPU "{name}": status={status}, driver={driver}, resolution={res}')
                    if status and status.strip().lower() != 'ok':
                        findings.append(('Display adapter reporting a problem', f'"{name}" reports status "{status.strip()}" instead of OK.'))
                    if res.strip() in ('0x0', 'x'):
                        findings.append(('No active resolution reported', f'"{name}" is not reporting an active resolution, which can mean it is disabled or disconnected.'))
        else:
            findings.append(('Could not query display adapters', 'WMI did not return video controller info in this pass.'))
    except Exception: pass
    if not findings:
        findings.append(('Display adapter looks normal', 'The graphics adapter is reporting OK status with an active resolution. Hardware Inventory has full driver and monitor detail.'))
    return findings[:6], details


def _probe_audio():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    try:
        out = _ps("Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue | Select-Object Name,Status | ForEach-Object {\"$($_.Name)|$($_.Status)\"}", 20)
        if out:
            any_ok = False
            for line in out.splitlines():
                parts = line.split('|')
                if len(parts) == 2:
                    name, status = parts
                    details.append(f'Audio device "{name}": status={status}')
                    if status and status.strip().lower() == 'ok': any_ok = True
                    else: findings.append(('Audio device reporting a problem', f'"{name}" reports status "{status.strip()}" instead of OK.'))
            if not any_ok and not findings:
                findings.append(('No audio device reporting OK', 'None of the detected audio devices report a healthy status.'))
        else:
            findings.append(('No audio devices detected', 'Windows did not report any sound devices in this pass — a driver or hardware issue is likely.'))
    except Exception: pass
    if not findings:
        findings.append(('Audio devices look normal', 'At least one sound device reports OK status. If a specific app has no sound, check its own output-device setting first.'))
    return findings[:6], details


def _probe_security():
    findings, details = [], []
    if platform.system() != 'Windows':
        return _windows_only()
    try:
        out = _ps("Get-MpComputerStatus -ErrorAction SilentlyContinue | Select-Object AMServiceEnabled,AntispywareEnabled,RealTimeProtectionEnabled,AntivirusSignatureAge,FirewallEnabled | ForEach-Object {\"$($_.AMServiceEnabled)|$($_.AntispywareEnabled)|$($_.RealTimeProtectionEnabled)|$($_.AntivirusSignatureAge)\"}", 20)
        if out:
            parts = out.splitlines()[0].split('|')
            if len(parts) == 4:
                am, spy, rtp, age = parts
                details.append(f'Antimalware service: {am}, real-time protection: {rtp}, signature age: {age} day(s)')
                if rtp.strip().lower() != 'true':
                    findings.append(('Real-time protection is off', 'Windows real-time malware protection is not currently enabled.'))
                if age.strip().isdigit() and int(age.strip()) >= 7:
                    findings.append(('Antivirus signatures are outdated', f'Signatures are {age.strip()} day(s) old. Update them before relying on real-time scanning.'))
    except Exception: pass
    try:
        fw = _ps("(Get-NetFirewallProfile -ErrorAction SilentlyContinue | Where-Object {$_.Enabled -eq $false} | Select-Object -ExpandProperty Name) -join ','", 15)
        if fw: details.append(f'Firewall profiles disabled: {fw}'); findings.append(('Firewall profile disabled', f'The following firewall profile(s) are off: {fw}.'))
        else: details.append('All firewall profiles reporting enabled.')
    except Exception: pass
    if not findings:
        findings.append(('No obvious security gaps found', 'Real-time protection, signature age, and firewall profiles all look fine in this pass. Security Center has the full picture.'))
    return findings[:6], details


# ---------------------------------------------------------------------
# Category registry: id -> (icon, label, probe fn, recommended tools)
# Each recommended tool is (button label, app-method-name) — the method
# only navigates to an existing tool tab, it never performs an action.
# ---------------------------------------------------------------------
CATEGORIES = [
    ('slow', '◌', 'PC IS SLOW', _probe_slow,
     [('Performance Lab', 'open_performance_lab_tab'),
      ('Diagnostic Engine', 'open_diagnostic_engine_tab')]),
    ('crashes', '✦', 'APPS CRASH', _probe_crashes,
     [('Event Log Analyzer', 'open_event_log_analyzer_tab'),
      ('Diagnostic Engine', 'open_diagnostic_engine_tab'),
      ('Repair Center', 'open_repair_center_tab')]),
    ('internet', '◎', 'INTERNET', _probe_internet,
     [('Network Lab', 'open_network_lab_tab')]),
    ('storage', '▣', 'STORAGE', _probe_storage,
     [('Repair Center', 'open_repair_center_tab'),
      ('Hardware Inventory', 'open_hardware_inventory_tab')]),
    ('display', '▣', 'DISPLAY', _probe_display,
     [('Hardware Inventory', 'open_hardware_inventory_tab'),
      ('Troubleshooting Wizard', 'open_troubleshooting_wizard_tab')]),
    ('audio', '◖', 'AUDIO', _probe_audio,
     [('Hardware Inventory', 'open_hardware_inventory_tab'),
      ('Troubleshooting Wizard', 'open_troubleshooting_wizard_tab')]),
    ('security', '◆', 'SECURITY', _probe_security,
     [('Security Center', 'open_security_center_tab')]),
    ('unsure', '?', "I'M NOT SURE", _probe_general,
     [('Troubleshooting Wizard', 'open_troubleshooting_wizard_tab'),
      ('Diagnostic Engine', 'open_diagnostic_engine_tab')]),
]
_CATEGORY_BY_ID = {c[0]: c for c in CATEGORIES}


class FixMyPCPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme['BG'])
        self.app = app; self.theme = app.theme; self.aero = app.is_aero_enabled()
        self._active = None  # currently selected category id, or None for the picker
        self._build_shell()
        self._show_picker()

    # -- shell -----------------------------------------------------
    def _build_shell(self):
        th = self.theme
        h = tk.Frame(self, bg=th['BG']); h.pack(fill='x', padx=24, pady=(22, 8))
        tk.Label(h, text='TECHDRIVE / GUIDED REPAIR', bg=th['BG'], fg=th['ACCENT_GLOW'], font=fl.F_TINY()).pack(anchor='w')
        tk.Label(h, text='FIX MY PC', bg=th['BG'], fg=th['FG'], font=fl.F_TITLE()).pack(anchor='w')
        tk.Label(h, text="Don't worry — TechDrive diagnoses first. Nothing is repaired, deleted, reset, or disabled automatically.",
                 bg=th['BG'], fg=th['MUTED'], font=fl.F_SMALL()).pack(anchor='w')
        self.body = tk.Frame(self, bg=th['BG']); self.body.pack(fill='both', expand=True, padx=24, pady=8)

    def _clear_body(self):
        for w in self.body.winfo_children(): w.destroy()

    # -- picker screen -----------------------------------------------------
    def _show_picker(self):
        self._active = None
        self._clear_body()
        th = self.theme
        card = GlassCard(self.body, th, aero=self.aero, accent=th['ACCENT']); card.pack(fill='x', pady=(0, 12))
        tk.Label(card.body, text="What's wrong?", bg=card.fill, fg=th['FG'], font=fl.F_CARD_TITLE()).pack(anchor='w', padx=16, pady=(14, 4))
        tk.Label(card.body, text='Pick the closest match. TechDrive will collect read-only diagnostics and point you at the right tools.',
                 bg=card.fill, fg=th['MUTED'], font=fl.F_SMALL(), wraplength=850, justify='left').pack(anchor='w', padx=16, pady=(0, 14))

        grid = tk.Frame(self.body, bg=th['BG']); grid.pack(fill='x')
        cols = 4
        for i in range(cols): grid.grid_columnconfigure(i, weight=1, uniform='fixmypc')
        for idx, (cid, icon, label, _probe, _tools) in enumerate(CATEGORIES):
            r, c = divmod(idx, cols)
            btn = FluentButton(grid, label, icon=icon, theme=th, aero=self.aero,
                                kind='standard', width=190, height=64,
                                command=(lambda cid=cid: self._select_category(cid)),
                                backdrop=th['BG'])
            btn.grid(row=r, column=c, padx=6, pady=6, sticky='ew')

    # -- result screen -----------------------------------------------------
    def _select_category(self, cid):
        self._active = cid
        _cid, icon, label, probe, tools = _CATEGORY_BY_ID[cid]
        self._clear_body()
        th = self.theme
        bar = tk.Frame(self.body, bg=th['BG']); bar.pack(fill='x', pady=(0, 8))
        back = FluentButton(bar, '← WHAT\'S WRONG?', theme=th, aero=self.aero, kind='subtle',
                             width=170, height=30, command=self._show_picker, backdrop=th['BG'])
        back.pack(side='left')
        tk.Label(bar, text=f'{icon}  {label}', bg=th['BG'], fg=th['FG'], font=fl.F_SUBTITLE()).pack(side='left', padx=14)
        self.status = tk.Label(bar, text='Collecting live diagnostics…', bg=th['BG'], fg=th['MUTED'], font=fl.F_SMALL())
        self.status.pack(side='left', padx=10)

        self.result_area = tk.Frame(self.body, bg=th['BG']); self.result_area.pack(fill='both', expand=True)
        self._render_results([], [], tools, loading=True)

        def worker():
            f, d = probe()
            self.app._post_ui(lambda f=f, d=d: self._done(cid, f, d, tools))
        threading.Thread(target=worker, daemon=True).start()

    def _done(self, cid, findings, details, tools):
        if self._active != cid: return  # user navigated away mid-scan
        self.status.config(text='Diagnostic pass complete.')
        self._render_results(findings, details, tools, loading=False)

    def _render_results(self, findings, details, tools, loading):
        for w in self.result_area.winfo_children(): w.destroy()
        th = self.theme
        clean = bool(findings) and findings[0][0].startswith(('No ', 'Basic', 'Audio devices look', 'Display adapter looks'))
        accent = th['ACCENT'] if (loading or clean) else fl.WARN
        c = GlassCard(self.result_area, th, aero=self.aero, accent=accent); c.pack(fill='x', pady=6)
        headline = 'Collecting evidence…' if loading else f"I found {len(findings)} thing{'s' if len(findings) != 1 else ''} worth investigating."
        tk.Label(c.body, text=headline, bg=c.fill, fg=th['FG'], font=fl.F_CARD_TITLE()).pack(anchor='w', padx=16, pady=(14, 6))
        for title, msg in findings:
            tk.Label(c.body, text='• ' + title, bg=c.fill, fg=th['FG'], font=fl.F_BODY()).pack(anchor='w', padx=20, pady=(4, 0))
            tk.Label(c.body, text=msg, bg=c.fill, fg=th['MUTED'], font=fl.F_SMALL(), wraplength=850, justify='left').pack(anchor='w', padx=36, pady=(0, 4))

        if tools and not loading:
            rec = GlassCard(self.result_area, th, aero=self.aero, accent=th['ACCENT'], gradient=False); rec.pack(fill='x', pady=6)
            tk.Label(rec.body, text='RECOMMENDED TOOLS', bg=rec.fill, fg=th['ACCENT_GLOW'], font=fl.F_TINY()).pack(anchor='w', padx=16, pady=(14, 4))
            tk.Label(rec.body, text='These open the matching tool for a closer look. Nothing runs automatically — you stay in control of any actual repair.',
                     bg=rec.fill, fg=th['MUTED'], font=fl.F_SMALL(), wraplength=850, justify='left').pack(anchor='w', padx=16, pady=(0, 8))
            row = tk.Frame(rec.body, bg=rec.fill); row.pack(anchor='w', padx=16, pady=(0, 14))
            for tool_label, method_name in tools:
                method = getattr(self.app, method_name, None)
                btn = FluentButton(row, tool_label, theme=th, aero=self.aero, kind='accent',
                                    width=190, height=34, backdrop=rec.fill,
                                    command=(method if method else (lambda: None)))
                btn.pack(side='left', padx=(0, 8))

        d = GlassCard(self.result_area, th, aero=self.aero, accent=th['ACCENT'], gradient=False); d.pack(fill='both', expand=True, pady=6)
        tk.Label(d.body, text='EVIDENCE COLLECTED', bg=d.fill, fg=th['ACCENT_GLOW'], font=fl.F_TINY()).pack(anchor='w', padx=16, pady=(14, 4))
        out = tk.Text(d.body, bg=d.fill, fg=th['MUTED'], font=fl.font(9, mono=True), height=8, wrap='word', borderwidth=0)
        out.pack(fill='both', expand=True, padx=16, pady=(0, 14))
        out.insert('end', '\n'.join(details) if details else ('Working…' if loading else 'No additional evidence collected.'))
        out.config(state='disabled')
