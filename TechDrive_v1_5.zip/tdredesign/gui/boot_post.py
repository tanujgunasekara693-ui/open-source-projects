"""Optional, non-blocking BIOS-style startup information window."""

import threading
import tkinter as tk

from gui import ui_dispatch
from gui.boot_post_data import collect_post_info, format_bytes


class BootPostWindow(tk.Toplevel):
    """Show a short, skippable hardware inventory report at startup."""

    BACKGROUND = "#07120d"
    PANEL = "#0b1b13"
    GREEN = "#8effa4"
    MUTED = "#8aa895"
    CYAN = "#75e6db"

    def __init__(self, app, on_close=None, cpu_name_provider=None):
        super().__init__(app)
        self.app = app
        self._on_close = on_close
        self._cpu_name_provider = cpu_name_provider
        self._closed = False
        self.title("TechDrive Startup POST")
        self.configure(bg=self.BACKGROUND)
        self.resizable(False, False)
        self.transient(app)
        self.attributes("-topmost", True)
        self.protocol("WM_DELETE_WINDOW", self.close)

        width, height = 690, 470
        x = max(0, (self.winfo_screenwidth() - width) // 2)
        y = max(0, (self.winfo_screenheight() - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

        self._build()
        self.after(80, self._start_collection)
        self.after(12000, self.close)

    def _build(self):
        outer = tk.Frame(
            self, bg=self.BACKGROUND, highlightthickness=1,
            highlightbackground="#23523a", padx=22, pady=18,
        )
        outer.pack(fill="both", expand=True, padx=8, pady=8)

        tk.Label(
            outer, text="TECHDRIVE  /  POWER-ON SELF TEST",
            bg=self.BACKGROUND, fg=self.GREEN,
            font=("Consolas", 17, "bold"),
        ).pack(anchor="w")
        tk.Label(
            outer,
            text="Live startup inventory  •  informational only  •  no firmware settings changed",
            bg=self.BACKGROUND, fg=self.MUTED, font=("Consolas", 9),
        ).pack(anchor="w", pady=(3, 15))

        self._log = tk.Text(
            outer, height=13, bg=self.PANEL, fg=self.GREEN,
            insertbackground=self.GREEN, relief="flat", borderwidth=0,
            padx=13, pady=10, font=("Consolas", 10), wrap="word",
            state="disabled",
        )
        self._log.pack(fill="both", expand=True)
        self._append("TECHDRIVE POST 1.0")
        self._append("Initializing local hardware report...")

        footer = tk.Frame(outer, bg=self.BACKGROUND)
        footer.pack(fill="x", pady=(12, 0))
        self._progress = tk.Canvas(
            footer, height=12, bg="#102319", highlightthickness=0,
            borderwidth=0,
        )
        self._progress.pack(side="left", fill="x", expand=True, padx=(0, 14))
        self._progress.bind("<Configure>", self._draw_progress)
        self._progress_value = 8
        self._draw_progress()

        self._status = tk.StringVar(value="Collecting current system information...")
        tk.Label(
            outer, textvariable=self._status,
            bg=self.BACKGROUND, fg=self.CYAN, font=("Consolas", 9),
        ).pack(anchor="w", pady=(9, 0))
        tk.Button(
            footer, text="Skip", command=self.close,
            bg="#163322", activebackground="#21482f", fg=self.GREEN,
            activeforeground="#ffffff", relief="flat", bd=0,
            padx=15, pady=5, cursor="hand2", font=("Consolas", 9, "bold"),
        ).pack(side="right")

    def _append(self, message):
        if self._closed or not self.winfo_exists():
            return
        self._log.configure(state="normal")
        self._log.insert("end", f"> {message}\n")
        self._log.see("end")
        self._log.configure(state="disabled")

    def _draw_progress(self, _event=None):
        if not self.winfo_exists():
            return
        self._progress.delete("all")
        width = max(1, self._progress.winfo_width())
        filled = int(width * max(0, min(100, self._progress_value)) / 100)
        self._progress.create_rectangle(
            0, 0, filled, 12, fill=self.GREEN, outline="",
        )

    def _set_phase(self, message):
        if self._closed or not self.winfo_exists():
            return
        self._status.set(message)
        self._progress_value = min(82, self._progress_value + 22)
        self._draw_progress()
        self._append(message)

    def _start_collection(self):
        if self._closed:
            return

        def phase(message):
            ui_dispatch.post(lambda value=message: self._set_phase(value))

        def collect():
            try:
                report = collect_post_info(
                    cpu_name_provider=self._cpu_name_provider,
                    on_phase=phase,
                )
                ui_dispatch.post(lambda result=report: self._finish_report(result))
            except Exception as exc:
                ui_dispatch.post(lambda error=str(exc): self._finish_error(error))

        threading.Thread(target=collect, name="techdrive-post-report", daemon=True).start()

    def _finish_report(self, report):
        if self._closed or not self.winfo_exists():
            return
        self._append(f"CPU: {report['cpu_name']}")
        self._append(f"Logical processors: {report['logical_cpus'] or 'Unavailable'}")
        self._append(
            "Memory: "
            f"{format_bytes(report['memory_total'])} installed; "
            f"{format_bytes(report['memory_available'])} available"
        )
        if report["drives"]:
            for drive in report["drives"]:
                self._append(
                    f"Storage {drive['label']}: {format_bytes(drive['free'])} free / "
                    f"{format_bytes(drive['total'])} total"
                )
        else:
            self._append("Storage: no mounted drives could be measured.")
        self._append(f"Platform: {report['platform']}")
        self._status.set("POST complete — TechDrive is ready.")
        self._progress_value = 100
        self._draw_progress()
        self.after(2600, self.close)

    def _finish_error(self, message):
        if self._closed or not self.winfo_exists():
            return
        self._append(f"Hardware report unavailable: {message}")
        self._status.set("Startup report finished with unavailable readings.")
        self._progress_value = 100
        self._draw_progress()
        self.after(2600, self.close)

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            self.destroy()
        except tk.TclError:
            pass
        if self._on_close:
            self._on_close()