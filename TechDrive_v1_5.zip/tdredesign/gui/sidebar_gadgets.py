#!/usr/bin/env python3
r"""
gui/sidebar_gadgets.py - Sidebar Gadgets (entirely original)
================================================================
A slim panel docked to the edge of the screen holding a few small,
always-on-top live widgets - the general idea of a docked gadget strip,
built from scratch with TechDrive's own original artwork (Canvas-drawn
gauges, a hand-drawn clock face, a calendar grid, and a small vector
glyph set - no emoji, no third-party icon packs). No Microsoft gadget
icons, layouts, names, or assets are used anywhere here - every widget
is original to this app, drawn with the same rounded-card + soft-shadow
language as the rest of the Fluent shell (see gui/widgets.py:paint_panel).

Off by default, toggled from Settings. A separate Toplevel window
(borderless, always-on-top) - doesn't touch or depend on the main
window at all, so it can't destabilize it.

Public API:
    is_open()      -> bool
    show(app)       -> opens the sidebar (no-op if already open)
    hide()          -> closes it
"""

import calendar
import datetime
import math
import random
import tkinter as tk

from techdrive_modules import hw_sensors as hw
from gui import fluent as fl
from gui.widgets import round_rect, paint_panel

_WIDTH = 200
_BG = fl.DARK["BG"]
_CARD_BG = fl.DARK["LAYER_1"]
_CARD_BORDER = fl.DARK["STROKE"]
_FG = fl.DARK["FG"]
_MUTED = fl.DARK["MUTED"]
_ACCENT = fl.DARK["ACCENT_GLOW"]
_ACCENT2 = fl.DARK["ACCENT2"]
_TRACK = fl.DARK["LAYER_3"]
_SHADOW = fl.DARK["SHADOW"]
_ON_ACCENT = fl.DARK["ON_ACCENT"]
_RADIUS = 14

_F_TITLE = ("Segoe UI Semibold", 10)
_F_HEAD = ("Segoe UI Semibold", 10)
_F_DIGITAL = ("Segoe UI", 12, "bold")
_F_SMALL_BOLD = ("Segoe UI Semibold", 8)
_F_SMALL = ("Segoe UI", 8)
_F_TIP = ("Segoe UI", 8)

_TIPS = [
    "Ctrl+Shift+Esc opens Task Manager instantly.",
    "Windows+V opens clipboard history.",
    "Windows+. opens the emoji picker anywhere.",
    "Windows+Shift+S snips part of the screen.",
    "A dying HDD often clicks before it fails - back up early.",
    "SSDs don't need defragmenting - TRIM does the equivalent job.",
    "Ctrl+Z works in File Explorer too, not just editors.",
    "Windows+Tab shows every open window, grouped by desktop.",
    "Shift+Delete skips the Recycle Bin - use it carefully.",
    "A cheap $10 UPS can save you from a lot of corrupted files.",
]

_state = {"win": None}


def is_open():
    try:
        return _state["win"] is not None and _state["win"].winfo_exists()
    except tk.TclError:
        return False


def hide():
    if is_open():
        _state["win"].destroy()
    _state["win"] = None


def show(app):
    if is_open():
        _state["win"].lift()
        return
    _apply_palette(getattr(app, "theme", fl.DARK))
    win = tk.Toplevel(app)
    win.overrideredirect(True)
    win.attributes("-topmost", True)
    win.configure(bg=_BG)

    screen_w = app.winfo_screenwidth()
    screen_h = app.winfo_screenheight()
    win.geometry(f"{_WIDTH}x{screen_h}+{screen_w - _WIDTH}+0")

    header = tk.Frame(win, bg=_BG)
    header.pack(fill="x", pady=(14, 8))
    icon = tk.Canvas(header, width=18, height=18, bg=_BG, highlightthickness=0)
    icon.pack(side="left", padx=(14, 6))
    _draw_grid_glyph(icon)
    tk.Label(header, text="TechDrive Gadgets", bg=_BG, fg=_FG,
             font=_F_TITLE).pack(side="left")
    close_btn = tk.Label(header, text="\u2715", bg=_BG, fg=_MUTED,
                         font=("Segoe UI", 10), cursor="hand2")
    close_btn.pack(side="right", padx=14)
    close_btn.bind("<Enter>", lambda _e: close_btn.config(fg=_FG))
    close_btn.bind("<Leave>", lambda _e: close_btn.config(fg=_MUTED))
    close_btn.bind("<Button-1>", lambda _e: hide())

    _divider(win)
    _clock_gadget(win)
    _calendar_gadget(win)
    _gauge_row(win, [
        ("CPU", lambda: hw.cpu_sample().get("usage", 0)),
        ("RAM", lambda: hw.ram_sample().get("percent", 0)),
    ])
    _tip_gadget(win)

    _state["win"] = win


def refresh(app):
    """Reopen the docked gadgets with the app's current theme colors."""
    hide()
    show(app)


def _apply_palette(theme):
    global _BG, _CARD_BG, _CARD_BORDER, _FG, _MUTED, _ACCENT, _ACCENT2
    global _TRACK, _SHADOW, _ON_ACCENT
    _BG = theme.get("BG", fl.DARK["BG"])
    _CARD_BG = theme.get("CARD_BG", fl.DARK["CARD_BG"])
    _CARD_BORDER = theme.get("CARD_BORDER", fl.DARK["CARD_BORDER"])
    _FG = theme.get("FG", fl.DARK["FG"])
    _MUTED = theme.get("MUTED", fl.DARK["MUTED"])
    _ACCENT = theme.get("ACCENT_GLOW", theme.get("ACCENT", fl.DARK["ACCENT_GLOW"]))
    _ACCENT2 = theme.get("ACCENT2", fl.DARK["ACCENT2"])
    _TRACK = theme.get("LAYER_3", fl.DARK["LAYER_3"])
    _SHADOW = theme.get("SHADOW", fl.DARK["SHADOW"])
    _ON_ACCENT = theme.get("ON_ACCENT", fl.DARK["ON_ACCENT"])


def _divider(parent):
    line = tk.Frame(parent, bg=_CARD_BORDER, height=1)
    line.pack(fill="x", padx=14, pady=(0, 4))


# ---------------------------------------------------------------------------
# Small vector glyphs (Canvas-drawn, no emoji / no icon-font dependency)
# ---------------------------------------------------------------------------

def _draw_grid_glyph(canvas):
    """A small four-point sparkle/glimmer mark - reads as "extras /
    gadgets" without echoing any OS or third-party logo shape."""
    canvas.delete("all")
    cx, cy, length = 9, 9, 8

    # Two kite-shaped spikes (vertical + horizontal) overlapped = a
    # four-pointed sparkle, drawn as solid polygons.
    w = length * 0.22
    vertical = [cx, cy - length, cx + w, cy, cx, cy + length, cx - w, cy]
    horizontal = [cx - length, cy, cx, cy - w, cx + length, cy, cx, cy + w]
    canvas.create_polygon(*vertical, fill=_ACCENT, outline="")
    canvas.create_polygon(*horizontal, fill=_ACCENT, outline="")

    # A tiny second sparkle offset to the upper-right, in the muted tone,
    # for a bit of depth/sparkle-cluster feel.
    sx, sy, sl = 14, 4, 3
    sw = sl * 0.3
    canvas.create_polygon(sx, sy - sl, sx + sw, sy, sx, sy + sl, sx - sw, sy,
                          fill=_MUTED, outline="")


def _draw_bulb_glyph(canvas, w, h):
    """A minimal lightbulb glyph for the tip-of-the-day card."""
    canvas.delete("all")
    cx, cy = w / 2, h * 0.42
    r = min(w, h) * 0.30
    canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=_ACCENT, width=2)
    canvas.create_line(cx - r * 0.35, cy + r * 0.9, cx + r * 0.35, cy + r * 0.9,
                       fill=_ACCENT, width=2, capstyle="round")
    base_y = cy + r * 1.5
    canvas.create_rectangle(cx - r * 0.55, base_y, cx + r * 0.55, base_y + h * 0.14,
                            outline=_ACCENT, width=2)
    canvas.create_line(cx - r * 0.35, base_y + h * 0.22, cx + r * 0.35, base_y + h * 0.22,
                       fill=_ACCENT, width=2, capstyle="round")


# ---------------------------------------------------------------------------
# Card shell: real rounded + shadowed panel matching the rest of the app
# ---------------------------------------------------------------------------

class _Card(tk.Frame):
    """A rounded, softly-shadowed card (same visual language as
    gui/widgets.py:GlassCard, reimplemented locally so this standalone
    Toplevel doesn't need a full theme/app context to draw one)."""

    def __init__(self, parent, min_height=0):
        super().__init__(parent, bg=_BG)
        self.min_height = min_height
        self.canvas = tk.Canvas(self, bg=_BG, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=_CARD_BG)
        self._win = self.canvas.create_window(10, 8, anchor="nw", window=self.body)
        self.canvas.bind("<Configure>", self._redraw)
        self.body.bind("<Configure>", self._resize_to_body)

    def _resize_to_body(self, _e=None):
        self.canvas.itemconfigure(self._win, width=max(1, self.winfo_width() - 20))
        self.update_idletasks()
        h = self.body.winfo_reqheight() + 16
        h = max(h, self.min_height)
        self.canvas.config(height=h)
        self._redraw()

    def _redraw(self, _e=None):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 4 or h < 4:
            return
        paint_panel(self.canvas, w, h, fill=_CARD_BG, outline=_CARD_BORDER,
                   radius=_RADIUS, shadow=_SHADOW, backdrop=_BG)
        self.canvas.tag_raise(self._win)


def _card(parent, min_height=0):
    outer = _Card(parent, min_height=min_height)
    outer.pack(fill="x", padx=12, pady=6)
    return outer.body


# --- Clock gadget: original hand-drawn analog face + digital readout ----
def _clock_gadget(parent):
    body = _card(parent)
    size = _WIDTH - 64
    canvas = tk.Canvas(body, width=size, height=size, bg=_CARD_BG, highlightthickness=0)
    canvas.pack(pady=(10, 6))
    digital = tk.Label(body, bg=_CARD_BG, fg=_FG, font=_F_DIGITAL)
    digital.pack(pady=(0, 10))

    cx = cy = size / 2
    r = size / 2 - 8

    def tick():
        if not (canvas.winfo_exists() and digital.winfo_exists()):
            return
        canvas.delete("all")
        now = datetime.datetime.now()
        canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=_TRACK, width=3)
        canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=90,
                          extent=-360 * ((now.second + now.microsecond / 1e6) / 60),
                          outline=_ACCENT, width=3, style="arc")
        for i in range(12):
            a = math.radians(i * 30 - 90)
            x1, y1 = cx + (r - 7) * math.cos(a), cy + (r - 7) * math.sin(a)
            x2, y2 = cx + (r - 2) * math.cos(a), cy + (r - 2) * math.sin(a)
            canvas.create_line(x1, y1, x2, y2, fill=_MUTED, width=2, capstyle="round")
        hour_a = math.radians((now.hour % 12 + now.minute / 60) * 30 - 90)
        min_a = math.radians(now.minute * 6 - 90)
        canvas.create_line(cx, cy, cx + r * 0.48 * math.cos(hour_a),
                           cy + r * 0.48 * math.sin(hour_a), fill=_FG, width=3,
                           capstyle="round")
        canvas.create_line(cx, cy, cx + r * 0.74 * math.cos(min_a),
                           cy + r * 0.74 * math.sin(min_a), fill=_FG, width=2,
                           capstyle="round")
        canvas.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, fill=_ACCENT, outline="")
        digital.config(text=now.strftime("%H:%M:%S"))
        canvas.after(1000, tick)

    tick()


# --- Calendar gadget: original mini month grid --------------------------
def _calendar_gadget(parent):
    body = _card(parent)
    today = datetime.date.today()
    tk.Label(body, text=today.strftime("%B %Y"), bg=_CARD_BG, fg=_FG,
             font=_F_HEAD).pack(pady=(10, 8))
    grid = tk.Frame(body, bg=_CARD_BG)
    grid.pack(pady=(0, 10))
    for i, wd in enumerate(["S", "M", "T", "W", "T", "F", "S"]):
        tk.Label(grid, text=wd, bg=_CARD_BG, fg=_MUTED, font=_F_SMALL_BOLD,
                width=3).grid(row=0, column=i, pady=(0, 4))
    cal = calendar.Calendar(firstweekday=6)  # Sunday-first, matches header above
    row = 1
    for week in cal.monthdayscalendar(today.year, today.month):
        for col, day in enumerate(week):
            if day == 0:
                continue
            is_today = day == today.day
            cell = tk.Canvas(grid, width=24, height=22, bg=_CARD_BG,
                             highlightthickness=0)
            cell.grid(row=row, column=col, pady=1)
            if is_today:
                round_rect(cell, 2, 1, 22, 21, r=6, fill=_ACCENT, outline="")
                fg = _ON_ACCENT
            else:
                fg = _FG
            cell.create_text(12, 11, text=str(day), fill=fg, font=_F_SMALL)
        row += 1


# --- Gauge row: two side-by-side ring gauges, matching app-wide style ---
def _gauge_row(parent, specs):
    body = _card(parent)
    row = tk.Frame(body, bg=_CARD_BG)
    row.pack(pady=10, padx=4)
    for label, value_fn in specs:
        col = tk.Frame(row, bg=_CARD_BG)
        col.pack(side="left", expand=True, padx=6)
        _gauge(col, label, value_fn)


def _gauge(parent, label, value_fn):
    size = 76
    canvas = tk.Canvas(parent, width=size, height=size, bg=_CARD_BG,
                       highlightthickness=0)
    canvas.pack()
    caption = tk.Label(parent, text=label, bg=_CARD_BG, fg=_MUTED,
                       font=_F_SMALL_BOLD)
    caption.pack(pady=(6, 0))

    def tick():
        if not canvas.winfo_exists():
            return
        try:
            pct = value_fn() or 0
        except Exception:
            # A sensor hiccup (e.g. a flaky psutil/WMI counter) shouldn't
            # take the whole app down - just show 0 and try again next tick.
            pct = 0
        pct = max(0, min(100, pct))
        canvas.delete("all")
        cx = cy = size / 2
        r = size / 2 - 9
        canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=90, extent=-360,
                          outline=_TRACK, width=7, style="arc")
        color = _ACCENT2 if pct >= 80 else _ACCENT
        if pct > 0:
            canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=90,
                              extent=-360 * pct / 100,
                              outline=color, width=7, style="arc")
        canvas.create_text(cx, cy, text=f"{pct:.0f}%", fill=_FG,
                           font=("Segoe UI Semibold", 11), justify="center")
        canvas.after(1500, tick)

    tick()


# --- Tip gadget: rotating original tips, with a drawn bulb glyph --------
def _tip_gadget(parent):
    body = _card(parent)
    row = tk.Frame(body, bg=_CARD_BG)
    row.pack(fill="x", padx=12, pady=10)

    glyph = tk.Canvas(row, width=20, height=24, bg=_CARD_BG, highlightthickness=0)
    glyph.pack(side="left", padx=(0, 8), anchor="n")
    _draw_bulb_glyph(glyph, 20, 24)

    lbl = tk.Label(row, text="", bg=_CARD_BG, fg=_MUTED, font=_F_TIP,
                  wraplength=_WIDTH - 90, justify="left", anchor="w")
    lbl.pack(side="left", fill="x", expand=True)

    def rotate():
        if not lbl.winfo_exists():
            return
        lbl.config(text=random.choice(_TIPS))
        lbl.after(15000, rotate)

    rotate()
