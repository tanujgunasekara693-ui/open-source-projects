"""Activity-reactive Mystify and starfield screensavers."""

import math
import random
import time
import tkinter as tk

try:
    import psutil
except ImportError:
    psutil = None


def start(app, style="mystify", on_close=None):
    if style not in ("mystify", "starfield"):
        style = "mystify"
    existing = getattr(app, "_screensaver_window", None)
    if existing is not None:
        try:
            if existing.winfo_exists():
                existing.lift()
                return existing
        except tk.TclError:
            pass

    win = tk.Toplevel(app)
    app._screensaver_window = win
    win.configure(bg="#000000")
    win.overrideredirect(True)
    win.attributes("-fullscreen", True)
    win.attributes("-topmost", True)
    canvas = tk.Canvas(win, bg="#000000", highlightthickness=0, cursor="none")
    canvas.pack(fill="both", expand=True)
    closing = [False]

    def close(_event=None):
        if closing[0]:
            return
        closing[0] = True
        try:
            win.destroy()
        except tk.TclError:
            pass
        app._screensaver_window = None
        if on_close:
            on_close()

    win.bind("<Escape>", close)
    win.bind("<Any-KeyPress>", close)
    win.bind("<Button>", close)
    win.bind("<Motion>", close)
    try:
        win.focus_force()
    except tk.TclError:
        pass

    last_net = [None, time.monotonic()]
    last_sample = [0.0]
    activity = [0.25, 0.0]

    def sample_activity():
        now = time.monotonic()
        if now - last_sample[0] < 0.8:
            return
        last_sample[0] = now
        cpu = 0.0
        throughput = 0.0
        try:
            if psutil is not None:
                cpu = float(psutil.cpu_percent(interval=None))
                counters = psutil.net_io_counters()
                total = counters.bytes_recv + counters.bytes_sent
                if last_net[0] is not None:
                    elapsed = max(0.1, now - last_net[1])
                    throughput = max(0.0, (total - last_net[0]) / elapsed)
                last_net[:] = [total, now]
        except Exception:
            pass
        activity[:] = [max(0.0, min(1.0, cpu / 100.0)),
                       max(0.0, min(1.0, throughput / (20 * 1024 * 1024)))]

    width = lambda: max(1, canvas.winfo_width())
    height = lambda: max(1, canvas.winfo_height())

    if style == "starfield":
        stars = [[random.uniform(-1, 1), random.uniform(-1, 1),
                  random.uniform(0.08, 1.0)] for _ in range(180)]
        center = lambda: (width() / 2, height() / 2)

        def animate():
            if closing[0] or not win.winfo_exists():
                return
            sample_activity()
            canvas.delete("all")
            cx, cy = center()
            speed = 0.5 + activity[0] * 4.0 + activity[1] * 7.0
            for star in stars:
                x, y, z = star
                z -= speed * 0.002
                if z <= 0.04:
                    x, y, z = random.uniform(-1, 1), random.uniform(-1, 1), 1.0
                star[:] = [x, y, z]
                sx, sy = cx + x * cx / z, cy + y * cy / z
                if 0 <= sx < width() and 0 <= sy < height():
                    radius = max(1, min(4, int((1.02 - z) * 4)))
                    brightness = max(90, min(255, int((1.0 - z) * 255)))
                    color = f"#{brightness:02x}{brightness:02x}ff"
                    canvas.create_oval(sx - radius, sy - radius, sx + radius,
                                       sy + radius, fill=color, outline="")
            canvas.after(33, animate)
    else:
        phase = [0.0]

        def animate():
            if closing[0] or not win.winfo_exists():
                return
            sample_activity()
            canvas.delete("all")
            w, h = width(), height()
            phase[0] += 0.012 + activity[0] * 0.045 + activity[1] * 0.06
            amplitude = 0.18 + 0.20 * activity[0] + 0.25 * activity[1]
            points = []
            for index in range(6):
                t = phase[0] + index * (math.tau / 6)
                x = w * (0.5 + (0.36 + amplitude * 0.18) * math.sin(t * 0.71))
                y = h * (0.5 + (0.36 + amplitude * 0.18) * math.cos(t * 0.93))
                points.extend((x, y))
            color = "#60ff9b" if activity[0] + activity[1] < 0.8 else "#b1ff62"
            canvas.create_line(*points, points[0], points[1], fill="#0d7137",
                               width=7, smooth=True)
            canvas.create_line(*points, points[0], points[1], fill=color,
                               width=2, smooth=True)
            canvas.after(25, animate)

    animate()
    return win