#!/usr/bin/env python3
"""Apply Windows Acrylic / blur to more floating surfaces when supported."""

from __future__ import annotations

import platform
import tkinter as tk

IS_WINDOWS = platform.system() == "Windows"


def apply_acrylic(window, opacity=180, dark=True):
    """Best-effort acrylic on a Toplevel. Returns True if applied."""
    if not IS_WINDOWS or window is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        class ACCENT_POLICY(ctypes.Structure):
            _fields_ = [
                ("AccentState", ctypes.c_int),
                ("AccentFlags", ctypes.c_int),
                ("GradientColor", ctypes.c_uint),
                ("AnimationId", ctypes.c_int),
            ]

        class WINCOMPATTRDATA(ctypes.Structure):
            _fields_ = [
                ("Attribute", ctypes.c_int),
                ("Data", ctypes.POINTER(ACCENT_POLICY)),
                ("SizeOfData", ctypes.c_size_t),
            ]

        window.update_idletasks()
        hwnd = window.winfo_id()
        accent = ACCENT_POLICY()
        accent.AccentState = 4  # ACRYLICBLURBEHIND
        accent.AccentFlags = 2
        a = max(0, min(255, int(opacity)))
        # ABGR
        if dark:
            accent.GradientColor = (a << 24) | (0x12 << 16) | (0x12 << 8) | 0x12
        else:
            accent.GradientColor = (a << 24) | (0xF0 << 16) | (0xF0 << 8) | 0xF0
        data = WINCOMPATTRDATA()
        data.Attribute = 19
        data.Data = ctypes.pointer(accent)
        data.SizeOfData = ctypes.sizeof(accent)
        ctypes.windll.user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
        try:
            window.attributes("-alpha", 0.97)
        except tk.TclError:
            pass
        return True
    except Exception:
        return False


def try_acrylic_on_toplevels(app):
    """Optional pass — no-op if nothing to do."""
    return False
