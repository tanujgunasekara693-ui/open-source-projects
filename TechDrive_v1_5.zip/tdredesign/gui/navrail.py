#!/usr/bin/env python3
"""
gui/navrail.py — left navigation rail
=====================================
Windows-11-style navigation column, restyled to match the "next-gen"
concept mockup: a "Home" parent row with "Dashboard" nested under it, a
flat "All Tools" row, then grouped sections (TOOLS / REPORTS / SYSTEM)
with small-caps headers, category rows carrying a trailing chevron, and
a branded footer card (TD logo tile + app name + tier).

Every destination still routes to something that already exists in the
app - either the All Tools gallery (optionally pre-filtered to a group),
the Settings tab, or the About dialog. Nothing here re-implements tool
logic; it's purely the same NavRail shell, restructured.
"""

import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path

from gui import fluent as fl
from gui.widgets import NavItem

# Fallback if a destination list is somehow empty - keeps the rail at the
# same width it always had before this got measured dynamically.
_MIN_RAIL_WIDTH = 224


def _required_rail_width(labels):
    """Pixel width wide enough that NavItem's text_lbl never has to clip
    a label. Measures real font metrics rather than guessing a fixed
    width, so longer labels never get silently truncated by tkinter."""
    if not labels:
        return _MIN_RAIL_WIDTH
    body_font = tkfont.Font(font=fl.F_BODY())
    icon_font = tkfont.Font(font=fl.font(12))
    max_text_px = max(body_font.measure(label) for label in labels)
    icon_col_px = icon_font.measure("MM")       # icon_lbl's width=2 budget
    pill_px = 3 + 6                             # pill width + its left padx
    item_padx_px = 8 * 2                        # NavItem.pack(padx=8)
    margin_px = 16                              # breathing room / rounding
    return max(_MIN_RAIL_WIDTH,
               max_text_px + icon_col_px + pill_px + item_padx_px + margin_px)


def _flat_labels(spec):
    """Pull every real nav-item label out of the grouped spec, for width
    measurement."""
    out = []
    for entry in spec:
        if entry.get("kind") in ("item", "parent"):
            out.append(entry["label"])
    return out


class NavRail(tk.Frame):
    def __init__(self, parent, app, spec, on_dashboard):
        """
        spec : list of dicts, each one of:
          {"kind": "parent", "label", "icon"}          - non-selectable
                                                           header row with a
                                                           chevron (e.g. "Home")
          {"kind": "item", "label", "icon", "action",
           "indent": bool, "chevron": bool}             - selectable row
          {"kind": "section", "label"}                  - small-caps group
                                                           header text

        A callable action of None means "Dashboard" (handled here via
        on_dashboard). Backward compatible: callers that still pass the
        old flat (label, icon, action) tuple list get auto-wrapped.
        """
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.on_dashboard = on_dashboard
        bg = fl.glass(self.theme, "BG_LIGHT", self.aero, 0.16)

        spec = self._normalise(spec)
        rail_width = _required_rail_width(_flat_labels(spec))
        super().__init__(parent, bg=bg, width=rail_width)
        self.pack_propagate(False)

        self.items = {}

        # The rail contains enough destinations to exceed the vertical space
        # on compact laptops. Keep the brand/footer fixed while the actual
        # navigation list becomes independently scrollable. This prevents
        # headings such as REPORTS/SYSTEM from being clipped at 640px high.
        nav_host = tk.Frame(self, bg=bg)
        nav_host.pack(fill="both", expand=True, pady=(6, 4))
        nav_canvas = tk.Canvas(nav_host, bg=bg, highlightthickness=0, bd=0)
        nav_canvas.pack(side="left", fill="both", expand=True)
        nav_scroll = tk.Scrollbar(nav_host, orient="vertical", command=nav_canvas.yview,
                                  width=7, relief="flat", bd=0, highlightthickness=0,
                                  bg=bg, troughcolor=bg, activebackground=bg)
        nav_scroll.pack(side="right", fill="y")
        nav_content = tk.Frame(nav_canvas, bg=bg)
        nav_window = nav_canvas.create_window((0, 0), window=nav_content, anchor="nw")
        nav_canvas.configure(yscrollcommand=lambda first, last: self._sync_nav_scrollbar(
            nav_scroll, first, last))
        nav_canvas._wheel_scrollable = True
        nav_content.bind("<Configure>", lambda _e: nav_canvas.configure(scrollregion=nav_canvas.bbox("all")))
        nav_canvas.bind("<Configure>", lambda e: nav_canvas.itemconfigure(nav_window, width=e.width))
        nav = nav_content
        for entry in spec:
            kind = entry["kind"]
            if kind == "section":
                hdr = tk.Label(nav, text=entry["label"].upper(), bg=bg,
                               fg=self.theme["MUTED"], font=fl.F_TINY(),
                               anchor="w")
                hdr.pack(fill="x", padx=18, pady=(14, 4))
                continue
            if kind == "parent":
                # "parent" rows are group headers (e.g. "Home") and stay
                # non-selectable by default, but an optional "action" lets
                # a parent row (e.g. "TechDrive Core") be clickable too,
                # without becoming a normal highlightable NavItem.
                parent_action = entry.get("action")
                command = parent_action if callable(parent_action) else None
                item = NavItem(nav, entry["label"], entry["icon"], self.theme,
                               aero=self.aero, chevron=True, command=command)
                item.pack(fill="x", padx=8, pady=1)
                continue
            # kind == "item"
            label = entry["label"]
            action = entry.get("action")
            item = NavItem(nav, label, entry["icon"], self.theme,
                           aero=self.aero,
                           indent=entry.get("indent", False),
                           chevron=entry.get("chevron", False),
                           command=lambda l=label, a=action: self._select(l, a))
            item.pack(fill="x", padx=8, pady=1)
            self.items[label] = item
            if action is None:
                # "Dashboard" by contract (see _select), but matched by
                # action rather than by an English literal so a translated
                # label still selects correctly on startup/rebuild.
                self._dashboard_label = label
        self.select(getattr(self, "_dashboard_label", None), notify=False)

        # --- footer brand card -------------------------------------------
        # A small rounded "TD" tile + app name + tier, echoing the
        # concept mockup's bottom-of-rail branded card instead of the
        # old plain two lines of text.
        footer_wrap = tk.Frame(self, bg=bg)
        footer_wrap.pack(side="bottom", fill="x", padx=10, pady=10)
        card_bg = fl.glass(self.theme, "LAYER_1", self.aero, 0.18)
        footer = tk.Frame(footer_wrap, bg=card_bg)
        footer.pack(fill="x")
        inner = tk.Frame(footer, bg=card_bg)
        inner.pack(fill="x", padx=10, pady=10)
        # Use the real TechDrive app icon in the branded footer card.
        # Keep a strong reference so Tk does not garbage-collect the image.
        brand_icon_path = Path(__file__).resolve().parent / "assets" / "ui_icons" / "techdrive_brand_40.png"
        self._footer_brand_icon = None
        if brand_icon_path.exists():
            try:
                self._footer_brand_icon = tk.PhotoImage(master=inner, file=str(brand_icon_path))
            except Exception:
                self._footer_brand_icon = None
        if self._footer_brand_icon is not None:
            tile = tk.Label(inner, image=self._footer_brand_icon, bg=card_bg,
                            bd=0, highlightthickness=0)
        else:
            tile = tk.Label(inner, text="TD", bg=self.theme["ACCENT"],
                            fg=self.theme["ON_ACCENT"], font=fl.F_CARD_TITLE(),
                            width=3, height=1)
        tile.pack(side="left")
        text_col = tk.Frame(inner, bg=card_bg)
        text_col.pack(side="left", padx=(8, 0))
        tk.Label(text_col, text="TechDrive 1.1", bg=card_bg,
                 fg=self.theme["FG"], font=fl.F_TINY()).pack(anchor="w")
        tk.Label(text_col, text=app._tier_text(), bg=card_bg,
                 fg=self.theme["ACCENT"], font=fl.F_TINY()).pack(anchor="w")

    # ------------------------------------------------------------------
    @staticmethod
    def _sync_nav_scrollbar(scrollbar, first, last):
        try:
            if float(first) <= 0.001 and float(last) >= 0.999:
                scrollbar.pack_forget()
            elif not scrollbar.winfo_ismapped():
                scrollbar.pack(side="right", fill="y")
            scrollbar.set(first, last)
        except tk.TclError:
            pass

    @staticmethod
    def _normalise(spec):
        """Accept either the new grouped-dict spec, or the old flat list
        of (label, icon, action) tuples, for backward compatibility."""
        if not spec:
            return []
        if isinstance(spec[0], dict):
            return spec
        return [{"kind": "item", "label": label, "icon": icon, "action": action}
                for label, icon, action in spec]

    def select(self, label, notify=True):
        for name, item in self.items.items():
            item.set_selected(name == label)

    def _select(self, label, action):
        self.select(label)
        if action is None:
            self.on_dashboard()
        else:
            try:
                action()
            except Exception as exc:
                try:
                    if hasattr(self.app, "show_toast"):
                        self.app.show_toast(f"{label}: {exc}", kind="error")
                    elif hasattr(self.app, "status_text"):
                        self.app.status_text.set(f"{label}: {exc}")
                except Exception:
                    pass
