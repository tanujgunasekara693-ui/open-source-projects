#!/usr/bin/env python3
"""Share Sheet — Apple-style export/share panel for reports and text."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import tkinter as tk
from pathlib import Path

from gui import fluent as fl
from gui.motion import tween, spring
from gui.widgets import FluentButton, round_rect


def show_share_sheet(app, *, title="Share", text="", file_path=None, default_name="TechDrive_Report"):
    """Open a springy share sheet.

    Provide either `text` (summary/body) and/or `file_path` (existing report).
    """
    ShareSheet(app, title=title, text=text or "", file_path=file_path, default_name=default_name)


class ShareSheet(tk.Toplevel):
    def __init__(self, app, title="Share", text="", file_path=None, default_name="TechDrive_Report"):
        super().__init__(app)
        self.app = app
        self.theme = app.theme
        self.text = text or ""
        self.file_path = file_path
        self.default_name = default_name
        self.title(title)
        self.overrideredirect(True)
        self.configure(bg=self.theme.get("STROKE", "#333"))
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.geometry(self._geometry())
        self.transient(app)
        self._build()
        self.bind("<Escape>", lambda e: self.destroy())
        try:
            self.attributes("-alpha", 0.0)
            self.after(10, self._fade_in)
        except tk.TclError:
            pass
        try:
            from gui.acrylic import apply_acrylic
            apply_acrylic(self, opacity=175)
        except Exception:
            pass

    def _geometry(self):
        w, h = 420, 360
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        x = max(8, (sw - w) // 2)
        y = max(40, (sh - h) // 2)
        return f"{w}x{h}+{x}+{y}"

    def _fade_in(self):
        for i, a in enumerate((0.3, 0.55, 0.8, 1.0)):
            self.after(i * 25, lambda a=a: self._set_alpha(a))

    def _set_alpha(self, a):
        try:
            self.attributes("-alpha", a)
        except tk.TclError:
            pass

    def _build(self):
        th = self.theme
        outer = tk.Frame(self, bg=th.get("LAYER_1", th["BG"]))
        outer.pack(fill="both", expand=True, padx=2, pady=2)

        tk.Label(
            outer, text="SHARE", bg=outer["bg"], fg=th["MUTED"],
            font=("Segoe UI", 8, "bold"), anchor="w",
        ).pack(fill="x", padx=16, pady=(14, 4))
        tk.Label(
            outer, text="Share report", bg=outer["bg"], fg=th["FG"],
            font=fl.F_TITLE3() if hasattr(fl, "F_TITLE3") else ("Segoe UI", 16, "bold"),
            anchor="w",
        ).pack(fill="x", padx=16, pady=(0, 12))

        actions = [
            ("Copy summary", "Copy text to clipboard", self._copy),
            ("Save as file…", "Choose folder and save", self._save_as),
            ("Open folder", "Reveal file in Explorer", self._reveal),
            ("Email draft", "Open mail client with summary", self._email),
        ]
        for label, hint, cmd in actions:
            row = tk.Frame(outer, bg=th.get("LAYER_2", th["CARD_BG"]), cursor="hand2")
            row.pack(fill="x", padx=14, pady=4)
            tk.Label(row, text=label, bg=row["bg"], fg=th["FG"],
                     font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x", padx=12, pady=(10, 0))
            tk.Label(row, text=hint, bg=row["bg"], fg=th["MUTED"],
                     font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=12, pady=(0, 10))
            row.bind("<Button-1>", lambda e, c=cmd: c())
            for ch in row.winfo_children():
                ch.bind("<Button-1>", lambda e, c=cmd: c())

        FluentButton(
            outer, "Cancel", command=self.destroy, theme=th,
            aero=getattr(self.app, "is_aero_enabled", lambda: False)(),
            kind="subtle", height=32, backdrop=outer["bg"],
        ).pack(pady=(12, 16))

    def _ensure_file(self):
        if self.file_path and os.path.isfile(self.file_path):
            return self.file_path
        # Write text to temp file
        suffix = ".txt"
        path = os.path.join(tempfile.gettempdir(), f"{self.default_name}{suffix}")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.text or "(empty)")
            self.file_path = path
            return path
        except Exception:
            return None

    def _copy(self):
        data = self.text
        if not data and self.file_path and os.path.isfile(self.file_path):
            try:
                with open(self.file_path, "r", encoding="utf-8", errors="ignore") as f:
                    data = f.read()[:50000]
            except Exception:
                data = ""
        try:
            self.clipboard_clear()
            self.clipboard_append(data or "")
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Copied to clipboard", kind="success")
        except Exception:
            pass
        self.destroy()

    def _save_as(self):
        from gui.tk_dialogs import filedialog
        src = self._ensure_file()
        if not src:
            return
        dest = filedialog.asksaveasfilename(
            parent=self,
            initialfile=os.path.basename(src),
            defaultextension=os.path.splitext(src)[1] or ".txt",
            filetypes=[("All files", "*.*"), ("Text", "*.txt"), ("HTML", "*.html"), ("PDF", "*.pdf")],
        )
        if dest:
            try:
                shutil.copy2(src, dest)
                self.file_path = dest
                if hasattr(self.app, "show_toast"):
                    self.app.show_toast("Saved", kind="success")
            except Exception as e:
                if hasattr(self.app, "show_toast"):
                    self.app.show_toast(f"Save failed: {e}", kind="error")
        self.destroy()

    def _reveal(self):
        path = self._ensure_file()
        if not path:
            return
        folder = os.path.dirname(os.path.abspath(path))
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", os.path.abspath(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception:
            pass
        self.destroy()

    def _email(self):
        import urllib.parse
        subject = urllib.parse.quote(self.default_name)
        body = urllib.parse.quote((self.text or "")[:4000])
        try:
            webbrowser_open = __import__("webbrowser").open
            webbrowser_open(f"mailto:?subject={subject}&body={body}")
        except Exception:
            pass
        self.destroy()
