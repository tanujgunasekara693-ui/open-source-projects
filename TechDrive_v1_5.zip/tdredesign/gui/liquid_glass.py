#!/usr/bin/env python3
"""
gui/liquid_glass.py - "Liquid Glass" surfaces for TechDrive
============================================================
A pure-tkinter take on the translucent, light-bending glass look of the
newest Apple design language.  Tk has no per-widget alpha or blur, so the
effect is built the same way the rest of TechDrive fakes glass (see
gui.fluent.mix): colour blending on a canvas.  What makes it read as
*liquid* glass rather than a flat card is the lighting model:

  * a cool, bright upper band that fades into the card colour (the glass
    catching light from above)
  * a soft refracted glow along the bottom edge (light bouncing back
    through the pane)
  * a thin specular rim, brightest on the top-left and bottom-right
    corners and dim in between, like a bevelled lens edge
  * a tiny specular glint near the top-left

Nothing here changes any background: panels are painted over whatever
backdrop colour the caller passes in, so the existing dashboard grid, glow
and hero artwork stay exactly as they were.

Public API
----------
    enabled() / set_enabled(flag)      user toggle (setting: liquid_glass)
    paint_liquid_panel(...)            drop-in for widgets.paint_panel
    paint_liquid_shape(...)            body + lighting only (no shadow)
    LiquidArrows                       segmented  <  >  capsule
    TabNavBar                          arrow bar that drives a ttk.Notebook
"""

import math
import tkinter as tk

from gui import fluent as fl

_ENABLED = None          # cached user setting (None = not read yet)


# ---------------------------------------------------------------------------
# User toggle
# ---------------------------------------------------------------------------

def enabled():
    """True when the Liquid Glass look is on (default: on)."""
    global _ENABLED
    if _ENABLED is None:
        try:
            from shared import database as db
            _ENABLED = bool(db.get_setting("liquid_glass", True))
        except Exception:
            _ENABLED = True
    return _ENABLED


def set_enabled(flag):
    """Persist and apply the toggle. Callers should redraw afterwards."""
    global _ENABLED
    _ENABLED = bool(flag)
    try:
        from shared import database as db
        db.set_setting("liquid_glass", _ENABLED)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Drawing helpers
# ---------------------------------------------------------------------------

def _rr(canvas, x1, y1, x2, y2, r, **kw):
    """Rounded rectangle (smoothed polygon, same trick as widgets.round_rect)."""
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
           x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
           x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return canvas.create_polygon(pts, smooth=True, **kw)


def _is_light(color):
    return fl.relative_luminance(color) > 0.5


def _row_inset(y, y1, y2, r):
    """Horizontal inset of a rounded rect at height y (clips gradient rows
    to the rounded outline, so the glass never pokes past its corners)."""
    if r <= 0:
        return 0.0
    if y < y1 + r:
        dy = (y1 + r) - y
    elif y > y2 - r:
        dy = y - (y2 - r)
    else:
        return 0.0
    dy = min(dy, r)
    return r - math.sqrt(max(0.0, r * r - dy * dy))


def _glass_colors(fill, tint, light, hovered):
    """Return (top, mid, bottom) gradient stops for a pane of `fill`.

    Tuned for a crisp Apple liquid-glass look: bright top specular,
    clean mid, soft bottom refraction. Less muddy than heavy Aero.
    """
    if light:
        top = fl.mix(fill, "#ffffff", 0.48)
        mid = fl.mix(fill, tint, 0.03)
        bottom = fl.mix(fill, tint, 0.12)
    else:
        # Dark glass: cool specular highlight, restrained tint
        top = fl.mix(fill, "#ffffff", 0.18)
        mid = fl.mix(fill, tint, 0.04)
        bottom = fl.mix(fill, fl.mix(tint, "#ffffff", 0.12), 0.10)
    if hovered:
        top = fl.mix(top, "#ffffff", 0.08)
        bottom = fl.mix(bottom, tint, 0.08)
    return top, mid, bottom


def _lerp_stops(stops, t):
    """stops = [(pos, color), ...] ascending; blend at t in 0..1."""
    if t <= stops[0][0]:
        return stops[0][1]
    for (p0, c0), (p1, c1) in zip(stops, stops[1:]):
        if t <= p1:
            span = max(1e-6, p1 - p0)
            return fl.mix(c0, c1, (t - p0) / span)
    return stops[-1][1]


def paint_liquid_shape(canvas, x1, y1, x2, y2, fill, outline, radius,
                       tint, hovered=False, pressed=False, tag="panel",
                       glint=True):
    """Paint the glass body + lighting inside the box (x1,y1)-(x2,y2).

    No shadow is drawn here, so it can be reused for buttons, pills and
    the arrow capsule as well as full cards.
    """
    h = y2 - y1
    w = x2 - x1
    if w < 6 or h < 6:
        return
    r = max(2, min(radius, w / 2, h / 2))
    light = _is_light(fill)
    top, mid, bottom = _glass_colors(fill, tint, light, hovered)
    if pressed:
        top, mid, bottom = (fl.darken(c, 0.07) for c in (top, mid, bottom))
    stops = [(0.0, top), (0.42, mid), (1.0, bottom)]

    # Rim colours: bright where light hits the bevel, dim elsewhere.
    if light:
        rim_hi = fl.mix(outline, "#ffffff", 0.9)
        rim_lo = fl.mix(outline, tint, 0.25)
        rim_mid = outline
    else:
        rim_hi = fl.mix(fl.mix(tint, "#ffffff", 0.7), "#ffffff", 0.25)
        rim_lo = fl.mix(outline, fl.mix(tint, "#ffffff", 0.5), 0.35)
        rim_mid = fl.mix(outline, fl.mix(tint, "#ffffff", 0.3), 0.25)
    if hovered:
        rim_mid = fl.mix(rim_mid, tint, 0.45)
        rim_lo = fl.mix(rim_lo, tint, 0.45)

    # Underlay (gives the rounded silhouette + smooths row seams).
    _rr(canvas, x1, y1, x2, y2, r, fill=mid, outline="", tags=tag)

    # Gradient rows, clipped to the rounded outline. Rows are 2px in the
    # corner zones (so the curve stays clean) and larger through the middle.
    y = y1 + 1
    end = y2 - 1
    while y < end:
        in_corner = (y < y1 + r) or (y > y2 - r - 4)
        step = 1 if in_corner else max(2, int(h / 18))
        yb = min(end, y + step)
        ym = (y + yb) / 2
        inset = _row_inset(ym, y1, y2, r) + 1
        t = (ym - y1) / h
        canvas.create_rectangle(x1 + inset, y, x2 - inset, yb + 0.5,
                                fill=_lerp_stops(stops, t), outline="",
                                tags=tag)
        y = yb

    # Rim: full outline, then brighter arcs on the two lit corners.
    _rr(canvas, x1, y1, x2, y2, r, fill="", outline=rim_mid, width=1,
        tags=tag)
    span = max(8.0, min(r * 2.0, w * 0.45))
    d = r * 2
    # top edge highlight (fades toward the right via two segments)
    canvas.create_line(x1 + r, y1 + 0.5, x1 + r + span, y1 + 0.5,
                       fill=rim_hi, width=1, tags=tag)
    canvas.create_line(x1 + r + span, y1 + 0.5, x2 - r, y1 + 0.5,
                       fill=fl.mix(rim_hi, rim_mid, 0.55), width=1, tags=tag)
    # bottom edge: soft refraction light, brighter toward the right
    canvas.create_line(x1 + r, y2 - 0.5, x2 - r - span, y2 - 0.5,
                       fill=rim_lo, width=1, tags=tag)
    canvas.create_line(x2 - r - span, y2 - 0.5, x2 - r, y2 - 0.5,
                       fill=fl.mix(rim_lo, rim_hi, 0.55), width=1, tags=tag)
    # lit corners (top-left bright, bottom-right medium)
    canvas.create_arc(x1, y1, x1 + d, y1 + d, start=90, extent=90,
                      style="arc", outline=rim_hi, width=2, tags=tag)
    canvas.create_arc(x2 - d, y2 - d, x2, y2, start=270, extent=90,
                      style="arc",
                      outline=fl.mix(rim_hi, rim_lo, 0.45), width=2,
                      tags=tag)
    # side edges, left lit more than right
    if h > d + 4:
        canvas.create_line(x1 + 0.5, y1 + r, x1 + 0.5, y2 - r,
                           fill=fl.mix(rim_mid, rim_hi, 0.4), width=1,
                           tags=tag)
        canvas.create_line(x2 - 0.5, y1 + r, x2 - 0.5, y2 - r,
                           fill=rim_lo, width=1, tags=tag)

    # Specular glint, near the top-left.
    if glint and w > 60 and h > 24:
        gx, gy = x1 + r * 1.15, y1 + 3.5
        canvas.create_oval(gx, gy, gx + min(22, w * 0.12), gy + 3,
                           fill=fl.mix(top, "#ffffff", 0.45 if not light else 0.9),
                           outline="", tags=tag)


def paint_liquid_panel(canvas, w, h, fill, outline, radius=fl.RADIUS_CARD,
                       shadow=None, backdrop=None, tint=None,
                       hovered=False, shadow_layers=fl.SHADOW_LAYERS,
                       tag="panel"):
    """Drop-in liquid-glass replacement for widgets.paint_panel.

    The soft shadow is drawn exactly like paint_panel draws it, so panels
    sit on the existing background identically; only the pane itself
    changes."""
    canvas.delete(tag)
    if w < 4 or h < 4:
        return
    tint = tint or outline
    if shadow and backdrop:
        for i in range(shadow_layers, 0, -1):
            t = 0.12 * (shadow_layers - i + 1) / shadow_layers
            _rr(canvas, i, i + 1, w - i, h - i + 1, radius + i,
                fill=fl.mix(backdrop, shadow, t), outline="", tags=tag)
    paint_liquid_shape(canvas, 0, 0, w - 1, h - shadow_layers, fill, outline,
                       radius, tint, hovered=hovered, tag=tag, glint=False)
    canvas.tag_lower(tag)


# ---------------------------------------------------------------------------
# Arrow capsule  (  <  |  >  )
# ---------------------------------------------------------------------------

class LiquidArrows(tk.Canvas):
    """Two-segment liquid-glass capsule holding a previous / next chevron.

    Each half hovers and presses independently, and dims when it has
    nowhere to go (first / last tab)."""

    def __init__(self, parent, theme, on_prev=None, on_next=None,
                 backdrop=None, width=84, height=30):
        self.theme = theme
        self.on_prev = on_prev
        self.on_next = on_next
        self._backdrop = backdrop or theme["BG"]
        self._can = {"prev": True, "next": True}
        self._hover = None
        self._press = None
        super().__init__(parent, width=width, height=height,
                         bg=self._backdrop, highlightthickness=0, bd=0,
                         cursor="hand2", takefocus=0)
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Motion>", self._on_motion)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

    def set_state(self, can_prev, can_next):
        if (can_prev, can_next) != (self._can["prev"], self._can["next"]):
            self._can = {"prev": bool(can_prev), "next": bool(can_next)}
            self._draw()

    def _half(self, x):
        return "prev" if x < self.winfo_width() / 2 else "next"

    def _on_motion(self, e):
        half = self._half(e.x)
        if half != self._hover:
            self._hover = half
            self._draw()

    def _on_leave(self, _e):
        self._hover = None
        self._press = None
        self._draw()

    def _on_press(self, e):
        self._press = self._half(e.x)
        self._draw()

    def _on_release(self, e):
        half = self._half(e.x)
        fire = (self._press == half) and self._can[half]
        self._press = None
        self._draw()
        if fire:
            cb = self.on_prev if half == "prev" else self.on_next
            if cb:
                cb()

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 20 or h < 10:
            return
        th = self.theme
        fill = th["LAYER_1"]
        any_hover = self._hover is not None
        paint_liquid_shape(self, 1, 1, w - 2, h - 2, fill, th["STROKE"],
                           (h - 3) / 2, th["ACCENT"], hovered=any_hover,
                           pressed=self._press is not None, tag="cap",
                           glint=False)
        mid = w / 2
        # A lit half: soft accent wash under the hovered/pressed chevron.
        if self._hover and self._can[self._hover]:
            x1, x2 = (3, mid - 1) if self._hover == "prev" else (mid + 1, w - 4)
            wash = fl.mix(fill, th["ACCENT"], 0.30 if self._press == self._hover else 0.18)
            _rr(self, x1, 3, x2, h - 4, (h - 8) / 2, fill=wash,
                outline="", tags="cap")
        # divider
        self.create_line(mid, 7, mid, h - 7,
                         fill=fl.mix(th["STROKE"], th["FG"], 0.25), width=1)
        for half, cx in (("prev", w * 0.25), ("next", w * 0.75)):
            ok = self._can[half]
            col = th["FG"] if ok else fl.mix(th["FG"], th["BG"], 0.68)
            if ok and self._hover == half:
                col = th["ACCENT_GLOW"]
            s = 4.2
            cy = h / 2
            if half == "prev":
                pts = (cx + s * 0.6, cy - s * 1.15, cx - s * 0.6, cy,
                       cx + s * 0.6, cy + s * 1.15)
            else:
                pts = (cx - s * 0.6, cy - s * 1.15, cx + s * 0.6, cy,
                       cx - s * 0.6, cy + s * 1.15)
            self.create_line(*pts, fill=col, width=2, capstyle="round",
                             joinstyle="round")


# ---------------------------------------------------------------------------
# Tab navigation bar
# ---------------------------------------------------------------------------

class TabNavBar(tk.Frame):
    """Slim bar above the tab notebook with previous / next arrows, the
    open-tab position (e.g. 2 / 5) and the current tab's name.

    Works with any ttk.Notebook (TechDrive's ClosableNotebook included) and
    needs nothing from it except the stock tabs()/select()/tab() calls, so
    tabs opened or closed anywhere in the app keep the bar in sync via the
    notebook's own events.  Alt+Left / Alt+Right do the same as the arrows.
    """

    def __init__(self, parent, notebook, theme, title_of=None):
        super().__init__(parent, bg=theme["BG"], height=34)
        self.notebook = notebook
        self.theme = theme
        self._title_of = title_of or self._default_title
        self.pack_propagate(False)

        self.arrows = LiquidArrows(self, theme, on_prev=self.prev_tab,
                                   on_next=self.next_tab)
        self.arrows.pack(side="left", padx=(fl.GAP, 10), pady=2)
        self.pos_lbl = tk.Label(self, text="", bg=theme["BG"],
                                fg=theme["MUTED"], font=fl.font(9, "bold"))
        self.pos_lbl.pack(side="left")
        self.name_lbl = tk.Label(self, text="", bg=theme["BG"],
                                 fg=theme["FG"], font=fl.font(10, "bold"))
        self.name_lbl.pack(side="left", padx=(8, 0))

        self._after = None
        notebook.bind("<<NotebookTabChanged>>", self._schedule, add="+")
        notebook.bind("<ButtonRelease-1>", self._schedule, add="+")
        notebook.bind("<Map>", self._schedule, add="+")
        self.bind("<Destroy>", self._on_destroy, add="+")
        self._top = self.winfo_toplevel()
        self._key_ids = (
            self._top.bind("<Alt-Left>", self._key_prev, add="+"),
            self._top.bind("<Alt-Right>", self._key_next, add="+"),
        )
        self._schedule()

    @staticmethod
    def _default_title(text):
        text = str(text or "").strip()
        if text.endswith("\u00d7"):
            text = text[:-1].rstrip()
        if " " in text:
            first, rest = text.split(" ", 1)
            if rest and not any(ch.isalnum() for ch in first):
                text = rest.strip()
        return text

    # -- navigation ----------------------------------------------------
    def _tabs(self):
        try:
            return list(self.notebook.tabs())
        except tk.TclError:
            return []

    def _current_index(self, tabs):
        try:
            cur = self.notebook.select()
            return tabs.index(cur) if cur in tabs else -1
        except tk.TclError:
            return -1

    def _go(self, delta):
        tabs = self._tabs()
        i = self._current_index(tabs)
        if i < 0:
            return
        j = i + delta
        if 0 <= j < len(tabs):
            try:
                self.notebook.select(tabs[j])
            except tk.TclError:
                pass
            self._schedule()

    def prev_tab(self):
        self._go(-1)

    def next_tab(self):
        self._go(+1)

    def _key_prev(self, _e=None):
        self.prev_tab()
        return "break"

    def _key_next(self, _e=None):
        self.next_tab()
        return "break"

    # -- state ---------------------------------------------------------
    def _schedule(self, _e=None):
        if self._after is None:
            try:
                self._after = self.after_idle(self.refresh)
            except tk.TclError:
                self._after = None

    def refresh(self):
        self._after = None
        try:
            tabs = self._tabs()
            i = self._current_index(tabs)
            if i < 0:
                self.pos_lbl.configure(text="")
                self.name_lbl.configure(text="")
                self.arrows.set_state(False, False)
                return
            self.arrows.set_state(i > 0, i < len(tabs) - 1)
            self.pos_lbl.configure(text=f"{i + 1} / {len(tabs)}")
            self.name_lbl.configure(
                text=self._title_of(self.notebook.tab(tabs[i], "text")))
        except tk.TclError:
            pass

    def _on_destroy(self, event):
        if event.widget is not self:
            return
        # Remove only our own bindings, never anyone else's.
        try:
            for seq, fid in zip(("<Alt-Left>", "<Alt-Right>"), self._key_ids):
                self._top.unbind(seq, fid)
        except Exception:
            pass
