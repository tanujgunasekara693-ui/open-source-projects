# Auto-generated TechDrive icon registry.
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "icon_manifest.json"
DATA = json.loads(MANIFEST.read_text(encoding="utf-8"))

BY_ID = {e["icon_id"]: e for e in DATA["entries"]}
BY_KEY = {(e["module"], e["category"], e["tool"], e["index"]): e for e in DATA["entries"]}

def icon_path(icon_id: str, size: int = 32) -> Path:
    e = BY_ID[icon_id]
    if size not in DATA["sizes"]:
        raise ValueError(f"Unsupported icon size: {size}; use {DATA['sizes']}")
    return ROOT / e["icon_dir"] / f"{icon_id}_{size}.png"

def icon_svg_path(icon_id: str) -> Path:
    e = BY_ID[icon_id]
    return ROOT / e["icon_dir"] / f"{icon_id}.svg"

def find_icon(module: str, category: str, tool: str, index: int = 0) -> str:
    return BY_KEY[(module, category, tool, index)]["icon_id"]
