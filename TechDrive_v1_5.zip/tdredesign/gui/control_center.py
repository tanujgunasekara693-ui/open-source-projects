#!/usr/bin/env python3
"""
gui/control_center.py — Floating Apple-style Control Center
=============================================================
Springy liquid-glass sheet with:
  • Swipe-down dismiss (rubber-band spring)
  • Windows Acrylic / blur backdrop when available
  • Theme chips + quick toggles

Open: Ctrl+Shift+C, toolbar "Controls", or Settings menu.
"""

from __future__ import annotations

import platform
import tkinter as tk

from gui import fluent as fl
from gui import liquid_glass as lg
from gui.motion import (
    ease_out_quint,
    spring,
    sheet_dismiss,
    sheet_present,
    motion_enabled,
    tween,
)
from gui.widgets import round_rect
from shared import database as db

IS_WINDOWS = platform.system() == "Windows"


def _theme_aero(root):
    theme = getattr(root, "theme", fl.DARK)
    aero = False
    fn = getattr(root, "is_aero_enabled", None)
    if callable(fn):
        try:
            aero = bool(fn())
        except Exception:
            pass
    return theme, aero


def _try_acrylic_overlay(hwnd, enable=True, opacity=160):
    """Best-effort Windows acrylic/blur on a Toplevel HWND."""
    if not IS_WINDOWS or not hwnd:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        class ACCENT_POLICY(ctypes.Structure):
            _fields_ = [
                ("AccentState", ctypes.c_int),
                ("AccentFlags", ctypes.c_int),
                ("GradientColor", ctypes.c_uint),
                ("AnimationId", ctypes.c_int),
            ]

        class WINCOMPATTRDATA(ctypes.Structure):
            _fields_ = [
                ("Attribute", ctypes.c_int),
                ("Data", ctypes.POINTER(ACCENT_POLICY)),
                ("SizeOfData", ctypes.c_size_t),
            ]

        user32 = ctypes.windll.user32
        # ACCENT_ENABLE_ACRYLICBLURBEHIND = 4, BLURBEHIND = 3
        accent = ACCENT_POLICY()
        accent.AccentState = 4 if enable else 0
        accent.AccentFlags = 2
        # ABGR: alpha << 24 | B << 16 | G << 8 | R
        a = max(0, min(255, int(opacity)))
        accent.GradientColor = (a << 24) | (0x10 << 16) | (0x10 << 8) | 0x10
        data = WINCOMPATTRDATA()
        data.Attribute = 19  # WCA_ACCENT_POLICY
        data.Data = ctypes.pointer(accent)
        data.SizeOfData = ctypes.sizeof(accent)
        user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
        return True
    except Exception:
        return False


class _ToggleRow(tk.Frame):
    def __init__(self, parent, theme, label, value, command, aero=False):
        super().__init__(parent, bg=parent["bg"])
        self.theme = theme
        self._value = bool(value)
        self._command = command

        tk.Label(
            self, text=label, bg=parent["bg"], fg=theme["FG"],
            font=fl.F_BODY(), anchor="w",
        ).pack(side="left", fill="x", expand=True)

        self.switch = tk.Canvas(
            self, width=46, height=28, bg=parent["bg"],
            highlightthickness=0, bd=0, cursor="hand2",
        )
        self.switch.pack(side="right")
        self.switch.bind("<Button-1>", self._toggle)
        self._draw()

    def _draw(self):
        self.switch.delete("all")
        w, h = 46, 28
        on = self._value
        track = self.theme["ACCENT"] if on else fl.mix(
            self.theme["LAYER_2"], self.theme["STROKE"], 0.35
        )
        round_rect(self.switch, 0, 0, w - 1, h - 1, r=14, fill=track, outline="")
        kx = (w - 24 - 2) if on else 2
        self.switch.create_oval(kx, 2, kx + 24, 26, fill="#ffffff", outline="")

    def _toggle(self, _e=None):
        self._value = not self._value
        self._draw()
        if self._command:
            try:
                self._command(self._value)
            except Exception:
                pass


class _ThemeChip(tk.Canvas):
    def __init__(self, parent, theme_id, label, palette, selected, command, bg):
        super().__init__(
            parent, width=72, height=56, bg=bg,
            highlightthickness=0, bd=0, cursor="hand2",
        )
        self.theme_id = theme_id
        self.palette = palette
        self._selected = selected
        self._command = command
        self._label = label
        self.bind("<Button-1>", lambda e: self._command and self._command(self.theme_id))
        self._draw()

    def _draw(self):
        self.delete("all")
        p = self.palette
        fill = p.get("CARD_BG", p.get("BG", "#111"))
        accent = p.get("ACCENT", "#0a84ff")
        stroke = accent if self._selected else p.get("STROKE", "#333")
        round_rect(self, 2, 2, 70, 40, r=10, fill=fill, outline=stroke,
                   width=2 if self._selected else 1)
        self.create_rectangle(10, 12, 62, 18, fill=accent, outline="")
        self.create_text(36, 48, text=self._label, fill="#98989d",
                         font=("Segoe UI", 9))


class ControlCenter:
    def __init__(self, app):
        self.app = app
        self._overlay = None
        self._sheet = None
        self._open = False
        self._anim_cancel = None
        self._drag = None  # {start_y, sheet_y0, dragging}
        self._acrylic = False

    def toggle(self):
        if self._open:
            self.hide()
        else:
            self.show()

    def show(self):
        if self._open:
            return
        self._open = True
        try:
            from gui import haptics
            haptics.sheet_open()
        except Exception:
            pass
        root = self.app
        theme, aero = _theme_aero(root)
        th = theme

        # Overlay — prefer a real Toplevel so we can apply Acrylic on Windows
        self._overlay = tk.Toplevel(root)
        self._overlay.withdraw()
        self._overlay.overrideredirect(True)
        self._overlay.configure(bg="#000000")
        try:
            self._overlay.attributes("-topmost", True)
        except tk.TclError:
            pass

        root.update_idletasks()
        rx, ry = root.winfo_rootx(), root.winfo_rooty()
        rw = max(root.winfo_width(), 400)
        rh = max(root.winfo_height(), 400)
        self._overlay.geometry(f"{rw}x{rh}+{rx}+{ry}")

        # Acrylic / blur when possible; otherwise solid dim
        self._acrylic = False
        try:
            self._overlay.update_idletasks()
            hwnd = self._overlay.winfo_id()
            # On Windows, try translucent + acrylic
            if IS_WINDOWS:
                try:
                    self._overlay.attributes("-transparentcolor", "")
                    self._overlay.attributes("-alpha", 0.92)
                except tk.TclError:
                    pass
                self._acrylic = _try_acrylic_overlay(hwnd, True, opacity=140)
        except Exception:
            self._acrylic = False

        if not self._acrylic:
            try:
                self._overlay.attributes("-alpha", 0.55)
            except tk.TclError:
                pass

        self._overlay.deiconify()
        try:
            # Soft dim fade-in
            self._overlay.attributes("-alpha", 0.0)
            def _ov(t, ov=self._overlay, target=0.55 if not self._acrylic else 0.92):
                try:
                    ov.attributes("-alpha", target * min(1.0, t))
                except Exception:
                    pass
            tween(self._overlay, 280, _ov, easing=ease_out_quint)
        except Exception:
            pass
        self._overlay.bind("<Button-1>", lambda e: self.hide())
        self._overlay.bind("<Escape>", lambda e: self.hide())

        # Sheet
        sheet_w, sheet_h = 400, 500
        self._sheet = tk.Frame(self._overlay, bg=th["BG"], width=sheet_w, height=sheet_h)
        self._sheet.pack_propagate(False)

        x = (rw - sheet_w) // 2
        start_y = rh + 24
        end_y = max(36, (rh - sheet_h) // 2)
        self._end_y = end_y
        self._sheet_h = sheet_h
        self._rh = rh

        self._sheet.place(x=x, y=start_y, width=sheet_w, height=sheet_h)
        self._sheet.lift()
        # Don't close when clicking the sheet body
        self._sheet.bind("<Button-1>", lambda e: "break")

        self._build_content(th, aero)
        self._bind_swipe()

        def update(t):
            y = start_y + (end_y - start_y) * t
            try:
                self._sheet.place_configure(y=int(y))
            except Exception:
                pass

        if self._anim_cancel:
            self._anim_cancel()
        self._anim_cancel = tween(self._sheet, 460, update, easing=spring)

        try:
            self._overlay.focus_force()
        except Exception:
            pass
        root.bind("<Escape>", self._on_escape, add="+")

    def hide(self, velocity=0):
        if not self._open and self._sheet is None:
            return
        root = self.app
        sheet = self._sheet
        if sheet is None:
            self._cleanup()
            return

        try:
            start_y = int(sheet.winfo_y())
        except Exception:
            start_y = 100
        end_y = self._rh + 60
        # Faster close when flung hard
        duration = 220 if velocity > 8 else 300

        def update(t):
            y = start_y + (end_y - start_y) * t
            try:
                sheet.place_configure(y=int(y))
            except Exception:
                pass

        def finish():
            self._cleanup()

        if self._anim_cancel:
            self._anim_cancel()
        self._open = False
        self._anim_cancel = tween(sheet, duration, update, complete=finish, easing=spring)

    def _on_escape(self, _event=None):
        if self._open:
            self.hide()
            return "break"

    def _cleanup(self):
        self._open = False
        if self._anim_cancel:
            try:
                self._anim_cancel()
            except Exception:
                pass
            self._anim_cancel = None
        if self._overlay is not None and self._acrylic:
            try:
                _try_acrylic_overlay(self._overlay.winfo_id(), False)
            except Exception:
                pass
        for w in (self._sheet, self._overlay):
            if w is not None:
                try:
                    w.destroy()
                except Exception:
                    pass
        self._sheet = None
        self._overlay = None
        self._drag = None
        try:
            self.app.unbind("<Escape>")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Swipe-down dismiss with rubber-band
    # ------------------------------------------------------------------
    def _bind_swipe(self):
        sheet = self._sheet
        # Drag handle area = top ~48px + header labels
        for seq, handler in (
            ("<ButtonPress-1>", self._drag_start),
            ("<B1-Motion>", self._drag_move),
            ("<ButtonRelease-1>", self._drag_end),
        ):
            sheet.bind(seq, handler, add="+")
            for child in sheet.winfo_children():
                try:
                    child.bind(seq, handler, add="+")
                except Exception:
                    pass

    def _drag_start(self, event):
        if self._sheet is None:
            return
        # Only start drag near the top of the sheet (grab handle zone)
        try:
            local_y = event.y_root - self._sheet.winfo_rooty()
        except Exception:
            local_y = 0
        if local_y > 72:
            return  # let other widgets handle lower clicks
        if self._anim_cancel:
            try:
                self._anim_cancel()
            except Exception:
                pass
            self._anim_cancel = None
        try:
            sheet_y = int(self._sheet.winfo_y())
        except Exception:
            sheet_y = self._end_y
        self._drag = {
            "start_root_y": event.y_root,
            "sheet_y0": sheet_y,
            "last_y": event.y_root,
            "last_t": event.time,
            "velocity": 0.0,
        }
        return "break"

    def _drag_move(self, event):
        if not self._drag or self._sheet is None:
            return
        dy = event.y_root - self._drag["start_root_y"]
        # Only allow dragging downward (positive dy); rubber-band upward a little
        if dy < 0:
            dy = dy * 0.25  # resistance when pulling up
        new_y = self._drag["sheet_y0"] + dy
        # Rubber-band past rest position is already handled; clamp extreme
        new_y = max(self._end_y - 40, new_y)
        try:
            self._sheet.place_configure(y=int(new_y))
        except Exception:
            pass
        # Velocity estimate (px per ms)
        dt = max(1, event.time - self._drag["last_t"])
        self._drag["velocity"] = (event.y_root - self._drag["last_y"]) / dt
        self._drag["last_y"] = event.y_root
        self._drag["last_t"] = event.time
        return "break"

    def _drag_end(self, event):
        if not self._drag or self._sheet is None:
            self._drag = None
            return
        try:
            cur_y = int(self._sheet.winfo_y())
        except Exception:
            cur_y = self._end_y
        dy = cur_y - self._end_y
        velocity = self._drag.get("velocity", 0) * 16  # scale to ~frame
        self._drag = None

        # Dismiss if dragged far enough or flung downward
        threshold = self._sheet_h * 0.28
        if dy > threshold or velocity > 12:
            self.hide(velocity=max(velocity, 0))
            return "break"

        # Spring back to rest
        start = cur_y
        end = self._end_y

        def update(t):
            y = start + (end - start) * t
            try:
                self._sheet.place_configure(y=int(y))
            except Exception:
                pass

        if self._anim_cancel:
            self._anim_cancel()
        self._anim_cancel = tween(self._sheet, 320, update, easing=spring)
        return "break"

    # ------------------------------------------------------------------
    # Content
    # ------------------------------------------------------------------
    def _build_content(self, th, aero):
        sheet = self._sheet
        sheet.configure(bg=th["BG"])

        canvas = tk.Canvas(sheet, bg=th["BG"], highlightthickness=0, bd=0)
        canvas.place(relx=0, rely=0, relwidth=1, relheight=1)

        def paint(_e=None):
            w, h = canvas.winfo_width(), canvas.winfo_height()
            if w < 10 or h < 10:
                return
            canvas.delete("all")
            if lg.enabled():
                try:
                    lg.paint_liquid_panel(
                        canvas, w, h,
                        fill=fl.glass(th, "CARD_BG", aero, 0.28),
                        outline=th["STROKE"],
                        radius=fl.RADIUS_CARD + 4,
                        backdrop=th["BG"],
                        tint=th["AERO_TINT"],
                        hovered=False,
                    )
                except Exception:
                    round_rect(canvas, 0, 0, w - 1, h - 1, r=20,
                               fill=th["CARD_BG"], outline=th["STROKE"])
            else:
                round_rect(canvas, 0, 0, w - 1, h - 1, r=20,
                           fill=th["CARD_BG"], outline=th["STROKE"])
            # Grab handle (Apple sheet indicator)
            canvas.create_rectangle(
                w // 2 - 22, 10, w // 2 + 22, 14,
                fill=th["MUTED"], outline="", tags="handle",
            )

        canvas.bind("<Configure>", paint)
        paint()

        body = tk.Frame(sheet, bg=th["CARD_BG"])
        body.place(relx=0.04, rely=0.06, relwidth=0.92, relheight=0.90)

        header = tk.Frame(body, bg=th["CARD_BG"])
        header.pack(fill="x", pady=(4, 12))
        tk.Label(
            header, text="Control Center", bg=th["CARD_BG"], fg=th["FG"],
            font=fl.F_TITLE3() if hasattr(fl, "F_TITLE3") else fl.F_SUBTITLE(),
        ).pack(side="left")
        close_btn = tk.Label(
            header, text="✕", bg=th["CARD_BG"], fg=th["MUTED"],
            font=("Segoe UI", 14), cursor="hand2",
        )
        close_btn.pack(side="right")
        close_btn.bind("<Button-1>", lambda e: self.hide())

        tk.Label(
            body, text="APPEARANCE", bg=th["CARD_BG"], fg=th["MUTED"],
            font=fl.F_CAPTION() if hasattr(fl, "F_CAPTION") else ("Segoe UI", 9),
            anchor="w",
        ).pack(fill="x", pady=(0, 6))

        theme_row = tk.Frame(body, bg=th["CARD_BG"])
        theme_row.pack(fill="x", pady=(0, 14))
        current = getattr(self.app, "theme_id", "dark")
        for tid, label in (("dark", "Dark"), ("light", "Light"),
                           ("oled", "OLED"), ("midnight_blue", "Midnight")):
            entry = fl.THEMES.get(tid)
            if not entry:
                continue
            chip = _ThemeChip(
                theme_row, tid, label, entry["palette"],
                selected=(tid == current), command=self._pick_theme, bg=th["CARD_BG"],
            )
            chip.pack(side="left", padx=(0, 8))

        # Focus modes
        tk.Label(
            body, text="FOCUS", bg=th["CARD_BG"], fg=th["MUTED"],
            font=("Segoe UI", 9), anchor="w",
        ).pack(fill="x", pady=(8, 6))
        focus_row = tk.Frame(body, bg=th["CARD_BG"])
        focus_row.pack(fill="x", pady=(0, 10))
        try:
            from gui.focus_modes import MODES, get_mode, set_mode
            cur, _ = get_mode()
            for mid, cfg in MODES.items():
                btn = tk.Label(
                    focus_row,
                    text=f"{cfg.get('icon', '')} {cfg['label']}",
                    bg=th["ACCENT"] if mid == cur else th.get("LAYER_2", th["CARD_BG"]),
                    fg=th.get("ON_ACCENT", "#fff") if mid == cur else th["FG"],
                    font=("Segoe UI", 9, "bold"),
                    padx=10, pady=6, cursor="hand2",
                )
                btn.pack(side="left", padx=(0, 6))
                btn.bind("<Button-1>", lambda e, m=mid: (set_mode(m, self.app), self.hide(), self.app.after(120, self.show)))
        except Exception:
            pass

        tk.Frame(body, bg=th["STROKE"], height=1).pack(fill="x", pady=(0, 12))

        tk.Label(
            body, text="QUICK SETTINGS", bg=th["CARD_BG"], fg=th["MUTED"],
            font=fl.F_CAPTION() if hasattr(fl, "F_CAPTION") else ("Segoe UI", 9),
            anchor="w",
        ).pack(fill="x", pady=(0, 8))

        host = tk.Frame(body, bg=th["CARD_BG"])
        host.pack(fill="x")
        try:
            self._build_tile_grid(host, th, aero)
        except Exception:
            pass

    def _pick_theme(self, theme_id):
        apply_theme = getattr(self.app, "apply_theme_choice", None)
        if not callable(apply_theme):
            raise AttributeError("Application does not support theme selection")
        self.hide()
        apply_theme(theme_id)


def attach_control_center(app):
    """Create and attach the floating Control Center to the application."""
    control_center = ControlCenter(app)
    app.control_center = control_center
    return control_center
