"""Local, persistent TechDrive achievement tracking."""

from datetime import date, datetime, timedelta

from gui import sounds
from shared import database as db

BADGES = (
    ("first_scan", "First scan", "Complete your first Health Center scan."),
    ("freed_1gb", "Freed 1 GB", "Free at least 1 GiB with TechDrive Cleanup."),
    ("week_streak", "7-day streak", "Open TechDrive on seven consecutive days."),
)


def get_unlocked():
    value = db.get_setting("achievements_unlocked", {})
    return value if isinstance(value, dict) else {}


def _stats():
    value = db.get_setting("achievement_stats", {})
    return value if isinstance(value, dict) else {}


def _nonnegative_int(value):
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError, OverflowError):
        return 0


def _award(app, badge_id):
    unlocked = get_unlocked()
    if badge_id in unlocked:
        return False
    unlocked[badge_id] = datetime.now().isoformat(timespec="seconds")
    db.set_setting("achievements_unlocked", unlocked)
    label = next((title for key, title, _ in BADGES if key == badge_id), "Achievement")
    description = next((text for key, _, text in BADGES if key == badge_id), "")
    try:
        sounds.play("achievement")
    except Exception:
        pass
    try:
        if app is not None and hasattr(app, "notify"):
            app.notify(f"Achievement unlocked: {label}", description,
                       kind="success", toast=True, source="Achievements")
    except Exception:
        pass
    return True


def record_app_launch(app=None, today=None):
    """Count at most one active day per local calendar date."""
    day = today or date.today()
    day_text = day.isoformat()
    stats = _stats()
    last_text = stats.get("last_active_day")
    if last_text != day_text:
        try:
            previous = date.fromisoformat(last_text) if last_text else None
        except (TypeError, ValueError):
            previous = None
        current = _nonnegative_int(stats.get("active_streak", 0))
        stats["active_streak"] = current + 1 if previous == day - timedelta(days=1) else 1
        stats["last_active_day"] = day_text
        db.set_setting("achievement_stats", stats)
    if _nonnegative_int(stats.get("active_streak", 0)) >= 7:
        _award(app, "week_streak")


def record_scan(app=None):
    stats = _stats()
    stats["scan_count"] = _nonnegative_int(stats.get("scan_count", 0)) + 1
    db.set_setting("achievement_stats", stats)
    if stats["scan_count"] >= 1:
        _award(app, "first_scan")


def record_cleanup(bytes_freed, app=None):
    try:
        amount = max(0, int(bytes_freed))
    except (TypeError, ValueError, OverflowError):
        return
    if not amount:
        return
    stats = _stats()
    stats["bytes_freed"] = _nonnegative_int(stats.get("bytes_freed", 0)) + amount
    db.set_setting("achievement_stats", stats)
    if stats["bytes_freed"] >= 1024 ** 3:
        _award(app, "freed_1gb")