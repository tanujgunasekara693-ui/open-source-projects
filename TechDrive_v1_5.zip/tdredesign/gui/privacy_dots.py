#!/usr/bin/env python3
"""Privacy / probe indicators — iOS-style status dots while diagnostics run."""

from __future__ import annotations

import tkinter as tk
import time

from gui import fluent as fl

# Active probe kinds → color
_PROBE_COLORS = {
    "disk": "#ff9f0a",      # orange — storage access
    "network": "#64d2ff",   # cyan — network
    "wmi": "#bf5af2",       # purple — system management
    "scan": "#0a84ff",      # blue — general scan
    "gpu": "#30d158",       # green — GPU
}


class PrivacyDots(tk.Frame):
    def __init__(self, parent, app, theme=None, bg=None):
        th = theme or getattr(app, "theme", fl.DARK)
        bg = bg or parent["bg"]
        super().__init__(parent, bg=bg, width=72, height=28)
        self.pack_propagate(False)
        self.app = app
        self.theme = th
        self._bg = bg
        self._active = {}  # kind -> expire monotonic
        self.canvas = tk.Canvas(self, width=72, height=28, bg=bg, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self._job = None
        self._draw()
        self._tick()

    def set_theme(self, theme, bg=None):
        self.theme = theme
        if bg:
            self._bg = bg
            self.configure(bg=bg)
            self.canvas.configure(bg=bg)
        self._draw()

    def pulse(self, kind="scan", duration_s=3.0):
        """Mark a probe active for a short window."""
        kind = (kind or "scan").lower()
        self._active[kind] = time.monotonic() + max(0.5, float(duration_s))
        self._draw()

    def clear(self, kind=None):
        if kind is None:
            self._active.clear()
        else:
            self._active.pop(kind, None)
        self._draw()

    def _tick(self):
        if not self.winfo_exists():
            return
        now = time.monotonic()
        expired = [k for k, exp in self._active.items() if exp <= now]
        for k in expired:
            self._active.pop(k, None)
        if expired:
            self._draw()
        self._job = self.after(400, self._tick)

    def _draw(self):
        self.canvas.delete("all")
        kinds = list(self._active.keys())[:4]
        if not kinds:
            return
        x = 8
        for kind in kinds:
            color = _PROBE_COLORS.get(kind, self.theme.get("ACCENT", "#0a84ff"))
            self.canvas.create_oval(x, 10, x + 8, 18, fill=color, outline="")
            x += 14
        # tooltip-ish label
        self.canvas.create_text(
            min(x + 4, 70), 14, text="•", fill=self.theme.get("MUTED", "#888"),
            font=("Segoe UI", 7), anchor="w",
        )


def attach_privacy_dots(topbar, app):
    th = getattr(app, "theme", fl.DARK)
    bg = topbar["bg"] if "bg" in topbar.keys() else th.get("SURFACE", "#1c1c1e")
    dots = PrivacyDots(topbar, app, theme=th, bg=bg)
    dots.pack(side="left", padx=(8, 4), pady=6)
    topbar.privacy_dots = dots
    app.privacy_dots = dots
    return dots


def signal_probe(app, kind="scan", duration_s=3.0):
    dots = getattr(app, "privacy_dots", None)
    if dots is not None:
        try:
            dots.pulse(kind, duration_s)
        except Exception:
            pass
