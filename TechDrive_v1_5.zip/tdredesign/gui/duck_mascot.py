#!/usr/bin/env python3
"""
duck_assistant_demo.py — standalone proactive duck assistant mockup

An original Canvas-drawn duck (not traced from any stock art) that sits
in the corner of the screen and proactively pops a speech bubble with a
tip, the way gui/duck_assistant.py could evolve toward being "eyes-on"
instead of purely click-to-open.

Run directly: python3 duck_assistant_demo.py

Everything here is self-contained (stdlib only) so it's easy to drop
into TechDrive's own gui/ package and swap the fake `sample_system()`
for real psutil calls / health_center.py scores later.
"""
import math
import ctypes
import os
import random
import re
import shutil
import subprocess
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from shared import database as db

# ---------------------------------------------------------------------------
# Clippy Duck Palette & Style (Clean, simple rubber duck desktop assistant)
# ---------------------------------------------------------------------------
BG_TRANSPARENT = "#010203"  # Windows chroma key

# Bright, cheerful rubber duck tones
DUCK_YELLOW = "#ffcc00"
DUCK_SHADOW = "#e59e00"
DUCK_HIGHLIGHT = "#ffe875"
BEAK_ORANGE = "#ff6600"
BEAK_DARK = "#d03a00"
CHEEK_BLUSH = "#ffb0b0"
OUTLINE = "#22201d"

# Eyes & Expressions (Iconic Clippy styling)
EYE_WHITE = "#ffffff"
EYE_PUPIL = "#111111"
EYEBROW_COLOR = "#2b1c05"

# Classic Office Assistant pale-yellow note balloon
BUBBLE_BG = "#ffffdb"
BUBBLE_BORDER = "#8c877a"
BUBBLE_SHADOW = "#a39f93"
TEXT_COLOR = "#1a1a18"
IDLE_DELAY_MS = 120000
FEATURE_ALERT_COOLDOWN = 180
DUCK_SIZE = 95
NOTES_PATH = Path(os.environ.get("APPDATA") or Path.home()) / "TechDriveDuck" / "quick_notes.txt"
DUCK_ANIMATIONS = (
    ("welcome wave", "Hi!", "float", "#fff5bd"),
    ("star cheer", "★", "confetti", "#ffd34d"),
    ("thinking", "?", "orbit", "#ffffff"),
    ("sleepy", "z", "float", "#d9f3f2"),
    ("giggle", "ha", "shake", "#ffb0b0"),
    ("idea pop", "!", "burst", "#ffe875"),
    ("sweetheart", "♥", "pulse", "#ff8eaa"),
    ("dizzy stars", "✦", "orbit", "#fff5bd"),
    ("sneeze", "...", "burst", "#d9f3f2"),
    ("dance beat", "♪", "wave", "#ffcc00"),
    ("sparkle shower", "✧", "confetti", "#ffffff"),
    ("curious peek", "?", "slide", "#fff5bd"),
    ("task complete", "✓", "pulse", "#83c98b"),
    ("magic trick", "✧", "orbit", "#e4b8ff"),
    ("rainy day", ".", "rain", "#8cc9e8"),
    ("bubble float", "o", "rise", "#b9edf0"),
    ("focus pulse", "+", "pulse", "#9bd3aa"),
    ("salute", ">", "slide", "#ffe875"),
    ("zoom in", "O", "wave", "#d9f3f2"),
    ("grand finale", "★", "confetti", "#ff9a62"),
)

TIPS = [
    ("It looks like you're running low on disk space.\nWould you like help cleaning temporary files?", ["Clean up disk", "Ignore for now"]),
    ("It looks like your CPU is working extra hard today!\nShall I monitor runaway processes?", ["Inspect CPU", "I like the heat"]),
    ("It looks like you haven't taken a system snapshot recently.\nWould you like to save one?", ["Create snapshot", "Later"]),
    ("It looks like your RAM is filling up nicely!\nWant me to free up cached memory?", ["Optimize RAM", "Let it ride"]),
    ("Everything looks shipshape and ducky! 🦆\nNeed any tips on computer health?", ["Give me a tip", "Thanks Duck"]),
    ("Quack! Just checking in. Remember to stretch and stay hydrated while coding!", ["Thanks buddy", "Dismiss"]),
]

TIPS_OF_DAY = (
    ("Restore points and backups", "A restore point can help undo some Windows changes, but it does not back up your personal files."),
    ("Review before deleting", "Check the name and location of files before removing them; avoid deleting Windows or application folders manually."),
    ("Benchmark consistently", "For a useful performance comparison, close heavy apps and run one benchmark at a time."),
    ("SSD maintenance", "Windows normally handles SSD optimization with TRIM. Avoid third-party defragmentation tools unless you know why they are needed."),
    ("Check the destination", "Before creating a backup or snapshot, confirm the destination drive has enough free space."),
    ("High CPU use", "A short CPU spike is normal. If it stays high, sort processes by CPU and investigate apps you recognize."),
    ("Memory pressure", "Windows uses spare RAM for caching. Check whether apps are actually slowing down before trying to free memory."),
    ("Drive health", "A clean file-system scan does not guarantee a drive is healthy. Keep a separate backup of important files."),
    ("Before an update", "Save open work and make sure the device has reliable power before a large update or restart."),
    ("Disk scans", "TechDrive's scan map represents files checked by the app, not physical disk sectors."),
    ("Safe troubleshooting", "Change one setting at a time and note the original value so you can undo a change if needed."),
    ("Restarting", "A restart can clear temporary software issues, but it is not a substitute for backing up files."),
)


class Duck(tk.Canvas):
    """An iconic, simplified Clippy-style duck assistant with big expressive
    googly eyes, animated inquisitive eyebrows, and bouncy animations."""

    def __init__(self, master, size=140, on_click=None, **kw):
        super().__init__(master, width=size, height=size, bg=BG_TRANSPARENT,
                         highlightthickness=0, **kw)
        self.size = size
        self.on_click = on_click
        self._bob = 0.0
        self._bob_dir = 1
        self._eye_h = 16
        self._face = {
            "eye_h": 16.0,
            "left_brow": -3.0,
            "right_brow": -3.0,
            "pupil_x": 0.0,
            "pupil_y": 0.0,
        }
        self._pupil_offset = (0, 0)
        self._face_generation = 0
        self._prop_generation = 0
        self._prop = None
        self._prop_progress = 0.0
        self._tap_times = []
        self._effect_generation = 0
        self._tornado_phase = 0.0
        self._tornado_frame = None
        self._wave = None
        self._animation_index = -1
        self._animation_name = None
        self._animation_frame = 0
        self._animation_generation = 0
        self.bind("<Button-1>", self._handle_click, add="+")
        self._dirty = True
        self._t0 = time.monotonic()
        self._trap_shake = 0.0
        self._render_loop()
        self._schedule_blink()
        self._schedule_look_around()

    def _handle_click(self, event):
        if getattr(self.master, "_trapped", False):
            self.master._set_trapped(False)
            self.master._record_activity()
            return
        self.master._record_activity()
        self._animate_expression("happy")
        self.play_next_animation()
        self._tap_times = [stamp for stamp in self._tap_times if time.monotonic() - stamp < 0.8]
        self._tap_times.append(time.monotonic())
        if len(self._tap_times) >= 3:
            self._tap_times.clear()
            self._start_tornado()
        else:
            self._start_sound_waves(event.x, event.y)
        if self.on_click:
            self.on_click()

    def play_next_animation(self):
        self._animation_index = (self._animation_index + 1) % len(DUCK_ANIMATIONS)
        self.play_animation(DUCK_ANIMATIONS[self._animation_index][0])

    def play_animation(self, name):
        if name not in {animation[0] for animation in DUCK_ANIMATIONS}:
            return
        self._animation_name = name
        self._animation_frame = 0
        self._animation_generation += 1
        self._tick_animation(self._animation_generation)

    def _tick_animation(self, generation):
        if not self.winfo_exists() or generation != self._animation_generation:
            return
        self.draw()
        if self._animation_frame < 28:
            self._animation_frame += 1
            self.after(45, lambda: self._tick_animation(generation))
        else:
            self._animation_name = None
            self.draw()

    def _draw_animation(self, cx, cy):
        if self._animation_name is None:
            return
        name, symbol, mode, color = next(
            animation for animation in DUCK_ANIMATIONS if animation[0] == self._animation_name
        )
        frame = self._animation_frame
        progress = frame / 28
        phase = progress * math.tau
        top = cy - 52
        if mode == "float":
            x = cx + math.sin(phase * 2) * 18
            y = top - progress * 34
            self.create_text(x, y, text=symbol, fill=color, font=("Segoe UI", 13, "bold"))
        elif mode == "orbit":
            for index in range(3):
                angle = phase + index * math.tau / 3
                x = cx + math.cos(angle) * 34
                y = cy - 18 + math.sin(angle) * 25
                self.create_text(x, y, text=symbol, fill=color,
                                 font=("Segoe UI Symbol", 12, "bold"))
        elif mode == "shake":
            x = cx + math.sin(phase * 5) * 12
            y = top - 8
            self.create_text(x, y, text=symbol, fill=color, font=("Segoe UI", 12, "bold"))
        elif mode == "burst":
            radius = 12 + progress * 27
            for index in range(8):
                angle = phase + index * math.tau / 8
                x1 = cx + math.cos(angle) * radius * 0.45
                y1 = cy - 22 + math.sin(angle) * radius * 0.45
                x2 = cx + math.cos(angle) * radius
                y2 = cy - 22 + math.sin(angle) * radius
                self.create_line(x1, y1, x2, y2, fill=color, width=2)
            self.create_text(cx, top - 5, text=symbol, fill=color,
                             font=("Segoe UI", 12, "bold"))
        elif mode == "pulse":
            radius = 13 + abs(math.sin(phase * 2)) * 15
            self.create_oval(cx - radius, cy - 34 - radius, cx + radius, cy - 34 + radius,
                             outline=color, width=2)
            self.create_text(cx, cy - 34, text=symbol, fill=color,
                             font=("Segoe UI Symbol", 12, "bold"))
        elif mode == "confetti":
            for index in range(8):
                x = cx + math.sin(index * 2.4 + phase) * (18 + index * 3)
                y = top + ((frame * (index + 2) + index * 13) % 76)
                self.create_text(x, y, text=symbol, fill=color,
                                 font=("Segoe UI Symbol", 10, "bold"))
        elif mode == "rain":
            for index in range(7):
                x = cx - 30 + index * 10
                y = top + ((frame * 4 + index * 11) % 55)
                self.create_line(x, y, x - 3, y + 7, fill=color, width=2)
        elif mode == "rise":
            for index in range(4):
                x = cx - 22 + index * 15 + math.sin(phase + index) * 4
                y = cy + 22 - ((frame * 3 + index * 12) % 72)
                radius = 3 + index % 3
                self.create_oval(x - radius, y - radius, x + radius, y + radius,
                                 outline=color, width=2)
        elif mode == "slide":
            x = cx - 34 + progress * 68
            y = top - 5 + math.sin(phase) * 6
            self.create_text(x, y, text=symbol, fill=color,
                             font=("Segoe UI Symbol", 13, "bold"))
        elif mode == "wave":
            radius = 8 + progress * 30
            self.create_arc(cx - radius, cy - 30 - radius, cx + radius, cy - 30 + radius,
                            start=25, extent=130, style="arc", outline=color, width=2)
            self.create_arc(cx - radius, cy - 30 - radius, cx + radius, cy - 30 + radius,
                            start=205, extent=130, style="arc", outline=color, width=2)

    # -- click effects: state only; the render loop paints them ---------
    def _start_sound_waves(self, x, y):
        self._effect_generation += 1
        self._wave = [x, y, 0]
        self._step_sound_waves(self._effect_generation)

    def _step_sound_waves(self, generation):
        if not self.winfo_exists() or generation != self._effect_generation or not self._wave:
            return
        self._wave[2] += 1
        if self._wave[2] < 16:
            self.after(25, lambda: self._step_sound_waves(generation))
        else:
            self._wave = None

    def _paint_sound_waves(self):
        if not self._wave:
            return
        x, y, frame = self._wave
        for wave in range(3):
            radius = frame * 2.3 + wave * 7
            if 0 < radius <= 35:
                for start in (35, 215):
                    self.create_arc(x - radius, y - radius, x + radius, y + radius,
                                    start=start, extent=110, style="arc",
                                    outline="#fff5bd", width=2)

    def _start_tornado(self):
        self._effect_generation += 1
        generation = self._effect_generation
        self._wave = None
        self._tornado_phase = 0.0
        self._tornado_frame = 0
        self._animate_expression("confused")
        self._step_tornado(generation)

    def _step_tornado(self, generation):
        if not self.winfo_exists() or generation != self._effect_generation:
            return
        self._tornado_phase += 0.45
        self._tornado_frame += 1
        if self._tornado_frame <= 24:
            self.after(35, lambda: self._step_tornado(generation))
        else:
            self._tornado_frame = None
            self._animate_expression("curious")

    def _paint_tornado(self, cx, cy):
        frame = getattr(self, "_tornado_frame", None)
        if not frame:
            return
        for band in range(3):
            width = 15 + band * 7
            y = cy - 30 + band * 17
            sway = math.sin(self._tornado_phase + band * 1.7) * (8 + band * 2)
            self.create_arc(cx - width + sway, y - 7, cx + width + sway, y + 7,
                            start=15 + frame * 17, extent=300, style="arc",
                            outline="#d9f3f2", width=2)

    def _reset_expression(self):
        self._animate_expression("curious")

    def morph_for_tip(self, expression, prop):
        self._animate_expression(expression)
        self._prop_generation += 1
        generation = self._prop_generation
        self._prop = prop
        self._animate_prop(generation, 0.0, 1.0, 0)

    def _animate_expression(self, expression):
        keyframes = {
            "curious": [
                (5, {"eye_h": 18, "left_brow": -8, "right_brow": -3,
                     "pupil_x": 1, "pupil_y": -1}),
                (8, {"eye_h": 19, "left_brow": -10, "right_brow": -5,
                     "pupil_x": 1, "pupil_y": -1}),
            ],
            "confused": [
                (6, {"eye_h": 16, "left_brow": -5, "right_brow": 5,
                     "pupil_x": -1, "pupil_y": 0}),
                (8, {"eye_h": 13, "left_brow": -3, "right_brow": 7,
                     "pupil_x": -1, "pupil_y": 0}),
            ],
            "happy": [
                (6, {"eye_h": 13, "left_brow": -1, "right_brow": -1,
                     "pupil_x": 0, "pupil_y": 0}),
                (8, {"eye_h": 10, "left_brow": 1, "right_brow": 1,
                     "pupil_x": 0, "pupil_y": 0}),
            ],
            "frustrated": [
                (6, {"eye_h": 14, "left_brow": 4, "right_brow": -4,
                     "pupil_x": 0, "pupil_y": 1}),
                (8, {"eye_h": 12, "left_brow": 7, "right_brow": -7,
                     "pupil_x": 0, "pupil_y": 1}),
            ],
              "bored": [
                 (8, {"eye_h": 11, "left_brow": 1, "right_brow": 1,
                     "pupil_x": 2, "pupil_y": 2}),
              ],
            "neutral": [
                (8, {"eye_h": 16, "left_brow": -3, "right_brow": -3,
                     "pupil_x": 0, "pupil_y": 0}),
            ],
        }
        self._face_generation += 1
        self._run_face_keyframe(self._face_generation, keyframes.get(expression, keyframes["curious"]), 0)

    def _run_face_keyframe(self, generation, keyframes, index):
        if not self.winfo_exists() or generation != self._face_generation:
            return
        if index >= len(keyframes):
            return

        duration, target = keyframes[index]
        start = dict(self._face)

        def frame(step=0):
            if not self.winfo_exists() or generation != self._face_generation:
                return
            progress = min(1.0, step / duration)
            eased = progress * progress * (3 - 2 * progress)
            for name, end_value in target.items():
                self._face[name] = start[name] + (end_value - start[name]) * eased
            self.draw()
            if progress < 1.0:
                self.after(20, lambda: frame(step + 1))
            else:
                self.after(20, lambda: self._run_face_keyframe(generation, keyframes, index + 1))

        frame()

    def _animate_prop(self, generation, start, end, step):
        if not self.winfo_exists() or generation != self._prop_generation:
            return
        progress = min(1.0, step / 15)
        eased = progress * progress * (3 - 2 * progress)
        self._prop_progress = start + (end - start) * eased
        self.draw()
        if progress < 1.0:
            self.after(20, lambda: self._animate_prop(generation, start, end, step + 1))
        elif end == 1.0:
            self.after(1800, lambda: self._animate_prop(generation, 1.0, 0.0, 0))
        else:
            self._prop = None
            self._animate_expression("curious")

    # -- drawing --------------------------------------------------------
    def draw(self):
        """Request a repaint. All timers call this; only the single render
        loop below actually touches the canvas, so frames never fight."""
        self._dirty = True

    def _render(self):
        self.delete("all")
        trapped = getattr(self.master, "_trapped", False)
        self.configure(bg="#7896a3" if trapped else BG_TRANSPARENT)
        s = self.size
        cx, cy = s * 0.48 + self._trap_shake, s * 0.54 + self._bob

        # 1. Soft drop shadow beneath
        self.create_oval(cx - 34, cy + 34, cx + 36, cy + 44,
                          fill="#181818", outline="")

        # 2. Duck Tail
        tail_pts = [
            cx + 24, cy + 6,
            cx + 48, cy - 4,
            cx + 38, cy + 18,
            cx + 26, cy + 24
        ]
        self.create_polygon(tail_pts, fill=DUCK_YELLOW, outline=OUTLINE, width=2.2, smooth=True)

        # 3. Duck Body (Plump round rubber duck)
        self.create_oval(cx - 34, cy - 6, cx + 36, cy + 34,
                          fill=DUCK_YELLOW, outline=OUTLINE, width=2.5)
        # Gentle body shadow
        self.create_arc(cx - 34, cy - 6, cx + 36, cy + 34,
                        start=215, extent=110, fill=DUCK_SHADOW, outline="")

        # 4. Wing (Simple clean cartoon curve)
        self.create_oval(cx - 4, cy + 4, cx + 24, cy + 24,
                          fill=DUCK_SHADOW, outline=OUTLINE, width=2)
        self.create_arc(cx - 6, cy + 3, cx + 22, cy + 22,
                        start=60, extent=180, fill=DUCK_YELLOW, outline="")

        # 5. Duck Head (Clean round circle)
        hx, hy = cx - 12, cy - 22
        self.create_oval(hx - 25, hy - 25, hx + 25, hy + 25,
                          fill=DUCK_YELLOW, outline=OUTLINE, width=2.5)

        # Simple glossy head shine
        self.create_oval(hx - 18, hy - 20, hx - 6, hy - 11,
                          fill=DUCK_HIGHLIGHT, outline="")

        # 6. Rosy Cheeks
        self.create_oval(hx - 10, hy + 7, hx + 4, hy + 17,
                          fill=CHEEK_BLUSH, outline="")

        # 7. Orange Duck Beak (Simple cheerful smile)
        beak_pts = [
            hx - 14, hy - 2,
            hx - 36, hy + 6,
            hx - 30, hy + 15,
            hx - 8, hy + 12
        ]
        self.create_polygon(beak_pts, fill=BEAK_ORANGE, outline=OUTLINE, width=2, smooth=True)
        self.create_line(hx - 32, hy + 7, hx - 10, hy + 5, fill=BEAK_DARK, width=1.5)

        # 8. Clippy Googly Eyes (Expressive, clean, iconic)
        eh = max(2, self._face["eye_h"])
        px = self._pupil_offset[0] + self._face["pupil_x"]
        py = self._pupil_offset[1] + self._face["pupil_y"]

        # Left Eye (Back eye)
        lx, ly = hx - 12, hy - 7
        self.create_oval(lx - 7, ly - eh * 0.45, lx + 7, ly + eh * 0.45,
                          fill=EYE_WHITE, outline=OUTLINE, width=2)
        if eh > 4:
            self.create_oval(lx - 3 + px, ly - 3 + py, lx + 3 + px, ly + 3 + py,
                              fill=EYE_PUPIL, outline="")
            self.create_oval(lx - 2 + px, ly - 3 + py, lx + px, ly - 1 + py,
                              fill=EYE_WHITE, outline="")

        # Right Eye (Foreground - Iconic large Clippy eye)
        rx, ry = hx + 4, hy - 7
        self.create_oval(rx - 9, ry - eh * 0.55, rx + 9, ry + eh * 0.55,
                          fill=EYE_WHITE, outline=OUTLINE, width=2)
        if eh > 4:
            self.create_oval(rx - 4 + px, ry - 4 + py, rx + 4 + px, ry + 4 + py,
                              fill=EYE_PUPIL, outline="")
            self.create_oval(rx - 3 + px, ry - 3.5 + py, rx - 1 + px, ry - 1.5 + py,
                              fill=EYE_WHITE, outline="")

        # 9. Iconic Clippy Curved Eyebrows
        brow_y = hy - 17
        self.create_line(
            lx - 7, brow_y + 1,
            lx + 7, brow_y + 1 + self._face["left_brow"],
            fill=EYEBROW_COLOR, width=3, capstyle="round"
        )
        self.create_line(
            rx - 7, brow_y - 2,
            rx + 9, brow_y - 2 + self._face["right_brow"],
            fill=EYEBROW_COLOR, width=3.5, capstyle="round"
        )

        self._draw_prop(cx, cy)
        self._draw_animation(cx, cy)
        self._paint_sound_waves()
        self._paint_tornado(cx, cy)
        self.scale("all", cx, cy, self.size / 140, self.size / 140)
        if trapped:
            self.create_rectangle(2, 2, s - 2, s - 2, outline="#26343d", width=5)
            self.create_rectangle(6, 6, s - 6, s - 6, outline="#d8edf3", width=2)
            self.create_polygon(
                s - 19, 8, s - 9, 8, s - 9, s - 10, s - 19, s - 24,
                fill="#e2f8ff", outline="", stipple="gray50"
            )
            self.create_text(s / 2, 10, text="LET ME OUT!", fill="#17303b",
                             font=("Segoe UI", 6, "bold"))

    def _draw_prop(self, cx, cy):
        if not self._prop or self._prop_progress <= 0:
            return
        scale = self._prop_progress
        x, y = cx, cy - 3
        if self._prop == "magnifier":
            radius = 15 * scale
            self.create_oval(x - radius, y - 19 * scale, x + radius, y + 11 * scale,
                             fill="#dff4f5", outline="#33302b", width=3)
            self.create_line(x + 10 * scale, y + 8 * scale,
                             x + 24 * scale, y + 23 * scale,
                             fill="#8c5b34", width=max(2, 6 * scale), capstyle="round")
            self.create_oval(x - 8 * scale, y - 13 * scale, x - 2 * scale, y - 7 * scale,
                             fill="#ffffff", outline="")
        elif self._prop == "notepad":
            half_w, half_h = 21 * scale, 27 * scale
            self.create_rectangle(x - half_w, y - half_h, x + half_w, y + half_h,
                                  fill="#fff5bd", outline="#33302b", width=2)
            for line in range(3):
                line_y = y - 7 * scale + line * 9 * scale
                self.create_line(x - 12 * scale, line_y, x + 12 * scale, line_y,
                                 fill="#79a9bc", width=max(1, 2 * scale))
            for ring in (-10, 0, 10):
                self.create_oval(x + ring * scale - 2 * scale, y - 24 * scale,
                                 x + ring * scale + 2 * scale, y - 20 * scale,
                                 fill="#e59e00", outline="")
        elif self._prop == "magnet":
            self.create_arc(x - 23 * scale, y - 26 * scale, x + 23 * scale, y + 25 * scale,
                            start=180, extent=180, style="arc", outline="#d94343",
                            width=max(3, 11 * scale))
            self.create_line(x - 23 * scale, y, x - 23 * scale, y + 22 * scale,
                             fill="#d94343", width=max(3, 11 * scale))
            self.create_line(x + 23 * scale, y, x + 23 * scale, y + 22 * scale,
                             fill="#3976bd", width=max(3, 11 * scale))
            self.create_line(x - 23 * scale, y + 22 * scale, x - 15 * scale, y + 22 * scale,
                             fill="#d7d5cf", width=max(3, 11 * scale))
            self.create_line(x + 15 * scale, y + 22 * scale, x + 23 * scale, y + 22 * scale,
                             fill="#d7d5cf", width=max(3, 11 * scale))

    # -- idle animations ------------------------------------------------
    def _render_loop(self):
        """Single ~30 FPS loop; throttle repainting while the mascot is off."""
        if not self.winfo_exists():
            return
        # The enabled flag belongs to DuckAssistantWindow (self.master),
        # not the Canvas widget itself. Read it from the owning window.
        if not getattr(self.master, "_enabled", True):
            self.after(500, self._render_loop)
            return
        t = time.monotonic() - self._t0
        self._bob = math.sin(t * 2.6) * 3.0
        trapped = getattr(self.master, "_trapped", False)
        self._trap_shake = math.sin(t * 18) * 1.5 if trapped and int(t * 2) % 3 == 0 else 0
        self._render()
        self.after(33, self._render_loop)

    def _schedule_blink(self):
        if not self.winfo_exists():
            return
        self.after(random.randint(2200, 4800), self._blink)

    def _blink(self):
        if not self.winfo_exists():
            return
        self._blink_eye_h = self._face["eye_h"]
        self._face["eye_h"] = 2
        self.draw()
        self.after(100, self._unblink)

    def _unblink(self):
        if not self.winfo_exists():
            return
        self._face["eye_h"] = getattr(self, "_blink_eye_h", 16)
        self.draw()
        self._schedule_blink()

    def _schedule_look_around(self):
        if not self.winfo_exists():
            return
        self.after(random.randint(3000, 6000), self._look_around)

    def _look_around(self):
        if not self.winfo_exists():
            return
        self._pupil_offset = (random.choice([-2, 0, 2]), random.choice([-2, 0, 1]))
        self.draw()
        self.after(1400, self._reset_look)

    def _reset_look(self):
        if not self.winfo_exists():
            return
        self._pupil_offset = (0, 0)
        self.draw()
        self._schedule_look_around()


class SpeechBubble(tk.Toplevel):
    """Classic Clippy assistant yellow parchment speech bubble with tail and buttons."""

    def __init__(self, master, anchor_widget, text, actions=None, on_action=None, help_text=None):
        super().__init__(master)
        self.anchor_widget = anchor_widget
        self.on_action = on_action
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg=BG_TRANSPARENT)
        try:
            self.wm_attributes("-transparentcolor", BG_TRANSPARENT)
        except Exception:
            pass

        # Shadow container for classic 3D Office note look
        outer = tk.Frame(self, bg=BG_TRANSPARENT)
        outer.pack(padx=6, pady=6)

        # Shadow layer
        shadow_box = tk.Frame(outer, bg="#8e8979", padx=1, pady=1)
        shadow_box.pack(padx=(2, 0), pady=(2, 0))

        # Main parchment card
        card = tk.Frame(shadow_box, bg=BUBBLE_BG, highlightbackground=BUBBLE_BORDER,
                        highlightthickness=1, padx=14, pady=11)
        card.pack()

        # Header banner with mini assistant icon & close glyph
        header = tk.Frame(card, bg=BUBBLE_BG)
        header.pack(fill="x", pady=(0, 6))

        title_box = tk.Frame(header, bg=BUBBLE_BG)
        title_box.pack(side="left")
        tk.Label(title_box, text="🦆", font=("Segoe UI", 9),
                 bg=BUBBLE_BG, fg="#444444").pack(side="left", padx=(0, 4))
        tk.Label(title_box, text="Duck Assistant", font=("Segoe UI", 9, "bold"),
                 bg=BUBBLE_BG, fg="#444444").pack(side="left")

        close_x = tk.Label(header, text="✕", font=("Segoe UI", 9, "bold"),
                           bg=BUBBLE_BG, fg="#888478", cursor="hand2")
        close_x.pack(side="right")
        close_x.bind("<Button-1>", lambda e: self.close())
        close_x.bind("<Enter>", lambda e: close_x.config(fg="#222222"))
        close_x.bind("<Leave>", lambda e: close_x.config(fg="#888478"))

        # Message text
        wraplength = max(160, min(300, self.winfo_screenwidth() - 40))
        tk.Label(card, text=text, font=("Segoe UI", 9), bg=BUBBLE_BG, fg=TEXT_COLOR,
                 justify="left", wraplength=wraplength).pack(anchor="w", pady=(0, 8))
        if help_text:
            tk.Label(card, text=help_text, font=("Segoe UI", 8), bg=BUBBLE_BG,
                     fg="#625d50", justify="left", wraplength=wraplength).pack(
                         anchor="w", pady=(0, 8))

        # Clippy style action options
        if actions:
            btn_frame = tk.Frame(card, bg=BUBBLE_BG)
            btn_frame.pack(fill="x")
            for act in actions:
                btn = tk.Button(
                    btn_frame, text=f"•  {act}", font=("Segoe UI", 9),
                    bg="#fcf8e3", activebackground="#f4ebb8",
                    fg="#1a1a1a", relief="groove", bd=1,
                    anchor="w", cursor="hand2", padx=8, pady=3,
                    command=lambda a=act: self._handle_click_action(a)
                )
                btn.pack(fill="x", pady=2)

        self.update_idletasks()
        self.reposition()
        self._dismiss_job = self.after(10000, self.close)
        # Clicking the bubble's text or background clears it right away, so it
        # can never sit on top of the app's controls. Real action buttons are
        # left alone so they keep working.
        self.bind("<Button-1>", self._dismiss_on_click, add="+")

    def _dismiss_on_click(self, event):
        if isinstance(event.widget, (tk.Label, tk.Frame, tk.Toplevel)) or event.widget is self:
            self.close()

    def reposition(self):
        ax = self.anchor_widget.winfo_rootx()
        ay = self.anchor_widget.winfo_rooty()
        aw = max(1, self.anchor_widget.winfo_width())
        ah = max(1, self.anchor_widget.winfo_height())
        bw = self.winfo_reqwidth()
        bh = self.winfo_reqheight()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        candidates = [
            (ax + aw - bw, ay - bh - 8),
            (ax + aw - bw, ay + ah + 8),
            (ax - bw - 8, ay + ah - bh),
            (ax + aw + 8, ay + ah - bh),
        ]

        def placement_cost(position):
            x, y = position
            overflow = max(0, 8 - x) + max(0, x + bw - sw + 8)
            overflow += max(0, 8 - y) + max(0, y + bh - sh + 8)
            overlaps_duck = not (x + bw <= ax or x >= ax + aw or
                                 y + bh <= ay or y >= ay + ah)
            return overflow * 100 + (100000 if overlaps_duck else 0)

        x, y = min(candidates, key=placement_cost)
        x = min(max(8, x), max(8, sw - bw - 8))
        y = min(max(8, y), max(8, sh - bh - 8))
        self.geometry(f"+{x}+{y}")

    def _handle_click_action(self, action_name):
        if self.on_action:
            self.on_action(action_name)
        self.close()

    def close(self):
        if self._dismiss_job:
            self.after_cancel(self._dismiss_job)
            self._dismiss_job = None
        self.destroy()


class QuickNotesWindow(tk.Toplevel):
    """Small persistent scratchpad for notes and a simple to-do list."""

    def __init__(self, master):
        super().__init__(master)
        self.title("Duck Quick Notes")
        self.transient(master)
        self.configure(bg="#f5f1df")
        self.minsize(360, 260)

        toolbar = tk.Frame(self, bg="#f5f1df", padx=12, pady=10)
        toolbar.pack(fill="x")
        tk.Label(toolbar, text="Quick Notes / To-do", font=("Segoe UI", 12, "bold"),
                 bg="#f5f1df", fg=TEXT_COLOR).pack(side="left")
        tk.Button(toolbar, text="Save", command=self._save, padx=12).pack(side="right")

        editor = tk.Frame(self, bg="#f5f1df", padx=12)
        editor.pack(fill="both", expand=True)
        scrollbar = tk.Scrollbar(editor)
        scrollbar.pack(side="right", fill="y")
        self.text = tk.Text(editor, wrap="word", undo=True, font=("Segoe UI", 10),
                            padx=8, pady=8, yscrollcommand=scrollbar.set)
        self.text.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.text.yview)

        footer = tk.Frame(self, bg="#f5f1df", padx=12, pady=8)
        footer.pack(fill="x")
        self.status = tk.Label(footer, text="Saved notes stay on this PC.",
                               bg="#f5f1df", fg="#625d50", anchor="w")
        self.status.pack(side="left", fill="x", expand=True)
        tk.Button(footer, text="Close", command=self._close).pack(side="right")

        try:
            saved_text = NOTES_PATH.read_text(encoding="utf-8")
        except FileNotFoundError:
            saved_text = ""
        except OSError:
            saved_text = ""
            self.status.config(text="Couldn't read the saved note; you can still create a new one.")
        self.text.insert("1.0", saved_text)
        self.text.edit_modified(False)
        self.text.bind("<<Modified>>", self._mark_unsaved)
        self.bind("<Control-s>", self._save_shortcut)
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.geometry("520x380")
        self.text.focus_set()

    def _mark_unsaved(self, event=None):
        if self.text.edit_modified():
            self.status.config(text="Unsaved changes")
            self.text.edit_modified(False)

    def _save(self):
        try:
            NOTES_PATH.parent.mkdir(parents=True, exist_ok=True)
            NOTES_PATH.write_text(self.text.get("1.0", "end-1c"), encoding="utf-8")
        except OSError as error:
            self.status.config(text=f"Couldn't save notes: {error}")
            return False
        self.text.edit_modified(False)
        self.status.config(text="Notes saved on this PC.")
        return True

    def _save_shortcut(self, event=None):
        self._save()
        return "break"

    def _close(self):
        if self.text.edit_modified():
            should_save = messagebox.askyesnocancel(
                "Unsaved notes", "Save your changes before closing?", parent=self
            )
            if should_save is None:
                return
            if should_save and not self._save():
                return
        self.destroy()


class DuckAssistantWindow(tk.Toplevel):
    """Always-on-top draggable Clippy Duck assistant."""

    def __init__(self, master):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg=BG_TRANSPARENT)
        try:
            self.wm_attributes("-transparentcolor", BG_TRANSPARENT)
        except Exception:
            pass

        self._active_bubble = None
        self._trapped = False
        self._enabled = True
        self._last_activity = time.monotonic()
        self._idle_timer_id = None
        self._idle_announced = False
        self._feature_last_shown = {}
        self._proactive_paused = False
        self._focus_remaining = 0
        self._focus_job = None
        self._intro_job = None
        self._intro_shown = False
        self._daily_tip_job = None
        self._bubble_reason = None
        self._context_last_shown = {}
        self._last_context_hint = float("-inf")
        self._notes_window = None
        self._clipboard_cleaned = None
        self.duck = Duck(self, size=DUCK_SIZE, on_click=self._quack)
        self.duck.pack()

        # Dragging support
        self._drag_x = 0
        self._drag_y = 0
        self.duck.bind("<ButtonPress-1>", self._start_drag, add="+")
        self.duck.bind("<B1-Motion>", self._on_drag)

        # Right click context menu
        self._menu = tk.Menu(self, tearoff=0)
        self._menu.add_command(label="🦆 Quack / Ask Duck", command=self._quack)
        help_menu = tk.Menu(self._menu, tearoff=0)
        help_menu.add_command(label="Writing a message", command=lambda: self._show_help_topic("writing"))
        help_menu.add_command(label="Computer running slowly", command=lambda: self._show_help_topic("slow"))
        help_menu.add_command(label="Find a downloaded file", command=lambda: self._show_help_topic("files"))
        self._menu.add_cascade(label="❔ Help Topics", menu=help_menu)
        self._menu.add_command(label="✍ Check Copied Text", command=self._check_clipboard_text)
        self._menu.add_command(label="📊 System Health", command=self._show_health)
        focus_menu = tk.Menu(self._menu, tearoff=0)
        for minutes in (15, 25, 45):
            focus_menu.add_command(
                label=f"Start {minutes}-Minute Focus",
                command=lambda duration=minutes: self._start_focus(duration),
            )
        focus_menu.add_separator()
        focus_menu.add_command(label="Stop Focus Sprint", command=self._stop_focus, state="disabled")
        self._focus_stop_index = focus_menu.index("end")
        self._menu.add_cascade(label="⏱ Focus Sprint", menu=focus_menu)
        self._menu.add_command(label="📝 Quick Notes / To-do", command=self._open_notes)
        self._menu.add_command(
            label="💡 Tip of the Day",
            command=lambda: self._show_tip_of_day(automatic=False),
        )
        self._menu.add_command(label="📂 Open Downloads", command=self._open_downloads)
        self._menu.add_command(label="🎞 Play Next Animation", command=self.duck.play_next_animation)
        self._menu.add_command(label="🧹 Review Storage", command=lambda: self._handle_action("clean up disk"))
        self._menu.add_command(label="📌 Trap Duck", command=lambda: self._set_trapped(not self._trapped))
        self._trapped_menu_index = self._menu.index("end")
        self._menu.add_command(label="🔔 Pause Proactive Alerts", command=self._toggle_proactive)
        self._proactive_menu_index = self._menu.index("end")
        self._menu.add_separator()
        self._menu.add_command(label="❌ Hide Duck", command=self._disable_from_menu)
        self.duck.bind("<Button-3>", lambda e: self._menu.tk_popup(e.x_root, e.y_root))

        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        # Start beside TechDrive's Ribbon, not at the desktop's lower corner.
        self.geometry(f"{DUCK_SIZE}x{DUCK_SIZE}+{max(0, sw - DUCK_SIZE - 30)}+{max(0, sh - DUCK_SIZE - 90)}")
        self.after(700, self._position_near_ribbon)
        self.bind_all("<KeyPress>", self._record_activity, add="+")
        self.bind_all("<ButtonPress>", self._record_activity, add="+")

        self._intro_job = self.after(1000, self._intro)
        self._schedule_proactive_tip()
        self._schedule_idle_timer()
        self._schedule_daily_tip()

    def _position_near_ribbon(self):
        """Place the mascot just below the Ribbon in the main TechDrive window."""
        if not self.winfo_exists() or not self._enabled:
            return
        try:
            app = self.master
            x = app.winfo_rootx() + max(0, app.winfo_width() - DUCK_SIZE - 14)
            y = app.winfo_rooty() + app.topbar.winfo_height() + app.ribbon.winfo_height() + 6
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            x = min(max(0, x), max(0, sw - DUCK_SIZE))
            y = min(max(0, y), max(0, sh - DUCK_SIZE))
            self.geometry(f"{DUCK_SIZE}x{DUCK_SIZE}+{x}+{y}")
        except (AttributeError, tk.TclError):
            pass

    def _disable_from_menu(self):
        callback = getattr(self.master, "set_duck_mascot_enabled", None)
        if callback:
            callback(False)
        else:
            self.hide()

    def show(self):
        self._enabled = True
        self.deiconify()
        self.lift()
        self._position_near_ribbon()
        self._last_activity = time.monotonic()
        self._schedule_idle_timer()
        self._schedule_proactive_tip()
        if not self._intro_shown and self._intro_job is None:
            self._intro_job = self.after(700, self._intro)
        self._schedule_daily_tip()

    def hide(self):
        self._enabled = False
        if self._idle_timer_id is not None:
            try:
                self.after_cancel(self._idle_timer_id)
            except tk.TclError:
                pass
            self._idle_timer_id = None
        for attribute in ("_intro_job", "_daily_tip_job"):
            job = getattr(self, attribute, None)
            if job is not None:
                try:
                    self.after_cancel(job)
                except tk.TclError:
                    pass
                setattr(self, attribute, None)
        if self._active_bubble is not None:
            try:
                if self._active_bubble.winfo_exists():
                    self._active_bubble.close()
            except tk.TclError:
                pass
        self.withdraw()

    def _record_activity(self, event=None):
        if not self._enabled:
            return
        self._last_activity = time.monotonic()
        if self._idle_announced:
            self.duck._animate_expression("curious")
            self.duck.play_animation("welcome wave")
        self._idle_announced = False
        self._schedule_idle_timer()

    def _schedule_idle_timer(self):
        if self._idle_timer_id is not None:
            self.after_cancel(self._idle_timer_id)
        remaining = max(1, int(IDLE_DELAY_MS - (time.monotonic() - self._last_activity) * 1000))
        self._idle_timer_id = self.after(remaining, self._bored_idle)

    def _set_trapped(self, trapped):
        self._trapped = trapped
        label = "📺 Release Duck" if trapped else "📌 Trap Duck"
        self._menu.entryconfigure(self._trapped_menu_index, label=label)
        if trapped:
            self.duck._animate_expression("confused")
            self.duck.play_animation("giggle")
            self._say("Oh no! I'm trapped inside the monitor! Tap me to set me free.")
        else:
            self.duck._animate_expression("happy")
            self._say("Free at last! Let's get moving.")

    def _toggle_proactive(self):
        self._record_activity()
        self._proactive_paused = not self._proactive_paused
        label = "🔔 Resume Proactive Alerts" if self._proactive_paused else "🔔 Pause Proactive Alerts"
        self._menu.entryconfigure(self._proactive_menu_index, label=label)
        self._say("Proactive alerts are paused. Ask me anytime for a health check or tip."
                  if self._proactive_paused else "Proactive alerts are back on.")
        if not self._proactive_paused:
            self._schedule_daily_tip()

    def _start_focus(self, duration_minutes):
        self._record_activity()
        if self._focus_job is not None:
            self.after_cancel(self._focus_job)
        self._focus_remaining = duration_minutes * 60
        self._menu.entryconfigure(self._focus_stop_index, state="normal")
        self._say(f"Your {duration_minutes}-minute focus sprint has started. I'll keep quiet while you work.")
        self._focus_job = self.after(1000, self._tick_focus)

    def _stop_focus(self):
        if self._focus_job is None:
            return
        self.after_cancel(self._focus_job)
        self._focus_job = None
        self._focus_remaining = 0
        self._menu.entryconfigure(self._focus_stop_index, state="disabled")
        self._say("Focus sprint stopped. Take a stretch or start another when you're ready.")
        self._schedule_daily_tip()

    def _tick_focus(self):
        self._focus_remaining -= 1
        if self._focus_remaining <= 0:
            self._focus_job = None
            self._menu.entryconfigure(self._focus_stop_index, state="disabled")
            self._say("Focus sprint complete! Nice work. Time for a short break?")
            return
        self._focus_job = self.after(1000, self._tick_focus)

    def _open_notes(self):
        self._record_activity()
        if self._notes_window is not None and self._notes_window.winfo_exists():
            self._notes_window.deiconify()
            self._notes_window.lift()
            return
        self._notes_window = QuickNotesWindow(self)

    def _open_downloads(self):
        self._record_activity()
        downloads = Path.home() / "Downloads"
        try:
            subprocess.Popen(("explorer.exe", str(downloads)), close_fds=True)
        except OSError:
            self._say("I couldn't open Downloads. You can find the folder from File Explorer.")

    def _show_help_topic(self, topic):
        self._record_activity()
        topics = {
            "writing": (
                "Writing a message? Put the main point first, keep each paragraph to one idea, "
                "and finish with a clear next step.",
                ["Check copied text", "Open Notepad", "Close"],
            ),
            "slow": (
                "Let's find what's slowing things down. Check CPU and memory use before closing "
                "apps; save your work first.",
                ["System Health", "Inspect processes", "Close"],
            ),
            "files": (
                "If a file came from the web or an email, start in Downloads. In File Explorer, "
                "sort by Date modified to find recent items.",
                ["Open Downloads", "Open This PC", "Close"],
            ),
        }
        text, actions = topics[topic]
        self._say(text, actions)

    def _check_clipboard_text(self):
        self._record_activity()
        try:
            text = self.clipboard_get()
        except tk.TclError:
            self._say("I couldn't find text on the clipboard. Copy a passage first, then try again.",
                      ["Help with writing", "Close"])
            return

        stats = analyze_clipboard_text(text)
        if not stats["words"]:
            self._say("The clipboard doesn't contain any words to check.", ["Open Notepad", "Close"])
            return
        message = (
            f"Clipboard check: {stats['words']} words, {stats['characters']} characters, "
            f"{stats['sentences']} sentences, about {stats['reading_minutes']} min to read."
        )
        if stats["changed"]:
            message += "\nI can remove trailing spaces and blank lines while preserving indentation."
            self._clipboard_cleaned = stats["cleaned"]
            actions = ["Copy tidied text", "Open Notepad", "Close"]
        else:
            self._clipboard_cleaned = None
            actions = ["Open Notepad", "Close"]
        self._say(message, actions)


    def _show_health(self):
        self._record_activity()
        reading = sample_system()
        cpu = "Measuring..." if reading["cpu_pct"] is None else f"{reading['cpu_pct']}%"
        disk = "Unavailable" if reading["disk_pct"] is None else f"{reading['disk_pct']}% used"
        memory = "Unavailable" if reading["memory_pct"] is None else f"{reading['memory_pct']}% used"
        self._say(
            f"System check\nCPU: {cpu}\nMemory: {memory}\nSystem drive: {disk}",
            ["Refresh status", "Inspect processes", "Close"],
            "These are live readings. The first CPU sample needs a moment to warm up.",
        )

    def _start_drag(self, event):
        self._record_activity()
        if self._trapped:
            return
        self._drag_x = event.x
        self._drag_y = event.y

    def _on_drag(self, event):
        if self._trapped:
            return
        self._record_activity()
        x = self.winfo_x() + (event.x - self._drag_x)
        y = self.winfo_y() + (event.y - self._drag_y)
        x = min(max(0, x), max(0, self.winfo_screenwidth() - self.winfo_width()))
        y = min(max(0, y), max(0, self.winfo_screenheight() - self.winfo_height()))
        self.geometry(f"+{x}+{y}")
        if self._active_bubble and self._active_bubble.winfo_exists():
            self._active_bubble.reposition()

    def _intro(self):
        if not self._enabled:
            return
        self._intro_job = None
        if getattr(self.master, "_startup_post_active", False):
            self._intro_job = self.after(400, self._intro)
            return
        self._intro_shown = True
        self._say(
            "Hi there! It looks like you're working on your computer.\nWould you like some assistance?",
            ["Yes, help me out!", "I'm good, thanks!"],
            reason="intro",
        )

    def suggest_for_tool(self, title):
        """Offer one concise, context-aware hint when the user opens a tool."""
        if not self._enabled or self._proactive_paused or self._focus_job is not None:
            return
        if getattr(self.master, "_startup_post_active", False):
            return
        title = str(title or "").strip()
        if not title:
            return
        self._record_activity()
        now = time.monotonic()
        key = title.casefold()
        if now - self._last_context_hint < 10:
            return
        if now - self._context_last_shown.get(key, float("-inf")) < 1800:
            return

        lowered = key
        if any(word in lowered for word in ("diagnostic", "event log", "baseline")):
            activity = "checking diagnostics"
            note = "Start with the findings; a warning by itself is not a repair instruction."
        elif any(word in lowered for word in ("performance", "benchmark", "process")):
            activity = "measuring performance"
            note = "For a useful comparison, close heavy apps and run one test at a time."
        elif any(word in lowered for word in ("hardware", "inventory", "device")):
            activity = "reviewing hardware"
            note = "Compare the installed part and capacity with what Windows reports before changing settings."
        elif any(word in lowered for word in ("security", "defender", "firewall")):
            activity = "reviewing security"
            note = "Check the finding and its source before allowing or blocking anything."
        elif any(word in lowered for word in ("network", "wifi", "internet")):
            activity = "checking network details"
            note = "Compare the local connection status with the gateway before changing adapter settings."
        elif any(word in lowered for word in ("snapshot", "backup", "restore")):
            activity = "preparing a backup or restore point"
            note = "Restore points do not replace a separate backup of personal files."
        elif any(word in lowered for word in ("repair", "troubleshoot", "fix")):
            activity = "working through a repair"
            note = "Review the proposed change first, and keep a note of the original setting."
        elif any(word in lowered for word in ("disk", "storage", "space", "cleanup")):
            activity = "reviewing storage"
            note = "Check the file list before cleanup; the scan map tracks files checked, not physical sectors."
        elif any(word in lowered for word in ("vault", "arcade")):
            activity = "looking for hidden items"
            note = "Explore Hardware Inventory, Performance Lab, and Diagnostic Engine to earn the Vault's game-unlocking achievement."
        else:
            activity = f"exploring {title}"
            note = "I can help explain what the results mean or suggest a safe next step."

        if self._intro_job is not None:
            try:
                self.after_cancel(self._intro_job)
            except tk.TclError:
                pass
            self._intro_job = None
        if self._active_bubble is not None:
            try:
                if self._active_bubble.winfo_exists():
                    if self._bubble_reason in ("intro", "idle"):
                        self._active_bubble.close()
                    else:
                        return
            except tk.TclError:
                pass

        self._context_last_shown[key] = now
        self._last_context_hint = now
        self.duck.play_animation("curious peek")
        self._say(
            f"It looks like you're trying to {activity}.\n{note}",
            ["Tell me a tip", "Not now"],
            reason="context",
        )

    def set_daily_tip_enabled(self, enabled):
        db.set_setting("duck_daily_tip_enabled", bool(enabled))
        if enabled:
            self._schedule_daily_tip()
        elif self._daily_tip_job is not None:
            try:
                self.after_cancel(self._daily_tip_job)
            except tk.TclError:
                pass
            self._daily_tip_job = None

    def _schedule_daily_tip(self, delay_ms=45000):
        if (
            not self._enabled
            or not db.get_setting("duck_daily_tip_enabled", True)
            or db.get_setting("duck_tip_last_shown_date", "") == time.strftime("%Y-%m-%d")
            or self._daily_tip_job is not None
        ):
            return
        self._daily_tip_job = self.after(delay_ms, self._maybe_show_daily_tip)

    def _maybe_show_daily_tip(self):
        self._daily_tip_job = None
        if not self.winfo_exists() or not self._enabled:
            return
        if not db.get_setting("duck_daily_tip_enabled", True):
            return
        if db.get_setting("duck_tip_last_shown_date", "") == time.strftime("%Y-%m-%d"):
            return
        if self._proactive_paused:
            return
        if self._focus_job is not None:
            self._schedule_daily_tip(5 * 60 * 1000)
            return
        if self._active_bubble is not None:
            try:
                if self._active_bubble.winfo_exists():
                    self._schedule_daily_tip(60 * 1000)
                    return
            except tk.TclError:
                pass
        self._show_tip_of_day(automatic=True)

    def _show_tip_of_day(self, automatic=False):
        if not self._enabled:
            return
        today = time.strftime("%Y-%m-%d")
        if automatic and (
            not db.get_setting("duck_daily_tip_enabled", True)
            or db.get_setting("duck_tip_last_shown_date", "") == today
        ):
            return
        tip_index = (time.localtime().tm_yday - 1) % len(TIPS_OF_DAY)
        title, body = TIPS_OF_DAY[tip_index]
        self.duck.play_animation("idea pop")
        self._say(
            f"TIP OF THE DAY  /  {title}\n{body}",
            ["Close"],
            reason="daily_tip",
        )
        db.set_setting("duck_tip_last_shown_date", today)

    def _schedule_proactive_tip(self):
        self.after(60000, self._proactive_check)

    def _bored_idle(self):
        if not self.winfo_exists() or not self._enabled:
            return
        self._idle_timer_id = None
        if self._focus_job is not None:
            return
        idle_for = time.monotonic() - self._last_activity
        if idle_for < IDLE_DELAY_MS / 1000:
            self._schedule_idle_timer()
            return
        if self._idle_announced:
            return
        self._idle_announced = True
        if not (self._active_bubble and self._active_bubble.winfo_exists()):
            self._say(
                "Psst... it's awfully quiet. Tap me if you need a hand!",
                ["Tell me a tip", "Not now"],
                reason="idle",
            )
        self.duck._animate_expression("bored")
        self.duck.play_animation("sleepy")

    def _intercept_feature(self, reading):
        if reading["disk_pct"] is not None and reading["disk_pct"] > 90:
            return (
                "disk",
                f"Your disk is {reading['disk_pct']}% full. Want to review temporary files?",
                ["Clean temp files", "Ignore"],
            )
        if reading["cpu_pct"] is not None and reading["cpu_pct"] > 90:
            return (
                "cpu",
                f"CPU usage is {reading['cpu_pct']}%. Want to inspect busy processes?",
                ["Inspect processes", "It's fine"],
            )
        if reading["memory_pct"] is not None and reading["memory_pct"] > 90:
            return (
                "memory",
                f"Memory use is {reading['memory_pct']}%. Want to review running apps?",
                ["Optimize RAM", "It's fine"],
            )
        return None

    def _proactive_check(self):
        if not self.winfo_exists() or not self._enabled:
            return
        if self._proactive_paused or self._focus_job is not None:
            self._schedule_proactive_tip()
            return
        if time.monotonic() - self._last_activity < 90 or (
            self._active_bubble and self._active_bubble.winfo_exists()
        ):
            self._schedule_proactive_tip()
            return
        reading = sample_system()
        intercepted = self._intercept_feature(reading)
        now = time.monotonic()
        if intercepted and now - self._feature_last_shown.get(intercepted[0], 0) >= FEATURE_ALERT_COOLDOWN:
            feature, text, actions = intercepted
            self._feature_last_shown[feature] = now
            self._say(text, actions, reason="proactive")
        self._schedule_proactive_tip()

    def _quack(self):
        self._record_activity()
        text, actions = random.choice(TIPS)
        self._say(text, actions)

    def _tool_tab_open(self):
        """True when a tool tab (anything other than Dashboard) is selected."""
        try:
            nb = self.master.notebook
            current = nb.select()
            if not current:
                return False
            return nb._display_title(nb.tab(current, "text")) != "Dashboard"
        except Exception:
            return False

    def _say(self, text, actions=None, help_text=None, reason="interaction"):
        if not self._enabled:
            return
        # Automatic tips (intro, context, daily tip, idle, proactive alerts)
        # must not pop over a tool page. Their bubble is a topmost window and
        # would sit on top of the tool's CLOSE/PREV/NEXT buttons.
        if reason != "interaction" and self._tool_tab_open():
            return
        if self._active_bubble and self._active_bubble.winfo_exists():
            self._active_bubble.close()

        message = f"{text} {' '.join(actions or [])}".lower()
        if any(word in message for word in ("full", "low on disk", "extra hard", "frustrat")):
            expression = "frustrated"
        elif any(word in message for word in ("confused", "unclear", "what does")):
            expression = "confused"
        elif any(word in message for word in ("thanks", "shipshape", "saved successfully")):
            expression = "happy"
        else:
            expression = "curious"

        if any(word in message for word in ("disk", "clean temp", "cleanup", "clean up")):
            prop = "magnet"
        elif any(word in message for word in ("cpu", "inspect", "diagnostic", "health")):
            prop = "magnifier"
        else:
            prop = "notepad"
        self.duck.morph_for_tip(expression, prop)
        help_text = help_text or self._contextual_help(message)

        self._bubble_reason = reason
        self._active_bubble = SpeechBubble(self, self, text, actions, self._handle_action, help_text)

    def _handle_action(self, choice):
        self._record_activity()
        normalized = choice.lower()
        if normalized == "help with writing":
            self._show_help_topic("writing")
            return
        if normalized == "check copied text":
            self._check_clipboard_text()
            return
        if normalized == "copy tidied text":
            if self._clipboard_cleaned is not None:
                self.clipboard_clear()
                self.clipboard_append(self._clipboard_cleaned)
                self._clipboard_cleaned = None
                self._say("Tidied text is copied. Indentation was preserved.")
            return
        if normalized == "open notepad":
            try:
                subprocess.Popen(("notepad.exe",), close_fds=True)
            except OSError:
                self._say("I couldn't open Notepad. You can launch it from the Start menu.")
            return
        if normalized == "system health":
            self._show_health()
            return
        if normalized == "open downloads":
            self._open_downloads()
            return
        if normalized == "open this pc":
            try:
                subprocess.Popen(("explorer.exe", "shell:MyComputerFolder"), close_fds=True)
            except OSError:
                self._say("I couldn't open File Explorer. You can launch it from the Start menu.")
            return
        if normalized == "refresh status":
            self._show_health()
            return
        if normalized == "close":
            return
        if normalized in ("give me a tip", "tell me a tip"):
            self._show_tip_of_day(automatic=False)
            return
        destinations = {
            "clean up disk": ("explorer.exe", "ms-settings:storagesense"),
            "clean temp files": ("explorer.exe", "ms-settings:storagesense"),
            "inspect cpu": ("taskmgr.exe",),
            "inspect processes": ("taskmgr.exe",),
            "optimize ram": ("taskmgr.exe",),
            "create snapshot": ("SystemPropertiesProtection.exe",),
        }
        responses = {
            "clean up disk": "Storage settings are open. Review suggested items before removing anything.",
            "clean temp files": "Storage settings are open. Review suggested items before removing anything.",
            "inspect cpu": "Task Manager is open. Check the Processes tab for CPU use.",
            "inspect processes": "Task Manager is open. Sort the Processes tab by CPU use.",
            "optimize ram": "Task Manager is open. Check Memory use and close only apps you recognize.",
            "create snapshot": "System Protection is open. Choose a drive to review restore point options.",
            "give me a tip": "A quick win: restart apps that have been open for days to clear stale memory.",
            "tell me a tip": "A quick win: save your work before installing updates or restarting.",
            "ignore for now": "No problem. I'll leave things as they are.",
            "ignore": "No problem. I'll leave things as they are.",
            "later": "Sure, we can come back to that later.",
            "i like the heat": "Fair enough. I'll keep an eye on things.",
            "it's fine": "Got it. I'll stay out of the way.",
            "let it ride": "All right. Let me know if things start to slow down.",
            "thanks duck": "You're welcome! Quack anytime.",
            "thanks buddy": "Anytime! I'll be right here.",
            "dismiss": "All right. I'll be here if you need me.",
            "not now": "Okay. I'll keep myself occupied.",
            "yes, help me out!": "On it! Pick a tip or task and we'll work through it together.",
            "i'm good, thanks!": "Sounds good. I'll stay nearby if anything comes up.",
        }
        destination = destinations.get(normalized)
        response = responses.get(normalized, "All right. I'll be here if you need me.")
        if destination:
            try:
                subprocess.Popen(destination, close_fds=True)
            except OSError:
                response = "I couldn't open that Windows tool. You can find it from the Start menu."
        self._say(response)

    @staticmethod
    def _contextual_help(message):
        if any(word in message for word in ("disk", "temporary file", "temp files", "cleanup")):
            return "Review the suggested files before removing anything."
        if any(word in message for word in ("cpu", "process", "diagnostic")):
            return "Sort processes by CPU use to find what is keeping the system busy."
        if any(word in message for word in ("ram", "memory", "cached")):
            return "Check memory use first; close only apps you recognize and no longer need."
        if any(word in message for word in ("snapshot", "restore point")):
            return "A restore point can help undo some system changes; personal files are not backed up."
        return None


def sample_system():
    """Return measured Windows CPU, memory, and system-drive usage."""
    disk_pct = None
    try:
        disk_root = os.environ.get("SystemDrive", "C:") + "\\"
        disk = shutil.disk_usage(disk_root)
        disk_pct = round(100 * (1 - disk.free / disk.total))
    except OSError:
        pass

    cpu_pct = None
    memory_pct = None
    if os.name == "nt":
        class FILETIME(ctypes.Structure):
            _fields_ = [("low", ctypes.c_ulong), ("high", ctypes.c_ulong)]

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        idle, kernel_time, user_time = FILETIME(), FILETIME(), FILETIME()
        if kernel.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel_time), ctypes.byref(user_time)):
            def filetime_value(value):
                return (value.high << 32) | value.low

            current = (
                filetime_value(idle),
                filetime_value(kernel_time) + filetime_value(user_time),
            )
            previous = getattr(sample_system, "_cpu_times", None)
            sample_system._cpu_times = current
            if previous:
                idle_delta = current[0] - previous[0]
                total_delta = current[1] - previous[1]
                if total_delta > 0:
                    cpu_pct = round(100 * (1 - idle_delta / total_delta))

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("length", ctypes.c_ulong), ("memory_load", ctypes.c_ulong),
                ("total_phys", ctypes.c_ulonglong), ("avail_phys", ctypes.c_ulonglong),
                ("total_page_file", ctypes.c_ulonglong), ("avail_page_file", ctypes.c_ulonglong),
                ("total_virtual", ctypes.c_ulonglong), ("avail_virtual", ctypes.c_ulonglong),
                ("avail_extended_virtual", ctypes.c_ulonglong),
            ]

        memory_status = MEMORYSTATUSEX()
        memory_status.length = ctypes.sizeof(memory_status)
        if kernel.GlobalMemoryStatusEx(ctypes.byref(memory_status)):
            memory_pct = int(memory_status.memory_load)

    return {"cpu_pct": cpu_pct, "disk_pct": disk_pct, "memory_pct": memory_pct}


def analyze_clipboard_text(text):
    """Return lightweight writing stats and cleanup without changing indentation."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    cleaned_lines = [line.rstrip() for line in lines]
    while cleaned_lines and not cleaned_lines[0].strip():
        cleaned_lines.pop(0)
    while cleaned_lines and not cleaned_lines[-1].strip():
        cleaned_lines.pop()
    cleaned = "\n".join(cleaned_lines)

    words = re.findall(r"\b[\w'-]+\b", text, flags=re.UNICODE)
    sentences = len(re.findall(r"[.!?]+(?=\s|$)", text.strip()))
    if words and sentences == 0:
        sentences = 1
    return {
        "words": len(words),
        "characters": len(text),
        "sentences": sentences,
        "reading_minutes": max(1, (len(words) + 199) // 200) if words else 0,
        "cleaned": cleaned,
        "changed": cleaned != text,
    }


