#!/usr/bin/env python3
"""
gui/topbar.py — Fluent top bar
==============================
Search box, live date/time, theme switch, Aero switch, user profile and
window controls (minimise / maximise / close) in one thin chrome strip.

The search box reuses the *existing* tool search index (gui/search.py) and
opens real tools through app.open_tool — it is a faster front door to the
same catalogue the sidebar shows, not a second implementation.
"""

import math
import tkinter as tk
from datetime import datetime
from pathlib import Path

from gui import fluent as fl
from gui.live_activity import attach_live_activity
from gui.privacy_dots import attach_privacy_dots
from gui.widgets import SearchBox, round_rect
from gui.search import ToolSearchIndex
from gui.command_palette import toggle as toggle_command_palette
from i18n import t


class WindowControls(tk.Frame):
    """Minimise / maximise / close with real vector-style UI icons."""

    def __init__(self, parent, app, theme, aero=False):
        self.app = app
        self.theme = theme
        self.aero = aero
        self._images = []
        super().__init__(parent, bg=parent["bg"])
        specs = [("minimize", self._minimize, None),
                 ("maximize", self._toggle_max, None),
                 ("close", app._on_close, "#c42b1c")]
        for icon, cmd, hover in specs:
            self._make(icon, cmd, hover)

    def _make(self, icon, command, hover_bg):
        normal = self._load_icon(icon, active=False)
        active = self._load_icon(icon, active=True)
        if normal is None:
            # Defensive fallback; these assets are bundled, but never let
            # decorative chrome prevent the app from launching.
            lbl = tk.Label(self, text="", bg=self["bg"], fg=self.theme["FG"],
                           width=4, height=1, cursor="hand2")
        else:
            self._images.extend([normal, active])
            lbl = tk.Label(self, image=normal, bg=self["bg"],
                           width=24, height=24, cursor="hand2")
            lbl._ui_icons = (normal, active)
        lbl.pack(side="left", padx=1)
        hover = hover_bg or fl.glass(self.theme, "LAYER_3", self.aero, 0.2)
        fg_hover = "#ffffff" if hover_bg else self.theme["FG"]
        def enter(_e):
            lbl.config(bg=hover)
            if hasattr(lbl, "_ui_icons") and lbl._ui_icons[1] is not None:
                lbl.config(image=lbl._ui_icons[1])
            elif hover_bg:
                lbl.config(fg=fg_hover)
        def leave(_e):
            lbl.config(bg=self["bg"])
            if hasattr(lbl, "_ui_icons"):
                lbl.config(image=lbl._ui_icons[0])
            elif hover_bg:
                lbl.config(fg=self.theme["FG"])
        lbl.bind("<Enter>", enter)
        lbl.bind("<Leave>", leave)
        lbl.bind("<Button-1>", lambda _e: command())

    @staticmethod
    def _load_icon(name, active=False):
        try:
            path = Path(__file__).resolve().parent / "assets" / "ui_icons" / f"{name}{'_active' if active else ''}_20.png"
            return tk.PhotoImage(file=str(path)) if path.exists() else None
        except Exception:
            return None

    def _minimize(self):
        self.app.iconify()

    def _toggle_max(self):
        try:
            if hasattr(self.app, "toggle_maximize"):
                self.app.toggle_maximize()   # work-area maximize: keeps taskbar visible
            else:
                self.app.state("normal" if self.app.state() == "zoomed" else "zoomed")
        except tk.TclError:
            self.app.attributes("-fullscreen",
                                not self.app.attributes("-fullscreen"))


class TrafficLights(WindowControls):
    """macOS-style close / minimise / zoom dots, pinned to the left edge.

    Same commands as WindowControls (inherited _minimize, _toggle_max and
    app._on_close). Glyphs appear on hover, as on macOS.
    """

    _DOTS = (
        ("close", "#ff5f57", "#c1403a", "\u00d7"),
        ("minimize", "#febc2e", "#c99420", "\u2212"),
        ("maximize", "#28c840", "#1fa02f", "+"),
    )

    def __init__(self, parent, app, theme, aero=False):
        self.app = app
        self.theme = theme
        self.aero = aero
        self._images = []
        tk.Frame.__init__(self, parent, bg=parent["bg"])
        commands = {"close": app._on_close,
                    "minimize": self._minimize,
                    "maximize": self._toggle_max}
        for name, fill, edge, glyph in self._DOTS:
            self._dot(name, fill, edge, glyph, commands[name])

    def _dot(self, name, fill, edge, glyph, command):
        size = 13
        canvas = tk.Canvas(self, width=size, height=size, highlightthickness=0,
                           bd=0, bg=self["bg"], cursor="hand2")
        canvas.pack(side="left", padx=4)
        oval = canvas.create_oval(0, 0, size - 1, size - 1,
                                  fill=fill, outline=edge, width=1)
        mark = canvas.create_text(size / 2, size / 2 - 0.5, text="",
                                  fill="#4d0000" if name == "close" else "#5a4200",
                                  font=("Segoe UI", 7, "bold"))
        def enter(_e):
            canvas.itemconfigure(mark, text=glyph)
        def leave(_e):
            canvas.itemconfigure(mark, text="")
        canvas.bind("<Enter>", enter)
        canvas.bind("<Leave>", leave)
        canvas.bind("<Button-1>", lambda _e: command())

class TopBar(tk.Frame):
    def __init__(self, parent, app, catalogue):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.catalogue = catalogue
        self.index = ToolSearchIndex(catalogue)
        self._clock_job = None
        self._orb_job = None
        self._destroyed = False
        self._orb_phase = 0.0
        self._orb_hover = False
        self._scan_active = bool(getattr(app, "_active_scan_count", 0))
        bg = fl.glass(self.theme, "SURFACE", self.aero, 0.18)
        self.bg = bg
        super().__init__(parent, bg=bg, height=52)
        self.pack_propagate(False)

        # --- traffic lights (macOS style, far left) ---------------------
        # If the dots fail to build, fall back to the original icon buttons
        # so the window always has minimise / maximise / close.
        try:
            controls = TrafficLights(self, app, self.theme, self.aero)
            controls.pack(side="left", padx=(14, 6))
        except Exception:
            WindowControls(self, app, self.theme, self.aero).pack(side="left",
                                                                  padx=(14, 6))

        # --- brand ------------------------------------------------------
        brand = tk.Frame(self, bg=bg)
        brand.pack(side="left", padx=(16, 20))
        # Keep the bundled brand artwork and add a small, original glass orb
        # as a separate layer so the logo stays recognizable.
        logo_path = Path(__file__).resolve().parent / "assets" / "ui_icons" / "techdrive_brand_32.png"
        self._brand_icon = None
        if logo_path.exists():
            try:
                self._brand_icon = tk.PhotoImage(master=brand, file=str(logo_path))
            except Exception:
                self._brand_icon = None
        logo = tk.Canvas(
            brand, width=40, height=40, bg=bg, highlightthickness=0,
            bd=0, cursor="hand2",
        )
        logo.pack(side="left")
        self._brand_logo_canvas = logo
        if self._brand_icon is not None:
            logo.create_image(16, 16, image=self._brand_icon, anchor="center",
                              tags=("brand",))
        else:
            # Defensive fallback if the PNG is missing/corrupt.
            round_rect(logo, 2, 2, 30, 30, r=9,
                       fill=fl.mix(bg, "#050a12", 0.7), outline=self.theme["ACCENT"], width=1)
            logo.create_text(16, 15, text="TD", fill="#ffffff",
                             font=fl.font(10, "bold", True))
            logo.create_line(9, 24, 23, 22, fill=self.theme["ACCENT"], width=2)
        logo.bind("<Enter>", self._orb_enter, add="+")
        logo.bind("<Leave>", self._orb_leave, add="+")
        self._draw_brand_orb()
        self._tick_brand_orb()
        try:
            from gui._td_devmode import arm as _arm_devmode
            _arm_devmode(logo, self.theme, self.aero)
        except Exception:
            pass
        text = tk.Frame(brand, bg=bg)
        text.pack(side="left", padx=8)
        brand_row = tk.Frame(text, bg=bg)
        brand_row.pack(anchor="w")
        title_label = tk.Label(brand_row, text="TechDrive", bg=bg,
                               fg=fl.glow_color(self.theme, self.aero),
                               font=fl.font(13, "bold", True))
        title_label.pack(side="left")
        from gui.feedback_widget import FeedbackBadge
        self.feedback_badge = FeedbackBadge(brand_row, app, self.theme, self.aero, bg=bg)
        self.feedback_badge.pack(side="left", padx=(8, 0))
        subtitle_label = tk.Label(text, text="Diagnostics & repair",
                                  bg=bg, fg=self.theme["MUTED"], font=fl.F_TINY())
        subtitle_label.pack(anchor="w", pady=(2, 0))

        # Frameless Windows mode needs a draggable client-side title area.
        # Keep this limited to the brand/title text so buttons and search
        # controls continue to receive their normal clicks.
        self._drag_start = None
        for drag_widget in (brand, text, brand_row, title_label, subtitle_label):
            drag_widget.bind("<ButtonPress-1>", self._start_window_drag, add="+")
            drag_widget.bind("<B1-Motion>", self._move_window_drag, add="+")
            drag_widget.bind("<Double-Button-1>", self._dblclick_title, add="+")

        # --- Dynamic Island–style live activity pill --------------------
        try:
            attach_live_activity(self, app)
        except Exception:
            pass
        try:
            attach_privacy_dots(self, app)
        except Exception:
            pass

        # --- window controls (right edge first so they stay pinned) -------
        # Standard minimise / maximise / close on the right as well.
        WindowControls(self, app, self.theme, self.aero).pack(side="right",
                                                              padx=(6, 6))
        self._icon_button("theme", "Switch light / dark theme", app.toggle_theme)
        self._icon_button("aero", "Toggle Aero glass", app.toggle_aero_glass)

        # --- quick settings gear -------------------------------------------
        # A dedicated gear icon (separate from the nav rail's "Settings"
        # row) matching the mockup's top-right icon cluster; packed here
        # (before the bell) so it lands just right of the bell, closer to
        # the window controls, same relative order as the mockup.
        self._icon_button("settings", "Settings", app.open_settings_tab)

        # --- notifications --------------------------------------------------
        # Small bell + unread-dot badge, matching the concept mockup's
        # top-right icon cluster (search -> bell -> avatar). Purely visual
        # chrome for now: it opens app.open_notifications() if that exists,
        # otherwise the click is a harmless no-op, same defensive pattern
        # every other topbar icon here already uses.
        bell = tk.Frame(self, bg=bg, width=34, height=30)
        bell.pack(side="right", padx=2)
        bell.pack_propagate(False)
        bell_icon = self._load_ui_icon("notifications", active=False)
        bell_active = self._load_ui_icon("notifications", active=True)
        if bell_icon is not None:
            self._ui_images = getattr(self, "_ui_images", [])
            self._ui_images.extend([bell_icon, bell_active])
            bell_lbl = tk.Label(bell, image=bell_icon, bg=bg,
                                width=20, height=20, cursor="hand2")
            bell_lbl._ui_icons = (bell_icon, bell_active)
        else:
            bell_lbl = tk.Label(bell, text="", bg=bg, cursor="hand2")
        bell_lbl.place(relx=0.5, rely=0.5, anchor="center")
        # Small unread-count badge, top-right corner of the bell. Hidden
        # (no text) until set_unread_count() reports a nonzero count, so
        # it costs nothing visually when there's nothing to flag.
        self.bell_badge = tk.Label(bell, text="", bg=fl.BAD, fg="#ffffff",
                                   font=fl.font(7, "bold"), width=2)
        bell_hover = fl.glass(self.theme, "LAYER_3", self.aero, 0.2)

        def _bell_enter(_e):
            bell.config(bg=bell_hover)
            bell_lbl.config(bg=bell_hover)
            if hasattr(bell_lbl, "_ui_icons") and bell_lbl._ui_icons[1] is not None:
                bell_lbl.config(image=bell_lbl._ui_icons[1])

        def _bell_leave(_e):
            bell.config(bg=bg)
            bell_lbl.config(bg=bg)
            if hasattr(bell_lbl, "_ui_icons"):
                bell_lbl.config(image=bell_lbl._ui_icons[0])

        def _bell_click(_e):
            try:
                self.app.open_notifications()
            except Exception as exc:
                try: self.app.show_toast(f"Notification Center: {exc}", kind="error")
                except Exception: pass

        for w in (bell, bell_lbl):
            w.bind("<Enter>", _bell_enter)
            w.bind("<Leave>", _bell_leave)
            w.bind("<Button-1>", _bell_click)

        # Reflect whatever's already in the Notification Center as soon as
        # the top bar exists (e.g. warnings logged during startup checks).
        try:
            from shared import database as db
            self.set_unread_count(db.unread_notification_count())
        except Exception:
            pass

        # --- profile ------------------------------------------------------
        profile = tk.Frame(self, bg=bg)
        profile.pack(side="right", padx=12)
        avatar = tk.Canvas(profile, width=30, height=30, bg=bg,
                           highlightthickness=0)
        avatar.pack(side="left")
        avatar.create_oval(1, 1, 29, 29,
                           fill=fl.mix(bg, self.theme["ACCENT"], 0.55),
                           outline="")
        avatar.create_text(15, 15, text=app.get_user_name()[:1].upper(),
                           fill=self.theme["ON_ACCENT"], font=fl.font(11, "bold"))
        who = tk.Frame(profile, bg=bg)
        who.pack(side="left", padx=8)
        tk.Label(who, text=app.get_user_name(), bg=bg, fg=self.theme["FG"],
                 font=fl.F_SMALL()).pack(anchor="w")
        self.tier_label = tk.Label(who, text=app._tier_text(), bg=bg,
                                   fg=self.theme["ACCENT"], font=fl.F_TINY())
        self.tier_label.pack(anchor="w")

        # --- clock ---------------------------------------------------------
        clock_box = tk.Frame(self, bg=bg)
        clock_box.pack(side="right", padx=14)
        self.clock = tk.Label(clock_box, text="", bg=bg, fg=self.theme["FG"],
                              font=fl.font(11, "bold"))
        self.clock.pack(anchor="e")
        self.date = tk.Label(clock_box, text="", bg=bg, fg=self.theme["MUTED"],
                             font=fl.F_TINY())
        self.date.pack(anchor="e")

        # --- search ----------------------------------------------------------
        # Packed on the right (like the concept mockup's search -> bell ->
        # avatar cluster) rather than hugging the brand on the left. It's
        # inserted after clock_box above so it lands just left of the clock,
        # i.e. still left of bell/avatar, matching the reference layout.
        # "(Ctrl + K)" is appended in code rather than baked into every
        # i18n/locales/*.json string, so translations stay untouched.
        placeholder = f"{t('topbar.search_placeholder')}  (Ctrl + K)"
        self.search = SearchBox(self, self.theme, aero=self.aero, width=300,
                                placeholder=placeholder,
                                on_change=self._on_search,
                                on_submit=self._on_submit)
        self.search.pack(side="right", padx=(8, 4), pady=10)
        self.results = None
        self.bind("<Configure>", self._responsive_layout, add="+")
        self.search.entry.bind("<Escape>", self._escape_search, add="+")
        self.search.entry.bind("<Down>", self._search_down, add="+")
        self.search.entry.bind("<Up>", self._search_up, add="+")
        self.search.entry.bind("<Return>", self._search_enter, add="+")

        # Global Ctrl+K -> focus the search box, matching the hint shown
        # in its own placeholder text.
        try:
            # Bind on the root window rather than the global ``all`` tag.
            # Theme/font rebuilds destroy this TopBar, so keeping a binding
            # on the old widget could leave callbacks targeting dead Entry
            # objects.  A root-level binding is replaced and removed by the
            # TopBar lifecycle below without touching other app-wide key
            # handlers.
            old_id = getattr(self.app, "_topbar_ctrl_k_id", None)
            if old_id:
                try:
                    self.app.unbind("<Control-k>", old_id)
                except Exception:
                    pass
            self.app._topbar_ctrl_k_id = self.app.bind("<Control-k>", lambda e: toggle_command_palette(self.app), add="+")
        except Exception:
            self.app._topbar_ctrl_k_id = None

        self._tick()

    def _focus_search(self, _event=None):
        try:
            self.search.focus_entry()
        except Exception:
            pass
        return "break"

    def _responsive_layout(self, _event=None):
        """Keep the top bar usable at the full supported window range.

        At compact widths the long instructional placeholder competes with
        the live clock/profile/window controls. The search function itself
        is unchanged; only its presentation is shortened.
        """
        try:
            width = self.winfo_width()
            target = 300 if width >= 1280 else 240 if width >= 1120 else 205
            self.search.configure(width=target)
            compact = width < 1120
            placeholder = ("Search tools…" if compact
                           else f"{t('topbar.search_placeholder')}  (Ctrl + K)")
            if self.search._showing_placeholder and self.search.placeholder != placeholder:
                self.search.placeholder = placeholder
                self.search.entry.delete(0, "end")
                self.search.entry.insert(0, placeholder)
        except tk.TclError:
            pass

    def _orb_enter(self, _event=None):
        self._orb_hover = True
        self._draw_brand_orb()
        self._schedule_brand_orb(72)

    def _orb_leave(self, _event=None):
        self._orb_hover = False
        self._draw_brand_orb()
        self._schedule_brand_orb(72 if self._scan_active else 600)

    def set_scan_activity(self, active):
        """Show the orb's scan pulse while a disk scan is running."""
        self._scan_active = bool(active)
        self._draw_brand_orb()
        self._schedule_brand_orb(72 if self._scan_active or self._orb_hover else 600)

    def _schedule_brand_orb(self, delay):
        try:
            if self._orb_job:
                self.after_cancel(self._orb_job)
            self._orb_job = self.after(delay, self._tick_brand_orb)
        except tk.TclError:
            self._orb_job = None

    def _draw_brand_orb(self):
        canvas = getattr(self, "_brand_logo_canvas", None)
        if canvas is None:
            return
        try:
            if not canvas.winfo_exists():
                return
            canvas.delete("orb")
            active = self._scan_active or self._orb_hover
            pulse = (math.sin(self._orb_phase) + 1) / 2 if active else 0.0
            cx, cy = 30, 29
            radius = 6.2 + (0.8 * pulse if active else 0)
            bg = canvas.cget("bg")
            blue = "#16a7ff"
            glow_mix = 0.25 + 0.12 * pulse if active else 0.12
            glow = fl.mix(bg, blue, glow_mix)
            rim = fl.mix("#07509c", "#75e4ff", 0.4 + 0.4 * pulse)
            orb = fl.mix("#07509c", "#27c8ff", 0.42 + 0.34 * pulse)
            canvas.create_oval(
                cx - radius - 2.0, cy - radius - 2.0,
                cx + radius + 2.0, cy + radius + 2.0,
                fill=glow, outline="", tags=("orb",),
            )
            canvas.create_oval(
                cx - radius, cy - radius, cx + radius, cy + radius,
                fill=orb, outline=rim, width=1.2, tags=("orb",),
            )
            canvas.create_arc(
                cx - radius + 1.2, cy - radius + 1.0,
                cx + radius - 1.2, cy + radius - 1.2,
                start=25, extent=145, style="arc",
                outline=fl.mix("#b8f4ff", orb, 0.18), width=1.3, tags=("orb",),
            )
            canvas.create_oval(
                cx - radius * 0.46, cy - radius * 0.58,
                cx + radius * 0.17, cy - radius * 0.20,
                fill=fl.mix("#ffffff", orb, 0.16), outline="", tags=("orb",),
            )
        except tk.TclError:
            pass

    def _tick_brand_orb(self):
        if self._destroyed:
            return
        try:
            if not self.winfo_exists():
                return
            if self._scan_active or self._orb_hover:
                self._orb_phase += 0.24
                self._draw_brand_orb()
                delay = 72
            else:
                delay = 600
            self._orb_job = self.after(delay, self._tick_brand_orb)
        except tk.TclError:
            self._orb_job = None

    def _escape_search(self, _event=None):
        self._close_results()
        return "break"

    def set_unread_count(self, count):
        """Show/hide the bell's unread badge. Called by app.notify() and
        whenever the Notification Center is opened (which clears it)."""
        try:
            if count and count > 0:
                self.bell_badge.config(text=str(count) if count < 10 else "9+")
                self.bell_badge.place(relx=1.0, y=2, x=-2, anchor="ne")
            else:
                self.bell_badge.place_forget()
        except tk.TclError:
            pass

    def refresh_catalogue(self, catalogue):
        """Rebuilds the search index against a new catalogue - called
        when a plugin is installed/uninstalled at runtime."""
        self.catalogue = catalogue
        self.index = ToolSearchIndex(catalogue)

    # ------------------------------------------------------------------
    def _load_ui_icon(self, name, active=False):
        try:
            path = Path(__file__).resolve().parent / "assets" / "ui_icons" / f"{name}{'_active' if active else ''}_20.png"
            return tk.PhotoImage(file=str(path)) if path.exists() else None
        except Exception:
            return None

    def _start_window_drag(self, event):
        try:
            if hasattr(self.app, "is_window_maximized") and self.app.is_window_maximized():
                # Dragging the title area of a maximized window restores it
                # under the cursor (standard Windows behaviour).
                self.app.restore_from_maximize((event.x_root, event.y_root))
                self.app.update_idletasks()
            elif self.app.state() == "zoomed":
                self._drag_start = None
                return
        except tk.TclError:
            pass
        self._drag_start = (event.x_root, event.y_root,
                            self.app.winfo_x(), self.app.winfo_y())

    def _dblclick_title(self, _event=None):
        self._drag_start = None
        try:
            self.app.toggle_maximize()
        except Exception:
            pass

    def _move_window_drag(self, event):
        if not self._drag_start:
            return
        start_x, start_y, win_x, win_y = self._drag_start
        x = win_x + (event.x_root - start_x)
        y = win_y + (event.y_root - start_y)
        try:
            sw, sh = self.app.winfo_screenwidth(), self.app.winfo_screenheight()
            w, h = self.app.winfo_width(), self.app.winfo_height()
            x = min(max(0, x), max(0, sw - w))
            y = min(max(0, y), max(0, sh - h))
            self.app.geometry(f"+{x}+{y}")
        except tk.TclError:
            self._drag_start = None

    def _icon_button(self, icon, tooltip, command):
        normal = self._load_ui_icon(icon, active=False)
        active = self._load_ui_icon(icon, active=True)
        if normal is None:
            lbl = tk.Label(self, text="", bg=self.bg, fg=self.theme["FG"],
                           width=3, cursor="hand2")
        else:
            self._ui_images = getattr(self, "_ui_images", [])
            self._ui_images.extend([normal, active])
            lbl = tk.Label(self, image=normal, bg=self.bg,
                           width=24, height=24, cursor="hand2")
            lbl._ui_icons = (normal, active)
        lbl.pack(side="right", padx=2)
        hover = fl.glass(self.theme, "LAYER_3", self.aero, 0.2)
        def enter(_e):
            lbl.config(bg=hover)
            if hasattr(lbl, "_ui_icons") and lbl._ui_icons[1] is not None:
                lbl.config(image=lbl._ui_icons[1])
        def leave(_e):
            lbl.config(bg=self.bg)
            if hasattr(lbl, "_ui_icons"):
                lbl.config(image=lbl._ui_icons[0])
        lbl.bind("<Enter>", enter)
        lbl.bind("<Leave>", leave)
        lbl.bind("<Button-1>", lambda _e: command())
        return lbl

    # -- search --------------------------------------------------------
    def _on_search(self, query):
        self._close_results()
        query = query.strip()
        if len(query) < 2:
            return
        matches = [r for r in self.index.search(query)][:8]
        if not matches:
            return
        self.results = tk.Toplevel(self)
        self.results.overrideredirect(True)
        self.results.configure(bg=self.theme["STROKE"])
        screen_w = max(320, self.winfo_screenwidth())
        result_w = min(380, max(260, screen_w - 24))
        x = self.search.winfo_rootx()
        x = max(8, min(x, screen_w - result_w - 8))
        result_h = min(len(matches) * 30 + 2, max(62, self.winfo_screenheight() - 24))
        y = self.search.winfo_rooty() + self.search.winfo_height() + 4
        if y + result_h > self.winfo_screenheight() - 8:
            y = max(8, self.search.winfo_rooty() - result_h - 4)
        self.results.geometry(f"{result_w}x{result_h}+{x}+{y}")
        inner = tk.Frame(self.results, bg=self.theme["LAYER_1"])
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        self._result_rows = []
        for cat, _icon, tool in matches:
            row = tk.Label(inner, text=f"{tool}   ·   {cat}", anchor="w",
                           bg=self.theme["LAYER_1"], fg=self.theme["FG"],
                           font=fl.F_SMALL(), padx=10, cursor="hand2")
            row.pack(fill="x", ipady=4)
            row._search_bg = self.theme["LAYER_1"]
            row._search_hover = self.theme["LAYER_3"]
            row.bind("<Enter>", lambda _e, r=row: self._highlight_result(r))
            row.bind("<Leave>", lambda _e, r=row: r.config(bg=r._search_bg))
            row.bind("<Button-1>",
                     lambda _e, c=cat, t=tool: self._pick(c, t))
            self._result_rows.append((row, cat, tool))
        if self._result_rows:
            self._highlight_result(self._result_rows[0][0])

    def _highlight_result(self, row):
        for item, _cat, _tool in getattr(self, "_result_rows", []):
            try:
                item.config(bg=item._search_hover if item is row else item._search_bg)
            except tk.TclError:
                pass
        self._selected_result = next(
            (i for i, (item, _c, _t) in enumerate(getattr(self, "_result_rows", [])) if item is row), 0
        )

    def _move_result(self, delta):
        rows = getattr(self, "_result_rows", [])
        if not rows:
            return "break"
        idx = (getattr(self, "_selected_result", 0) + delta) % len(rows)
        self._highlight_result(rows[idx][0])
        return "break"

    def _search_down(self, _event=None):
        return self._move_result(1)

    def _search_up(self, _event=None):
        return self._move_result(-1)

    def _search_enter(self, _event=None):
        rows = getattr(self, "_result_rows", [])
        if rows:
            _row, cat, tool = rows[getattr(self, "_selected_result", 0)]
            self._pick(cat, tool)
        return "break"

    def _pick(self, category, tool):
        self._close_results()
        self.app.open_tool(category, tool)

    def _on_submit(self, query):
        matches = self.index.search(query.strip())
        if matches:
            cat, _icon, tool = matches[0]
            self._pick(cat, tool)

    def _close_results(self):
        if self.results is not None:
            try:
                self.results.destroy()
            except Exception:
                pass
            self.results = None
        self._result_rows = []
        self._selected_result = 0

    # -- clock ---------------------------------------------------------
    def _tick(self):
        if self._destroyed:
            return
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        now = datetime.now()
        self.clock.config(text=now.strftime("%I:%M %p").lstrip("0"))
        self.date.config(text=now.strftime("%a, %d %b %Y"))
        self._clock_job = self.after(20000, self._tick)

    def destroy(self):
        self._destroyed = True
        if self._clock_job:
            try:
                self.after_cancel(self._clock_job)
            except Exception:
                pass
            self._clock_job = None
        if self._orb_job:
            try:
                self.after_cancel(self._orb_job)
            except Exception:
                pass
            self._orb_job = None
        self._close_results()
        try:
            bind_id = getattr(self.app, "_topbar_ctrl_k_id", None)
            if bind_id:
                self.app.unbind("<Control-k>", bind_id)
                self.app._topbar_ctrl_k_id = None
        except Exception:
            pass
        super().destroy()
