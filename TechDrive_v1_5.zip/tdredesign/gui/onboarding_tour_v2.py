#!/usr/bin/env python3
"""Interactive in-app onboarding tour 2.0 — hotspot steps inside the window."""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.motion import tween, spring
from shared import database as db

STEPS = [
    {
        "title": "Welcome to TechDrive",
        "body": "Your Windows repair and diagnostics suite. This quick tour highlights the main controls.",
        "anchor": "center",
    },
    {
        "title": "Command Palette",
        "body": "Press Ctrl+K anytime to search tools, actions, focus modes, and recent work.",
        "anchor": "top",
    },
    {
        "title": "Control Center",
        "body": "Ctrl+Shift+C opens quick toggles: theme, glass, focus modes, sounds, density.",
        "anchor": "top",
    },
    {
        "title": "Live Activity",
        "body": "The pill in the top bar shows live CPU and RAM. Click it to expand.",
        "anchor": "top",
    },
    {
        "title": "Smart Suggestions",
        "body": "The dashboard suggests what needs attention — full disks, stale scans, and more.",
        "anchor": "center",
    },
    {
        "title": "You're ready",
        "body": "Open All Tools or run a Quick Scan. Replay this tour anytime from Settings.",
        "anchor": "center",
    },
]


class InteractiveTour(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.theme = app.theme
        self.step = 0
        self.overrideredirect(True)
        self.configure(bg="#000000")
        try:
            self.attributes("-topmost", True)
            self.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self._sync_geometry()
        self.bind("<Escape>", lambda e: self._finish())
        self.bind("<Configure>", lambda e: None)
        app.bind("<Configure>", self._on_app_configure, add="+")
        self._card = None
        self._build_step()
        self.after(20, self._fade_in)

    def _on_app_configure(self, _e=None):
        try:
            if self.winfo_exists():
                self._sync_geometry()
        except tk.TclError:
            pass

    def _sync_geometry(self):
        app = self.app
        try:
            app.update_idletasks()
            x, y = app.winfo_rootx(), app.winfo_rooty()
            w, h = max(app.winfo_width(), 400), max(app.winfo_height(), 300)
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

    def _fade_in(self):
        for i, a in enumerate((0.25, 0.4, 0.55)):
            self.after(i * 30, lambda a=a: self._alpha(a))

    def _alpha(self, a):
        try:
            self.attributes("-alpha", a)
        except tk.TclError:
            pass

    def _build_step(self):
        for w in self.winfo_children():
            w.destroy()
        th = self.theme
        # dim layer receives clicks to advance? only via buttons
        dim = tk.Frame(self, bg="#000000")
        dim.place(relx=0, rely=0, relwidth=1, relheight=1)

        card_w, card_h = 420, 220
        card = tk.Frame(self, bg=th.get("CARD_BG", "#1c1c1e"), width=card_w, height=card_h)
        card.pack_propagate(False)
        self._card = card

        step = STEPS[self.step]
        anchor = step.get("anchor", "center")
        if anchor == "top":
            card.place(relx=0.5, rely=0.12, anchor="n", width=card_w, height=card_h)
        else:
            card.place(relx=0.5, rely=0.5, anchor="center", width=card_w, height=card_h)

        tk.Label(
            card, text=f"STEP {self.step + 1} OF {len(STEPS)}",
            bg=card["bg"], fg=th["MUTED"], font=("Segoe UI", 8, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 4))
        tk.Label(
            card, text=step["title"], bg=card["bg"], fg=th["FG"],
            font=fl.F_TITLE3() if hasattr(fl, "F_TITLE3") else ("Segoe UI", 16, "bold"),
            wraplength=380, justify="left",
        ).pack(anchor="w", padx=20)
        tk.Label(
            card, text=step["body"], bg=card["bg"], fg=th["MUTED"],
            font=("Segoe UI", 11), wraplength=380, justify="left",
        ).pack(anchor="w", padx=20, pady=(8, 16))

        nav = tk.Frame(card, bg=card["bg"])
        nav.pack(fill="x", padx=20, pady=(0, 16))
        tk.Button(
            nav, text="Skip", command=self._finish,
            bg=card["bg"], fg=th["MUTED"], relief="flat", bd=0, cursor="hand2",
        ).pack(side="left")
        next_label = "Done" if self.step >= len(STEPS) - 1 else "Next"
        tk.Button(
            nav, text=next_label, command=self._next,
            bg=th["ACCENT"], fg="#ffffff", relief="flat", bd=0, padx=16, pady=6, cursor="hand2",
        ).pack(side="right")
        # try this now actions on some steps
        if self.step == 1:
            tk.Button(
                nav, text="Try Ctrl+K", command=self._try_palette,
                bg=card["bg"], fg=th["ACCENT"], relief="flat", bd=0, cursor="hand2",
            ).pack(side="right", padx=(0, 10))
        if self.step == 2:
            tk.Button(
                nav, text="Open Controls", command=self._try_cc,
                bg=card["bg"], fg=th["ACCENT"], relief="flat", bd=0, cursor="hand2",
            ).pack(side="right", padx=(0, 10))

        try:
            from gui import haptics
            haptics.click()
        except Exception:
            pass

    def _try_palette(self):
        try:
            from gui.command_palette import toggle
            toggle(self.app)
        except Exception:
            pass

    def _try_cc(self):
        try:
            cc = getattr(self.app, "control_center", None)
            if cc:
                cc.show()
        except Exception:
            pass

    def _next(self):
        if self.step >= len(STEPS) - 1:
            self._finish()
            return
        self.step += 1
        self._build_step()

    def _finish(self):
        try:
            db.set_setting("onboarding_tour_shown", True)
            db.set_setting("onboarding_v2_shown", True)
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass


def maybe_show(app):
    if db.get_setting("onboarding_v2_shown", False) or db.get_setting("onboarding_tour_shown", False):
        return False
    show(app)
    return True


def show(app):
    try:
        InteractiveTour(app)
        return True
    except Exception:
        return False
