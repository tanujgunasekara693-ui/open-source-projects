#!/usr/bin/env python3
"""
gui/settings.py — Settings tab
=================================
Takes the running TechDriveApp instance (duck-typed - only relies on
`app.license`, `app.theme`, `app.apply_theme_choice(name)`,
`app.get_trial_status()`, `app.get_machine_id()`, and
`app.activate_license_key(key)`, all of which techdrive.py provides) so
this module never has to `import techdrive` and risk a circular import.

Sections, per the spec:
  - License: tier, days left, HWID, key entry
  - Theme: Dark / Light / Midnight Blue / Developer / High Contrast / Classic
    (see gui.fluent.THEMES), applies immediately
  - Language: English / Sinhala / Tamil / Japanese / Russian, hooked into
    i18n.t() and live-applied across the app shell via app.refresh_language()
  - Startup: launch on Windows startup (real registry Run-key toggle on
    Windows; a no-op elsewhere), minimize/close to tray (backed by a real
    pystray tray icon - see gui/tray_icon.py)
  - Backup: export/import settings+favorites as JSON
  - Reset: wipe settings/favorites/recent back to defaults
"""

import os
import sys
import tkinter as tk
import time
from tkinter import ttk, colorchooser
from gui.tk_dialogs import filedialog, messagebox

from gui.theme import FONT_CARD_TITLE, FONT_UI, FONT_UI_BOLD, THEMES
from gui import achievements, sounds
from shared import database as db

IS_WINDOWS = sys.platform.startswith("win")
STARTUP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
STARTUP_VALUE_NAME = "TechDrive"

from i18n import t, LANGUAGES as I18N_LANGUAGES, get_language, set_language, missing_font_warning
from gui.tray_icon import TrayIcon

# Legacy display-name list kept only for any other module still importing
# it directly; the Settings UI itself now drives off i18n.LANGUAGES (codes).
LANGUAGES = list(I18N_LANGUAGES.values())

ACCENT_PRESETS = [
    ("Neon Cyan", "#00e5ff"),
    ("Neon Magenta", "#ff3df0"),
    ("Neon Violet", "#7a5cff"),
    ("Electric Green", "#39ffb0"),
    ("Amber", "#ffb020"),
    ("Crimson", "#ff4d6d"),
]

FONT_SCALES = [("Small", 0.9), ("Medium (default)", 1.0), ("Large", 1.15), ("Extra Large", 1.3)]


def _bind_mousewheel(canvas, scroll_frame):
    """Mark a Settings canvas as scrollable for TechDrive's shared wheel
    router.  Settings used to install a temporary ``bind_all`` handler and
    then call ``unbind_all`` on mouse-leave; that could remove the app-wide
    handler and make every other tool stop scrolling until restart."""
    canvas._wheel_scrollable = True


def _section(parent, theme, title):
    tk.Label(parent, text=title, bg=theme["BG"], fg=theme["FG"],
             font=FONT_CARD_TITLE).pack(anchor="w", padx=16, pady=(16, 4))
    body = tk.Frame(parent, bg=theme["CARD_BG"], bd=1, relief="solid")
    body.pack(fill="x", padx=16, pady=(0, 4))
    return body


def build_settings_tab(parent, app):
    """Populates `parent` (an empty Frame) with the full settings UI."""
    theme = app.theme
    parent.configure(bg=theme["BG"])

    canvas = tk.Canvas(parent, bg=theme["BG"], highlightthickness=0)
    scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas, bg=theme["BG"])
    scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    scroll_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    # Keep the inner frame's width in sync with the canvas so wraplength
    # labels reflow correctly on resize instead of a fixed narrow column.
    canvas.bind("<Configure>", lambda e: canvas.itemconfigure(scroll_window, width=e.width))
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    _bind_mousewheel(canvas, scroll_frame)

    _build_settings_overview(scroll_frame, app, theme, canvas)

    _build_license_section(scroll_frame, app, theme)
    _build_theme_section(scroll_frame, app, theme)
    _build_accent_color_section(scroll_frame, app, theme)
    _build_font_size_section(scroll_frame, app, theme)
    _build_language_section(scroll_frame, app, theme)
    _build_duck_section(scroll_frame, app, theme)
    _build_ai_assistant_section(scroll_frame, app, theme)
    _build_tour_section(scroll_frame, app, theme)
    _build_rgb_accent_section(scroll_frame, app, theme)
    _build_aero_section(scroll_frame, app, theme)
    _build_xp_theme_section(scroll_frame, app, theme)
    _build_sidebar_gadgets_section(scroll_frame, app, theme)
    _build_monitor_visual_section(scroll_frame, app, theme)
    _build_screensaver_section(scroll_frame, app, theme)
    _build_achievements_section(scroll_frame, app, theme)
    _build_interface_section(scroll_frame, app, theme)
    _build_notifications_section(scroll_frame, app, theme)
    _build_sound_section(scroll_frame, app, theme)
    _build_search_performance_section(scroll_frame, app, theme)
    _build_datetime_units_section(scroll_frame, app, theme)
    _build_window_section(scroll_frame, app, theme)
    _build_accessibility_section(scroll_frame, app, theme)
    _build_file_ops_section(scroll_frame, app, theme)
    _build_network_updates_section(scroll_frame, app, theme)
    _build_privacy_data_section(scroll_frame, app, theme)
    _build_dashboard_display_section(scroll_frame, app, theme)
    _build_advanced_section(scroll_frame, app, theme)
    _build_keyboard_section(scroll_frame, app, theme)
    _build_security_section(scroll_frame, app, theme)
    _build_appearance_extras_section(scroll_frame, app, theme)
    _build_tool_behavior_section(scroll_frame, app, theme)
    _build_diagnostics_section(scroll_frame, app, theme)
    _build_system_integration_section(scroll_frame, app, theme)
    _build_startup_section(scroll_frame, app, theme)
    _build_backup_section(scroll_frame, app, theme)
    _build_reset_section(scroll_frame, app, theme)

    tk.Frame(scroll_frame, bg=theme["BG"], height=16).pack()


# ---------------------------------------------------------------------------
# Settings overview / navigation
# ---------------------------------------------------------------------------
def _build_settings_overview(parent, app, theme, canvas):
    body = _section(parent, theme, "Settings")
    tk.Label(body, text="Configure TechDrive without hunting through a long list. Changes are saved automatically.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=520,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    categories = [
        ("General", "Interface & Behavior"),
        ("Appearance", "Theme"),
        ("Sounds", "TechDrive Sounds"),
        ("Notifications", "Notifications"),
        ("Performance", "Search & Performance"),
        ("Privacy", "Privacy & Data"),
        ("Advanced", "Advanced"),
        ("Backup", "Backup & Restore"),
        ("Startup", "Startup"),
        ("Reset", "Reset"),
    ]
    grid = tk.Frame(body, bg=theme["CARD_BG"])
    grid.pack(fill="x", padx=14, pady=(0, 10))

    def jump_to(title):
        def do_jump():
            canvas.update_idletasks()
            target = None
            for child in parent.winfo_children():
                if isinstance(child, tk.Label) and str(child.cget("text")) == title:
                    target = child
                    break
            if target is None:
                # Section titles are followed by their card body; tolerate
                # decorated legacy titles by matching the visible text.
                for child in parent.winfo_children():
                    if isinstance(child, tk.Label) and title.lower() in str(child.cget("text")).lower():
                        target = child
                        break
            if target is not None:
                canvas.yview_moveto(max(0.0, min(1.0, target.winfo_y() / max(1, parent.winfo_height()))))
        return do_jump

    for i, (label, title) in enumerate(categories):
        btn = tk.Button(grid, text=label, command=jump_to(title),
                        bg=theme["BG"], fg=theme["FG"], activebackground=theme["SURFACE"],
                        activeforeground=theme["FG"], relief="flat", bd=0,
                        padx=10, pady=6, cursor="hand2" if IS_WINDOWS else "arrow")
        btn.grid(row=i // 5, column=i % 5, sticky="ew", padx=3, pady=3)
    for col in range(5):
        grid.grid_columnconfigure(col, weight=1)

    def open_center():
        try:
            app.open_notifications()
        except Exception as exc:
            messagebox.showerror("Notifications", f"Could not open Notification Center:\n{exc}")
    # A small status strip gives users a direct way into the live center.
    unread = db.unread_notification_count()
    tk.Label(body, text=f"Notification Center: {unread} unread" if unread else "Notification Center: all caught up",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI).pack(side="left", padx=14, pady=(0, 12))
    tk.Button(body, text="Open Notification Center", command=open_center,
              bg=theme["ACCENT"], fg="white", relief="flat", padx=10, pady=5).pack(side="right", padx=14, pady=(0, 12))

# ---------------------------------------------------------------------------
# License
# ---------------------------------------------------------------------------
def _build_license_section(parent, app, theme):
    body = _section(parent, theme, "◆ License")

    lic = app.license
    tier_name = lic.tier
    info_lines = [f"Tier: {tier_name}", f"Licensed to: {lic.licensed_to}"]
    if lic.tier == "F":
        status = app.get_trial_status()
        if status["show_popup"]:
            info_lines.append("Trial expired.")
        else:
            info_lines.append(f"Trial days left: {status['days_left']}")
    elif lic.expires:
        info_lines.append(f"Expires: {lic.expires}")
    info_lines.append(f"HWID: {app.get_machine_id().upper()}")

    for line in info_lines:
        lbl = tk.Label(body, text=line, bg=theme["CARD_BG"], fg=theme["FG"],
                       font=FONT_UI, anchor="w")
        lbl.pack(anchor="w", padx=14, pady=2)
        if line.startswith("HWID:"):
            try:
                from gui._td_devmode import arm as _arm_devmode
                _arm_devmode(lbl, theme, getattr(app, "is_aero_enabled",
                            lambda: False)(), clicks=5, button="<Button-3>")
            except Exception:
                pass

    key_row = tk.Frame(body, bg=theme["CARD_BG"])
    key_row.pack(fill="x", padx=14, pady=(6, 14))
    key_var = tk.StringVar()
    tk.Entry(key_row, textvariable=key_var, bg=theme["SURFACE"], fg=theme["FG"],
              insertbackground=theme["FG"], relief="flat", width=32).pack(side="left", ipady=3)

    def activate():
        ok, msg = app.activate_license_key(key_var.get())
        messagebox.showinfo("License", msg)
        if ok:
            app.refresh_settings_tab()

    tk.Button(key_row, text="Activate Key", command=activate,
              bg=theme["ACCENT"], fg="white", relief="flat", padx=10).pack(side="left", padx=8)


# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------
def _build_theme_section(parent, app, theme):
    body = _section(parent, theme, f"✦ {t('settings.theme.title')}")
    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=10)

    current = db.get_setting("theme_choice", "dark")
    if current not in THEMES:
        current = "dark"
    choice_var = tk.StringVar(value=current)

    def apply_choice():
        app.apply_theme_choice(choice_var.get())

    # Reads the shared THEMES registry (gui/fluent.py) instead of a
    # hardcoded dark/light/system list, so a theme added there shows up
    # here automatically.
    for theme_id, entry in THEMES.items():
        label = f"{entry['icon']} {entry['label']}"
        tk.Radiobutton(row, text=label, variable=choice_var, value=theme_id,
                        command=apply_choice,
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"]).pack(side="left", padx=(0, 16))


# ---------------------------------------------------------------------------
# Accent Color
# ---------------------------------------------------------------------------
def _build_accent_color_section(parent, app, theme):
    body = _section(parent, theme, "◎ Accent Color")

    tk.Label(body, text="Applies immediately to buttons, highlights, and progress bars "
                         "in both Dark and Light theme.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    current = db.get_setting("accent_color", theme["ACCENT"])
    swatch_row = tk.Frame(body, bg=theme["CARD_BG"])
    swatch_row.pack(anchor="w", padx=14, pady=(0, 8))

    current_var = tk.StringVar(value=current)
    swatch_buttons = {}

    def select(hex_color):
        current_var.set(hex_color)
        app.set_accent_color(hex_color)
        for c, btn in swatch_buttons.items():
            if not btn.winfo_exists():
                continue
            btn.config(relief="solid" if c.lower() == hex_color.lower() else "flat")

    for name, hex_color in ACCENT_PRESETS:
        btn = tk.Button(swatch_row, bg=hex_color, activebackground=hex_color,
                         width=3, height=1, relief="flat", bd=2,
                         highlightthickness=0, cursor="hand2",
                         command=lambda h=hex_color: select(h))
        btn.pack(side="left", padx=4)
        swatch_buttons[hex_color] = btn
        if hex_color.lower() == str(current).lower():
            btn.config(relief="solid")

    custom_row = tk.Frame(body, bg=theme["CARD_BG"])
    custom_row.pack(anchor="w", padx=14, pady=(0, 12))

    def pick_custom():
        rgb, hex_color = colorchooser.askcolor(color=current_var.get(), title="Pick Accent Color")
        if hex_color:
            select(hex_color)

    tk.Button(custom_row, text="Custom...", command=pick_custom,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left")


# ---------------------------------------------------------------------------
# Font Size
# ---------------------------------------------------------------------------
def _build_font_size_section(parent, app, theme):
    body = _section(parent, theme, "A Font Size")

    tk.Label(body, text="Scales text across the toolbar, dashboard, and Settings tab "
                         "immediately. Tool panels already open pick it up next time "
                         "they're reopened.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=(0, 12))

    current_scale = db.get_setting("font_scale", 1.0)
    scale_var = tk.DoubleVar(value=current_scale)

    def apply_scale():
        app.set_font_scale(scale_var.get())

    for label, value in FONT_SCALES:
        tk.Radiobutton(row, text=label, variable=scale_var, value=value, command=apply_scale,
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"]).pack(anchor="w", pady=1)


# ---------------------------------------------------------------------------
# Language
# ---------------------------------------------------------------------------
def _build_language_section(parent, app, theme):
    body = _section(parent, theme, f"\U0001f310 {t('settings.language.title')}")
    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=10)

    codes = list(I18N_LANGUAGES.keys())
    names = list(I18N_LANGUAGES.values())
    current_code = get_language()
    display_var = tk.StringVar(value=I18N_LANGUAGES.get(current_code, I18N_LANGUAGES["en"]))
    combo = ttk.Combobox(row, textvariable=display_var, values=names, state="readonly", width=24)
    combo.pack(side="left")

    warn_label = tk.Label(body, text="", bg=theme["CARD_BG"], fg=theme.get("WARNING", "#e0a000"),
                           font=FONT_UI, wraplength=460, justify="left")

    def _refresh_warning():
        msg = missing_font_warning()
        warn_label.config(text=msg or "")
        if msg:
            warn_label.pack(anchor="w", padx=14, pady=(0, 4))
        else:
            warn_label.pack_forget()

    def on_change(_event=None):
        chosen_name = display_var.get()
        code = codes[names.index(chosen_name)]
        set_language(code)
        _refresh_warning()
        # Live-relabel the parts of the shell that registered for it
        # (topbar, sidebar, dashboard). Tool panels already open keep
        # their current language until reopened, same as the font-scale
        # behavior described above.
        if hasattr(app, "refresh_language"):
            app.refresh_language()

    combo.bind("<<ComboboxSelected>>", on_change)
    _refresh_warning()

    tk.Label(body, text=t("settings.language.description"),
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# Duck Assistant
# ---------------------------------------------------------------------------
def _build_duck_section(parent, app, theme):
    body = _section(parent, theme, "✦ Assistant")

    enabled_var = tk.BooleanVar(value=db.get_setting("duck_assistant_enabled", True))

    def on_toggle():
        app.set_duck_assistant_enabled(enabled_var.get())

    tk.Checkbutton(body, text="Show Assistant (floating helper)",
                    variable=enabled_var, command=on_toggle,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"]).pack(anchor="w", padx=14, pady=(10, 2))

    tk.Label(body, text="Answers PC-repair questions (BSOD, slow PC, disk health, boot issues, "
                         "RAM, Windows Update, file recovery) from a built-in knowledge base — "
                         "fully offline, no data leaves this PC. It also handles casual chat "
                         "(\"hi\", \"thanks\", \"who are you\") separately from the technical answers.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(0, 10))

    tk.Label(body, text="Personality", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(0, 2))

    mode_var = tk.StringVar(value=db.get_setting("duck_personality_mode", "normal"))

    def on_mode_change():
        db.set_setting("duck_personality_mode", mode_var.get())

    modes = [("funny", "● Funny — jokes, emoji, personality"),
            ("normal", "● Normal — friendly and to the point"),
            ("corporate", "◇ Corporate — formal, no emoji")]
    for value, label in modes:
        tk.Radiobutton(body, text=label, variable=mode_var, value=value,
                       command=on_mode_change, bg=theme["CARD_BG"], fg=theme["FG"],
                       selectcolor=theme["BG"], activebackground=theme["CARD_BG"],
                       font=FONT_UI).pack(anchor="w", padx=24, pady=1)

    tk.Label(body, text="Technical answers themselves stay accurate in every mode — only the "
                        "tone and casual chat responses change, so correctness never depends "
                        "on which personality is picked. Takes effect on your next message, "
                        "no restart needed.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(8, 12))

    daily_tip_var = tk.BooleanVar(
        value=db.get_setting("duck_daily_tip_enabled", True)
    )

    def on_daily_tip_toggle():
        app.set_duck_daily_tip_enabled(daily_tip_var.get())

    tk.Checkbutton(
        body, text="Show one Duck Tip of the Day",
        variable=daily_tip_var, command=on_daily_tip_toggle,
        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
        activebackground=theme["CARD_BG"],
    ).pack(anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# AI Assistant (online fallback, user-supplied key only)
# ---------------------------------------------------------------------------
def _build_ai_assistant_section(parent, app, theme):
    from techdrive_modules import ai_provider

    body = _section(parent, theme, "\U0001f916 AI Assistant (Online Fallback)")

    tk.Label(body, text="Optional. When the Assistant's offline knowledge base doesn't have "
                         "an answer, it can ask an online AI provider instead — but only if "
                         "you add your own API key here. TechDrive does not ship with, share, "
                         "or use any built-in key. Your key is stored only on this PC and is "
                         "sent solely to the provider you pick below.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(10, 10))

    if not ai_provider.HAVE_REQUESTS:
        tk.Label(body, text="The 'requests' package isn't installed, so this feature is "
                             "unavailable until it is (pip install requests).",
                  bg=theme["CARD_BG"], fg="#e5793a", font=FONT_UI, wraplength=460,
                  justify="left").pack(anchor="w", padx=14, pady=(0, 12))
        return

    tk.Label(body, text="Provider", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(0, 2))

    provider_var = tk.StringVar(value=ai_provider.get_provider())

    def on_provider_change():
        ai_provider.set_provider(provider_var.get())

    for value, cfg in ai_provider.PROVIDERS.items():
        tk.Radiobutton(body, text=cfg["label"], variable=provider_var, value=value,
                       command=on_provider_change, bg=theme["CARD_BG"], fg=theme["FG"],
                       selectcolor=theme["BG"], activebackground=theme["CARD_BG"],
                       font=FONT_UI).pack(anchor="w", padx=24, pady=1)

    tk.Label(body, text="API Key", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(10, 2))

    key_row = tk.Frame(body, bg=theme["CARD_BG"])
    key_row.pack(fill="x", padx=14, pady=(0, 4))

    key_var = tk.StringVar(value=ai_provider.get_api_key())
    key_entry = tk.Entry(key_row, textvariable=key_var, show="•", width=44,
                          bg=theme["BG"], fg=theme["FG"], relief="flat",
                          insertbackground=theme["FG"])
    key_entry.pack(side="left", fill="x", expand=True, ipady=4)

    reveal_var = tk.BooleanVar(value=False)

    def toggle_reveal():
        key_entry.config(show="" if reveal_var.get() else "•")

    tk.Checkbutton(key_row, text="Show", variable=reveal_var, command=toggle_reveal,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI).pack(side="left", padx=(8, 0))

    status_lbl = tk.Label(body, text="", bg=theme["CARD_BG"], fg=theme["MUTED"],
                          font=FONT_UI, wraplength=460, justify="left")
    status_lbl.pack(anchor="w", padx=14, pady=(4, 4))

    def save_key():
        ai_provider.set_api_key(key_var.get())
        provider_var.set(ai_provider.get_provider())  # reflect any auto-detected switch
        status_lbl.config(text="Saved locally.", fg=theme["MUTED"])

    def clear_key():
        ai_provider.clear_api_key()
        key_var.set("")
        status_lbl.config(text="Key cleared.", fg=theme["MUTED"])

    def test_key():
        ai_provider.set_api_key(key_var.get())
        provider_var.set(ai_provider.get_provider())
        status_lbl.config(text="Testing…", fg=theme["MUTED"])
        body.update_idletasks()
        ok, text = ai_provider.ask("Say 'ready' if you can read this.")
        if ok:
            status_lbl.config(text="\u2713 Key works.", fg="#3ba55d")
        else:
            status_lbl.config(text=f"\u2717 {text}", fg="#e5793a")

    def diagnose():
        ai_provider.set_api_key(key_var.get())
        provider_var.set(ai_provider.get_provider())
        status_lbl.config(text="Running diagnostics…", fg=theme["MUTED"])
        body.update_idletasks()
        report = ai_provider.diagnose()

        win = tk.Toplevel(body)
        win.title("AI Assistant Diagnostics")
        win.configure(bg=theme["BG"])
        win.geometry("640x480")

        text_box = tk.Text(win, bg=theme["BG"], fg=theme["FG"], font=("Consolas", 10),
                            wrap="word", relief="flat", padx=10, pady=10)
        text_box.pack(fill="both", expand=True, side="left")
        sb = ttk.Scrollbar(win, command=text_box.yview)
        sb.pack(fill="y", side="right")
        text_box.config(yscrollcommand=sb.set)

        text_box.insert("1.0", report)
        text_box.config(state="normal")  # left editable so the user can select/copy freely

        status_lbl.config(text="Diagnostics complete - see the window that opened.", fg=theme["MUTED"])

    btn_row = tk.Frame(body, bg=theme["CARD_BG"])
    btn_row.pack(anchor="w", padx=14, pady=(0, 10))
    tk.Button(btn_row, text="Save Key", command=save_key,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left")
    tk.Button(btn_row, text="Test Key", command=test_key,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left", padx=8)
    tk.Button(btn_row, text="Diagnose (detailed)", command=diagnose,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left", padx=(0, 8))
    tk.Button(btn_row, text="Clear Key", command=clear_key,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left")


# ---------------------------------------------------------------------------
# Welcome tour
# ---------------------------------------------------------------------------
def _build_tour_section(parent, app, theme):
    body = _section(parent, theme, "✋ Welcome Tour")

    tk.Label(body, text="A short animated walkthrough of TechDrive's categories - shown "
                        "automatically the first time the app is opened.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    def replay():
        from gui import onboarding_tour
        onboarding_tour.show(app)

    tk.Button(body, text="▶ Replay Welcome Tour", command=replay,
              bg=theme["BG"], fg=theme["FG"], relief="flat",
              padx=12, pady=6, cursor="hand2").pack(anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# RGB Accent
# ---------------------------------------------------------------------------
RGB_SPEED_CHOICES = [("Slow", "slow"), ("Normal (default)", "normal"), ("Fast", "fast")]
RGB_COLOR_MODES = [("Rainbow cycle (default)", "rainbow"), ("Match accent color", "static")]
RGB_LINE_STYLES = [("Solid (default)", "solid"), ("Thin transparent line", "line"),
                    ("Soft mist glow", "mist"), ("Fully transparent glass wash", "glass"),
                    ("Pulsing glow", "pulse")]


def _build_rgb_accent_section(parent, app, theme):
    body = _section(parent, theme, "≋ RGB Accent")

    tk.Label(body, text="A slow hue-cycling glow along the top/bottom edges and all four "
                        "corners of the window. Purely decorative, no effect on anything "
                        "functional - runs at ~25fps by default and pauses automatically "
                        "whenever the window is minimized or unfocused, so it costs "
                        "essentially nothing while you're not looking at it.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    enabled_var = tk.BooleanVar(value=db.get_setting("rgb_accent_enabled", False))

    def on_toggle():
        app.set_rgb_accent_enabled(enabled_var.get())
        _set_sub_controls_state(enabled_var.get())

    tk.Checkbutton(body, text="Enable RGB accent", variable=enabled_var, command=on_toggle,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI_BOLD
                    ).pack(anchor="w", padx=14, pady=(0, 10))

    # Everything below is disabled (greyed, non-interactive) while the
    # master switch above is off - no point letting someone fiddle with
    # speed/brightness for an effect that isn't currently showing.
    sub = tk.Frame(body, bg=theme["CARD_BG"])
    sub.pack(fill="x", padx=14, pady=(0, 4))
    sub_widgets = []

    def _set_sub_controls_state(enabled):
        state = "normal" if enabled else "disabled"
        for w in sub_widgets:
            try:
                w.config(state=state)
            except tk.TclError:
                pass

    # --- which parts show ---
    tk.Label(sub, text="Where", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(0, 2))

    edges_var = tk.BooleanVar(value=db.get_setting("rgb_accent_edges_enabled", True))
    corners_var = tk.BooleanVar(value=db.get_setting("rgb_accent_corners_enabled", True))

    cb1 = tk.Checkbutton(sub, text="Edges (top/bottom/left/right)", variable=edges_var,
                    command=lambda: app.set_rgb_accent_edges_enabled(edges_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI)
    cb1.pack(anchor="w", pady=1)
    cb2 = tk.Checkbutton(sub, text="Corners", variable=corners_var,
                    command=lambda: app.set_rgb_accent_corners_enabled(corners_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI)
    cb2.pack(anchor="w", pady=(1, 10))
    sub_widgets += [cb1, cb2]

    # --- speed ---
    tk.Label(sub, text="Speed", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(0, 2))
    speed_var = tk.StringVar(value=db.get_setting("rgb_accent_speed", "normal"))
    for label, value in RGB_SPEED_CHOICES:
        rb = tk.Radiobutton(sub, text=label, variable=speed_var, value=value,
                        command=lambda: app.set_rgb_accent_speed(speed_var.get()),
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"], font=FONT_UI)
        rb.pack(anchor="w", pady=1)
        sub_widgets.append(rb)

    # --- brightness ---
    tk.Label(sub, text="Brightness", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(10, 2))
    brightness_var = tk.DoubleVar(value=db.get_setting("rgb_accent_brightness", 1.0))

    def on_brightness_change(_val):
        app.set_rgb_accent_brightness(round(brightness_var.get(), 2))

    brightness_scale = ttk.Scale(sub, from_=0.3, to=1.0, orient="horizontal",
                                  variable=brightness_var, command=on_brightness_change)
    brightness_scale.pack(fill="x", pady=(0, 10))
    sub_widgets.append(brightness_scale)

    # --- color mode ---
    tk.Label(sub, text="Color", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(0, 2))
    color_mode_var = tk.StringVar(value=db.get_setting("rgb_accent_color_mode", "rainbow"))
    for label, value in RGB_COLOR_MODES:
        rb = tk.Radiobutton(sub, text=label, variable=color_mode_var, value=value,
                        command=lambda: app.set_rgb_accent_color_mode(color_mode_var.get()),
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"], font=FONT_UI)
        rb.pack(anchor="w", pady=1)
        sub_widgets.append(rb)

    # --- edge bar style (solid / thin transparent line / soft mist) ---
    tk.Label(sub, text="Edge bar style", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(10, 2))
    line_style_var = tk.StringVar(value=db.get_setting("rgb_accent_line_style", "solid"))
    for label, value in RGB_LINE_STYLES:
        rb = tk.Radiobutton(sub, text=label, variable=line_style_var, value=value,
                        command=lambda: app.set_rgb_accent_line_style(line_style_var.get()),
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"], font=FONT_UI)
        rb.pack(anchor="w", pady=1)
        sub_widgets.append(rb)

    tk.Label(sub, text="Line/mist opacity", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", pady=(8, 2))
    opacity_var = tk.DoubleVar(value=db.get_setting("rgb_accent_line_opacity", 0.6))

    def on_opacity_change(_val):
        app.set_rgb_accent_line_opacity(round(opacity_var.get(), 2))

    opacity_scale = ttk.Scale(sub, from_=0.1, to=1.0, orient="horizontal",
                               variable=opacity_var, command=on_opacity_change)
    opacity_scale.pack(fill="x", pady=(0, 10))
    sub_widgets.append(opacity_scale)

    _set_sub_controls_state(enabled_var.get())


# ---------------------------------------------------------------------------
# Aero Glass Effect
# ---------------------------------------------------------------------------
def _build_aero_section(parent, app, theme):
    body = _section(parent, theme, "□ Aero Glass Effect")

    tk.Label(body, text="A translucent frosted-glass window backdrop, using the same "
                        "Windows composition API real acrylic/Mica-style apps use. Off by "
                        "default - purely a look, no effect on anything functional. "
                        + ("" if IS_WINDOWS else "Windows only."),
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    status_label = tk.Label(body, bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    status_label.pack(anchor="w", padx=14, pady=(0, 6))

    tk.Label(body, text="Intensity", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(0, 2))

    intensity_var = tk.StringVar(value=db.get_setting("aero_glass_intensity", "light"))

    def on_intensity_change():
        db.set_setting("aero_glass_intensity", intensity_var.get())
        if db.get_setting("aero_glass_enabled", False):
            ok, method = app.apply_aero_glass()
            refresh_status(ok=ok, method=method, enabled=ok)

    tk.Radiobutton(body, text="Light — barely-there, stays readable over any wallpaper "
                              "(recommended)",
                   variable=intensity_var, value="light", command=on_intensity_change,
                   bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                   activebackground=theme["CARD_BG"], font=FONT_UI, wraplength=440,
                   justify="left").pack(anchor="w", padx=24, pady=1)
    tk.Radiobutton(body, text="Classic — heavier, more like real Windows 7 Aero, but text "
                              "can get hard to read over busy wallpapers",
                   variable=intensity_var, value="classic", command=on_intensity_change,
                   bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                   activebackground=theme["CARD_BG"], font=FONT_UI, wraplength=440,
                   justify="left").pack(anchor="w", padx=24, pady=(1, 8))

    def refresh_status(ok=None, method=None, enabled=None):
        if enabled is None:
            enabled = db.get_setting("aero_glass_enabled", False)
        if ok is False:
            status_label.config(text="⚠ Couldn't enable it on this system - your Windows "
                                     "build/desktop compositor may not support it.")
        elif enabled and method:
            label = "Windows backdrop (Windows 11)" if method == "backdrop" else \
                    "Aero blur-behind (Windows 10/11)"
            status_label.config(text=f"Currently: On - {label}")
        else:
            status_label.config(text="Currently: " + ("On" if enabled else "Off"))
        toggle_btn.config(text="Turn Off" if enabled else "Turn On  ✦")

    def toggle():
        currently_on = db.get_setting("aero_glass_enabled", False)
        if currently_on:
            app.set_aero_glass_enabled(False)
            refresh_status(enabled=False)
        else:
            ok, method = app.set_aero_glass_enabled(True)
            refresh_status(ok=ok, method=method, enabled=ok)

    toggle_btn = tk.Button(body, text="Turn On  ✦", command=toggle, bg=theme["BG"],
                           fg=theme["FG"], relief="flat", padx=12, pady=6,
                           cursor="hand2" if IS_WINDOWS else "arrow",
                           state="normal" if IS_WINDOWS else "disabled")
    toggle_btn.pack(anchor="w", padx=14, pady=(0, 12))
    refresh_status()


# ---------------------------------------------------------------------------
# Classic Blue window styling
# ---------------------------------------------------------------------------
def _build_xp_theme_section(parent, app, theme):
    body = _section(parent, theme, "✦ Classic Blue Window Style")

    tk.Label(body, text="An original blue/silver color scheme for TechDrive's own header "
                        "bar, inspired by early-2000s Windows styling - not a copy of any "
                        "Microsoft artwork or asset, just an original color pairing applied "
                        "to this app's own UI. Off by default.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    status_label = tk.Label(body, bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    status_label.pack(anchor="w", padx=14, pady=(0, 6))

    def refresh_status(enabled=None):
        if enabled is None:
            enabled = db.get_setting("xp_theme_enabled", False)
        status_label.config(text="Currently: " + ("On" if enabled else "Off"))
        toggle_btn.config(text="Turn Off" if enabled else "Turn On  ✦")

    def toggle():
        currently_on = db.get_setting("xp_theme_enabled", False)
        app.set_xp_theme_enabled(not currently_on)
        refresh_status(enabled=not currently_on)

    toggle_btn = tk.Button(body, text="Turn On  ✦", command=toggle, bg=theme["BG"],
                           fg=theme["FG"], relief="flat", padx=12, pady=6, cursor="hand2")
    toggle_btn.pack(anchor="w", padx=14, pady=(0, 12))
    refresh_status()


# ---------------------------------------------------------------------------
# Sidebar Gadgets
# ---------------------------------------------------------------------------
def _build_sidebar_gadgets_section(parent, app, theme):
    body = _section(parent, theme, "◇ Vista-inspired Desktop Gadgets")

    tk.Label(body, text="A slim docked panel with a live clock, mini calendar, CPU dial, "
                        "RAM dial, and rotating tips - all original "
                        "artwork drawn by TechDrive itself, not any third-party gadget "
                        "gallery. Off by default; opens as its own always-on-top panel "
                        "docked to the right edge of the screen.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
             justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    status_label = tk.Label(body, bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    status_label.pack(anchor="w", padx=14, pady=(0, 6))

    def refresh_status(enabled=None):
        if enabled is None:
            enabled = db.get_setting("sidebar_gadgets_enabled", False)
        status_label.config(text="Currently: " + ("Shown" if enabled else "Hidden"))
        toggle_btn.config(text="Hide Gadgets" if enabled else "Show Gadgets  ◇")

    def toggle():
        currently_on = db.get_setting("sidebar_gadgets_enabled", False)
        app.set_sidebar_gadgets_enabled(not currently_on)
        refresh_status(enabled=not currently_on)

    toggle_btn = tk.Button(body, text="Show Gadgets  ◇", command=toggle, bg=theme["BG"],
                           fg=theme["FG"], relief="flat", padx=12, pady=6, cursor="hand2")
    toggle_btn.pack(anchor="w", padx=14, pady=(0, 12))
    refresh_status()


def _build_monitor_visual_section(parent, app, theme):
    body = _section(parent, theme, "Monitor & Terminal Visuals")
    tk.Label(
        body,
        text="Choose the display treatment for live monitor charts and terminal-tool output.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        wraplength=460, justify="left",
    ).pack(anchor="w", padx=14, pady=(10, 6))
    selected = db.get_setting("monitor_visual_skin", "standard")
    if selected not in ("standard", "crt", "winamp"):
        selected = "standard"
    mode = tk.StringVar(value=selected)
    for label, value in (
        ("Standard", "standard"),
        ("CRT green phosphor — scanlines and glow", "crt"),
        ("Winamp monitor skin — neon graphs and CPU/RAM equalizer", "winamp"),
    ):
        tk.Radiobutton(
            body, text=label, variable=mode, value=value,
            command=lambda: app.set_monitor_visual_skin(mode.get()),
            bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
            activebackground=theme["CARD_BG"], font=FONT_UI,
            wraplength=460, justify="left", anchor="w",
        ).pack(anchor="w", padx=14, pady=3)
    tk.Label(
        body,
        text="The selected monitor skin updates open live charts immediately. CRT styling is applied to output the next time a terminal tool runs.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        wraplength=460, justify="left",
    ).pack(anchor="w", padx=14, pady=(4, 12))


def _build_screensaver_section(parent, app, theme):
    body = _section(parent, theme, "Live Screensaver")
    tk.Label(
        body,
        text="Mystify and starfield animations respond to live CPU and network activity. Press any key or click to close.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        wraplength=460, justify="left",
    ).pack(anchor="w", padx=14, pady=(10, 8))

    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=(0, 8))
    tk.Label(row, text="Style", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(side="left", padx=(0, 8))
    style = tk.StringVar(value=(
        "Starfield" if db.get_setting("screensaver_style", "mystify") == "starfield"
        else "Mystify"
    ))
    combo = ttk.Combobox(
        row, textvariable=style, state="readonly", width=18,
        values=("Mystify", "Starfield"),
    )
    combo.pack(side="left")

    def save_style(_event=None):
        db.set_setting("screensaver_style",
                       "starfield" if style.get() == "Starfield" else "mystify")

    combo.bind("<<ComboboxSelected>>", save_style)
    idle_row = tk.Frame(body, bg=theme["CARD_BG"])
    idle_row.pack(fill="x", padx=14, pady=(0, 10))
    tk.Label(idle_row, text="Start after idle", bg=theme["CARD_BG"],
             fg=theme["FG"], font=FONT_UI_BOLD).pack(side="left", padx=(0, 8))
    idle = tk.StringVar(value=str(db.get_setting("screensaver_idle_minutes", 0)))
    idle_combo = ttk.Combobox(idle_row, textvariable=idle, state="readonly",
                              width=12, values=("Off", "5 minutes", "10 minutes", "15 minutes"))
    idle_combo.pack(side="left")

    def save_idle(_event=None):
        text = idle.get()
        minutes = 0 if text == "Off" else int(text.split()[0])
        db.set_setting("screensaver_idle_minutes", minutes)
        app.configure_idle_screensaver()

    idle_combo.bind("<<ComboboxSelected>>", save_idle)
    if idle.get().isdigit():
        minutes = int(idle.get())
        idle.set(f"{minutes} minutes" if minutes in (5, 10, 15) else "Off")

    tk.Button(
        body, text="Start Screensaver Now",
        command=app.start_screensaver, bg=theme["BG"], fg=theme["FG"],
        relief="flat", padx=12, pady=6, cursor="hand2",
    ).pack(anchor="w", padx=14, pady=(0, 12))


def _build_achievements_section(parent, app, theme):
    body = _section(parent, theme, "Achievements")
    unlocked = achievements.get_unlocked()
    count = sum(1 for key, _title, _description in achievements.BADGES
                if key in unlocked)
    tk.Label(
        body, text=f"{count} of {len(achievements.BADGES)} badges unlocked",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
    ).pack(anchor="w", padx=14, pady=(10, 6))
    for badge_id, title, description in achievements.BADGES:
        earned = unlocked.get(badge_id)
        row = tk.Frame(body, bg=theme["CARD_BG"])
        row.pack(fill="x", padx=14, pady=4)
        badge_color = theme["ACCENT"] if earned else theme["MUTED"]
        state = "UNLOCKED" if earned else "LOCKED"
        tk.Label(row, text=f"[{state}]", bg=theme["CARD_BG"],
                 fg=badge_color, font=FONT_UI_BOLD, width=11,
                 anchor="w").pack(side="left")
        detail = f"{title} — {description}"
        if earned:
            detail += f"  ({str(earned)[:10]})"
        tk.Label(row, text=detail, bg=theme["CARD_BG"], fg=theme["FG"],
                 font=FONT_UI, wraplength=360, justify="left",
                 anchor="w").pack(side="left", fill="x", expand=True)
    tk.Label(
        body, text="Achievements are stored locally. When UI sounds are enabled, a scheme-matched cue and notification play when a badge is earned.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        wraplength=460, justify="left",
    ).pack(anchor="w", padx=14, pady=(6, 12))


# ---------------------------------------------------------------------------
# Interface & Behavior
# ---------------------------------------------------------------------------
def _build_interface_section(parent, app, theme):
    """Small preferences other parts of the app can read via
    db.get_setting(...) - most take effect immediately where a live app
    hook exists (noted per-row below); the rest are stored preferences
    for now, same honesty tradeoff as the existing Startup section."""
    body = _section(parent, theme, "\U0001fa9f Interface & Behavior")

    def checkbox(key, default, text):
        var = tk.BooleanVar(value=db.get_setting(key, default))
        tk.Checkbutton(body, text=text, variable=var,
                        command=lambda: db.set_setting(key, var.get()),
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"], font=FONT_UI,
                        wraplength=460, justify="left", anchor="w"
                        ).pack(anchor="w", padx=14, pady=3)
        return var

    checkbox("confirm_on_exit", False, "Ask for confirmation before closing TechDrive")
    checkbox("show_tooltips", True, "Show tooltips when hovering over tools and buttons")
    checkbox("compact_mode", False, "Compact mode - tighter spacing, smaller list rows")
    checkbox("remember_last_tab", True, "Reopen the last tab I had open on next launch")
    checkbox("animate_transitions", True, "Animate tab and panel transitions")

    tk.Label(body, text="Default tab on launch", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(8, 2))
    tab_var = tk.StringVar(value=db.get_setting("default_tab", "Dashboard"))
    tab_combo = ttk.Combobox(body, textvariable=tab_var, state="readonly", width=22,
                              values=["Dashboard", "Recent", "Favorites"])
    tab_combo.pack(anchor="w", padx=14, pady=(0, 12))
    tab_combo.bind("<<ComboboxSelected>>", lambda e: db.set_setting("default_tab", tab_var.get()))


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------
def _build_notifications_section(parent, app, theme):
    body = _section(parent, theme, "Notifications")

    enabled_var = tk.BooleanVar(value=db.get_setting("notifications_enabled", True))
    sound_var = tk.BooleanVar(value=db.get_setting("sound_on_complete", True))
    desktop_var = tk.BooleanVar(value=db.get_setting("desktop_notifications", False))
    volume_var = tk.DoubleVar(value=float(db.get_setting("notification_volume", 0.7)))
    filter_var = tk.StringVar(value="All")

    def save_enabled():
        db.set_setting("notifications_enabled", enabled_var.get())

    tk.Checkbutton(body, text="Enable Notification Center", variable=enabled_var, command=save_enabled,
                   bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                   activebackground=theme["CARD_BG"], font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(10, 3))
    tk.Checkbutton(body, text="Play a sound when a long-running tool finishes",
                   variable=sound_var, command=lambda: db.set_setting("sound_on_complete", sound_var.get()),
                   bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                   activebackground=theme["CARD_BG"], font=FONT_UI).pack(anchor="w", padx=14, pady=3)
    tk.Checkbutton(body, text="Show desktop notifications for background tasks",
                   variable=desktop_var, command=lambda: db.set_setting("desktop_notifications", desktop_var.get()),
                   bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                   activebackground=theme["CARD_BG"], font=FONT_UI).pack(anchor="w", padx=14, pady=3)

    tk.Label(body, text="Notification volume", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(8, 2))
    ttk.Scale(body, from_=0.0, to=1.0, orient="horizontal", variable=volume_var,
              command=lambda v: db.set_setting("notification_volume", round(float(v), 2))).pack(fill="x", padx=14, pady=(0, 8))

    actions = tk.Frame(body, bg=theme["CARD_BG"]); actions.pack(fill="x", padx=14, pady=(0, 6))
    def refresh_status():
        count = db.unread_notification_count()
        status.config(text=f"{count} unread notification(s)" if count else "All notifications are read")
    def open_center():
        if not enabled_var.get():
            messagebox.showinfo("Notifications", "Notification Center is disabled. Enable it first.")
            return
        app.open_notifications()
    def mark_read():
        db.mark_all_notifications_read(); refresh_status()
        app._refresh_notification_badge()
    def clear_all():
        if messagebox.askyesno("Clear notifications", "Delete all notification history?"):
            db.clear_notifications(); refresh_status(); app._refresh_notification_badge()
    def test_notification():
        if not enabled_var.get():
            messagebox.showinfo("Notifications", "Enable Notification Center first."); return
        app.notify("Test notification", "TechDrive notification system is working.", kind="success", toast=True)
        refresh_status()
    for text, cmd in (("Open Center", open_center), ("Test", test_notification), ("Mark All Read", mark_read), ("Clear History", clear_all)):
        tk.Button(actions, text=text, command=cmd, bg=theme["BG"], fg=theme["FG"], relief="flat", padx=8).pack(side="left", padx=(0, 5))
    status = tk.Label(body, text="", bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    status.pack(anchor="w", padx=14, pady=(0, 12)); refresh_status()


# ---------------------------------------------------------------------------
# TechDrive UI Sounds
# ---------------------------------------------------------------------------
def _build_sound_section(parent, app, theme):
    body = _section(parent, theme, "TechDrive Sounds")

    tk.Label(
        body,
        text="Choose a sound scheme for startup, shutdown, errors, clicks, notifications, and completed scans. "
             "Sounds are disabled by default. You can replace any event with your own WAV file.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=520,
        justify="left"
    ).pack(anchor="w", padx=14, pady=(10, 8))

    mode_labels = {label: mode for mode, label in sounds.SCHEME_LABELS.items()}
    scheme_var = tk.StringVar(
        value=sounds.SCHEME_LABELS[sounds.get_scheme_mode()]
    )
    scheme_row = tk.Frame(body, bg=theme["CARD_BG"])
    scheme_row.pack(fill="x", padx=14, pady=(0, 4))
    tk.Label(
        scheme_row, text="Sound scheme", bg=theme["CARD_BG"], fg=theme["FG"],
        font=FONT_UI_BOLD,
    ).pack(side="left")
    scheme_menu = ttk.Combobox(
        scheme_row, textvariable=scheme_var,
        values=list(sounds.SCHEME_LABELS.values()),
        state="readonly", width=23,
    )
    scheme_menu.pack(side="left", padx=(12, 0))
    scheme_status = tk.Label(
        body, bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        anchor="w",
    )
    scheme_status.pack(fill="x", padx=14, pady=(0, 8))

    def refresh_scheme_status():
        mode = mode_labels.get(scheme_var.get(), "auto")
        if mode == "auto":
            scheme_status.config(
                text="Follows appearance: XP look → XP sounds; Aero glass → Vista/7 sounds; "
                     "all other appearances → Dark."
            )
        else:
            scheme_status.config(text=f"Using {sounds.SCHEME_LABELS[mode]} sounds.")

    def apply_sound_scheme(_event=None):
        mode = mode_labels.get(scheme_var.get(), "auto")
        sounds.set_scheme_mode(mode)
        refresh_scheme_status()
        for event_name, event_var in source_vars.items():
            refresh_row(event_name, event_var)

    scheme_menu.bind("<<ComboboxSelected>>", apply_sound_scheme)
    refresh_scheme_status()

    enabled_var = tk.BooleanVar(value=sounds.is_enabled())

    def toggle():
        sounds.set_enabled(enabled_var.get())
        state = "Enabled" if enabled_var.get() else "Disabled"
        status.config(text=f"TechDrive sounds: {state}")

    tk.Checkbutton(
        body, text="Enable TechDrive sounds", variable=enabled_var, command=toggle,
        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
        activebackground=theme["CARD_BG"], font=FONT_UI_BOLD
    ).pack(anchor="w", padx=14, pady=(0, 8))

    rows = tk.Frame(body, bg=theme["CARD_BG"])
    rows.pack(fill="x", padx=14, pady=(0, 6))
    source_vars = {}

    def refresh_row(name, label_var):
        custom = sounds.has_custom(name)
        built_in = (
            "Built-in · Auto" if sounds.get_scheme_mode() == "auto"
            else f"Built-in · {sounds.get_active_scheme_label()}"
        )
        label_var.set(
            "Custom WAV" if custom
            else built_in
        )

    for name, title in (
        ("startup", "Startup sound"),
        ("shutdown", "Shutdown sound"),
        ("error", "Error sound"),
        ("click", "Click sound"),
        ("notification", "Notification sound"),
        ("scan_complete", "Scan-complete sound"),
    ):
        row = tk.Frame(rows, bg=theme["CARD_BG"])
        row.pack(fill="x", pady=4)

        tk.Label(row, text=title, bg=theme["CARD_BG"], fg=theme["FG"],
                 font=FONT_UI_BOLD, width=19, anchor="w").pack(side="left")
        source_var = tk.StringVar()
        source_vars[name] = source_var
        refresh_row(name, source_var)
        tk.Label(row, textvariable=source_var, bg=theme["CARD_BG"], fg=theme["MUTED"],
                 font=FONT_UI, width=20, anchor="w").pack(side="left", padx=(0, 6))

        def choose(event_name=name, event_var=source_var):
            path = filedialog.askopenfilename(
                title=f"Choose {event_name} sound",
                filetypes=[("WAV audio", "*.wav"), ("All files", "*.*")],
            )
            if not path:
                return
            try:
                dest = sounds.set_custom(event_name, path)
                refresh_row(event_name, event_var)
                status.config(text=f"Custom {event_name} sound saved: {dest.name}")
            except Exception as exc:
                messagebox.showerror("Sound", str(exc))

        def test(event_name=name):
            if not sounds.play(event_name, force=True):
                messagebox.showwarning(
                    "Sound",
                    "TechDrive could not play this WAV file. Make sure it is a valid WAV file and you are running Windows.",
                )

        def reset(event_name=name, event_var=source_var):
            sounds.reset_custom(event_name)
            refresh_row(event_name, event_var)
            status.config(text=f"{event_name.title()} sound restored to the built-in TechDrive sound.")

        tk.Button(row, text="Choose…", command=choose, bg=theme["BG"], fg=theme["FG"],
                  relief="flat", padx=8).pack(side="left")
        tk.Button(row, text="Test", command=test, bg=theme["BG"], fg=theme["FG"],
                  relief="flat", padx=8).pack(side="left", padx=4)
        tk.Button(row, text="Reset", command=reset, bg=theme["BG"], fg=theme["FG"],
                  relief="flat", padx=8).pack(side="left")

    status = tk.Label(body, text="TechDrive sounds: Enabled" if enabled_var.get() else "TechDrive sounds: Disabled",
                      bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    status.pack(anchor="w", padx=14, pady=(4, 12))


# ---------------------------------------------------------------------------
# Search & Performance
# ---------------------------------------------------------------------------
def _build_search_performance_section(parent, app, theme):
    body = _section(parent, theme, "\u26a1 Search & Performance")

    fuzzy_var = tk.BooleanVar(value=db.get_setting("fuzzy_search_enabled", True))
    tk.Checkbutton(body, text="Fuzzy search (matches close spellings, not just exact text)",
                    variable=fuzzy_var, command=lambda: db.set_setting("fuzzy_search_enabled", fuzzy_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=(10, 3))

    low_power_var = tk.BooleanVar(value=db.get_setting("low_power_mode", False))
    tk.Checkbutton(body, text="Low power mode - throttle background monitors to save CPU",
                    variable=low_power_var, command=lambda: db.set_setting("low_power_mode", low_power_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=3)

    hw_accel_var = tk.BooleanVar(value=db.get_setting("hw_accel_ui", True))
    tk.Checkbutton(body, text="Hardware-accelerated UI effects (aero blur, RGB accent)",
                    variable=hw_accel_var, command=lambda: db.set_setting("hw_accel_ui", hw_accel_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=3)

    tk.Label(body, text="Live monitor refresh rate", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(8, 2))
    refresh_var = tk.StringVar(value=str(db.get_setting("monitor_refresh_ms", 1000)))
    refresh_combo = ttk.Combobox(body, textvariable=refresh_var, state="readonly", width=22,
                                  values=["500", "1000", "2000", "5000"])
    refresh_combo.pack(anchor="w", padx=14, pady=(0, 2))
    tk.Label(body, text="Milliseconds between readings. Lower = smoother graphs, more CPU.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI
             ).pack(anchor="w", padx=14, pady=(0, 6))
    refresh_combo.bind("<<ComboboxSelected>>",
                        lambda e: db.set_setting("monitor_refresh_ms", int(refresh_var.get())))

    tk.Label(body, text="Search history size", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(4, 2))
    hist_var = tk.StringVar(value=str(db.get_setting("search_history_size", 25)))
    hist_combo = ttk.Combobox(body, textvariable=hist_var, state="readonly", width=22,
                               values=["10", "25", "50", "100"])
    hist_combo.pack(anchor="w", padx=14, pady=(0, 12))
    hist_combo.bind("<<ComboboxSelected>>",
                     lambda e: db.set_setting("search_history_size", int(hist_var.get())))

    # Lightweight local performance check.  This measures TechDrive's own
    # process instead of pretending the whole machine's CPU usage is the
    # application's cost.  It is deliberately opt-in and does no stress test.
    perf_label = tk.Label(body, text="Performance check: not run",
                          bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI)
    perf_label.pack(anchor="w", padx=14, pady=(4, 4))

    def run_perf_check():
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            proc.cpu_percent(None)
            rss_before = proc.memory_info().rss
            started = time.perf_counter()
            # A short sleep gives psutil a real sampling window without
            # stressing the machine.
            time.sleep(0.25)
            cpu = proc.cpu_percent(None)
            elapsed = (time.perf_counter() - started) * 1000
            rss = proc.memory_info().rss
            perf_label.config(text=f"TechDrive process: {cpu:.1f}% CPU · {rss / 1048576:.1f} MB RAM · sample {elapsed:.0f} ms")
        except Exception as exc:
            perf_label.config(text=f"Performance check unavailable: {exc}")

    tk.Button(body, text="Run Performance Check", command=run_perf_check,
              bg=theme["BG"], fg=theme["FG"], relief="flat", padx=10).pack(
                  anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# Date, Time & Units
# ---------------------------------------------------------------------------
def _build_datetime_units_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f4c5 Date, Time & Units")

    tk.Label(body, text="Date format", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(10, 2))
    date_var = tk.StringVar(value=db.get_setting("date_format", "YYYY-MM-DD"))
    date_combo = ttk.Combobox(body, textvariable=date_var, state="readonly", width=22,
                               values=["YYYY-MM-DD", "MM/DD/YYYY", "DD/MM/YYYY"])
    date_combo.pack(anchor="w", padx=14, pady=(0, 8))
    date_combo.bind("<<ComboboxSelected>>", lambda e: db.set_setting("date_format", date_var.get()))

    clock_var = tk.BooleanVar(value=db.get_setting("use_24h_clock", True))
    tk.Checkbutton(body, text="Use 24-hour clock (uncheck for 12-hour AM/PM)",
                    variable=clock_var, command=lambda: db.set_setting("use_24h_clock", clock_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=(0, 8))

    tk.Label(body, text="Temperature unit (hardware sensors)", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(0, 2))
    temp_var = tk.StringVar(value=db.get_setting("temp_unit", "C"))

    def on_temp_change():
        db.set_setting("temp_unit", temp_var.get())

    for value, label in [("C", "Celsius (°C)"), ("F", "Fahrenheit (°F)")]:
        tk.Radiobutton(body, text=label, variable=temp_var, value=value, command=on_temp_change,
                        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                        activebackground=theme["CARD_BG"], font=FONT_UI
                        ).pack(anchor="w", padx=24, pady=1)

    tk.Frame(body, bg=theme["CARD_BG"], height=8).pack()


# ---------------------------------------------------------------------------
# Window
# ---------------------------------------------------------------------------
def _build_window_section(parent, app, theme):
    body = _section(parent, theme, "\U0001fa9f Window")

    always_on_top_var = tk.BooleanVar(value=db.get_setting("always_on_top", False))

    def on_always_on_top():
        val = always_on_top_var.get()
        db.set_setting("always_on_top", val)
        try:
            app.attributes("-topmost", val)  # app IS the Tk root (TechDriveApp subclasses tk.Tk)
        except Exception:
            pass

    tk.Checkbutton(body, text="Keep TechDrive window always on top", variable=always_on_top_var,
                    command=on_always_on_top, bg=theme["CARD_BG"], fg=theme["FG"],
                    selectcolor=theme["BG"], activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=(10, 3))

    remember_geom_var = tk.BooleanVar(value=db.get_setting("remember_window_geometry", True))
    tk.Checkbutton(body, text="Remember window size and position between launches",
                    variable=remember_geom_var,
                    command=lambda: db.set_setting("remember_window_geometry", remember_geom_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=3)

    clear_recent_var = tk.BooleanVar(value=db.get_setting("clear_recent_on_exit", False))
    tk.Checkbutton(body, text="Clear the Recent tools list every time TechDrive closes",
                    variable=clear_recent_var,
                    command=lambda: db.set_setting("clear_recent_on_exit", clear_recent_var.get()),
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI
                    ).pack(anchor="w", padx=14, pady=(3, 12))


def _checkbox(body, theme, key, default, text, pady=3, on_change=None):
    """Shared helper for the simple settings sections below - a labeled
    Checkbutton wired straight to db.get_setting/set_setting, with an
    optional extra callback for the rare row that needs a live app hook."""
    var = tk.BooleanVar(value=db.get_setting(key, default))

    def _cmd():
        db.set_setting(key, var.get())
        if on_change:
            on_change(var.get())

    tk.Checkbutton(body, text=text, variable=var, command=_cmd,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"], font=FONT_UI,
                    wraplength=460, justify="left", anchor="w"
                    ).pack(anchor="w", padx=14, pady=pady)
    return var


def _dropdown(body, theme, key, default, label, values, pady=(0, 12), caster=str):
    tk.Label(body, text=label, bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=14, pady=(8, 2))
    var = tk.StringVar(value=str(db.get_setting(key, default)))
    combo = ttk.Combobox(body, textvariable=var, state="readonly", width=22, values=values)
    combo.pack(anchor="w", padx=14, pady=pady)
    combo.bind("<<ComboboxSelected>>", lambda e: db.set_setting(key, caster(var.get())))
    return var


# ---------------------------------------------------------------------------
# Accessibility
# ---------------------------------------------------------------------------
def _build_accessibility_section(parent, app, theme):
    body = _section(parent, theme, "\u267f Accessibility")

    _checkbox(body, theme, "high_contrast_mode", False,
              "High contrast mode - stronger foreground/background separation", pady=(10, 3))
    _checkbox(body, theme, "reduce_motion", False,
              "Reduce motion - skip fades and slide animations app-wide")
    _checkbox(body, theme, "underline_links", False,
              "Underline clickable links and buttons")
    _checkbox(body, theme, "screen_reader_hints", False,
              "Announce extra context for screen readers on dialogs and alerts")
    _checkbox(body, theme, "large_click_targets", False,
              "Larger click targets for buttons and checkboxes")
    _checkbox(body, theme, "bold_text", False,
              "Bold text throughout the interface")
    _checkbox(body, theme, "sticky_focus_outline", False,
              "Keep a visible focus outline on the last-used control")
    _checkbox(body, theme, "flash_instead_of_beep", False,
              "Flash the window instead of playing an alert sound", pady=(3, 12))


# ---------------------------------------------------------------------------
# File Operations
# ---------------------------------------------------------------------------
def _build_file_ops_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f4c1 File Operations")

    _checkbox(body, theme, "confirm_before_delete", True,
              "Ask for confirmation before deleting or wiping files", pady=(10, 3))
    _checkbox(body, theme, "confirm_before_overwrite", True,
              "Ask for confirmation before overwriting an existing file")
    _checkbox(body, theme, "show_hidden_files", False,
              "Show hidden and system files in file pickers")
    _checkbox(body, theme, "use_recycle_bin", True,
              "Send deleted files to the Recycle Bin instead of erasing immediately")
    _checkbox(body, theme, "verify_after_copy", False,
              "Verify file integrity (checksum) after copy/clone operations")
    _checkbox(body, theme, "auto_extract_archives", False,
              "Automatically offer to extract archives after downloading")
    _checkbox(body, theme, "preserve_timestamps_on_copy", True,
              "Preserve original timestamps when copying or cloning files")

    _dropdown(body, theme, "default_export_format", "CSV",
              "Default export format for reports", ["CSV", "JSON", "PDF", "TXT"])
    _dropdown(body, theme, "duplicate_scan_depth", "Normal",
              "Duplicate Finder scan depth", ["Quick", "Normal", "Thorough"], pady=(0, 12))


# ---------------------------------------------------------------------------
# Network & Updates
# ---------------------------------------------------------------------------
def _build_network_updates_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f310 Network & Updates")

    _checkbox(body, theme, "check_updates_on_launch", True,
              "Check for TechDrive updates on launch", pady=(10, 3))
    _checkbox(body, theme, "auto_download_updates", False,
              "Download updates automatically (still asks before installing)")
    _checkbox(body, theme, "metered_connection_aware", True,
              "Pause background network checks on a metered connection")
    _checkbox(body, theme, "use_ipv6", True,
              "Prefer IPv6 for network diagnostics tools when available")
    _checkbox(body, theme, "notify_on_update_available", True,
              "Show a banner when a new update is available")

    _dropdown(body, theme, "update_channel", "Stable",
              "Update channel", ["Stable", "Beta"])
    _dropdown(body, theme, "connection_timeout_s", "10",
              "Network tool timeout (seconds)", ["5", "10", "20", "30"],
              pady=(0, 12), caster=int)


# ---------------------------------------------------------------------------
# Privacy & Data
# ---------------------------------------------------------------------------
def _build_privacy_data_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f512 Privacy & Data")

    _checkbox(body, theme, "clear_clipboard_on_exit", False,
              "Clear the clipboard when TechDrive closes", pady=(10, 3))
    _checkbox(body, theme, "log_tool_usage_locally", True,
              "Keep a local log of which tools were run (used only for the Recent list)")
    _checkbox(body, theme, "mask_sensitive_fields", True,
              "Mask sensitive fields (keys, passwords) in the UI until clicked")
    _checkbox(body, theme, "auto_lock_on_idle", False,
              "Require re-entering the license key after the app is idle")
    _checkbox(body, theme, "anonymize_exported_reports", False,
              "Strip machine name and HWID from exported reports")
    _checkbox(body, theme, "confirm_before_sharing_logs", True,
              "Ask for confirmation before including logs in a support export")

    _dropdown(body, theme, "auto_lock_minutes", "15",
              "Idle time before auto-lock", ["5", "15", "30", "60"], pady=(0, 12), caster=int)


# ---------------------------------------------------------------------------
# Dashboard Display
# ---------------------------------------------------------------------------
def _build_dashboard_display_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f4ca Dashboard Display")

    _checkbox(body, theme, "show_dashboard_graphs", True,
              "Show live CPU/RAM/Disk graphs on the Dashboard", pady=(10, 3))
    _checkbox(body, theme, "show_dashboard_tips", True,
              "Show rotating tips on the Dashboard")
    _checkbox(body, theme, "show_favorites_on_dashboard", True,
              "Show a Favorites shortcut row on the Dashboard")
    _checkbox(body, theme, "show_recent_on_dashboard", True,
              "Show a Recently Used row on the Dashboard")
    _checkbox(body, theme, "grid_view_default", False,
              "Open tool categories in grid view instead of list view by default")
    _checkbox(body, theme, "show_tool_icons", True,
              "Show icons next to tool names in category lists")
    _checkbox(body, theme, "collapse_empty_categories", True,
              "Collapse categories with no favorited or recent tools")

    _dropdown(body, theme, "dashboard_columns", "3",
              "Dashboard tile columns", ["2", "3", "4", "5"], caster=int)
    _dropdown(body, theme, "chart_time_window_min", "5",
              "Live chart time window (minutes)", ["1", "5", "15", "30"],
              pady=(0, 12), caster=int)


# ---------------------------------------------------------------------------
# Advanced
# ---------------------------------------------------------------------------
def _build_advanced_section(parent, app, theme):
    body = _section(parent, theme, "\u2699\ufe0f Advanced")

    tk.Label(body, text="These affect how tools run under the hood. Leave at defaults "
                         "unless you have a specific reason to change them.",
              bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
              justify="left").pack(anchor="w", padx=14, pady=(10, 8))

    _checkbox(body, theme, "verbose_logging", False,
              "Verbose logging (more detail in diagnostics/log exports)")
    _checkbox(body, theme, "enable_experimental_tools", False,
              "Enable experimental tools still in testing")
    _checkbox(body, theme, "auto_retry_failed_ops", True,
              "Automatically retry a failed operation once before reporting an error")
    _checkbox(body, theme, "parallel_scans", True,
              "Run disk/duplicate scans on multiple threads when possible")
    _checkbox(body, theme, "skip_system_protected_paths", True,
              "Skip OS-protected paths during scans instead of prompting for elevation")
    _checkbox(body, theme, "cache_scan_results", True,
              "Cache scan results between runs to speed up repeated scans")
    _checkbox(body, theme, "warn_on_low_disk_before_scan", True,
              "Warn if free disk space is low before starting a scan")

    _dropdown(body, theme, "max_worker_threads", "4",
              "Max worker threads for scans", ["1", "2", "4", "8"], caster=int)
    _dropdown(body, theme, "log_retention_days", "30",
              "Keep local logs for", ["7", "30", "90", "365"], caster=int)
    _dropdown(body, theme, "scan_priority", "Normal",
              "Background scan CPU priority", ["Low", "Normal", "High"], pady=(0, 12))


# ---------------------------------------------------------------------------
# Keyboard & Shortcuts
# ---------------------------------------------------------------------------
def _build_keyboard_section(parent, app, theme):
    body = _section(parent, theme, "\u2328\ufe0f Keyboard & Shortcuts")

    _checkbox(body, theme, "enable_keyboard_shortcuts", True,
              "Enable keyboard shortcuts app-wide", pady=(10, 3))
    _checkbox(body, theme, "ctrl_w_closes_tab", True,
              "Ctrl+W closes the current tool tab")
    _checkbox(body, theme, "ctrl_tab_cycles_tabs", True,
              "Ctrl+Tab cycles between open tabs")
    _checkbox(body, theme, "quick_search_hotkey_enabled", True,
              "Global hotkey opens Quick Search from anywhere in the app")
    _checkbox(body, theme, "esc_closes_dialogs", True,
              "Esc closes the active dialog or popup")
    _checkbox(body, theme, "numpad_shortcuts", False,
              "Enable numpad-based shortcuts for common tools")
    _checkbox(body, theme, "hold_to_confirm_destructive", False,
              "Require holding the button (instead of one click) on destructive actions")

    _dropdown(body, theme, "quick_search_hotkey", "Ctrl+K",
              "Quick Search hotkey", ["Ctrl+K", "Ctrl+Space", "Alt+Space", "F2"], pady=(0, 12))


# ---------------------------------------------------------------------------
# Security
# ---------------------------------------------------------------------------
def _build_security_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f6e1\ufe0f Security")

    _checkbox(body, theme, "require_confirm_for_wipe_tools", True,
              "Require typing \"CONFIRM\" before running Shredder/Wipe tools", pady=(10, 3))
    _checkbox(body, theme, "warn_on_elevated_actions", True,
              "Warn before an action that requests elevated/admin privileges")
    _checkbox(body, theme, "auto_lock_password_tools", False,
              "Require re-entering the license key before opening Password Tools")
    _checkbox(body, theme, "encrypt_local_settings_backup", False,
              "Encrypt exported settings backups with your license key")
    _checkbox(body, theme, "disable_devmode_gestures", False,
              "Disable the hidden developer-mode click gesture entirely")
    _checkbox(body, theme, "lock_settings_tab", False,
              "Require the license key to reopen the Settings tab")

    _dropdown(body, theme, "password_tool_min_length", "12",
              "Minimum length suggested by Password Tools", ["8", "12", "16", "20"],
              caster=int, pady=(0, 12))


# ---------------------------------------------------------------------------
# Appearance Extras
# ---------------------------------------------------------------------------
def _build_appearance_extras_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f3a8 Appearance Extras")

    _checkbox(body, theme, "rounded_corners", True,
              "Rounded corners on cards and panels", pady=(10, 3))
    _checkbox(body, theme, "show_category_icons", True,
              "Show category icons in the sidebar")
    _checkbox(body, theme, "colorize_status_text", True,
              "Colorize status text (green/amber/red) instead of plain text")
    _checkbox(body, theme, "show_watermark_in_free_tier", True,
              "Show the small \"Free Tier\" watermark on report exports")
    _checkbox(body, theme, "dim_disabled_controls", True,
              "Dim controls that are unavailable in the current tier")
    _checkbox(body, theme, "show_card_shadows", True,
              "Show drop shadows under cards and panels")
    _checkbox(body, theme, "compact_scrollbars", False,
              "Use thinner scrollbars throughout the app")

    _dropdown(body, theme, "card_corner_radius", "8",
              "Card corner radius (px)", ["0", "4", "8", "12", "16"], caster=int)
    _dropdown(body, theme, "sidebar_width", "220",
              "Sidebar width (px)", ["180", "220", "260", "300"], caster=int, pady=(0, 12))


# ---------------------------------------------------------------------------
# Tool Behavior
# ---------------------------------------------------------------------------
def _build_tool_behavior_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f527 Tool Behavior")

    _checkbox(body, theme, "auto_open_report_after_scan", True,
              "Automatically open the report after a scan/test finishes", pady=(10, 3))
    _checkbox(body, theme, "keep_tool_tabs_open", True,
              "Keep tool tabs open after switching away instead of closing them")
    _checkbox(body, theme, "auto_save_tool_state", True,
              "Remember unsaved input in a tool if you navigate away and back")
    _checkbox(body, theme, "warn_on_long_running_tool", True,
              "Warn before starting a tool known to take several minutes")
    _checkbox(body, theme, "auto_close_after_export", False,
              "Auto-close a tool's panel once its export finishes")
    _checkbox(body, theme, "show_advanced_options_by_default", False,
              "Expand \"Advanced options\" sections in tools by default")
    _checkbox(body, theme, "confirm_before_closing_unsaved_tool", True,
              "Confirm before closing a tool tab with unsaved input")

    _dropdown(body, theme, "benchmark_test_duration_s", "30",
              "Default benchmark test duration (seconds)", ["10", "30", "60", "120"],
              caster=int, pady=(0, 12))


# ---------------------------------------------------------------------------
# Logging & Diagnostics
# ---------------------------------------------------------------------------
def _build_diagnostics_section(parent, app, theme):
    body = _section(parent, theme, "\U0001fa7a Logging & Diagnostics")

    _checkbox(body, theme, "auto_generate_crash_reports", True,
              "Automatically generate a local crash report if TechDrive crashes", pady=(10, 3))
    _checkbox(body, theme, "include_system_info_in_reports", True,
              "Include basic system info (OS, RAM, CPU model) in exported reports")
    _checkbox(body, theme, "keep_previous_session_log", True,
              "Keep the previous session's log file instead of overwriting it")
    _checkbox(body, theme, "timestamp_every_log_line", True,
              "Timestamp every line in diagnostic logs")
    _checkbox(body, theme, "redact_paths_in_logs", False,
              "Redact full file paths in exported logs, keeping only file names")
    _checkbox(body, theme, "auto_open_log_folder_after_export", False,
              "Open the containing folder after exporting a log or report")

    _dropdown(body, theme, "log_verbosity", "Normal",
              "Log verbosity", ["Minimal", "Normal", "Verbose", "Debug"])
    _dropdown(body, theme, "diagnostics_export_format", "TXT",
              "Diagnostics export format", ["TXT", "JSON", "PDF"], pady=(0, 12))

    # Practical diagnostics controls: users can inspect/export the same logs
    # that TechDrive uses internally without needing to browse AppData.
    actions = tk.Frame(body, bg=theme["CARD_BG"])
    actions.pack(fill="x", padx=14, pady=(0, 14))

    def log_folder():
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
        path = os.path.join(base, "TechDrive", "logs")
        try:
            os.makedirs(path, exist_ok=True)
            if IS_WINDOWS:
                os.startfile(path)
            elif sys.platform == "darwin":
                import subprocess; subprocess.Popen(["open", path])
            else:
                import subprocess; subprocess.Popen(["xdg-open", path])
        except Exception as e:
            messagebox.showerror("Diagnostics", f"Could not open log folder:\n{e}")

    def export_log():
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
        src = os.path.join(base, "TechDrive", "logs", "techdrive.log")
        if not os.path.exists(src):
            messagebox.showinfo("Diagnostics", "No TechDrive log has been created yet.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".log",
                                             filetypes=[("TechDrive log", "*.log"), ("Text", "*.txt")],
                                             initialfile="techdrive_diagnostics.log")
        if not path: return
        try:
            import shutil; shutil.copy2(src, path)
            messagebox.showinfo("Diagnostics", f"Diagnostic log exported to:\n{path}")
            if db.get_setting("auto_open_log_folder_after_export", False):
                log_folder()
        except Exception as e:
            messagebox.showerror("Diagnostics", f"Export failed:\n{e}")

    tk.Button(actions, text="Open Log Folder", command=log_folder, bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left")
    tk.Button(actions, text="Export Current Log", command=export_log, bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left", padx=8)
    tk.Label(body, text="Logs are local to this PC and rotate automatically to limit disk usage.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI).pack(anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# System Integration
# ---------------------------------------------------------------------------
def _build_system_integration_section(parent, app, theme):
    body = _section(parent, theme, "\U0001f5a5\ufe0f System Integration")

    _checkbox(body, theme, "add_context_menu_entries", False,
              "Add \"Scan with TechDrive\" to the Windows right-click menu", pady=(10, 3))
    _checkbox(body, theme, "register_default_archive_handler", False,
              "Offer TechDrive as a handler for common archive formats")
    _checkbox(body, theme, "show_in_system_tray", False,
              "Show a system tray icon while TechDrive is running",
              on_change=lambda _v: getattr(app, "_tray", None) and app._tray.sync())
    _checkbox(body, theme, "close_to_tray", False,
              "Closing the window minimizes to tray instead of quitting")
    _checkbox(body, theme, "associate_techdrive_project_files", False,
              "Associate .tdproj files with TechDrive")
    _checkbox(body, theme, "launch_minimized", False,
              "Launch TechDrive minimized to taskbar/tray")
    _checkbox(body, theme, "single_instance_only", True,
              "Prevent more than one TechDrive window from running at once")
    _checkbox(body, theme, "check_disk_space_before_launch", False,
              "Warn on launch if the system drive is critically low on space")

    _dropdown(body, theme, "tray_click_action", "Restore Window",
              "Tray icon single-click action",
              ["Restore Window", "Show Dashboard", "Show Quick Search"], pady=(0, 12))


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------
def _read_startup_enabled():
    if not IS_WINDOWS:
        return db.get_setting("launch_on_startup", False)
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY, 0, winreg.KEY_READ) as key:
            winreg.QueryValueEx(key, STARTUP_VALUE_NAME)
            return True
    except (FileNotFoundError, OSError):
        return False


def _set_startup_enabled(enabled):
    db.set_setting("launch_on_startup", enabled)
    if not IS_WINDOWS:
        return  # nothing more to do off Windows - preference is just stored
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY, 0, winreg.KEY_WRITE) as key:
        if enabled:
            if "__compiled__" in globals():
                # Nuitka build: sys.executable is the temp-extracted copy in
                # onefile mode; sys.argv[0] is the real TechDrive.exe path.
                exe = os.path.abspath(sys.argv[0])
                command = f'"{exe}"'
            else:
                exe = sys.executable
                script = os.path.abspath(sys.argv[0]) if not getattr(sys, "frozen", False) else exe
                command = f'"{exe}" "{script}"' if not getattr(sys, "frozen", False) else f'"{exe}"'
            winreg.SetValueEx(key, STARTUP_VALUE_NAME, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, STARTUP_VALUE_NAME)
            except FileNotFoundError:
                pass


def _build_startup_section(parent, app, theme):
    body = _section(parent, theme, f"→ {t('settings.startup.title')}")

    startup_var = tk.BooleanVar(value=_read_startup_enabled())
    tray_var = tk.BooleanVar(value=db.get_setting("minimize_to_tray", False))
    post_var = tk.BooleanVar(value=db.get_setting("boot_post_enabled", False))

    def on_startup_toggle():
        try:
            _set_startup_enabled(startup_var.get())
        except Exception as e:
            messagebox.showerror("Startup", f"Could not update startup setting: {e}")
            startup_var.set(not startup_var.get())

    def on_tray_toggle():
        db.set_setting("minimize_to_tray", tray_var.get())
        if tray_var.get():
            # Minimizing to tray needs an actual tray icon to minimize to -
            # turn that on too rather than silently doing nothing.
            db.set_setting("show_in_system_tray", True)
        if hasattr(app, "_tray") and app._tray is not None:
            app._tray.sync()

    def on_post_toggle():
        db.set_setting("boot_post_enabled", post_var.get())

    tk.Checkbutton(body, text=t("settings.startup.launch_on_startup") + ("" if IS_WINDOWS else " (Windows only)"),
                    variable=startup_var, command=on_startup_toggle,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"],
                    state="normal" if IS_WINDOWS else "disabled").pack(anchor="w", padx=14, pady=(10, 2))

    tk.Checkbutton(body, text=t("settings.startup.minimize_to_tray"),
                    variable=tray_var, command=on_tray_toggle,
                    bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
                    activebackground=theme["CARD_BG"]).pack(anchor="w", padx=14, pady=(2, 6))

    tk.Checkbutton(
        body, text="Show BIOS-style hardware report at startup (off by default)",
        variable=post_var, command=on_post_toggle,
        bg=theme["CARD_BG"], fg=theme["FG"], selectcolor=theme["BG"],
        activebackground=theme["CARD_BG"],
    ).pack(anchor="w", padx=14, pady=(2, 4))
    tk.Label(
        body,
        text="Shows live CPU, memory, and mounted-drive readings. This is an informational screen, not a firmware test.",
        bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI,
        wraplength=460, justify="left",
    ).pack(anchor="w", padx=14, pady=(0, 10))

    tray_note = ("" if TrayIcon.available() else
                 t("settings.startup.tray_unavailable"))
    if tray_note:
        tk.Label(body, text=tray_note,
                  bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=460,
                  justify="left").pack(anchor="w", padx=14, pady=(0, 12))


# ---------------------------------------------------------------------------
# Backup / Restore
# ---------------------------------------------------------------------------
def _build_backup_section(parent, app, theme):
    body = _section(parent, theme, f"▤ {t('settings.backup.title')}")
    tk.Label(body, text="Backups include settings, favorites, notification history, diagnostics, sensor history, and snapshots. Backups are versioned and written atomically.",
             bg=theme["CARD_BG"], fg=theme["MUTED"], font=FONT_UI, wraplength=520,
             justify="left").pack(anchor="w", padx=14, pady=(10, 4))
    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=12)

    def do_backup():
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("JSON", "*.json")],
                                             initialfile="techdrive_settings_backup.json")
        if not path:
            return
        try:
            db.export_backup(path)
            messagebox.showinfo("Backup", f"Settings backed up to:\n{path}")
        except Exception as e:
            messagebox.showerror("Backup", f"Backup failed: {e}")

    def do_restore():
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            db.import_backup(path)
            messagebox.showinfo("Restore", "Settings restored. Reopening Settings tab...")
            app.refresh_settings_tab()
        except Exception as e:
            messagebox.showerror("Restore", f"Restore failed: {e}")

    tk.Button(row, text="Backup Settings to JSON", command=do_backup,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left")
    tk.Button(row, text="Restore from Backup", command=do_restore,
              bg=theme["BG_LIGHT"], fg=theme["FG"], relief="flat", padx=10).pack(side="left", padx=8)


# ---------------------------------------------------------------------------
# Reset
# ---------------------------------------------------------------------------
def _build_reset_section(parent, app, theme):
    body = _section(parent, theme, f"\u26a0\ufe0f {t('settings.reset.title')}")
    row = tk.Frame(body, bg=theme["CARD_BG"])
    row.pack(fill="x", padx=14, pady=12)

    def do_reset():
        if not messagebox.askyesno(
            "Reset Settings",
            "This clears all settings, favorites, and recently-used history "
            "(your license stays active). Continue?",
        ):
            return
        db.reset_all()
        messagebox.showinfo("Reset", "Settings reset to default.")
        app.refresh_settings_tab()
        app._refresh_tool_widgets()

    tk.Button(row, text="Reset All Settings", command=do_reset,
              bg="#c0392b", fg="white", relief="flat", padx=10).pack(side="left")
