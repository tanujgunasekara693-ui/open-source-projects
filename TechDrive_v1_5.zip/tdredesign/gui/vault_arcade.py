"""Achievement-gated Minesweeper mini-game for the TechDrive Vault."""

import tkinter as tk

from gui import fluent as fl
from gui.minesweeper_logic import MinesweeperBoard
from gui.widgets import FluentButton, GlassCard
from shared import database as db


VAULT_DISCOVERY_PROGRESS_KEY = "vault_core_explorer_steps"
CORE_EXPLORER_ACHIEVEMENT_KEY = "achievement_core_explorer_unlocked"
SIGNAL_SLEUTH_ACHIEVEMENT_KEY = "achievement_signal_sleuth_unlocked"
VAULT_DISCOVERY_STEPS = (
    ("Hardware Inventory", "Inspect the machine's installed components."),
    ("Performance Lab", "Review the system's performance tools."),
    ("Diagnostic Engine", "Explore local health checks and diagnostics."),
)


class VaultArcadePage(tk.Frame):
    """Locked Vault arcade page with a persistent achievement checklist."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._unlocked_view_built = False
        self._build_shell()
        self.refresh_progress()

    def _build_shell(self):
        header = tk.Frame(self, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(20, 8))
        tk.Label(
            header, text="TECHDRIVE CORE  /  ARCADE",
            bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
        ).pack(anchor="w")
        tk.Label(
            header, text="Hidden game: Signal Sweep",
            bg=self.theme["BG"], fg=self.theme["FG"],
            font=fl.F_TITLE(),
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Explore three TechDrive tools to earn the Core Explorer achievement and reveal the game.",
            bg=self.theme["BG"], fg=self.theme["MUTED"],
            font=fl.F_SMALL(), wraplength=880, justify="left",
        ).pack(anchor="w", pady=(3, 0))
        self.content = tk.Frame(self, bg=self.theme["BG"])
        self.content.pack(fill="both", expand=True, padx=24, pady=10)

    def _clear_content(self):
        for child in self.content.winfo_children():
            child.destroy()

    def _progress(self):
        values = db.get_setting(VAULT_DISCOVERY_PROGRESS_KEY, [])
        if not isinstance(values, (list, tuple, set)):
            return set()
        return {str(value) for value in values}

    def refresh_progress(self):
        progress = self._progress()
        earned = bool(db.get_setting(CORE_EXPLORER_ACHIEVEMENT_KEY, False))
        earned = earned or all(title in progress for title, _ in VAULT_DISCOVERY_STEPS)
        try:
            self.master.tab(self, text="SIGNAL SWEEP" if earned else "???")
        except (tk.TclError, AttributeError):
            pass

        if earned:
            if not self._unlocked_view_built:
                self._clear_content()
                self._build_unlocked()
                self._unlocked_view_built = True
            else:
                self._update_signal_achievement()
            return

        self._clear_content()
        self._build_locked(progress)

    def _build_locked(self, progress):
        progress_count = len({
            title for title, _ in VAULT_DISCOVERY_STEPS if title in progress
        })
        card = GlassCard(
            self.content, self.theme, aero=self.aero,
            accent=self.theme["ACCENT"], gradient=True,
        )
        card.pack(fill="x", pady=6)
        tk.Label(
            card.body, text="ACHIEVEMENT  /  CORE EXPLORER",
            bg=card.fill, fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
        ).pack(anchor="w", padx=16, pady=(14, 6))
        tk.Label(
            card.body,
            text=f"Research tools visited: {progress_count} / {len(VAULT_DISCOVERY_STEPS)}",
            bg=card.fill, fg=self.theme["FG"], font=fl.F_CARD_TITLE(),
        ).pack(anchor="w", padx=16, pady=(0, 7))

        for title, description in VAULT_DISCOVERY_STEPS:
            complete = title in progress
            row = tk.Frame(card.body, bg=card.fill)
            row.pack(fill="x", padx=16, pady=3)
            tk.Label(
                row, text="✓" if complete else "○",
                bg=card.fill, fg="#65d58b" if complete else self.theme["MUTED"],
                font=fl.F_BODY(),
            ).pack(side="left", padx=(0, 8))
            tk.Label(
                row, text=f"{title} — {description}",
                bg=card.fill, fg=self.theme["FG"] if complete else self.theme["MUTED"],
                font=fl.F_BODY(), anchor="w", justify="left",
            ).pack(side="left", fill="x", expand=True)

        tk.Label(
            card.body,
            text="The game stays locked until all three tools have been opened. Progress is saved locally.",
            bg=card.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=800, justify="left",
        ).pack(anchor="w", padx=16, pady=(9, 14))

    def _build_unlocked(self):
        achievement = GlassCard(
            self.content, self.theme, aero=self.aero,
            accent="#69d996", gradient=True,
        )
        achievement.pack(fill="x", pady=6)
        tk.Label(
            achievement.body, text="ACHIEVEMENT UNLOCKED  /  CORE EXPLORER",
            bg=achievement.fill, fg="#65d58b", font=fl.F_TINY(),
        ).pack(anchor="w", padx=16, pady=(13, 4))
        self.core_description = tk.Label(
            achievement.body,
            text="You explored hardware, performance, and diagnostics. Signal Sweep is now unlocked.",
            bg=achievement.fill, fg=self.theme["FG"], font=fl.F_BODY(),
            wraplength=800, justify="left",
        )
        self.core_description.pack(anchor="w", padx=16, pady=(2, 7))
        FluentButton(
            achievement.body, "COPY ACHIEVEMENT",
            theme=self.theme, aero=self.aero, kind="standard",
            width=170, height=32, command=self._copy_core_achievement,
            backdrop=achievement.fill,
        ).pack(anchor="w", padx=16, pady=(0, 13))

        game_card = GlassCard(
            self.content, self.theme, aero=self.aero,
            accent=self.theme["ACCENT2"], gradient=False,
        )
        game_card.pack(fill="both", expand=True, pady=6)
        tk.Label(
            game_card.body, text="SIGNAL SWEEP  /  MINESWEEPER",
            bg=game_card.fill, fg=self.theme["ACCENT_GLOW"],
            font=fl.F_CARD_TITLE(),
        ).pack(anchor="w", padx=16, pady=(13, 3))
        tk.Label(
            game_card.body,
            text="Left-click to scan a cell. Right-click to flag a suspected signal. The first scan is safe.",
            bg=game_card.fill, fg=self.theme["MUTED"],
            font=fl.F_SMALL(), wraplength=800, justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 5))

        toolbar = tk.Frame(game_card.body, bg=game_card.fill)
        toolbar.pack(fill="x", padx=16, pady=(4, 5))
        self.game_status = tk.StringVar(value="Scan a cell to begin.")
        tk.Label(
            toolbar, textvariable=self.game_status,
            bg=game_card.fill, fg=self.theme["FG"], font=fl.F_BODY(),
        ).pack(side="left", fill="x", expand=True)
        FluentButton(
            toolbar, "NEW BOARD", theme=self.theme, aero=self.aero,
            kind="standard", width=112, height=30, command=self._new_board,
            backdrop=game_card.fill,
        ).pack(side="right")

        self.board = MinesweeperBoard()
        self.cells = []
        board_frame = tk.Frame(game_card.body, bg=game_card.fill)
        board_frame.pack(anchor="w", padx=16, pady=(0, 10))
        for row in range(self.board.rows):
            row_cells = []
            for column in range(self.board.columns):
                cell = tk.Button(
                    board_frame, text="", width=2, height=1,
                    bg=self.theme["SURFACE"], fg=self.theme["FG"],
                    activebackground=self.theme["ACCENT"],
                    activeforeground="#ffffff", relief="flat", bd=0,
                    font=("Segoe UI", 10, "bold"), cursor="hand2",
                    command=lambda r=row, c=column: self._reveal(r, c),
                )
                cell.grid(row=row, column=column, padx=2, pady=2)
                cell.bind(
                    "<Button-3>",
                    lambda event, r=row, c=column: self._toggle_flag(r, c),
                )
                row_cells.append(cell)
            self.cells.append(row_cells)

        self.signal_achievement = tk.Label(
            game_card.body, text="", bg=game_card.fill,
            fg="#65d58b", font=fl.F_SMALL(),
        )
        self.signal_achievement.pack(anchor="w", padx=16, pady=(0, 12))
        self._update_signal_achievement()
        self._render_board()

    def _copy_core_achievement(self):
        text = (
            "TechDrive achievement unlocked: Core Explorer — "
            "I explored Hardware Inventory, Performance Lab, and Diagnostic Engine."
        )
        self._copy_text(text)

    def _copy_text(self, text):
        try:
            self.app.clipboard_clear()
            self.app.clipboard_append(text)
            self.app.update_idletasks()
            self.app.show_toast("Achievement copied to clipboard.", kind="success")
        except Exception:
            pass

    def _new_board(self):
        self.board.reset()
        self.game_status.set("Scan a cell to begin.")
        self._render_board()

    def _reveal(self, row, column):
        result = self.board.reveal(row, column)
        if result == "mine":
            self.game_status.set("Signal lost. Start a new board to try again.")
        elif result == "won":
            self.game_status.set("All clear — you found every safe signal.")
            self._award_signal_sleuth()
        elif result == "revealed":
            self.game_status.set(
                f"Scanned {len(self.board.revealed)} safe cells. "
                f"Flags: {len(self.board.flagged)} / {self.board.mine_count}."
            )
        self._render_board()

    def _toggle_flag(self, row, column):
        if self.board.toggle_flag(row, column):
            self.game_status.set(
                f"Flags: {len(self.board.flagged)} / {self.board.mine_count}."
            )
            self._render_board()
        return "break"

    def _render_board(self):
        number_colors = {
            1: "#68a8ff", 2: "#65d58b", 3: "#ff7777",
            4: "#c49bff", 5: "#ffae63", 6: "#65d9d3",
            7: self.theme["FG"], 8: self.theme["MUTED"],
        }
        for row in range(self.board.rows):
            for column in range(self.board.columns):
                cell = (row, column)
                button = self.cells[row][column]
                if cell in self.board.revealed:
                    count = self.board.neighboring_mines(row, column)
                    text = str(count) if count else ""
                    button.configure(
                        text=text, state="disabled",
                        disabledforeground=number_colors.get(count, self.theme["FG"]),
                        bg=self.theme["BG_LIGHT"],
                    )
                elif cell in self.board.flagged:
                    button.configure(
                        text="F", state="normal", fg="#ffca66",
                        bg=self.theme["SURFACE"],
                    )
                elif self.board.game_over and cell in self.board.mines:
                    button.configure(
                        text="*", state="disabled", fg="#ff7777",
                        disabledforeground="#ff7777", bg=self.theme["BG_LIGHT"],
                    )
                else:
                    button.configure(
                        text="", state="normal", fg=self.theme["FG"],
                        bg=self.theme["SURFACE"],
                    )

    def _award_signal_sleuth(self):
        if db.get_setting(SIGNAL_SLEUTH_ACHIEVEMENT_KEY, False):
            return
        db.set_setting(SIGNAL_SLEUTH_ACHIEVEMENT_KEY, True)
        self._update_signal_achievement()
        try:
            self.app.notify(
                "Achievement unlocked",
                "Signal Sleuth — you cleared a Signal Sweep board.",
                kind="success",
            )
        except Exception:
            pass

    def _update_signal_achievement(self):
        if not hasattr(self, "signal_achievement"):
            return
        earned = bool(db.get_setting(SIGNAL_SLEUTH_ACHIEVEMENT_KEY, False))
        if earned:
            self.signal_achievement.configure(
                text="Achievement unlocked: Signal Sleuth — copy and share your find.",
            )
            if not getattr(self, "_signal_copy_button", None):
                self._signal_copy_button = FluentButton(
                    self.signal_achievement.master, "COPY SIGNAL SLEUTH",
                    theme=self.theme, aero=self.aero, kind="standard",
                    width=170, height=30,
                    command=lambda: self._copy_text(
                        "TechDrive achievement unlocked: Signal Sleuth — "
                        "I cleared the Signal Sweep Minesweeper board."
                    ),
                    backdrop=self.signal_achievement.master.cget("bg"),
                )
                self._signal_copy_button.pack(anchor="w", padx=16, pady=(0, 12))
        else:
            self.signal_achievement.configure(text="")