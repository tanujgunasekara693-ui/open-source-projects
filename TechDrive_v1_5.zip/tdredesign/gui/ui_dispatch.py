"""Small Tk-safe bridge for background workers.

Tkinter widgets must only be touched from the main thread.  Background
workers therefore put callbacks into this queue; TechDriveApp pumps the
queue from its normal Tk event loop.
"""
from __future__ import annotations
import queue
import threading

_QUEUE = queue.Queue()


def post(callback):
    """Queue a zero-argument callback for execution on Tk's main thread.
    This function deliberately does not touch Tk, so it is safe in workers.
    """
    if callback is not None:
        _QUEUE.put(callback)


def drain(limit=64):
    """Execute up to *limit* queued callbacks. Returns executed count."""
    count = 0
    while count < limit:
        try:
            callback = _QUEUE.get_nowait()
        except queue.Empty:
            break
        try:
            callback()
        except Exception:
            # A destroyed/closing page must never kill the UI pump.
            pass
        count += 1
    return count


def call_sync(callback):
    """Run a callback on Tk's main thread and synchronously return its result.

    This is specifically for operations such as native file/message/simple
    dialogs that must be created by Tk's UI thread.  Worker threads may call
    this safely; the callback is queued and the worker waits while Tk runs it.
    Calls already made on the UI thread execute immediately.
    """
    if threading.current_thread() is threading.main_thread():
        return callback()

    done = threading.Event()
    state = {}

    def invoke():
        try:
            state["result"] = callback()
        except BaseException as exc:
            state["error"] = exc
        finally:
            done.set()

    post(invoke)
    done.wait()
    error = state.get("error")
    if error is not None:
        raise error
    return state.get("result")
