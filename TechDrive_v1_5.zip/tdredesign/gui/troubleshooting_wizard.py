#!/usr/bin/env python3
"""
TechDrive Troubleshooting Wizard
================================

Read-only, evidence-based troubleshooting workflows.  The first wizard is
Internet Problems.  It runs real Windows networking queries and keeps the
raw command output visible so a technician can review exactly what happened.
No network setting is changed by this page.
"""

import platform
import subprocess
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard


IS_WINDOWS = platform.system() == "Windows"
POWERSHELL = (
    "powershell -NoProfile -NonInteractive "
    "-ExecutionPolicy Bypass -Command"
)


def _run_argv(argv, timeout=30):
    try:
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip()
        return {
            "ok": result.returncode == 0,
            "output": output or f"(no output, exit code {result.returncode})",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "output": "Command timed out."}
    except FileNotFoundError:
        return {"ok": False, "output": f"{argv[0]} is not available on this PC."}
    except Exception as exc:
        return {"ok": False, "output": f"{type(exc).__name__}: {exc}"}


def _powershell(script, timeout=30):
    return _run_argv(
        [
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            script,
        ],
        timeout=timeout,
    )


def _unavailable():
    return {
        "ok": False,
        "output": (
            "Windows-only check. No diagnostic command was executed on this "
            "operating system."
        ),
    }


def _adapter_detection():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-NetAdapter -Physical -ErrorAction Stop); "
        "if ($items.Count -eq 0) { "
        "  Write-Output 'No physical network adapters were returned.'; exit 2 "
        "}; "
        "$items | Select-Object Name,InterfaceDescription,Status,MacAddress,"
        "LinkSpeed | Format-Table -AutoSize | Out-String -Width 200",
        timeout=30,
    )


def _link_status():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-NetAdapter -Physical -ErrorAction Stop); "
        "$items | Select-Object Name,Status,MediaConnectionState,LinkSpeed,"
        "ReceiveLinkSpeed,TransmitLinkSpeed | Format-Table -AutoSize "
        "-Wrap | Out-String -Width 200; "
        "$up = @($items | Where-Object {$_.Status -eq 'Up'}); "
        "if ($up.Count -eq 0) { exit 2 }",
        timeout=30,
    )


def _dhcp():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$items = @(Get-NetIPInterface -AddressFamily IPv4 "
        "-ErrorAction Stop); "
        "$items | Select-Object InterfaceAlias,ConnectionState,Dhcp,"
        "NlMtu,InterfaceMetric | Format-Table -AutoSize | "
        "Out-String -Width 200; "
        "$active = @($items | Where-Object {$_.ConnectionState -eq 'Connected'}); "
        "$enabled = @($active | Where-Object {$_.Dhcp -eq 'Enabled'}); "
        "if ($active.Count -eq 0) { "
        "  Write-Output 'No connected IPv4 interface was returned.'; exit 2 "
        "}; "
        "if ($enabled.Count -eq 0) { "
        "  Write-Output 'Connected IPv4 interfaces are not using DHCP. "
        "A static configuration may be intentional.'; exit 2 "
        "}",
        timeout=30,
    )


def _gateway():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "$routes = @(Get-NetRoute -DestinationPrefix '0.0.0.0/0' "
        "-AddressFamily IPv4 -ErrorAction Stop | "
        "Sort-Object RouteMetric); "
        "if ($routes.Count -eq 0) { "
        "  Write-Output 'No IPv4 default route was returned.'; exit 2 "
        "}; "
        "$routes | Select-Object InterfaceAlias,NextHop,RouteMetric,"
        "State | Format-Table -AutoSize | Out-String -Width 200; "
        "$gateway = $routes[0].NextHop; "
        "Write-Output ('Testing gateway: ' + $gateway); "
        "if (-not (Test-Connection -ComputerName $gateway -Count 2 "
        "-Quiet -ErrorAction SilentlyContinue)) { exit 2 }",
        timeout=45,
    )


def _dns():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "Resolve-DnsName -Name 'www.microsoft.com' -Type A "
        "-ErrorAction Stop | Select-Object Name,Type,IPAddress,"
        "NameHost | Format-Table -AutoSize | Out-String -Width 200",
        timeout=30,
    )


def _https():
    if not IS_WINDOWS:
        return _unavailable()
    return _powershell(
        "Test-NetConnection -ComputerName 'www.microsoft.com' -Port 443 "
        "-InformationLevel Detailed | Format-List",
        timeout=45,
    )


def _specs():
    return [
        {
            "key": "adapter",
            "number": "1",
            "title": "Adapter detection",
            "description": "Lists physical network adapters, their state, MAC address, and link speed.",
            "command": f"{POWERSHELL} Get-NetAdapter -Physical",
            "run": _adapter_detection,
        },
        {
            "key": "link",
            "number": "2",
            "title": "Link status",
            "description": "Checks whether Windows reports a physical adapter as connected and up.",
            "command": f"{POWERSHELL} Get-NetAdapter -Physical | Select Status,LinkSpeed",
            "run": _link_status,
        },
        {
            "key": "dhcp",
            "number": "3",
            "title": "DHCP",
            "description": "Reads connected IPv4 interfaces and reports their DHCP mode.",
            "command": f"{POWERSHELL} Get-NetIPInterface -AddressFamily IPv4",
            "run": _dhcp,
        },
        {
            "key": "gateway",
            "number": "4",
            "title": "Default gateway",
            "description": "Finds the active IPv4 default route and pings its next hop.",
            "command": (
                f"{POWERSHELL} Get-NetRoute -DestinationPrefix '0.0.0.0/0' "
                "+ Test-Connection"
            ),
            "run": _gateway,
        },
        {
            "key": "dns",
            "number": "5",
            "title": "DNS resolution",
            "description": "Resolves a real public hostname through the configured DNS path.",
            "command": f"{POWERSHELL} Resolve-DnsName www.microsoft.com -Type A",
            "run": _dns,
        },
        {
            "key": "https",
            "number": "6",
            "title": "Internet HTTPS",
            "description": "Tests TCP connectivity to a real HTTPS endpoint on port 443.",
            "command": f"{POWERSHELL} Test-NetConnection www.microsoft.com -Port 443",
            "run": _https,
        },
    ]


class TroubleshootingWizardPage(tk.Frame):
    """Read-only Internet Problems wizard with real Windows probes."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.specs = _specs()
        self.states = {
            spec["key"]: {"busy": False, "ran": False, "ok": False}
            for spec in self.specs
        }
        self._build()

    def _build(self):
        _, root = make_scrollable(self, self.theme["BG"])

        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 12))
        tk.Label(
            header,
            text="TROUBLESHOOTING WIZARD",
            bg=self.theme["BG"],
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
        ).pack(anchor="w")
        title_row = tk.Frame(header, bg=self.theme["BG"])
        title_row.pack(fill="x", pady=(4, 4))
        tk.Label(
            title_row,
            text="Internet Problems",
            bg=self.theme["BG"],
            fg=self.theme["FG"],
            font=fl.F_TITLE(),
        ).pack(side="left")
        self.run_all_button = tk.Button(
            title_row,
            text="Run Internet Troubleshooter",
            command=self._run_all,
            bg=self.theme["ACCENT"],
            fg=self.theme["ON_ACCENT"],
            activebackground=self.theme["ACCENT_GLOW"],
            activeforeground=self.theme["ON_ACCENT"],
            relief="flat",
            padx=14,
            pady=7,
            cursor="hand2",
        )
        self.run_all_button.pack(side="right")
        tk.Label(
            header,
            text=(
                "A read-only diagnostic path: adapter detection, link status, "
                "DHCP, gateway, DNS, and HTTPS reachability."
            ),
            bg=self.theme["BG"],
            fg=self.theme["MUTED"],
            font=fl.F_BODY(),
            wraplength=800,
            justify="left",
        ).pack(anchor="w")

        notice = GlassCard(root, self.theme, aero=self.aero, accent=fl.GOOD)
        notice.pack(fill="x", padx=24, pady=(0, 14))
        body = notice.body
        tk.Label(
            body,
            text="READ-ONLY DIAGNOSTICS",
            bg=notice.fill,
            fg=fl.GOOD,
            font=fl.F_CARD_TITLE(),
        ).pack(anchor="w", padx=14, pady=(12, 3))
        tk.Label(
            body,
            text=(
                "This wizard does not reset adapters, renew DHCP, flush DNS, "
                "change routes, or modify firewall settings. It reports what "
                "Windows currently sees."
            ),
            bg=notice.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
            wraplength=800,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 12))

        if not IS_WINDOWS:
            tk.Label(
                root,
                text="Preview only: run TechDrive on Windows to execute these real checks.",
                bg=self.theme["BG"],
                fg=fl.WARN,
                font=fl.F_SMALL(),
            ).pack(anchor="w", padx=24, pady=(0, 8))
            self.run_all_button.configure(state=tk.DISABLED)

        for spec in self.specs:
            self._build_step(root, spec)

    def _build_step(self, root, spec):
        card = GlassCard(root, self.theme, aero=self.aero, accent=self.theme["ACCENT"])
        card.pack(fill="x", padx=24, pady=6)
        body = card.body

        heading = tk.Frame(body, bg=card.fill)
        heading.pack(fill="x", padx=14, pady=(12, 3))
        state_label = tk.Label(
            heading,
            text=f"{spec['number']}  ○",
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_CARD_TITLE(),
        )
        state_label.pack(side="left", padx=(0, 10))
        tk.Label(
            heading,
            text=spec["title"],
            bg=card.fill,
            fg=self.theme["FG"],
            font=fl.F_SUBTITLE(),
        ).pack(side="left")

        tk.Label(
            body,
            text=spec["description"],
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
            wraplength=800,
            justify="left",
        ).pack(anchor="w", padx=48, pady=(0, 4))
        tk.Label(
            body,
            text=f"Command: {spec['command']}",
            bg=card.fill,
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
            wraplength=800,
            justify="left",
        ).pack(anchor="w", padx=48, pady=(0, 7))
        output = tk.Text(
            body,
            height=5,
            wrap="word",
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            insertbackground=self.theme["FG"],
            font=fl.F_MONO(),
            relief="flat",
            padx=10,
            pady=8,
            state="disabled",
        )
        output.pack(fill="x", padx=48, pady=(0, 7))
        status_var = tk.StringVar(value="Not run")
        tk.Label(
            body,
            textvariable=status_var,
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        ).pack(anchor="w", padx=48, pady=(0, 8))
        run_button = tk.Button(
            body,
            text=f"Run check {spec['number']}",
            command=lambda item=spec: self._run_one(item),
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            activebackground=self.theme["SELECTION"],
            activeforeground=self.theme["FG"],
            relief="flat",
            padx=11,
            pady=5,
            cursor="hand2",
        )
        run_button.pack(anchor="w", padx=48, pady=(0, 14))
        if not IS_WINDOWS:
            run_button.configure(state=tk.DISABLED)

        state = self.states[spec["key"]]
        state.update(
            output=output,
            status_var=status_var,
            state_label=state_label,
            run_button=run_button,
        )

    def _write_output(self, widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _update_state(self, spec, result):
        state = self.states[spec["key"]]
        state["busy"] = False
        state["ran"] = True
        ok = bool(result.get("ok")) if isinstance(result, dict) else False
        output = result.get("output", str(result)) if isinstance(result, dict) else str(result)
        state["ok"] = ok
        state["state_label"].configure(
            text=f"{spec['number']}  {'✓' if ok else '⚠'}",
            fg=fl.GOOD if ok else fl.BAD,
        )
        state["status_var"].set("Passed" if ok else "Needs review")
        self._write_output(state["output"], output)
        state["run_button"].configure(state=tk.NORMAL)

    def _run_one(self, spec):
        state = self.states[spec["key"]]
        if state["busy"] or not IS_WINDOWS:
            return
        state["busy"] = True
        state["run_button"].configure(state=tk.DISABLED)
        state["status_var"].set("Running real Windows check…")
        self.app._run_bg(spec["run"], lambda result: self._update_state(spec, result))

    def _run_all(self):
        if not IS_WINDOWS:
            return
        self.run_all_button.configure(state=tk.DISABLED)
        for spec in self.specs:
            state = self.states[spec["key"]]
            state["busy"] = True
            state["run_button"].configure(state=tk.DISABLED)
            state["status_var"].set("Queued…")

        def run_all():
            results = []
            for spec in self.specs:
                result = spec["run"]()
                results.append((spec, result))
            return results

        def done(results):
            if not isinstance(results, list):
                results = [
                    (
                        spec,
                        {
                            "ok": False,
                            "output": f"Wizard failed before completing this check: {results}",
                        },
                    )
                    for spec in self.specs
                ]
            for spec, result in results:
                self._update_state(spec, result)
            self.run_all_button.configure(state=tk.NORMAL)

        self.app._run_bg(run_all, done)