#!/usr/bin/env python3
"""TechDrive notebook with predictable, per-tab close affordances.

Protected tabs (Dashboard/Settings) intentionally have no close glyph.  The
previous ttk image-element approach showed the glyph on every tab and then
silently ignored clicks on protected tabs.  This implementation keeps the
native ttk tab layout and puts a small ``×`` in the tab text for closable
pages, making the visual state and behavior agree on every supported Tk
version.
"""

import tkinter as tk
from tkinter import ttk

from gui import fluent as fl
from gui.motion import tween, spring, tab_content_fade, page_enter


class ClosableNotebook(ttk.Notebook):
    """ttk.Notebook with reliable close buttons and context-menu actions."""

    CLOSE_GLYPH = "×"

    def __init__(self, master, protected_titles=None, on_close=None, **kwargs):
        super().__init__(master, **kwargs)
        self.protected_titles = set(protected_titles or ())
        self.on_close = on_close
        self._pressed_tab = None
        self._menu = None
        self._closing = False
        self._indicator = None
        self._indicator_cancel = None

        self.bind("<ButtonPress-1>", self._on_press, True)
        self.bind("<ButtonRelease-1>", self._on_release, True)
        self.bind("<Double-Button-1>", self._on_double_click, True)
        self.bind("<Button-3>", self._on_right_click, True)
        # Middle-click is a familiar, forgiving close gesture and avoids
        # relying exclusively on ttk's inconsistent tab bounding boxes.
        self.bind("<Button-2>", self._on_middle_click, True)
        self.bind("<Control-w>", self._close_selected_event, True)
        self.bind("<Control-Shift-W>", self._close_all_event, True)
        self.bind("<<NotebookTabChanged>>", self._on_tab_changed, True)
        self.bind("<Configure>", self._on_configure, True)

    @classmethod
    def _display_title(cls, tab_text):
        """Return the logical title without decorative icon/close glyph."""
        text = str(tab_text or "").strip()
        if text.endswith(cls.CLOSE_GLYPH):
            text = text[:-1].rstrip()
        # Strip a leading icon token only when it contains no alphanumeric
        # characters, preserving real multi-word names such as Health Center.
        if " " in text:
            first, rest = text.split(" ", 1)
            if rest and not any(ch.isalnum() for ch in first):
                text = rest.strip()
        return text

    def _is_protected(self, tab_id):
        try:
            return self._display_title(self.tab(tab_id, "text")) in self.protected_titles
        except tk.TclError:
            return True

    def add_closable(self, child, text):
        """Add a tab, appending a visible close glyph only when closable."""
        logical = self._display_title(text)
        shown = str(text)
        if logical not in self.protected_titles and not shown.rstrip().endswith(self.CLOSE_GLYPH):
            shown = shown.rstrip() + "  " + self.CLOSE_GLYPH
        self.add(child, text=shown)

    def _close_button_hit(self, x, y):
        """Return the tab index when the pointer is over its close glyph.

        Some Tk 8.6 builds report ``bbox() == (0,0,0,0)`` for notebook tabs
        even though the tabs are visibly rendered.  Use the native tab index
        for hit-testing and a font-metric fallback for the right edge so the
        close action remains usable on those builds too.
        """
        try:
            index = self.index(f"@{x},{y}")
            if self._is_protected(index):
                return None
            bbox = self.bbox(index)
            if bbox and bbox[2] > 0 and bbox[3] > 0:
                bx, by, bw, bh = bbox
                # The glyph includes two spaces of padding. Use a slightly
                # wider hit target than the printed character for touchpads,
                # high-DPI displays, and Tk themes with different text metrics.
                if bx + max(18, bw - 30) <= x <= bx + bw and by <= y <= by + bh:
                    return index
                return None

            # Reliable fallback for Tk builds where bbox() is always zero:
            # discover the actual tab edges by asking Tk which tab occupies
            # each pixel on this row. This avoids guessing tab widths from font
            # metrics, which drift under DPI scaling and different ttk themes.
            widget_width = max(1, self.winfo_width())

            def tab_at(px):
                if px < 0 or px >= widget_width:
                    return None
                try:
                    return self.index(f"@{px},{y}")
                except (tk.TclError, ValueError):
                    return None

            left = x
            while left > 0 and tab_at(left - 1) == index:
                left -= 1
            right = x
            while right + 1 < widget_width and tab_at(right + 1) == index:
                right += 1
            tab_width = right - left + 1
            # Close glyph and its padding occupy the right-hand end of the
            # label. Clamp the target so short tab titles remain clickable.
            hit_width = min(34, max(24, tab_width // 3))
            if right - hit_width < x <= right:
                return index
            return None
        except (tk.TclError, ValueError):
            return None
        return None

    def _on_press(self, event):
        self._pressed_tab = self._close_button_hit(event.x, event.y)
        if self._pressed_tab is not None:
            return "break"
        return None

    def _on_release(self, event):
        pressed = self._pressed_tab
        self._pressed_tab = None
        if pressed is None:
            return None
        hit = self._close_button_hit(event.x, event.y)
        if hit == pressed:
            self.close_tab(hit)
            return "break"
        return None

    def _on_middle_click(self, event):
        """Close the tab under the pointer with a middle click."""
        try:
            tab_id = self.index(f"@{event.x},{event.y}")
            if not self._is_protected(tab_id):
                self.close_tab(tab_id)
                return "break"
        except tk.TclError:
            pass
        return None

    def _on_double_click(self, event):
        """A robust secondary close gesture for Tk builds with unreliable
        notebook tab bounding boxes. Protected tabs are never closed."""
        try:
            tab_id = self.index(f"@{event.x},{event.y}")
            if not self._is_protected(tab_id):
                self.close_tab(tab_id)
                return "break"
        except tk.TclError:
            pass
        return None

    def _close_selected_event(self, _event=None):
        try:
            tab_id = self.select()
            if tab_id:
                self.close_tab(tab_id)
        except tk.TclError:
            pass
        return "break"

    def _close_all_event(self, _event=None):
        self.close_all_tabs()
        return "break"

    def close_tab(self, tab_id):
        try:
            if self._is_protected(tab_id):
                return False
            text = self.tab(tab_id, "text")
            # Remove the tab first so a callback failure can never leave a
            # page visible after the user explicitly asked to close it.
            self.forget(tab_id)
            if self.on_close:
                try:
                    self.on_close(text)
                except Exception:
                    # Close semantics must not depend on optional bookkeeping.
                    pass
            return True
        except (tk.TclError, ValueError, IndexError):
            return False

    def close_all_tabs(self):
        closed = 0
        for tab_id in list(self.tabs()):
            if self.close_tab(tab_id):
                closed += 1
        return closed

    def close_other_tabs(self, keep_tab_id):
        closed = 0
        for tab_id in list(self.tabs()):
            if tab_id == keep_tab_id:
                continue
            if self.close_tab(tab_id):
                closed += 1
        return closed

    def _on_right_click(self, event):
        try:
            tab_id = self.index(f"@{event.x},{event.y}")
        except tk.TclError:
            return "break"
        text = self._display_title(self.tab(tab_id, "text"))
        menu = tk.Menu(self, tearoff=0)
        if text not in self.protected_titles:
            menu.add_command(label="Close Tab", command=lambda: self.close_tab(tab_id))
        menu.add_command(label="Close Other Tabs", command=lambda: self.close_other_tabs(tab_id))
        menu.add_command(label="Close All Tabs", command=self.close_all_tabs)
        menu.add_separator()
        menu.add_command(label="Close Tabs to the Right", command=lambda: self._close_right(tab_id))
        self._menu = menu
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def _close_right(self, keep_tab_id):
        tabs = list(self.tabs())
        try:
            start = tabs.index(keep_tab_id) + 1
        except ValueError:
            return
        for tab_id in tabs[start:]:
            self.close_tab(tab_id)

    def _on_tab_changed(self, _event=None):
        # Kept as a hook for future visual state updates; forcing a geometry
        # refresh here makes the text close glyph remain aligned after DPI or
        # font changes on older Tk builds.
        self.after_idle(self._safe_geometry_refresh)
        self.after_idle(self._animate_selection_indicator)

    def _animate_selection_indicator(self):
        """Springy accent underline under the newly selected tab + content fade."""
        try:
            selected = self.select()
            if not selected:
                return
            index = self.index(selected)
            x, y, width, height = self.bbox(index)
            if width <= 0:
                return
            indicator_color = getattr(self, "accent_color", fl.DARK["ACCENT"])
            if self._indicator is None or not self._indicator.winfo_exists():
                self._indicator = tk.Frame(self, bg=indicator_color, height=2)
            if self._indicator_cancel:
                self._indicator_cancel()
            self._indicator.configure(bg=indicator_color)
            self._indicator.place(x=x, y=max(0, y + height - 2), width=1, height=2)
            self._indicator.lift()
            self._indicator_cancel = tween(
                self, 280,
                lambda progress: self._indicator.place_configure(width=max(1, round(width * progress))),
                easing=spring,
            )
            # Soft springy content entrance
            try:
                tab_content_fade(self, duration_ms=300)
            except Exception:
                pass
        except tk.TclError:
            self._indicator = None

    def _on_configure(self, _event=None):
        # Only react to real size changes. The refresh itself calls
        # update_idletasks(), which can fire another <Configure>; reacting to
        # every event made the two keep feeding each other indefinitely.
        size = (self.winfo_width(), self.winfo_height())
        if size == getattr(self, "_last_configure_size", None):
            return
        self._last_configure_size = size
        self.after_idle(self._safe_geometry_refresh)

    def _safe_geometry_refresh(self):
        # update_idletasks() runs pending idle callbacks, which schedule this
        # method again; guard against re-entering it (infinite recursion).
        if getattr(self, "_geometry_refreshing", False):
            return
        self._geometry_refreshing = True
        try:
            if self.winfo_exists():
                self.update_idletasks()
        except tk.TclError:
            pass
        finally:
            self._geometry_refreshing = False
