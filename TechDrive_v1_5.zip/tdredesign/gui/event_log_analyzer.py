#!/usr/bin/env python3
"""TechDrive Core — Event Log Analyzer.
Reads real Windows event logs with Get-WinEvent and groups related storage errors."""
import json, platform, subprocess, threading, tkinter as tk
from gui.tk_dialogs import filedialog, messagebox
from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton

PS = r'''$ErrorActionPreference='SilentlyContinue'
$logs=@('System','Application')
$events=@()
foreach($log in $logs){ try { $events += @(Get-WinEvent -FilterHashtable @{LogName=$log; StartTime=(Get-Date).AddDays(-7)} -MaxEvents 1500 | ForEach-Object {
  [ordered]@{Log=$_.LogName;Id=$_.Id;Level=$_.LevelDisplayName;Provider=$_.ProviderName;Time=$_.TimeCreated.ToString('o');Message=([string]$_.Message)}
 }) } catch {} }
$events | Sort-Object Time -Descending | ConvertTo-Json -Depth 5 -Compress'''

def scan():
    if platform.system()!='Windows': return {'ok':False,'error':'Event Log Analyzer requires Windows.'}
    try:
        r=subprocess.run(['powershell','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',PS],capture_output=True,text=True,errors='replace',timeout=90)
        raw=(r.stdout or '').strip()
        if not raw: return {'ok':False,'error':(r.stderr or 'Windows returned no events.').strip()}
        data=json.loads(raw); return {'ok':True,'events':data if isinstance(data,list) else [data]}
    except Exception as e: return {'ok':False,'error':f'{type(e).__name__}: {e}'}

def storage_related(e):
    s=' '.join(str(e.get(k,'')) for k in ('Provider','Message')).lower()
    keys=('disk','storahci','stornvme','nvme','iaStor','partmgr','volmgr','ntfs','disk','storage')
    return any(k.lower() in s for k in keys)

class EventLogAnalyzerPage(tk.Frame):
    def __init__(self,parent,app):
        super().__init__(parent,bg=app.theme['BG']); self.app=app; self.theme=app.theme; self.aero=app.is_aero_enabled(); self.events=[]
        _,self.body=make_scrollable(self,self.theme['BG']); self._build()
    def _build(self):
        h=tk.Frame(self.body,bg=self.theme['BG']); h.pack(fill='x',padx=24,pady=(22,8))
        tk.Label(h,text='TECHDRIVE CORE  /  EVENT LOG ANALYZER',bg=self.theme['BG'],fg=self.theme['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w')
        tk.Label(h,text='Event Log Analyzer',bg=self.theme['BG'],fg=self.theme['FG'],font=fl.F_TITLE()).pack(anchor='w')
        tk.Label(h,text='Turn the last 7 days of Windows System and Application events into counts, relationships, and inspectable evidence.',bg=self.theme['BG'],fg=self.theme['MUTED'],font=fl.F_SMALL(),wraplength=850,justify='left').pack(anchor='w')
        bar=tk.Frame(self.body,bg=self.theme['BG']); bar.pack(fill='x',padx=24,pady=8)
        self.scan_btn=FluentButton(bar,'ANALYZE',command=self.run,theme=self.theme,aero=self.aero,kind='accent',width=120,height=34,backdrop=self.theme['BG']); self.scan_btn.pack(side='left')
        self.save_btn=FluentButton(bar,'SAVE EVENTS',command=self.save,theme=self.theme,aero=self.aero,kind='standard',width=130,height=34,backdrop=self.theme['BG']); self.save_btn.pack(side='left',padx=8)
        self.status=tk.Label(bar,text='Ready — scan Windows Event Log.',bg=self.theme['BG'],fg=self.theme['MUTED'],font=fl.F_SMALL()); self.status.pack(side='left',padx=10)
        self.result=tk.Frame(self.body,bg=self.theme['BG']); self.result.pack(fill='both',expand=True,padx=24,pady=8)
    def run(self):
        self.scan_btn.config(state=tk.DISABLED); self.status.config(text='Reading Windows Event Log…')
        def worker():
            result = scan()
            self.app._post_ui(lambda result=result: self.finish(result))
        threading.Thread(target=worker,daemon=True).start()
    def finish(self,r):
        self.scan_btn.config(state=tk.NORMAL); self.result.destroy(); self.result=tk.Frame(self.body,bg=self.theme['BG']); self.result.pack(fill='both',expand=True,padx=24,pady=8)
        if not r['ok']: self.status.config(text=r['error']); return
        self.events=sorted(r['events'],key=lambda x:x.get('Time',''),reverse=True); self.status.config(text=f'Analyzed {len(self.events)} events from System + Application.')
        counts={k:sum(1 for e in self.events if str(e.get('Level','')).lower()==k.lower()) for k in ('Critical','Error','Warning','Information')}
        card=GlassCard(self.result,self.theme,aero=self.aero,accent=self.theme['ACCENT']); card.pack(fill='x',pady=6)
        row=tk.Frame(card.body,bg=card.fill); row.pack(fill='x',padx=16,pady=14)
        for k in ('Critical','Error','Warning','Information'):
            tk.Label(row,text=f'{k}\n{counts[k]}',bg=card.fill,fg=fl.BAD if k=='Critical' else (fl.WARN if k in ('Error','Warning') else self.theme['FG']),font=fl.F_CARD_TITLE(),justify='center',width=16).pack(side='left',padx=2)
        related=[e for e in self.events if str(e.get('Level','')).lower() in ('error','critical') and storage_related(e)]
        if related:
            c=GlassCard(self.result,self.theme,aero=self.aero,accent=fl.WARN); c.pack(fill='x',pady=6)
            tk.Label(c.body,text='[!] Storage-related pattern detected',bg=c.fill,fg=fl.WARN,font=fl.F_CARD_TITLE()).pack(anchor='w',padx=16,pady=(12,2))
            tk.Label(c.body,text=f'{len(related)} critical/error event(s) mention storage, disk, NTFS, NVMe, or a storage driver. Inspect the events below before taking action.',bg=c.fill,fg=self.theme['MUTED'],font=fl.F_SMALL(),wraplength=820,justify='left').pack(anchor='w',padx=16,pady=(0,12))
        listcard=GlassCard(self.result,self.theme,aero=self.aero,accent=self.theme['ACCENT']); listcard.pack(fill='both',expand=True,pady=6)
        tk.Label(listcard.body,text='EVENTS — SELECT AN EVENT',bg=listcard.fill,fg=self.theme['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w',padx=14,pady=(12,4))
        lb=tk.Listbox(listcard.body,bg=self.theme['SURFACE'],fg=self.theme['FG'],selectbackground=self.theme['ACCENT'],height=16,borderwidth=0,highlightthickness=0); lb.pack(fill='both',expand=True,padx=14,pady=(0,8))
        for e in self.events[:500]: lb.insert('end',f"{e.get('Time','')[:19]} | {e.get('Level','')} | {e.get('Provider','')} | ID {e.get('Id','')}")
        detail=tk.Text(listcard.body,bg=self.theme['SURFACE'],fg=self.theme['FG'],height=8,wrap='word',borderwidth=0); detail.pack(fill='x',padx=14,pady=(0,14))
        def show(_=None):
            i=lb.curselection();
            if not i:return
            e=self.events[i[0]]; detail.delete('1.0','end'); detail.insert('end',json.dumps(e,indent=2,ensure_ascii=False))
        lb.bind('<<ListboxSelect>>',show)
    def save(self):
        if not self.events: return
        p=filedialog.asksaveasfilename(title='Save analyzed Windows events',defaultextension='.json',filetypes=[('JSON','*.json'),('Text','*.txt')])
        if not p:return
        try:
            with open(p,'w',encoding='utf-8') as f: json.dump(self.events,f,indent=2,ensure_ascii=False)
            messagebox.showinfo('TechDrive',f'Saved {len(self.events)} events to:\n{p}')
        except Exception as e: messagebox.showerror('TechDrive',str(e))
