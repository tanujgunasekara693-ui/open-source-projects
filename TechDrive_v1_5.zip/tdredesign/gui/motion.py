#!/usr/bin/env python3
"""Buttery-smooth, cancel-safe animation helpers for TechDrive.

Designed to feel like Apple's motion system:
  * physics-inspired spring and quintic curves
  * consistent ~60 fps cadence
  * cancel-safe (safe during rapid hover / theme changes)
  * respects the reduce_motion accessibility setting
"""

from __future__ import annotations

import math
import time
import tkinter as tk

from shared import database as db


FRAME_MS = 16  # ~60 fps


def motion_enabled():
    """Respect the existing accessibility setting without caching it."""
    try:
        return not bool(db.get_setting("reduce_motion", False))
    except Exception:
        return True


# ---------------------------------------------------------------------------
# Easing curves (Apple-inspired)
# ---------------------------------------------------------------------------

def ease_out_cubic(value):
    value = max(0.0, min(1.0, float(value)))
    return 1.0 - pow(1.0 - value, 3)


def ease_in_out(value):
    value = max(0.0, min(1.0, float(value)))
    return -(math.cos(math.pi * value) - 1.0) / 2.0


def ease_out_quint(value):
    value = max(0.0, min(1.0, float(value)))
    return 1.0 - pow(1.0 - value, 5)


def ease_out_expo(value):
    value = max(0.0, min(1.0, float(value)))
    return 1.0 if value >= 1.0 else 1.0 - pow(2, -10 * value)


def ease_in_out_cubic(value):
    value = max(0.0, min(1.0, float(value)))
    if value < 0.5:
        return 4 * value * value * value
    return 1 - pow(-2 * value + 2, 3) / 2


def spring(value, mass=1.0, stiffness=180.0, damping=22.0):
    """Under-damped spring — soft overshoot then settle (Apple UI)."""
    value = max(0.0, min(1.0, float(value)))
    omega = math.sqrt(stiffness / mass)
    zeta = damping / (2 * math.sqrt(stiffness * mass))
    if zeta < 1.0:
        wd = omega * math.sqrt(1 - zeta * zeta)
        return 1.0 - math.exp(-zeta * omega * value) * (
            math.cos(wd * value) + (zeta * omega / wd) * math.sin(wd * value)
        )
    return 1.0 - math.exp(-omega * value) * (1.0 + omega * value)


def ease_apple(value):
    """Default UI curve — soft landing with a touch of spring."""
    value = max(0.0, min(1.0, float(value)))
    # Blend quintic landing with a whisper of spring for life
    q = ease_out_quint(value)
    s = spring(value)
    return q * 0.72 + s * 0.28


# ---------------------------------------------------------------------------
# Core tween
# ---------------------------------------------------------------------------

def tween(widget, duration_ms, update, complete=None, easing=None):
    """Run an elapsed-time tween and return a callable that cancels it."""
    if easing is None:
        easing = ease_apple

    state = {"job": None, "cancelled": False}

    def cancel():
        state["cancelled"] = True
        job = state.get("job")
        if job is not None:
            try:
                widget.after_cancel(job)
            except tk.TclError:
                pass
            state["job"] = None

    if not motion_enabled() or duration_ms <= 0:
        try:
            update(1.0)
            if complete:
                complete()
        except tk.TclError:
            pass
        return cancel

    started = time.monotonic()

    def frame():
        if state["cancelled"]:
            return
        try:
            if not widget.winfo_exists():
                return
            elapsed = (time.monotonic() - started) * 1000.0
            progress = min(1.0, elapsed / max(1, duration_ms))
            update(easing(progress))
            if progress < 1.0:
                state["job"] = widget.after(FRAME_MS, frame)
            else:
                state["job"] = None
                if complete:
                    complete()
        except tk.TclError:
            state["job"] = None

    frame()
    return cancel


# ---------------------------------------------------------------------------
# Convenience helpers
# ---------------------------------------------------------------------------

def fade(widget, from_alpha, to_alpha, duration_ms=240, complete=None, apply=None):
    def update(t):
        a = from_alpha + (to_alpha - from_alpha) * t
        if apply:
            apply(a)

    return tween(widget, duration_ms, update, complete=complete, easing=ease_out_quint)


def spring_tween(widget, duration_ms, update, complete=None):
    return tween(widget, duration_ms, update, complete=complete, easing=spring)


def press_scale(widget, pressed, duration_ms=100):
    """Subtle press feedback for canvas buttons (simulates scale via pad)."""
    target = 0.96 if pressed else 1.0
    state = {"t": 1.0 if not pressed else 0.96}

    def update(t):
        # t goes 0→1; interpolate toward target
        pass

    # Best-effort: many widgets use their own hover; keep lightweight
    return tween(widget, duration_ms, lambda t: None, easing=ease_out_cubic)


def page_enter(widget, duration_ms=320, direction="up", distance=22, complete=None):
    """Slide + settle entrance for a page or panel."""
    if not motion_enabled():
        if complete:
            try:
                complete()
            except Exception:
                pass
        return lambda: None

    # Only slide widgets that are laid out with pack(). A notebook tab page
    # is managed by the notebook; moving it with place() detaches it from the
    # tab strip and leaves it floating over the page, so skip the animation.
    try:
        manager = widget.winfo_manager()
    except Exception:
        manager = ""
    if manager != "pack":
        if complete:
            try:
                complete()
            except Exception:
                pass
        return lambda: None

    try:
        widget.update_idletasks()
    except Exception:
        pass

    dx = dy = 0
    if direction == "up":
        dy = distance
    elif direction == "down":
        dy = -distance
    elif direction == "left":
        dx = distance
    elif direction == "right":
        dx = -distance

    was_packed = False
    pack_info = {}
    try:
        pack_info = widget.pack_info()
        was_packed = True
    except Exception:
        pack_info = {}

    spacer = None
    try:
        x = widget.winfo_x()
        y = widget.winfo_y()
        w = widget.winfo_width()
        h = widget.winfo_height()
        if was_packed:
            # Hold the widget's slot in the pack order with an invisible
            # spacer. Without it the widget was re-packed at the END of its
            # parent on finish, which pushed banners/bars below everything
            # else and left an empty gap at the top of the page.
            spacer_opts = {k: v for k, v in pack_info.items() if k != "in"}
            spacer_opts["expand"] = False
            spacer_opts["fill"] = "x" if pack_info.get("fill") in ("x", "both") else "none"
            spacer = tk.Frame(widget.master, height=h, width=1,
                              bg=widget.master.cget("bg"))
            spacer.pack(before=widget, **spacer_opts)
            widget.pack_forget()
            widget.place(x=x + dx, y=y + dy, width=w, height=h)
        else:
            widget.place_configure(x=x + dx, y=y + dy)
    except Exception:
        if spacer is not None:
            try:
                widget.place_forget()
                widget.pack(before=spacer, **{k: v for k, v in pack_info.items() if k != "in"})
                spacer.destroy()
            except Exception:
                pass
        if complete:
            try:
                complete()
            except Exception:
                pass
        return lambda: None

    start_x, start_y = x + dx, y + dy
    end_x, end_y = x, y

    def update(t):
        try:
            widget.place_configure(
                x=int(start_x + (end_x - start_x) * t),
                y=int(start_y + (end_y - start_y) * t),
            )
        except Exception:
            pass

    def finish():
        try:
            if was_packed:
                widget.place_forget()
                opts = {k: v for k, v in pack_info.items() if k != "in"}
                if spacer is not None and spacer.winfo_exists():
                    widget.pack(before=spacer, **opts)
                    spacer.destroy()
                else:
                    widget.pack(**opts)
            else:
                widget.place_configure(x=end_x, y=end_y)
        except Exception:
            pass
        if complete:
            try:
                complete()
            except Exception:
                pass

    return tween(widget, duration_ms, update, complete=finish, easing=spring)


def sheet_present(window, duration_ms=340, from_y=28):
    """Present a Toplevel sheet: fade in + slide up with spring."""
    if not motion_enabled():
        try:
            window.attributes("-alpha", 1.0)
        except tk.TclError:
            pass
        return lambda: None

    try:
        window.attributes("-alpha", 0.0)
        geo = window.geometry()
        # parse WxH+X+Y
        parts = geo.replace("+", " ").replace("x", " ").split()
        if len(parts) >= 4:
            w, h, x, y = map(int, parts[:4])
            start_y = y + from_y
            window.geometry(f"{w}x{h}+{x}+{start_y}")
        else:
            w = h = x = y = start_y = None
    except Exception:
        w = h = x = y = start_y = None

    def update(t):
        try:
            window.attributes("-alpha", min(1.0, t * 1.05))
            if w is not None:
                cy = int(start_y + (y - start_y) * t)
                window.geometry(f"{w}x{h}+{x}+{cy}")
        except tk.TclError:
            pass

    return tween(window, duration_ms, update, easing=spring)


def sheet_dismiss(window, duration_ms=220, to_y=20, complete=None):
    """Dismiss sheet: fade out + slide down."""
    if not motion_enabled():
        try:
            window.destroy()
        except Exception:
            pass
        if complete:
            try:
                complete()
            except Exception:
                pass
        return lambda: None

    try:
        geo = window.geometry()
        parts = geo.replace("+", " ").replace("x", " ").split()
        if len(parts) >= 4:
            w, h, x, y = map(int, parts[:4])
            end_y = y + to_y
        else:
            w = h = x = y = end_y = None
    except Exception:
        w = h = x = y = end_y = None

    def update(t):
        try:
            window.attributes("-alpha", max(0.0, 1.0 - t))
            if w is not None:
                cy = int(y + (end_y - y) * t)
                window.geometry(f"{w}x{h}+{x}+{cy}")
        except tk.TclError:
            pass

    def finish():
        try:
            window.destroy()
        except Exception:
            pass
        if complete:
            try:
                complete()
            except Exception:
                pass

    return tween(window, duration_ms, update, complete=finish, easing=ease_out_cubic)


def tab_content_fade(notebook, duration_ms=280):
    """Springy content transition when switching tabs."""
    if not motion_enabled():
        return lambda: None
    try:
        selected = notebook.select()
        if not selected:
            return lambda: None
        tab = notebook.nametowidget(selected)
        if not tab.winfo_exists():
            return lambda: None
        bg = tab.cget("bg") if "bg" in tab.keys() else "#0b0b0d"
        overlay = tk.Frame(tab, bg=bg)
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        def update(t):
            try:
                # Soft wipe upward + shrink
                overlay.place_configure(
                    rely=t * 0.06,
                    relheight=max(0.02, 1.0 - t * 0.98),
                )
            except Exception:
                pass

        def finish():
            try:
                overlay.destroy()
            except Exception:
                pass

        return tween(notebook, duration_ms, update, complete=finish, easing=spring)
    except Exception:
        return lambda: None


def cascade(widgets, stagger_ms=40, anim_fn=None, duration_ms=280):
    """Staggered entrance for a list of widgets."""
    if not motion_enabled() or not widgets:
        return
    anim_fn = anim_fn or (lambda w, **kw: page_enter(w, duration_ms=duration_ms, direction="up", distance=16))
    root = widgets[0]
    for i, w in enumerate(widgets):
        try:
            root.after(i * stagger_ms, lambda ww=w: anim_fn(ww))
        except Exception:
            pass


def pulse_highlight(canvas, item_or_tag, color_from, color_to, duration_ms=500):
    """Pulse a canvas item fill between two colors once."""
    if not motion_enabled():
        return lambda: None

    def update(t):
        # triangle wave 0→1→0
        p = 1.0 - abs(1.0 - 2.0 * t)
        try:
            # simple: just set to color_to mid-way
            if p > 0.5:
                canvas.itemconfigure(item_or_tag, fill=color_to)
            else:
                canvas.itemconfigure(item_or_tag, fill=color_from)
        except Exception:
            pass

    def finish():
        try:
            canvas.itemconfigure(item_or_tag, fill=color_from)
        except Exception:
            pass

    return tween(canvas, duration_ms, update, complete=finish, easing=ease_in_out)
