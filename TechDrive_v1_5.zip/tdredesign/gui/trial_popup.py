#!/usr/bin/env python3
r"""
gui/trial_popup.py - WinRAR-style trial nag popup
=====================================================
Shown on every launch once the 30-day free trial (techdrive.py's
TRIAL_FILE/TRIAL_DAYS tracking) has elapsed. Same spirit as WinRAR's
famously toothless nag: nothing is locked, nothing breaks, every tool
keeps working exactly the same forever - this is purely a reminder,
and it's meant to be funny about admitting that, not a wall you have
to fight through. "Remind Me Later" dismisses it instantly, every
time, no tricks.

There are 10 interchangeable "skins" for the same toothless nag - one
picked at random each launch (avoiding an immediate repeat of last
time's), just so returning users get a different joke instead of the
same wall of text every day. Every skin has identical mechanics:
same 4 buttons, same Escape/close behavior, same on_close chaining.
Only the copy, colors and emoji change.

Public API:
    show_trial_popup(app, on_close=None)
"""

import random
import tkinter as tk
from tkinter import ttk

# Remembers the index of the last-shown variant (module-level - lives
# only for this process's lifetime, which is fine: it just needs to
# stop back-to-back repeats within a single running instance, not
# across restarts).
_last_variant = [None]


def _base_popup(app, title, geometry="560x460"):
    popup = tk.Toplevel(app)
    popup.title(title)
    popup.geometry(geometry)
    popup.resizable(False, False)
    # No .transient(app): this is a fully independent top-level window
    # (its own taskbar entry), not attached to / parented inside the
    # main app window.
    popup.configure(bg="#2b2b2b")
    popup.attributes("-topmost", True)
    popup.after(200, lambda: popup.attributes("-topmost", False))
    popup.grab_set()
    return popup


def _make_dismiss(popup, app, on_close):
    """Single close helper - routes every dismiss path through here so
    on_close fires exactly once regardless of how the user exits."""
    _dismissed = [False]

    def _dismiss(post_action=None):
        if _dismissed[0]:
            return
        _dismissed[0] = True
        popup.destroy()
        if post_action:
            post_action()
        if on_close:
            app.after(250, on_close)

    return _dismiss


def _standard_buttons(popup, btn_frame, app, dismiss, labels):
    """Build the four decorative nag buttons.

    Beta mode intentionally keeps the existing buttons and their labels
    for visual design/review purposes, but button clicks perform no action.
    The popup can still be dismissed with the window close button or Escape.
    This avoids accidental payment/license/navigation actions while TechDrive
    is being released as a beta for user feedback.
    """
    up_text, biz_text, info_text, later_text = labels

    # Deliberately inert: these are visual-only beta nag controls.
    noop = lambda: None

    tk.Button(btn_frame, text=up_text, command=noop,
              bg="#2ecc71", fg="white", padx=15, pady=8, width=30).pack(pady=4)
    tk.Button(btn_frame, text=biz_text, command=noop,
              bg="#f39c12", fg="white", padx=15, pady=8, width=30).pack(pady=4)
    tk.Button(btn_frame, text=info_text, command=noop,
              bg="#3b3b3b", fg="white", padx=15, pady=8, width=30).pack(pady=4)
    tk.Button(btn_frame, text=later_text, command=noop,
              bg="#7f8c8d", fg="white", padx=15, pady=8, width=30).pack(pady=4)

    popup.bind("<Escape>", lambda e: dismiss())
    popup.protocol("WM_DELETE_WINDOW", lambda: dismiss())


# ---------------------------------------------------------------------------
# Variant 1 - "Well, This Is Awkward..." (the original)
# ---------------------------------------------------------------------------
def _variant_1(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Awkward Popup Time")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="● Well, This Is Awkward...", font=("Segoe UI", 17, "bold"),
             bg="#2b2b2b", fg="#00e5ff").pack(pady=(22, 4))
    tk.Label(popup, text="Your 30-day free trial expired a while ago.\n"
                        "We just now got around to mentioning it - sorry, we were\n"
                        "busy fixing your PC instead of building nag screens.",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="Nothing is locked. Nothing broke. Every single tool still\n"
                        "works exactly the same as it did on day one. This popup exists\n"
                        "purely because that's what an entire generation of PC users\n"
                        "was trained to expect - and honestly, we couldn't resist.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="If you'd like this popup gone forever (and to fund more "
                        "late-night feature-building), here's the menu:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"¤ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"▥ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Technically, businesses are supposed to grab a license here. "
                        "We're not going to chase you down about it - we just felt "
                        "like mentioning it once, for the bit.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("◇ Upgrade Now", "▥ Business License", "▤ License Info",
                        "● Not Today (Remind Me Later)"))

    tk.Label(popup, text="No pressure - click below and we'll see you in exactly the\n"
                        "same amount of time from now. Enterprise quotes: "
                        "support@techdrive.com",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 2 - "This Is Fine" (the burning-room dog meme)
# ---------------------------------------------------------------------------
def _variant_2(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — This Is Fine")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="△●○ This Is Fine.", font=("Segoe UI", 17, "bold"),
             bg="#2b2b2b", fg="#ff6b35").pack(pady=(22, 4))
    tk.Label(popup, text="Your trial expired weeks ago. Everything still works.\n"
                        "We are choosing, as a company, to sit in this burning\n"
                        "room and not fix anything about that. This is fine.",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="No countdown. No lockout. No sudden 'buy now or else'.\n"
                        "Just a small dog, a small popup, and a mild sense that\n"
                        "one of us really ought to do something about this.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Extremely optional ways to make the fire go away:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"○ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"▰ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses technically get their own tier. We are, once\n"
                        "again, choosing not to make a thing of it.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("○ Put Out The Fire (Upgrade)", "▰ Business License",
                        "▤ License Info", "● Everything Is Fine (Later)"))

    tk.Label(popup, text="See you tomorrow, same fire, same dog, same couch.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 3 - Clippy-style "It looks like you're avoiding a purchase"
# ---------------------------------------------------------------------------
def _variant_3(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Your Old Office Assistant Is Back")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="⌕ It looks like you're avoiding a purchase.",
             font=("Segoe UI", 15, "bold"), bg="#2b2b2b", fg="#f1c40f",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="Would you like help with that?\n"
                        "(There is only one correct answer and it costs money.)",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="I noticed you've been using this software for free for\n"
                        "over 30 days. I also noticed you keep closing this exact\n"
                        "popup. I've saved a memo about it. Just so you know.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Here are some options I generated, entirely unprompted:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"⌕ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"⌕ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="I'll keep this memo brief: businesses should probably\n"
                        "grab this tier. I won't mention it again. (I will.)",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("⌕ Yes, Help Me Purchase", "⌕ Business Help, Please",
                        "⌕ Tell Me About My License", "⌕ Go Away, Clippy"))

    tk.Label(popup, text="I'll be in the paperclip drawer if you need me.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 4 - Distracted Boyfriend meme
# ---------------------------------------------------------------------------
def _variant_4(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Wandering Eye")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="◉ You, Looking At 'Maybe I'll Buy It Later'",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#e056fd",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="Meanwhile 'Actually Buying It Right Now'\n"
                        "walks by in a red dress and you don't even glance over.\n"
                        "Your girlfriend '30 More Days Of Free Nagging' is upset.",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="This is a stock meme format applied to software licensing.\n"
                        "We are not proud of it. We are also not taking it down.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Options, presented with zero subtlety:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"♥ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"♥ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses are the guy's mom in this analogy. We're not\n"
                        "going to unpack that further.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("♥ Look Over Here Instead (Upgrade)", "♥ Business License",
                        "▤ License Info", "◌ Keep Walking (Later)"))

    tk.Label(popup, text="See you tomorrow for round two of this exact bit.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 5 - Windows-XP-error-sound-energy "critical" alert (fake urgency, played for laughs)
# ---------------------------------------------------------------------------
def _variant_5(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — !!! ATTENTION !!!")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="⚠ SYSTEM ALERT: FREE TRIAL STATUS: EXPIRED ⚠",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#ff3333",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="THIS LOOKS SERIOUS BUT IT IS NOT.\n"
                        "We just used a red font and some exclamation points because\n"
                        "that's how every scary popup gets your attention. It worked, right?",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="Your computer is not slow. You do not have 3 viruses.\n"
                        "Nothing is 'critically at risk'. You just haven't paid for\n"
                        "software you've been happily using for over a month.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Recommended action (per absolutely no scan of any kind):",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"⚠ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"⚠ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses should 'act now' per this entirely fake urgency\n"
                        "meter we just invented for comedic effect.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("⚠ Resolve Now (Upgrade)", "⚠ Business License",
                        "▤ License Info", "● Ignore This Very Fake Alert"))

    tk.Label(popup, text="Real talk: nothing bad happens if you click the gray button.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 6 - "Are you sure?" guilt-trip cancel-flow parody
# ---------------------------------------------------------------------------
def _variant_6(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Before You Go...")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="● Wait, Are You Sure You Don't Want To Upgrade?",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#74b9ff",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="We noticed you've dismissed this popup before.\n"
                        "(We notice everything. We built the popup, remember.)",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="This is the part in every subscription-cancellation flow\n"
                        "where they show you a sad face and ask 'are you SURE?' three\n"
                        "more times. We're doing that, except you were never even\n"
                        "trying to cancel anything. You just opened the app.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Before you click away, one more look at what you're missing:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"● Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"● Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses get an extra sad face here, out of respect for\n"
                        "how much money they're theoretically saving by not clicking.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("● Fine, You Win (Upgrade)", "● Business License",
                        "▤ License Info", "♥ Yes, I'm Sure (Later)"))

    tk.Label(popup, text="That's it. No fourth confirmation screen. We have some dignity.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 7 - Terms & Conditions wall-of-text parody, played for laughs
# ---------------------------------------------------------------------------
def _variant_7(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Please Review This Very Serious Document")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="▤ A Brief, Totally-Read-By-No-One Legal Notice",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#a29bfe",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="WHEREAS the undersigned ('you') opened this application,\n"
                        "and WHEREAS 30 days have elapsed since said opening, the\n"
                        "party of the first part (also you) is hereby informed that\n"
                        "a free tier exists, has always existed, and continues to exist.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#dcdcdc", justify="center",
             wraplength=480).pack(pady=4)
    tk.Label(popup, text="TL;DR: nothing legally binding is happening here. We just\n"
                        "wanted one popup to sound like a EULA nobody's ever finished reading.",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Section 4(b): Available Remedies To This Popup",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"⚖ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"⚖ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Per Clause 12, businesses are 'strongly encouraged, though\n"
                        "not enforced, monitored, or in any way tracked' to buy this tier.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("⚖ I Agree, Take My Money", "⚖ Business License",
                        "▤ License Info", "▤ I Did Not Read This (Later)"))

    tk.Label(popup, text="No jury of your peers required. Just click a button.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 8 - Expanding Brain meme
# ---------------------------------------------------------------------------
def _variant_8(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Galaxy Brain Purchasing Decisions")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="◉ The Expanding Brain Guide To This Popup",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#00ffab",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="◉ Small brain: closes the popup without reading it\n"
                        "◉✦ Regular brain: reads it, closes it anyway\n"
                        "◉✦ Galaxy brain: buys a license just to make the popup stop\n"
                        "✦◉✦ Universe brain: realizes it never asked to stop, just less often",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="left").pack(pady=4)
    tk.Label(popup, text="We are not saying which brain you have. The button\n"
                        "choices below will say it for you.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="Ascend accordingly:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"◉✦ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"✦◉✦ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses are, canonically, the universe-brain tier.\n"
                        "That's not a sales tactic, that's just how the meme works.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("◉✦ Ascend (Upgrade)", "✦◉✦ Business License",
                        "▤ License Info", "◉ Small Brain (Later)"))

    tk.Label(popup, text="No shame in small brain. Small brain still gets full functionality.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 9 - "Two Buttons" sweating-guy meme
# ---------------------------------------------------------------------------
def _variant_9(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — A Very Difficult Decision")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="● Guy Sweating Over Two Buttons: Software Edition",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#ff7675",
             wraplength=500, justify="center").pack(pady=(22, 4))
    tk.Label(popup, text="[ Button 1: Pay $9.99 for software you already use daily ]\n"
                        "[ Button 2: Keep using it for free, forever, no consequences ]\n"
                        "Sweat intensifies. The math is not actually close.",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="We drew this popup as a meme specifically because both\n"
                        "options are fine and we needed 30 more seconds of your\n"
                        "attention to say so.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="The two buttons, now with a third and fourth for legal reasons:",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"● Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"● Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses sweat over this decision at a corporate scale,\n"
                        "which mostly means someone forwards this email thread.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("● Pick Button 1 (Upgrade)", "● Business License",
                        "▤ License Info", "● Pick Button 2 (Later)"))

    tk.Label(popup, text="Both buttons lead to the same fully-functional app either way.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


# ---------------------------------------------------------------------------
# Variant 10 - Fake "installing" progress bar that's actually just a nag
# ---------------------------------------------------------------------------
def _variant_10(app, on_close, TIER_INFO):
    popup = _base_popup(app, "TechDrive — Optimizing Your Experience...")
    dismiss = _make_dismiss(popup, app, on_close)

    tk.Label(popup, text="⏳ Please Wait While We Definitely Optimize Something",
             font=("Segoe UI", 14, "bold"), bg="#2b2b2b", fg="#55efc4",
             wraplength=500, justify="center").pack(pady=(22, 4))

    pbar = ttk.Progressbar(popup, orient="horizontal", length=420, mode="determinate")
    pbar.pack(pady=(6, 4))
    pbar["value"] = 97

    tk.Label(popup, text="Optimizing... 97% complete",
             font=("Segoe UI", 10), bg="#2b2b2b", fg="#dcdcdc", justify="center").pack(pady=4)
    tk.Label(popup, text="This progress bar has been at 97% since installation.\n"
                        "It will remain at 97% forever. It is not doing anything.\n"
                        "It is, however, extremely convincing. That was the whole plan.",
             font=("Segoe UI", 9), bg="#2b2b2b", fg="#9aa0a6", justify="center").pack(pady=(8, 4))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=12)

    tk.Label(popup, text="The only way to actually finish 'optimizing':",
             font=("Segoe UI", 9, "italic"), bg="#2b2b2b", fg="#7f8c8d",
             wraplength=480, justify="center").pack(pady=(0, 8))

    tk.Label(popup, text=f"⏳ Personal Pro — {TIER_INFO['P']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#2ecc71").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text=f"⏳ Business — {TIER_INFO['B']['price']}", font=("Segoe UI", 12, "bold"),
             bg="#2b2b2b", fg="#f39c12").pack(anchor="w", padx=40, pady=5)
    tk.Label(popup, text="Businesses optimize 3% faster with this tier. This claim\n"
                        "has not been measured, tested, or thought about very hard.",
             font=("Segoe UI", 8), bg="#2b2b2b", fg="#7f8c8d", wraplength=460,
             justify="left").pack(anchor="w", padx=40, pady=(0, 5))

    ttk.Separator(popup, orient="horizontal").pack(fill="x", padx=20, pady=10)

    btn_frame = tk.Frame(popup, bg="#2b2b2b")
    btn_frame.pack(pady=6)
    _standard_buttons(popup, btn_frame, app, dismiss,
                       ("⏳ Finish The 3% (Upgrade)", "⏳ Business License",
                        "▤ License Info", "■ Leave It At 97% (Later)"))

    tk.Label(popup, text="97% is a perfectly respectable place to live, honestly.",
             bg="#2b2b2b", fg="#9aa0a6", font=("Segoe UI", 8), justify="center").pack(pady=(8, 12))


_VARIANTS = [_variant_1, _variant_2, _variant_3, _variant_4, _variant_5, _variant_6, _variant_7,
             _variant_8, _variant_9, _variant_10]


def show_trial_popup(app, on_close=None):
    """on_close: optional zero-arg callable invoked after the popup is
    dismissed (any path). Used by techdrive.py to chain the System
    Summary auto-open so launch order is:
    Trial popup (1st) -> System Summary (2nd) -> App (3rd).

    Each call picks one of 10 differently-skinned nag variants at
    random (never repeating the immediately-previous one within the
    same running session), so the joke stays fresh across launches."""
    from techdrive import TIER_INFO  # local import - avoids a circular import at module load

    choices = list(range(len(_VARIANTS)))
    if _last_variant[0] is not None and len(choices) > 1:
        choices.remove(_last_variant[0])
    idx = random.choice(choices)
    _last_variant[0] = idx

    _VARIANTS[idx](app, on_close, TIER_INFO)
