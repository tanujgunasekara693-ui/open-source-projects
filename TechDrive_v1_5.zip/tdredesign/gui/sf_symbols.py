#!/usr/bin/env python3
"""SF Symbols–style hierarchical icons drawn on Canvas.

Multicolor / hierarchical rendering that adapts to theme.
Not real SF Symbols assets — symbolic vector-ish glyphs for common tools.
"""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl


def draw_symbol(canvas, name, x, y, size=20, theme=None, primary=None, secondary=None, tertiary=None):
    """Draw a hierarchical symbol centered at (x,y). Returns item ids."""
    th = theme or fl.DARK
    p = primary or th.get("FG", "#fff")
    s = secondary or th.get("ACCENT", "#0a84ff")
    t = tertiary or th.get("MUTED", "#98989d")
    r = size / 2
    ids = []
    name = (name or "circle").lower()

    def oval(x1, y1, x2, y2, fill, outline=""):
        ids.append(canvas.create_oval(x1, y1, x2, y2, fill=fill, outline=outline))

    def line(x1, y1, x2, y2, fill, width=2):
        ids.append(canvas.create_line(x1, y1, x2, y2, fill=fill, width=width, capstyle=tk.ROUND))

    def rect(x1, y1, x2, y2, fill, outline=""):
        ids.append(canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=outline))

    if name in ("cpu", "chip"):
        rect(x - r * 0.5, y - r * 0.5, x + r * 0.5, y + r * 0.5, s)
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            line(x + dx * r * 0.5, y + dy * r * 0.5,
                 x + dx * r * 0.9, y + dy * r * 0.9, t, 2)
    elif name in ("memory", "ram"):
        rect(x - r * 0.7, y - r * 0.35, x + r * 0.7, y + r * 0.35, s)
        for i in range(3):
            xx = x - r * 0.4 + i * r * 0.4
            rect(xx - 2, y - r * 0.2, xx + 2, y + r * 0.2, p)
    elif name in ("disk", "storage"):
        oval(x - r * 0.8, y - r * 0.8, x + r * 0.8, y + r * 0.8, "", outline=s)
        oval(x - r * 0.25, y - r * 0.25, x + r * 0.25, y + r * 0.25, s)
    elif name in ("network", "wifi"):
        for i, sc in enumerate((0.9, 0.6, 0.3)):
            oval(x - r * sc, y - r * sc * 0.3, x + r * sc, y + r * sc * 0.9,
                 "", outline=s if i == 0 else t)
        oval(x - 2, y + r * 0.5, x + 2, y + r * 0.7, p)
    elif name in ("health", "heart"):
        # simple heart-ish with ovals
        oval(x - r * 0.55, y - r * 0.35, x, y + r * 0.2, s)
        oval(x, y - r * 0.35, x + r * 0.55, y + r * 0.2, s)
        ids.append(canvas.create_polygon(
            x - r * 0.7, y, x, y + r * 0.75, x + r * 0.7, y,
            fill=s, outline="",
        ))
    elif name in ("shield", "security"):
        ids.append(canvas.create_polygon(
            x, y - r * 0.85, x + r * 0.7, y - r * 0.4,
            x + r * 0.55, y + r * 0.5, x, y + r * 0.85,
            x - r * 0.55, y + r * 0.5, x - r * 0.7, y - r * 0.4,
            fill=s, outline="",
        ))
        line(x - r * 0.2, y, x - r * 0.05, y + r * 0.25, p, 2)
        line(x - r * 0.05, y + r * 0.25, x + r * 0.3, y - r * 0.25, p, 2)
    elif name in ("scan", "bolt"):
        ids.append(canvas.create_polygon(
            x - r * 0.15, y - r * 0.85, x + r * 0.35, y - r * 0.1,
            x + r * 0.05, y - r * 0.1, x + r * 0.25, y + r * 0.85,
            x - r * 0.35, y + r * 0.05, x - r * 0.05, y + r * 0.05,
            fill=s, outline="",
        ))
    elif name in ("settings", "gear"):
        oval(x - r * 0.35, y - r * 0.35, x + r * 0.35, y + r * 0.35, "", outline=s)
        oval(x - r * 0.15, y - r * 0.15, x + r * 0.15, y + r * 0.15, p)
        for i in range(6):
            import math
            a = i * math.pi / 3
            line(x + math.cos(a) * r * 0.4, y + math.sin(a) * r * 0.4,
                 x + math.cos(a) * r * 0.85, y + math.sin(a) * r * 0.85, s, 2)
    elif name in ("warning", "exclamation"):
        ids.append(canvas.create_polygon(
            x, y - r * 0.85, x + r * 0.75, y + r * 0.7, x - r * 0.75, y + r * 0.7,
            fill=s, outline="",
        ))
        rect(x - 2, y - r * 0.35, x + 2, y + r * 0.15, p)
        oval(x - 2.5, y + r * 0.3, x + 2.5, y + r * 0.55, p)
    else:
        oval(x - r * 0.7, y - r * 0.7, x + r * 0.7, y + r * 0.7, "", outline=s)
        oval(x - r * 0.25, y - r * 0.25, x + r * 0.25, y + r * 0.25, p)
    return ids


class SymbolIcon(tk.Canvas):
    """Small adaptive symbol widget."""

    def __init__(self, parent, name="circle", size=22, theme=None, aero=False, bg=None, **kw):
        th = theme or fl.DARK
        bg = bg or parent["bg"]
        super().__init__(parent, width=size + 4, height=size + 4, bg=bg,
                         highlightthickness=0, bd=0, **kw)
        self.name = name
        self.size = size
        self.theme = th
        self.bind("<Configure>", lambda e: self.redraw())
        self.redraw()

    def redraw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4:
            w = self.size + 4
            h = self.size + 4
        draw_symbol(self, self.name, w / 2, h / 2, size=self.size, theme=self.theme)

    def set_name(self, name):
        self.name = name
        self.redraw()
