#!/usr/bin/env python3
"""
gui/workspace_panel.py — Reusable "tool workspace" shell
==========================================================

Some tools (Disk Health, and eventually Network Monitor, Performance
Lab, etc.) have more going on than a single scroll of stat rows: an
at-a-glance summary, a drill-down per item, deep technical data, and a
history of past runs. Cramming all of that into one CardPanel makes the
tool feel cluttered; splitting it into separate top-level tabs in the
main notebook makes it feel like four different tools.

WorkspacePanel is the middle ground: one tool, one tab in the main
notebook, with its own small tab bar inside (Overview | Drives | SMART |
History, or whatever a given tool needs). It reuses the same visual
header (title/subtitle/status dot) that CardPanel/_panel_header use, so
a workspace-style tool still looks like a native part of TechDrive.

Usage from a tool_* method:

    def tool_disk_health_check(self, frame):
        ws = WorkspacePanel(frame, self.theme, aero=self.is_aero_enabled(),
                             icon="❤", title="Disk Health",
                             subtitle="Per-drive status, SMART data, and scan history",
                             on_refresh=lambda: self._run_bg(gather, redraw))

        overview = ws.add_tab("Overview")
        drives = ws.add_tab("Drives")
        smart = ws.add_tab("SMART")
        history = ws.add_tab("History")

        # build once; each tab keeps its own state/scroll position when
        # the user switches away and back, instead of being torn down.
        ...

Each tab returned by add_tab() is a plain themed tk.Frame that the
caller populates however it likes (CardPanel rows, GlassCards, a Text
widget, etc.) — WorkspacePanel only owns the header and the tab strip.
"""

import tkinter as tk
from tkinter import ttk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.theme import FONT_UI, FONT_UI_BOLD


class WorkspacePanel:
    """A tool panel with its own internal tab bar.

    Distinct from ClosableNotebook (which manages the *app's* top-level
    tool tabs, each closable): WorkspacePanel's tabs live *inside* one
    of those tool tabs, are not individually closable, and are meant to
    be built once and reused across refreshes — call .tab(name) to get
    back a previously-built frame and update its contents in place
    rather than rebuilding the whole workspace.
    """

    def __init__(self, parent, theme_colors, icon="", title="", subtitle="",
                 aero=False, on_refresh=None, on_close=None):
        self.theme = theme_colors
        self.parent = parent
        self._aero = aero
        self._tabs = {}          # name -> frame
        self._tab_ids = {}       # name -> notebook tab id
        self._on_tab_changed = {}  # name -> list of callbacks, fired once per switch-in

        th = theme_colors
        root = tk.Frame(parent, bg=th["BG"])
        root.pack(fill="both", expand=True)
        self.root = root

        # --- header: same shape as CardPanel's, so a workspace tool
        # still reads as "one of the family" rather than a bespoke UI.
        header = tk.Frame(root, bg=th["BG"])
        header.pack(fill="x", anchor="n")

        title_area = tk.Frame(header, bg=th["BG"])
        title_area.pack(side="left", fill="x", expand=True, padx=16, pady=(14, 4))
        title_text = f"{icon} {title}".strip()
        tk.Label(title_area, text=title_text, bg=th["BG"], fg=fl.glow_color(th, aero),
                 font=fl.F_TITLE(), anchor="w", justify="left").pack(fill="x", anchor="w")
        if subtitle:
            tk.Label(title_area, text=subtitle, bg=th["BG"], fg=th["MUTED"],
                     font=fl.F_SMALL(), anchor="w", justify="left", wraplength=760,
                     ).pack(fill="x", anchor="w")

        btns = tk.Frame(header, bg=th["BG"])
        btns.pack(side="right", padx=16, pady=(14, 4))
        close_fn = on_close or self._make_default_close()
        if close_fn is not None:
            tk.Button(btns, text="✕ Close", command=close_fn, bg=th["BG_LIGHT"],
                       fg=th["FG"], relief="flat", padx=10, pady=2).pack(side="right", padx=(6, 0))
        if on_refresh is not None:
            tk.Button(btns, text="⟳ Refresh", command=on_refresh, bg=th["BG_LIGHT"],
                       fg=th["FG"], relief="flat", padx=10, pady=2).pack(side="right")

        status_row = tk.Frame(root, bg=th["BG"])
        status_row.pack(fill="x", padx=16, pady=(2, 8), anchor="w")
        tk.Label(status_row, text="STATUS", bg=th["BG"], fg=th["MUTED"],
                  font=fl.font(8, "bold")).pack(side="left")
        self._status_dot = tk.Label(status_row, text="●", bg=th["BG"], font=fl.font(10),
                                      fg=th["ACCENT_GLOW"])
        self._status_dot.pack(side="left", padx=(9, 4))
        self._status_lbl = tk.Label(status_row, text="Ready", bg=th["BG"], fg=th["FG"],
                                      font=fl.F_SMALL())
        self._status_lbl.pack(side="left")

        tk.Frame(root, bg=th["STROKE"], height=1).pack(fill="x", padx=16, pady=(0, 8))

        # --- the internal tab strip. Built with the plain ttk.Notebook
        # (not ClosableNotebook — these tabs are permanent, not closable).
        style_name = self._ensure_style()
        self.notebook = ttk.Notebook(root, style=style_name)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.notebook.bind("<<NotebookTabChanged>>", self._fire_tab_changed, True)

    # -- status ----------------------------------------------------------
    def set_status(self, text, kind="ready"):
        colors = {"busy": fl.WARN, "error": "#ff5c5c", "done": self.theme["ACCENT_GLOW"],
                   "ready": self.theme["ACCENT_GLOW"]}
        try:
            self._status_dot.config(fg=colors.get(kind, self.theme["ACCENT_GLOW"]))
            self._status_lbl.config(text=text)
        except tk.TclError:
            pass  # tab closed mid-update

    # -- tabs --------------------------------------------------------------
    def add_tab(self, name, scrollable=True):
        """Create (or return the existing) tab frame for *name*.

        Safe to call repeatedly with the same name — returns the already
        built frame rather than duplicating the tab, so callers can lay
        out all of a workspace's tabs up-front without guarding against
        re-entry themselves.
        """
        if name in self._tabs:
            return self._tabs[name]

        th = self.theme
        if scrollable:
            _canvas, body = make_scrollable(self.notebook, th["BG"])
            container = _canvas
        else:
            container = tk.Frame(self.notebook, bg=th["BG"])
            body = container

        self.notebook.add(container, text=name)
        self._tabs[name] = body
        self._tab_ids[name] = container
        return body

    def tab(self, name):
        """Return a previously created tab's content frame, or None."""
        return self._tabs.get(name)

    def clear_tab(self, name):
        """Remove all children from a tab so it can be repopulated
        in place (same convention as CardPanel.clear())."""
        frame = self._tabs.get(name)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()

    def select(self, name):
        container = self._tab_ids.get(name)
        if container is not None:
            try:
                self.notebook.select(container)
            except tk.TclError:
                pass

    def on_tab_shown(self, name, callback):
        """Register *callback* (zero-arg) to run the first time tab
        *name* is switched into — handy for lazy-loading a tab's data
        (e.g. only query SMART data once the user actually opens the
        SMART tab) without re-running it every time they switch back."""
        self._on_tab_changed.setdefault(name, []).append(callback)

    def _fire_tab_changed(self, _event=None):
        try:
            current = self.notebook.select()
            text = self.notebook.tab(current, "text")
        except tk.TclError:
            return
        callbacks = self._on_tab_changed.get(text)
        if callbacks:
            # Each callback fires once, then is dropped, so returning to
            # a tab later doesn't re-trigger a load that already ran.
            for cb in callbacks:
                try:
                    cb()
                except Exception:
                    pass
            self._on_tab_changed[text] = []

    # -- plumbing ------------------------------------------------------
    def _ensure_style(self):
        """A ttk.Notebook style tuned to sit inside a tool panel (flat,
        no border, themed tab colors) rather than looking like a second
        app chrome nested inside the first."""
        th = self.theme
        style = ttk.Style()
        name = "WorkspacePanel.TNotebook"
        try:
            style.configure(name, background=th["BG"], borderwidth=0, tabmargins=(2, 4, 2, 0))
            style.configure(f"{name}.Tab", background=th["BG_LIGHT"], foreground=th["FG"],
                              padding=(12, 6), font=FONT_UI)
            style.map(f"{name}.Tab",
                       background=[("selected", th["ACCENT"])],
                       foreground=[("selected", th.get("ON_ACCENT", "#ffffff"))])
        except tk.TclError:
            pass  # some ttk builds reject a subset of these options; tabs still work
        return name

    def _make_default_close(self):
        from gui.closable_notebook import ClosableNotebook
        widget = self.parent
        tab_frame = None
        notebook = None
        while widget is not None:
            master = widget.nametowidget(widget.winfo_parent()) if widget.winfo_parent() else None
            if isinstance(master, ClosableNotebook):
                tab_frame = widget
                notebook = master
                break
            widget = master
        if tab_frame is None:
            return None

        def _close():
            try:
                notebook.close_tab(tab_frame)
            except tk.TclError:
                pass

        return _close
