"""
TechDrive Snapshot Manager
==========================

One place for named TechDrive snapshots. Each snapshot stores a small,
read-only machine-state record for comparison and, on Windows, attempts to
pair it with a real System Restore point for restoration.

Restore is always explicit and warns that Windows may reboot. Snapshot
creation and restore never happen silently from a list click.
"""

import datetime as _datetime
import json
import os
import platform
import shutil
import socket
import subprocess
import tkinter as tk
from gui.tk_dialogs import messagebox, simpledialog

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton
from shared import database as db

try:
    import psutil
except ImportError:  # pragma: no cover - optional runtime dependency
    psutil = None


IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = (
    subprocess.CREATE_NO_WINDOW
    if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW")
    else 0
)


def _date_label(value):
    try:
        return _datetime.datetime.fromtimestamp(float(value)).strftime("%b %d %H:%M")
    except (TypeError, ValueError, OSError):
        return "Unknown date"


def _powershell_json(script, timeout=90):
    if not IS_WINDOWS:
        return None, "System Restore points are available only on Windows."
    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                script,
            ],
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
            creationflags=NO_WINDOW,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip()
        if result.returncode != 0:
            return None, output or f"PowerShell exited with code {result.returncode}."
        if not output:
            return None, "The Windows command returned no output."
        return json.loads(output), None
    except subprocess.TimeoutExpired:
        return None, "The Windows command timed out."
    except FileNotFoundError:
        return None, "powershell.exe is not available on this PC."
    except json.JSONDecodeError as exc:
        return None, f"Windows returned an unreadable restore-point result: {exc}"
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def _capture_machine_state():
    """Capture comparison-safe local facts without serial numbers or secrets."""
    state = {
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor() or "Not returned",
            "hostname": socket.gethostname(),
        },
        "memory_total": None,
        "disk": None,
        "network_adapters": [],
    }
    if psutil is None:
        return state
    try:
        state["memory_total"] = int(psutil.virtual_memory().total)
    except Exception:
        pass
    try:
        root = os.environ.get("SystemDrive", os.path.abspath(os.sep))
        usage = shutil.disk_usage(root)
        state["disk"] = {
            "path": root,
            "total": int(usage.total),
            "free": int(usage.free),
            "used": int(usage.used),
        }
    except Exception:
        pass
    try:
        stats = psutil.net_if_stats()
        addresses = psutil.net_if_addrs()
        for name, stat in sorted(stats.items()):
            if name.lower() in {"lo", "loopback"}:
                continue
            ipv4 = next(
                (
                    item.address
                    for item in addresses.get(name, [])
                    if getattr(item, "family", None) == socket.AF_INET
                ),
                None,
            )
            state["network_adapters"].append({
                "name": name,
                "up": bool(stat.isup),
                "speed_mbps": int(stat.speed or 0),
                "ipv4": ipv4,
            })
    except Exception:
        pass
    return state


def _create_windows_restore_point(label):
    safe_label = label.replace("'", "''")
    script = (
        f"$description = '{safe_label}'; "
        "Checkpoint-Computer -Description $description "
        "-RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; "
        "Get-ComputerRestorePoint | Sort-Object CreationTime -Descending | "
        "Select-Object -First 1 SequenceNumber,Description,CreationTime | "
        "ConvertTo-Json -Compress"
    )
    return _powershell_json(script)


def create_snapshot(label):
    """Capture a local TechDrive snapshot and pair it with System Restore."""
    state = _capture_machine_state()
    restore_point = None
    restore_error = None
    if IS_WINDOWS:
        restore_point, restore_error = _create_windows_restore_point(label)
        if isinstance(restore_point, list):
            restore_point = restore_point[0] if restore_point else None
    return {
        "label": label,
        "payload": state,
        "restore_point_number": (
            int(restore_point.get("SequenceNumber"))
            if isinstance(restore_point, dict) and restore_point.get("SequenceNumber") is not None
            else None
        ),
        "restore_point_time": (
            str(restore_point.get("CreationTime"))
            if isinstance(restore_point, dict) and restore_point.get("CreationTime")
            else None
        ),
        "restore_point_description": (
            str(restore_point.get("Description"))
            if isinstance(restore_point, dict) and restore_point.get("Description")
            else None
        ),
        "restore_error": restore_error,
    }


def restore_snapshot(snapshot):
    sequence = snapshot.get("restore_point_number")
    if not IS_WINDOWS:
        return False, "Windows System Restore is unavailable on this operating system."
    if sequence is None:
        return False, "This snapshot has no associated Windows Restore point."
    script = f"Restore-Computer -RestorePoint {int(sequence)} -Confirm:$false"
    _, error = _powershell_json(
        f"try {{ {script}; "
        "[pscustomobject]@{Started=$true} | ConvertTo-Json -Compress "
        "} catch { "
        "[pscustomobject]@{Started=$false; Error=$_.Exception.Message} | "
        "ConvertTo-Json -Compress; exit 1 }",
        timeout=120,
    )
    if error:
        return False, error
    return True, (
        f"Restore to '{snapshot.get('label', 'snapshot')}' was initiated. "
        "Windows may restart to complete it."
    )


def _format_bytes(value):
    if value is None:
        return "—"
    number = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(number) < 1024:
            return f"{number:.1f} {unit}"
        number /= 1024
    return f"{number:.1f} PB"


def _value_text(value):
    if value is None:
        return "not returned"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, list):
        return ", ".join(str(item) for item in value) or "none"
    return str(value)


def compare_snapshots(left, right):
    """Return human-readable differences between two captured states."""
    a = left.get("payload") or {}
    b = right.get("payload") or {}
    changes = []

    for path, label in (
        (("platform", "release"), "Windows release"),
        (("platform", "version"), "OS version"),
        (("platform", "machine"), "Machine architecture"),
        (("platform", "processor"), "Processor"),
        (("memory_total",), "Installed memory"),
    ):
        current_a = a
        current_b = b
        for key in path:
            current_a = current_a.get(key) if isinstance(current_a, dict) else None
            current_b = current_b.get(key) if isinstance(current_b, dict) else None
        if current_a != current_b:
            if path == ("memory_total",):
                current_a = _format_bytes(current_a)
                current_b = _format_bytes(current_b)
            changes.append(f"{label}: {_value_text(current_a)} → {_value_text(current_b)}")

    disk_a = a.get("disk") or {}
    disk_b = b.get("disk") or {}
    if disk_a.get("free") != disk_b.get("free"):
        changes.append(
            f"Free system-drive space: {_format_bytes(disk_a.get('free'))} → "
            f"{_format_bytes(disk_b.get('free'))}"
        )

    adapters_a = {
        item.get("name"): item for item in a.get("network_adapters", [])
    }
    adapters_b = {
        item.get("name"): item for item in b.get("network_adapters", [])
    }
    for name in sorted(set(adapters_a) | set(adapters_b)):
        item_a = adapters_a.get(name)
        item_b = adapters_b.get(name)
        if item_a is None:
            changes.append(f"Adapter added: {name}")
        elif item_b is None:
            changes.append(f"Adapter missing: {name}")
        elif item_a != item_b:
            changes.append(
                f"Adapter changed: {name} "
                f"({_value_text(item_a.get('speed_mbps'))} Mbps / "
                f"{'up' if item_a.get('up') else 'down'} → "
                f"{_value_text(item_b.get('speed_mbps'))} Mbps / "
                f"{'up' if item_b.get('up') else 'down'})"
            )
    return changes


class SnapshotManagerPage(tk.Frame):
    """Named snapshots with compare and explicitly confirmed restore."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._busy = False
        self.snapshots = []
        _, self.content = make_scrollable(self, self.theme["BG"])
        self._build()

    def _build(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  SNAPSHOT MANAGER",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        title_row = tk.Frame(header, bg=self.theme["BG"])
        title_row.pack(fill="x", pady=(4, 2))
        tk.Label(title_row, text="Snapshots", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(side="left")
        tk.Label(
            header,
            text="Save named machine-state baselines, compare captured changes, "
                 "and restore through an explicitly confirmed Windows Restore point.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=850, justify="left",
        ).pack(anchor="w")

        action_card = GlassCard(root, self.theme, aero=self.aero,
                                accent=self.theme["ACCENT"])
        action_card.pack(fill="x", padx=24, pady=(8, 14))
        row = tk.Frame(action_card.body, bg=action_card.fill)
        row.pack(fill="x", padx=18, pady=16)
        tk.Label(
            row,
            text="Create a local comparison record and, on Windows, a real "
                 "System Restore point.",
            bg=action_card.fill, fg=self.theme["FG"], font=fl.F_SMALL(),
            wraplength=420, justify="left",
        ).pack(side="left", fill="x", expand=True)
        self.create_button = FluentButton(
            row, "CREATE SNAPSHOT", command=self._prompt_create,
            theme=self.theme, aero=self.aero, kind="accent", icon="＋",
            width=180, height=40, backdrop=action_card.fill,
        )
        self.create_button.pack(side="right")
        self.status_var = tk.StringVar(value="Select one or two snapshots to compare or restore.")
        tk.Label(action_card.body, textvariable=self.status_var,
                 bg=action_card.fill, fg=self.theme["MUTED"],
                 font=fl.F_TINY(), wraplength=850, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 14))

        self.list_card = GlassCard(root, self.theme, aero=self.aero,
                                   accent=fl.GOOD)
        self.list_card.pack(fill="x", padx=24, pady=(0, 14))
        self.list_body = self.list_card.body
        self._render_list_shell()

        self.detail = tk.Frame(root, bg=self.theme["BG"])
        self.detail.pack(fill="x", padx=24, pady=(0, 14))
        self._render_detail("Select snapshots to see comparison details.")
        self.refresh()

    def _render_list_shell(self):
        body = self.list_body
        tk.Label(body, text="SNAPSHOTS", bg=self.list_card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text="Named restore points and TechDrive baselines",
                 bg=self.list_card.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE()).pack(anchor="w", padx=18, pady=(0, 8))
        list_row = tk.Frame(body, bg=self.list_card.fill)
        list_row.pack(fill="x", padx=18, pady=(0, 12))
        self.listbox = tk.Listbox(
            list_row,
            selectmode=tk.EXTENDED,
            height=8,
            bg=self.theme["SURFACE"],
            fg=self.theme["TEXT_FG"],
            selectbackground=self.theme["SELECTION"],
            selectforeground=self.theme["FG"],
            activestyle="none",
            relief="flat",
            highlightthickness=0,
            font=fl.F_BODY(),
        )
        self.listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_row, orient="vertical",
                                 command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=scrollbar.set)
        self.listbox.bind("<<ListboxSelect>>", lambda _event: self._selection_changed())
        buttons = tk.Frame(body, bg=self.list_card.fill)
        buttons.pack(fill="x", padx=18, pady=(0, 16))
        self.compare_button = FluentButton(
            buttons, "COMPARE", command=self._compare_selected,
            theme=self.theme, aero=self.aero, kind="standard", width=120,
            height=34, backdrop=self.list_card.fill,
        )
        self.compare_button.pack(side="left")
        self.restore_button = FluentButton(
            buttons, "RESTORE", command=self._restore_selected,
            theme=self.theme, aero=self.aero, kind="standard", width=120,
            height=34, backdrop=self.list_card.fill,
        )
        self.restore_button.pack(side="left", padx=(8, 0))

    def refresh(self):
        self.snapshots = db.get_snapshots(limit=100)
        self.listbox.delete(0, tk.END)
        for snapshot in self.snapshots:
            restore = " • restore point" if snapshot.get("restore_point_number") else " • local only"
            self.listbox.insert(
                tk.END,
                f"●  {snapshot.get('label', 'Unnamed snapshot')}    "
                f"{_date_label(snapshot.get('created_at'))}{restore}",
            )
        if not self.snapshots:
            self.listbox.insert(tk.END, "No snapshots yet — create one before a driver update or repair.")
            self.listbox.itemconfig(0, foreground=self.theme["MUTED"])
        self._selection_changed()

    def _selected(self):
        return [
            self.snapshots[index]
            for index in self.listbox.curselection()
            if index < len(self.snapshots)
        ]

    def _selection_changed(self):
        count = len(self._selected())
        if count == 2:
            self.status_var.set("Two snapshots selected. Compare the captured machine state.")
        elif count == 1:
            self.status_var.set("One snapshot selected. Compare needs two; Restore needs one.")
        else:
            self.status_var.set("Select one or two snapshots to compare or restore.")

    def _prompt_create(self):
        if self._busy:
            return
        label = simpledialog.askstring(
            "Create Snapshot",
            "Snapshot name:",
            initialvalue="Before Driver Update",
            parent=self.winfo_toplevel(),
        )
        if not label or not label.strip():
            return
        label = label.strip()[:120]
        message = (
            f"Create snapshot '{label}'?\n\n"
            "TechDrive will save a local comparison record."
        )
        if IS_WINDOWS:
            message += (
                "\n\nIt will also ask Windows to create a System Restore point. "
                "This may require Administrator permission."
            )
        if not messagebox.askyesno("Confirm Snapshot", message, parent=self.winfo_toplevel()):
            return
        self._busy = True
        self.create_button.configure(state="disabled")
        self.status_var.set(f"Creating '{label}'…")
        self.app._run_bg(lambda: create_snapshot(label), self._finish_create)

    def _finish_create(self, result):
        self._busy = False
        self.create_button.configure(state="normal")
        if hasattr(result, "message"):
            self.status_var.set(f"Snapshot failed: {result}")
            return
        snapshot_id = db.add_snapshot(
            result["label"],
            result["payload"],
            restore_point_number=result.get("restore_point_number"),
            restore_point_time=result.get("restore_point_time"),
            restore_point_description=result.get("restore_point_description"),
            restore_error=result.get("restore_error"),
        )
        if result.get("restore_error"):
            self.status_var.set(
                f"Saved '{result['label']}' locally, but Windows Restore point "
                f"was not created: {result['restore_error']}"
            )
        elif result.get("restore_point_number"):
            self.status_var.set(
                f"Created '{result['label']}' with Windows Restore point "
                f"#{result['restore_point_number']}."
            )
        else:
            self.status_var.set(f"Created local snapshot '{result['label']}'.")
        self.refresh()
        if snapshot_id:
            self.listbox.selection_set(0)
            self.listbox.see(0)

    def _compare_selected(self):
        selected = self._selected()
        if len(selected) != 2:
            messagebox.showinfo(
                "Compare Snapshots",
                "Select exactly two snapshots to compare.",
                parent=self.winfo_toplevel(),
            )
            return
        self._render_detail(
            self._comparison_text(selected[0], selected[1])
        )

    def _comparison_text(self, left, right):
        changes = compare_snapshots(left, right)
        lines = [
            f"{left.get('label', 'Snapshot')}  →  {right.get('label', 'Snapshot')}",
            f"{_date_label(left.get('created_at'))}  →  {_date_label(right.get('created_at'))}",
            "",
        ]
        if changes:
            lines.append("Observed changes:")
            lines.extend(f"• {change}" for change in changes)
        else:
            lines.append("No differences were found in the captured comparison fields.")
        lines.extend([
            "",
            "This compares TechDrive's captured metadata only. It is not a "
            "full file, registry, driver, or application diff.",
        ])
        return "\n".join(lines)

    def _restore_selected(self):
        selected = self._selected()
        if len(selected) != 1:
            messagebox.showinfo(
                "Restore Snapshot",
                "Select exactly one snapshot to restore.",
                parent=self.winfo_toplevel(),
            )
            return
        snapshot = selected[0]
        if not snapshot.get("restore_point_number"):
            messagebox.showinfo(
                "Restore Snapshot",
                "This is a local-only snapshot and has no Windows Restore point. "
                "Create the snapshot again on Windows with System Protection enabled.",
                parent=self.winfo_toplevel(),
            )
            return
        confirmed = messagebox.askyesno(
            "Confirm Windows Restore",
            f"Restore '{snapshot.get('label', 'snapshot')}'?\n\n"
            "Windows may restart the computer. Save work and close applications "
            "before continuing. This action changes system state and cannot be "
            "undone from TechDrive.",
            parent=self.winfo_toplevel(),
        )
        if not confirmed:
            return
        self._busy = True
        self.restore_button.configure(state="disabled")
        self.status_var.set(f"Starting restore for '{snapshot.get('label')}'…")
        self.app._run_bg(
            lambda: restore_snapshot(snapshot),
            self._finish_restore,
        )

    def _finish_restore(self, result):
        self._busy = False
        self.restore_button.configure(state="normal")
        if hasattr(result, "message"):
            self.status_var.set(f"Restore failed safely: {result}")
            return
        ok, message = result
        self.status_var.set(message if ok else f"Restore failed: {message}")
        self._render_detail(message)

    def _render_detail(self, text):
        for child in self.detail.winfo_children():
            child.destroy()
        card = GlassCard(self.detail, self.theme, aero=self.aero,
                         accent=self.theme["ACCENT2"])
        card.pack(fill="x")
        tk.Label(card.body, text="SNAPSHOT NOTES", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(card.body, text=text, bg=card.fill, fg=self.theme["FG"],
                 font=fl.F_SMALL(), wraplength=850,
                 justify="left").pack(anchor="w", padx=18, pady=(0, 16))
