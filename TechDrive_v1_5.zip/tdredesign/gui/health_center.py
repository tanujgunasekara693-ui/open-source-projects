#!/usr/bin/env python3
"""
TechDrive Health Center
=======================

The Health Center is intentionally a read-only orchestration layer.  It
collects a practical snapshot from psutil and, on Windows, from native
PowerShell/Windows utilities.  It never repairs, deletes, disables, starts,
or changes anything on the user's PC.

The checks are kept here instead of in a plugin so the single "SCAN MY PC"
experience remains available even when the optional tool catalogue is empty
or a plugin has not been installed yet.
"""

import datetime as _datetime
import os
import platform
import re
import subprocess
import tkinter as tk

from gui import achievements, fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton, HealthRing, MeterBar
from shared import database as db

try:
    import psutil
except ImportError:  # pragma: no cover - the app already supports this fallback
    psutil = None


WINDOWS_CHECKS = "Run TechDrive on Windows for this check."


def _run_argv(argv, timeout=30):
    """Run a fixed, read-only command without a shell."""
    try:
        result = subprocess.run(
            argv, shell=False, capture_output=True, text=True,
            timeout=timeout, errors="replace",
        )
        output = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, output.strip()
    except subprocess.TimeoutExpired:
        return False, "Command timed out."
    except FileNotFoundError:
        return False, f"{argv[0]} is not available."
    except Exception as exc:
        return False, str(exc)


def _powershell(script, timeout=30):
    return _run_argv(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
         "Bypass", "-Command", script],
        timeout=timeout,
    )


def _item(title, explanation, action, severity="good"):
    return {
        "title": title,
        "explanation": explanation,
        "action": action,
        "severity": severity,
    }


def _result(key, label, score, items):
    return {"key": key, "label": label, "score": int(max(0, min(100, score))),
            "items": items}


def _unavailable(title, why=WINDOWS_CHECKS):
    return _item(
        title,
        f"TechDrive could not measure this safely here: {why}",
        "No change was made. Re-run Health Center on the target Windows PC "
        "for a device-specific reading.",
        "info",
    )


def _score_usage(percent, good_at=70, warn_at=85):
    if percent <= good_at:
        return 100
    if percent <= warn_at:
        return 88
    if percent <= 95:
        return 70
    return 48


def _check_cpu():
    if not psutil:
        return _result("cpu", "CPU", 80, [_item(
            "CPU usage was not available",
            "The optional psutil package is not installed, so TechDrive "
            "cannot sample processor load.",
            "Install the TechDrive runtime dependencies and scan again.",
            "info")])
    usage = float(psutil.cpu_percent(interval=0.45))
    logical = psutil.cpu_count(logical=True) or 0
    physical = psutil.cpu_count(logical=False) or logical
    score = _score_usage(usage, 70, 85)
    if usage <= 70:
        item = _item(
            f"CPU load is {usage:.0f}%",
            f"The current snapshot is comfortable across {physical} physical "
            f"and {logical} logical cores.",
            "No action needed. Keep an eye on sustained load rather than a "
            "single busy moment.",
        )
    elif usage <= 85:
        item = _item(
            f"CPU load is elevated at {usage:.0f}%",
            "The processor is working harder than normal during this scan, "
            "but this is not by itself evidence of a fault.",
            "Close an unneeded heavy application and scan again after a few "
            "minutes of normal use.",
            "warn",
        )
    else:
        item = _item(
            f"CPU load is high at {usage:.0f}%",
            "A sustained load this high can make the PC feel slow and may "
            "indicate a runaway process or a demanding task.",
            "Open Task Manager, sort by CPU, and investigate the top process "
            "before changing or uninstalling anything.",
            "bad",
        )
    return _result("cpu", "CPU", score, [item])


def _check_ram():
    if not psutil:
        return _result("ram", "RAM", 80, [_unavailable(
            "RAM usage was not available",
            "psutil is not installed.",
        )])
    memory = psutil.virtual_memory()
    usage = float(memory.percent)
    score = _score_usage(usage, 72, 88)
    detail = f"{usage:.0f}% in use ({_bytes(memory.used)} of {_bytes(memory.total)})."
    if usage <= 72:
        item = _item("Memory headroom is healthy", detail,
                     "No action needed. Keep at least a small amount of free "
                     "memory for Windows and background services.")
    elif usage <= 88:
        item = _item("Memory headroom is getting tight", detail,
                     "Close unused browser tabs or large applications, then "
                     "scan again if the slowdown continues.", "warn")
    else:
        item = _item("Memory pressure is high", detail,
                     "Save your work, close the heaviest apps, and check Task "
                     "Manager for an app with an unusual memory increase.", "bad")
    return _result("ram", "RAM", score, [item])


def _check_gpu():
    if not _is_windows():
        return _result("gpu", "GPU", 82, [_unavailable(
            "GPU inventory is Windows-specific",
            "the installed GPU provider is queried through Windows hardware "
            "inventory.",
        )])
    ok, output = _powershell(
        "Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue "
        "| Select-Object -ExpandProperty Name",
        timeout=20,
    )
    names = [line.strip() for line in output.splitlines()
             if line.strip() and "Name" not in line]
    if ok and names:
        shown = ", ".join(names[:2])
        if len(names) > 2:
            shown += f" (+{len(names) - 2} more)"
        return _result("gpu", "GPU", 96, [_item(
            "GPU detected",
            f"Windows reports {shown}. Health Center confirms inventory but "
            "does not run a stress test during a normal scan.",
            "No action needed. Use the dedicated GPU monitor or stress test "
            "if you are investigating crashes or artifacts.",
        )])
    return _result("gpu", "GPU", 82, [_item(
        "GPU inventory was inconclusive",
        "Windows did not return a display adapter name through the standard "
        "read-only inventory query.",
        "Check Device Manager for a disabled or unrecognized Display adapter; "
        "do not install a driver from an untrusted site.",
        "info",
    )])


def _check_storage():
    if not psutil:
        return _result("storage", "Storage", 80, [_unavailable(
            "Storage usage was not available", "psutil is not installed.")])
    root = os.environ.get("SystemDrive", os.path.abspath(os.sep))
    try:
        disk = psutil.disk_usage(root)
    except Exception as exc:
        return _result("storage", "Storage", 70, [_unavailable(
            "Storage usage could not be read", str(exc))])
    used = float(disk.percent)
    free = 100.0 - used
    score = 100 if free >= 25 else 88 if free >= 15 else 68 if free >= 8 else 45
    detail = f"{used:.0f}% used; {_bytes(disk.free)} free of {_bytes(disk.total)}."
    if free >= 25:
        item = _item("System drive has healthy headroom", detail,
                     "No action needed. Keeping a quarter of the drive free "
                     "helps updates and temporary files.")
    elif free >= 15:
        item = _item("System drive is starting to fill", detail,
                     "Review large files and uninstall apps you no longer use; "
                     "avoid deleting Windows folders manually.", "warn")
    else:
        item = _item("System drive has low free space", detail,
                     "Use Disk Cleanup or Storage settings to remove temporary "
                     "files safely before installing updates.", "bad")
    return _result("storage", "Storage", score, [item])


def _check_smart():
    if not _is_windows():
        return _result("smart", "SMART", 82, [_unavailable(
            "SMART health was not queried",
            "drive health is read from Windows physical-disk inventory.",
        )])
    ok, output = _powershell(
        "Get-PhysicalDisk -ErrorAction SilentlyContinue "
        "| Select-Object FriendlyName,HealthStatus,OperationalStatus "
        "| ConvertTo-Csv -NoTypeInformation",
        timeout=25,
    )
    if ok and output:
        lower = output.lower()
        bad_words = ("unhealthy", "warning", "failed", "degraded")
        if any(word in lower for word in bad_words):
            return _result("smart", "SMART", 42, [_item(
                "A physical disk reported a warning",
                "Windows PhysicalDisk inventory contains an unhealthy, "
                "warning, failed, or degraded status.",
                "Back up important files immediately and check the affected "
                "drive's exact status before replacing or repairing it.",
                "bad",
            )])
        if "healthy" in lower or "online" in lower:
            return _result("smart", "SMART", 100, [_item(
                "Physical disks report healthy/online",
                "Windows returned healthy or online status for the physical "
                "disk inventory. This is a status check, not a surface scan.",
                "No action needed. Keep a current backup because SMART is an "
                "early signal, not a guarantee.",
            )])
    ok, output = _run_argv(["wmic", "diskdrive", "get", "status"], timeout=20)
    if ok and output and "OK" in output.upper():
        return _result("smart", "SMART", 94, [_item(
            "SMART status reports OK",
            "The legacy Windows disk query returned OK for the available "
            "physical disks.",
            "No action needed; continue maintaining a current backup.",
        )])
    return _result("smart", "SMART", 78, [_item(
        "SMART status was inconclusive",
        "Windows did not provide a definitive health value through the "
        "available read-only disk queries.",
        "Check the drive vendor's health utility or TechDrive's Disk Health "
        "tool before assuming the disk is failing.",
        "info",
    )])


def _check_windows_services():
    if not _is_windows():
        return _result("services", "Windows services", 82, [_unavailable(
            "Windows services were not inspected")])
    script = (
        "$names='WinDefend','wuauserv','BITS','Dhcp','Dnscache'; "
        "Get-Service -Name $names -ErrorAction SilentlyContinue | "
        "ForEach-Object { '{0}|{1}' -f $_.Name,$_.Status }"
    )
    ok, output = _powershell(script, timeout=25)
    rows = [line.strip().split("|", 1) for line in output.splitlines()
            if "|" in line]
    stopped = [row[0] for row in rows if len(row) == 2 and
               row[1].lower() not in ("running", "startpending")]
    if not ok and not rows:
        return _result("services", "Windows services", 75, [_item(
            "Service status could not be read",
            output or "PowerShell returned no service data.",
            "Run TechDrive as a normal Windows user first; only use an "
            "administrator session if Windows itself asks for it.",
            "info",
        )])
    if stopped:
        return _result("services", "Windows services", 72, [_item(
            f"{len(stopped)} important service(s) are not running",
            "The snapshot found: " + ", ".join(stopped) + ". Some services "
            "are intentionally manual, so this is a review signal rather "
            "than an automatic fault.",
            "Open Services and verify each service's startup type and recent "
            "errors before changing anything.",
            "warn",
        )])
    return _result("services", "Windows services", 98, [_item(
        "Core Windows services look active",
        f"TechDrive read {len(rows)} of the selected update, network, and "
        "security services and found no stopped service in the snapshot.",
        "No action needed. Service state can change as Windows starts or "
        "stops on-demand components.",
    )])


def _check_startup():
    if not _is_windows():
        return _result("startup", "Startup programs", 82, [_unavailable(
            "Startup programs were not enumerated")])
    ok, output = _powershell(
        "(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue "
        "| Measure-Object).Count",
        timeout=25,
    )
    match = re.search(r"\b\d+\b", output or "")
    if match:
        count = int(match.group())
        score = 100 if count <= 8 else 90 if count <= 15 else 72 if count <= 25 else 55
        if count <= 15:
            item = _item(
                f"{count} startup program(s) detected",
                "The count is within a range that is common for a Windows PC; "
                "the scan does not disable anything.",
                "No action needed. Review startup entries only if boot time or "
                "background activity is a problem.",
            )
        else:
            item = _item(
                f"{count} startup programs may slow boot",
                "A large startup set can increase boot time and background "
                "memory use, even when every item is legitimate.",
                "Review Startup apps in Task Manager and disable only apps "
                "you recognize and do not need at sign-in.", "warn")
        return _result("startup", "Startup programs", score, [item])
    return _result("startup", "Startup programs", 76, [_item(
        "Startup inventory was inconclusive",
        output or "Windows returned no startup count.",
        "Review Startup apps in Task Manager if boot time is unexpectedly "
        "slow; Health Center did not change any entries.",
        "info",
    )])


def _check_drivers():
    if not _is_windows():
        return _result("drivers", "Drivers", 82, [_unavailable(
            "Driver problem codes were not inspected")])
    script = (
        "$bad=@(Get-CimInstance Win32_PnPSignedDriver "
        "-ErrorAction SilentlyContinue | Where-Object "
        "{$_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0}); "
        "'BAD=' + $bad.Count"
    )
    ok, output = _powershell(script, timeout=35)
    match = re.search(r"BAD=(\d+)", output or "", re.I)
    if match:
        count = int(match.group(1))
        if count == 0:
            return _result("drivers", "Drivers", 98, [_item(
                "No Plug and Play driver problem codes found",
                "Windows returned zero non-zero ConfigManagerErrorCode values "
                "in the signed-driver inventory.",
                "No action needed. Do not update a driver simply because a "
                "newer version exists.",
            )])
        return _result("drivers", "Drivers", 50, [_item(
            f"{count} driver problem code(s) found",
            "At least one device reports a non-zero Windows problem code; "
            "the scan does not guess which driver should replace it.",
            "Open Device Manager, inspect the device with the warning icon, "
            "and use Windows Update or the hardware maker's site.", "bad")])
    return _result("drivers", "Drivers", 76, [_item(
        "Driver inventory was inconclusive",
        output or "Windows returned no signed-driver problem count.",
        "Check Device Manager for warning icons. No driver was installed or "
        "changed by this scan.", "info")])


def _check_system_files():
    if not _is_windows():
        return _result("system_files", "System files", 82, [_unavailable(
            "Windows system files were not verified")])
    ok, output = _run_argv(["sfc", "/verifyonly"], timeout=90)
    lower = (output or "").lower()
    if "no integrity violations" in lower or "did not find any integrity" in lower:
        return _result("system_files", "System files", 100, [_item(
            "Windows Resource Protection found no integrity violations",
            "SFC completed its read-only verification and did not report "
            "corrupted protected files.",
            "No action needed. This scan verified files without attempting "
            "a repair.",
        )])
    if "corrupt" in lower or "violation" in lower or "repair" in lower:
        return _result("system_files", "System files", 55, [_item(
            "SFC reported a possible system-file issue",
            output[-900:] if output else "SFC returned a warning.",
            "Save your work, then review the full SFC result before running "
            "a repair. Back up important files first.", "warn")])
    if not ok and "timed out" in lower:
        return _result("system_files", "System files", 70, [_item(
            "System-file verification timed out",
            "SFC did not finish within the safe scan window; no repair was "
            "attempted.",
            "Run `sfc /verifyonly` from an elevated Command Prompt when you "
            "can leave the PC idle, then review the result.", "info")])
    return _result("system_files", "System files", 78, [_item(
        "System-file verification was inconclusive",
        output[-900:] if output else "Windows returned no readable SFC result.",
        "Review the CBS log or run SFC from an elevated Windows session; "
        "Health Center did not change system files.", "info")])


def _check_event_logs():
    if not _is_windows():
        return _result("event_logs", "Event logs", 82, [_unavailable(
            "Windows event logs were not inspected")])
    script = (
        "$start=(Get-Date).AddDays(-7); "
        "$events=@(Get-WinEvent -FilterHashtable "
        "@{LogName='System';Level=1,2;StartTime=$start} "
        "-ErrorAction SilentlyContinue); "
        "'COUNT=' + $events.Count"
    )
    ok, output = _powershell(script, timeout=35)
    match = re.search(r"COUNT=(\d+)", output or "", re.I)
    if match:
        count = int(match.group(1))
        score = 100 if count <= 4 else 88 if count <= 20 else 65 if count <= 60 else 45
        if count <= 4:
            item = _item(
                f"{count} critical/error System event(s) in the last 7 days",
                "The recent System log is relatively quiet. Event counts alone "
                "do not prove whether an event affected you.",
                "No action needed. Keep the timestamp and source if a problem "
                "returns so it can be correlated.",
            )
        else:
            item = _item(
                f"{count} critical/error System event(s) in the last 7 days",
                "The count is a signal to review recurring sources, not a list "
                "of confirmed failures.",
                "Open Event Viewer and inspect repeated events around the time "
                "you noticed a symptom; avoid clearing the log.", "warn")
        return _result("event_logs", "Event logs", score, [item])
    return _result("event_logs", "Event logs", 76, [_item(
        "Event-log query was inconclusive",
        output or "Windows returned no event count.",
        "Open Event Viewer manually if you are investigating a crash; the "
        "scan did not clear or modify logs.", "info")])


def _check_updates():
    if not _is_windows():
        return _result("updates", "Windows updates", 82, [_unavailable(
            "Windows update history was not inspected")])
    script = (
        "Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn "
        "-Descending | Select-Object -First 1 InstalledOn,HotFixID "
        "| ConvertTo-Json -Compress"
    )
    ok, output = _powershell(script, timeout=35)
    match = re.search(r'"InstalledOn"\s*:\s*"([^"]+)"', output or "", re.I)
    if match:
        raw = match.group(1)
        parsed = None
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y"):
            try:
                parsed = _datetime.datetime.strptime(raw[:19], fmt)
                break
            except ValueError:
                continue
        if parsed:
            age = max(0, (_datetime.datetime.now() - parsed).days)
            score = 100 if age <= 30 else 86 if age <= 60 else 62
            if age <= 30:
                item = _item(
                    f"Recent update history found ({age} day(s) ago)",
                    f"The latest hotfix record is {raw}. This confirms update "
                    "history, not whether a reboot is pending.",
                    "No action needed unless Windows Update shows a pending "
                    "restart.",
                )
            else:
                item = _item(
                    f"Latest recorded hotfix is {age} day(s) old",
                    f"Windows returned {raw} as the newest installed hotfix.",
                    "Open Settings → Windows Update and check for updates; "
                    "review the offered update before installing.", "warn")
            return _result("updates", "Windows updates", score, [item])
    return _result("updates", "Windows updates", 76, [_item(
        "Update history was inconclusive",
        output or "Get-HotFix returned no readable result.",
        "Open Settings → Windows Update to check manually. Health Center did "
        "not trigger or install an update.", "info")])


def _check_network():
    if not psutil:
        return _result("network", "Network", 80, [_unavailable(
            "Network adapters were not available", "psutil is not installed.")])
    try:
        stats = psutil.net_if_stats()
    except Exception as exc:
        return _result("network", "Network", 70, [_unavailable(
            "Network adapter status could not be read", str(exc))])
    active = [name for name, data in stats.items() if data.isup and name]
    if active:
        names = ", ".join(active[:3])
        return _result("network", "Network", 96, [_item(
            f"{len(active)} network adapter(s) are up",
            f"Active adapter(s): {names}. This confirms local adapter state "
            "only; it does not promise internet access or good throughput.",
            "No action needed. Use Network tools if a specific site or service "
            "is still unreachable.",
        )])
    return _result("network", "Network", 50, [_item(
        "No active network adapter was found",
        "The operating system reported no network interface in an up state.",
        "Check Wi-Fi mode, Ethernet cabling, and the adapter in Windows "
        "Settings before resetting network configuration.", "bad")])


def _check_security():
    if not _is_windows():
        return _result("security", "Security", 82, [_unavailable(
            "Windows security configuration was not inspected")])
    defender_ok, defender = _powershell(
        "Get-MpComputerStatus -ErrorAction SilentlyContinue | "
        "Select-Object AntivirusEnabled,RealTimeProtectionEnabled,"
        "AntivirusSignatureLastUpdated | ConvertTo-Json -Compress",
        timeout=30,
    )
    firewall_ok, firewall = _run_argv(
        ["netsh", "advfirewall", "show", "allprofiles", "state"], timeout=20)
    defender_lower = (defender or "").lower()
    firewall_lower = (firewall or "").lower()
    av_on = '"antivirusenabled":true' in defender_lower
    realtime_on = '"realtimeprotectionenabled":true' in defender_lower
    fw_on = "state                                 on" in firewall_lower or \
        re.search(r"state\s+on", firewall_lower) is not None
    checks = int(av_on) + int(realtime_on) + int(fw_on)
    score = {3: 100, 2: 82, 1: 60, 0: 42}.get(checks, 76)
    if checks == 3:
        item = _item(
            "Defender and firewall protection are enabled",
            "The read-only snapshot found antivirus, real-time protection, "
            "and at least one enabled Windows firewall profile.",
            "No action needed. Keep signatures and Windows updates current.",
        )
    else:
        missing = []
        if not av_on:
            missing.append("antivirus")
        if not realtime_on:
            missing.append("real-time protection")
        if not fw_on:
            missing.append("firewall")
        item = _item(
            "Security configuration needs review",
            "The scan could not confirm: " + ", ".join(missing) + ". "
            "Raw provider data may be unavailable on managed PCs.",
            "Open Windows Security and review the relevant protection page. "
            "Do not disable another security product to force a green result.",
            "warn" if checks else "bad",
        )
    return _result("security", "Security", score, [item])


def _bytes(value):
    value = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(value) < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} EB"


def _is_windows():
    return platform.system().lower() == "windows"


def sensor_snapshot():
    """Collect fast, read-only counters that can be charted over time."""
    sample = {
        "occurred_at": _datetime.datetime.now().timestamp(),
        "timestamp": _datetime.datetime.now().isoformat(timespec="seconds"),
        "cpu_percent": None,
        "ram_percent": None,
        "storage_percent": None,
        "network_adapters_up": None,
        "network_bytes_sent": None,
        "network_bytes_recv": None,
        "temperature_c": None,
    }
    if not psutil:
        return sample
    try:
        sample["cpu_percent"] = round(float(psutil.cpu_percent(interval=0.0)), 1)
    except Exception:
        pass
    try:
        sample["ram_percent"] = round(float(psutil.virtual_memory().percent), 1)
    except Exception:
        pass
    try:
        root = os.environ.get("SystemDrive", os.path.abspath(os.sep))
        sample["storage_percent"] = round(float(psutil.disk_usage(root).percent), 1)
    except Exception:
        pass
    try:
        sample["network_adapters_up"] = sum(
            1 for data in psutil.net_if_stats().values() if data.isup
        )
    except Exception:
        pass
    try:
        network = psutil.net_io_counters()
        sample["network_bytes_sent"] = int(network.bytes_sent)
        sample["network_bytes_recv"] = int(network.bytes_recv)
    except Exception:
        pass
    try:
        readings = [
            float(entry.current)
            for entries in psutil.sensors_temperatures().values()
            for entry in entries
            if entry.current is not None
        ]
        if readings:
            sample["temperature_c"] = round(max(readings), 1)
    except Exception:
        pass
    return sample


def scan_pc(progress=None):
    """Run every check and return the serializable Health Center report."""
    checks = [
        ("Hardware", [_check_cpu, _check_ram, _check_gpu]),
        ("Storage", [_check_storage, _check_smart]),
        ("Windows", [_check_windows_services, _check_startup, _check_drivers,
                     _check_system_files, _check_event_logs, _check_updates]),
        ("Network", [_check_network]),
        ("Security", [_check_security]),
    ]
    categories = []
    for label, functions in checks:
        if progress:
            progress(f"Checking {label.lower()}…")
        subresults = [fn() for fn in functions]
        score = round(sum(result["score"] for result in subresults) /
                      max(1, len(subresults)))
        categories.append({
            "key": label.lower(),
            "label": label,
            "score": score,
            "checks": subresults,
            "items": [item for result in subresults for item in result["items"]],
        })
    overall = round(sum(category["score"] for category in categories) /
                    max(1, len(categories)))
    return {
        "score": overall,
        "status": "Healthy" if overall >= 80 else
                  "Needs attention" if overall >= 55 else "At risk",
        "limited": not _is_windows(),
        "timestamp": _datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "categories": categories,
        "sensors": sensor_snapshot(),
    }


class HealthCenterPage(tk.Frame):
    """Single-action Health Center view embedded in a TechDrive tab."""

    def __init__(self, parent, app):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        super().__init__(parent, bg=self.theme["BG"])
        self._scanning = False
        self._report = None
        _canvas, self.content = make_scrollable(self, self.theme["BG"])
        self._build_shell()

    def _build_shell(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  HEALTH CENTER",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        tk.Label(header, text="Health Center", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(anchor="w",
                                                                pady=(4, 2))
        tk.Label(
            header,
            text="One safe, read-only scan across hardware, Windows, storage, "
                 "network, and security.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=760, justify="left",
        ).pack(anchor="w")

        cta = GlassCard(root, self.theme, aero=self.aero, gradient=True,
                        accent=fl.GOOD)
        cta.pack(fill="x", padx=24, pady=(8, 14))
        cta_body = cta.body
        tk.Label(cta_body, text="READY WHEN YOU ARE", bg=cta.fill,
                 fg=self.theme["MUTED"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 2))
        tk.Label(cta_body, text="See what is healthy — and what to do next.",
                 bg=cta.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE()).pack(anchor="w", padx=18)
        row = tk.Frame(cta_body, bg=cta.fill)
        row.pack(fill="x", padx=18, pady=(12, 16))
        self.scan_button = FluentButton(
            row, "SCAN MY PC", command=self.start_scan, theme=self.theme,
            aero=self.aero, kind="accent", icon="△", width=190, height=46,
            backdrop=cta.fill,
        )
        self.scan_button.pack(side="left")
        self.status_var = tk.StringVar(
            value="Click SCAN MY PC to run real read-only Windows diagnostics")
        tk.Label(row, textvariable=self.status_var, bg=cta.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=480, justify="left").pack(side="left", padx=16)

        self.summary = tk.Frame(root, bg=self.theme["BG"])
        self.summary.pack(fill="x", padx=24, pady=(0, 14))
        self._render_preflight()

    def _render_preflight(self):
        """Show real live telemetry before the deeper scan starts.

        This deliberately avoids fake scores or empty placeholder cards.  A
        user opening Health Center immediately sees values read from the
        current machine, while the button remains the explicit action that
        starts the longer Windows diagnostics.
        """
        for child in self.summary.winfo_children():
            child.destroy()
        card = GlassCard(self.summary, self.theme, aero=self.aero,
                         accent=fl.GOOD)
        card.pack(fill="x")
        body = card.body
        tk.Label(body, text="Live preflight telemetry", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text="Current values below are read from this machine. "
                 "SCAN MY PC adds SMART, services, drivers, event logs, "
                 "updates, system-file, and security checks.",
                 bg=card.fill, fg=self.theme["MUTED"],
                 font=fl.F_SMALL(), wraplength=760, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 12))
        telemetry = tk.Frame(body, bg=card.fill)
        telemetry.pack(fill="x", padx=18, pady=(0, 16))
        values = self._live_telemetry()
        for column, (label, value, color) in enumerate(values):
            cell = tk.Frame(telemetry, bg=card.fill)
            cell.grid(row=0, column=column, sticky="ew",
                      padx=(0 if column == 0 else 8, 8 if column < 3 else 0))
            telemetry.grid_columnconfigure(column, weight=1)
            tk.Label(cell, text=label.upper(), bg=card.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY()).pack(anchor="w")
            tk.Label(cell, text=value, bg=card.fill, fg=color,
                     font=fl.F_CARD_TITLE()).pack(anchor="w", pady=(3, 0))

    def _live_telemetry(self):
        """Collect only fast local counters for the initial view."""
        if not psutil:
            return [
                ("CPU", "psutil missing", fl.WARN),
                ("RAM", "psutil missing", fl.WARN),
                ("Storage", "psutil missing", fl.WARN),
                ("Network", "psutil missing", fl.WARN),
            ]
        try:
            cpu = f"{psutil.cpu_percent(interval=0.0):.0f}%"
        except Exception:
            cpu = "unavailable"
        try:
            ram = f"{psutil.virtual_memory().percent:.0f}% used"
        except Exception:
            ram = "unavailable"
        try:
            root = os.environ.get("SystemDrive", os.path.abspath(os.sep))
            storage = f"{psutil.disk_usage(root).percent:.0f}% used"
        except Exception:
            storage = "unavailable"
        try:
            active = sum(1 for data in psutil.net_if_stats().values() if data.isup)
            network = f"{active} adapter{'s' if active != 1 else ''} up"
        except Exception:
            network = "unavailable"
        return [
            ("CPU", cpu, self.theme["ACCENT"]),
            ("RAM", ram, self.theme["ACCENT2"]),
            ("Storage", storage, fl.GOOD),
            ("Network", network, fl.GOOD),
        ]

    def start_scan(self):
        if self._scanning:
            return
        self._scanning = True
        self.scan_button.configure(state="disabled")
        self.status_var.set("Starting read-only checks…")
        self._render_preflight()
        self.app._run_bg(
            lambda: scan_pc(progress=self._set_progress),
            self._finish_scan,
        )

    def _set_progress(self, text):
        try:
            self.app._post_ui(lambda text=text: self.status_var.set(text))
        except tk.TclError:
            pass

    def _finish_scan(self, report):
        self._scanning = False
        self.scan_button.configure(state="normal")
        if hasattr(report, "message"):
            self.status_var.set("The scan could not finish.")
            self._render_error(str(report))
            return
        self._report = report
        try:
            db.add_health_scan(report)
        except Exception:
            # History is useful, but a local database problem must never hide
            # the completed scan from the user.
            pass
        try:
            achievements.record_scan(self.app)
        except Exception:
            pass
        suffix = " • limited Windows coverage on this OS" if report["limited"] else ""
        self.status_var.set(f"Completed at {report['timestamp']}{suffix}")
        self._render_report(report)
        if hasattr(self.app, "notify"):
            score = report["score"]
            level = "success" if score >= 80 else "warning" if score >= 55 else "error"
            self.app.notify(
                "System scan completed",
                f"{report['status']} — {score}/100{suffix}",
                kind=level, source="Health Center",
            )

    def _render_error(self, message):
        for child in self.summary.winfo_children():
            child.destroy()
        card = GlassCard(self.summary, self.theme, aero=self.aero,
                         accent=fl.BAD)
        card.pack(fill="x")
        tk.Label(card.body, text="Health scan stopped safely",
                 bg=card.fill, fg=fl.BAD, font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(18, 4))
        tk.Label(card.body, text=message, bg=card.fill, fg=self.theme["MUTED"],
                 font=fl.F_SMALL(), wraplength=760, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 18))

    def _render_report(self, report):
        for child in self.summary.winfo_children():
            child.destroy()
        overview = GlassCard(self.summary, self.theme, aero=self.aero,
                             accent=self._score_color(report["score"]))
        overview.pack(fill="x", pady=(0, 14))
        body = overview.body
        left = tk.Frame(body, bg=overview.fill)
        left.pack(side="left", padx=(18, 10), pady=16)
        ring = HealthRing(left, self.theme, size=134, aero=self.aero,
                          bg=overview.fill)
        ring.pack()
        ring.set_score(report["score"], report["status"])
        right = tk.Frame(body, bg=overview.fill)
        right.pack(side="left", fill="both", expand=True, padx=(8, 18), pady=18)
        title = f"{report['status']} — {report['score']}/100"
        tk.Label(right, text=title, bg=overview.fill, fg=self._score_color(
            report["score"]), font=fl.F_TITLE()).pack(anchor="w")
        description = (
            "Your PC is in a good place based on this snapshot."
            if report["score"] >= 80 else
            "A few areas deserve a closer look; start with the amber or red findings."
            if report["score"] >= 55 else
            "Several checks need attention. Address the red findings first."
        )
        if report["limited"]:
            description += " This development OS cannot provide Windows-only readings."
        tk.Label(right, text=description, bg=overview.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=660, justify="left").pack(anchor="w", pady=(5, 10))
        tk.Label(right, text=f"Scan timestamp: {report['timestamp']}",
                 bg=overview.fill, fg=self.theme["MUTED"],
                 font=fl.F_TINY()).pack(anchor="w")

        grid = tk.Frame(self.summary, bg=self.theme["BG"])
        grid.pack(fill="x")
        for col in range(2):
            grid.grid_columnconfigure(col, weight=1, uniform="health")
        for index, category in enumerate(report["categories"]):
            self._category_card(grid, category).grid(
                row=index // 2, column=index % 2, sticky="nsew",
                padx=(0, 7) if index % 2 == 0 else (7, 0),
                pady=(0, 14),
            )

    def _category_card(self, parent, category):
        color = self._score_color(category["score"])
        card = GlassCard(parent, self.theme, aero=self.aero, accent=color)
        body = card.body
        top = tk.Frame(body, bg=card.fill)
        top.pack(fill="x", padx=16, pady=(14, 3))
        tk.Label(top, text=category["label"], bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(side="left")
        tk.Label(top, text=f"{category['score']}/100", bg=card.fill,
                 fg=color, font=fl.F_SUBTITLE()).pack(side="right")
        meter = MeterBar(body, self.theme, color=color, height=8, aero=self.aero,
                         bg=card.fill)
        meter.pack(fill="x", padx=16, pady=(0, 12))
        meter.set_value(category["score"] / 100.0)
        for item in category["items"]:
            self._finding(body, card.fill, item)
        return card

    def _finding(self, parent, fill, item):
        color = self._severity_color(item["severity"])
        wrap = tk.Frame(parent, bg=fill)
        wrap.pack(fill="x", padx=16, pady=(0, 10))
        title = tk.Frame(wrap, bg=fill)
        title.pack(fill="x")
        tk.Label(title, text="●", bg=fill, fg=color,
                 font=fl.F_SMALL()).pack(side="left")
        tk.Label(title, text=item["title"], bg=fill, fg=self.theme["FG"],
                 font=fl.font(10, "bold")).pack(side="left", padx=(6, 0))
        tk.Label(wrap, text=f"Why: {item['explanation']}", bg=fill,
                 fg=self.theme["MUTED"], font=fl.F_TINY(),
                 wraplength=430, justify="left").pack(anchor="w", padx=(16, 0))
        tk.Label(wrap, text=f"Safe next step: {item['action']}", bg=fill,
                 fg=self.theme["TEXT_FG"], font=fl.F_TINY(),
                 wraplength=430, justify="left").pack(anchor="w", padx=(16, 0),
                                                       pady=(2, 0))

    @staticmethod
    def _score_color(score):
        return fl.GOOD if score >= 80 else fl.WARN if score >= 55 else fl.BAD

    @staticmethod
    def _severity_color(severity):
        return {
            "good": fl.GOOD,
            "warn": fl.WARN,
            "bad": fl.BAD,
            "info": "#7ea7d9",
        }.get(severity, "#7ea7d9")