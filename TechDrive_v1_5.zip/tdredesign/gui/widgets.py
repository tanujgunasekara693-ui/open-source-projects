#!/usr/bin/env python3
"""
gui/widgets.py — reusable Fluent/Aero widgets for TechDrive
============================================================
Pure-tkinter building blocks (no extra dependencies, no Electron, no web
view) used by the redesigned shell:

  GlassCard      rounded, soft-shadowed, optionally translucent panel
  FluentButton   rounded button with a smooth hover-lighting fade
  NavItem        sidebar row with hover + selected pill indicator
  Sparkline      tiny filled trend line for the metric cards
  LineChart      multi-series live performance graph
  HealthRing     donut gauge for the System Health card
  MeterBar       thin rounded progress/usage bar
  SearchBox      rounded search entry with placeholder text

Design notes
------------
* tkinter has no per-widget alpha, so "glass" is faked by blending colors
  (see gui.fluent.mix). Aero mode pulls surfaces toward the Aero tint.
* Shadows are a few concentric rounded rects blended toward the shadow
  color — cheap to draw, no images, no blur passes.
* Animations are short color fades on `after()` timers (5 frames), so the
  UI feels alive without burning CPU on a system-utility app.
"""

import tkinter as tk
import time
from pathlib import Path

from gui import fluent as fl
from gui import liquid_glass as lg
from gui.motion import ease_in_out, ease_apple, ease_out_quint, motion_enabled, tween, spring_tween, press_scale


# ---------------------------------------------------------------------------
# Canvas primitives
# ---------------------------------------------------------------------------

def attach_tooltip(widget, text, delay_ms=450):
    """Lightweight hover tooltip for icon-only / non-obvious controls.

    Shows a small dark label near the cursor after a short hover delay,
    matching the existing borderless-popup look used elsewhere in the
    app. Safe to call on any widget; failures (e.g. widget destroyed
    mid-hover) are swallowed since a missing tooltip is never worth a
    crash.
    """
    state = {"after_id": None, "win": None}

    def _show(event):
        _hide()
        def _popup():
            try:
                win = tk.Toplevel(widget)
                win.overrideredirect(True)
                try:
                    win.attributes("-topmost", True)
                except Exception:
                    pass
                lbl = tk.Label(
                    win, text=text, bg="#1c1f26", fg="#e8ebf2",
                    font=("Segoe UI", 10), padx=8, pady=5,
                    wraplength=220, justify="left",
                )
                lbl.pack()
                x = widget.winfo_rootx() + 6
                y = widget.winfo_rooty() + widget.winfo_height() + 6
                win.geometry(f"+{x}+{y}")
                state["win"] = win
            except Exception:
                pass
        state["after_id"] = widget.after(delay_ms, _popup)

    def _hide(_event=None):
        after_id = state.get("after_id")
        if after_id:
            try:
                widget.after_cancel(after_id)
            except Exception:
                pass
            state["after_id"] = None
        win = state.get("win")
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass
            state["win"] = None

    widget.bind("<Enter>", _show, add="+")
    widget.bind("<Leave>", _hide, add="+")
    widget.bind("<Button-1>", _hide, add="+")
    return state


def round_rect(canvas, x1, y1, x2, y2, r=10, **kwargs):
    """Rounded rectangle as a smoothed polygon (works on every Tk build)."""
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


def paint_panel(canvas, w, h, fill, outline, radius=fl.RADIUS_CARD,
                shadow=None, backdrop=None, gradient=None):
    """Draw a card: soft shadow, body, 1px stroke, optional top gradient.

    `gradient` is (top_color, bottom_color); it is drawn as a handful of
    horizontal bands clipped inside the rounded body — enough to read as a
    Fluent gradient without the cost of a per-pixel fill."""
    canvas.delete("panel")
    if w < 4 or h < 4:
        return
    if shadow and backdrop:
        # Soft professional ambient shadow (wider, lower opacity)
        layers = max(3, fl.SHADOW_LAYERS)
        for i in range(layers, 0, -1):
            t = 0.045 * (layers - i + 1) / layers
            ox = int(i * 0.6)
            oy = int(i * 0.9)
            round_rect(canvas, ox, oy, w - ox + 1, h - 1,
                       r=radius + i // 2, fill=fl.mix(backdrop, shadow, t),
                       outline="", tags="panel")
    body_top, body_bottom = 0, h - fl.SHADOW_LAYERS
    round_rect(canvas, 0, body_top, w - 1, body_bottom, r=radius,
               fill=fill, outline=outline, width=1, tags="panel")
    if gradient:
        top, bottom = gradient
        bands = 10
        band_h = max(1, (body_bottom - body_top) / bands)
        for i in range(bands):
            y1 = body_top + i * band_h
            color = fl.mix(top, bottom, i / max(1, bands - 1))
            inset = 1 if i else radius * 0.35
            canvas.create_rectangle(inset, y1, w - 1 - inset, y1 + band_h,
                                    fill=color, outline="", tags="panel")
        round_rect(canvas, 0, body_top, w - 1, body_bottom, r=radius,
                   fill="", outline=outline, width=1, tags="panel")
    canvas.tag_lower("panel")


# ---------------------------------------------------------------------------
# Cards
# ---------------------------------------------------------------------------

class GlassCard(tk.Frame):
    """Rounded, shadowed panel. Pack/grid children into `card.body`."""

    def __init__(self, parent, theme, aero=False, backdrop=None,
                 radius=fl.RADIUS_CARD, padding=fl.PAD_CARD,
                 accent=None, gradient=False, **kw):
        self.theme = theme
        self.aero = aero
        self.radius = radius
        self.padding = padding
        self.accent = accent
        self.gradient = gradient
        self.backdrop = backdrop or theme["BG"]
        self._hovered = False
        self._hover_t = 0.0
        self._hover_cancel = None
        super().__init__(parent, bg=self.backdrop, **kw)

        self.fill = fl.glass(theme, "CARD_BG", aero)
        self.canvas = tk.Canvas(self, bg=self.backdrop, highlightthickness=0,
                                bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self, bg=self.fill)
        self.body.place(x=padding, y=padding,
                        relwidth=1.0, relheight=1.0,
                        width=-2 * padding, height=-2 * padding - fl.SHADOW_LAYERS)
        self.canvas.bind("<Configure>", self._redraw)
        # A faint accent-tinted outline on hover gives cards a subtle
        # "lift" without the cost of re-animating the shadow every frame.
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)

    # ------------------------------------------------------------------
    # Optional content-driven height
    # ------------------------------------------------------------------
    def enable_autofit(self, on_change=None):
        """Make this card exactly as tall as what is inside it (opt-in).

        `body` is place()d on top of the canvas, so the card's requested
        height is really just the Tk canvas default (~265px) whatever the
        body holds.  Short content then sits in a tall, empty panel, and
        long content (extra rows, wrapped text) is chopped off at the
        bottom.  With autofit the canvas height follows the body's real
        requested height, re-measured after layout and whenever the card
        is resized (wrapped text changes height with width).

        `on_change` (optional) is called after the height actually changes.
        """
        self._autofit_h = None
        self._autofit_cb = on_change
        self._autofit_idle = None
        self._autofit_late = None
        self.bind("<Configure>", self._schedule_autofit, add="+")
        self._schedule_autofit()

    def _schedule_autofit(self, _event=None):
        if not hasattr(self, "_autofit_h"):
            return                      # autofit was never enabled
        # Only a width change can re-wrap text. Our own autofit resizes the
        # card's height, which fires <Configure> again; reacting to that
        # height-only event made every pass schedule the next one forever.
        if _event is not None:
            width = getattr(_event, "width", None)
            if width is not None and width == getattr(self, "_autofit_last_w", None):
                return
            self._autofit_last_w = width
        try:
            if self._autofit_idle is None:
                self._autofit_idle = self.after_idle(self._run_autofit)
            # Second pass: wrapped labels only reflow once they know their
            # new width, so measure again shortly after the first change.
            if self._autofit_late is None:
                self._autofit_late = self.after(160, self._run_autofit_late)
        except tk.TclError:
            pass

    def _run_autofit_late(self):
        self._autofit_late = None
        self._run_autofit()

    def _run_autofit(self):
        self._autofit_idle = None
        # Re-entrancy guard shared by every autofit card. _run_autofit_once()
        # calls update_idletasks(), which runs other cards' pending idle
        # callbacks; those can start another autofit pass, and the nesting
        # recursed until Python's recursion limit was hit. A nested request
        # is simply retried once the outer pass has finished.
        if _AUTOFIT_DEPTH[0] > 0:
            try:
                self.after(120, self._run_autofit)
            except tk.TclError:
                pass
            return
        _AUTOFIT_DEPTH[0] += 1
        try:
            self._run_autofit_once()
        finally:
            _AUTOFIT_DEPTH[0] -= 1

    def _run_autofit_once(self):
        try:
            if not self.winfo_exists():
                return
            self.body.update_idletasks()    # let pack/grid compute requests
            need = (int(self.body.winfo_reqheight())
                    + 2 * self.padding + fl.SHADOW_LAYERS)
        except tk.TclError:
            return
        if need < 2 * self.padding + fl.SHADOW_LAYERS + 8:
            return                          # body not populated yet
        if need == self._autofit_h:
            return
        self._autofit_h = need
        try:
            self.canvas.configure(height=need)
        except tk.TclError:
            return
        if self._autofit_cb is not None:
            try:
                self._autofit_cb()
            except Exception:
                pass

    def _on_enter(self, _event=None):
        self._hovered = True
        self._animate_hover(1.0)

    def _on_leave(self, _event=None):
        self._hovered = False
        self._animate_hover(0.0)

    def _animate_hover(self, target):
        if self._hover_cancel:
            self._hover_cancel()
        start = self._hover_t
        self._hover_cancel = tween(
            self, fl.MOTION_NORMAL,
            lambda progress: self._set_hover_progress(start + (target - start) * progress),
            easing=ease_out_quint,
        )

    def _set_hover_progress(self, value):
        self._hover_t = max(0.0, min(1.0, value))
        self._redraw()

    def play_entrance(self, delay=0, duration=320, steps=10):
        """Soft spring edge reveal — never hides content."""
        if not self.winfo_exists():
            return
        for child in list(self.winfo_children()):
            if child is not self.canvas and child is not self.body:
                try:
                    child.destroy()
                except tk.TclError:
                    pass
        if not motion_enabled():
            return

        def start():
            try:
                if not self.winfo_exists():
                    return
            except tk.TclError:
                return
            self._hover_t = 0.0

            def update(t):
                # Rise then settle: peak mid-way, return to rest
                peak = 0.55
                if t < 0.55:
                    self._hover_t = peak * (t / 0.55)
                else:
                    self._hover_t = peak * (1.0 - (t - 0.55) / 0.45)
                try:
                    self._redraw()
                except Exception:
                    pass

            def done():
                self._hover_t = 0.0
                try:
                    self._redraw()
                except Exception:
                    pass

            tween(self, duration, update, complete=done, easing=ease_out_quint)

        if delay:
            try:
                self.after(int(delay), start)
            except Exception:
                start()
        else:
            start()

    def _redraw(self, event=None):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        grad = None
        if self.gradient:
            grad = (fl.mix(self.fill, self.theme["ACCENT"], 0.10 if self.aero else 0.06),
                    self.fill)
        outline = self.theme["STROKE"]
        if self._hover_t > 0:
            outline = fl.mix(self.theme["STROKE"], self.theme["ACCENT"],
                             0.22 * self._hover_t)
        if lg.enabled():
            lg.paint_liquid_panel(
                self.canvas, w, h, self.fill, self.theme["STROKE"],
                radius=self.radius, shadow=self.theme["SHADOW"],
                backdrop=self.backdrop,
                tint=self.accent or self.theme["ACCENT"],
                hovered=self._hover_t > 0.45)
        else:
            paint_panel(self.canvas, w, h, self.fill, outline,
                        radius=self.radius, shadow=self.theme["SHADOW"],
                        backdrop=self.backdrop, gradient=grad)
        # No per-card accent bar: colour is reserved for data (values,
        # sparklines, status). Card chrome stays neutral.

    def set_aero(self, aero):
        self.aero = aero
        self.fill = fl.glass(self.theme, "CARD_BG", aero)
        self.body.configure(bg=self.fill)
        self._redraw()


def card_label(parent, text, theme, fnt=None, fg_key="FG", **kw):
    """Label pre-wired to a card body's background (saves repeating bg=)."""
    return tk.Label(parent, text=text, bg=parent["bg"], fg=theme[fg_key],
                    font=fnt or fl.F_BODY(), **kw)


# ---------------------------------------------------------------------------
# Buttons
# ---------------------------------------------------------------------------

# Nesting depth of autofit passes (see _run_autofit).
_AUTOFIT_DEPTH = [0]


class FluentButton(tk.Canvas):
    """Rounded button with a short hover-lighting fade and press feedback."""

    def __init__(self, parent, text, command=None, theme=None, aero=False,
                 kind="standard", icon="", width=None, height=32,
                 backdrop=None, accent=None, font_=None):
        self.theme = theme
        self.aero = aero
        self.kind = kind          # standard | accent | subtle
        self.command = command
        self.text = text
        self.icon = icon
        self.accent = accent or theme["ACCENT"]
        self.backdrop = backdrop or parent["bg"]
        self._font = font_ or fl.F_BODY()
        self._t = 0.0             # hover progress 0..1
        self._anim = None
        self._pressed = False
        self._focused = False

        label = f"{icon}  {text}".strip() if icon else text
        w = width or (len(label) * 8 + 34)
        super().__init__(parent, width=w, height=height, bg=self.backdrop,
                         highlightthickness=0, bd=0, cursor="hand2", takefocus=1)
        self.bind("<FocusIn>", lambda e: self._focus_draw(True), add="+")
        self.bind("<FocusOut>", lambda e: self._focus_draw(False), add="+")
        self.bind("<Return>", self._key_activate, add="+")
        self.bind("<space>", self._key_activate, add="+")
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._animate(1.0))
        self.bind("<Leave>", lambda e: self._animate(0.0))
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self._draw()

    def _key_activate(self, _event=None):
        if self.command:
            self.command()
        return "break"

    def _focus_draw(self, focused):
        self._focused = bool(focused)
        self._draw()

    # -- colors --------------------------------------------------------
    def _base_fill(self):
        th = self.theme
        if self.kind == "accent":
            return self.accent
        if self.kind == "subtle":
            return fl.glass(th, "LAYER_1", self.aero, 0.10)
        return fl.glass(th, "LAYER_2", self.aero, 0.12)

    def _fg(self):
        if self.kind == "accent":
            return self.theme["ON_ACCENT"]
        return self.theme["FG"]

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 2:
            return
        base = self._base_fill()
        # Hover = subtle lighting; Aero adds a touch of tint on top.
        hover_target = fl.lighten(base, 0.16 if self.kind != "accent" else 0.10)
        if self.aero:
            hover_target = fl.mix(hover_target, self.theme["AERO_TINT"], 0.12)
        fill = fl.mix(base, hover_target, self._t)
        if self._pressed:
            fill = fl.darken(fill, 0.08)
        outline = self.theme["STROKE"] if self.kind != "accent" else fill
        if getattr(self, "_focused", False):
            outline = self.theme["ACCENT_GLOW"]

        if self.kind == "accent" and self.accent == self.theme["ACCENT"]:
            # Blue -> violet gradient pill (matches the "Quick Scan" CTA);
            # only for the default accent color so an explicit `accent=`
            # override (e.g. a status color) still renders as a flat fill.
            g_start, g_end = fl.ACCENT_GRAD
            if self._pressed:
                g_start, g_end = fl.darken(g_start, 0.08), fl.darken(g_end, 0.08)
            elif self._t:
                g_start = fl.mix(g_start, fl.lighten(g_start, 0.12), self._t)
                g_end = fl.mix(g_end, fl.lighten(g_end, 0.12), self._t)
            round_rect(self, 0, 0, w - 1, h - 1, r=fl.RADIUS_CONTROL,
                       fill=g_start, outline=g_start, width=1)
            bands = 12
            for i in range(bands):
                x1 = (w - 1) * i / bands
                x2 = (w - 1) * (i + 1) / bands
                color = fl.mix(g_start, g_end, i / max(1, bands - 1))
                self.create_rectangle(x1, 1, x2, h - 2, fill=color,
                                      outline="")
            round_rect(self, 0, 0, w - 1, h - 1, r=fl.RADIUS_CONTROL,
                       fill="", outline=g_end, width=1)
        elif lg.enabled():
            lg.paint_liquid_shape(
                self, 0, 0, w - 1, h - 1, self._base_fill(),
                self.theme["STROKE"], fl.RADIUS_CONTROL,
                self.theme["ACCENT"], hovered=self._t > 0.5,
                pressed=self._pressed, tag="lg", glint=False)
        else:
            round_rect(self, 0, 0, w - 1, h - 1, r=fl.RADIUS_CONTROL,
                       fill=fill, outline=outline, width=1)
        photo = None
        if self.icon and len(self.icon) > 1 and self.icon.isascii():
            try:
                from gui.hand_icons import icon_photo
                photo = icon_photo(self, self.icon, 14, self._fg())
            except Exception:
                photo = None
        if photo is not None:
            # Hand-drawn icon + label, centred together.
            tmp = self.create_text(0, 0, text=self.text, font=self._font,
                                   anchor="nw")
            bbox = self.bbox(tmp)
            self.delete(tmp)
            tw = (bbox[2] - bbox[0]) if bbox else len(self.text) * 7
            total = 14 + 6 + tw
            x0 = (w - total) / 2
            self.create_image(x0 + 7, h / 2, image=photo)
            self._icon_ref = photo
            self.create_text(x0 + 20, h / 2, text=self.text, fill=self._fg(),
                             font=self._font, anchor="w")
        else:
            label = f"{self.icon}  {self.text}".strip() if self.icon else self.text
            self.create_text(w / 2, h / 2, text=label, fill=self._fg(),
                             font=self._font)

    # -- motion --------------------------------------------------------
    def _animate(self, target):
        if self._anim:
            self._anim()
            self._anim = None
        start = self._t
        def update(progress):
            self._t = start + (target - start) * progress
            self._draw()
        # Longer, softer Apple-style hover (160ms + quintic)
        self._anim = tween(self, fl.MOTION_FAST, update, easing=ease_out_quint)

    def _on_press(self, _e):
        self._pressed = True
        # Subtle press scale for that buttery tactile feel
        if not hasattr(self, '_press_scale'):
            self._press_scale = 1.0
        press_scale(self, True, duration_ms=80)
        self._draw()

    def _on_release(self, _e):
        self._pressed = False
        press_scale(self, False, duration_ms=110)
        self._draw()
        if self.command and self.winfo_containing(_e.x_root, _e.y_root) is self:
            self.command()

    def set_aero(self, aero):
        self.aero = aero
        self._draw()

    def set_text(self, text):
        """Update the button caption without rebuilding the widget."""
        self.text = str(text)
        self._draw()


class NavItem(tk.Frame):
    """Sidebar navigation row: icon + label, hover highlight, selected pill.
    Optional trailing chevron (matches the concept mockup's category rows)
    and optional indent (used for "Dashboard" nested under the "Home"
    parent row)."""

    def __init__(self, parent, text, icon, theme, command=None, aero=False,
                 chevron=False, indent=False):
        self.theme = theme
        self.aero = aero
        self.command = command
        self.selected = False
        self._hover_t = 0.0
        self._hover_cancel = None
        self._base = parent["bg"]
        super().__init__(parent, bg=self._base, height=36, takefocus=1)
        self.pack_propagate(False)
        self.configure(highlightthickness=0)

        self.pill = tk.Frame(self, bg=self._base, width=3)
        self.pill.pack(side="left", fill="y", padx=(6, 0), pady=8)
        if indent:
            tk.Frame(self, bg=self._base, width=18).pack(side="left")
        # Shell/navigation icons are real raster assets, not Unicode glyphs.
        # Tool icons are still handled by gui.icons and are never touched here.
        self._icon_key = str(icon)
        self._icon_normal = self._load_shell_icon(self._icon_key, active=False)
        self._icon_active = self._load_shell_icon(self._icon_key, active=True)
        if self._icon_normal is not None:
            self.icon_lbl = tk.Label(self, image=self._icon_normal, bg=self._base,
                                     width=20, height=20)
            self.icon_lbl._shell_icon_images = (self._icon_normal, self._icon_active)
        else:
            # Backward-compatible fallback for any legacy NavItem callers.
            self.icon_lbl = tk.Label(self, text=icon, bg=self._base,
                                     fg=theme["MUTED"], font=fl.font(12), width=2)
        self.icon_lbl.pack(side="left", padx=(0, 2))
        self.text_lbl = tk.Label(self, text=text, bg=self._base,
                                 fg=theme["FG"], font=fl.F_BODY(), anchor="w")
        self.text_lbl.pack(side="left", fill="x", expand=True)
        self.chevron_lbl = None
        if chevron:
            self.chevron_lbl = tk.Label(self, text="›", bg=self._base,
                                        fg=theme["MUTED"], font=fl.font(11))
            self.chevron_lbl.pack(side="right", padx=(0, 10))

        watch = [self, self.icon_lbl, self.text_lbl, self.pill]
        if self.chevron_lbl is not None:
            watch.append(self.chevron_lbl)
        self.bind("<FocusIn>", self._on_focus_in, add="+")
        self.bind("<FocusOut>", self._on_focus_out, add="+")
        self.bind("<Return>", self._on_key_activate, add="+")
        self.bind("<space>", self._on_key_activate, add="+")
        for w in watch:
            w.bind("<Enter>", self._on_enter)
            w.bind("<Leave>", self._on_leave)
            w.bind("<Button-1>", self._on_click)
            w.configure(cursor="hand2")

    @staticmethod
    def _load_shell_icon(name, active=False):
        try:
            path = Path(__file__).resolve().parent / "assets" / "ui_icons" / f"{name}{'_active' if active else ''}_20.png"
            if path.exists():
                return tk.PhotoImage(file=str(path))
        except Exception:
            pass
        return None

    def _set_shell_icon(self, active):
        if hasattr(self.icon_lbl, "_shell_icon_images"):
            normal, selected = self.icon_lbl._shell_icon_images
            image = selected if active and selected is not None else normal
            if image is not None:
                self.icon_lbl.configure(image=image, text="")

    def _paint(self, bg, pill, fg, icon_fg):
        widgets = [self, self.icon_lbl, self.text_lbl]
        if self.chevron_lbl is not None:
            widgets.append(self.chevron_lbl)
        for w in widgets:
            w.configure(bg=bg)
        self.pill.configure(bg=pill)
        self.text_lbl.configure(fg=fg)
        self.icon_lbl.configure(fg=icon_fg)
        if self.chevron_lbl is not None:
            self.chevron_lbl.configure(fg=icon_fg)


    def _hover_bg(self):
        return fl.glass(self.theme, "LAYER_2", self.aero, 0.14)

    def _on_enter(self, _e=None):
        if not self.selected:
            self._animate_hover(1.0)

    def _on_leave(self, _e=None):
        if not self.selected:
            self._animate_hover(0.0)

    def _animate_hover(self, target):
        if self._hover_cancel:
            self._hover_cancel()
        start = self._hover_t
        def update(progress):
            self._hover_t = start + (target - start) * progress
            hover = self._hover_bg()
            bg = fl.mix(self._base, hover, self._hover_t)
            icon = fl.mix(self.theme["MUTED"], self.theme["FG"], self._hover_t)
            self._paint(bg, bg, self.theme["FG"], icon)
        self._hover_cancel = tween(self, fl.MOTION_FAST, update, easing=ease_out_quint)

    def _on_click(self, _e=None):
        if self.command:
            self.command()

    def _on_focus_in(self, _e=None):
        if not self.selected:
            self.configure(highlightthickness=2, highlightbackground=self.theme["ACCENT_GLOW"])
            self._paint(self._hover_bg(), self._hover_bg(), self.theme["FG"], self.theme["FG"])

    def _on_focus_out(self, _e=None):
        self.configure(highlightthickness=0)
        if not self.selected:
            self._on_leave()

    def _on_key_activate(self, _e=None):
        self._on_click()
        return "break"

    def set_selected(self, selected):
        self.selected = selected
        if self._hover_cancel:
            self._hover_cancel()
            self._hover_cancel = None
        self._hover_t = 0.0
        if selected:
            # The reference uses a luminous blue selection pill rather than
            # the neutral grey used by the legacy shell. The narrow accent
            # rail stays in place as a clear keyboard/mouse target cue.
            bg = fl.mix(self.theme["LAYER_3"], self.theme["ACCENT"], 0.22)
            self._paint(bg, self.theme["ACCENT"], self.theme["FG"],
                        self.theme["ACCENT"])
            self._set_shell_icon(True)
        else:
            self._on_leave()
            self._set_shell_icon(False)


# ---------------------------------------------------------------------------
# Data visualisation
# ---------------------------------------------------------------------------

class Sparkline(tk.Canvas):
    """Small filled trend line. Feed it values with push()/set_values()."""

    def __init__(self, parent, color, theme, height=40, capacity=60, bg=None):
        self.color = color
        self.theme = theme
        self.capacity = capacity
        self.values = []
        self._bg = bg or parent["bg"]
        self._anim_job = None
        self._anim_from = None
        self._anim_to = None
        super().__init__(parent, height=height, bg=self._bg,
                         highlightthickness=0, bd=0)
        self.bind("<Configure>", lambda e: self._draw())

    def push(self, value, animate=True):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return
        if not self.values:
            self.values.append(value)
            self._draw()
            return

        # Keep the history discrete, but ease the newest point toward the
        # incoming sample so the line does not visibly jump every 1.5 s.
        previous = self.values[-1]
        self.values.append(previous)
        if len(self.values) > self.capacity:
            self.values.pop(0)
        if animate:
            self._start_endpoint_animation(previous, value)
        else:
            self.values[-1] = value
            self._draw()

    def _start_endpoint_animation(self, start, end, duration=260):
        if self._anim_job is not None:
            try:
                self.after_cancel(self._anim_job)
            except Exception:
                pass
        self._anim_from = float(start)
        self._anim_to = float(end)
        started = time.monotonic() if 'time' in globals() else 0.0
        if started == 0.0:
            import time as _time
            started = _time.monotonic()
        self._anim_started = started

        def step():
            try:
                if not self.winfo_exists():
                    return
                import time as _time
                t = min(1.0, (_time.monotonic() - self._anim_started) / (duration / 1000.0))
                # Smoothstep easing: slow at both ends, quick through the middle.
                eased = t * t * (3.0 - 2.0 * t)
                if self.values:
                    self.values[-1] = self._anim_from + (self._anim_to - self._anim_from) * eased
                self._draw()
                if t < 1.0:
                    self._anim_job = self.after(16, step)
                else:
                    self._anim_job = None
                    if self.values:
                        self.values[-1] = self._anim_to
                    self._draw()
            except tk.TclError:
                self._anim_job = None

        step()

    def set_values(self, values, animate=False):
        if self._anim_job is not None:
            try:
                self.after_cancel(self._anim_job)
            except Exception:
                pass
            self._anim_job = None
        self.values = list(values)[-self.capacity:]
        self._draw()

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4 or h < 4 or len(self.values) < 2:
            return
        top = max(1.0, max(self.values) * 1.25)
        n = len(self.values)
        step = w / max(1, n - 1)
        pts = [(i * step, h - (v / top) * (h - 4) - 2)
               for i, v in enumerate(self.values)]
        # Soft area fill (a few blended bands instead of a real gradient).
        poly = [p for xy in pts for p in xy] + [w, h, 0, h]
        self.create_polygon(poly, fill=fl.mix(self._bg, self.color, 0.22),
                            outline="")
        flat = [p for xy in pts for p in xy]
        self.create_line(flat, fill=self.color, width=2, smooth=True,
                         capstyle="round")


class LineChart(tk.Canvas):
    """Live multi-series performance chart with grid + time axis.

    The chart keeps a rolling buffer sized in *samples*, but the caller
    can retarget how much wall-clock time that buffer should span (see
    `set_window_seconds`) — the buffer capacity is recalculated from the
    known per-sample interval so "Last 5 min" always means five real
    minutes of history regardless of how often push() is called.
    """

    def __init__(self, parent, theme, series, height=190, capacity=60,
                 aero=False, bg=None, sample_interval_s=1.5):
        """series: list of (key, label, color)."""
        self.theme = theme
        self.aero = aero
        self.series = series
        self.sample_interval_s = max(0.001, sample_interval_s)
        self.capacity = capacity
        self.window_seconds = capacity * self.sample_interval_s
        self.data = {key: [] for key, _, _ in series}
        self.hidden = set()   # keys the user has toggled off via the legend
        self._bg = bg or parent["bg"]
        super().__init__(parent, height=height, bg=self._bg,
                         highlightthickness=0, bd=0)
        self.bind("<Configure>", lambda e: self._draw())
        self._geom = None
        self.bind("<Motion>", self._on_motion)
        self.bind("<Leave>", self._on_leave)

    def set_series_visible(self, key, visible):
        """Show/hide one series (called from a legend chip click)."""
        if visible:
            self.hidden.discard(key)
        else:
            self.hidden.add(key)
        self._draw()

    def set_window_seconds(self, seconds):
        """Retarget the visible window (e.g. 60 / 300 / 900 seconds).

        Existing samples are kept — trimmed to the new capacity from the
        most recent end — so switching ranges doesn't blank the chart.
        """
        self.window_seconds = max(self.sample_interval_s, seconds)
        self.capacity = max(2, round(self.window_seconds / self.sample_interval_s))
        for key, buf in self.data.items():
            if len(buf) > self.capacity:
                del buf[0:len(buf) - self.capacity]
        self._draw()

    def push(self, samples):
        """samples: {key: value} — missing keys simply keep their history."""
        for key, value in samples.items():
            if key in self.data:
                buf = self.data[key]
                buf.append(value)
                if len(buf) > self.capacity:
                    buf.pop(0)
        self._draw()

    @staticmethod
    def _fmt_ago(seconds):
        if seconds <= 0:
            return "0s"
        if seconds < 60:
            return f"{seconds:.0f}s"
        minutes = seconds / 60
        if minutes < 60:
            return f"{minutes:.0f}m" if minutes == int(minutes) else f"{minutes:.1f}m"
        return f"{minutes / 60:.1f}h"

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 20 or h < 20:
            self._geom = None
            return
        # Reserve a small left gutter for the 0/25/50/75/100% axis labels.
        pad_l, pad_b, pad_t, pad_r = 30, 18, 6, 6
        plot_h = h - pad_b - pad_t
        grid = fl.mix(self._bg, self.theme["FG"], 0.10)
        for i in range(5):
            y = pad_t + plot_h * i / 4
            self.create_line(pad_l, y, w - pad_r, y, fill=grid)
            pct = 100 - i * 25
            self.create_text(pad_l - 4, y, text=f"{pct}%",
                             fill=self.theme["MUTED"], font=fl.F_TINY(),
                             anchor="e")
        labels = [self._fmt_ago(self.window_seconds * (4 - i) / 4)
                  for i in range(5)]
        for i, text in enumerate(labels):
            x = pad_l + (w - pad_l - pad_r) * i / 4
            self.create_text(x, h - 8, text=text, fill=self.theme["MUTED"],
                             font=fl.F_TINY())
        baseline_y = pad_t + plot_h
        for key, _label, color in self.series:
            if key in self.hidden:
                continue
            values = self.data[key]
            if len(values) < 2:
                continue
            step = (w - pad_l - pad_r) / max(1, self.capacity - 1)
            offset = (self.capacity - len(values)) * step
            pts = []
            for i, v in enumerate(values):
                x = pad_l + offset + i * step
                y = pad_t + plot_h - (min(100.0, max(0.0, v)) / 100.0) * plot_h
                pts.extend((x, y))
            # Soft fill from the line down to the baseline so the chart
            # reads as an area graph instead of leaving the space above
            # a low, flat line looking empty. `stipple` gives a dithered,
            # semi-transparent look since plain tk canvases have no
            # real alpha compositing.
            area = list(pts) + [pts[-2], baseline_y, pts[0], baseline_y]
            self.create_polygon(area, fill=color, outline="",
                                stipple="gray25")
            self.create_line(pts, fill=color, width=2, smooth=True,
                             capstyle="round")
        # Remember the plot's geometry so a mouse hover can map back to
        # a sample index without recomputing all of the above.
        self._geom = (pad_l, pad_r, pad_t, plot_h, w, h)
        self._draw_hover()

    def _on_motion(self, event):
        self._hover_x = event.x
        self._draw_hover()

    def _on_leave(self, _event=None):
        self._hover_x = None
        self.delete("hover")

    def _draw_hover(self):
        """Crosshair + value readout for whatever sample the mouse is
        currently over. Redrawn on top of `_draw()`'s output rather than
        forcing a full redraw, so hovering doesn't re-run the (cheap but
        non-trivial) series/polygon drawing every mouse-move event."""
        self.delete("hover")
        geom = self._geom
        x = getattr(self, "_hover_x", None)
        if geom is None or x is None:
            return
        pad_l, pad_r, pad_t, plot_h, w, h = geom
        plot_w = max(1, w - pad_l - pad_r)
        if x < pad_l or x > w - pad_r:
            return
        frac = (x - pad_l) / plot_w
        idx_full = round(frac * (self.capacity - 1))
        snap_x = pad_l + (idx_full / max(1, self.capacity - 1)) * plot_w
        self.create_line(snap_x, pad_t, snap_x, pad_t + plot_h,
                         fill=fl.mix(self._bg, self.theme["FG"], 0.35),
                         dash=(2, 2), tags="hover")
        ago = self._fmt_ago(self.window_seconds * (1 - idx_full / max(1, self.capacity - 1)))
        lines = [f"T-{ago}" if ago != "0s" else "now"]
        for key, label, color in self.series:
            if key in self.hidden:
                continue
            values = self.data[key]
            value_idx = idx_full - (self.capacity - len(values))
            if 0 <= value_idx < len(values):
                v = values[value_idx]
                y = pad_t + plot_h - (min(100.0, max(0.0, v)) / 100.0) * plot_h
                self.create_oval(snap_x - 3, y - 3, snap_x + 3, y + 3,
                                 fill=color, outline=self._bg, width=1,
                                 tags="hover")
                lines.append(f"{label}: {v:.0f}%")
        if len(lines) <= 1:
            return
        text = "\n".join(lines)
        # Keep the readout on-screen: flip to the left of the cursor once
        # there isn't room to the right.
        anchor_left = snap_x < w - 90
        tx = snap_x + 8 if anchor_left else snap_x - 8
        text_id = self.create_text(
            tx, pad_t + 4, text=text, fill=self.theme["FG"],
            font=fl.F_TINY(), anchor="nw" if anchor_left else "ne",
            justify="left" if anchor_left else "right", tags="hover",
        )
        bx1, by1, bx2, by2 = self.bbox(text_id)
        bg_id = self.create_rectangle(
            bx1 - 5, by1 - 3, bx2 + 5, by2 + 3,
            fill=fl.mix(self._bg, "#000000", 0.35),
            outline=fl.mix(self._bg, self.theme["FG"], 0.15), tags="hover",
        )
        self.tag_lower(bg_id, text_id)


class HealthRing(tk.Canvas):
    """Donut gauge (System Health score)."""

    def __init__(self, parent, theme, size=140, aero=False, bg=None):
        self.theme = theme
        self.aero = aero
        self.size = size
        self.score = 0
        self._display_score = 0.0
        self._anim_cancel = None
        self.caption = ""
        self._bg = bg or parent["bg"]
        super().__init__(parent, width=size, height=size, bg=self._bg,
                         highlightthickness=0, bd=0)

    def set_score(self, score, caption=""):
        target = max(0, min(100, int(score)))
        self.score = target
        self.caption = caption
        if self._anim_cancel:
            self._anim_cancel()
        start = self._display_score
        self._anim_cancel = tween(
            self, fl.MOTION_SLOW,
            lambda progress: self._set_display_score(start + (target - start) * progress),
            easing=ease_out_quint,
        )

    def _set_display_score(self, value):
        self._display_score = value
        self._draw()

    def _color(self):
        if self.score >= 80:
            return fl.GOOD
        return fl.WARN if self.score >= 55 else fl.BAD

    def _draw(self):
        self.delete("all")
        s = self.size
        pad, width = 12, 10
        track = fl.mix(self._bg, self.theme["FG"], 0.12)
        self.create_oval(pad, pad, s - pad, s - pad, outline=track,
                         width=width)
        extent = -359.9 * (self._display_score / 100.0)
        if self._display_score:
            color = self._color()
            if self.aero:   # faint outer halo so it glows behind glass
                self.create_arc(pad - 3, pad - 3, s - pad + 3, s - pad + 3,
                                start=90, extent=extent, style="arc",
                                outline=fl.mix(self._bg, color, 0.35),
                                width=width + 4)
            self.create_arc(pad, pad, s - pad, s - pad, start=90,
                            extent=extent, style="arc", outline=color,
                            width=width)
        self.create_text(s / 2, s / 2 - 8, text=self.caption or "—",
                         fill=self.theme["FG"], font=fl.font(15, "bold", True))
        self.create_text(s / 2, s / 2 + 14, text=f"{round(self._display_score)} / 100",
                         fill=self.theme["MUTED"], font=fl.F_SMALL())


class MeterBar(tk.Canvas):
    """Thin rounded usage bar (storage drives, RAM, etc.)."""

    def __init__(self, parent, theme, color=None, height=8, aero=False,
                 bg=None):
        self.theme = theme
        self.aero = aero
        self.color = color or theme["ACCENT"]
        self.value = 0.0
        self._display_value = 0.0
        self._anim_cancel = None
        self._bg = bg or parent["bg"]
        super().__init__(parent, height=height, bg=self._bg,
                         highlightthickness=0, bd=0)
        self.bind("<Configure>", lambda e: self._draw())

    def set_value(self, fraction, color=None):
        target = max(0.0, min(1.0, fraction))
        self.value = target
        if color:
            self.color = color
        if self._anim_cancel:
            self._anim_cancel()
        start = self._display_value
        self._anim_cancel = tween(
            self, fl.MOTION_SLOW,
            lambda progress: self._set_display_value(start + (target - start) * progress),
            easing=ease_out_quint,
        )

    def _set_display_value(self, value):
        self._display_value = value
        self._draw()

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4:
            return
        r = h / 2
        round_rect(self, 0, 0, w - 1, h - 1, r=r,
                   fill=fl.mix(self._bg, self.theme["FG"], 0.14), outline="")
        filled = max(h, (w - 1) * self._display_value)
        if self._display_value > 0:
            round_rect(self, 0, 0, filled, h - 1, r=r,
                       fill=self.color, outline="")


class SearchBox(tk.Frame):
    """Rounded search field with placeholder + Enter/typing callbacks."""

    def __init__(self, parent, theme, placeholder="Search tools, settings, files...",
                 width=340, aero=False, on_change=None, on_submit=None):
        self.theme = theme
        self.aero = aero
        self.placeholder = placeholder
        self.on_change = on_change
        self.on_submit = on_submit
        backdrop = parent["bg"]
        super().__init__(parent, bg=backdrop, width=width, height=32)
        self.pack_propagate(False)

        self.canvas = tk.Canvas(self, bg=backdrop, highlightthickness=0, bd=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.fill = fl.glass(theme, "LAYER_2", aero, 0.14)
        self._focused = False
        self._focus_t = 0.0
        self._focus_cancel = None

        self.var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.var, bd=0, relief="flat",
                              bg=self.fill, fg=theme["MUTED"],
                              insertbackground=theme["FG"], font=fl.F_BODY())
        self.entry.place(x=30, y=6, relwidth=1.0, width=-56, height=20)
        self.entry.insert(0, placeholder)
        self._showing_placeholder = True

        self.canvas.bind("<Configure>", lambda e: self._draw())
        self.entry.bind("<FocusIn>", self._focus_in)
        self.entry.bind("<FocusOut>", self._focus_out)
        self.entry.bind("<Return>", lambda e: self._submit())
        self.var.trace_add("write", lambda *_: self._changed())

    def _draw(self):
        self.canvas.delete("all")
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if w < 4:
            return
        outline = fl.mix(self.theme["STROKE"], self.theme["ACCENT"], self._focus_t)
        round_rect(self.canvas, 0, 0, w - 1, h - 1, r=h / 2, fill=self.fill,
                   outline=outline, width=1)
        self.canvas.create_text(16, h / 2, text="⌕", font=fl.F_SMALL(),
                                fill=self.theme["MUTED"])

    def get(self):
        return "" if self._showing_placeholder else self.var.get()

    def focus_entry(self):
        """Focus the entry and select any existing text - used by the
        top bar's Ctrl+K shortcut (mirrors the hint in the placeholder)."""
        self.entry.focus_set()
        self.entry.selection_range(0, "end")

    def _focus_in(self, _e):
        self._focused = True
        self._animate_focus(1.0)
        if self._showing_placeholder:
            self.entry.delete(0, "end")
            self.entry.configure(fg=self.theme["FG"])
            self._showing_placeholder = False

    def _focus_out(self, _e):
        self._focused = False
        self._animate_focus(0.0)
        if not self.var.get():
            self._showing_placeholder = True
            self.entry.configure(fg=self.theme["MUTED"])
            self.entry.insert(0, self.placeholder)

    def _animate_focus(self, target):
        if self._focus_cancel:
            self._focus_cancel()
        start = self._focus_t
        def update(progress):
            self._focus_t = start + (target - start) * progress
            self._draw()
        self._focus_cancel = tween(self, fl.MOTION_FAST, update, easing=ease_out_quint)

    def _changed(self):
        if self.on_change and not self._showing_placeholder:
            self.on_change(self.var.get())

    def _submit(self):
        if self.on_submit:
            self.on_submit(self.get())
