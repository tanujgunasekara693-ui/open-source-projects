#!/usr/bin/env python3
"""
gui/theme.py — TechDrive theme palettes
========================================
Thin compatibility layer over gui/fluent.py.

The redesign moved every color/typography token into gui/fluent.py, but a
lot of existing code (techdrive.py and the 50+ tool modules) imports
DARK_THEME / LIGHT_THEME / FONT_* / status_color from here. Those names
still exist and still mean exactly what they used to — they simply carry
the new Fluent/Aero values now, so nothing had to be rewritten.
"""

from gui import fluent as fl

DARK_THEME = fl.DARK
LIGHT_THEME = fl.LIGHT

# Full theme registry (TechDrive Dark/Light plus Midnight Blue, Developer,
# High Contrast). Anything offering the user a theme picker should read
# THEMES rather than assuming dark/light are the only two options.
THEMES = fl.THEMES
DEFAULT_THEME_ID = fl.DEFAULT_THEME_ID
get_theme = fl.get_theme
is_dark = fl.is_dark

# Status colors - same in both themes, chosen to read clearly on dark or
# light card backgrounds.
GOOD = fl.GOOD
WARN = fl.WARN
BAD = fl.BAD

# Legacy font tuples. They stay plain tuples (not fl.font() calls) so the
# module keeps importing before a Tk root exists; the shell upgrades to the
# resolved Segoe UI Variable families at runtime via fl.init_fonts().
FONT_UI = ("Segoe UI", 13)
FONT_UI_BOLD = ("Segoe UI", 13, "bold")
FONT_HEADER = ("Segoe UI", 18, "bold")
FONT_CARD_TITLE = ("Segoe UI", 13, "bold")
FONT_MONO = ("Consolas", 12)


def status_color(level):
    """level: 'good' | 'warn' | 'bad' -> hex color. Unknown levels fall
    back to a neutral color rather than raising, since this is almost
    always called from inside a tool's data-gathering code."""
    return {"good": GOOD, "warn": WARN, "bad": BAD}.get(level, fl.DARK["MUTED"])
