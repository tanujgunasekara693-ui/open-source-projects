#!/usr/bin/env python3
"""Haptic-style micro sound design — thin wrapper over gui.sounds."""

from __future__ import annotations

def _play(name, force=False):
    try:
        from gui import sounds
        sounds.play(name, force=force)
    except Exception:
        pass


def click():
    _play("click")


def success():
    try:
        from gui import sounds
        sounds.play("scan_complete")
    except Exception:
        _play("notification")


def warn():
    _play("notification")


def error():
    _play("error")


def sheet_open():
    _play("click")


def sheet_close():
    _play("click")


def toggle_on():
    _play("click")


def toggle_off():
    _play("click")
