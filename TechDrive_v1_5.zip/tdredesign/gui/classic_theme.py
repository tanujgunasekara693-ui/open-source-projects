"""Windows 95/98-inspired bevels for TechDrive's own Tk controls."""

import tkinter as tk


def apply(root, enabled=True):
    """Apply raised grey bevels to classic-theme buttons in the widget tree.

    The regular theme rebuild destroys old controls before this is called, so
    disabling the classic theme simply means rebuilding with the normal styles.
    """
    if not enabled:
        return

    def visit(parent):
        for widget in parent.winfo_children():
            if isinstance(widget, tk.Button):
                try:
                    widget.configure(
                        bg="#c0c0c0",
                        fg="#000000",
                        activebackground="#dfdfdf",
                        activeforeground="#000000",
                        disabledforeground="#808080",
                        relief=tk.RAISED,
                        overrelief=tk.RAISED,
                        bd=2,
                        highlightthickness=1,
                        highlightbackground="#ffffff",
                        highlightcolor="#000080",
                        font=("MS Sans Serif", 9),
                    )
                except tk.TclError:
                    pass
            visit(widget)

    visit(root)