#!/usr/bin/env python3
"""Offline Genius tips — contextual explanations without cloud AI."""

from __future__ import annotations

TIPS = {
    "cpu_hot": {
        "title": "High CPU temperature",
        "body": "Sustained loads above ~90°C can trigger thermal throttling. "
                "Check cooler seating, dust, and case airflow before replacing hardware.",
    },
    "cpu_usage_high": {
        "title": "CPU at high utilization",
        "body": "Identify the top process in Live Monitor. Background updates, "
                "antivirus scans, and browser tabs are common causes.",
    },
    "ram_high": {
        "title": "Memory pressure",
        "body": "Windows will hard-fault to disk when RAM is exhausted, which feels "
                "like severe slowdown. Close heavy apps or add RAM if this is frequent.",
    },
    "disk_full": {
        "title": "Low free disk space",
        "body": "Updates, restore points, and repair tools need free space. "
                "Aim for at least 15–20% free on the system volume.",
    },
    "disk_slow": {
        "title": "Slow storage",
        "body": "High latency or 100% active time often means a failing drive, "
                "full SSD without TRIM, or a saturating backup/scan.",
    },
    "smart_warning": {
        "title": "SMART warning",
        "body": "SMART attributes predict failure; they are not a guarantee. "
                "Back up immediately and plan a drive replacement.",
    },
    "gpu_hot": {
        "title": "GPU running hot",
        "body": "Under load, 75–85°C is common for many cards. Sustained values "
                "near the manufacturer's limit warrant cleaning and fan curve checks.",
    },
    "network_drop": {
        "title": "Network instability",
        "body": "Intermittent drops are often Wi‑Fi interference, power-saving NICs, "
                "or driver issues. Test with Ethernet to isolate the layer.",
    },
    "health_stale": {
        "title": "Health data is outdated",
        "body": "Run Health Center after major updates or hardware changes so "
                "suggestions and baselines stay meaningful.",
    },
    "default": {
        "title": "TechDrive tip",
        "body": "Use Ctrl+K to jump anywhere. Control Center (Ctrl+Shift+C) "
                "holds Focus modes, glass, and density toggles.",
    },
}


def tip_for(key: str) -> dict:
    return dict(TIPS.get(key) or TIPS["default"])


def tip_for_metric(kind: str, value: float | None = None) -> dict:
    kind = (kind or "").lower()
    if kind in ("cpu_temp", "temperature") and value is not None and value >= 90:
        return tip_for("cpu_hot")
    if kind in ("cpu", "cpu_percent") and value is not None and value >= 90:
        return tip_for("cpu_usage_high")
    if kind in ("ram", "memory") and value is not None and value >= 85:
        return tip_for("ram_high")
    if kind in ("disk", "disk_percent") and value is not None and value >= 90:
        return tip_for("disk_full")
    if kind in ("smart", "disk_health"):
        return tip_for("smart_warning")
    if kind in ("gpu_temp",) and value is not None and value >= 88:
        return tip_for("gpu_hot")
    if kind in ("network",):
        return tip_for("network_drop")
    if kind in ("health", "stale"):
        return tip_for("health_stale")
    return tip_for("default")


def show_tip_dialog(app, key="default", value=None):
    """Show a modern dialog with an offline Genius tip."""
    tip = tip_for_metric(key, value) if value is not None else tip_for(key)
    try:
        from gui.modern_dialog import info
        info(app, tip["title"], tip["body"])
    except Exception:
        try:
            app.show_toast(f"{tip['title']}: {tip['body'][:80]}…", kind="info", duration=4000)
        except Exception:
            pass
