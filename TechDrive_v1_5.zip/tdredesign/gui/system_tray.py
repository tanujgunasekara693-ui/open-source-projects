#!/usr/bin/env python3
"""System tray Live Activity for TechDrive.

Uses pystray when available; otherwise no-ops gracefully.
Shows CPU/RAM and opens Control Center or main window on click.
"""

from __future__ import annotations

import threading
import time

try:
    import psutil
except ImportError:
    psutil = None

_tray = None
_stop = threading.Event()


def _make_image():
    """Tiny 64x64 icon (blue circle) via Pillow if present, else None."""
    try:
        from PIL import Image, ImageDraw
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse((4, 4, 60, 60), fill=(10, 132, 255, 255))
        d.ellipse((20, 20, 44, 44), fill=(255, 255, 255, 230))
        return img
    except Exception:
        return None


def start_tray(app):
    """Start tray icon in a daemon thread. Safe to call multiple times."""
    global _tray
    if _tray is not None:
        return _tray
    try:
        import pystray
        from pystray import MenuItem as item
    except ImportError:
        return None

    image = _make_image()
    if image is None:
        return None

    def on_show(icon, _item):
        try:
            app.after(0, app.deiconify)
            app.after(0, app.lift)
        except Exception:
            pass

    def on_controls(icon, _item):
        def open_cc():
            cc = getattr(app, "control_center", None)
            if cc:
                cc.show()
        try:
            app.after(0, open_cc)
        except Exception:
            pass

    def on_quit(icon, _item):
        _stop.set()
        try:
            icon.stop()
        except Exception:
            pass
        try:
            app.after(0, app.destroy)
        except Exception:
            pass

    def title_text():
        if not psutil:
            return "TechDrive"
        try:
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            return f"TechDrive  ·  CPU {cpu:.0f}%  ·  RAM {ram:.0f}%"
        except Exception:
            return "TechDrive"

    menu = pystray.Menu(
        item("Show TechDrive", on_show, default=True),
        item("Control Center", on_controls),
        item("Quit", on_quit),
    )
    icon = pystray.Icon("TechDrive", image, title_text(), menu)

    def run():
        global _tray
        _tray = icon
        # periodic title update
        def updater():
            while not _stop.is_set():
                try:
                    icon.title = title_text()
                except Exception:
                    pass
                time.sleep(2.5)
        threading.Thread(target=updater, daemon=True).start()
        try:
            icon.run()
        except Exception:
            pass
        finally:
            _tray = None

    threading.Thread(target=run, daemon=True).start()
    return icon


def stop_tray():
    global _tray
    _stop.set()
    if _tray is not None:
        try:
            _tray.stop()
        except Exception:
            pass
        _tray = None
