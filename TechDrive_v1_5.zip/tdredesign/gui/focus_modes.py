#!/usr/bin/env python3
"""Focus modes for TechDrive — Repair / Gaming / Quiet / Default."""

from __future__ import annotations

from shared import database as db

MODES = {
    "default": {
        "label": "Default",
        "icon": "○",
        "desc": "Balanced UI, normal density and sounds",
        "compact": False,
        "reduce_motion": False,
        "sounds": None,  # leave as-is
        "glass": None,
        "theme_hint": None,
    },
    "repair": {
        "label": "Repair",
        "icon": "🔧",
        "desc": "Dense layout, glass on, tools front and center",
        "compact": True,
        "reduce_motion": False,
        "sounds": True,
        "glass": True,
        "theme_hint": None,
    },
    "gaming": {
        "label": "Gaming",
        "icon": "🎮",
        "desc": "OLED-friendly, less motion, quieter",
        "compact": True,
        "reduce_motion": True,
        "sounds": False,
        "glass": False,
        "theme_hint": "oled",
    },
    "quiet": {
        "label": "Quiet",
        "icon": "☾",
        "desc": "Reduce motion, mute UI sounds, soft glass",
        "compact": False,
        "reduce_motion": True,
        "sounds": False,
        "glass": True,
        "theme_hint": None,
    },
}


def get_mode():
    mid = db.get_setting("focus_mode", "default") or "default"
    if mid not in MODES:
        mid = "default"
    return mid, MODES[mid]


def set_mode(mode_id, app=None):
    if mode_id not in MODES:
        mode_id = "default"
    cfg = MODES[mode_id]
    db.set_setting("focus_mode", mode_id)

    db.set_setting("compact_density", bool(cfg["compact"]))
    db.set_setting("reduce_motion", bool(cfg["reduce_motion"]))
    if cfg["sounds"] is not None:
        db.set_setting("ui_sounds_enabled", bool(cfg["sounds"]))
    if cfg["glass"] is not None:
        try:
            from gui import liquid_glass as lg
            lg.set_enabled(bool(cfg["glass"]))
        except Exception:
            pass

    # Apply padding tokens
    try:
        from gui import fluent as fl
        if cfg["compact"]:
            fl.PAD_PAGE, fl.PAD_CARD, fl.GAP = 10, 8, 6
        else:
            fl.PAD_PAGE, fl.PAD_CARD, fl.GAP = 14, 12, 8
    except Exception:
        pass

    if app is not None:
        hint = cfg.get("theme_hint")
        if hint and hasattr(app, "apply_theme_choice"):
            try:
                # Only switch theme when Gaming wants OLED and user isn't already on it
                if hint == "oled" and getattr(app, "theme_id", "") != "oled":
                    app.apply_theme_choice("oled")
                elif hasattr(app, "apply_theme_choice"):
                    # Refresh chrome for density/glass
                    app.apply_theme_choice(getattr(app, "theme_id", "dark"))
            except Exception:
                pass
        # Notify live UI
        try:
            if hasattr(app, "show_toast"):
                app.show_toast(f"Focus: {cfg['label']}", kind="info", duration=1800)
        except Exception:
            pass
    return mode_id, cfg
