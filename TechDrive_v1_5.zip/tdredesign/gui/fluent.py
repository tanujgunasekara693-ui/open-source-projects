#!/usr/bin/env python3
"""
gui/fluent.py — TechDrive Fluent / Aero design tokens
=====================================================
Single source of truth for the modern Windows 11 + Aero look:

  * two full palettes (dark / light) that are *supersets* of the legacy
    gui.theme dicts, so every existing widget keeps working — old keys
    (BG, BG_LIGHT, FG, ACCENT, SURFACE, TEXT_FG, CARD_BG, CARD_BORDER,
    MUTED) are still present and still mean the same thing
  * Fluent extras: layered surfaces, stroke colors, gradient stops,
    shadow tints, accent ramp
  * Segoe UI Variable typography scale
  * tiny color math helpers (mix / lighten / darken) used by the widgets
    to fake translucency and hover lighting on a toolkit (tkinter) that
    has no real per-widget alpha channel.

Nothing here touches Tk, so it stays cheap to import and easy to test.
"""

# ---------------------------------------------------------------------------
# Color math
# ---------------------------------------------------------------------------

def hex_to_rgb(color):
    """'#1a2b3c' -> (26, 43, 60)."""
    h = color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    """(26, 43, 60) -> '#1a2b3c' (values are clamped, not wrapped)."""
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(c)))) for c in rgb)


def mix(color_a, color_b, t):
    """Linear blend: t=0 -> color_a, t=1 -> color_b.

    This is how the whole UI fakes alpha: a 'translucent' card is really
    its own color mixed a little way toward the backdrop (or toward the
    Aero tint when glass mode is on)."""
    a, b = hex_to_rgb(color_a), hex_to_rgb(color_b)
    return rgb_to_hex(tuple(a[i] + (b[i] - a[i]) * t for i in range(3)))


def lighten(color, amount=0.08):
    return mix(color, "#ffffff", amount)


def darken(color, amount=0.08):
    return mix(color, "#000000", amount)


def relative_luminance(color):
    """WCAG 2.x relative luminance for an sRGB color."""
    channels = []
    for c in hex_to_rgb(color):
        v = c / 255.0
        channels.append(v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4)
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def contrast_ratio(foreground, background):
    """Return the WCAG contrast ratio between two sRGB colors."""
    a, b = relative_luminance(foreground), relative_luminance(background)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


def theme_audit(theme=None):
    """Audit any theme dict's text colors against WCAG AA text targets
    (4.5:1 for normal text). Defaults to the live DARK theme; used by
    high_contrast_audit() for the dedicated High Contrast palette, and
    callable directly to spot-check the default theme after color
    tweaks instead of relying on eyeballing a screenshot."""
    theme = theme or DARK
    pairs = {
        "FG/BG": (theme["FG"], theme["BG"]),
        "MUTED/BG": (theme["MUTED"], theme["BG"]),
        "MUTED/CARD_BG": (theme["MUTED"], theme["CARD_BG"]),
        "ACCENT/BG": (theme["ACCENT"], theme["BG"]),
    }
    return {name: round(contrast_ratio(fg, bg), 2) for name, (fg, bg) in pairs.items()}


def high_contrast_audit():
    """Audit the shipped High Contrast palette against WCAG AA text targets."""
    pairs = {
        "FG/BG": (HIGH_CONTRAST["FG"], HIGH_CONTRAST["BG"]),
        "MUTED/BG": (HIGH_CONTRAST["MUTED"], HIGH_CONTRAST["BG"]),
        "ACCENT/BG": (HIGH_CONTRAST["ACCENT"], HIGH_CONTRAST["BG"]),
        "ACCENT_GLOW/BG": (HIGH_CONTRAST["ACCENT_GLOW"], HIGH_CONTRAST["BG"]),
        "ACCENT2/BG": (HIGH_CONTRAST["ACCENT2"], HIGH_CONTRAST["BG"]),
        "ACCENT3/BG": (HIGH_CONTRAST["ACCENT3"], HIGH_CONTRAST["BG"]),
        "FG/CARD_BG": (HIGH_CONTRAST["FG"], HIGH_CONTRAST["CARD_BG"]),
        "FG/LAYER_2": (HIGH_CONTRAST["FG"], HIGH_CONTRAST["LAYER_2"]),
    }
    return {name: round(contrast_ratio(fg, bg), 2) for name, (fg, bg) in pairs.items()}


def readable_on(background, light="#ffffff", dark="#101317"):
    """Pick whichever of `light`/`dark` stays readable on `background`.
    Used by Aero mode so glowing/translucent surfaces never eat text."""
    return dark if relative_luminance(background) > 0.55 else light


# ---------------------------------------------------------------------------
# Palettes
# ---------------------------------------------------------------------------
# Legacy keys are kept verbatim in meaning so nothing in techdrive.py or the
# 50+ tool modules has to change.

DARK = {
    # Professional dark shell — quiet chrome, clear elevation
    "BG": "#1c1c1e",
    "BG_LIGHT": "#232326",
    "FG": "#f5f5f7",
    "ACCENT": "#0a84ff",
    "SURFACE": "#242427",
    "TEXT_FG": "#e8e8ed",
    "CARD_BG": "#2c2c2e",
    "CARD_BORDER": "#3a3a3c",
    "MUTED": "#a1a1a6",
    "LAYER_1": "#2c2c2e",
    "LAYER_2": "#3a3a3c",
    "LAYER_3": "#0a84ff",
    "STROKE": "#48484a",
    "STROKE_SOFT": "#3a3a3c",
    "SHADOW": "#000000",
    "ACCENT_SOFT": "#0a3a75",
    "ACCENT_GLOW": "#5eb0ff",
    "ON_ACCENT": "#ffffff",
    "AERO_TINT": "#1a6fd0",
    "SELECTION": "#0a3a75",
    "GRAD_TOP": "#323235",
    "GRAD_BOTTOM": "#1c1c1e",
    "ACCENT2": "#bf5af2",
    "ACCENT3": "#64d2ff",
}

LIGHT = {
    # Professional light — clean paper, soft separators
    "BG": "#f5f5f7",
    "BG_LIGHT": "#ebebed",
    "FG": "#1d1d1f",
    "ACCENT": "#0066cc",
    "SURFACE": "#ffffff",
    "TEXT_FG": "#1d1d1f",
    "CARD_BG": "#ffffff",
    "CARD_BORDER": "#d2d2d7",
    "MUTED": "#6e6e73",
    "LAYER_1": "#ffffff",
    "LAYER_2": "#f5f5f7",
    "LAYER_3": "#e8e8ed",
    "STROKE": "#d2d2d7",
    "STROKE_SOFT": "#e8e8ed",
    "SHADOW": "#86868b",
    "ACCENT_SOFT": "#b3d7ff",
    "ACCENT_GLOW": "#0066cc",
    "ON_ACCENT": "#ffffff",
    "AERO_TINT": "#cce4ff",
    "SELECTION": "#e5f1ff",
    "GRAD_TOP": "#ffffff",
    "GRAD_BOTTOM": "#f5f5f7",
    "ACCENT2": "#a05ad6",
    "ACCENT3": "#00c7be",
}

MIDNIGHT_BLUE = {
    # Deeper, more saturated indigo than TechDrive Dark — less "black with
    # a blue tint", more "blue with black mixed in".
    "BG": "#05081a",
    "BG_LIGHT": "#0a0f2e",
    "FG": "#eef1ff",
    "ACCENT": "#5b7bff",
    "SURFACE": "#0a0f2e",
    "TEXT_FG": "#dbe1ff",
    "CARD_BG": "#0d1338",
    "CARD_BORDER": "#242c66",
    "MUTED": "#8189c2",
    "LAYER_1": "#101749",
    "LAYER_2": "#161f5c",
    "LAYER_3": "#202b7a",
    "STROKE": "#2a3378",
    "STROKE_SOFT": "#161d4d",
    "SHADOW": "#000000",
    "ACCENT_SOFT": "#232f7d",
    "ACCENT_GLOW": "#9db2ff",
    "ON_ACCENT": "#ffffff",
    "AERO_TINT": "#3d54c9",
    "SELECTION": "#26317f",
    "GRAD_TOP": "#141d5c",
    "GRAD_BOTTOM": "#05081a",
    "ACCENT2": "#8a5bff",
    "ACCENT3": "#3d6bff",
}

DEVELOPER = {
    # Near-black terminal surface, green/amber signal colors, monospace
    # bias — for people who want TechDrive to feel like their editor.
    "BG": "#0a0c0a",
    "BG_LIGHT": "#101310",
    "FG": "#e6f2e6",
    "ACCENT": "#4ade80",
    "SURFACE": "#0e110e",
    "TEXT_FG": "#c9e8c9",
    "CARD_BG": "#12160f",
    "CARD_BORDER": "#2a3327",
    "MUTED": "#7c9179",
    "LAYER_1": "#161c15",
    "LAYER_2": "#1c241a",
    "LAYER_3": "#243021",
    "STROKE": "#2d3a29",
    "STROKE_SOFT": "#1a2117",
    "SHADOW": "#000000",
    "ACCENT_SOFT": "#1d3d26",
    "ACCENT_GLOW": "#86efac",
    "ON_ACCENT": "#062b13",
    "AERO_TINT": "#1f6b3f",
    "SELECTION": "#1f4a2b",
    "GRAD_TOP": "#141e13",
    "GRAD_BOTTOM": "#0a0c0a",
    "ACCENT2": "#facc15",   # amber — secondary accent (warnings read as "logs")
    "ACCENT3": "#38bdf8",   # cyan — tertiary accent
}

HIGH_CONTRAST = {
    # Pure black/white, oversized-contrast accent, thicker strokes.
    # Not just "dark theme with different numbers" — widgets that draw a
    # 1px STROKE should read it as a real, visible border here.
    "BG": "#000000",
    "BG_LIGHT": "#000000",
    "FG": "#ffffff",
    "ACCENT": "#ffd60a",
    "SURFACE": "#000000",
    "TEXT_FG": "#ffffff",
    "CARD_BG": "#0a0a0a",
    "CARD_BORDER": "#ffffff",
    "MUTED": "#c9c9c9",
    "LAYER_1": "#141414",
    "LAYER_2": "#1e1e1e",
    "LAYER_3": "#2a2a2a",
    "STROKE": "#ffffff",
    "STROKE_SOFT": "#8a8a8a",
    "SHADOW": "#000000",
    "ACCENT_SOFT": "#4d4110",
    "ACCENT_GLOW": "#ffe873",
    "ON_ACCENT": "#000000",
    "AERO_TINT": "#ffd60a",
    "SELECTION": "#3d3405",
    "GRAD_TOP": "#141414",
    "GRAD_BOTTOM": "#000000",
    "ACCENT2": "#00e5ff",
    "ACCENT3": "#ff6b6b",
}

CLASSIC = {
    # Windows 95/98-inspired colors, drawn entirely with TechDrive widgets.
    "BG": "#008080",
    "BG_LIGHT": "#008080",
    "FG": "#000000",
    "ACCENT": "#000080",
    "SURFACE": "#c0c0c0",
    "TEXT_FG": "#000000",
    "CARD_BG": "#c0c0c0",
    "CARD_BORDER": "#808080",
    "MUTED": "#404040",
    "LAYER_1": "#dfdfdf",
    "LAYER_2": "#c0c0c0",
    "LAYER_3": "#000080",
    "STROKE": "#ffffff",
    "STROKE_SOFT": "#808080",
    "SHADOW": "#404040",
    "ACCENT_SOFT": "#000080",
    "ACCENT_GLOW": "#000080",
    "ON_ACCENT": "#ffffff",
    "AERO_TINT": "#c0c0c0",
    "SELECTION": "#000080",
    "GRAD_TOP": "#ffffff",
    "GRAD_BOTTOM": "#c0c0c0",
    "ACCENT2": "#008080",
    "ACCENT3": "#808080",
}

OLED = {
    # Pure pure-black OLED — true #000000 pixels, minimal elevation,
    # high-contrast labels, system-blue accents. Designed for AMOLED
    # panels so black areas turn pixels fully off.
    "BG": "#000000",
    "BG_LIGHT": "#000000",
    "FG": "#ffffff",
    "ACCENT": "#0a84ff",
    "SURFACE": "#000000",
    "TEXT_FG": "#f5f5f7",
    "CARD_BG": "#0a0a0a",       # barely elevated so cards still read
    "CARD_BORDER": "#1c1c1e",
    "MUTED": "#8e8e93",
    "LAYER_1": "#111111",
    "LAYER_2": "#1c1c1e",
    "LAYER_3": "#0a84ff",
    "STROKE": "#2c2c2e",
    "STROKE_SOFT": "#111111",
    "SHADOW": "#000000",
    "ACCENT_SOFT": "#003366",
    "ACCENT_GLOW": "#64b5ff",
    "ON_ACCENT": "#ffffff",
    "AERO_TINT": "#0a84ff",
    "SELECTION": "#003d7a",
    "GRAD_TOP": "#0a0a0a",
    "GRAD_BOTTOM": "#000000",
    "ACCENT2": "#bf5af2",
    "ACCENT3": "#64d2ff",
}



# ---------------------------------------------------------------------------
# Theme registry
# ---------------------------------------------------------------------------
# Single source of truth for "what themes exist". Anything that lets the
# user pick a theme (Settings, quick-toggle, etc.) should read this
# registry instead of hardcoding a dark/light pair, and any module that
# draws UI should pull its colors from the active theme's `palette` dict
# (app.theme) rather than inventing its own hex codes — that's what keeps
# a new theme here from requiring per-tool changes elsewhere.
THEMES = {
    "dark": {
        "label": "TechDrive Dark",
        "icon": "\U0001F311",   # ●
        "palette": DARK,
        "dark": True,
    },
    "light": {
        "label": "TechDrive Light",
        "icon": "\u2600\ufe0f",  # ☼
        "palette": LIGHT,
        "dark": False,
    },
    "midnight_blue": {
        "label": "Midnight Blue",
        "icon": "\U0001F535",   # ●
        "palette": MIDNIGHT_BLUE,
        "dark": True,
    },
    "developer": {
        "label": "Developer",
        "icon": "\U0001F7E3",   # ●
        "palette": DEVELOPER,
        "dark": True,
    },
    "high_contrast": {
        "label": "High Contrast",
        "icon": "\U0001F7E2",   # ●
        "palette": HIGH_CONTRAST,
        "dark": True,
    },
    "classic": {
        "label": "Windows 95/98 Classic",
        "icon": "\u25a3",
        "palette": CLASSIC,
        "dark": False,
    },
    "oled": {
        "label": "OLED Pure Black",
        "icon": "\U0001F311",
        "palette": OLED,
        "dark": True,
    },
}

DEFAULT_THEME_ID = "dark"


def get_theme(theme_id):
    """Look up a palette dict by id, falling back to the default theme
    for unknown/legacy ids (e.g. an old 'system' choice)."""
    entry = THEMES.get(theme_id)
    return entry["palette"] if entry else THEMES[DEFAULT_THEME_ID]["palette"]


def is_dark(theme_id):
    entry = THEMES.get(theme_id)
    return entry["dark"] if entry else True


# Per-metric accent colors reused by dashboard cards, sparklines and the
# live performance chart so a color always means the same thing. Tuned to
# a neon-on-dark palette (still legible on the light theme's white cards).
METRIC_COLORS = {
    "cpu": "#0a84ff",      # system blue
    "ram": "#bf5af2",      # system purple
    "gpu": "#30d158",      # system green
    "disk": "#30d158",     # system green
    "storage": "#64d2ff",  # system cyan
    "network": "#ff9f0a",  # system orange
}

GOOD = "#30d158"
WARN = "#ff9f0a"
BAD = "#ff453a"

# Gradient stops for the primary "accent" CTA (Quick Scan-style) buttons,
# read left-to-right to match the blue -> violet pill in the dashboard.
ACCENT_GRAD = ("#0a84ff", "#0a84ff")


# ---------------------------------------------------------------------------
# Typography — Segoe UI Variable with graceful fallbacks
# ---------------------------------------------------------------------------
# Tk resolves the first family that exists on the machine when given a list,
# but only via the font *object* API; for plain tuples we hand it a family
# name string, so we pick the best available at runtime in `init_fonts()`.

_DISPLAY_CANDIDATES = ["SF Pro Display", "SF Pro", "Segoe UI Variable Display", "Segoe UI Semibold", "Segoe UI"]
_TEXT_CANDIDATES = ["SF Pro Text", "SF Pro", "Segoe UI Variable Text", "Segoe UI", "Helvetica"]
_MONO_CANDIDATES = ["Cascadia Mono", "Consolas", "Courier New"]

FAMILY_DISPLAY = "Segoe UI"
FAMILY_TEXT = "Segoe UI"
FAMILY_MONO = "Consolas"

# User-adjustable global text scale (Settings > Font Size). 1.0 = default.
# Every F_* helper below routes through font(), so changing this and
# rebuilding the window chrome (see techdrive.py:_rebuild_chrome) is
# enough to resize all Fluent-drawn text app-wide.
FONT_SCALE = 1.0


def set_font_scale(scale):
    global FONT_SCALE
    FONT_SCALE = scale


def init_fonts(root):
    """Resolve the best installed font families once, at startup.
    Safe to call on Linux/macOS dev machines — it just falls through to
    whatever exists there."""
    global FAMILY_DISPLAY, FAMILY_TEXT, FAMILY_MONO
    try:
        from tkinter import font as tkfont
        available = {f.lower() for f in tkfont.families(root)}
    except Exception:
        return

    def pick(candidates, fallback):
        for name in candidates:
            if name.lower() in available:
                return name
        return fallback

    FAMILY_DISPLAY = pick(_DISPLAY_CANDIDATES, FAMILY_DISPLAY)
    FAMILY_TEXT = pick(_TEXT_CANDIDATES, FAMILY_TEXT)
    FAMILY_MONO = pick(_MONO_CANDIDATES, FAMILY_MONO)


def font(size=10, weight="normal", display=False, mono=False):
    """Typography helper: font(size, weight) -> tuple Tk understands.
    Size is scaled by FONT_SCALE (Settings > Font Size), rounded and
    floored at 6px so nothing collapses to unreadable at the low end."""
    family = FAMILY_MONO if mono else (FAMILY_DISPLAY if display else FAMILY_TEXT)
    scaled = max(6, round(size * FONT_SCALE))
    return (family, scaled) if weight == "normal" else (family, scaled, weight)


# Named scale — SF Pro / Apple HIG style hierarchy
# (Large Title → Title → Headline → Body → Callout → Footnote → Caption)
def F_LARGE_TITLE(): return font(28, "bold", display=True)
def F_TITLE():       return font(22, "bold", display=True)
def F_TITLE2():      return font(18, "bold", display=True)
def F_TITLE3():      return font(16, "bold", display=True)
def F_HEADLINE():    return font(15, "bold")
def F_SUBTITLE():    return font(14, "bold", display=True)
def F_CARD_TITLE():  return font(13, "bold")
def F_METRIC():      return font(26, "bold", display=True)
def F_BODY():        return font(13)
def F_CALLOUT():     return font(12)
def F_FOOTNOTE():    return font(11)
def F_SMALL():       return font(11)
def F_CAPTION():     return font(10)
def F_TINY():        return font(9)
def F_MONO():        return font(12, mono=True)
# backwards-compat aliases
def F_BODY_SM():     return font(12)


# ---------------------------------------------------------------------------
# Geometry / motion tokens
# ---------------------------------------------------------------------------
RADIUS_CARD = 16
RADIUS_CONTROL = 10
RADIUS_PILL = 999
SHADOW_LAYERS = 5          # restrained depth keeps busy workspaces crisp
PAD_PAGE = 24
PAD_CARD = 16
GAP = 16
HOVER_STEPS = 8
HOVER_INTERVAL = 16
MOTION_FAST = 150
MOTION_NORMAL = 220
MOTION_SLOW = 300


# ---------------------------------------------------------------------------
# Aero helpers
# ---------------------------------------------------------------------------

def glass(theme, base_key="CARD_BG", aero=False, strength=0.14):
    """Return the fill a 'glass' surface should use.

    With Aero off this is just the flat card color. With Aero on the color
    is pulled toward the Aero tint so cards read as translucent panes over
    the blurred desktop, exactly like Windows 7's glass chrome."""
    base = theme[base_key]
    if not aero:
        return base
    return mix(base, theme["AERO_TINT"], strength)


def glow_color(theme, aero=False):
    """Title glow color. Aero titles get the full bright accent halo;
    even with Aero off, titles lean slightly toward the neon accent
    rather than flat body text, so the brand color stays present without
    Aero mode being required for the app to feel "neon"."""
    if aero:
        return theme["ACCENT_GLOW"]
    return mix(theme["FG"], theme["ACCENT"], 0.22)
