#!/usr/bin/env python3
"""
TechDrive Diagnostic History
============================

Displays the results actually saved by Health Center and Diagnostic Engine.
There are no seed/demo rows: the timeline is empty until a real scan
completes on the user's machine.
"""

import datetime as _datetime
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton, MeterBar
from shared import database as db


def _date_label(timestamp):
    try:
        value = _datetime.datetime.fromtimestamp(float(timestamp))
        return value.strftime("%b %d").replace(" 0", " ")
    except (TypeError, ValueError, OSError):
        return "Unknown date"


def _category_scores(entry):
    report = entry.get("report") or {}
    return {
        category.get("label", category.get("key", "Category")):
        int(category.get("score", 0))
        for category in report.get("categories", [])
    }


def trend_statement(history):
    """Return an evidence-based statement from real health history rows."""
    if len(history) < 2:
        return "Complete another Health Center scan to establish a trend."
    chronological = sorted(history, key=lambda item: item.get("occurred_at", 0))
    oldest, newest = chronological[0], chronological[-1]
    old_scores = _category_scores(oldest)
    new_scores = _category_scores(newest)
    changes = [
        (label, new_scores[label] - old_scores[label])
        for label in new_scores if label in old_scores
    ]
    drops = sorted((change, label) for label, change in changes if change <= -3)
    gains = sorted((change, label) for label, change in changes if change >= 3)
    since = _date_label(oldest.get("occurred_at"))
    if drops:
        change, label = drops[0]
        return f"{label} health has declined since {since} ({change} points)."
    if gains:
        change, label = gains[-1]
        return f"{label} health has improved since {since} (+{change} points)."
    old_score = int(oldest.get("score") or 0)
    new_score = int(newest.get("score") or 0)
    delta = new_score - old_score
    if delta:
        direction = "improved" if delta > 0 else "declined"
        sign = "+" if delta > 0 else ""
        return f"Overall health has {direction} since {since} ({sign}{delta} points)."
    return f"Health has remained stable since {since}."


class DiagnosticHistoryPage(tk.Frame):
    """Timeline for persisted Health Center scans and diagnostic sessions."""

    def __init__(self, parent, app):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        super().__init__(parent, bg=self.theme["BG"])
        _canvas, self.content = make_scrollable(self, self.theme["BG"])
        self._build_shell()

    def _build_shell(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  DIAGNOSTIC HISTORY",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        title_row = tk.Frame(header, bg=self.theme["BG"])
        title_row.pack(fill="x")
        tk.Label(title_row, text="Diagnostic History", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(side="left",
                                                               pady=(4, 2))
        self.refresh_button = FluentButton(
            title_row, "REFRESH", command=self.refresh, theme=self.theme,
            aero=self.aero, kind="standard", icon="↻", width=116, height=34,
            backdrop=self.theme["BG"],
        )
        self.refresh_button.pack(side="right", pady=(4, 0))
        tk.Label(
            header,
            text="Every completed Health Center scan and Diagnostic Engine "
                 "session is stored locally and compared over time.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=780, justify="left",
        ).pack(anchor="w")
        self.body = tk.Frame(root, bg=self.theme["BG"])
        self.body.pack(fill="x", padx=24, pady=(8, 14))
        self.refresh()

    def refresh(self):
        health = db.get_health_history(limit=50)
        diagnostic = db.get_diagnostic_history(limit=50)
        for child in self.body.winfo_children():
            child.destroy()
        self._render_trend(health)
        self._render_system_history(health)
        self._render_diagnostic_sessions(diagnostic)

    def _render_trend(self, health):
        card = GlassCard(self.body, self.theme, aero=self.aero,
                         accent=self.theme["ACCENT"])
        card.pack(fill="x", pady=(0, 14))
        title = "SYSTEM TREND"
        tk.Label(card.body, text=title, bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        text = trend_statement(health)
        tk.Label(card.body, text=text, bg=card.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE(), wraplength=780,
                 justify="left").pack(anchor="w", padx=18, pady=(0, 4))
        if health:
            latest = health[0]
            tk.Label(card.body, text=f"Latest Health Center score: "
                     f"{latest.get('score', 0)}/100 on "
                     f"{_date_label(latest.get('occurred_at'))}",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
        else:
            tk.Label(card.body, text="No Health Center scans have completed "
                     "on this installation yet.",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))

    def _render_system_history(self, health):
        card = GlassCard(self.body, self.theme, aero=self.aero,
                         accent=fl.GOOD)
        card.pack(fill="x", pady=(0, 14))
        tk.Label(card.body, text="SYSTEM HISTORY", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(card.body, text="Health Center timeline", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(0, 8))
        if not health:
            tk.Label(card.body, text="Run SCAN MY PC in Health Center to "
                     "create the first real history entry.",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
            return
        for index, entry in enumerate(health):
            self._health_row(card, entry, index == len(health) - 1)

    def _health_row(self, card, entry, last):
        score = int(entry.get("score") or 0)
        color = fl.GOOD if score >= 80 else fl.WARN if score >= 55 else fl.BAD
        row = tk.Frame(card.body, bg=card.fill)
        row.pack(fill="x", padx=18, pady=(2, 7))
        rail = tk.Frame(row, bg=card.fill, width=26)
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        tk.Label(rail, text="●", bg=card.fill, fg=color,
                 font=fl.F_SMALL()).pack(anchor="n")
        if not last:
            tk.Frame(rail, bg=fl.mix(card.fill, self.theme["FG"], 0.18),
                     width=2).pack(fill="y", padx=5)
        detail = tk.Frame(row, bg=card.fill)
        detail.pack(side="left", fill="x", expand=True, padx=(6, 0))
        top = tk.Frame(detail, bg=card.fill)
        top.pack(fill="x")
        tk.Label(top, text=_date_label(entry.get("occurred_at")),
                 bg=card.fill, fg=self.theme["MUTED"],
                 font=fl.F_BODY()).pack(side="left")
        tk.Label(top, text=f"Health {score}", bg=card.fill, fg=color,
                 font=fl.F_CARD_TITLE()).pack(side="right")
        scores = _category_scores(entry)
        category_text = "  ·  ".join(
            f"{label} {value}" for label, value in scores.items())
        tk.Label(detail, text=category_text or entry.get("summary", ""),
                 bg=card.fill, fg=self.theme["TEXT_FG"],
                 font=fl.F_TINY(), wraplength=700,
                 justify="left").pack(anchor="w", pady=(2, 6))
        meter = MeterBar(detail, self.theme, color=color, height=6,
                         aero=self.aero, bg=card.fill)
        meter.pack(fill="x", pady=(0, 5))
        meter.set_value(score / 100)

    def _render_diagnostic_sessions(self, sessions):
        card = GlassCard(self.body, self.theme, aero=self.aero,
                         accent=self.theme["ACCENT2"])
        card.pack(fill="x")
        tk.Label(card.body, text="DIAGNOSTIC ENGINE SESSIONS", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(card.body, text="Symptom investigations", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(0, 8))
        if not sessions:
            tk.Label(card.body, text="No Diagnostic Engine sessions have "
                     "completed on this installation yet.",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
            return
        for session in sessions:
            self._session_row(card, session)

    def _session_row(self, card, session):
        score = int(session.get("score") or 0)
        color = fl.GOOD if score >= 80 else fl.WARN if score >= 55 else fl.BAD
        row = tk.Frame(card.body, bg=card.fill)
        row.pack(fill="x", padx=18, pady=(2, 9))
        top = tk.Frame(row, bg=card.fill)
        top.pack(fill="x")
        report = session.get("report") or {}
        session_id = report.get("session_id", f"#{session.get('id', '')}")
        tk.Label(top, text=f"{_date_label(session.get('occurred_at'))}  "
                 f"{session_id}", bg=card.fill, fg=self.theme["MUTED"],
                 font=fl.F_BODY()).pack(side="left")
        tk.Label(top, text=f"{score}/100", bg=card.fill, fg=color,
                 font=fl.F_CARD_TITLE()).pack(side="right")
        tk.Label(row, text=report.get("symptom", session.get("summary", "")),
                 bg=card.fill, fg=self.theme["FG"], font=fl.F_BODY(),
                 wraplength=740, justify="left").pack(anchor="w", pady=(3, 0))
        tk.Label(row, text=f"Likely area: {report.get('likely_area', 'Not recorded')}",
                 bg=card.fill, fg=self.theme["TEXT_FG"], font=fl.F_TINY(),
                 wraplength=740, justify="left").pack(anchor="w", pady=(2, 0))