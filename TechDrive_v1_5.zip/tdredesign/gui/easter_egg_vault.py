#!/usr/bin/env python3
import os, platform, random, time, tkinter as tk
from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton
JOKES=["Have you tried turning the technician off and on again?","404: Motivation not found. Diagnostics continue anyway.","TechDrive has inspected the inspection inspector.","Your PC has declined to comment on the incident."]
class EasterEggVaultPage(tk.Frame):
 def __init__(self,parent,app):
  super().__init__(parent,bg=app.theme['BG']); self.app=app; self.theme=app.theme; self.aero=app.is_aero_enabled(); self._build()
 def _build(self):
  th=self.theme; h=tk.Frame(self,bg=th['BG']); h.pack(fill='x',padx=24,pady=(22,8)); tk.Label(h,text='TECHDRIVE CORE  /  VAULT',bg=th['BG'],fg=th['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w'); tk.Label(h,text='TechDrive Vault',bg=th['BG'],fg=th['FG'],font=fl.F_TITLE()).pack(anchor='w'); tk.Label(h,text='Harmless hidden experiments, developer diagnostics, jokes and visual easter eggs. Nothing here changes, repairs, deletes, or disables Windows.',bg=th['BG'],fg=th['MUTED'],font=fl.F_SMALL(),wraplength=900,justify='left').pack(anchor='w')
  body=tk.Frame(self,bg=th['BG']); body.pack(fill='both',expand=True,padx=24,pady=10)
  c=GlassCard(body,th,aero=self.aero,accent=th['ACCENT2'],gradient=True); c.pack(fill='x',pady=6); tk.Label(c.body,text='○ EASTER EGG DECK',bg=c.fill,fg=th['FG'],font=fl.F_CARD_TITLE()).pack(anchor='w',padx=16,pady=(14,4)); self.joke=tk.StringVar(value=random.choice(JOKES)); tk.Label(c.body,textvariable=self.joke,bg=c.fill,fg=th['MUTED'],font=fl.F_BODY(),wraplength=820,justify='left').pack(anchor='w',padx=16,pady=6); FluentButton(c.body,'ANOTHER JOKE',theme=th,aero=self.aero,kind='standard',width=130,height=32,command=lambda:self.joke.set(random.choice(JOKES)),backdrop=c.fill).pack(anchor='w',padx=16,pady=(2,14))
  d=GlassCard(body,th,aero=self.aero,accent=th['ACCENT'],gradient=False); d.pack(fill='both',expand=True,pady=6); tk.Label(d.body,text='DEVELOPER DIAGNOSTICS',bg=d.fill,fg=th['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w',padx=16,pady=(14,4)); out=tk.Text(d.body,bg=th['SURFACE'],fg=th['FG'],insertbackground=th['FG'],font=fl.font(9,mono=True),height=12,wrap='word',borderwidth=0); out.pack(fill='both',expand=True,padx=16,pady=8)
  def diag():
   lines=[f'Time: {time.strftime("%Y-%m-%d %H:%M:%S")}',f'Platform: {platform.platform()}',f'Python: {platform.python_version()}',f'Architecture: {platform.machine()}',f'Windows: {platform.system()=="Windows"}',f'Process ID: {os.getpid()}',f'Developer mode: {bool(getattr(self.app,"developer_mode",False))}']; out.delete('1.0','end'); out.insert('end','\n'.join(lines))
  FluentButton(d.body,'RUN LOCAL DIAGNOSTIC',theme=th,aero=self.aero,kind='accent',width=170,height=32,command=diag,backdrop=d.fill).pack(anchor='w',padx=16,pady=(0,14))
