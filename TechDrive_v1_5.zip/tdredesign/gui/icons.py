"""TechDrive centralized icon loader.

The bundled SVG masters are the source artwork; 24/32/48/64 PNG renders are
used by Tkinter. Missing assets gracefully fall back to a small generated
TechDrive glyph rather than crashing the GUI.
"""
from pathlib import Path
import json
import tkinter as tk

_ROOT = Path(__file__).resolve().parent / "assets" / "techdrive_icons"
_MANIFEST = _ROOT / "icon_manifest.json"
try:
    _DATA = json.loads(_MANIFEST.read_text(encoding="utf-8"))
except Exception:
    _DATA = {"sizes": [24, 32, 48, 64], "entries": []}

_ENTRIES = _DATA.get("entries", [])
_BY_KEY = {}
_BY_ID = {}
for entry in _ENTRIES:
    _BY_ID[entry.get("icon_id", "")] = entry
    key = (entry.get("category", ""), entry.get("tool", ""))
    _BY_KEY.setdefault(key, entry)


def find_icon_id(category, tool):
    """Return the generated icon id for a catalogue tool, if available."""
    entry = _BY_KEY.get((category, tool))
    if entry:
        return entry["icon_id"]
    # Case-insensitive fallback for older/generated manifests.
    cl, tl = str(category).lower(), str(tool).lower()
    for e in _ENTRIES:
        if str(e.get("category", "")).lower() == cl and str(e.get("tool", "")).lower() == tl:
            return e.get("icon_id")
    return None


def path_for(icon_id, size=32):
    if not icon_id:
        return None
    try:
        size = int(size)
    except Exception:
        size = 32
    if size not in _DATA.get("sizes", [24, 32, 48, 64]):
        size = 32
    entry = _BY_ID.get(icon_id)
    if not entry:
        return None
    path = _ROOT / entry.get("icon_dir", "") / f"{icon_id}_{size}.png"
    return path if path.exists() else None


def path_for_tool(category, tool, size=32):
    return path_for(find_icon_id(category, tool), size)


def load_photo(parent, category, tool, size=32, cache=None):
    """Load a Tk PhotoImage and retain it in an optional cache dict."""
    path = path_for_tool(category, tool, size)
    if not path:
        return None
    cache = cache if cache is not None else {}
    key = str(path)
    if key not in cache:
        try:
            cache[key] = tk.PhotoImage(master=parent, file=str(path))
        except Exception:
            return None
    return cache[key]


def load_photo_by_id(parent, icon_id, size=32, cache=None):
    path = path_for(icon_id, size)
    if not path:
        return None
    cache = cache if cache is not None else {}
    key = str(path)
    if key not in cache:
        try:
            cache[key] = tk.PhotoImage(master=parent, file=str(path))
        except Exception:
            return None
    return cache[key]


def module_icon(category, size=32):
    """Best-effort module/category icon lookup using a representative tool."""
    for e in _ENTRIES:
        if e.get("category") == category:
            return path_for(e.get("icon_id"), size)
    return None


def stats():
    return {"entries": len(_ENTRIES), "sizes": list(_DATA.get("sizes", [])), "root": str(_ROOT)}
