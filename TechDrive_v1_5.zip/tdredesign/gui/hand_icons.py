#!/usr/bin/env python3
"""
gui/hand_icons.py - TechDrive's own hand-drawn icon set
=======================================================
Original line icons that replace emoji and unicode glyphs in the dashboard.

Every icon is described as a few strokes on a 24 x 24 grid.  When rendered, each
stroke is subdivided and nudged by a small, *deterministic* wobble (seeded by the
icon name), closed shapes overshoot slightly and strokes get round caps - so the
set reads as drawn with a pen rather than stamped from a font, yet each icon looks
identical on every launch.

Icons are drawn with PIL at 4x and scaled down (smooth edges at any size), tinted
with whatever colour the caller asks for, and cached.  Nothing is loaded from disk
or the network, and no emoji / font glyphs are involved.

    photo = icon_photo(widget, "cpu", 20, "#0a84ff")   # tk-compatible image
    img   = icon_image("cpu", 20, "#0a84ff")           # plain PIL image
"""

from __future__ import annotations

import math
import random

try:
    from PIL import Image, ImageDraw
except Exception:                                   # pragma: no cover
    Image = ImageDraw = None

GRID = 24.0
SS = 4                      # supersampling factor
STROKE = 1.7                # stroke width in grid units


# ---------------------------------------------------------------------------
# Stroke primitives (all coordinates on the 24-unit grid)
# ---------------------------------------------------------------------------
def _line(*pts):
    return ("poly", list(pts), False)


def _shape(*pts):
    return ("poly", list(pts), True)


def _rect(x0, y0, x1, y1):
    return ("poly", [(x0, y0), (x1, y0), (x1, y1), (x0, y1)], True)


def _circle(cx, cy, r):
    return ("arc", cx, cy, r, 0, 360)


def _arc(cx, cy, r, a0, a1):
    return ("arc", cx, cy, r, a0, a1)


def _dot(x, y, r=1.1):
    return ("dot", x, y, r)


def _heart():
    pts = []
    for i in range(0, 41):
        t = i / 40 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((12 + x * 0.54, 11.5 - y * 0.54))
    return ("poly", pts, True)


def _star():
    pts = []
    for i in range(10):
        r = 9.2 if i % 2 == 0 else 4.0
        a = -math.pi / 2 + i * math.pi / 5
        pts.append((12 + r * math.cos(a), 12.6 + r * math.sin(a)))
    return ("poly", pts, True)


def _polygon(cx, cy, r, n, rot=0.0):
    return ("poly", [(cx + r * math.cos(rot + i * 2 * math.pi / n),
                      cy + r * math.sin(rot + i * 2 * math.pi / n))
                     for i in range(n)], True)


ICONS = {
    # --- hardware / metrics ------------------------------------------------
    "cpu": [
        _rect(6.5, 6.5, 17.5, 17.5), _rect(10, 10, 14, 14),
        _line((9.5, 3), (9.5, 6.5)), _line((14.5, 3), (14.5, 6.5)),
        _line((9.5, 17.5), (9.5, 21)), _line((14.5, 17.5), (14.5, 21)),
        _line((3, 9.5), (6.5, 9.5)), _line((3, 14.5), (6.5, 14.5)),
        _line((17.5, 9.5), (21, 9.5)), _line((17.5, 14.5), (21, 14.5)),
    ],
    "ram": [
        _rect(3, 7.5, 21, 16),
        _line((7, 10.5), (7, 13)), _line((11, 10.5), (11, 13)),
        _line((15, 10.5), (15, 13)),
        _line((6, 16), (6, 19)), _line((9.5, 16), (9.5, 19)),
        _line((13, 16), (13, 19)), _line((16.5, 16), (16.5, 19)),
        _line((20, 16.5), (20, 19)),
    ],
    "storage": [
        _shape((3.5, 8.5), (5.5, 4.5), (18.5, 4.5), (20.5, 8.5),
               (20.5, 18), (3.5, 18)),
        _line((3.5, 12.5), (20.5, 12.5)),
        _dot(17, 15.4, 1.0), _dot(13.5, 15.4, 1.0),
    ],
    "gpu": [
        _rect(3, 6.5, 19, 16.5), _circle(11, 11.5, 3.3),
        _line((11, 8.2), (11, 11.5), (13.6, 12.8)),
        _line((19, 9), (21.5, 9)), _line((19, 13), (21.5, 13)),
        _line((5, 19.5), (13, 19.5)),
    ],
    "network": [
        _arc(12, 18, 4.5, 228, 312), _arc(12, 18, 9, 228, 312),
        _arc(12, 18, 13.5, 232, 308), _dot(12, 18.2, 1.3),
    ],
    # --- system overview -----------------------------------------------------
    "monitor": [
        _shape((3, 5), (21, 5), (21, 16), (3, 16)),
        _line((12, 16), (12, 19.5)), _line((8, 19.8), (16, 19.8)),
    ],
    "clock": [
        _circle(12, 12, 8.6), _line((12, 7), (12, 12.2), (15.6, 14.2)),
    ],
    "user": [
        _circle(12, 8, 3.7), _arc(12, 22, 9, 207, 333),
    ],
    "battery": [
        _rect(3.5, 7.5, 18.5, 16.5), _line((18.5, 10.5), (21, 10.5), (21, 13.5), (18.5, 13.5)),
        _shape((11, 9), (8.5, 12.3), (11.3, 12.3), (9.7, 15.2), (13.5, 11.2), (11, 11.2)),
    ],
    "layers": [
        _shape((12, 3.5), (20.5, 8), (12, 12.5), (3.5, 8)),
        _line((3.5, 12), (12, 16.5), (20.5, 12)),
        _line((3.5, 15.8), (12, 20.3), (20.5, 15.8)),
    ],
    "drive": [
        _rect(3, 8, 21, 17), _line((3, 12.5), (21, 12.5)),
        _dot(7, 14.9, 0.9), _dot(10.2, 14.9, 0.9),
    ],
    # --- actions -------------------------------------------------------------
    "mini": [
        _rect(3, 5, 21, 19), _rect(11.5, 11, 18, 16),
    ],
    "drop": [
        _shape((12, 3), (16.5, 9.2), (18, 13.4), (16.8, 17.6), (13.6, 20.2),
               (10.4, 20.2), (7.2, 17.6), (6, 13.4), (7.5, 9.2)),
        _arc(12, 14, 3.6, 110, 190),
    ],
    "refresh": [
        _arc(12, 12, 8, 35, 320), _line((16.5, 3.6), (19.4, 6.7), (15.2, 8.2)),
    ],
    "open": [
        _line((7, 17), (17, 7)), _line((9, 7), (17, 7), (17, 15)),
    ],
    "star": [_star()],
    "gear": [
        _circle(12, 12, 3.1), _circle(12, 12, 7.2),
        _line((12, 2.8), (12, 4.8)), _line((12, 19.2), (12, 21.2)),
        _line((2.8, 12), (4.8, 12)), _line((19.2, 12), (21.2, 12)),
        _line((5.5, 5.5), (6.9, 6.9)), _line((17.1, 17.1), (18.5, 18.5)),
        _line((5.5, 18.5), (6.9, 17.1)), _line((17.1, 6.9), (18.5, 5.5)),
    ],
    "heart": [_heart()],
    "chevron": [_line((9, 6), (15, 12), (9, 18))],
    "arrow": [_line((4, 12), (19, 12)), _line((13.5, 6.5), (19, 12), (13.5, 17.5))],
    "grip": [_dot(9, 6.5, 1.2), _dot(15, 6.5, 1.2), _dot(9, 12, 1.2),
             _dot(15, 12, 1.2), _dot(9, 17.5, 1.2), _dot(15, 17.5, 1.2)],
    "close": [_line((6, 6), (18, 18)), _line((18, 6), (6, 18))],
    "hexagon": [_polygon(12, 12, 9.2, 6, math.pi / 6),
                _polygon(12, 12, 4.2, 6, math.pi / 6)],
    # --- quick actions ---------------------------------------------------------
    "wrench": [
        _arc(16.2, 7.8, 4.4, 130, 405),
        _line((13.2, 11.2), (4.6, 19.8)), _line((6.4, 21), (4.2, 18.8)),
    ],
    "scan": [
        _circle(10.5, 10.5, 6.6), _line((15.4, 15.4), (20.5, 20.5)),
        _arc(10.5, 10.5, 3.2, 200, 290),
    ],
    "pulse": [
        _line((2.5, 12.5), (7.5, 12.5), (9.6, 6.5), (13.2, 18.2),
              (15.4, 12.5), (21.5, 12.5)),
    ],
    "log": [
        _shape((5.5, 3.5), (15, 3.5), (19, 7.5), (19, 20.5), (5.5, 20.5)),
        _line((15, 3.5), (15, 7.5), (19, 7.5)),
        _line((8.5, 12), (16, 12)), _line((8.5, 15.2), (16, 15.2)),
        _line((8.5, 18.2), (12.5, 18.2)),
    ],
    "broom": [
        _line((19.5, 3.5), (12.8, 11.6)),
        _shape((9.6, 11), (15.2, 14.4), (12.2, 21), (4.6, 17.2)),
        _line((8, 15.3), (9.8, 19.2)), _line((10.6, 16.6), (11.6, 19.8)),
    ],
    "power": [
        _arc(12, 13, 7.8, -52, 232), _line((12, 3.2), (12, 12)),
    ],
    "bars": [
        _line((3.5, 20.5), (20.5, 20.5)),
        _rect(5.2, 13, 8.8, 20.5), _rect(10.3, 5.5, 13.9, 20.5),
        _rect(15.4, 9.5, 19, 20.5),
    ],
    "gauge": [
        _arc(12, 15.5, 9, 180, 360), _line((12, 15.5), (17, 9.8)),
        _dot(12, 15.5, 1.4), _line((3, 15.5), (5, 15.5)),
        _line((19, 15.5), (21, 15.5)),
    ],
    "folder": [
        _shape((3, 6.5), (9.5, 6.5), (11.5, 9), (21, 9), (21, 19.5), (3, 19.5)),
        _circle(15.5, 14.5, 2.6), _line((17.4, 16.4), (19.2, 18.2)),
    ],
    "tag": [
        _shape((3.5, 12), (12, 3.5), (20.5, 3.5), (20.5, 12), (12, 20.5)),
        _circle(16, 8, 1.4),
    ],
}

# Dashboard Quick Actions use two-letter codes; map them to icon names.
CODE_TO_ICON = {
    "FX": "wrench", "SC": "scan", "HD": "pulse", "EV": "log", "CL": "broom",
    "ST": "power", "PR": "bars", "NW": "gauge", "FS": "folder",
}


def has_icon(name):
    return name in ICONS or name in CODE_TO_ICON


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------
def _wobble_poly(pts, closed, rnd, amount=0.28, step=2.6):
    """Subdivide a polyline and jitter every point to mimic a pen stroke."""
    seq = list(pts)
    if closed:
        seq = seq + [seq[0]]
    out = []
    for (x0, y0), (x1, y1) in zip(seq, seq[1:]):
        length = math.hypot(x1 - x0, y1 - y0)
        n = max(1, int(length / step))
        for i in range(n):
            t = i / n
            out.append((x0 + (x1 - x0) * t + rnd.uniform(-amount, amount),
                        y0 + (y1 - y0) * t + rnd.uniform(-amount, amount)))
    x, y = seq[-1]
    out.append((x + rnd.uniform(-amount, amount), y + rnd.uniform(-amount, amount)))
    if closed and len(out) > 2:
        # Hand-drawn closure: overshoot the start a touch instead of a perfect join.
        x0, y0 = out[0]
        x1, y1 = out[1]
        out.append((x0 + (x1 - x0) * 0.35, y0 + (y1 - y0) * 0.35))
    return out


def _arc_points(cx, cy, r, a0, a1, rnd, amount=0.22):
    span = a1 - a0
    n = max(8, int(abs(span) / 9))
    full = abs(span) >= 359
    pts = []
    for i in range(n + 1):
        a = math.radians(a0 + span * i / n)
        rr = r + rnd.uniform(-amount, amount)
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    if full:
        # Slight overshoot so circles do not close perfectly.
        a = math.radians(a0 + span + 14)
        pts.append((cx + (r + 0.18) * math.cos(a), cy + (r + 0.18) * math.sin(a)))
    return pts


def _hex_rgb(color):
    c = color.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


_IMAGE_CACHE = {}
_PHOTO_CACHE = {}


def icon_image(name, size=20, color="#ffffff", stroke=STROKE):
    """Return a transparent RGBA PIL image of the icon, tinted `color`."""
    if Image is None:
        return None
    name = CODE_TO_ICON.get(name, name)
    strokes = ICONS.get(name) or ICONS["tag"]
    key = (name, int(size), color, stroke)
    cached = _IMAGE_CACHE.get(key)
    if cached is not None:
        return cached

    big = int(size) * SS
    unit = big / GRID
    rnd = random.Random(sum(ord(c) * (i + 1) for i, c in enumerate(name)))
    mask = Image.new("L", (big, big), 0)
    d = ImageDraw.Draw(mask)
    width = max(2, int(round(stroke * unit * (size / 24.0 * 0.35 + 0.65))))
    radius = width / 2.0

    def px(p):
        return (p[0] * unit, p[1] * unit)

    def stroke_path(points):
        pts = [px(p) for p in points]
        if len(pts) >= 2:
            d.line(pts, fill=255, width=width, joint="curve")
        for x, y in (pts[0], pts[-1]):          # round caps
            d.ellipse((x - radius, y - radius, x + radius, y + radius), fill=255)

    for item in strokes:
        kind = item[0]
        if kind == "poly":
            stroke_path(_wobble_poly(item[1], item[2], rnd))
        elif kind == "arc":
            _, cx, cy, r, a0, a1 = item
            stroke_path(_arc_points(cx, cy, r, a0, a1, rnd))
        elif kind == "dot":
            _, x, y, r = item
            x, y, r = x * unit, y * unit, r * unit
            d.ellipse((x - r, y - r, x + r, y + r), fill=255)

    mask = mask.resize((int(size), int(size)), Image.LANCZOS)
    img = Image.new("RGBA", (int(size), int(size)), _hex_rgb(color) + (0,))
    img.putalpha(mask)
    _IMAGE_CACHE[key] = img
    return img


def icon_photo(master, name, size=20, color="#ffffff"):
    """Tk-compatible PhotoImage for the icon (cached per master/name/size/colour).
    Returns None if PIL/ImageTk is unavailable so callers can fall back to text."""
    try:
        from PIL import ImageTk
        key = (id(master.winfo_toplevel()), name, int(size), color)
        photo = _PHOTO_CACHE.get(key)
        if photo is None:
            img = icon_image(name, size, color)
            if img is None:
                return None
            photo = ImageTk.PhotoImage(img, master=master)
            _PHOTO_CACHE[key] = photo
        return photo
    except Exception:
        return None


def contact_sheet(path, size=48, color="#e8e8ed", bg="#1c1c1e", cols=8):
    """Write a PNG preview of every icon (dev helper)."""
    names = list(ICONS)
    rows = (len(names) + cols - 1) // cols
    cell = size + 28
    sheet = Image.new("RGB", (cols * cell, rows * cell), bg)
    d = ImageDraw.Draw(sheet)
    for i, n in enumerate(names):
        x, y = (i % cols) * cell + 14, (i // cols) * cell + 8
        im = icon_image(n, size, color)
        sheet.paste(im, (x, y), im)
        d.text((x, y + size + 3), n, fill="#8e8e93")
    sheet.save(path)


if __name__ == "__main__":                          # pragma: no cover
    contact_sheet("hand_icons_preview.png")
