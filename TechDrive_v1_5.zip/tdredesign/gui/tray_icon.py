#!/usr/bin/env python3
"""
gui/tray_icon.py — real system tray icon
=========================================
Replaces the old "stored preference only, no tray icon implementation"
stub described in gui/settings.py. Uses `pystray` (cross-platform: native
Win32 shell notify icon on Windows via its win32 backend, AppIndicator/Gtk
on Linux, NSStatusBar on macOS) with the app's existing `generate_icon()`
PIL badge as the tray glyph, so no extra icon asset is required.

Wiring, driven entirely by existing Settings preferences:
  - show_in_system_tray   -> whether a tray icon exists at all
  - close_to_tray         -> closing the window hides it instead of quitting
  - minimize_to_tray      -> iconifying the window hides it to tray instead
  - tray_click_action     -> what a single left-click on the icon does
                             ("Restore Window" | "Show Dashboard" | "Show Quick Search")

Runs pystray in "detached" mode (icon.run_detached()) on platforms that
support it (Windows, macOS) so it shares the existing Tk mainloop instead
of needing its own; on Linux (GTK backend, no run_detached) it falls back
to a background thread running icon.run(). All menu callbacks hop back
onto the Tk thread via `app.after(0, ...)` since pystray invokes them from
its own thread.

Entirely best-effort: if pystray/Pillow aren't installed, or the platform
backend fails to initialize, the app degrades to the old behavior (no tray
icon; minimize/close just do their normal Tk thing) rather than crashing.
"""

import threading

try:
    import pystray
except Exception:                                   # pragma: no cover
    pystray = None

try:
    from PIL import Image
except Exception:                                    # pragma: no cover
    Image = None

from shared import database as db

try:
    from i18n import t, on_language_change
except Exception:                                     # pragma: no cover
    def t(key, **kwargs):
        return key

    def on_language_change(cb):
        return cb


class TrayIcon:
    """Owns the pystray Icon instance for one TechDriveApp window.

    Usage (from techdrive.py):
        self._tray = TrayIcon(self)
        self._tray.sync()   # creates/destroys the icon based on current settings

    Call `sync()` again any time `show_in_system_tray` changes in Settings.
    """

    def __init__(self, app):
        self.app = app
        self._icon = None          # pystray.Icon instance, or None
        self._thread = None        # only used on the GTK/Linux fallback path
        self._pil_image = None
        on_language_change(lambda _code: self._retitle())

    # ------------------------------------------------------------------
    # Availability
    # ------------------------------------------------------------------
    @staticmethod
    def available():
        return pystray is not None and Image is not None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def sync(self):
        """Call after any change to the show_in_system_tray setting. Creates
        the icon if the setting is on and none exists yet; tears it down if
        the setting is off and one exists."""
        wanted = db.get_setting("show_in_system_tray", False)
        if wanted and self._icon is None:
            self._create()
        elif not wanted and self._icon is not None:
            self._destroy()

    def _icon_image(self):
        if self._pil_image is not None:
            return self._pil_image
        try:
            # Reuse the app's own programmatic badge generator so the tray
            # glyph matches the taskbar/window icon exactly, with no extra
            # asset to ship.
            from techdrive import generate_icon
            img = generate_icon(size=64)
        except Exception:
            img = None
        if img is None and Image is not None:
            # Minimal solid-color fallback so a broken generate_icon() (or
            # a missing Pillow feature) still leaves a visible tray icon
            # rather than none at all.
            img = Image.new("RGBA", (64, 64), (0, 200, 230, 255))
        self._pil_image = img
        return img

    def _build_menu(self):
        return pystray.Menu(
            pystray.MenuItem(t("tray.restore"), self._on_restore, default=True),
            pystray.MenuItem(t("tray.dashboard"), self._on_dashboard),
            pystray.MenuItem(t("tray.settings"), self._on_settings),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(t("tray.exit"), self._on_exit),
        )

    def _create(self):
        if not self.available():
            return  # pystray/Pillow not installed - degrade silently
        image = self._icon_image()
        if image is None:
            return
        try:
            icon = pystray.Icon(
                "TechDrive", image, t("app.name"), menu=self._build_menu()
            )
            icon.on_activate = self._on_click  # not all backends call this; menu's default item covers those that don't
            self._icon = icon
            if hasattr(icon, "run_detached"):
                # Windows / macOS: shares the existing Tk mainloop.
                icon.run_detached()
            else:
                # Linux/GTK backend has no run_detached(); give it its own
                # daemon thread instead so it doesn't block Tk's mainloop.
                self._thread = threading.Thread(target=icon.run, daemon=True)
                self._thread.start()
        except Exception:
            self._icon = None
            self._thread = None

    def _destroy(self):
        if self._icon is not None:
            try:
                self._icon.stop()
            except Exception:
                pass
        self._icon = None
        self._thread = None

    def _retitle(self):
        if self._icon is not None:
            try:
                self._icon.title = t("app.name")
                self._icon.menu = self._build_menu()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Callbacks — pystray invokes these off the Tk thread, so every one
    # hops back via app.after(0, ...) before touching any Tk widget.
    # ------------------------------------------------------------------
    def _restore_window(self):
        try:
            self.app.deiconify()
            self.app.lift()
            self.app.focus_force()
        except Exception:
            pass

    def _on_click(self, icon, item=None):
        action = db.get_setting("tray_click_action", "Restore Window")
        if action == "Show Dashboard":
            self.app.after(0, self._show_dashboard)
        elif action == "Show Quick Search":
            self.app.after(0, self._show_quick_search)
        else:
            self.app.after(0, self._restore_window)

    def _on_restore(self, icon=None, item=None):
        self.app.after(0, self._restore_window)

    def _show_dashboard(self):
        self._restore_window()
        try:
            self.app.show_dashboard()
        except Exception:
            pass

    def _show_quick_search(self):
        self._restore_window()
        try:
            if hasattr(self.app, "topbar") and hasattr(self.app.topbar, "search"):
                self.app.topbar.search.entry.focus_set()
        except Exception:
            pass

    def _on_dashboard(self, icon=None, item=None):
        self.app.after(0, self._show_dashboard)

    def _on_settings(self, icon=None, item=None):
        def go():
            self._restore_window()
            try:
                self.app.open_settings_tab()
            except Exception:
                pass
        self.app.after(0, go)

    def _on_exit(self, icon=None, item=None):
        self.app.after(0, lambda: self.app._on_close(force_quit=True))
