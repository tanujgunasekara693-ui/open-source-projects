"""Native Tkinter Ribbon command surface for TechDrive.

The Ribbon is a navigation surface, not a second tool implementation layer.
Every diagnostic button displayed in the Ribbon is resolved from the live
TechDrive CATALOGUE and opens that exact existing tool through app.open_tool().
This keeps the 667-tool engine untouched while making a useful subset of
frequently-used tools immediately reachable.
"""
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from gui import fluent as fl
from shared import database as db
from gui.icons import load_photo, path_for_tool

# Each tuple is (group title, top-level catalogue group, keyword priorities).
# The resolver selects real tools from the live CATALOGUE at runtime, so the
# Ribbon never points at made-up/placeholder tools.
RIBBON_SPECS = {
    # Four groups per tab keeps the Ribbon useful without turning it into a
    # wall of 50+ buttons. Every button is resolved from the live CATALOGUE.
    "SYSTEM": [
        ("SYSTEM INFO", "System", ("System Info", "System Summary", "OS Info", "Windows Info", "Version", "Build")),
        ("BOOT & POWER", "System", ("Boot Info", "Boot", "Startup", "Power", "Shutdown", "Restart", "Uptime")),
        ("TERMINAL", "System", ("PowerShell", "CMD", "Terminal", "Script", "Command", "Console")),
        ("UTILITIES", "System", ("Search", "Diagnostic", "Report", "Accessibility", "Windows Tweaks", "Utilities")),
    ],
    "HARDWARE": [
        ("PROCESSOR", "Hardware", ("CPU Info", "CPU Test", "CPU Monitor", "Benchmark", "Stress", "Temperature", "Load")),
        ("MEMORY", "Hardware", ("RAM Info", "RAM Test", "Memory", "Speed", "Memory Test")),
        ("GRAPHICS", "Hardware", ("GPU Info", "GPU Test", "GPU Monitor", "NVIDIA", "VRAM", "DirectX", "Vulkan")),
        ("DEVICES", "Hardware", ("Motherboard", "BIOS", "Display", "Audio", "Printer", "Sensors", "Device")),
    ],
    "STORAGE": [
        ("DISKS", "Disk", ("Disk Info", "Disk Monitor", "Disk Test", "SMART", "Space", "Benchmark", "Disk Health")),
        ("PARTITIONS", "Disk", ("Partition", "Volume", "Disk Structure", "Virtual Disk", "Format", "Resize", "Merge")),
        ("BACKUP", "Disk", ("Backup", "Quick Snapshot", "Clone", "Imaging", "Restore", "System Restore")),
        ("RECOVERY", "Disk", ("Data Recovery", "Recovery", "Recovery Media", "Advanced Recovery", "Wipe", "Shredder")),
    ],
    "NETWORK": [
        ("NETWORK", "Network", ("Network Info", "Adapters", "IP Config", "Ping", "Traceroute", "Network Tools")),
        ("WI-FI", "Network", ("WiFi", "Wireless", "Networks", "Signal", "SSID", "Wi-Fi")),
        ("ETHERNET", "Network", ("Ethernet", "Adapter", "Link", "LAN", "Speed")),
        ("INTERNET & CLOUD", "Network", ("Internet", "Bandwidth", "DNS", "Latency", "Cloud", "Sync")),
    ],
    "SECURITY": [
        ("PROTECTION", "Security", ("Security", "Defender", "Firewall", "Secure Boot", "UAC", "Security Tools")),
        ("PRIVACY", "Security", ("Privacy", "Cookies", "History", "Cache", "Privacy Cleaner", "Telemetry")),
        ("ENCRYPTION", "Security", ("Encryption", "BitLocker", "Certificate", "Encrypted", "Key")),
        ("CREDENTIALS", "Security", ("Password", "Credentials", "Account", "Recovery Key")),
    ],
    "REPAIR": [
        ("WINDOWS REPAIR", "Repair", ("SFC", "DISM", "System Repair", "Component Store", "Health Check", "Repair")),
        ("REGISTRY", "Repair", ("Registry", "Registry Backup", "Registry Cleaner", "Registry Advanced", "Key Search")),
        ("DRIVERS & DLL", "Repair", ("Driver", "DLL", "Dependency", "Missing", "Driver Tools")),
        ("TROUBLESHOOTING", "Repair", ("BSOD", "Troubleshoot", "Diagnostics", "Recovery", "Fix")),
    ],
    "MONITOR": [
        ("LIVE", "Monitoring", ("Live Monitor", "CPU Monitor", "RAM Monitor", "GPU Monitor", "Network Monitor", "Disk Monitor")),
        ("PERFORMANCE", "Monitoring", ("Performance", "Benchmark", "Stress", "Load", "Monitor Test", "Performance Tools")),
        ("SENSORS", "Monitoring", ("Sensors", "Temperature", "Fan", "Power", "Hardware Sensors")),
        ("LOGS & HISTORY", "Monitoring", ("Event Log", "Log", "History", "Diagnostics", "Report", "Error")),
    ],
    "TOOLS": [
        ("FILES", "File", ("File Search", "Advanced Search", "Rename", "Batch Rename", "File Management")),
        ("ARCHIVE & DATA", "Disk", ("Archive", "Zip", "Unzip", "Duplicate", "File System")),
        ("DEVELOPER", "System", ("Developer", "Terminal", "Script", "IDE", "Markdown", "Console")),
        ("EXTRAS", "Hardware", ("Gaming", "Game Mode", "FPS", "System Summary", "Extra", "Utility")),
    ],
}

HOME_COMMANDS = [
    ("Quick Scan", "scan", "quick_scan"),
    ("Fix My PC", "fix", "fix_my_pc"),
    ("System Health", "health", "health"),
    ("All Tools", "tools", "all_tools"),
    ("Pinned Tools", "pin", "pinned"),
    ("Recent Tools", "recent", "recent"),
    ("Reports", "report", "reports"),
]

VIEW_COMMANDS = [
    ("Full Ribbon", "ribbon", "full"),
    ("Compact Ribbon", "compact", "compact"),
    ("Collapsed", "collapse", "collapsed"),
    ("Dark Mode", "dark", "dark"),
    ("Light Mode", "light", "light"),
    ("Aero", "aero", "aero"),
    ("Customize Ribbon", "ribbon", "customize"),
    ("Settings", "settings", "settings"),
]

# A small set of original, code-generated Ribbon glyphs is included for
# shell commands that are not catalogue tools. Tool buttons use the real
# per-tool SVG-derived PNGs from gui/assets/techdrive_icons.
_SHELL_ICON_DIR = Path(__file__).resolve().parent / "assets" / "ribbon_icons"


def _shell_icon_path(name, size=24):
    p = _SHELL_ICON_DIR / f"{name}_{size}.png"
    return p if p.exists() else None


class TechDriveRibbon(tk.Frame):
    """Responsive Office-inspired Ribbon using the live TechDrive catalogue."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["SURFACE"], highlightthickness=0)
        self.app = app
        self.theme = app.theme
        self._tab_buttons = {}
        self._mode = getattr(app, "_ribbon_mode", "full")
        self._active_tab = "HOME"
        self._image_cache = {}
        self._build()

    # ------------------------------------------------------------------
    # Live catalogue resolution
    # ------------------------------------------------------------------
    def _flatten(self):
        return [(cat, tool) for cat, _icon, tools in self._catalogue() for tool in tools]

    def _catalogue(self):
        # techdrive.CATALOGUE is the authoritative live list after module
        # loading. Prefer the app module's object so enable/disable refreshes
        # are reflected immediately.
        try:
            import sys
            mod = sys.modules[type(self.app).__module__]
            return mod.CATALOGUE
        except Exception:
            return []

    def _tools_in_group(self, group):
        try:
            import sys
            mod = sys.modules[type(self.app).__module__]
            names = set(mod.TOOL_GROUPS.get(group, []))
        except Exception:
            names = set()
        result = []
        for cat, _icon, tools in self._catalogue():
            if cat in names:
                result.extend((cat, t) for t in tools)
        return result

    @staticmethod
    def _score(tool, keywords):
        name = str(tool).lower()
        score = 0
        for i, kw in enumerate(keywords):
            k = str(kw).lower()
            if name == k:
                score += 1000 - i
            elif name.startswith(k):
                score += 400 - i
            elif k in name:
                score += 100 - i
        return score

    def _resolve_tools(self, group, keywords, count=3, used=None):
        used = used if used is not None else set()
        pool = self._tools_in_group(group)
        ranked = sorted(pool, key=lambda x: (-self._score(x[1], keywords), x[1].lower(), x[0].lower()))
        chosen = []
        for cat, tool in ranked:
            key = (cat, tool)
            if key in used:
                continue
            # Require a meaningful keyword match. If a group has fewer than
            # count matches, fill from the same live group so the Ribbon is
            # never populated with dead commands.
            if self._score(tool, keywords) > 0:
                chosen.append(key)
                used.add(key)
            if len(chosen) >= count:
                break
        if len(chosen) < count:
            for key in sorted(pool, key=lambda x: (x[1].lower(), x[0].lower())):
                if key not in used:
                    chosen.append(key)
                    used.add(key)
                if len(chosen) >= count:
                    break
        return chosen

    # ------------------------------------------------------------------
    # Shell command dispatch
    # ------------------------------------------------------------------
    def _shell_commands(self):
        a = self.app
        return {
            "Quick Scan": a.run_quick_scan,
            "Fix My PC": a.open_fix_my_pc_tab,
            "System Health": a.open_health_center_tab,
            "All Tools": a.open_all_tools_tab,
            "Pinned Tools": a.open_pinned_tools_tab,
            "Recent Tools": self._show_recent,
            "Reports": a.open_report_generator_tab,
            "Full Ribbon": lambda: self.set_mode("full"),
            "Compact Ribbon": lambda: self.set_mode("compact"),
            "Collapsed": lambda: self.set_mode("collapsed"),
            "Dark Mode": lambda: a._set_theme_from_ribbon("dark"),
            "Light Mode": lambda: a._set_theme_from_ribbon("light"),
            "Aero": a.toggle_aero_glass,
            "Customize Ribbon": self.open_customizer,
            "Settings": a.open_settings_tab,
        }

    # ------------------------------------------------------------------
    # Ribbon customization / persistence
    # ------------------------------------------------------------------
    def _default_custom_items(self, tab):
        """Resolve the current live catalogue into a stable ordered list."""
        used = set()
        items = []
        for title, group, keywords in RIBBON_SPECS.get(tab, []):
            for cat, tool in self._resolve_tools(group, keywords, count=4, used=used):
                items.append((cat, tool))
        return items

    def _custom_items(self, tab):
        default = self._default_custom_items(tab)
        saved = db.get_setting("ribbon_customization", {})
        raw = saved.get(tab) if isinstance(saved, dict) else None
        if not isinstance(raw, list):
            return default
        available = {(c, t) for c, t in default}
        result = []
        for item in raw:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                key = (str(item[0]), str(item[1]))
                if key in available and key not in result:
                    result.append(key)
        # Keep newly-added live tools instead of silently losing them after an update.
        result.extend(item for item in default if item not in result)
        return result

    def _save_custom_items(self, tab, items):
        saved = db.get_setting("ribbon_customization", {})
        if not isinstance(saved, dict):
            saved = {}
        saved[tab] = [[c, t] for c, t in items]
        db.set_setting("ribbon_customization", saved)

    def _clear_customization(self, tab):
        saved = db.get_setting("ribbon_customization", {})
        if isinstance(saved, dict):
            saved.pop(tab, None)
            db.set_setting("ribbon_customization", saved)

    def open_customizer(self):
        """Open a native drag/drop ribbon editor."""
        win = tk.Toplevel(self)
        win.title("Customize Ribbon — TechDrive")
        win.transient(self.winfo_toplevel())
        win.resizable(True, True)
        win.minsize(760, 500)
        try:
            win.attributes("-topmost", False)
        except Exception:
            pass
        bg = self.theme["BG"]
        card = self.theme.get("CARD_BG", self.theme.get("SURFACE", bg))
        win.configure(bg=bg)

        tk.Label(win, text="Customize Ribbon", bg=bg, fg=self.theme["FG"],
                 font=fl.font(17, "bold")).pack(anchor="w", padx=20, pady=(18, 2))
        tk.Label(win, text="Pin tools, remove buttons, and drag items to reorder them. Changes are saved automatically.",
                 bg=bg, fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(anchor="w", padx=20, pady=(0, 14))

        body = tk.Frame(win, bg=bg)
        body.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        left = tk.Frame(body, bg=card, highlightthickness=1,
                        highlightbackground=self.theme["STROKE_SOFT"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right = tk.Frame(body, bg=card, highlightthickness=1,
                         highlightbackground=self.theme["STROKE_SOFT"])
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))

        tk.Label(left, text="RIBBON BUTTONS", bg=card, fg=self.theme["FG"],
                 font=fl.font(9, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
        tk.Label(left, text="Drag to reorder • Remove unneeded buttons", bg=card,
                 fg=self.theme["MUTED"], font=fl.F_TINY()).pack(anchor="w", padx=12, pady=(0, 6))
        current = tk.Listbox(left, activestyle="none", selectmode="browse",
                             bg=card, fg=self.theme["FG"],
                             selectbackground=fl.mix(card, self.theme["ACCENT"], .28),
                             selectforeground=self.theme["FG"], relief="flat", bd=0,
                             highlightthickness=0, font=fl.font(9),
                             exportselection=False)
        current.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        tk.Label(right, text="AVAILABLE TOOLS", bg=card, fg=self.theme["FG"],
                 font=fl.font(9, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
        tk.Label(right, text="Pin a tool to the selected tab", bg=card,
                 fg=self.theme["MUTED"], font=fl.F_TINY()).pack(anchor="w", padx=12, pady=(0, 6))
        available = tk.Listbox(right, activestyle="none", selectmode="browse",
                               bg=card, fg=self.theme["FG"],
                               selectbackground=fl.mix(card, self.theme["ACCENT"], .28),
                               selectforeground=self.theme["FG"], relief="flat", bd=0,
                               highlightthickness=0, font=fl.font(9),
                               exportselection=False)
        available.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        tab_var = tk.StringVar(value=next(iter(RIBBON_SPECS), "SYSTEM"))
        items_cache = {}
        available_cache = {}
        drag_index = {"value": None}

        tab_row = tk.Frame(win, bg=bg)
        tab_row.pack(fill="x", padx=20, pady=(0, 8))
        tk.Label(tab_row, text="Tab:", bg=bg, fg=self.theme["FG"], font=fl.F_SMALL()).pack(side="left")
        tab_menu = ttk.Combobox(tab_row, textvariable=tab_var,
                                values=list(RIBBON_SPECS), state="readonly", width=18)
        tab_menu.pack(side="left", padx=8)

        # ttk is already used elsewhere in the application; import lazily so
        # ribbon.py keeps its startup footprint tiny.
        def refresh_lists(tab):
            items = items_cache.setdefault(tab, self._custom_items(tab))
            defaults = self._default_custom_items(tab)
            available_cache[tab] = [x for x in defaults if x not in items]
            current.delete(0, "end")
            for cat, tool in items:
                current.insert("end", tool)
            available.delete(0, "end")
            for cat, tool in available_cache[tab]:
                available.insert("end", tool)

        def load_tab(_event=None):
            tab = tab_var.get()
            items_cache[tab] = self._custom_items(tab)
            refresh_lists(tab)
            if items_cache[tab]:
                current.selection_set(0)

        def commit():
            tab = tab_var.get()
            self._save_custom_items(tab, items_cache.get(tab, self._custom_items(tab)))
            self.show_tab(self._active_tab)

        def pin_selected():
            tab = tab_var.get()
            idx = available.curselection()
            if not idx:
                return
            source = available_cache.get(tab, [])
            item = source[idx[0]]
            items = items_cache.setdefault(tab, self._custom_items(tab))
            if item not in items:
                items.append(item)
            commit()
            refresh_lists(tab)
            current.selection_set(len(items) - 1)

        def remove_selected():
            tab = tab_var.get()
            idx = current.curselection()
            if not idx:
                return
            items = items_cache.setdefault(tab, self._custom_items(tab))
            if 0 <= idx[0] < len(items):
                items.pop(idx[0])
            commit()
            refresh_lists(tab)

        def move(delta):
            tab = tab_var.get()
            idx = current.curselection()
            if not idx:
                return
            i = idx[0]
            items = items_cache.setdefault(tab, self._custom_items(tab))
            j = i + delta
            if not (0 <= j < len(items)):
                return
            items[i], items[j] = items[j], items[i]
            commit()
            refresh_lists(tab)
            current.selection_set(j)

        def reset_tab():
            tab = tab_var.get()
            if not messagebox.askyesno("Reset Ribbon Tab", f"Restore the default buttons for {tab}?", parent=win):
                return
            self._clear_customization(tab)
            items_cache.pop(tab, None)
            load_tab()
            self.show_tab(self._active_tab)

        # Simple mouse drag-and-drop within the current listbox.
        def drag_start(event):
            idx = current.nearest(event.y)
            if 0 <= idx < current.size():
                drag_index["value"] = idx
                current.selection_clear(0, "end")
                current.selection_set(idx)

        def drag_motion(event):
            src = drag_index.get("value")
            if src is None or current.size() == 0:
                return
            dst = max(0, min(current.size() - 1, current.nearest(event.y)))
            if dst == src:
                return
            tab = tab_var.get()
            items = items_cache.setdefault(tab, self._custom_items(tab))
            if 0 <= src < len(items) and 0 <= dst < len(items):
                item = items.pop(src)
                items.insert(dst, item)
                load_tab()
                current.selection_set(dst)
                drag_index["value"] = dst

        def drag_end(_event):
            if drag_index.get("value") is not None:
                commit()
            drag_index["value"] = None

        current.bind("<Button-1>", drag_start, add="+")
        current.bind("<B1-Motion>", drag_motion, add="+")
        current.bind("<ButtonRelease-1>", drag_end, add="+")
        current.bind("<Delete>", lambda _e: (remove_selected(), "break")[1])
        available.bind("<Double-Button-1>", lambda _e: pin_selected())

        controls = tk.Frame(win, bg=bg)
        controls.pack(fill="x", padx=20, pady=(0, 18))
        FluentButton = getattr(fl, "FluentButton", None)
        # Use ordinary Tk buttons here so the editor also works on stripped-down
        # installs where themed button assets are unavailable.
        for text, cmd in (("Pin Selected", pin_selected), ("Remove", remove_selected),
                          ("Move Up", lambda: move(-1)), ("Move Down", lambda: move(1)),
                          ("Reset Tab", reset_tab)):
            tk.Button(controls, text=text, command=cmd, relief="flat", bd=0,
                      padx=10, pady=5, bg=self.theme["SURFACE"], fg=self.theme["FG"],
                      activebackground=fl.mix(self.theme["SURFACE"], self.theme["ACCENT"], .18),
                      activeforeground=self.theme["FG"], cursor="hand2").pack(side="left", padx=(0, 6))
        tk.Button(controls, text="Done", command=win.destroy, relief="flat", bd=0,
                  padx=14, pady=5, bg=self.theme["ACCENT"], fg="#ffffff",
                  activebackground=self.theme["ACCENT"], activeforeground="#ffffff",
                  cursor="hand2").pack(side="right")

        tab_menu.bind("<<ComboboxSelected>>", load_tab)
        load_tab()
        win.grab_set()
        win.focus_set()

    def _show_recent(self):
        self.app.open_all_tools_tab()
        page = getattr(self.app, "_all_tools_page", None)
        if page:
            page.show_recent()

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def _build(self):
        tabbar = tk.Frame(self, bg=self.theme["SURFACE"], height=38)
        tabbar.pack(fill="x")
        tabbar.pack_propagate(False)
        self._tabbar = tabbar
        self._duck_toggle = None

        logo_path = _shell_icon_path("techdrive", 24)
        if logo_path:
            img = self._photo(logo_path, tabbar)
            tk.Label(tabbar, image=img, bg=tabbar["bg"], padx=8).pack(side="left")
        else:
            tk.Label(tabbar, text="TD", bg=tabbar["bg"], fg=self.theme["ACCENT_GLOW"],
                     font=fl.font(9, "bold"), padx=10).pack(side="left")

        for name in ("HOME",) + tuple(RIBBON_SPECS) + ("VIEW",):
            b = tk.Label(tabbar, text=name, bg=tabbar["bg"], fg=self.theme["MUTED"],
                         font=fl.font(9, "bold"), padx=11, pady=8, cursor="hand2", takefocus=1)
            b.bind("<Return>", lambda _e, n=name: self.show_tab(n), add="+")
            b.bind("<space>", lambda _e, n=name: self.show_tab(n), add="+")
            b.bind("<FocusIn>", lambda _e, x=b: x.configure(highlightthickness=2, highlightbackground=self.theme["ACCENT_GLOW"]), add="+")
            b.bind("<FocusOut>", lambda _e, x=b: x.configure(highlightthickness=0), add="+")
            b.pack(side="left")
            b.bind("<Button-1>", lambda _e, n=name: self.show_tab(n))
            self._tab_buttons[name] = b

        self._mode_btn = tk.Label(tabbar, text="Ribbon", bg=tabbar["bg"], fg=self.theme["MUTED"],
                                  font=fl.font(8, "bold"), cursor="hand2", padx=9, takefocus=1)
        self._mode_btn.bind("<Return>", lambda _e: self.set_mode("compact" if self._mode == "full" else "full"), add="+")
        self._mode_btn.bind("<space>", lambda _e: self.set_mode("compact" if self._mode == "full" else "full"), add="+")
        self._mode_btn.bind("<FocusIn>", lambda _e: self._mode_btn.configure(highlightthickness=2, highlightbackground=self.theme["ACCENT_GLOW"]), add="+")
        self._mode_btn.bind("<FocusOut>", lambda _e: self._mode_btn.configure(highlightthickness=0), add="+")
        self._mode_btn.pack(side="right")
        self._mode_btn.bind("<Button-1>", lambda _e: self.set_mode("compact" if self._mode == "full" else "full"))

        self._body = tk.Frame(self, bg=self.theme["BG_LIGHT"], height=94)
        self._body.pack(fill="x")
        self._body.pack_propagate(False)
        self.show_tab(self._active_tab)
        self.bind("<Configure>", self._responsive, add="+")
        self.bind_all("<Control-Shift-R>", lambda _e: (self.set_mode("compact" if self._mode == "full" else "full"), "break")[1], add="+")

    def add_duck_toggle(self, enabled=True):
        """Add a compact persisted mascot switch beside the AI chat launcher."""
        if self._duck_toggle is None or not self._duck_toggle.winfo_exists():
            self._duck_toggle = tk.Button(
                self._tabbar, text="Duck: ON" if enabled else "Duck: OFF",
                command=lambda: self.app.set_duck_mascot_enabled(
                    not bool(db.get_setting("duck_mascot_enabled", True))),
                relief="flat", bd=0, padx=8, pady=4,
                bg=self.theme["SURFACE"], fg=self.theme["FG"],
                activebackground=fl.mix(self.theme["SURFACE"], self.theme["ACCENT"], .18),
                activeforeground=self.theme["FG"], cursor="hand2",
                font=fl.font(8, "bold"), takefocus=1,
            )
            self._duck_toggle.pack(side="right", padx=(0, 4), pady=3)
        self.set_duck_toggle(enabled)

    def set_duck_toggle(self, enabled):
        if self._duck_toggle is not None and self._duck_toggle.winfo_exists():
            self._duck_toggle.configure(text="Duck: ON" if enabled else "Duck: OFF",
                                        fg=self.theme["ACCENT_GLOW"] if enabled else self.theme["MUTED"])

    def _photo(self, path, parent):
        key = str(path)
        if key not in self._image_cache:
            try:
                self._image_cache[key] = tk.PhotoImage(master=parent, file=key)
            except Exception:
                self._image_cache[key] = None
        return self._image_cache.get(key)

    def show_tab(self, name):
        self._active_tab = name
        for n, b in self._tab_buttons.items():
            active = n == name
            b.configure(bg=fl.mix(self.theme["SURFACE"], self.theme["ACCENT"], .22 if active else 0),
                         fg=self.theme["FG"] if active else self.theme["MUTED"])
        for child in self._body.winfo_children():
            child.destroy()

        if self._mode == "collapsed":
            self._body.configure(height=0)
            self._body.pack_forget()
            return
        if not self._body.winfo_ismapped():
            self._body.pack(fill="x")
        self._body.configure(height=92 if self._mode == "full" else 66)

        if name == "HOME":
            self._make_shell_groups([("QUICK ACCESS", HOME_COMMANDS[:4]), ("WORKSPACE", HOME_COMMANDS[4:])])
        elif name == "VIEW":
            self._make_shell_groups([("LAYOUT", VIEW_COMMANDS[:3]), ("APPEARANCE", VIEW_COMMANDS[3:6]), ("SETTINGS", VIEW_COMMANDS[6:])])
        else:
            # The editor stores an ordered list of exact live catalogue
            # buttons. Re-group contiguous items by their original Ribbon
            # section so customization does not destroy the curated layout.
            custom = self._custom_items(name)
            title_by_item = {}
            for title, group, keywords in RIBBON_SPECS[name]:
                used = set()
                for item in self._resolve_tools(group, keywords, count=4, used=used):
                    title_by_item.setdefault(item, (title, group))
            if not custom:
                empty = tk.Label(self._body, text="No buttons pinned to this tab",
                                 bg=self._body["bg"], fg=self.theme["MUTED"],
                                 font=fl.F_SMALL())
                empty.pack(side="left", padx=16)
            else:
                groups = []
                for item in custom:
                    group_info = title_by_item.get(item, ("CUSTOM", item[0]))
                    if groups and groups[-1][0] == group_info[0]:
                        groups[-1][2].append(item)
                    else:
                        groups.append([group_info[0], group_info[1], [item]])
                limit = 4 if self._mode == "full" else 3
                for title, group, items in groups:
                    self._make_tool_group(title, group, items[:limit])

    def _make_shell_groups(self, groups):
        for title, items in groups:
            frame = tk.Frame(self._body, bg=self._body["bg"], highlightbackground=self.theme["STROKE_SOFT"], highlightthickness=1)
            frame.pack(side="left", fill="y", padx=(6, 0), pady=5)
            inner = tk.Frame(frame, bg=frame["bg"])
            inner.pack(fill="both", expand=True, padx=5, pady=3)
            row = tk.Frame(inner, bg=inner["bg"])
            row.pack(side="top", fill="both", expand=True)
            for label, hint, _ in items:
                self._make_shell_command(row, label, hint)
            tk.Label(inner, text=title, bg=inner["bg"], fg=self.theme["MUTED"],
                     font=fl.font(7, "bold")).pack(side="bottom", fill="x", pady=(2, 0))

    def _make_tool_group(self, title, group, tools):
        frame = tk.Frame(self._body, bg=self._body["bg"], highlightbackground=self.theme["STROKE_SOFT"], highlightthickness=1)
        frame.pack(side="left", fill="y", padx=(6, 0), pady=5)
        inner = tk.Frame(frame, bg=frame["bg"])
        inner.pack(fill="both", expand=True, padx=5, pady=3)
        row = tk.Frame(inner, bg=inner["bg"])
        row.pack(side="top", fill="both", expand=True)
        for cat, tool in tools:
            self._make_tool_command(row, cat, tool)
        more = tk.Label(inner, text="More tools  ›", bg=inner["bg"], fg=self.theme["ACCENT_GLOW"],
                        font=fl.font(7, "bold"), cursor="hand2")
        more.pack(side="bottom", fill="x", pady=(2, 0))
        more.bind("<Button-1>", lambda _e, g=group: self.app.open_tool_group_tab(g))
        tk.Label(inner, text=title, bg=inner["bg"], fg=self.theme["MUTED"],
                 font=fl.font(7, "bold")).pack(side="bottom", fill="x")

    def _make_shell_command(self, parent, label, hint):
        command = self._shell_commands().get(label)
        if not command:
            return
        path = _shell_icon_path(hint, 24)
        image = self._photo(path, parent) if path else None
        cell = tk.Frame(parent, bg=parent["bg"], cursor="hand2", takefocus=1, highlightthickness=0)
        cell.pack(side="left", fill="y", padx=2)
        cell.bind("<Return>", lambda _e: command(), add="+")
        cell.bind("<space>", lambda _e: command(), add="+")
        cell.bind("<FocusIn>", lambda _e: cell.configure(highlightthickness=2, highlightbackground=self.theme["ACCENT_GLOW"]), add="+")
        cell.bind("<FocusOut>", lambda _e: cell.configure(highlightthickness=0), add="+")
        if image:
            tk.Label(cell, image=image, bg=cell["bg"]).pack(pady=(2, 1))
        tk.Label(cell, text=label, bg=cell["bg"], fg=self.theme["FG"], font=fl.font(7),
                 wraplength=66, justify="center").pack(padx=2)
        for w in (cell,) + tuple(cell.winfo_children()):
            w.bind("<Button-1>", lambda _e, c=command: self._invoke(c))
            w.bind("<Enter>", lambda _e, c=cell: c.configure(bg=fl.mix(parent["bg"], self.theme["ACCENT"], .10)))
            w.bind("<Leave>", lambda _e, c=cell: c.configure(bg=parent["bg"]))

    def _make_tool_command(self, parent, category, tool):
        # This is the critical path: the callback contains the exact live
        # catalogue category + tool name, so it cannot accidentally call a
        # guessed category or placeholder command.
        command = lambda c=category, t=tool: self.app.open_tool(c, t)
        path = path_for_tool(category, tool, 24)
        image = self._photo(path, parent) if path else None
        cell = tk.Frame(parent, bg=parent["bg"], cursor="hand2", takefocus=1, highlightthickness=0)
        cell.pack(side="left", fill="y", padx=2)
        cell.bind("<Return>", lambda _e: command(), add="+")
        cell.bind("<space>", lambda _e: command(), add="+")
        cell.bind("<FocusIn>", lambda _e: cell.configure(highlightthickness=2, highlightbackground=self.theme["ACCENT_GLOW"]), add="+")
        cell.bind("<FocusOut>", lambda _e: cell.configure(highlightthickness=0), add="+")
        if image:
            tk.Label(cell, image=image, bg=cell["bg"]).pack(pady=(2, 1))
        else:
            # Text-free fallback: a tiny generated shell glyph if an old
            # installation lacks an icon asset.
            fallback = _shell_icon_path("tool", 24)
            fimg = self._photo(fallback, cell) if fallback else None
            if fimg:
                tk.Label(cell, image=fimg, bg=cell["bg"]).pack(pady=(2, 1))
        tk.Label(cell, text=tool, bg=cell["bg"], fg=self.theme["FG"], font=fl.font(7),
                 wraplength=72, justify="center").pack(padx=2)
        for w in (cell,) + tuple(cell.winfo_children()):
            w.bind("<Button-1>", lambda _e, c=command: self._invoke(c))
            w.bind("<Enter>", lambda _e, c=cell: c.configure(bg=fl.mix(parent["bg"], self.theme["ACCENT"], .10)))
            w.bind("<Leave>", lambda _e, c=cell: c.configure(bg=parent["bg"]))

    def _invoke(self, command):
        try:
            command()
        except Exception as exc:
            try:
                self.app.show_toast(str(exc), kind="error")
            except Exception:
                pass

    def set_mode(self, mode):
        if mode not in ("full", "compact", "collapsed"):
            mode = "full"
        self._mode = mode
        self.app._ribbon_mode = mode
        self.show_tab(self._active_tab)

    def _responsive(self, _event=None):
        try:
            if self.winfo_width() < 1120 and self._mode == "full":
                self.set_mode("compact")
        except tk.TclError:
            pass
