"""
TechDrive Technician Workspace
==============================

Privacy-conscious local support session. This page exports evidence only
after visible user approval and never opens a remote-control channel,
uploads data, or accepts inbound technician commands.
"""

import datetime as _datetime
import json
import os
import secrets
import tkinter as tk
import zipfile
from gui.tk_dialogs import filedialog, messagebox

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton
from shared import database as db
from shared import report_generator as reports


def get_or_create_session_id():
    current = db.get_setting("technician_session_id")
    if isinstance(current, str) and current.startswith("TD-") and len(current) == 7:
        return current
    session_id = f"TD-{secrets.token_hex(2).upper()}"
    db.set_setting("technician_session_id", session_id)
    return session_id


def _manifest(session_id, report_data):
    return {
        "package_type": "TechDrive Diagnostic Package",
        "package_version": "1.0",
        "session": {
            "session_id": session_id,
            "status": "Local",
            "remote_access_active": False,
            "network_upload_performed": False,
        },
        "privacy": {
            "scope": "Local diagnostic evidence selected by the user.",
            "export_requires_explicit_approval": True,
            "remote_access": "Not implemented or activated.",
        },
        "generated_at": _datetime.datetime.now().isoformat(timespec="seconds"),
        "included_sections": [
            "Current sensor snapshot",
            "Health Center history",
            "Diagnostic Engine history",
            "Network Lab history",
            "Security Center history",
            "Snapshot Manager history",
        ],
        "report_generated_at": report_data.get("generated_at"),
    }


def _write_readme(path, session_id):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(
            "TECHDRIVE DIAGNOSTIC PACKAGE\n"
            "============================\n\n"
            f"Session ID: {session_id}\n"
            "Status: Local\n"
            "Remote access: Not active\n"
            "Network upload: Not performed by TechDrive\n\n"
            "This package contains local diagnostic evidence selected for "
            "technician review. Treat it as sensitive system information.\n"
            "TechDrive does not include passwords, API keys, or session "
            "credentials in this package.\n"
        )


def write_diagnostic_package(output_dir, session_id):
    """Write one portable, local-only ZIP package for technician review."""
    package_dir = os.path.join(output_dir, f"TechDrive-{session_id}-package")
    os.makedirs(package_dir, exist_ok=True)
    report_data = reports.build_report_data()
    report_data["technician_session"] = {
        "session_id": session_id,
        "status": "Local",
        "remote_access_active": False,
    }
    report_data["network_lab_history"] = db.get_network_lab_history(limit=50)
    report_data["security_center_history"] = db.get_security_audit_history(limit=50)
    report_data["snapshot_history"] = db.get_snapshots(limit=50)
    report_data["package_privacy"] = {
        "network_upload_performed": False,
        "remote_access_active": False,
    }

    data_path = os.path.join(package_dir, "diagnostic_package.json")
    with open(data_path, "w", encoding="utf-8") as handle:
        json.dump(report_data, handle, indent=2, ensure_ascii=False, default=str)
    manifest_path = os.path.join(package_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(_manifest(session_id, report_data), handle, indent=2)
    _write_readme(os.path.join(package_dir, "README.txt"), session_id)

    archive_path = os.path.join(
        output_dir, f"TechDrive-{session_id}-diagnostic-package.zip"
    )
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(os.listdir(package_dir)):
            path = os.path.join(package_dir, name)
            archive.write(path, arcname=name)
    return {
        "archive": archive_path,
        "directory": package_dir,
        "session_id": session_id,
    }


def write_technician_report(output_dir, session_id):
    """Write the existing report bundle with an explicit local session note."""
    report_data = reports.build_report_data()
    report_data["technician_session"] = {
        "session_id": session_id,
        "status": "Local",
        "remote_access_active": False,
    }
    paths = reports.write_report_bundle(output_dir, data=report_data)
    note_path = os.path.join(output_dir, f"TechDrive-{session_id}-session.txt")
    with open(note_path, "w", encoding="utf-8") as handle:
        handle.write(
            "TECHDRIVE TECHNICIAN SESSION\n"
            "============================\n\n"
            f"Session ID: {session_id}\n"
            "Status: Local\n"
            "Remote access: Not active\n"
            "Network upload: Not performed by TechDrive\n\n"
            "The report bundle contains local diagnostic evidence. "
            "Share it only with a technician you trust.\n"
        )
    paths["session note"] = note_path
    return paths


class TechnicianWorkspacePage(tk.Frame):
    """Local support session and explicitly approved diagnostic exports."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.session_id = get_or_create_session_id()
        self._running = False
        self.export_approved = tk.BooleanVar(value=False)
        _, self.content = make_scrollable(self, self.theme["BG"])
        self._build()

    def _build(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  TECHNICIAN WORKSPACE",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        tk.Label(header, text="Technician Workspace", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(
                     anchor="w", pady=(4, 2))
        tk.Label(
            header,
            text="Prepare local diagnostic evidence for support without "
                 "opening remote access or sending data anywhere.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=850, justify="left",
        ).pack(anchor="w")

        session_card = GlassCard(root, self.theme, aero=self.aero,
                                 accent=self.theme["ACCENT2"], gradient=True)
        session_card.pack(fill="x", padx=24, pady=(8, 14))
        body = session_card.body
        tk.Label(body, text="TECHDRIVE SESSION", bg=session_card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        main = tk.Frame(body, bg=session_card.fill)
        main.pack(fill="x", padx=18, pady=(0, 16))
        left = tk.Frame(main, bg=session_card.fill)
        left.pack(side="left", fill="x", expand=True)
        tk.Label(left, text=f"Session ID: {self.session_id}",
                 bg=session_card.fill, fg=self.theme["FG"],
                 font=fl.F_TITLE()).pack(anchor="w")
        tk.Label(left, text="Status: LOCAL", bg=session_card.fill,
                 fg=fl.GOOD, font=fl.F_SUBTITLE()).pack(anchor="w", pady=(3, 0))
        tk.Label(
            left,
            text="No technician is connected. TechDrive does not listen for "
                 "remote commands and does not upload diagnostics.",
            bg=session_card.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=600, justify="left",
        ).pack(anchor="w", pady=(6, 0))
        self.session_badge = tk.Label(
            main, text="●  LOCAL ONLY", bg=session_card.fill, fg=fl.GOOD,
            font=fl.F_CARD_TITLE(), padx=14, pady=10,
        )
        self.session_badge.pack(side="right", anchor="n")

        consent_card = GlassCard(root, self.theme, aero=self.aero,
                                 accent=fl.WARN)
        consent_card.pack(fill="x", padx=24, pady=(0, 14))
        tk.Label(consent_card.body, text="PRIVACY APPROVAL", bg=consent_card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(
            consent_card.body,
            text="Diagnostic packages can include computer name, operating "
                 "system details, health results, network metadata, security "
                 "findings, and local history.",
            bg=consent_card.fill, fg=self.theme["FG"], font=fl.F_SMALL(),
            wraplength=820, justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 8))
        tk.Checkbutton(
            consent_card.body,
            text="I approve saving selected diagnostic evidence to a folder I choose.",
            variable=self.export_approved,
            bg=consent_card.fill, activebackground=consent_card.fill,
            fg=self.theme["TEXT_FG"], activeforeground=self.theme["FG"],
            selectcolor=self.theme["SURFACE"], highlightthickness=0,
            font=fl.F_SMALL(),
        ).pack(anchor="w", padx=14, pady=(0, 14))

        actions = GlassCard(root, self.theme, aero=self.aero,
                            accent=fl.GOOD)
        actions.pack(fill="x", padx=24, pady=(0, 14))
        tk.Label(actions.body, text="SUPPORT OUTPUTS", bg=actions.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(
            actions.body,
            text="Choose an output folder. TechDrive never uploads these files.",
            bg=actions.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
        ).pack(anchor="w", padx=18, pady=(0, 12))
        button_row = tk.Frame(actions.body, bg=actions.fill)
        button_row.pack(fill="x", padx=18, pady=(0, 8))
        self.package_button = FluentButton(
            button_row, "EXPORT DIAGNOSTIC PACKAGE",
            command=self.export_package, theme=self.theme, aero=self.aero,
            kind="accent", icon="□", width=260, height=42,
            backdrop=actions.fill,
        )
        self.package_button.pack(side="left")
        self.report_button = FluentButton(
            button_row, "GENERATE TECHNICIAN REPORT",
            command=self.generate_report, theme=self.theme, aero=self.aero,
            kind="standard", icon="▤", width=250, height=42,
            backdrop=actions.fill,
        )
        self.report_button.pack(side="left", padx=(10, 0))
        self.status_var = tk.StringVar(
            value="Approve export above, then choose an output action."
        )
        tk.Label(actions.body, textvariable=self.status_var,
                 bg=actions.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=820, justify="left").pack(
                     anchor="w", padx=18, pady=(0, 16))

        scope = GlassCard(root, self.theme, aero=self.aero,
                          accent=self.theme["ACCENT"])
        scope.pack(fill="x", padx=24, pady=(0, 14))
        tk.Label(scope.body, text="REMOTE ACCESS BOUNDARY", bg=scope.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(
            scope.body,
            text="Remote technician access is intentionally not active in "
                 "this workspace. There is no unattended control, inbound "
                 "listener, screen sharing, or hidden background session. "
                 "Any future remote-support feature must add a separate, "
                 "visible approval step before it connects.",
            bg=scope.fill, fg=self.theme["FG"], font=fl.F_SMALL(),
            wraplength=820, justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 16))

    def _approved(self):
        if self.export_approved.get():
            return True
        messagebox.showinfo(
            "Privacy Approval Required",
            "Check the privacy approval box before exporting diagnostic evidence.",
            parent=self.winfo_toplevel(),
        )
        return False

    def _choose_folder(self, title):
        folder = filedialog.askdirectory(title=title)
        if not folder:
            self.status_var.set("Export cancelled.")
        return folder

    def export_package(self):
        if self._running or not self._approved():
            return
        output_dir = self._choose_folder("Choose a folder for the diagnostic package")
        if not output_dir:
            return
        self._start_job(
            "Exporting local diagnostic package…",
            lambda: write_diagnostic_package(output_dir, self.session_id),
            self._finish_package,
        )

    def generate_report(self):
        if self._running or not self._approved():
            return
        output_dir = self._choose_folder("Choose a folder for the technician report")
        if not output_dir:
            return
        self._start_job(
            "Generating technician report from local evidence…",
            lambda: write_technician_report(output_dir, self.session_id),
            self._finish_report,
        )

    def _start_job(self, status, work, done):
        self._running = True
        self.package_button.configure(state="disabled")
        self.report_button.configure(state="disabled")
        self.status_var.set(status)
        self.app._run_bg(work, done)

    def _finish_package(self, result):
        self._finish_common()
        if hasattr(result, "message"):
            self.status_var.set(f"Package export failed: {result}")
            return
        self.status_var.set(
            f"Diagnostic package saved: {os.path.basename(result['archive'])}"
        )

    def _finish_report(self, result):
        self._finish_common()
        if hasattr(result, "message"):
            self.status_var.set(f"Technician report failed: {result}")
            return
        self.status_var.set(f"Generated {len(result)} technician report files.")

    def _finish_common(self):
        self._running = False
        self.package_button.configure(state="normal")
        self.report_button.configure(state="normal")
