#!/usr/bin/env python3
"""
gui/rgb_accent.py — Animated RGB accent strip + corner glow
===============================================================
Two purely decorative Fluent/Aero-style widgets:

  - RGBAccentBar: a thin hue-cycling strip, meant to run along any one
    edge (top/bottom/left/right) of the window. Several visual styles
    (solid / thin line / soft mist / transparent glass wash / pulsing
    glow) - see the class docstring below.
  - CornerGlow: a small hue-cycling glow blob meant to sit in one of the
    four window corners (built on the same animation approach).

Both are wired up together as "RGB accent" — one on/off setting in
Settings controls all of them (see techdrive.py:
`set_rgb_accent_enabled`, and gui/settings.py `_build_rgb_accent_section`).

Design goals (see chat discussion — this runs alongside live dashboard
sampling on low-end hardware, so it has to be nearly free):
  - Only small regions are animated, never the whole window.
  - Ticks on `after()` at ~25fps by default (`speed_ms=40`), not 60fps —
    a slow hue cycle doesn't need a high frame rate.
  - Color stops are computed once per tick with `colorsys`, not via any
    image generation, and applied with `itemconfig` on a small, fixed
    set of pre-created canvas items — no delete/recreate churn.
  - Each widget pauses itself automatically when the window loses focus
    or is minimized, and exposes start()/stop() so callers can also
    pause manually (e.g. during a heavy diskpart/dism operation).
  - Corner glows use `place()` with a small fixed size and are created
    last (so they render on top) but pinned tight to the true window
    corners — outside where TopBar/status-bar controls live — so they
    don't sit on top of anything clickable.

Usage (see techdrive.py `_build_layout` / `_apply_rgb_accent_visibility`):
    from gui.rgb_accent import RGBAccentBar, CornerGlow, CORNERS

    self.rgb_accent_top = RGBAccentBar(self, bg=self.theme["BG"])
    self.rgb_accent_top.pack(side="top", fill="x")

    self.rgb_accent_bottom = RGBAccentBar(self, bg=self.theme["BG"])
    self.rgb_accent_bottom.pack(side="bottom", fill="x")

    self.rgb_corners = [CornerGlow(self, corner=c) for c in CORNERS]

    for w in (self.rgb_accent_top, self.rgb_accent_bottom, *self.rgb_corners):
        w.start()
"""

import colorsys
import math
import types
import tkinter as tk

DEFAULT_HEIGHT = 4
DEFAULT_SPEED_MS = 40      # ~25fps
DEFAULT_HUE_STEP = 0.004   # full cycle in ~10s at 25fps
DEFAULT_SATURATION = 0.65
DEFAULT_VALUE = 1.0
SEGMENT_TARGET_PX = 20     # ~1 segment per this many pixels of width

CORNERS = ("top_left", "top_right", "bottom_left", "bottom_right")
DEFAULT_CORNER_SIZE = 56
DEFAULT_CORNER_RINGS = 5


def _hue_to_hex(h, s=DEFAULT_SATURATION, v=DEFAULT_VALUE):
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
    return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"


def _hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def blend_with_bg(color_hex, bg_hex, alpha):
    """Mixes color_hex toward bg_hex by (1 - alpha), simulating
    transparency on a Canvas (which has no real alpha channel). alpha=1.0
    -> full color, alpha=0.0 -> indistinguishable from the background."""
    alpha = max(0.0, min(1.0, alpha))
    cr, cg, cb = _hex_to_rgb(color_hex)
    br, bg_, bb = _hex_to_rgb(bg_hex)
    r = round(cr * alpha + br * (1 - alpha))
    g = round(cg * alpha + bg_ * (1 - alpha))
    b = round(cb * alpha + bb * (1 - alpha))
    return f"#{r:02x}{g:02x}{b:02x}"


def hex_to_hue(hex_color):
    """Extracts just the hue (0.0-1.0) from a '#rrggbb' color — used to
    line up "static" accent mode with the app's current theme accent
    color. Falls back to 0.0 (red) on anything unparseable."""
    try:
        hex_color = hex_color.lstrip("#")
        r = int(hex_color[0:2], 16) / 255
        g = int(hex_color[2:4], 16) / 255
        b = int(hex_color[4:6], 16) / 255
        h, _s, _v = colorsys.rgb_to_hsv(r, g, b)
        return h
    except Exception:
        return 0.0


SPEED_PRESETS = {"slow": 90, "normal": 40, "fast": 18}  # ms per tick


class RGBAccentBar(tk.Canvas):
    """Thin animated hue-cycling strip along one edge of the window.
    Cheap enough to run continuously on low-end hardware; still exposes
    start()/stop() for callers who want to suspend it during heavy
    operations or when backgrounded.

    `orientation`:
      - "horizontal" (default): runs along the top/bottom edge, hue
        cycles left-to-right, thickness is `height`.
      - "vertical": runs along the left/right edge, hue cycles
        top-to-bottom, thickness is `width` (pass via `height` still -
        it's reused as "thickness" regardless of orientation).

    `style` controls how the strip is drawn:
      - "solid" (default): the original flat, fully-opaque strip.
      - "line": a thin (2px) strip blended toward the background color
        by `opacity` - a faint, semi-transparent accent line.
      - "mist": several stacked bands fading from `opacity` at the
        center out to fully background-colored at the edges - a soft,
        blurred-looking glow instead of a hard-edged strip.
      - "glass": a single band at full thickness, uniformly blended
        toward the background at a low `opacity` - a barely-there
        tinted-glass wash rather than a bright bar. This is the
        "fully transparent" option; drag `opacity` near 0 for an
        almost-invisible tint, or up for a stronger wash.
      - "pulse": like "solid", but `opacity` itself breathes up and
        down over time (sine wave) instead of staying fixed, so the
        whole strip fades in and out as it cycles color.

    No real alpha channel is involved anywhere here (Canvas doesn't
    have one) - transparency is faked by blending each band's hue
    color toward the bar's own background color, see blend_with_bg().
    `opacity` (0.0-1.0) is the blend strength used by every style
    except "solid" (always fully opaque).
    """

    def __init__(self, parent, height=DEFAULT_HEIGHT, speed_ms=DEFAULT_SPEED_MS,
                 hue_step=DEFAULT_HUE_STEP, saturation=DEFAULT_SATURATION,
                 value=DEFAULT_VALUE, enabled=True, hue_offset=0.0,
                 style="solid", opacity=1.0, orientation="horizontal", **kw):
        kw.setdefault("highlightthickness", 0)
        kw.setdefault("bd", 0)
        bg = kw.get("bg") or (parent.cget("bg") if hasattr(parent, "cget") else "#000000")
        kw.setdefault("bg", bg)
        self._orientation = orientation if orientation in ("horizontal", "vertical") else "horizontal"
        thickness = self._thickness_for_style(style, height)
        if self._orientation == "vertical":
            super().__init__(parent, width=thickness, **kw)
        else:
            super().__init__(parent, height=thickness, **kw)

        self._hue = hue_offset % 1.0
        self._speed = speed_ms
        self._hue_step = hue_step
        self._saturation = saturation
        self._value = value
        self._job = None
        self._segments = []  # list of (band_alpha, [rect_ids...]) per band
        self._enabled = enabled  # user/setting-level on-off, distinct from start/stop
        self._style = style if style in ("solid", "line", "mist", "glass", "pulse") else "solid"
        self._opacity = max(0.0, min(1.0, opacity))
        self._bg = bg
        self._pulse_t = 0.0

        self.bind("<Configure>", self._on_resize)

        # Auto-pause when the top-level window is minimized or loses
        # focus, auto-resume when it comes back — this is what keeps the
        # animation from burning cycles in the background.
        toplevel = self.winfo_toplevel()
        self._toplevel = toplevel
        self._bind_ids = [
            ("<FocusOut>", toplevel.bind("<FocusOut>", self._on_focus_out, add="+")),
            ("<FocusIn>", toplevel.bind("<FocusIn>", self._on_focus_in, add="+")),
            ("<Unmap>", toplevel.bind("<Unmap>", self._on_focus_out, add="+")),
            ("<Map>", toplevel.bind("<Map>", self._on_focus_in, add="+")),
        ]

    @staticmethod
    def _thickness_for_style(style, requested):
        """"line" wants to stay thin regardless of the caller's default;
        "mist" wants enough room for its fade bands to actually read as
        a gradient rather than a few flat stripes."""
        if style == "line":
            return min(requested, 2)
        if style == "mist":
            return max(requested, 12)
        return requested

    def _band_alphas(self):
        """Per-band blend alpha (0-1), near edge to far edge, for the
        current style. "solid"/"pulse" are one band at full/pulsing
        alpha; "line"/"glass" are one band at self._opacity (line stays
        thin via thickness, glass fills the whole thickness); "mist" is
        several bands fading from self._opacity at the center to ~0 at
        the outer edges."""
        if self._style in ("line", "glass"):
            return [self._opacity]
        if self._style == "mist":
            bands = 5
            mid = (bands - 1) / 2
            out = []
            for r in range(bands):
                dist = abs(r - mid) / (mid if mid else 1)
                out.append(self._opacity * (1 - dist) ** 1.6)
            return out
        if self._style == "pulse":
            return [self._opacity]  # actual pulsing alpha computed per-tick
        return [1.0]

    # -- layout ---------------------------------------------------------
    def _on_resize(self, event):
        if event.width <= 1 or event.height <= 1:
            return
        self.delete("all")
        self._segments = []
        alphas = self._band_alphas()
        n_bands = len(alphas)
        vertical = self._orientation == "vertical"
        length = event.height if vertical else event.width      # hue-cycle axis
        thickness = event.width if vertical else event.height   # band-stack axis
        band_t = max(1, thickness / n_bands)
        n_segs = max(8, length // SEGMENT_TARGET_PX)
        seg_len = length / n_segs
        for b, alpha in enumerate(alphas):
            t0 = b * band_t
            t1 = thickness if b == n_bands - 1 else (b + 1) * band_t
            rects = []
            for i in range(n_segs):
                l0 = i * seg_len
                l1 = (i + 1) * seg_len + 1
                if vertical:
                    rect = self.create_rectangle(t0, l0, t1, l1, width=0)
                else:
                    rect = self.create_rectangle(l0, t0, l1, t1, width=0)
                rects.append(rect)
            self._segments.append((alpha, rects))

    # -- animation --------------------------------------------------------
    def _tick(self):
        try:
            if not self.winfo_exists() or not self._enabled:
                self._job = None
                return
        except tk.TclError:
            self._job = None
            return
        pulse_mult = 1.0
        if self._style == "pulse":
            self._pulse_t += self._speed / 1000.0
            # 0.35-1.0 range so it never fully vanishes, just breathes
            pulse_mult = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(self._pulse_t * 2.4))
        for alpha, rects in self._segments:
            n = len(rects)
            if not n:
                continue
            eff_alpha = alpha * pulse_mult if self._style == "pulse" else alpha
            for i, rect in enumerate(rects):
                h = self._hue + (i / n)
                color = _hue_to_hex(h, self._saturation, self._value)
                if eff_alpha < 1.0:
                    color = blend_with_bg(color, self._bg, eff_alpha)
                self.itemconfig(rect, fill=color)
        self._hue = (self._hue + self._hue_step) % 1.0
        try:
            self._job = self.after(self._speed, self._tick)
        except tk.TclError:
            self._job = None

    def start(self):
        """Begin (or resume) animating. Safe to call repeatedly."""
        if not self._enabled:
            return
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self._job is None:
            self._tick()

    def stop(self):
        """Pause animation. Widget stays put, just stops updating."""
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None

    def destroy(self):
        self.stop()
        try:
            for sequence, bind_id in getattr(self, "_bind_ids", []):
                if bind_id:
                    self._toplevel.unbind(sequence, bind_id)
        except Exception:
            pass
        self._bind_ids = []
        super().destroy()

    def set_enabled(self, enabled):
        """Persist-able on/off (e.g. wired to a Settings toggle), as
        opposed to the transient pausing done by start()/stop()."""
        self._enabled = enabled
        if enabled:
            self.start()
        else:
            self.stop()

    def configure_animation(self, speed_ms=None, hue_step=None,
                             saturation=None, value=None, fixed_hue=None,
                             style=None, opacity=None):
        """Live-tune the animation without recreating the widget. Pass
        only the parameters that changed. `fixed_hue` (0.0-1.0) freezes
        the strip at one color (hue_step is forced to 0); pass
        fixed_hue=None with a hue_step to go back to cycling.

        `style` ("solid"/"line"/"mist"/"glass"/"pulse") and `opacity`
        (0.0-1.0) affect how many bands are drawn and how strongly each
        blends toward the background — changing either rebuilds the
        band layout (cheap; only happens on an explicit settings
        change, not per-tick).
        """
        if speed_ms is not None:
            self._speed = speed_ms
        if saturation is not None:
            self._saturation = saturation
        if value is not None:
            self._value = value
        if fixed_hue is not None:
            self._hue = fixed_hue % 1.0
            self._hue_step = 0.0
        elif hue_step is not None:
            self._hue_step = hue_step

        rebuild = False
        valid_styles = ("solid", "line", "mist", "glass", "pulse")
        if style is not None and style in valid_styles and style != self._style:
            self._style = style
            rebuild = True
        if opacity is not None and opacity != self._opacity:
            self._opacity = max(0.0, min(1.0, opacity))
            if self._style != "solid":
                rebuild = True
        if rebuild:
            new_thickness = self._thickness_for_style(self._style, DEFAULT_HEIGHT)
            dim = "width" if self._orientation == "vertical" else "height"
            if int(self.cget(dim)) != new_thickness:
                self.configure(**{dim: new_thickness})
            w = self.winfo_width()
            h = self.winfo_height()
            if w > 1 and h > 1:
                self._on_resize(types.SimpleNamespace(width=w, height=h))

    # -- focus handling ---------------------------------------------------
    def _on_focus_out(self, _event=None):
        self.stop()

    def _on_focus_in(self, _event=None):
        self.start()


class CornerGlow(tk.Canvas):
    """Small hue-cycling glow blob pinned to one corner of the window
    via place(). Drawn as a handful of concentric arcs (cheapest way to
    fake a soft glow on a plain Canvas — no PhotoImage/PIL involved) so
    a full redraw per tick is still just a few `itemconfig` calls.

    `corner` is one of CORNERS ("top_left", "top_right", "bottom_left",
    "bottom_right"). Placement is anchored to the true window corner
    (relx/rely 0 or 1) with a small pixel size, so it never overlaps
    TopBar/status-bar controls, which sit further in."""

    def __init__(self, parent, corner="top_left", size=DEFAULT_CORNER_SIZE,
                 rings=DEFAULT_CORNER_RINGS, speed_ms=DEFAULT_SPEED_MS,
                 hue_step=DEFAULT_HUE_STEP, saturation=DEFAULT_SATURATION,
                 value=DEFAULT_VALUE, enabled=True, hue_offset=0.0, **kw):
        if corner not in CORNERS:
            raise ValueError(f"corner must be one of {CORNERS}, got {corner!r}")
        kw.setdefault("highlightthickness", 0)
        kw.setdefault("bd", 0)
        parent_bg = kw.pop("bg", None)
        super().__init__(parent, width=size, height=size,
                          bg=parent_bg if parent_bg else parent.cget("bg"), **kw)

        self._corner = corner
        self._size = size
        self._rings = max(2, rings)
        self._hue = hue_offset % 1.0
        self._speed = speed_ms
        self._hue_step = hue_step
        self._saturation = saturation
        self._value = value
        self._job = None
        self._enabled = enabled
        self._items = []

        self._build_rings()
        self._place_in_corner()

        toplevel = self.winfo_toplevel()
        self._toplevel = toplevel
        self._bind_ids = [
            ("<FocusOut>", toplevel.bind("<FocusOut>", self._on_focus_out, add="+")),
            ("<FocusIn>", toplevel.bind("<FocusIn>", self._on_focus_in, add="+")),
            ("<Unmap>", toplevel.bind("<Unmap>", self._on_focus_out, add="+")),
            ("<Map>", toplevel.bind("<Map>", self._on_focus_in, add="+")),
        ]

    # -- layout ---------------------------------------------------------
    def _corner_origin(self):
        """(cx, cy) the glow radiates from — the actual window corner
        point, so it reads as light bleeding in from that corner."""
        s = self._size
        return {
            "top_left": (0, 0),
            "top_right": (s, 0),
            "bottom_left": (0, s),
            "bottom_right": (s, s),
        }[self._corner]

    def _build_rings(self):
        cx, cy = self._corner_origin()
        # Largest ring first (drawn behind), shrinking inward, each a
        # quarter-circle-ish oval clipped by the canvas edges — cheap
        # stand-in for a radial gradient without any image generation.
        for i in range(self._rings, 0, -1):
            r = self._size * (i / self._rings)
            item = self.create_oval(cx - r, cy - r, cx + r, cy + r, width=0)
            self._items.append(item)

    def _place_in_corner(self):
        relx, x_sign = (0.0, 1) if "left" in self._corner else (1.0, -1)
        rely, y_sign = (0.0, 1) if "top" in self._corner else (1.0, -1)
        # Tiny inset (2px) so it doesn't sit flush against the OS window
        # border where it could visually clash with resize cursors.
        self.place(relx=relx, rely=rely,
                   x=2 * x_sign - (0 if x_sign > 0 else self._size),
                   y=2 * y_sign - (0 if y_sign > 0 else self._size))
        # Canvas overrides both .lift() and .tkraise() with tag_raise()
        # (for raising canvas *items* by tag/id, not the widget itself) -
        # calling either here would misfire into that item-stacking Tcl
        # command instead of the widget-stacking one. Call the base
        # Misc.lift implementation directly to bypass Canvas's override
        # and actually raise this widget above its siblings.
        tk.Misc.lift(self)

    # -- animation --------------------------------------------------------
    def _tick(self):
        try:
            if not self.winfo_exists() or not self._enabled:
                self._job = None
                return
        except tk.TclError:
            self._job = None
            return
        n = len(self._items)
        for i, item in enumerate(self._items):
            # Outer rings get a slightly lower value so the glow reads as
            # fading outward rather than a flat-colored disc.
            fade = 0.35 + 0.65 * ((i + 1) / n)
            self.itemconfig(item, fill=_hue_to_hex(self._hue, self._saturation,
                                                    self._value * fade))
        self._hue = (self._hue + self._hue_step) % 1.0
        try:
            self._job = self.after(self._speed, self._tick)
        except tk.TclError:
            self._job = None

    def start(self):
        if not self._enabled:
            return
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self._job is None:
            self._tick()

    def stop(self):
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None

    def destroy(self):
        self.stop()
        try:
            for sequence, bind_id in getattr(self, "_bind_ids", []):
                if bind_id:
                    self._toplevel.unbind(sequence, bind_id)
        except Exception:
            pass
        self._bind_ids = []
        super().destroy()

    def set_enabled(self, enabled):
        self._enabled = enabled
        if enabled:
            self.start()
        else:
            self.stop()

    def configure_animation(self, speed_ms=None, hue_step=None,
                             saturation=None, value=None, fixed_hue=None):
        """Same knobs as RGBAccentBar.configure_animation() — see there."""
        if speed_ms is not None:
            self._speed = speed_ms
        if saturation is not None:
            self._saturation = saturation
        if value is not None:
            self._value = value
        if fixed_hue is not None:
            self._hue = fixed_hue % 1.0
            self._hue_step = 0.0
        elif hue_step is not None:
            self._hue_step = hue_step

    def _on_focus_out(self, _event=None):
        self.stop()

    def _on_focus_in(self, _event=None):
        self.start()
