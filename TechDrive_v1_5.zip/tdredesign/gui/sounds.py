"""Theme-aware TechDrive UI sounds.

Built-in XP, Vista/7, and Dark sound sets can be selected independently or
automatically matched to the app's XP/Aero appearance settings. Custom WAV
files remain per-event overrides and are copied into the user's data folder.
"""
from pathlib import Path
import os
import platform
import shutil
import wave

from shared import database as db

_BASE = Path(__file__).resolve().parent / "assets" / "sounds"
_DARK_FILES = {
    "startup": "TechDrive_Startup_Improved.wav",
    "shutdown": "TechDrive_Shutdown_Improved.wav",
    "error": "TechDrive_Error_Improved.wav",
    "click": "dark_click.wav",
    "notification": "dark_notification.wav",
    "scan_complete": "dark_scan_complete.wav",
    "achievement": "dark_scan_complete.wav",
}
_SCHEME_FILES = {
    "dark": _DARK_FILES,
    "vista7": {
        event: f"vista7_{event}.wav"
        for event in ("startup", "shutdown", "error", "click", "notification",
                      "scan_complete", "achievement")
    },
    "xp": {
        event: f"xp_{event}.wav"
        for event in ("startup", "shutdown", "error", "click", "notification",
                      "scan_complete", "achievement")
    },
}
_SCHEME_FILES["vista7"]["achievement"] = "vista7_scan_complete.wav"
_SCHEME_FILES["xp"]["achievement"] = "xp_scan_complete.wav"
_LABELS = {
    "startup": "Startup",
    "shutdown": "Shutdown",
    "error": "Error",
    "click": "Click",
    "notification": "Notification",
    "scan_complete": "Scan-complete",
    "achievement": "Achievement",
}
SCHEME_LABELS = {
    "auto": "Follow visual theme",
    "xp": "Windows XP",
    "vista7": "Vista / 7",
    "dark": "TechDrive Dark",
}


def _user_sound_dir():
    """Return a persistent per-user sound directory."""
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
    path = Path(base) / "TechDrive" / "sounds"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _default_path(name):
    scheme = get_active_scheme()
    filename = _SCHEME_FILES.get(scheme, {}).get(name)
    path = _BASE / filename if filename else None
    if path is not None and path.is_file():
        return path
    # Keep the pre-existing built-in cues available if an optional generated
    # sound file is missing from an older or manually copied installation.
    fallback = _SCHEME_FILES["dark"].get(name)
    return _BASE / fallback if fallback else None


def _custom_path(name):
    value = db.get_setting(f"custom_sound_{name}", "")
    if not value:
        return None
    path = Path(value).expanduser()
    return path if path.is_file() else None


def is_enabled():
    return bool(db.get_setting("ui_sounds_enabled", False))


def get_path(name):
    """Return the active sound path, preferring the user's custom WAV."""
    custom = _custom_path(name)
    if custom is not None:
        return custom
    return _default_path(name)


def get_display_path(name):
    custom = _custom_path(name)
    if custom is not None:
        return str(custom)
    default = _default_path(name)
    return str(default) if default else ""


def has_custom(name):
    return _custom_path(name) is not None


def set_enabled(enabled):
    db.set_setting("ui_sounds_enabled", bool(enabled))


def set_custom(name, source_path):
    """Copy a user-selected WAV into TechDrive's persistent sound folder."""
    if name not in _LABELS:
        raise ValueError("Unknown sound event")
    source = Path(source_path).expanduser()
    if not source.is_file():
        raise FileNotFoundError(str(source))
    if source.suffix.lower() != ".wav":
        raise ValueError("TechDrive custom sounds must be WAV files.")
    try:
        with wave.open(str(source), "rb") as wav:
            if wav.getnchannels() < 1 or wav.getsampwidth() < 1 or wav.getframerate() < 1:
                raise ValueError("The selected WAV file is not valid audio.")
    except (wave.Error, EOFError, OSError) as exc:
        raise ValueError("The selected file is not a valid WAV audio file.") from exc

    dest = _user_sound_dir() / f"custom_{name}.wav"
    shutil.copy2(source, dest)
    db.set_setting(f"custom_sound_{name}", str(dest))
    return dest


def reset_custom(name):
    """Remove a custom sound and return to the bundled TechDrive sound."""
    if name not in _LABELS:
        raise ValueError("Unknown sound event")
    value = db.get_setting(f"custom_sound_{name}", "")
    if value:
        try:
            path = Path(value).expanduser()
            if path.is_file() and path.parent == _user_sound_dir():
                path.unlink()
        except Exception:
            pass
    db.set_setting(f"custom_sound_{name}", "")


def _play(path):
    if platform.system() != "Windows":
        return False
    try:
        import winsound
        if not path or not path.is_file():
            return False
        winsound.PlaySound(
            str(path),
            winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT,
        )
        return True
    except Exception:
        return False


def get_scheme_mode():
    """Return the user's sound-scheme setting, defaulting to visual matching."""
    mode = db.get_setting("sound_scheme_mode", "auto")
    return mode if mode in SCHEME_LABELS else "auto"


def set_scheme_mode(mode):
    if mode not in SCHEME_LABELS:
        raise ValueError("Unknown TechDrive sound scheme.")
    db.set_setting("sound_scheme_mode", mode)


def get_active_scheme():
    """Resolve the active scheme; auto follows XP first, then Aero, then Dark."""
    mode = get_scheme_mode()
    if mode != "auto":
        return mode
    if db.get_setting("xp_theme_enabled", False):
        return "xp"
    if db.get_setting("aero_glass_enabled", False):
        return "vista7"
    return "dark"


def get_active_scheme_label():
    return SCHEME_LABELS[get_active_scheme()]


def get_event_label(name):
    return _LABELS.get(name, name.replace("_", " ").title())


def play(name, force=False):
    """Play a TechDrive event sound without ever raising into the app.

    ``force=True`` is used by Settings' Test buttons and intentionally plays
    even when the global UI-sound switch is disabled.
    """
    if name not in _LABELS or (not force and not is_enabled()):
        return False
    return _play(get_path(name))
