#!/usr/bin/env python3
"""Mission Control — Exposé-style overview of open notebook tabs."""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.widgets import round_rect
from gui.motion import tween, spring


class MissionControl(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.theme = app.theme
        self.overrideredirect(True)
        self.configure(bg="#000000")
        try:
            self.attributes("-topmost", True)
            self.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self._sync()
        self.bind("<Escape>", lambda e: self._close())
        self.bind("<Button-1>", lambda e: self._close())
        app.bind("<Configure>", self._on_cfg, add="+")
        self._build()
        self.after(15, self._fade_in)

    def _on_cfg(self, _e=None):
        try:
            if self.winfo_exists():
                self._sync()
        except tk.TclError:
            pass

    def _sync(self):
        try:
            self.app.update_idletasks()
            x, y = self.app.winfo_rootx(), self.app.winfo_rooty()
            w = max(self.app.winfo_width(), 400)
            h = max(self.app.winfo_height(), 300)
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

    def _fade_in(self):
        for i, a in enumerate((0.2, 0.35, 0.5)):
            self.after(i * 25, lambda a=a: self._alpha(a))

    def _alpha(self, a):
        try:
            self.attributes("-alpha", a)
        except tk.TclError:
            pass

    def _close(self):
        try:
            self.destroy()
        except Exception:
            pass

    def _build(self):
        th = self.theme
        host = tk.Frame(self, bg="#0a0a0a")
        host.place(relx=0.05, rely=0.08, relwidth=0.9, relheight=0.84)
        host.bind("<Button-1>", lambda e: "break")

        tk.Label(
            host, text="MISSION CONTROL", bg=host["bg"], fg=th["MUTED"],
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=8, pady=(0, 10))

        grid = tk.Frame(host, bg=host["bg"])
        grid.pack(fill="both", expand=True)

        tabs = []
        try:
            nb = self.app.notebook
            for tab_id in nb.tabs():
                title = nb.tab(tab_id, "text")
                display = nb._display_title(title) if hasattr(nb, "_display_title") else title
                tabs.append((tab_id, display))
        except Exception:
            tabs = []

        if not tabs:
            tk.Label(grid, text="No open tabs", bg=host["bg"], fg=th["MUTED"]).pack()
            return

        cols = min(4, max(2, len(tabs)))
        for i, (tab_id, title) in enumerate(tabs):
            r, c = divmod(i, cols)
            card = tk.Frame(
                grid, bg=th.get("CARD_BG", "#1c1c1e"),
                highlightthickness=1,
                highlightbackground=th.get("STROKE", "#333"),
                cursor="hand2", width=180, height=110,
            )
            card.grid(row=r, column=c, padx=8, pady=8, sticky="nsew")
            card.pack_propagate(False)
            grid.columnconfigure(c, weight=1)
            grid.rowconfigure(r, weight=1)

            cv = tk.Canvas(card, bg=th.get("LAYER_2", th["CARD_BG"]),
                           highlightthickness=0, height=64)
            cv.pack(fill="x", padx=6, pady=(6, 0))
            # fake thumbnail chrome
            round_rect(cv, 4, 4, 170, 56, r=8, fill=th.get("LAYER_1", "#222"), outline="")
            cv.create_text(20, 30, text="▣", fill=th.get("ACCENT", "#0a84ff"), font=("Segoe UI", 16))

            tk.Label(
                card, text=title[:28], bg=card["bg"], fg=th["FG"],
                font=("Segoe UI", 10, "bold"),
            ).pack(anchor="w", padx=8, pady=6)

            def select(_e=None, tid=tab_id):
                try:
                    self.app.notebook.select(tid)
                except Exception:
                    pass
                self._close()

            card.bind("<Button-1>", select)
            for ch in card.winfo_children():
                ch.bind("<Button-1>", select)

        tk.Label(
            host, text="Click a tab · Esc to dismiss",
            bg=host["bg"], fg=th["MUTED"], font=("Segoe UI", 9),
        ).pack(pady=(8, 0))


def open_mission_control(app):
    return MissionControl(app)
