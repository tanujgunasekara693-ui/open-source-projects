#!/usr/bin/env python3
"""Continue where you left off — persist light tool session state."""

from __future__ import annotations

import json
import time

from shared import database as db

_KEY = "tool_resume_state"


def _load_all():
    try:
        raw = db.get_setting(_KEY, "{}") or "{}"
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_all(data):
    try:
        db.set_setting(_KEY, json.dumps(data)[:200000])
    except Exception:
        pass


def save_state(category, tool_name, state: dict):
    """Save a small JSON-serializable state blob for a tool."""
    if not category or not tool_name or not isinstance(state, dict):
        return
    all_state = _load_all()
    key = f"{category}::{tool_name}"
    all_state[key] = {
        "category": category,
        "tool": tool_name,
        "state": state,
        "updated_at": time.time(),
    }
    # Keep last 40 tools only
    if len(all_state) > 40:
        items = sorted(all_state.items(), key=lambda kv: kv[1].get("updated_at", 0), reverse=True)
        all_state = dict(items[:40])
    _save_all(all_state)


def load_state(category, tool_name):
    all_state = _load_all()
    key = f"{category}::{tool_name}"
    entry = all_state.get(key)
    if not entry:
        return None
    return entry.get("state")


def last_sessions(limit=8):
    """Return recent sessions newest-first: list of {category, tool, state, updated_at}."""
    all_state = _load_all()
    items = sorted(all_state.values(), key=lambda e: e.get("updated_at", 0), reverse=True)
    return items[:limit]


def clear_state(category=None, tool_name=None):
    if category is None:
        _save_all({})
        return
    all_state = _load_all()
    key = f"{category}::{tool_name}"
    all_state.pop(key, None)
    _save_all(all_state)
