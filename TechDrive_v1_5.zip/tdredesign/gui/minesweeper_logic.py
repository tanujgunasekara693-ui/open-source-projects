"""Small, UI-independent Minesweeper rules for the Vault mini-game."""

import random


class MinesweeperBoard:
    """Minesweeper board with a safe first click and zero-cell expansion."""

    def __init__(self, rows=9, columns=9, mine_count=10, rng=None):
        if rows < 2 or columns < 2:
            raise ValueError("A Minesweeper board must be at least 2 by 2.")
        if mine_count < 1 or mine_count >= rows * columns - 1:
            raise ValueError("The mine count must leave at least one safe cell.")
        self.rows = rows
        self.columns = columns
        self.mine_count = mine_count
        self._rng = rng or random.SystemRandom()
        self.reset()

    def reset(self):
        self.mines = set()
        self.revealed = set()
        self.flagged = set()
        self.first_click = True
        self.game_over = False
        self.won = False

    def _in_bounds(self, row, column):
        return 0 <= row < self.rows and 0 <= column < self.columns

    def _neighbors(self, row, column):
        for r in range(max(0, row - 1), min(self.rows, row + 2)):
            for c in range(max(0, column - 1), min(self.columns, column + 2)):
                if (r, c) != (row, column):
                    yield r, c

    def _place_mines(self, safe_row, safe_column):
        protected = {(safe_row, safe_column), *self._neighbors(safe_row, safe_column)}
        candidates = [
            (row, column)
            for row in range(self.rows)
            for column in range(self.columns)
            if (row, column) not in protected
        ]
        if len(candidates) < self.mine_count:
            protected = {(safe_row, safe_column)}
            candidates = [
                (row, column)
                for row in range(self.rows)
                for column in range(self.columns)
                if (row, column) not in protected
            ]
        self.mines = set(self._rng.sample(candidates, self.mine_count))
        self.first_click = False

    def neighboring_mines(self, row, column):
        return sum(cell in self.mines for cell in self._neighbors(row, column))

    def toggle_flag(self, row, column):
        cell = (row, column)
        if (
            self.game_over
            or not self._in_bounds(row, column)
            or cell in self.revealed
        ):
            return False
        if cell in self.flagged:
            self.flagged.remove(cell)
        else:
            self.flagged.add(cell)
        return True

    def reveal(self, row, column):
        cell = (row, column)
        if (
            self.game_over
            or not self._in_bounds(row, column)
            or cell in self.flagged
            or cell in self.revealed
        ):
            return "ignored"

        if self.first_click:
            self._place_mines(row, column)
        if cell in self.mines:
            self.game_over = True
            self.won = False
            return "mine"

        self._reveal_region(row, column)
        if len(self.revealed) == self.rows * self.columns - self.mine_count:
            self.game_over = True
            self.won = True
            return "won"
        return "revealed"

    def _reveal_region(self, row, column):
        pending = [(row, column)]
        while pending:
            cell = pending.pop()
            if cell in self.revealed or cell in self.flagged or cell in self.mines:
                continue
            self.revealed.add(cell)
            if self.neighboring_mines(*cell) == 0:
                pending.extend(self._neighbors(*cell))