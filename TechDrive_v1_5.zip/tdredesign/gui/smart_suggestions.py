#!/usr/bin/env python3
"""Smart Suggestions — dashboard strip with actionable tips."""

from __future__ import annotations

import time
import tkinter as tk

from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton, round_rect
from shared import database as db

try:
    import psutil
except ImportError:
    psutil = None


def collect_suggestions(app, limit=5):
    """Return list of dicts: {id, title, body, action_label, action, kind}."""
    out = []
    now = time.time()

    # 1) Recent tools empty → suggest explore
    try:
        recent = list(db.get_recent(3) or [])
    except Exception:
        recent = []
    if not recent:
        out.append({
            "id": "explore_tools",
            "title": "Explore tools",
            "body": "Open All Tools to find diagnostics and repair utilities.",
            "action_label": "All Tools",
            "action": lambda: getattr(app, "open_all_tools_tab", lambda: None)(),
            "kind": "info",
        })

    # 2) Disk / memory pressure
    if psutil:
        try:
            mem = psutil.virtual_memory()
            if mem.percent >= 85:
                out.append({
                    "id": "high_ram",
                    "title": f"Memory at {mem.percent:.0f}%",
                    "body": "High RAM use can slow repairs and scans.",
                    "action_label": "Performance",
                    "action": lambda: getattr(app, "open_performance_lab_tab", None)
                                      and app.open_performance_lab_tab()
                                      or app.open_tool("Performance", "Live Performance Monitor")
                                      if hasattr(app, "open_tool") else None,
                    "kind": "warn",
                })
        except Exception:
            pass
        try:
            for part in psutil.disk_partitions(all=False):
                if "cdrom" in part.opts or not part.fstype:
                    continue
                try:
                    u = psutil.disk_usage(part.mountpoint)
                except Exception:
                    continue
                if u.percent >= 90:
                    out.append({
                        "id": f"disk_{part.mountpoint}",
                        "title": f"Disk {part.mountpoint} is {u.percent:.0f}% full",
                        "body": "Low free space can break updates and repairs.",
                        "action_label": "Disk Tools",
                        "action": lambda: app.open_tool("Disk", "Disk Health")
                                          if hasattr(app, "open_tool") else None,
                        "kind": "warn",
                    })
                    break
        except Exception:
            pass
        try:
            cpu = psutil.cpu_percent(interval=None)
            if cpu >= 90:
                out.append({
                    "id": "high_cpu",
                    "title": f"CPU at {cpu:.0f}%",
                    "body": "Something is loading the CPU heavily right now.",
                    "action_label": "Live Monitor",
                    "action": lambda: app.open_tool("Performance", "Live Performance Monitor")
                                      if hasattr(app, "open_tool") else None,
                    "kind": "warn",
                })
        except Exception:
            pass

    # 3) Last health / diagnostic age
    try:
        last = db.get_setting("last_health_scan_at")
        if last:
            age_days = (now - float(last)) / 86400.0
            if age_days >= 14:
                out.append({
                    "id": "stale_health",
                    "title": "Health scan is outdated",
                    "body": f"Last scan was about {int(age_days)} days ago.",
                    "action_label": "Health Center",
                    "action": lambda: getattr(app, "open_health_center_tab",
                                              getattr(app, "show_dashboard", lambda: None))(),
                    "kind": "info",
                })
        else:
            out.append({
                "id": "never_health",
                "title": "Run a system health check",
                "body": "No recent Health Center scan on record.",
                "action_label": "Open Health",
                "action": lambda: getattr(app, "open_health_center_tab",
                                          getattr(app, "show_dashboard", lambda: None))(),
                "kind": "info",
            })
    except Exception:
        pass

    # 4) Focus mode tip
    try:
        from gui.focus_modes import get_mode
        mid, cfg = get_mode()
        if mid == "default":
            out.append({
                "id": "genius_tip",
                "title": "Offline Genius tips",
                "body": "Plain-language advice for CPU, disk, and SMART warnings.",
                "action_label": "Show tip",
                "action": lambda: getattr(app, "show_genius_tip", lambda: None)("default"),
                "kind": "info",
            })
            out.append({
                "id": "try_focus",
                "title": "Try Focus modes",
                "body": "Repair, Gaming, or Quiet — one tap in Control Center.",
                "action_label": "Controls",
                "action": lambda: getattr(app, "control_center", None) and app.control_center.show(),
                "kind": "info",
            })
    except Exception:
        pass

    # 5) OLED suggestion for dark sessions
    try:
        if getattr(app, "theme_id", "") == "dark":
            out.append({
                "id": "try_oled",
                "title": "OLED Pure Black available",
                "body": "True black theme for AMOLED and lower power draw.",
                "action_label": "Switch",
                "action": lambda: app.apply_theme_choice("oled")
                                  if hasattr(app, "apply_theme_choice") else None,
                "kind": "info",
            })
    except Exception:
        pass

    # Deduplicate by id, limit
    seen = set()
    final = []
    for s in out:
        if s["id"] in seen:
            continue
        seen.add(s["id"])
        final.append(s)
        if len(final) >= limit:
            break
    return final


class SuggestionsStrip(tk.Frame):
    """Horizontal strip of suggestion cards for the dashboard."""

    def __init__(self, parent, app, theme, aero=False):
        super().__init__(parent, bg=theme["BG"])
        self.app = app
        self.theme = theme
        self.aero = aero
        self._cards = []
        self.refresh()

    def refresh(self):
        for w in self.winfo_children():
            w.destroy()
        self._cards.clear()
        th = self.theme
        suggestions = collect_suggestions(self.app, limit=4)
        if not suggestions:
            return

        header = tk.Frame(self, bg=th["BG"])
        header.pack(fill="x", pady=(0, 6))
        tk.Label(
            header, text="SUGGESTIONS", bg=th["BG"], fg=th["MUTED"],
            font=fl.F_CAPTION() if hasattr(fl, "F_CAPTION") else ("Segoe UI", 9),
            anchor="w",
        ).pack(side="left")
        tk.Label(
            header, text="Refresh", bg=th["BG"], fg=th["ACCENT"],
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(side="right")
        header.winfo_children()[-1].bind("<Button-1>", lambda e: self.refresh())

        row = tk.Frame(self, bg=th["BG"])
        row.pack(fill="x")
        for i, s in enumerate(suggestions):
            row.columnconfigure(i, weight=1, uniform="sug")
            self._make_card(row, s, i)

    def _make_card(self, parent, s, col):
        th = self.theme
        kind = s.get("kind", "info")
        accent = th["ACCENT"]
        if kind == "warn":
            accent = getattr(fl, "WARN", "#ffd60a")
        elif kind == "bad":
            accent = getattr(fl, "BAD", "#ff453a")

        card = GlassCard(parent, th, aero=self.aero, backdrop=th["BG"],
                         accent=accent, padding=12)
        card.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 6, 0))
        body = card.body
        body.configure(bg=card.fill)

        title_lbl = tk.Label(
            body, text=s["title"], bg=card.fill, fg=th["FG"],
            font=fl.F_CARD_TITLE() if hasattr(fl, "F_CARD_TITLE") else ("Segoe UI", 11, "bold"),
            anchor="w", wraplength=200, justify="left",
        )
        title_lbl.pack(fill="x")
        body_lbl = tk.Label(
            body, text=s.get("body", ""), bg=card.fill, fg=th["MUTED"],
            font=fl.F_SMALL() if hasattr(fl, "F_SMALL") else ("Segoe UI", 9),
            anchor="w", wraplength=200, justify="left",
        )
        body_lbl.pack(fill="x", pady=(4, 8))

        def _rewrap(event, labels=(title_lbl, body_lbl)):
            # Wrap to the card's real width (was a fixed 200px, wider than
            # the cards, so the right edge of every line was cut off).
            for lbl in labels:
                lbl.config(wraplength=max(60, event.width - 4))
            card._schedule_autofit()

        body.bind("<Configure>", _rewrap)
        card.enable_autofit()

        def run(_s=s):
            try:
                act = _s.get("action")
                if callable(act):
                    act()
            except Exception:
                pass

        FluentButton(
            body, s.get("action_label") or "Open", command=run, theme=th, aero=self.aero,
            kind="subtle", height=28, backdrop=card.fill,
            font_=("Segoe UI", 9, "bold"),
        ).pack(anchor="w")
        self._cards.append(card)
        try:
            card.play_entrance(delay=len(self._cards) * 40, duration=300)
        except Exception:
            pass


def _s_label(s):
    return s.get("action_label") or "Open"
