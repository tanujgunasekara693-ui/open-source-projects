"""TechDrive Core module browser.

First-party bundled modules are presented as Core Modules rather than as a
plugin marketplace. The page consumes PLUGIN_REGISTRY metadata only; actual
tool implementations and dispatch remain in techdrive.py/modules.
"""
import tkinter as tk
from gui import fluent as fl
from gui.icons import module_icon

class CoreModulesPage(tk.Frame):
    def __init__(self, parent, app, registry, on_open_module):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.registry = registry
        self.on_open_module = on_open_module
        self._cache = {}
        self._query = ""
        self._cards = []
        self._build()

    def _build(self):
        th=self.theme
        header=tk.Frame(self,bg=th["BG"]); header.pack(fill="x",padx=20,pady=(18,8))
        tk.Label(header,text="TECHDRIVE CORE",bg=th["BG"],fg=th["ACCENT_GLOW"],font=fl.font(9,"bold")).pack(anchor="w")
        row=tk.Frame(header,bg=th["BG"]); row.pack(fill="x",pady=(3,0))
        tk.Label(row,text="Built-in Modules",bg=th["BG"],fg=th["FG"],font=fl.F_TITLE()).pack(side="left")
        tool_count=sum(v.get("tool_count",0) for v in self.registry.values())
        tk.Label(row,text=f"  {len(self.registry)} modules  •  {tool_count} tools",bg=th["BG"],fg=th["MUTED"],font=fl.F_SMALL()).pack(side="left",pady=(6,0))
        search=tk.Frame(self,bg=fl.glass(th,"CARD_BG",self.app.is_aero_enabled()),highlightbackground=th["STROKE"],highlightthickness=1); search.pack(fill="x",padx=20,pady=(0,12))
        tk.Label(search,text="⌕",bg=search["bg"],fg=th["ACCENT"],font=fl.font(15)).pack(side="left",padx=(10,5))
        self.var=tk.StringVar(); ent=tk.Entry(search,textvariable=self.var,bg=search["bg"],fg=th["FG"],insertbackground=th["FG"],relief="flat",bd=0,font=fl.F_BODY()); ent.pack(side="left",fill="x",expand=True,ipady=7); ent.bind("<Escape>",lambda e:self.var.set("")); self.var.trace_add("write",lambda *_:self._render())
        holder=tk.Frame(self,bg=th["BG"]); holder.pack(fill="both",expand=True,padx=20,pady=(0,12))
        canvas=tk.Canvas(holder,bg=th["BG"],highlightthickness=0,bd=0); sb=tk.Scrollbar(holder,orient="vertical",command=canvas.yview); canvas.configure(yscrollcommand=sb.set); canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        self.body=tk.Frame(canvas,bg=th["BG"]); win=canvas.create_window((0,0),window=self.body,anchor="nw"); self._canvas=canvas
        self.body.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all"))); canvas.bind("<Configure>",lambda e:canvas.itemconfigure(win,width=e.width))
        self._render()

    def _render(self):
        for c in self.body.winfo_children(): c.destroy()
        q=self.var.get().strip().lower() if hasattr(self,"var") else ""
        rows=[]
        for mod,info in sorted(self.registry.items(),key=lambda x:x[1].get("name",x[0]).lower()):
            name=info.get("name") or mod.replace("_"," ").title()
            hay=" ".join([mod,name," ".join(info.get("categories",[]))]).lower()
            if q and q not in hay: continue
            rows.append((mod,info))
        self._cards=[]
        cols=3
        for i,(mod,info) in enumerate(rows):
            card=self._card(self.body,mod,info); card.grid(row=i//cols,column=i%cols,sticky="nsew",padx=6,pady=6)
        for c in range(cols): self.body.grid_columnconfigure(c,weight=1)

    def _card(self,parent,mod,info):
        th=self.theme; bg=fl.glass(th,"CARD_BG",self.app.is_aero_enabled())
        card=tk.Frame(parent,bg=bg,highlightbackground=th["STROKE"],highlightthickness=1,width=260,height=145); card.grid_propagate(False)
        # Some bundled support modules legitimately have no catalogue
        # categories. Never let an empty category list crash the Core page.
        categories = info.get("categories") or []
        icon_key = categories[0] if categories else (info.get("name") or mod)
        icon=module_icon(icon_key,40)
        if icon:
            img=tk.PhotoImage(master=card,file=str(icon)); self._cache[str(icon)]=img
            tk.Label(card,image=img,bg=bg).pack(side="left",padx=(12,8),pady=12)
        else:
            tk.Label(card,text="◈",bg=bg,fg=th["ACCENT"],font=fl.font(24)).pack(side="left",padx=(12,8))
        col=tk.Frame(card,bg=bg); col.pack(side="left",fill="both",expand=True,padx=(0,10),pady=12)
        name=info.get("name") or mod.replace("_"," ").title()
        tk.Label(col,text=name,bg=bg,fg=th["FG"],font=fl.F_CARD_TITLE(),anchor="w",wraplength=150,justify="left").pack(fill="x")
        cats=", ".join(info.get("categories",[])) or "Bundled support module"
        tk.Label(col,text=f"{info.get('tool_count',0)} tools",bg=bg,fg=th["ACCENT_GLOW"],font=fl.F_TINY()).pack(anchor="w",pady=(3,0))
        tk.Label(col,text=cats,bg=bg,fg=th["MUTED"],font=fl.F_TINY(),wraplength=150,justify="left").pack(anchor="w",pady=(2,6))
        tk.Button(col,text="OPEN MODULE",command=lambda m=mod:self.on_open_module(m),bg=fl.mix(bg,th["ACCENT"],.18),fg=th["FG"],relief="flat",bd=0,padx=7,pady=3).pack(anchor="w")
        return card
