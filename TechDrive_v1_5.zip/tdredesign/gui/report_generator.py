#!/usr/bin/env python3
"""TechDrive Core professional report generator page."""

import os
import tkinter as tk
from gui.tk_dialogs import filedialog

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton
from shared import database as db
from shared import report_generator as reports


class ReportGeneratorPage(tk.Frame):
    """Generate one technician-ready bundle from real local evidence."""

    def __init__(self, parent, app):
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._running = False
        self._last_output = None
        super().__init__(parent, bg=self.theme["BG"])
        _canvas, self.content = make_scrollable(self, self.theme["BG"])
        self._build_shell()

    def _build_shell(self):
        root = self.content
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 8))
        tk.Label(header, text="TECHDRIVE CORE  /  REPORT GENERATOR",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        tk.Label(header, text="Professional Report Generator",
                 bg=self.theme["BG"], fg=self.theme["FG"],
                 font=fl.F_TITLE()).pack(anchor="w", pady=(4, 2))
        tk.Label(
            header,
            text="Create a technician-ready evidence bundle from the latest "
                 "completed diagnostics and a fresh sensor snapshot.",
            bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=780, justify="left",
        ).pack(anchor="w")

        health = db.get_health_history(limit=1)
        diagnostic = db.get_diagnostic_history(limit=1)
        source = GlassCard(root, self.theme, aero=self.aero,
                           accent=self.theme["ACCENT2"])
        source.pack(fill="x", padx=24, pady=(8, 14))
        tk.Label(source.body, text="REPORT INPUT", bg=source.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        health_text = (
            f"Latest Health Center scan: {health[0]['score']}/100"
            if health else "Latest Health Center scan: none completed"
        )
        diag_text = (
            f"Latest Diagnostic Engine session: {diagnostic[0]['title']}"
            if diagnostic else "Latest Diagnostic Engine session: none completed"
        )
        tk.Label(source.body, text=health_text, bg=source.fill,
                 fg=self.theme["FG"], font=fl.F_BODY()).pack(
                     anchor="w", padx=18, pady=(2, 0))
        tk.Label(source.body, text=diag_text, bg=source.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(
                     anchor="w", padx=18, pady=(2, 16))

        formats = GlassCard(root, self.theme, aero=self.aero,
                            accent=fl.GOOD)
        formats.pack(fill="x", padx=24, pady=(0, 14))
        tk.Label(formats.body, text="ONE ACTION  /  FIVE DELIVERABLES",
                 bg=formats.fill, fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w", padx=18, pady=(16, 3))
        tk.Label(formats.body, text="Generate Report Bundle", bg=formats.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(0, 3))
        tk.Label(
            formats.body,
            text="Choose an output folder. TechDrive will write HTML, PDF, "
                 "TXT, a complete JSON diagnostic bundle, and CSV sensor "
                 "history with the same timestamp.",
            bg=formats.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(),
            wraplength=760, justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 12))
        row = tk.Frame(formats.body, bg=formats.fill)
        row.pack(fill="x", padx=18, pady=(0, 16))
        self.generate_button = FluentButton(
            row, "GENERATE REPORT BUNDLE", command=self.start,
            theme=self.theme, aero=self.aero, kind="accent", icon="▤",
            width=245, height=44, backdrop=formats.fill,
        )
        self.generate_button.pack(side="left")
        self.status_var = tk.StringVar(
            value="No files generated in this session."
        )
        tk.Label(row, textvariable=self.status_var, bg=formats.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=480, justify="left").pack(side="left", padx=16)

        output = GlassCard(root, self.theme, aero=self.aero,
                           accent=self.theme["ACCENT"])
        output.pack(fill="x", padx=24, pady=(0, 14))
        tk.Label(output.body, text="OUTPUTS", bg=output.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        self.output_body = output.body
        self._render_outputs([])

    def _render_outputs(self, paths):
        for child in getattr(self, "_output_rows", []):
            child.destroy()
        self._output_rows = []
        if not paths:
            label = tk.Label(
                self.output_body,
                text="The generated files will appear here.",
                bg=self.output_body.cget("bg"), fg=self.theme["MUTED"],
                font=fl.F_SMALL(),
            )
            label.pack(anchor="w", padx=18, pady=(0, 16))
            self._output_rows.append(label)
            return
        for kind, path in paths.items():
            row = tk.Frame(self.output_body, bg=self.output_body.cget("bg"))
            row.pack(fill="x", padx=18, pady=(0, 7))
            tk.Label(row, text=kind.upper(), width=10, anchor="w",
                     bg=row.cget("bg"), fg=self.theme["ACCENT_GLOW"],
                     font=fl.F_TINY()).pack(side="left")
            tk.Label(row, text=os.path.basename(path), bg=row.cget("bg"),
                     fg=self.theme["TEXT_FG"], font=fl.F_SMALL(),
                     anchor="w").pack(side="left", fill="x", expand=True)
            self._output_rows.append(row)
        note = tk.Label(
            self.output_body,
            text=f"Saved to {os.path.dirname(next(iter(paths.values())))}",
            bg=self.output_body.cget("bg"), fg=self.theme["MUTED"],
            font=fl.F_TINY(), wraplength=760, justify="left",
        )
        note.pack(anchor="w", padx=18, pady=(2, 16))
        self._output_rows.append(note)

    def start(self):
        if self._running:
            return
        output_dir = filedialog.askdirectory(
            title="Choose a folder for the TechDrive report bundle"
        )
        if not output_dir:
            self.status_var.set("Report generation cancelled.")
            return
        self._running = True
        self.generate_button.configure(state="disabled")
        self.status_var.set("Collecting current sensors and writing five files…")
        self.app._run_bg(
            lambda: reports.write_report_bundle(output_dir),
            self._finish,
        )

    def _finish(self, result):
        self._running = False
        self.generate_button.configure(state="normal")
        if hasattr(result, "message"):
            self.status_var.set(f"Report generation failed: {result}")
            return
        self._last_output = result
        self._render_outputs(result)
        self.status_var.set(
            f"Generated {len(result)} files for technician review."
        )
        if hasattr(self.app, "notify"):
            folder = os.path.dirname(next(iter(result.values())))
            self.app.notify(
                "Report exported",
                f"Saved {len(result)} files to {folder}",
                kind="success", source="Report Generator",
            )


def offer_share(app, text="", file_path=None):
    """Convenience for report UIs to open the Share Sheet."""
    try:
        if hasattr(app, "share_report"):
            app.share_report(text=text, file_path=file_path)
            return
        from gui.share_sheet import show_share_sheet
        show_share_sheet(app, text=text, file_path=file_path)
    except Exception:
        pass
