"""
TechDrive Network Lab
=====================

One read-only surface for the network signals that are otherwise scattered
across Network Tools, Internet Tools, and the Troubleshooting Wizard.

The values shown here are always collected from the current machine.  A
failed or unavailable probe is rendered as such instead of being replaced
with a sample value.
"""

import datetime as _datetime
import re
import socket
import subprocess
import time
import urllib.request
import tkinter as tk

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard, FluentButton
from shared import database as db

try:
    import psutil
except ImportError:  # pragma: no cover - optional runtime dependency
    psutil = None


IS_WINDOWS = __import__("platform").system() == "Windows"


def _run(argv, timeout=8):
    try:
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        return result.returncode, ((result.stdout or "") + (result.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        return 124, "Operation timed out."
    except FileNotFoundError:
        return 127, f"{argv[0]} is not available on this PC."
    except Exception as exc:
        return 1, f"{type(exc).__name__}: {exc}"


def _format_latency(value):
    if value is None:
        return "—"
    if value < 1:
        return "<1 ms"
    return f"{value:.0f} ms"


def _default_gateway():
    """Return the gateway reported by the local routing table."""
    if IS_WINDOWS:
        code, output = _run(["route", "print", "-4"])
        match = re.search(
            r"^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+"
            r"((?:\d{1,3}\.){3}\d{1,3})\s+",
            output,
            flags=re.MULTILINE,
        )
    else:
        code, output = _run(["ip", "route", "show", "default"])
        match = re.search(r"\bdefault\s+via\s+((?:\d{1,3}\.){3}\d{1,3})", output)
        if not match:
            # A small fallback for minimal Linux images without `ip`.
            try:
                with open("/proc/net/route", "r", encoding="utf-8") as route_file:
                    for line in route_file.readlines()[1:]:
                        parts = line.split()
                        if len(parts) >= 3 and parts[1] == "00000000":
                            raw = int(parts[2], 16)
                            gateway = socket.inet_ntoa(raw.to_bytes(4, "little"))
                            return gateway
            except (OSError, ValueError):
                pass
    return match.group(1) if match else None


def _ping(host):
    if not host:
        return {
            "ok": False,
            "latency_ms": None,
            "detail": "No default gateway was reported by the routing table.",
        }
    args = (
        ["ping", "-n", "1", "-w", "1500", host]
        if IS_WINDOWS
        else ["ping", "-c", "1", "-W", "2", host]
    )
    started = time.perf_counter()
    code, output = _run(args, timeout=5)
    elapsed_ms = (time.perf_counter() - started) * 1000
    match = re.search(r"time[=<]\s*([\d.]+)\s*ms", output, flags=re.IGNORECASE)
    latency = float(match.group(1)) if match else (elapsed_ms if code == 0 else None)
    return {
        "ok": code == 0,
        "latency_ms": latency,
        "detail": (
            f"Gateway {host} replied."
            if code == 0
            else f"Gateway {host} did not reply. {output.splitlines()[-1] if output else ''}".strip()
        ),
    }


def _dns_probe():
    started = time.perf_counter()
    try:
        addresses = socket.getaddrinfo("www.microsoft.com", 443, type=socket.SOCK_STREAM)
        latency = (time.perf_counter() - started) * 1000
        unique = sorted({item[4][0] for item in addresses if item[4]})
        return {
            "ok": bool(unique),
            "latency_ms": latency,
            "detail": f"Resolved www.microsoft.com ({len(unique)} address{'es' if len(unique) != 1 else ''}).",
        }
    except Exception as exc:
        return {
            "ok": False,
            "latency_ms": None,
            "detail": f"DNS resolution failed: {exc}",
        }


def _internet_probe():
    started = time.perf_counter()
    try:
        request = urllib.request.Request(
            "https://www.msftconnecttest.com/connecttest.txt",
            headers={"User-Agent": "TechDrive-Network-Lab/1.0"},
        )
        with urllib.request.urlopen(request, timeout=8) as response:
            response.read(128)
            latency = (time.perf_counter() - started) * 1000
            return {
                "ok": 200 <= response.status < 400,
                "latency_ms": latency,
                "detail": f"HTTPS reachability confirmed ({response.status}).",
            }
    except Exception as exc:
        return {
            "ok": False,
            "latency_ms": None,
            "detail": f"HTTPS reachability failed: {exc}",
        }


def _adapter_snapshot():
    if psutil is None:
        return [], {
            "ok": False,
            "latency_ms": None,
            "detail": "psutil is not installed; adapter state is unavailable.",
        }
    try:
        stats = psutil.net_if_stats()
        addresses = psutil.net_if_addrs()
        rows = []
        for name, stat in sorted(stats.items()):
            if name.lower() in {"lo", "loopback"}:
                continue
            ipv4 = next(
                (
                    item.address
                    for item in addresses.get(name, [])
                    if getattr(item, "family", None) == socket.AF_INET
                ),
                "—",
            )
            rows.append({
                "name": name,
                "up": bool(stat.isup),
                "speed": f"{stat.speed:g} Mbps" if stat.speed else "Unknown",
                "address": ipv4,
            })
        active = sum(1 for row in rows if row["up"])
        return rows, {
            "ok": active > 0,
            "latency_ms": None,
            "detail": f"{active} active adapter{'s' if active != 1 else ''} detected.",
        }
    except Exception as exc:
        return [], {
            "ok": False,
            "latency_ms": None,
            "detail": f"Adapter scan failed: {exc}",
        }


def run_network_lab():
    """Run the complete read-only Network Lab snapshot."""
    adapters, adapter_result = _adapter_snapshot()
    gateway = _default_gateway()
    gateway_result = _ping(gateway)
    dns_result = _dns_probe()
    internet_result = _internet_probe()

    checks = [
        dict(key="adapter", label="Adapters", **adapter_result),
        dict(key="gateway", label="Gateway", **gateway_result),
        dict(key="dns", label="DNS", **dns_result),
        dict(key="internet", label="Internet", **internet_result),
    ]
    passed = sum(1 for check in checks if check["ok"])
    status = (
        "ONLINE" if dns_result["ok"] and internet_result["ok"]
        else "LIMITED" if any(check["ok"] for check in checks)
        else "OFFLINE"
    )
    latencies = {
        check["key"]: check["latency_ms"]
        for check in checks
        if check["latency_ms"] is not None
    }
    timestamp = _datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    return {
        "timestamp": timestamp,
        "status": status,
        "score": round(passed / len(checks) * 100),
        "gateway": gateway,
        "checks": checks,
        "latencies": latencies,
        "adapters": adapters,
    }


class NetworkLabPage(tk.Frame):
    """Unified network status, probes, adapter view, and local history -
    laid out as a WorkspacePanel (Overview / Connections / Adapters /
    History tabs) instead of one long scroll, same pattern as the Disk
    Health workspace."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._running = False
        self._report = None
        self._build()

    def _build(self):
        from gui.workspace_panel import WorkspacePanel
        self.ws = WorkspacePanel(
            self, self.theme, aero=self.aero, icon="◎", title="Network Lab",
            subtitle="A single read-only view of connection health, gateway/DNS/"
                     "Internet latency, adapters, and repeatable diagnostics.",
            on_refresh=self.start_diagnostics,
        )
        self.overview_tab = self.ws.add_tab("Overview")
        self.connections_tab = self.ws.add_tab("Connections")
        self.adapters_tab = self.ws.add_tab("Adapters")
        self.history_tab = self.ws.add_tab("History")

        hero = GlassCard(self.overview_tab, self.theme, aero=self.aero, gradient=True,
                         accent=fl.GOOD)
        hero.pack(fill="x", padx=18, pady=(14, 14))
        self.hero_body = hero.body
        top = tk.Frame(hero.body, bg=hero.fill)
        top.pack(fill="x", padx=18, pady=(16, 4))
        left = tk.Frame(top, bg=hero.fill)
        left.pack(side="left", fill="x", expand=True)
        self.hero_status = tk.StringVar(value="READY")
        tk.Label(left, textvariable=self.hero_status, bg=hero.fill,
                 fg=fl.GOOD, font=fl.F_TITLE()).pack(anchor="w")
        self.hero_detail = tk.StringVar(
            value="Run diagnostics to measure this machine's current network path."
        )
        tk.Label(left, textvariable=self.hero_detail, bg=hero.fill,
                 fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=600, justify="left").pack(anchor="w", pady=(3, 0))
        self.run_button = FluentButton(
            top, "RUN DIAGNOSTICS", command=self.start_diagnostics,
            theme=self.theme, aero=self.aero, kind="accent", icon="▶",
            width=190, height=42, backdrop=hero.fill,
        )
        self.run_button.pack(side="right", padx=(16, 0))
        self.summary = tk.Frame(self.overview_tab, bg=self.theme["BG"])
        self.summary.pack(fill="x", padx=18, pady=(0, 14))
        self.detail = self.connections_tab

        latest = db.get_network_lab_history(limit=1)
        latest_report = latest[0].get("report") if latest else None
        if isinstance(latest_report, dict) and latest_report.get("checks"):
            self._report = latest_report
            self.hero_status.set(latest_report.get("status", "READY"))
            self.hero_detail.set(
                f"Last checked {latest_report.get('timestamp', 'unknown')} • "
                "run diagnostics again to refresh the snapshot."
            )
        self._render_summary(latest_report)
        self._render_detail(latest_report)

    def start_diagnostics(self):
        if self._running:
            return
        self._running = True
        self.run_button.configure(state="disabled")
        self.hero_status.set("RUNNING…")
        self.hero_detail.set("Testing adapters, gateway, DNS resolution, and HTTPS reachability.")
        self.app._run_bg(run_network_lab, self._finish_diagnostics)

    def _finish_diagnostics(self, report):
        self._running = False
        self.run_button.configure(state="normal")
        if hasattr(report, "message"):
            self.hero_status.set("FAILED SAFELY")
            self.hero_detail.set(str(report))
            return
        self._report = report
        try:
            db.add_network_lab_run(report)
        except Exception:
            pass
        self.hero_status.set(report["status"])
        self.hero_detail.set(
            f"Last checked {report['timestamp']} • {report['score']}/100 "
            f"across {len(report['checks'])} read-only checks."
        )
        self._render_summary(report)
        self._render_detail(report)

    def _check_map(self, report):
        return {item["key"]: item for item in (report or {}).get("checks", [])}

    def _render_summary(self, report):
        for child in self.summary.winfo_children():
            child.destroy()
        check_map = self._check_map(report)
        items = [
            ("Connection", report["status"] if report else "—", "Overall path status", "status"),
            ("Gateway", check_map.get("gateway", {}).get("latency_ms"), "Default route ping", "gateway"),
            ("DNS", check_map.get("dns", {}).get("latency_ms"), "www.microsoft.com lookup", "dns"),
            ("Internet", check_map.get("internet", {}).get("latency_ms"), "HTTPS reachability", "internet"),
        ]
        for column, (label, value, detail, key) in enumerate(items):
            self.summary.grid_columnconfigure(column, weight=1, uniform="network_summary")
            card = GlassCard(self.summary, self.theme, aero=self.aero,
                             accent=fl.GOOD if report and (
                                 key == "status" and report["status"] == "ONLINE"
                                 or key != "status" and check_map.get(key, {}).get("ok")
                             ) else self.theme["ACCENT"])
            card.grid(row=0, column=column, sticky="nsew",
                      padx=(0 if column == 0 else 6, 6 if column < 3 else 0))
            body = card.body
            tk.Label(body, text=label.upper(), bg=card.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY()).pack(
                         anchor="w", padx=14, pady=(13, 2))
            shown = (
                value if key == "status" else _format_latency(value)
            )
            color = fl.GOOD if report and (
                key == "status" and report["status"] == "ONLINE"
                or key != "status" and check_map.get(key, {}).get("ok")
            ) else self.theme["FG"]
            tk.Label(body, text=shown, bg=card.fill, fg=color,
                     font=fl.F_SUBTITLE()).pack(anchor="w", padx=14)
            tk.Label(body, text=detail, bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_TINY()).pack(anchor="w", padx=14, pady=(2, 13))

    def _render_detail(self, report):
        for child in self.detail.winfo_children():
            child.destroy()
        for child in self.adapters_tab.winfo_children():
            child.destroy()
        for child in self.history_tab.winfo_children():
            child.destroy()

        if report is None:
            card = GlassCard(self.detail, self.theme, aero=self.aero,
                             accent=self.theme["ACCENT"])
            card.pack(fill="x", padx=18, pady=(14, 0))
            tk.Label(card.body, text="NO SNAPSHOT YET", bg=card.fill,
                     fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                         anchor="w", padx=18, pady=(16, 3))
            tk.Label(card.body, text="Run diagnostics to populate the lab.",
                     bg=card.fill, fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                         anchor="w", padx=18, pady=(0, 16))
            adapters_placeholder = GlassCard(self.adapters_tab, self.theme, aero=self.aero,
                                              accent=self.theme["ACCENT"])
            adapters_placeholder.pack(fill="x", padx=18, pady=(14, 0))
            tk.Label(adapters_placeholder.body, text="Run diagnostics to list adapters.",
                     bg=adapters_placeholder.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=16)
            self._render_history(self.history_tab).pack(fill="x", padx=18, pady=(14, 0))
            return

        latency = GlassCard(self.detail, self.theme, aero=self.aero,
                            accent=self.theme["ACCENT"])
        latency.pack(fill="x", padx=18, pady=(14, 14))
        tk.Label(latency.body, text="LATENCY  /  TECHDRIVE", bg=latency.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(latency.body, text="Connection path measurements",
                 bg=latency.fill, fg=self.theme["FG"],
                 font=fl.F_SUBTITLE()).pack(anchor="w", padx=18, pady=(0, 8))
        for check in report["checks"]:
            row = tk.Frame(latency.body, bg=latency.fill)
            row.pack(fill="x", padx=18, pady=3)
            color = fl.GOOD if check["ok"] else fl.BAD
            tk.Label(row, text="●", bg=latency.fill, fg=color,
                     font=fl.F_SMALL()).pack(side="left", padx=(0, 8))
            tk.Label(row, text=check["label"], bg=latency.fill,
                     fg=self.theme["FG"], font=fl.F_BODY(),
                     width=14, anchor="w").pack(side="left")
            tk.Label(row, text=_format_latency(check["latency_ms"]),
                     bg=latency.fill, fg=color, font=fl.F_CARD_TITLE(),
                     width=10, anchor="w").pack(side="left")
            tk.Label(row, text=check["detail"], bg=latency.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY(),
                     anchor="w").pack(side="left", fill="x", expand=True)
        tk.Frame(latency.body, bg=latency.fill, height=10).pack()

        self._render_adapters(self.adapters_tab, report).pack(
            fill="x", padx=18, pady=(14, 0))
        self._render_history(self.history_tab).pack(
            fill="x", padx=18, pady=(14, 0))

    def _render_adapters(self, parent, report):
        card = GlassCard(parent, self.theme, aero=self.aero, accent=fl.GOOD)
        body = card.body
        tk.Label(body, text="ADAPTERS", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text="Detected network interfaces", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(0, 8))
        rows = report.get("adapters", [])
        if not rows:
            tk.Label(body, text="No non-loopback adapters were returned.",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
        for adapter in rows:
            row = tk.Frame(body, bg=card.fill)
            row.pack(fill="x", padx=18, pady=3)
            tk.Label(row, text="●", bg=card.fill,
                     fg=fl.GOOD if adapter["up"] else fl.BAD,
                     font=fl.F_SMALL()).pack(side="left", padx=(0, 8))
            tk.Label(row, text=adapter["name"], bg=card.fill,
                     fg=self.theme["FG"], font=fl.F_BODY(),
                     anchor="w").pack(side="left", fill="x", expand=True)
            tk.Label(row, text=adapter["speed"], bg=card.fill,
                     fg=self.theme["TEXT_FG"], font=fl.F_TINY()).pack(side="right")
            tk.Label(body, text=f"    {adapter['address']}",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_TINY()).pack(anchor="w", padx=18)
        tk.Frame(body, bg=card.fill, height=10).pack()
        return card

    def _render_history(self, parent):
        card = GlassCard(parent, self.theme, aero=self.aero,
                         accent=self.theme["ACCENT2"])
        body = card.body
        tk.Label(body, text="DIAGNOSTIC HISTORY", bg=card.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TINY()).pack(
                     anchor="w", padx=18, pady=(16, 3))
        tk.Label(body, text="Recent Network Lab runs", bg=card.fill,
                 fg=self.theme["FG"], font=fl.F_SUBTITLE()).pack(
                     anchor="w", padx=18, pady=(0, 8))
        history = db.get_network_lab_history(limit=6)
        if not history:
            tk.Label(body, text="No Network Lab runs saved yet.",
                     bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_SMALL()).pack(anchor="w", padx=18, pady=(0, 16))
            return card
        for entry in history:
            score = int(entry.get("score") or 0)
            color = fl.GOOD if score >= 80 else fl.WARN if score >= 50 else fl.BAD
            when = _datetime.datetime.fromtimestamp(
                float(entry.get("occurred_at", 0))
            ).strftime("%b %d, %H:%M")
            row = tk.Frame(body, bg=card.fill)
            row.pack(fill="x", padx=18, pady=3)
            tk.Label(row, text=when, bg=card.fill, fg=self.theme["MUTED"],
                     font=fl.F_TINY()).pack(side="left")
            tk.Label(row, text=f"{entry.get('title', 'Network Lab')}  {score}/100",
                     bg=card.fill, fg=color, font=fl.F_CARD_TITLE()).pack(
                         side="right")
            tk.Label(body, text=entry.get("summary", ""), bg=card.fill,
                     fg=self.theme["TEXT_FG"], font=fl.F_TINY(),
                     wraplength=360, justify="left").pack(anchor="w", padx=18)
        tk.Frame(body, bg=card.fill, height=10).pack()
        return card