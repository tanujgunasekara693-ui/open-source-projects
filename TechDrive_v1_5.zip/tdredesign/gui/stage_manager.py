#!/usr/bin/env python3
"""Stage Manager–style multi-panel workspace for TechDrive.

Pin 2–3 tools side by side in a single notebook tab without full separate tabs.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from gui import fluent as fl
from gui.widgets import FluentButton
from gui.motion import tween, spring
from gui.snap_layouts import show_snap_layouts


class StageManager(tk.Frame):
    """Horizontal stage with up to 3 panes."""

    MAX_PANES = 3

    def __init__(self, parent, app, theme=None, aero=False):
        th = theme or getattr(app, "theme", fl.DARK)
        super().__init__(parent, bg=th["BG"])
        self.app = app
        self.theme = th
        self.aero = aero
        self.panes = []  # list of dicts {frame, title, category, tool}
        self._host = tk.Frame(self, bg=th["BG"])
        self._host.pack(fill="both", expand=True)
        self._toolbar = tk.Frame(self, bg=th.get("SURFACE", th["BG"]), height=36)
        self._toolbar.pack(fill="x", side="bottom")
        self._toolbar.pack_propagate(False)
        tk.Label(
            self._toolbar, text="Stage Manager", bg=self._toolbar["bg"],
            fg=th["MUTED"], font=("Segoe UI", 9, "bold"),
        ).pack(side="left", padx=12)
        FluentButton(
            self._toolbar, "Snap", command=self._show_snap,
            theme=th, aero=aero, kind="subtle", height=28, width=70,
            backdrop=self._toolbar["bg"],
        ).pack(side="right", padx=4, pady=4)
        FluentButton(
            self._toolbar, "Add pane", command=self._prompt_add,
            theme=th, aero=aero, kind="subtle", height=28, width=90,
            backdrop=self._toolbar["bg"],
        ).pack(side="right", padx=8, pady=4)
        FluentButton(
            self._toolbar, "Clear", command=self.clear,
            theme=th, aero=aero, kind="subtle", height=28, width=70,
            backdrop=self._toolbar["bg"],
        ).pack(side="right", padx=4, pady=4)

    def clear(self):
        for p in self.panes:
            try:
                p["frame"].destroy()
            except Exception:
                pass
        self.panes.clear()
        self._relayout()

    def add_tool(self, category, tool_name):
        if len(self.panes) >= self.MAX_PANES:
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Stage is full (max 3 panes)", kind="warn")
            return
        th = self.theme
        pane = tk.Frame(self._host, bg=th.get("CARD_BG", th["BG"]),
                        highlightthickness=1,
                        highlightbackground=th.get("STROKE", "#333"))
        header = tk.Frame(pane, bg=th.get("SURFACE", th["BG"]), height=32)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text=f"{tool_name}", bg=header["bg"], fg=th["FG"],
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=10)
        tk.Label(
            header, text=category, bg=header["bg"], fg=th["MUTED"],
            font=("Segoe UI", 8),
        ).pack(side="left", padx=4)

        def close(_p=None):
            self._close_pane(pane)

        tk.Label(
            header, text="✕", bg=header["bg"], fg=th["MUTED"],
            font=("Segoe UI", 11), cursor="hand2",
        ).pack(side="right", padx=8)
        header.winfo_children()[-1].bind("<Button-1>", lambda e: close())

        body = tk.Frame(pane, bg=th["BG"])
        body.pack(fill="both", expand=True)
        # Build tool into body via app.open_tool machinery without new notebook tab
        try:
            method = None
            from techdrive import TOOL_DISPATCH, slugify
            method = TOOL_DISPATCH.get((category, tool_name))
            if method is not None:
                method = method.__get__(self.app, type(self.app))
            else:
                method_name = "tool_" + slugify(tool_name)
                method = getattr(self.app, method_name, None)
            if method:
                method(body)
            else:
                tk.Label(body, text=f"Open {tool_name} from All Tools for full panel.",
                         bg=th["BG"], fg=th["MUTED"]).pack(pady=20)
        except Exception as e:
            tk.Label(body, text=f"Could not load pane: {e}",
                     bg=th["BG"], fg=th["MUTED"], wraplength=240).pack(pady=20)

        self.panes.append({
            "frame": pane, "title": tool_name,
            "category": category, "tool": tool_name,
        })
        if getattr(self, "_regions", None):
            self._apply_snap_regions()
        else:
            self._relayout()
        try:
            from gui import haptics
            haptics.click()
        except Exception:
            pass

    def _close_pane(self, frame):
        self.panes = [p for p in self.panes if p["frame"] is not frame]
        try:
            frame.destroy()
        except Exception:
            pass
        self._relayout()

    def _relayout(self):
        for child in self._host.winfo_children():
            child.pack_forget()
        n = len(self.panes)
        if n == 0:
            tk.Label(
                self._host,
                text="Pin up to 3 tools side by side.\nUse Add pane or Stage from Command Palette.",
                bg=self.theme["BG"], fg=self.theme["MUTED"],
                font=("Segoe UI", 11), justify="center",
            ).pack(expand=True)
            return
        for p in self.panes:
            p["frame"].pack(side="left", fill="both", expand=True, padx=3, pady=3)

    def _show_snap(self):
        def apply(key, regions):
            self._layout_key = key
            self._regions = regions
            self._apply_snap_regions()
        show_snap_layouts(self.app, on_pick=apply)

    def _apply_snap_regions(self):
        """Place panes according to last snap regions (relative)."""
        regions = getattr(self, "_regions", None)
        if not regions or not self.panes:
            self._relayout()
            return
        for child in self._host.winfo_children():
            try:
                child.place_forget()
            except Exception:
                pass
            try:
                child.pack_forget()
            except Exception:
                pass
        self._host.update_idletasks()
        for i, p in enumerate(self.panes):
            if i >= len(regions):
                p["frame"].pack_forget()
                continue
            rx, ry, rw, rh = regions[i]
            p["frame"].place(relx=rx, rely=ry, relwidth=rw, relheight=rh)

    def _prompt_add(self):
        # Open command-palette-like quick pick of recent tools
        try:
            recent = self.app.get_recent_tools(12) if hasattr(self.app, "get_recent_tools") else []
        except Exception:
            recent = []
        if not recent:
            if hasattr(self.app, "show_toast"):
                self.app.show_toast("Open a tool first, then pin it here", kind="info")
            return
        top = tk.Toplevel(self)
        top.title("Add to Stage")
        top.geometry("320x360")
        top.configure(bg=self.theme["BG"])
        top.transient(self.winfo_toplevel())
        tk.Label(top, text="Recent tools", bg=self.theme["BG"], fg=self.theme["FG"],
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=12, pady=10)
        for cat, tool in recent:
            def add(c=cat, t=tool):
                top.destroy()
                self.add_tool(c, t)
            tk.Button(
                top, text=f"{tool}  ·  {cat}", command=add,
                bg=self.theme.get("LAYER_2", self.theme["CARD_BG"]),
                fg=self.theme["FG"], relief="flat", anchor="w",
                padx=10, pady=8, cursor="hand2",
            ).pack(fill="x", padx=12, pady=2)


def open_stage_tab(app):
    """Open or focus the Stage Manager notebook tab."""
    for tab_id in app.notebook.tabs():
        try:
            if app.notebook._display_title(app.notebook.tab(tab_id, "text")) == "Stage Manager":
                app.notebook.select(tab_id)
                return getattr(app, "_stage_manager", None)
        except Exception:
            pass
    frame = tk.Frame(app.notebook, bg=app.theme["BG"])
    app.notebook.add_closable(frame, text="Stage Manager")
    app.notebook.select(frame)
    sm = StageManager(frame, app, theme=app.theme, aero=app.is_aero_enabled())
    sm.pack(fill="both", expand=True)
    app._stage_manager = sm
    return sm
