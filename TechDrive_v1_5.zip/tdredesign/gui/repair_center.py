#!/usr/bin/env python3
"""
TechDrive Repair Center
=======================

The Repair Center is the controlled, one-click repair surface.  Every
potentially disruptive operation follows the same four explicit stages:

    Preview -> Confirm -> Execute -> Verify

Command lines are fixed in code and displayed before confirmation.  The
page never shells out on construction, and the advanced repair surface is
intentionally locked out of this first-party flow.
"""

import os
import platform
import subprocess
import tempfile
import ctypes
import shutil
import tkinter as tk
from gui.tk_dialogs import messagebox

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard


IS_WINDOWS = platform.system() == "Windows"


def _run_argv(argv, timeout=60):
    """Run a fixed argv without a shell and return (success, output)."""
    try:
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip()
        return result.returncode == 0, output or f"(no output, exit code {result.returncode})"
    except subprocess.TimeoutExpired:
        return False, "Command timed out."
    except FileNotFoundError:
        return False, f"{argv[0]} is not available on this PC."
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _powershell(script, timeout=60):
    return _run_argv(
        [
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            script,
        ],
        timeout=timeout,
    )


def _windows_only():
    return {
        "ok": False,
        "output": (
            "Windows-only repair. No command was executed because this "
            "TechDrive session is not running on Windows."
        ),
    }


def _result(ok, output):
    return {"ok": bool(ok), "output": output}


def _temp_roots():
    """Return only user/system temp directories, never arbitrary folders."""
    candidates = [tempfile.gettempdir(), os.environ.get("TEMP"), os.environ.get("TMP")]
    roots = []
    for candidate in candidates:
        if not candidate:
            continue
        path = os.path.abspath(candidate)
        if os.path.isdir(path) and path not in roots:
            roots.append(path)
    return roots


def _temp_inventory():
    files = 0
    total = 0
    roots = _temp_roots()
    for root in roots:
        for current, directories, names in os.walk(root, topdown=True, followlinks=False):
            directories[:] = [
                name
                for name in directories
                if not os.path.islink(os.path.join(current, name))
            ]
            for name in names:
                path = os.path.join(current, name)
                if os.path.islink(path):
                    continue
                try:
                    total += os.path.getsize(path)
                    files += 1
                except OSError:
                    continue
    return roots, files, total


def _bytes(value):
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def _preview_temp():
    roots, files, total = _temp_inventory()
    if not roots:
        return {
            "ok": False,
            "output": "No approved temporary-file locations were found. No files will be touched.",
        }
    root_text = "\n".join(f"  - {root}" for root in roots)
    return {
        "ok": True,
        "output": (
            "Approved locations:\n"
            f"{root_text}\n\n"
            f"Preview found approximately {files:,} files ({_bytes(total)}).\n"
            "TechDrive will delete files only inside these temporary folders, "
            "skip symbolic links, and leave directories in place."
        ),
    }


def _execute_temp():
    if not IS_WINDOWS:
        return _windows_only()
    roots = _temp_roots()
    deleted = 0
    skipped = 0
    freed = 0
    for root in roots:
        for current, directories, names in os.walk(root, topdown=True, followlinks=False):
            directories[:] = [
                name
                for name in directories
                if not os.path.islink(os.path.join(current, name))
            ]
            for name in names:
                path = os.path.join(current, name)
                if os.path.islink(path):
                    skipped += 1
                    continue
                try:
                    freed += os.path.getsize(path)
                    os.remove(path)
                    deleted += 1
                except OSError:
                    skipped += 1
    return _result(
        True,
        f"Removed {deleted:,} temporary files and freed approximately {_bytes(freed)}. "
        f"Skipped {skipped:,} locked or unavailable files.",
    )


def _verify_temp():
    roots, files, total = _temp_inventory()
    if not roots:
        return _result(False, "No approved temporary-file locations were found.")
    return _result(
        True,
        f"Verification complete: {files:,} files ({_bytes(total)}) remain in "
        "the approved temporary locations. Locked files may remain by design.",
    )


def _repair_update_script():
    return (
        "$ErrorActionPreference = 'Stop'; "
        "$services = @('wuauserv','bits','cryptsvc'); "
        "foreach ($service in $services) { "
        "  Stop-Service -Name $service -Force -ErrorAction SilentlyContinue "
        "}; "
        "$stamp = Get-Date -Format 'yyyyMMddHHmmss'; "
        "$software = Join-Path $env:SystemRoot 'SoftwareDistribution'; "
        "$catroot = Join-Path $env:SystemRoot 'System32\\catroot2'; "
        "if (Test-Path $software) { "
        "  Rename-Item $software ($software + '.TechDrive.' + $stamp) "
        "}; "
        "if (Test-Path $catroot) { "
        "  Rename-Item $catroot ($catroot + '.TechDrive.' + $stamp) "
        "}; "
        "foreach ($service in $services) { "
        "  Start-Service -Name $service -ErrorAction SilentlyContinue "
        "}; "
        "Write-Output 'Windows Update cache reset completed.'"
    )


def _verify_update():
    return _powershell(
        "Get-Service wuauserv,bits,cryptsvc | "
        "Select-Object Name,Status,StartType | Format-Table -AutoSize | "
        "Out-String -Width 160",
        timeout=30,
    )


def _execute_network():
    if not IS_WINDOWS:
        return _windows_only()
    outputs = []
    all_ok = True
    for argv in (
        ["netsh", "winsock", "reset"],
        ["netsh", "int", "ip", "reset"],
    ):
        ok, output = _run_argv(argv, timeout=120)
        all_ok = all_ok and ok
        outputs.append(f"> {' '.join(argv)}\n{output}")
    return _result(all_ok, "\n\n".join(outputs))


def _verify_network():
    if not IS_WINDOWS:
        return _windows_only()
    return _run_argv(["ipconfig", "/all"], timeout=30)


def _execute_commands(commands, timeout):
    if not IS_WINDOWS:
        return _windows_only()
    ok, output = _run_argv(commands, timeout=timeout)
    return _result(ok, output)


def _execute_update():
    if not IS_WINDOWS:
        return _windows_only()
    return _result(*_powershell(_repair_update_script(), timeout=300))


def _execute_common():
    if not IS_WINDOWS:
        return _windows_only()
    outputs = []
    all_ok = True
    for argv, timeout in (
        (["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"], 2400),
        (["sfc", "/scannow"], 1800),
    ):
        ok, output = _run_argv(argv, timeout=timeout)
        all_ok = all_ok and ok
        outputs.append(f"> {' '.join(argv)}\n{output}")
    return _result(all_ok, "\n\n".join(outputs))


def _verify_common():
    if not IS_WINDOWS:
        return _windows_only()
    dism_ok, dism_output = _run_argv(
        ["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"], timeout=60
    )
    sfc_ok, sfc_output = _run_argv(["sfc", "/verifyonly"], timeout=900)
    return _result(
        dism_ok and sfc_ok,
        f"> DISM /Online /Cleanup-Image /CheckHealth\n{dism_output}\n\n"
        f"> sfc /verifyonly\n{sfc_output}",
    )



def _is_admin():
    if not IS_WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _preflight():
    if not IS_WINDOWS:
        return {"ok": True, "output": "Preview mode: repair commands are disabled outside Windows."}
    drive = os.environ.get("SystemDrive", "C:") + "\\"
    try:
        total, used, free = shutil.disk_usage(drive)
        free_text = _bytes(free)
    except OSError:
        free_text = "Unknown"
    admin = _is_admin()
    return {
        "ok": True,
        "output": (
            f"Administrator: {'Yes' if admin else 'No'}\n"
            f"System drive free space: {free_text}\n"
            "Execution is still gated by Preview -> Confirm -> Execute -> Verify."
        ),
    }

def _action_specs():
    return [
        {
            "key": "component_store",
            "title": "Repair Windows component store",
            "description": "Repairs the Windows image and component store with DISM RestoreHealth.",
            "impact": "May use Windows Update as a source and can take up to 20 minutes.",
            "preview": (
                "DISM /Online /Cleanup-Image /RestoreHealth\n\n"
                "Verify with:\n"
                "DISM /Online /Cleanup-Image /CheckHealth"
            ),
            "execute": lambda: _execute_commands(
                ["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"], 2400
            ),
            "verify": lambda: _result(
                *_run_argv(
                    ["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"], timeout=60
                )
            ),
        },
        {
            "key": "system_files",
            "title": "Check system files",
            "description": "Scans and repairs protected Windows system files with System File Checker.",
            "impact": "Can take several minutes; repaired files are recorded by Windows.",
            "preview": "sfc /scannow\n\nVerify with:\nsfc /verifyonly",
            "execute": lambda: _execute_commands(["sfc", "/scannow"], 1800),
            "verify": lambda: _result(
                *_run_argv(["sfc", "/verifyonly"], timeout=900)
            )
        },
        {
            "key": "network",
            "title": "Reset network stack",
            "description": "Resets Winsock and TCP/IP configuration using fixed netsh commands.",
            "impact": "Active network connections may drop. Restart Windows afterward if requested.",
            "preview": (
                "netsh winsock reset\n"
                "netsh int ip reset\n\n"
                "Verify with:\n"
                "ipconfig /all"
            ),
            "execute": _execute_network,
            "verify": lambda: _result(*_verify_network()),
        },
        {
            "key": "windows_update",
            "title": "Repair Windows Update",
            "description": "Stops update services, renames their caches, and starts the services again.",
            "impact": "Windows Update may need to redownload pending update data.",
            "preview": (
                "PowerShell script:\n"
                f"{_repair_update_script()}\n\n"
                "Verify with:\n"
                "Get-Service wuauserv,bits,cryptsvc"
            ),
            "execute": _execute_update,
            "verify": lambda: _result(*_verify_update()),
        },
        {
            "key": "temp_files",
            "title": "Clear safe temporary files",
            "description": "Removes files only from approved Windows temporary folders.",
            "impact": "Locked files are skipped. Temporary files may be recreated by Windows or apps.",
            "preview": _preview_temp,
            "execute": _execute_temp,
            "verify": _verify_temp,
        },
        {
            "key": "common_components",
            "title": "Repair common system components",
            "description": "Runs the standard DISM and SFC repair pair in sequence.",
            "impact": "This is the longest one-click repair and should not be interrupted.",
            "preview": (
                "1. DISM /Online /Cleanup-Image /RestoreHealth\n"
                "2. sfc /scannow\n\n"
                "Verify with DISM CheckHealth and sfc /verifyonly."
            ),
            "execute": _execute_common,
            "verify": _verify_common,
        },
    ]


class RepairCenterPage(tk.Frame):
    """Controlled repair dashboard embedded in the main notebook."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self._states = {}
        self._build()

    def _build(self):
        canvas, root = make_scrollable(self, self.theme["BG"])
        self._root = root

        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 12))
        tk.Label(
            header,
            text="REPAIR CENTER",
            bg=self.theme["BG"],
            fg=self.theme["ACCENT_GLOW"],
            font=fl.F_TINY(),
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Controlled repairs, clear outcomes",
            bg=self.theme["BG"],
            fg=self.theme["FG"],
            font=fl.F_TITLE(),
        ).pack(anchor="w", pady=(4, 4))
        tk.Label(
            header,
            text=(
                "Every repair shows the exact plan before it can run. "
                "Preview → Confirm → Execute → Verify."
            ),
            bg=self.theme["BG"],
            fg=self.theme["MUTED"],
            font=fl.F_BODY(),
            wraplength=760,
            justify="left",
        ).pack(anchor="w")

        pre = GlassCard(root, self.theme, aero=self.aero, accent=self.theme["ACCENT"])
        pre.pack(fill="x", padx=24, pady=(0, 10))
        pre_body = tk.Frame(pre.body, bg=pre.fill)
        pre_body.pack(fill="x", padx=14, pady=12)
        tk.Label(pre_body, text="REPAIR PREFLIGHT", bg=pre.fill, fg=self.theme["FG"], font=fl.F_CARD_TITLE()).pack(anchor="w")
        tk.Label(pre_body, text="Read-only check of permissions and available system-drive space before you begin.", bg=pre.fill, fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(anchor="w", pady=(4, 8))
        pre_status = tk.Label(pre_body, text="Not checked", bg=pre.fill, fg=self.theme["MUTED"], font=fl.F_SMALL(), justify="left")
        pre_status.pack(anchor="w", pady=(0, 8))
        def run_preflight():
            pre_status.configure(text="Checking…", fg=self.theme["ACCENT"])
            def done(result):
                output = result.get("output", str(result)) if isinstance(result, dict) else str(result)
                pre_status.configure(text=output, fg=fl.GOOD if result.get("ok", True) else fl.BAD)
            self.app._run_bg(_preflight, done)
        tk.Button(pre_body, text="Run preflight check", command=run_preflight, bg=self.theme["BG_LIGHT"], fg=self.theme["FG"], activebackground=self.theme["SELECTION"], activeforeground=self.theme["FG"], relief="flat", padx=11, pady=5).pack(anchor="w")

        notice = GlassCard(root, self.theme, aero=self.aero, accent=fl.WARN)
        notice.pack(fill="x", padx=24, pady=(0, 14))
        notice_body = tk.Frame(notice.body, bg=notice.fill)
        notice_body.pack(fill="x", padx=14, pady=12)
        mode = (
            "Windows execution is available."
            if IS_WINDOWS
            else "Preview mode only: execution is available when TechDrive runs on Windows."
        )
        tk.Label(
            notice_body,
            text=f"●  {mode}",
            bg=notice.fill,
            fg=fl.WARN,
            font=fl.F_CARD_TITLE(),
        ).pack(anchor="w")
        tk.Label(
            notice_body,
            text=(
                "Most repairs need Administrator rights. Opening this page "
                "never changes the PC."
            ),
            bg=notice.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        ).pack(anchor="w", pady=(5, 0))

        for spec in _action_specs():
            self._build_action_card(root, spec)

        self._build_advanced_card(root)

    def _build_action_card(self, root, spec):
        card = GlassCard(root, self.theme, aero=self.aero, accent=self.theme["ACCENT"])
        card.pack(fill="x", padx=24, pady=6)
        body = card.body
        state = {
            "preview": False,
            "confirmed": False,
            "executed": False,
            "verified": False,
            "busy": False,
        }
        self._states[spec["key"]] = state

        title_row = tk.Frame(body, bg=card.fill)
        title_row.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(
            title_row,
            text="✓",
            bg=card.fill,
            fg=fl.GOOD,
            font=fl.F_SUBTITLE(),
        ).pack(side="left", padx=(0, 10))
        tk.Label(
            title_row,
            text=spec["title"],
            bg=card.fill,
            fg=self.theme["FG"],
            font=fl.F_SUBTITLE(),
        ).pack(side="left")

        tk.Label(
            body,
            text=spec["description"],
            bg=card.fill,
            fg=self.theme["FG"],
            font=fl.F_BODY(),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", padx=48, pady=(0, 3))
        tk.Label(
            body,
            text=f"Impact: {spec['impact']}",
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", padx=48, pady=(0, 8))

        preview_box = tk.Text(
            body,
            height=5,
            wrap="word",
            bg=self.theme["BG_LIGHT"],
            fg=self.theme["FG"],
            insertbackground=self.theme["FG"],
            font=fl.F_MONO(),
            relief="flat",
            padx=10,
            pady=8,
            state="disabled",
        )
        preview_box.pack(fill="x", padx=48, pady=(0, 8))

        status_var = tk.StringVar(value="Step 1 of 4 · Preview required")
        status_label = tk.Label(
            body,
            textvariable=status_var,
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SMALL(),
        )
        status_label.pack(anchor="w", padx=48, pady=(0, 8))

        controls = tk.Frame(body, bg=card.fill)
        controls.pack(anchor="w", padx=48, pady=(0, 14))
        buttons = {}
        for name, label in (
            ("preview", "1  Preview"),
            ("confirm", "2  Confirm"),
            ("execute", "3  Execute"),
            ("verify", "4  Verify"),
        ):
            buttons[name] = tk.Button(
                controls,
                text=label,
                command=lambda stage=name, item=spec: self._stage(item, stage),
                bg=self.theme["BG_LIGHT"],
                fg=self.theme["FG"],
                activebackground=self.theme["SELECTION"],
                activeforeground=self.theme["FG"],
                relief="flat",
                padx=11,
                pady=5,
                cursor="hand2",
            )
            buttons[name].pack(side="left", padx=(0, 8))

        self._states[spec["key"]]["buttons"] = buttons
        self._states[spec["key"]]["preview_box"] = preview_box
        self._states[spec["key"]]["status_var"] = status_var
        self._states[spec["key"]]["status_label"] = status_label
        self._refresh_controls(spec)

    def _build_advanced_card(self, root):
        card = GlassCard(root, self.theme, aero=self.aero, accent=self.theme["MUTED"])
        card.pack(fill="x", padx=24, pady=(14, 24))
        body = card.body
        row = tk.Frame(body, bg=card.fill)
        row.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(
            row,
            text="○",
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SUBTITLE(),
        ).pack(side="left", padx=(0, 10))
        tk.Label(
            row,
            text="Advanced repair",
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_SUBTITLE(),
        ).pack(side="left")
        tk.Label(
            body,
            text=(
                "Boot configuration, registry, driver, and other high-impact "
                "operations stay outside the one-click flow."
            ),
            bg=card.fill,
            fg=self.theme["MUTED"],
            font=fl.F_BODY(),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", padx=48, pady=(0, 5))
        tk.Label(
            body,
            text="Locked until a dedicated advanced-repair review is added.",
            bg=card.fill,
            fg=fl.WARN,
            font=fl.F_SMALL(),
        ).pack(anchor="w", padx=48, pady=(0, 14))

    def _set_preview_text(self, state, text):
        box = state["preview_box"]
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", text)
        box.configure(state="disabled")

    def _stage(self, spec, stage):
        state = self._states[spec["key"]]
        if state["busy"]:
            return
        if stage == "preview":
            state.update(preview=False, confirmed=False, executed=False, verified=False, busy=True)
            self._set_status(spec, "Previewing approved scope…", self.theme["ACCENT"])
            self._refresh_controls(spec)

            def done(result):
                state["busy"] = False
                state["preview"] = True
                output = result.get("output", str(result)) if isinstance(result, dict) else str(result)
                self._set_preview_text(
                    state,
                    f"COMMAND PLAN\n\n{spec['preview']}\n\nPREVIEW DETAILS\n{output}",
                )
                self._set_status(spec, "Step 2 of 4 · Preview ready for confirmation", self.theme["ACCENT"])
                self._refresh_controls(spec)

            preview = spec["preview"] if callable(spec["preview"]) else lambda: {
                "ok": True,
                "output": "No command was executed. This is a read-only plan.",
            }
            self.app._run_bg(preview, done)
            return

        if stage == "confirm":
            if not IS_WINDOWS:
                messagebox.showinfo(
                    "Windows required",
                    "This session is in preview-only mode. No repair can be confirmed or executed here.",
                )
                return
            if not state["preview"]:
                messagebox.showinfo("Preview required", "Run Preview before confirming a repair.")
                return
            if messagebox.askyesno(
                "Confirm repair",
                (
                    f"{spec['title']}\n\n"
                    f"{spec['impact']}\n\n"
                    "TechDrive will run only the command plan shown above. "
                    "Continue to the Execute step?"
                ),
            ):
                state["confirmed"] = True
                self._set_status(
                    spec,
                    "Step 3 of 4 · Confirmed; Execute is now available",
                    fl.WARN,
                )
                self._refresh_controls(spec)
            return

        if stage == "execute":
            if not state["preview"] or not state["confirmed"]:
                messagebox.showinfo(
                    "Confirmation required",
                    "Preview and confirm this repair before execution.",
                )
                return
            state["busy"] = True
            self._set_status(spec, "Executing approved command plan…", fl.WARN)
            self._refresh_controls(spec)

            def done(result):
                state["busy"] = False
                state["executed"] = True
                ok, output = self._normalise_result(result)
                self._set_preview_text(
                    state,
                    f"EXECUTION RESULT\n\n{'Success' if ok else 'Completed with errors'}\n\n{output}",
                )
                status = (
                    "Step 4 of 4 · Execute finished; run Verify"
                    if ok
                    else "Step 4 of 4 · Execution reported an error; run Verify for details"
                )
                self._set_status(spec, status, fl.GOOD if ok else fl.BAD)
                self._refresh_controls(spec)
                try:
                    self.app.notify(
                        "Repair completed" if ok else "Repair needs review",
                        f"{spec['title']}: {output[:220]}",
                        kind="success" if ok else "error",
                        toast=True,
                        source="Repair Center",
                    )
                except Exception:
                    pass

            self.app._run_bg(spec["execute"], done)
            return

        if stage == "verify":
            if not state["executed"]:
                messagebox.showinfo("Execute required", "Execute the confirmed repair before verifying it.")
                return
            state["busy"] = True
            self._set_status(spec, "Running read-only verification…", self.theme["ACCENT"])
            self._refresh_controls(spec)

            def done(result):
                state["busy"] = False
                state["verified"] = True
                ok, output = self._normalise_result(result)
                self._set_preview_text(
                    state,
                    f"VERIFICATION RESULT\n\n{'Verified' if ok else 'Review needed'}\n\n{output}",
                )
                self._set_status(
                    spec,
                    "Verified successfully" if ok else "Verification needs review",
                    fl.GOOD if ok else fl.BAD,
                )
                self._refresh_controls(spec)
                try:
                    self.app.notify(
                        "Repair verified" if ok else "Verification needs review",
                        f"{spec['title']}: {output[:220]}",
                        kind="success" if ok else "warning",
                        toast=True,
                        source="Repair Center",
                    )
                except Exception:
                    pass

            self.app._run_bg(spec["verify"], done)

    @staticmethod
    def _normalise_result(result):
        if isinstance(result, dict):
            return bool(result.get("ok")), str(result.get("output", ""))
        text = str(result)
        return not text.lower().startswith(("error:", "command timed out", "windows-only")), text

    def _set_status(self, spec, text, color):
        state = self._states[spec["key"]]
        state["status_var"].set(text)
        state["status_label"].configure(fg=color)

    def _refresh_controls(self, spec):
        state = self._states[spec["key"]]
        buttons = state.get("buttons", {})
        if not buttons:
            return
        busy = state["busy"]
        buttons["preview"].configure(state=tk.DISABLED if busy else tk.NORMAL)
        buttons["confirm"].configure(
            state=(
                tk.NORMAL
                if IS_WINDOWS and state["preview"] and not state["confirmed"] and not busy
                else tk.DISABLED
            )
        )
        buttons["execute"].configure(
            state=(
                tk.NORMAL
                if IS_WINDOWS and state["confirmed"] and not state["executed"] and not busy
                else tk.DISABLED
            )
        )
        buttons["verify"].configure(
            state=(
                tk.NORMAL
                if IS_WINDOWS and state["executed"] and not state["verified"] and not busy
                else tk.DISABLED
            )
        )
