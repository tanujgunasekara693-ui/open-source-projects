"""First-use contextual explanations for selected TechDrive tools."""
import tkinter as tk
from gui import fluent as fl
from shared import database as db

TOOLTIPS = {
    "Disk Health": "SMART and health indicators summarize drive condition. Green is normal; warnings merit a backup and closer inspection.",
    "CPU Monitor": "Watch processor load, temperature and activity over time. Short spikes are normal; sustained high load can explain sluggishness.",
    "RAM Monitor": "Memory usage shows how much RAM Windows is using. High usage can cause paging and slower application switching.",
    "GPU Monitor": "GPU load and temperature help explain graphics-heavy workloads. Compare the live values with your normal workload.",
    "Live Monitor": "This view streams system activity without blocking the rest of TechDrive.",
    "Network Monitor": "Throughput and connection activity show what the network is doing right now.",
    "Event Log Analyzer": "This groups Windows event-log entries so you can focus on recurring warnings and errors instead of isolated noise.",
    "SMART Health": "SMART attributes are drive-health signals reported by the storage device. A warning is a reason to investigate, not a diagnosis by itself.",
}


def _key(category, tool):
    return "context_tooltip_seen::" + str(category) + "::" + str(tool)


def show_tooltip_for_tool(app, category, tool):
    if not db.get_setting("context_tooltips_enabled", True):
        return
    text = TOOLTIPS.get(tool)
    if not text:
        return
    key = _key(category, tool)
    if db.get_setting(key, False):
        return
    db.set_setting(key, True)
    win = tk.Toplevel(app)
    win.overrideredirect(True)
    win.attributes("-topmost", True)
    win.configure(bg=app.theme["STROKE"])
    body = tk.Frame(win, bg=app.theme["LAYER_1"])
    body.pack(fill="both", expand=True, padx=1, pady=1)
    tk.Label(body, text="QUICK TIP", bg=body["bg"], fg=app.theme["ACCENT_GLOW"],
             font=fl.font(8, "bold"), anchor="w").pack(fill="x", padx=12, pady=(10, 3))
    tk.Label(body, text=text, bg=body["bg"], fg=app.theme["FG"], wraplength=350,
             justify="left", anchor="w", font=fl.F_SMALL()).pack(fill="x", padx=12)
    tk.Button(body, text="Got it", command=win.destroy, relief="flat", bd=0,
              bg=app.theme["LAYER_2"], fg=app.theme["FG"], takefocus=1).pack(anchor="e", padx=12, pady=9)
    app.update_idletasks()
    x = min(app.winfo_rootx() + app.winfo_width() - 390, app.winfo_screenwidth() - 400)
    y = min(app.winfo_rooty() + app.winfo_height() - 180, app.winfo_screenheight() - 210)
    x = max(8, x); y = max(8, y)
    win.geometry(f"380x170+{x}+{y}")
    win.after(9000, lambda: win.destroy() if win.winfo_exists() else None)
