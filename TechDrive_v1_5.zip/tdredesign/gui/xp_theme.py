#!/usr/bin/env python3
r"""
gui/xp_theme.py - Classic Blue window styling (early-2000s Windows-
inspired, entirely original)
=====================================================================
An original color scheme for TechDrive's own header/border chrome -
a deep blue bar with a pale silver-blue accent border, evoking the
general look many people fondly remember from that era. Every color
here is composed fresh for TechDrive; nothing is extracted from,
traced from, or copies any Microsoft artwork, icon, bitmap, or
trademarked asset - it's just a blue color scheme, applied to this
app's own custom-drawn UI.

Scope, honestly stated: this recolors TechDrive's own header bar and
adds a colored border strip beneath it - the parts of the UI TechDrive
actually draws itself. It does NOT repaint the real OS-native window
title bar/frame (the one with the actual minimize/maximize/close
buttons) - that belongs to Windows, and a normal Tk app can't safely
redraw it without disabling native window decorations entirely, which
risks breaking dragging, resizing, and window snapping. Not attempted
here on purpose.

Off by default. Toggled from Settings; every original color/state is
snapshotted before changing anything, so turning it back off restores
the exact previous look rather than guessing at "default" colors.

Public API:
    apply(app)    -> bool, True if it could find the header to recolor
    remove(app)   -> reverts to whatever it looked like before apply()
"""

import tkinter as tk

# Original palette, composed for TechDrive - not sampled from any
# Microsoft asset. Just a blue/silver color pairing.
TITLE_BLUE = "#2A5DA8"
TITLE_BLUE_DARK = "#14315C"
TITLE_TEXT = "#FFFFFF"
BORDER_SILVER = "#ECE9D8"
BORDER_ACCENT = "#7A9CC6"


def _snapshot_widget(widget):
    snap = {}
    for opt in ("bg", "fg"):
        try:
            snap[opt] = widget.cget(opt)
        except tk.TclError:
            pass
    return snap


def apply(app):
    header = getattr(app, "_header_frame", None)
    if header is None or not header.winfo_exists():
        return False

    if not hasattr(app, "_xp_snapshot"):
        app._xp_snapshot = {"header": _snapshot_widget(header), "children": {}}
        for child in header.winfo_children():
            app._xp_snapshot["children"][child] = _snapshot_widget(child)

    header.configure(bg=TITLE_BLUE)
    for child in header.winfo_children():
        if isinstance(child, tk.Label):
            try:
                child.configure(bg=TITLE_BLUE, fg=TITLE_TEXT)
            except tk.TclError:
                pass
        # Buttons (Upgrade / Theme toggle) keep their own accent colors
        # on purpose - they're meant to stand out, not blend into the bar.

    border = getattr(app, "_xp_border_frame", None)
    if border is None or not border.winfo_exists():
        border = tk.Frame(app, bg=BORDER_ACCENT, height=3)
        border.pack(side="top", fill="x", after=header)
        app._xp_border_frame = border
    return True


def remove(app):
    header = getattr(app, "_header_frame", None)
    snapshot = getattr(app, "_xp_snapshot", None)
    if header is not None and header.winfo_exists() and snapshot:
        try:
            header.configure(**snapshot["header"])
        except tk.TclError:
            pass
        for child, opts in snapshot["children"].items():
            if child.winfo_exists():
                try:
                    child.configure(**opts)
                except tk.TclError:
                    pass
    if hasattr(app, "_xp_snapshot"):
        del app._xp_snapshot

    border = getattr(app, "_xp_border_frame", None)
    if border is not None and border.winfo_exists():
        border.destroy()
        app._xp_border_frame = None
