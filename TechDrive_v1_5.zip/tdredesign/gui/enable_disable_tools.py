#!/usr/bin/env python3
"""TechDrive Core Module Manager page.

This page manages the bundled tool modules that are already shipped with
TechDrive.  It does not download or install anything from the network.
Core TechDrive surfaces are not listed here; this page controls optional
module-backed tools only.
"""

import sys
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import messagebox

from gui.theme import FONT_CARD_TITLE, FONT_UI, FONT_UI_BOLD

ALL_CATEGORIES = "All"


def _card(parent, theme):
    return tk.Frame(parent, bg=theme["CARD_BG"], bd=1, relief="solid")


def _techdrive_module(app):
    return sys.modules[type(app).__module__]


def build_enable_disable_tools_tab(parent, app):
    """Build the local bundled-tool enable/disable manager."""
    theme = app.theme
    parent.configure(bg=theme["BG"])
    techdrive = _techdrive_module(app)
    registry = techdrive.PLUGIN_REGISTRY

    header = tk.Frame(parent, bg=theme["BG"])
    header.pack(fill="x", padx=18, pady=(16, 8))

    title_box = tk.Frame(header, bg=theme["BG"])
    title_box.pack(side="left", fill="x", expand=True)
    tk.Label(title_box, text="◈ Core Module Manager", bg=theme["BG"], fg=theme["FG"],
             font=FONT_CARD_TITLE, anchor="w").pack(fill="x")
    tk.Label(title_box,
             text="Manage bundled TechDrive Core modules. Disabled modules disappear from All Tools and search until re-enabled.",
             bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI, anchor="w").pack(fill="x", pady=(3, 0))

    action_box = tk.Frame(header, bg=theme["BG"])
    action_box.pack(side="right", anchor="n")

    body = tk.Frame(parent, bg=theme["BG"])
    body.pack(fill="both", expand=True, padx=18, pady=(0, 16))

    # Search/filter controls
    controls = tk.Frame(body, bg=theme["BG"])
    controls.pack(fill="x", pady=(0, 10))
    search_var = tk.StringVar()
    search = tk.Entry(controls, textvariable=search_var, bg=theme["CARD_BG"], fg=theme["FG"],
                      insertbackground=theme["FG"], relief="flat", font=FONT_UI)
    search.pack(side="left", fill="x", expand=True, ipady=7, padx=(0, 8))
    categories = [ALL_CATEGORIES] + sorted({c for p in registry.values() for c in p.get("categories", [])})
    cat_var = tk.StringVar(value=ALL_CATEGORIES)
    combo = ttk.Combobox(controls, textvariable=cat_var, values=categories,
                         state="readonly", width=22, font=FONT_UI)
    combo.pack(side="left")

    status_var = tk.StringVar()
    status = tk.Label(body, textvariable=status_var, bg=theme["BG"], fg=theme["MUTED"],
                      font=FONT_UI, anchor="w")
    status.pack(fill="x", pady=(0, 8))

    canvas = tk.Canvas(body, bg=theme["BG"], highlightthickness=0, bd=0)
    scrollbar = ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
    grid = tk.Frame(canvas, bg=theme["BG"])
    window_id = canvas.create_window((0, 0), window=grid, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    canvas._wheel_scrollable = True

    def sync_scroll(_event=None):
        canvas.configure(scrollregion=canvas.bbox("all"))
        bbox = canvas.bbox("all")
        if bbox and bbox[3] > canvas.winfo_height() + 2:
            if not scrollbar.winfo_ismapped():
                scrollbar.pack(side="right", fill="y")
        elif scrollbar.winfo_ismapped():
            scrollbar.pack_forget()
            canvas.yview_moveto(0)

    grid.bind("<Configure>", sync_scroll)
    canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))

    def enabled(modname):
        return techdrive.is_plugin_enabled(modname)

    def update_header():
        total = len(registry)
        on = sum(1 for m in registry if enabled(m))
        off = total - on
        status_var.set(f"{on} enabled  •  {off} disabled  •  {total} bundled Core modules")

    def refresh_all():
        update_header()
        render()

    def enable_all():
        changed = 0
        for modname in registry:
            if not enabled(modname) and app.enable_app_plugin(modname):
                changed += 1
        app._refresh_tool_widgets()
        app.status_text.set(f"Enabled {changed} Core modules" if changed else "All Core modules are already enabled")
        refresh_all()

    def disable_all():
        if not messagebox.askyesno(
            "Disable all optional tools",
            "Disable all optional Core modules? TechDrive Core will remain available.",
            parent=parent,
        ):
            return
        changed = 0
        for modname in list(registry):
            if enabled(modname) and app.disable_app_plugin(modname):
                changed += 1
        app._refresh_tool_widgets()
        app.status_text.set(f"Disabled {changed} Core modules")
        refresh_all()

    tk.Button(action_box, text="Enable all", command=enable_all, bg=theme["ACCENT"], fg=theme["ON_ACCENT"],
              relief="flat", bd=0, font=FONT_UI_BOLD, cursor="hand2", padx=10, pady=5).pack(side="left", padx=(0, 6))
    tk.Button(action_box, text="Disable all", command=disable_all, bg=theme["CARD_BG"], fg=theme["FG"],
              relief="flat", bd=0, font=FONT_UI, cursor="hand2", padx=10, pady=5).pack(side="left")

    def render():
        for child in grid.winfo_children():
            child.destroy()
        query = search_var.get().strip().casefold()
        category = cat_var.get()
        results = []
        for plugin in sorted(registry.values(), key=lambda p: p.get("name", "").casefold()):
            cats = plugin.get("categories", [])
            haystack = " ".join([plugin.get("name", ""), *cats]).casefold()
            if category != ALL_CATEGORIES and category not in cats:
                continue
            if query and query not in haystack:
                continue
            results.append(plugin)

        if not results:
            tk.Label(grid, text="No Core modules match your filter.", bg=theme["BG"], fg=theme["MUTED"],
                     font=FONT_UI).pack(pady=48)
            sync_scroll()
            return

        for col in range(2):
            grid.columnconfigure(col, weight=1, uniform="tools")
        for i, plugin in enumerate(results):
            card = _build_tool_card(grid, theme, app, plugin, enabled, refresh_all)
            card.grid(row=i // 2, column=i % 2, sticky="nsew", padx=5, pady=5)
        sync_scroll()

    search_var.trace_add("write", lambda *_: render())
    combo.bind("<<ComboboxSelected>>", lambda _e: render())
    render()
    search.focus_set()


def _build_tool_card(parent, theme, app, plugin, enabled_fn, refresh):
    card = _card(parent, theme)
    pad = tk.Frame(card, bg=theme["CARD_BG"])
    pad.pack(fill="both", expand=True, padx=14, pady=12)

    top = tk.Frame(pad, bg=theme["CARD_BG"])
    top.pack(fill="x")
    tk.Label(top, text=plugin.get("icon", "◇"), bg=theme["CARD_BG"], fg=theme["FG"],
             font=("Segoe UI Emoji", 20)).pack(side="left")
    title = tk.Frame(top, bg=theme["CARD_BG"])
    title.pack(side="left", fill="x", expand=True, padx=(10, 0))
    tk.Label(title, text=plugin.get("name", plugin["id"]), bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI_BOLD, anchor="w").pack(fill="x")
    tk.Label(title, text=", ".join(plugin.get("categories", [])), bg=theme["CARD_BG"], fg=theme["MUTED"],
             font=("Segoe UI", 8), anchor="w").pack(fill="x")

    count = plugin.get("tool_count", 0)
    word = "tool" if count == 1 else "tools"
    tk.Label(pad, text=f"{count} {word}", bg=theme["CARD_BG"], fg=theme["FG"],
             font=FONT_UI, anchor="w").pack(fill="x", pady=(8, 8))

    status = tk.Label(pad, bg=theme["CARD_BG"], font=FONT_UI_BOLD, anchor="w")
    status.pack(fill="x")

    bottom = tk.Frame(pad, bg=theme["CARD_BG"])
    bottom.pack(fill="x", pady=(8, 0))
    button = tk.Label(bottom, cursor="hand2", font=FONT_UI_BOLD, padx=14, pady=5)
    button.pack(side="right")

    def update():
        on = enabled_fn(plugin["id"])
        if on:
            status.config(text="● Enabled", fg=theme["ACCENT"])
            button.config(text="Disable", bg=theme["CARD_BG"], fg=theme["FG"])
        else:
            status.config(text="○ Disabled", fg=theme["MUTED"])
            button.config(text="Enable", bg=theme["ACCENT"], fg=theme["ON_ACCENT"])

    def toggle(_event=None):
        modname = plugin["id"]
        try:
            if enabled_fn(modname):
                ok = app.disable_app_plugin(modname)
                action = "Disabled"
            else:
                ok = app.enable_app_plugin(modname)
                action = "Enabled"
            if not ok:
                raise RuntimeError(f"Could not change state for {modname}")
            app.status_text.set(f"{action}: {plugin.get('name', modname)}")
            refresh()
        except Exception as exc:
            messagebox.showerror("Tool state", f"Could not change this tool group.\n\n{exc}", parent=card)

    button.bind("<Button-1>", toggle)
    card.bind("<Double-Button-1>", toggle)
    update()
    return card
