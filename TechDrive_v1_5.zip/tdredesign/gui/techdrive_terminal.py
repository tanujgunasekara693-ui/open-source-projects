#!/usr/bin/env python3
import os, platform, subprocess, threading, ctypes, tkinter as tk
from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton
class TechDriveTerminalPage(tk.Frame):
 def __init__(self,parent,app):
  super().__init__(parent,bg=app.theme['BG']); self.app=app; self.theme=app.theme; self.aero=app.is_aero_enabled(); self.history=[]; self.history_index=None; self._build()
 def _build(self):
  th=self.theme; h=tk.Frame(self,bg=th['BG']); h.pack(fill='x',padx=24,pady=(22,8)); tk.Label(h,text='TECHDRIVE CORE  /  TERMINAL',bg=th['BG'],fg=th['ACCENT_GLOW'],font=fl.F_TINY()).pack(anchor='w'); tk.Label(h,text='TechDrive Terminal',bg=th['BG'],fg=th['FG'],font=fl.F_TITLE()).pack(anchor='w'); admin='Administrator' if self._is_admin() else 'Standard user'; tk.Label(h,text=f'Integrated Windows terminal • permission context: {admin} • commands run with current user rights',bg=th['BG'],fg=th['MUTED'],font=fl.F_SMALL()).pack(anchor='w')
  card=GlassCard(self,th,aero=self.aero,accent=th['ACCENT'],gradient=False); card.pack(fill='both',expand=True,padx=24,pady=8); out=tk.Text(card.body,bg='#05070b',fg='#d8f7ff',insertbackground='#d8f7ff',font=('Consolas',10),wrap='word',borderwidth=0,state='disabled'); out.pack(fill='both',expand=True,padx=12,pady=(12,8)); self.out=out; out.insert('end',f'TECHDRIVE TERMINAL\n{self._prompt()} ')
  row=tk.Frame(card.body,bg=card.fill); row.pack(fill='x',padx=12,pady=(0,12)); self.cmd=tk.Entry(row,bg=th['SURFACE'],fg=th['FG'],insertbackground=th['FG'],font=('Consolas',10),relief='flat'); self.cmd.pack(side='left',fill='x',expand=True,ipady=7); FluentButton(row,'RUN',theme=th,aero=self.aero,kind='accent',width=80,height=32,command=self.run,backdrop=card.fill).pack(side='left',padx=(8,0)); FluentButton(row,'CLEAR',theme=th,aero=self.aero,kind='subtle',width=80,height=32,command=self._clear,backdrop=card.fill).pack(side='left',padx=(6,0)); self.cmd.bind('<Return>',lambda e:self.run()); self.cmd.bind('<Up>',self._history_up); self.cmd.focus_set(); out.bind('<Control-c>',lambda e:self._copy_selection()); out.bind('<Control-v>',lambda e:self._paste()); out.bind('<Control-l>',lambda e:self._clear())
 def _prompt(self): return 'C:\\>' if platform.system()=='Windows' else '$ '
 def _is_admin(self):
  if platform.system()!='Windows': return False
  try:return bool(ctypes.windll.shell32.IsUserAnAdmin())
  except Exception:return False
 def _write(self,text):
  self.out.config(state='normal'); self.out.insert('end',text); self.out.see('end'); self.out.config(state='disabled')
 def _clear(self):
  self.out.config(state='normal'); self.out.delete('1.0','end'); self.out.config(state='disabled'); self._write(f'TECHDRIVE TERMINAL\n{self._prompt()} ')
 def _copy_selection(self):
  try:self.clipboard_clear(); self.clipboard_append(self.out.selection_get())
  except Exception:pass
 def _paste(self):
  try:self.cmd.insert('insert',self.clipboard_get())
  except Exception:pass
 def _history_up(self,event=None):
  if not self.history:return 'break'
  if self.history_index is None:self.history_index=len(self.history)
  self.history_index=max(0,self.history_index-1); self.cmd.delete(0,'end'); self.cmd.insert(0,self.history[self.history_index]); return 'break'
 def run(self):
  command=self.cmd.get().strip()
  if not command:return
  self.history.append(command); self.history_index=None; self._write(command+'\n'); self.cmd.delete(0,'end')
  if platform.system()!='Windows': self._write('Windows terminal is unavailable on this platform.\n'+self._prompt()+' '); return
  def worker():
   try:
    p=subprocess.run(['cmd.exe','/d','/s','/c',command],capture_output=True,text=True,errors='replace',timeout=120,cwd=os.path.expanduser('~')); text=(p.stdout or '')+(p.stderr or ''); text=text or '(command completed with no output)'; text += f'\n[exit code {p.returncode}]' if p.returncode else ''
   except subprocess.TimeoutExpired:text='[TechDrive] Command timed out after 120 seconds.'
   except Exception as e:text=f'[TechDrive] Terminal error: {e}'
   self.app._post_ui(lambda t=text: self._write(t.rstrip()+'\n'+self._prompt()+' '))
  threading.Thread(target=worker,daemon=True).start()
