#!/usr/bin/env python3
"""Live Update metric cards — ongoing progress on the dashboard."""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.widgets import GlassCard, round_rect
from gui.motion import motion_enabled, tween, ease_out_quint

try:
    import psutil
except ImportError:
    psutil = None


class LiveUpdateStrip(tk.Frame):
    """Compact row of live metric cards that refresh in place."""

    def __init__(self, parent, app, theme, aero=False):
        super().__init__(parent, bg=theme["BG"])
        self.app = app
        self.theme = theme
        self.aero = aero
        self._job = None
        self._canvases = {}
        self._build()
        self._tick()

    def _build(self):
        th = self.theme
        header = tk.Frame(self, bg=th["BG"])
        header.pack(fill="x", pady=(0, 6))
        tk.Label(
            header, text="LIVE", bg=th["BG"], fg=th["MUTED"],
            font=("Segoe UI", 9, "bold"),
        ).pack(side="left")
        self._scan_lbl = tk.Label(
            header, text="", bg=th["BG"], fg=th.get("ACCENT", "#0a84ff"),
            font=("Segoe UI", 9),
        )
        self._scan_lbl.pack(side="right")

        row = tk.Frame(self, bg=th["BG"])
        row.pack(fill="x")
        for i, key in enumerate(("cpu", "ram", "disk")):
            row.columnconfigure(i, weight=1, uniform="live")
            card = GlassCard(row, th, aero=self.aero, backdrop=th["BG"], padding=10)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0))
            body = card.body
            body.configure(bg=card.fill)
            title = {"cpu": "CPU", "ram": "Memory", "disk": "Disk"}.get(key, key)
            tk.Label(body, text=title, bg=card.fill, fg=th["MUTED"],
                     font=("Segoe UI", 9)).pack(anchor="w")
            val = tk.Label(body, text="—", bg=card.fill, fg=th["FG"],
                           font=("Segoe UI", 16, "bold"))
            val.pack(anchor="w")
            cv = tk.Canvas(body, height=6, bg=card.fill, highlightthickness=0, bd=0)
            cv.pack(fill="x", pady=(6, 0))
            self._canvases[key] = (val, cv, card.fill)
            card.enable_autofit()

    def _tick(self):
        if not self.winfo_exists():
            return
        cpu = ram = disk = None
        if psutil:
            try:
                cpu = float(psutil.cpu_percent(interval=None))
            except Exception:
                pass
            try:
                ram = float(psutil.virtual_memory().percent)
            except Exception:
                pass
            try:
                disk = float(psutil.disk_usage("/").percent) if hasattr(psutil, "disk_usage") else None
                # Windows C:
                import os
                if os.name == "nt":
                    disk = float(psutil.disk_usage("C:\\").percent)
            except Exception:
                pass
        self._set("cpu", cpu)
        self._set("ram", ram)
        self._set("disk", disk)
        scanning = bool(getattr(self.app, "_active_scan_count", 0))
        self._scan_lbl.configure(text="Scanning…" if scanning else "")
        if scanning:
            try:
                from gui.privacy_dots import signal_probe
                signal_probe(self.app, "scan", 2.0)
            except Exception:
                pass
        self._job = self.after(2000, self._tick)

    def _set(self, key, value):
        if key not in self._canvases:
            return
        lbl, cv, fill = self._canvases[key]
        th = self.theme
        if value is None:
            lbl.configure(text="—", fg=th["MUTED"])
            cv.delete("all")
            return
        color = th.get("ACCENT", "#0a84ff")
        if value >= 85:
            color = getattr(fl, "BAD", "#ff453a")
        elif value >= 65:
            color = getattr(fl, "WARN", "#ffd60a")
        prev = getattr(self, f"_prev_{key}", None)
        lbl.configure(text=f"{value:.0f}%", fg=color)
        cv.delete("all")
        w = max(cv.winfo_width(), 80)
        round_rect(cv, 0, 0, w, 6, r=3, fill=fl.mix(fill, "#ffffff", 0.08), outline="")
        target_w = max(4, int(w * min(1.0, value / 100.0)))
        # Animate bar width if change is noticeable
        if motion_enabled() and prev is not None and abs(prev - value) >= 1.5:
            start_w = max(4, int(w * min(1.0, prev / 100.0)))
            def update(t, c=cv, sw=start_w, tw=target_w, col=color, ww=w, ff=fill):
                try:
                    c.delete("all")
                    round_rect(c, 0, 0, ww, 6, r=3, fill=fl.mix(ff, "#ffffff", 0.08), outline="")
                    fw = int(sw + (tw - sw) * t)
                    round_rect(c, 0, 0, max(4, fw), 6, r=3, fill=col, outline="")
                except Exception:
                    pass
            try:
                tween(cv, 480, update, easing=ease_out_quint)
            except Exception:
                round_rect(cv, 0, 0, target_w, 6, r=3, fill=color, outline="")
        else:
            round_rect(cv, 0, 0, target_w, 6, r=3, fill=color, outline="")
        setattr(self, f"_prev_{key}", value)
