#!/usr/bin/env python3
"""
gui/doc_viewer.py — TechDrive document viewer (EULA + Help Center)
===================================================================
One themed, reusable reader window with a real menu bar:

    File   Save a copy... / Print... / Copy / Select All / Close
    View   Larger / Smaller / Reset text size, Wrap lines, Contents sidebar
    Go     Previous / Next section, Back / Forward, Top / Bottom, Sections >
    Find   Find... (Ctrl+F), Find Next (F3), Find Previous (Shift+F3)
    Help   window-specific shortcuts (e.g. "Open EULA", "Replay Welcome Tour")

plus a searchable contents sidebar, in-page find with highlighting, a
reading-progress status bar, and Back/Forward history.

Public API (techdrive.py resolves the bundled file paths and calls these):
    show_eula(app, path, section=None, help_items=None)
    show_help(app, path, topic=None, help_items=None)

Pure-Python/Tk only. No network access, no extra dependencies. Everything
degrades safely: a failure here must never take down the main app.
"""
import os
import re
import sys
import bisect
import tempfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from gui import fluent as fl

try:  # remembered text size (optional - the viewer works without the DB)
    from shared import database as db
except Exception:  # pragma: no cover
    db = None

_BANNER = re.compile(r"^={20,}\s*$")
_EULA_HEAD = re.compile(r"^(\d+\.\s.+|APPENDIX [A-Z].*|END OF AGREEMENT|KEY TERMS AT A GLANCE)$")
_CLAUSE = re.compile(r"^(\d+\.\d+(?:\.\d+)?)\s")
_INLINE = re.compile(r"(\*\*.+?\*\*|`[^`]+`|(?<![\w*])\*[^\s*][^*]*?\*(?![\w*]))")


# ----------------------------------------------------------------------
# Parsing -> list of section dicts: {"title", "blocks"}; a block is
# (kind, text) with kind in: h3 para lit mono bullet num row note title sub
# ----------------------------------------------------------------------
def _blocks_from_lines(lines):
    """Groups plain lines into paragraph / literal blocks. Hard-wrapped
    paragraphs are re-flowed so they wrap to the window width."""
    blocks, cur = [], []

    def flush():
        if not cur:
            return
        literal = any(l.startswith("  ") or re.search(r"\S {3,}\S", l) for l in cur)
        if literal:
            items = []
            for l in cur:
                if re.search(r"\S {3,}\S", l):
                    items.append(["mono", 0, l.rstrip()])
                    continue
                st, ind = l.strip(), len(l) - len(l.lstrip(" "))
                bul = re.match(r"[*-]\s+", st)
                item = bul or re.match(r"\(?[a-z0-9]{1,4}[.)]\s", st)
                if item or not items or items[-1][0] == "mono":
                    items.append(["bul" if bul else "lit", ind, st[bul.end():] if bul else st])
                else:
                    items[-1][2] += " " + st
            for kind, ind, txt in items:
                blocks.append(("bullet", txt) if kind == "bul" else
                              ("mono", txt) if kind == "mono" else ("lit", (ind, txt)))
        else:
            blocks.append(("para", " ".join(x.strip() for x in cur)))
        cur.clear()

    for line in lines:
        if not line.strip():
            flush()
        else:
            cur.append(line)
    flush()
    return blocks


def parse_eula(text):
    lines = text.splitlines()
    sections, cur = [], {"title": "Agreement", "blocks": []}
    head_n = 0
    i, pre = 0, []

    def close():
        nonlocal pre
        cur["blocks"] += _blocks_from_lines(pre)
        pre = []

    while i < len(lines):
        if _BANNER.match(lines[i]):
            j = i + 1
            while j < len(lines) and not _BANNER.match(lines[j]):
                j += 1
            inner = [l for l in lines[i + 1:j]]
            if inner and _EULA_HEAD.match(inner[0].strip()):
                close()
                sections.append(cur)
                cur = {"title": _smart_title(inner[0].strip()) if inner[0].isupper() else inner[0].strip(),
                       "blocks": []}
                note = [l for l in inner[1:] if l.strip()]
                if note:
                    cur["blocks"].append(("note", " ".join(x.strip() for x in note)))
                head_n += 1
            else:  # a banner-wrapped notice (e.g. the "PLEASE READ" block)
                close()
                cur["blocks"].append(("note", " ".join(x.strip() for x in inner if x.strip())))
            i = j + 1
            continue
        pre.append(lines[i])
        i += 1
    close()
    sections.append(cur)
    if sections and sections[0]["title"] == "Agreement":
        b = sections[0]["blocks"]
        # first two paragraph blocks are the title / subtitle lines
        flat = []
        for kind, val in b:
            flat.append((kind, val))
        sections[0]["blocks"] = flat
    # tidy section titles: "3. GRANT OF LICENSE" -> "3. Grant of License"
    for s in sections:
        t = s["title"]
        if re.match(r"^\d+\.\s", t) or t.startswith("Appendix"):
            s["title"] = _smart_title(t)
    return [s for s in sections if s["blocks"] or s["title"] != "Agreement"]


def _smart_title(t):
    small = {"and", "of", "to", "the", "or", "for", "on", "in", "a", "an", "as"}
    words = t.split(" ")
    out = []
    for n, w in enumerate(words):
        lw = w.lower()
        if w.startswith("(") and len(w) > 2:
            out.append(w[:2].upper() + w[2:].lower())
        elif re.match(r"^\d+\.?$", w) or w in ("—", "-"):
            out.append(w)
        elif lw in small and n:
            out.append(lw)
        elif w in ("EULA", "BIOS", "IP", "OS"):
            out.append(w)
        else:
            out.append(w[:1].upper() + w[1:].lower())
    return " ".join(out)


def parse_markdown(text):
    sections, cur, buf = [], {"title": "Overview", "blocks": []}, []

    def flush():
        if buf:
            cur["blocks"].append(("para", " ".join(x.strip() for x in buf)))
            buf.clear()

    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("## "):
            flush()
            if cur["blocks"]:
                sections.append(cur)
            cur = {"title": re.sub(r"^\d+\.\s*", "", line[3:].strip()), "blocks": []}
        elif line.startswith("# "):
            flush()
            cur["blocks"].append(("title", line[2:].strip()))
        elif line.startswith("### "):
            flush()
            cur["blocks"].append(("h3", line[4:].strip()))
        elif line.strip() in ("---", "***"):
            flush()
        elif line.startswith("|"):
            flush()
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if all(re.match(r"^:?-+:?$", c) for c in cells if c):
                continue
            cur["blocks"].append(("row", cells))
        elif re.match(r"^\s*[-*] ", line):
            flush()
            cur["blocks"].append(("bullet", re.sub(r"^\s*[-*] ", "", line)))
        elif re.match(r"^\d+\.\s", line):
            flush()
            cur["blocks"].append(("num", line))
        elif line.startswith("  ") and cur["blocks"] and cur["blocks"][-1][0] in ("bullet", "num"):
            k, v = cur["blocks"][-1]
            cur["blocks"][-1] = (k, v + " " + line.strip())
        elif not line.strip():
            flush()
        else:
            buf.append(line)
    flush()
    if cur["blocks"]:
        sections.append(cur)
    return sections


# ----------------------------------------------------------------------
class DocViewer(tk.Toplevel):
    def __init__(self, app, title, sections, source_text, *, subtitle="", footer="",
                 save_name="document.txt", help_items=None, geometry="980x700",
                 search_hint="Search contents…", key="doc"):
        super().__init__(app)
        self.app, self.sections, self.source, self.save_name = app, sections, source_text, save_name
        self.key = key
        th = getattr(app, "theme", None) or fl.DARK
        g = lambda k, d: th.get(k, d)
        self.c = dict(bg=g("BG", "#1c1c1e"), side=g("BG_LIGHT", "#232326"), panel=g("SURFACE", "#242427"),
                      fg=g("TEXT_FG", g("FG", "#e8e8ed")), head=g("FG", "#f5f5f7"), muted=g("MUTED", "#a1a1a6"),
                      accent=g("ACCENT", "#0a84ff"), glow=g("ACCENT_GLOW", "#5eb0ff"),
                      stroke=g("STROKE", "#48484a"), sel=g("SELECTION", "#0a3a75"), onacc=g("ON_ACCENT", "#ffffff"))
        self.title(title)
        self.configure(bg=self.c["bg"])
        self.geometry(geometry)
        self.minsize(640, 420)
        try:
            self.transient(app)
        except tk.TclError:
            pass

        self.size = 10
        if db:
            try:
                self.size = int(db.get_setting("doc_viewer_font", 10) or 10)
            except Exception:
                pass
        self.size = max(8, min(22, self.size))
        self._help_items = help_items or []
        self._hist, self._hpos, self._sync = [], -1, False
        self._starts, self._map = [], []
        self._hits, self._hit_i = [], -1
        self.wrap_var = tk.BooleanVar(value=True)
        self.side_var = tk.BooleanVar(value=True)
        self.case_var = tk.BooleanVar(value=False)
        self.filter_var = tk.StringVar()
        self.find_var = tk.StringVar()
        self._footer = footer

        self._build_menu()
        self._build_header(title, subtitle)
        self._build_body(search_hint)
        self._build_status()
        self._render()
        self._bind_keys()
        self._refill_list()
        self.update_idletasks()
        self._hist, self._hpos = [0], 0
        self._update_status()

    # ---------------- UI ----------------
    def _build_menu(self):
        mb = tk.Menu(self)
        f = tk.Menu(mb, tearoff=0)
        f.add_command(label="Save a copy…", accelerator="Ctrl+S", command=self.save_copy)
        f.add_command(label="Print…", accelerator="Ctrl+P", command=self.print_doc)
        f.add_separator()
        f.add_command(label="Copy", accelerator="Ctrl+C", command=self.copy_sel)
        f.add_command(label="Select All", accelerator="Ctrl+A", command=self.select_all)
        f.add_separator()
        f.add_command(label="Close", accelerator="Esc", command=self.destroy)
        mb.add_cascade(label="File", menu=f)

        v = tk.Menu(mb, tearoff=0)
        v.add_command(label="Larger Text", accelerator="Ctrl++", command=lambda: self.set_size(self.size + 1))
        v.add_command(label="Smaller Text", accelerator="Ctrl+-", command=lambda: self.set_size(self.size - 1))
        v.add_command(label="Reset Text Size", accelerator="Ctrl+0", command=lambda: self.set_size(10))
        v.add_separator()
        v.add_checkbutton(label="Wrap Lines", variable=self.wrap_var, command=self._apply_wrap)
        v.add_checkbutton(label="Contents Sidebar", variable=self.side_var, command=self._toggle_side)
        mb.add_cascade(label="View", menu=v)

        go = tk.Menu(mb, tearoff=0)
        go.add_command(label="Previous Section", accelerator="Alt+Up", command=lambda: self.step(-1))
        go.add_command(label="Next Section", accelerator="Alt+Down", command=lambda: self.step(1))
        go.add_separator()
        go.add_command(label="Back", accelerator="Alt+Left", command=self.back)
        go.add_command(label="Forward", accelerator="Alt+Right", command=self.forward)
        go.add_separator()
        go.add_command(label="Top", accelerator="Ctrl+Home", command=lambda: self.goto(0))
        go.add_command(label="Bottom", accelerator="Ctrl+End", command=lambda: self.text.yview_moveto(1.0))
        go.add_separator()
        sec = tk.Menu(go, tearoff=0)
        for i, s in enumerate(self.sections):
            sec.add_command(label=s["title"][:60], command=lambda i=i: self.goto(i),
                            columnbreak=(i and i % 20 == 0))
        go.add_cascade(label="Sections", menu=sec)
        mb.add_cascade(label="Go", menu=go)

        fd = tk.Menu(mb, tearoff=0)
        fd.add_command(label="Find…", accelerator="Ctrl+F", command=self.open_find)
        fd.add_command(label="Find Next", accelerator="F3", command=lambda: self.find_step(1))
        fd.add_command(label="Find Previous", accelerator="Shift+F3", command=lambda: self.find_step(-1))
        mb.add_cascade(label="Find", menu=fd)

        if self._help_items:
            h = tk.Menu(mb, tearoff=0)
            for it in self._help_items:
                if it is None:
                    h.add_separator()
                else:
                    h.add_command(label=it[0], command=it[1])
            mb.add_cascade(label="Help", menu=h)
        self.config(menu=mb)

    def _build_header(self, title, subtitle):
        c = self.c
        hdr = tk.Frame(self, bg=c["bg"])
        hdr.pack(fill="x", padx=16, pady=(12, 6))
        tk.Frame(self, bg=c["accent"], height=2).pack(fill="x", before=hdr)
        tk.Label(hdr, text=title, bg=c["bg"], fg=c["head"], font=fl.font(16, "bold", True)).pack(side="left")
        if subtitle:
            tk.Label(hdr, text="  " + subtitle, bg=c["bg"], fg=c["muted"], font=fl.font(9)).pack(
                side="left", pady=(6, 0))
        self.find_btn = tk.Button(hdr, text="Find  (Ctrl+F)", command=self.open_find, bg=c["panel"], fg=c["fg"],
                                  relief="flat", bd=0, padx=10, pady=3, activebackground=c["sel"],
                                  activeforeground=c["head"], cursor="hand2")
        self.find_btn.pack(side="right")

    def _build_body(self, search_hint):
        c = self.c
        self.findbar = tk.Frame(self, bg=c["side"])
        tk.Label(self.findbar, text="Find:", bg=c["side"], fg=c["muted"]).pack(side="left", padx=(16, 6), pady=6)
        self.find_entry = tk.Entry(self.findbar, textvariable=self.find_var, width=34, bg=c["panel"], fg=c["head"],
                                   insertbackground=c["head"], relief="flat", highlightthickness=1,
                                   highlightbackground=c["stroke"], highlightcolor=c["accent"])
        self.find_entry.pack(side="left", ipady=3)
        for t, d in (("▲", -1), ("▼", 1)):
            tk.Button(self.findbar, text=t, width=3, relief="flat", bd=0, bg=c["panel"], fg=c["fg"],
                      command=lambda d=d: self.find_step(d), cursor="hand2").pack(side="left", padx=(4, 0))
        tk.Checkbutton(self.findbar, text="Match case", variable=self.case_var, command=self._do_find,
                       bg=c["side"], fg=c["fg"], selectcolor=c["panel"], activebackground=c["side"],
                       activeforeground=c["head"]).pack(side="left", padx=10)
        self.find_info = tk.Label(self.findbar, text="", bg=c["side"], fg=c["muted"])
        self.find_info.pack(side="left")
        tk.Button(self.findbar, text="✕", relief="flat", bd=0, bg=c["side"], fg=c["muted"], cursor="hand2",
                  command=self.close_find).pack(side="right", padx=12)
        self.find_var.trace_add("write", lambda *_: self._do_find())

        self.body = tk.Frame(self, bg=c["bg"])
        self.body.pack(fill="both", expand=True, padx=(16, 16), pady=(4, 0))
        self.side = tk.Frame(self.body, bg=c["side"], width=290)
        self.side.pack(side="left", fill="y", padx=(0, 10))
        self.side.pack_propagate(False)
        se = tk.Entry(self.side, textvariable=self.filter_var, bg=c["panel"], fg=c["head"], relief="flat",
                      insertbackground=c["head"], highlightthickness=1, highlightbackground=c["stroke"],
                      highlightcolor=c["accent"])
        se.pack(fill="x", padx=8, pady=(8, 4), ipady=4)
        self._hint = search_hint
        se.insert(0, search_hint)
        se.configure(fg=c["muted"])
        se.bind("<FocusIn>", lambda e: self._hint_clear(se))
        se.bind("<FocusOut>", lambda e: self._hint_restore(se))
        self.filter_var.trace_add("write", lambda *_: self._refill_list())
        lw = tk.Frame(self.side, bg=c["side"])
        lw.pack(fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        self.lb = tk.Listbox(lw, bg=c["side"], fg=c["fg"], relief="flat", bd=0, highlightthickness=0,
                             activestyle="none", selectbackground=c["sel"], selectforeground=c["head"],
                             exportselection=False, font=fl.font(10))
        lsb = ttk.Scrollbar(lw, orient="vertical", command=self.lb.yview)
        self.lb.configure(yscrollcommand=lsb.set)
        self.lb.pack(side="left", fill="both", expand=True)
        lsb.pack(side="right", fill="y")
        self.lb.bind("<<ListboxSelect>>", self._on_list)

        main = tk.Frame(self.body, bg=c["panel"])
        main.pack(side="left", fill="both", expand=True)
        self.text = tk.Text(main, wrap="word", bg=c["panel"], fg=c["fg"], insertbackground=c["fg"], relief="flat",
                            bd=0, padx=22, pady=16, cursor="arrow", spacing1=2, spacing3=4,
                            selectbackground=c["sel"], selectforeground=c["head"], exportselection=True)
        self.vsb = ttk.Scrollbar(main, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=self._on_scroll)
        self.vsb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.text.bind("<Button-1>", lambda e: self.text.focus_set())
        self.text.bind("<Control-MouseWheel>", lambda e: (self.set_size(self.size + (1 if e.delta > 0 else -1)), "break")[1])

    def _build_status(self):
        c = self.c
        st = tk.Frame(self, bg=c["side"])
        st.pack(fill="x", side="bottom", pady=(8, 0))
        self.st_sec = tk.Label(st, text="", bg=c["side"], fg=c["fg"], anchor="w", font=fl.font(9))
        self.st_sec.pack(side="left", padx=16, pady=5)
        tk.Button(st, text="Close", command=self.destroy, relief="flat", bd=0, bg=c["accent"], fg=c["onacc"],
                  padx=14, pady=2, cursor="hand2", activebackground=c["glow"]).pack(side="right", padx=14, pady=4)
        self.st_pct = tk.Label(st, text="0%", bg=c["side"], fg=c["muted"], font=fl.font(9), width=6)
        self.st_pct.pack(side="right")
        if self._footer:
            tk.Label(st, text=self._footer, bg=c["side"], fg=c["muted"], font=fl.font(9)).pack(side="right", padx=10)

    # ---------------- rendering ----------------
    def _fonts(self):
        s, fam = self.size, fl.FAMILY_TEXT
        mono = fl.FAMILY_MONO
        t = self.text
        c = self.c
        t.configure(font=(fam, s))
        t.tag_configure("title", font=(fl.FAMILY_DISPLAY, s + 8, "bold"), foreground=c["head"], spacing3=8)
        t.tag_configure("h2", font=(fl.FAMILY_DISPLAY, s + 5, "bold"), foreground=c["glow"], spacing1=18, spacing3=6)
        t.tag_configure("h3", font=(fam, s + 1, "bold"), foreground=c["head"], spacing1=10, spacing3=3)
        t.tag_configure("bold", font=(fam, s, "bold"), foreground=c["head"])
        t.tag_configure("ital", font=(fam, s, "italic"))
        t.tag_configure("code", font=(mono, s - 1), background=c["side"], foreground=c["glow"])
        t.tag_configure("mono", font=(mono, s - 1), lmargin1=18, lmargin2=18, spacing1=0, spacing3=0)
        t.tag_configure("clause", font=(fam, s, "bold"), foreground=c["glow"])
        t.tag_configure("note", font=(fam, s - 1), foreground=c["muted"], lmargin1=14, lmargin2=14,
                        background=c["side"], spacing1=4, spacing3=8)
        t.tag_configure("bullet", lmargin1=18, lmargin2=34)
        t.tag_configure("num", lmargin1=18, lmargin2=36)
        t.tag_configure("row", font=(fam, s), lmargin1=18, tabs=("180", "left"), spacing1=3)
        t.tag_configure("rowhead", font=(fam, s, "bold"), foreground=c["muted"])
        t.tag_configure("hit", background="#5a4a00", foreground="#ffffff")
        t.tag_configure("cur", background="#ffd60a", foreground="#000000")
        for n in range(1, 9):
            t.tag_configure(f"ind{n}", lmargin1=n * 14, lmargin2=n * 14)
        t.tag_raise("hit")
        t.tag_raise("cur")
        t.tag_raise("sel")

    def _inline(self, line, tags=()):
        t, pos = self.text, 0
        for m in _INLINE.finditer(line):
            if m.start() > pos:
                t.insert("end", line[pos:m.start()], tags)
            tok = m.group(0)
            kind = "bold" if tok.startswith("**") else ("code" if tok[0] == "`" else "ital")
            t.insert("end", tok[2:-2] if kind == "bold" else tok[1:-1], tuple(tags) + (kind,))
            pos = m.end()
        t.insert("end", line[pos:], tags)

    def _render(self):
        t = self.text
        t.configure(state="normal")
        t.delete("1.0", "end")
        self._fonts()
        for i, s in enumerate(self.sections):
            t.mark_set(f"sec{i}", "end-1c")
            t.mark_gravity(f"sec{i}", "left")
            if i or s["title"] not in ("Overview", "Agreement"):
                t.insert("end", s["title"] + "\n", "h2")
            first_row = True
            for kind, val in s["blocks"]:
                if kind != "row":
                    first_row = True
                if kind == "title":
                    t.insert("end", val + "\n", "title")
                elif kind == "h3":
                    t.insert("end", val + "\n", "h3")
                elif kind == "note":
                    t.insert("end", val + "\n", "note")
                elif kind == "para":
                    m = _CLAUSE.match(val)
                    if m:
                        t.insert("end", m.group(1) + "  ", "clause")
                        self._inline(val[m.end():] + "\n")
                    else:
                        self._inline(val + "\n")
                elif kind == "lit":
                    ind, body = val
                    tag = f"ind{min(8, max(0, ind // 2))}" if ind else ()
                    self._inline(body + "\n", (tag,) if tag else ())
                elif kind == "mono":
                    t.insert("end", val + "\n", "mono")
                elif kind == "bullet":
                    t.insert("end", "•  ", "bullet")
                    self._inline(val + "\n", ("bullet",))
                elif kind == "num":
                    self._inline(val + "\n", ("num",))
                elif kind == "row":
                    tags = ("row", "rowhead") if first_row else ("row",)
                    t.insert("end", "\t".join(val) + "\n", tags)
                    first_row = False
        t.configure(state="disabled")
        self._starts = [int(t.index(f"sec{i}").split(".")[0]) for i in range(len(self.sections))]

    def set_size(self, n):
        self.size = max(8, min(22, n))
        if db:
            try:
                db.set_setting("doc_viewer_font", self.size)
            except Exception:
                pass
        cur = self._cur_section()
        self._fonts()
        self.update_idletasks()
        self.goto(cur, record=False)
        if self.find_var.get():
            self._do_find(keep=True)

    def _apply_wrap(self):
        self.text.configure(wrap="word" if self.wrap_var.get() else "none")

    def _toggle_side(self):
        if self.side_var.get():
            self.side.pack(side="left", fill="y", padx=(0, 10), before=self.text.master)
        else:
            self.side.pack_forget()

    # ---------------- navigation ----------------
    def _cur_section(self):
        try:
            line = int(self.text.index("@0,0").split(".")[0])
        except Exception:
            return 0
        return max(0, bisect.bisect_right(self._starts, line + 1) - 1)

    def goto(self, i, record=True):
        if not self.sections:
            return
        i = max(0, min(len(self.sections) - 1, i))
        self.text.yview(f"sec{i}")
        if record:
            if self._hpos < len(self._hist) - 1:
                del self._hist[self._hpos + 1:]
            if not self._hist or self._hist[-1] != i:
                self._hist.append(i)
            self._hpos = len(self._hist) - 1
        self._update_status()

    def step(self, d):
        self.goto(self._cur_section() + d)

    def back(self):
        if self._hpos > 0:
            self._hpos -= 1
            self.goto(self._hist[self._hpos], record=False)

    def forward(self):
        if self._hpos < len(self._hist) - 1:
            self._hpos += 1
            self.goto(self._hist[self._hpos], record=False)

    def goto_title(self, name):
        name = (name or "").lower()
        for i, s in enumerate(self.sections):
            if name and name in s["title"].lower():
                self.goto(i)
                return True
        return False

    def _on_scroll(self, a, b):
        self.vsb.set(a, b)
        self._update_status()

    def _update_status(self):
        i = self._cur_section()
        try:
            self.st_sec.config(text=self.sections[i]["title"])
            first, last = self.text.yview()
            self.st_pct.config(text=("100%" if last >= 0.999 else f"{int(first * 100)}%"))
        except Exception:
            return
        self._sync = True
        try:
            for pos, si in enumerate(self._map):
                if si == i:
                    self.lb.selection_clear(0, "end")
                    self.lb.selection_set(pos)
                    self.lb.see(pos)
                    break
        finally:
            self.after(30, lambda: setattr(self, "_sync", False))

    # ---------------- sidebar ----------------
    def _hint_clear(self, e):
        if self.filter_var.get() == self._hint:
            e.delete(0, "end")
            e.configure(fg=self.c["head"])

    def _hint_restore(self, e):
        if not e.get():
            e.insert(0, self._hint)
            e.configure(fg=self.c["muted"])

    def _refill_list(self):
        q = self.filter_var.get().strip().lower()
        if q == self._hint.lower():
            q = ""
        self.lb.delete(0, "end")
        self._map = []
        for i, s in enumerate(self.sections):
            hay = s["title"].lower()
            if q:
                hay += " " + " ".join(str(b[1]) for b in s["blocks"]).lower()
            if not q or q in hay:
                self.lb.insert("end", "  " + s["title"])
                self._map.append(i)

    def _on_list(self, _e):
        if self._sync:
            return
        sel = self.lb.curselection()
        if sel:
            self.goto(self._map[sel[0]])

    # ---------------- find ----------------
    def open_find(self):
        if not self.findbar.winfo_ismapped():
            self.findbar.pack(fill="x", before=self.body)
        self.find_entry.focus_set()
        self.find_entry.select_range(0, "end")

    def close_find(self):
        self.findbar.pack_forget()
        self.text.tag_remove("hit", "1.0", "end")
        self.text.tag_remove("cur", "1.0", "end")
        self.find_info.config(text="")
        self.text.focus_set()

    def _do_find(self, keep=False):
        t = self.text
        t.tag_remove("hit", "1.0", "end")
        t.tag_remove("cur", "1.0", "end")
        self._hits = []
        q = self.find_var.get()
        if len(q) < 2:
            self.find_info.config(text="")
            return
        start, nocase = "1.0", not self.case_var.get()
        cnt = tk.IntVar()
        while True:
            pos = t.search(q, start, stopindex="end", nocase=nocase, count=cnt)
            if not pos or not cnt.get():
                break
            end = f"{pos}+{cnt.get()}c"
            t.tag_add("hit", pos, end)
            self._hits.append((pos, end))
            start = end
        if not self._hits:
            self.find_info.config(text="No matches", fg="#ff6b6b")
            return
        self.find_info.config(fg=self.c["muted"])
        if not keep:
            self._hit_i = -1
            self.find_step(1)
        else:
            self._show_hit()

    def find_step(self, d):
        if not self._hits:
            self.open_find()
            return
        self._hit_i = (self._hit_i + d) % len(self._hits)
        self._show_hit()

    def _show_hit(self):
        t = self.text
        t.tag_remove("cur", "1.0", "end")
        pos, end = self._hits[self._hit_i]
        t.tag_add("cur", pos, end)
        t.see(pos)
        self.find_info.config(text=f"{self._hit_i + 1} of {len(self._hits)}")

    # ---------------- file / clipboard ----------------
    def save_copy(self):
        path = filedialog.asksaveasfilename(parent=self, defaultextension=os.path.splitext(self.save_name)[1],
                                            initialfile=self.save_name)
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.source)
            messagebox.showinfo(self.title(), f"Saved a copy to:\n{path}", parent=self)
        except OSError as e:
            messagebox.showerror(self.title(), f"Couldn't save the file:\n{e}", parent=self)

    def print_doc(self):
        try:
            if sys.platform.startswith("win"):
                fd, path = tempfile.mkstemp(suffix=".txt", prefix="techdrive_")
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(self.source)
                os.startfile(path, "print")  # noqa: S606 - user-initiated, local temp file
                return
        except Exception:
            pass
        messagebox.showinfo(self.title(), "Printing from here is only available on Windows.\n"
                            "Use File → Save a copy… and print the saved file instead.", parent=self)

    def copy_sel(self):
        try:
            txt = self.text.get("sel.first", "sel.last")
        except tk.TclError:
            return
        self.clipboard_clear()
        self.clipboard_append(txt)

    def select_all(self):
        self.text.tag_add("sel", "1.0", "end")

    # ---------------- keys ----------------
    def _bind_keys(self):
        b = self.bind
        b("<Escape>", lambda e: self.close_find() if self.findbar.winfo_ismapped() else self.destroy())
        b("<Control-f>", lambda e: (self.open_find(), "break")[1])
        b("<F3>", lambda e: self.find_step(1))
        b("<Shift-F3>", lambda e: self.find_step(-1))
        self.find_entry.bind("<Return>", lambda e: self.find_step(1))
        self.find_entry.bind("<Shift-Return>", lambda e: self.find_step(-1))
        b("<Control-s>", lambda e: self.save_copy())
        b("<Control-p>", lambda e: self.print_doc())
        b("<Control-a>", lambda e: (self.select_all(), "break")[1])
        for k in ("<Control-plus>", "<Control-equal>", "<Control-KP_Add>"):
            b(k, lambda e: self.set_size(self.size + 1))
        for k in ("<Control-minus>", "<Control-KP_Subtract>"):
            b(k, lambda e: self.set_size(self.size - 1))
        b("<Control-0>", lambda e: self.set_size(10))
        b("<Alt-Left>", lambda e: self.back())
        b("<Alt-Right>", lambda e: self.forward())
        b("<Alt-Up>", lambda e: self.step(-1))
        b("<Alt-Down>", lambda e: self.step(1))
        b("<Control-Home>", lambda e: self.goto(0))
        b("<Control-End>", lambda e: self.text.yview_moveto(1.0))
        self.text.focus_set()


# ----------------------------------------------------------------------
def _reuse(app, key):
    reg = getattr(app, "_doc_windows", None)
    if reg is None:
        reg = app._doc_windows = {}
    w = reg.get(key)
    try:
        if w is not None and w.winfo_exists():
            w.deiconify()
            w.lift()
            w.focus_force()
            return w
    except tk.TclError:
        pass
    return None


def _remember(app, key, win):
    app._doc_windows[key] = win


def show_eula(app, path, section=None, help_items=None):
    win = _reuse(app, "eula")
    if win is None:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        ver = re.search(r"^Version\s+(\S+)", text, re.M)
        eff = re.search(r"^Effective Date:\s*(.+)$", text, re.M)
        foot = "  ·  ".join(x for x in (f"Version {ver.group(1)}" if ver else "",
                                         f"Effective {eff.group(1).strip()}" if eff else "") if x)
        win = DocViewer(app, "End User License Agreement", parse_eula(text), text,
                        subtitle="Terms of Use", footer=foot, save_name="TechDrive_EULA.txt",
                        help_items=help_items, search_hint="Search sections…", key="eula")
        _remember(app, "eula", win)
    if section:
        win.goto_title(section)
    return win


def show_help(app, path, topic=None, help_items=None):
    win = _reuse(app, "help")
    if win is None:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        win = DocViewer(app, "TechDrive Help Center", parse_markdown(text), text,
                        subtitle="User Manual  ·  press F1 any time", footer="TechDrive v1.1",
                        save_name="TechDrive_User_Manual.md", help_items=help_items,
                        search_hint="Search help topics…", key="help")
        _remember(app, "help", win)
    if topic:
        win.goto_title(topic)
    return win
