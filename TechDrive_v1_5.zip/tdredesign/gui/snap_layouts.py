#!/usr/bin/env python3
"""Snap Layouts overlay — Win11-style templates with Apple spring polish for Stage Manager."""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.widgets import round_rect

LAYOUTS = [
    ("50/50", "two", ((0, 0, 0.5, 1), (0.5, 0, 0.5, 1))),
    ("67/33", "two_left", ((0, 0, 0.67, 1), (0.67, 0, 0.33, 1))),
    ("33/67", "two_right", ((0, 0, 0.33, 1), (0.33, 0, 0.67, 1))),
    ("33/33/33", "three", ((0, 0, 0.33, 1), (0.33, 0, 0.34, 1), (0.67, 0, 0.33, 1))),
    ("50/50 tall", "quad_top", ((0, 0, 0.5, 0.5), (0.5, 0, 0.5, 0.5), (0, 0.5, 1, 0.5))),
]


class SnapLayoutsOverlay(tk.Toplevel):
    """Flyout to pick a Stage snap template."""

    def __init__(self, app, on_pick=None):
        super().__init__(app)
        self.app = app
        self.theme = app.theme
        self.on_pick = on_pick
        self.overrideredirect(True)
        self.configure(bg=self.theme.get("STROKE", "#333"))
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        w, h = 340, 200
        try:
            ax = app.winfo_rootx() + max(40, app.winfo_width() - w - 40)
            ay = app.winfo_rooty() + 80
        except Exception:
            ax, ay = 100, 100
        self.geometry(f"{w}x{h}+{ax}+{ay}")
        self.transient(app)
        self.bind("<Escape>", lambda e: self.destroy())
        self._build()
        try:
            from gui.acrylic import apply_acrylic
            apply_acrylic(self, opacity=170)
        except Exception:
            pass

    def _build(self):
        th = self.theme
        outer = tk.Frame(self, bg=th.get("LAYER_1", th["BG"]))
        outer.pack(fill="both", expand=True, padx=2, pady=2)
        tk.Label(
            outer, text="SNAP LAYOUT", bg=outer["bg"], fg=th["MUTED"],
            font=("Segoe UI", 8, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 6))
        row = tk.Frame(outer, bg=outer["bg"])
        row.pack(fill="both", expand=True, padx=8, pady=(0, 10))
        for i, (label, key, regions) in enumerate(LAYOUTS):
            cell = tk.Canvas(
                row, width=56, height=44, bg=th.get("LAYER_2", th["CARD_BG"]),
                highlightthickness=1, highlightbackground=th.get("STROKE", "#444"),
                cursor="hand2",
            )
            cell.grid(row=0, column=i, padx=4, pady=4)
            self._draw_layout(cell, regions, th)
            cell.bind("<Button-1>", lambda e, k=key, r=regions: self._pick(k, r))
            tk.Label(row, text=label, bg=outer["bg"], fg=th["MUTED"],
                     font=("Segoe UI", 7)).grid(row=1, column=i)

    def _draw_layout(self, canvas, regions, th):
        canvas.delete("all")
        w, h = 56, 44
        pad = 4
        accent = th.get("ACCENT", "#0a84ff")
        for rx, ry, rw, rh in regions:
            x1 = pad + rx * (w - 2 * pad)
            y1 = pad + ry * (h - 2 * pad)
            x2 = x1 + rw * (w - 2 * pad) - 1
            y2 = y1 + rh * (h - 2 * pad) - 1
            round_rect(canvas, x1, y1, x2, y2, r=3, fill=accent, outline="")

    def _pick(self, key, regions):
        if callable(self.on_pick):
            try:
                self.on_pick(key, regions)
            except Exception:
                pass
        self.destroy()


def show_snap_layouts(app, on_pick=None):
    return SnapLayoutsOverlay(app, on_pick=on_pick)
