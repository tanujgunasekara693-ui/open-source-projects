"""Optional Qt Quick dashboard companion for TechDrive.

Launch with ``python -m gui.qml_dashboard`` after installing PySide6.
The original Tk dashboard remains available if PySide6 is not installed.
"""
import os
import platform
import sys

from PySide6.QtCore import QObject, QTimer, Signal, Slot, QUrl
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine

try:
    import psutil
except ImportError:
    psutil = None


class SystemBridge(QObject):
    metricsChanged = Signal(str, str, str, str)

    def __init__(self):
        super().__init__()
        self._timer = QTimer(self)
        self._timer.setInterval(1800)
        self._timer.timeout.connect(self.refresh)
        self._timer.start()
        self.refresh()

    @Slot()
    def refresh(self):
        cpu, ram, disk = "Unavailable", "Unavailable", "Unavailable"
        try:
            if psutil:
                cpu = f"{psutil.cpu_percent(interval=None):.0f}%"
                vm = psutil.virtual_memory()
                ram = f"{vm.percent:.0f}%"
                root = os.environ.get("SystemDrive", "C:") + "\\" if os.name == "nt" else "/"
                disk = f"{psutil.disk_usage(root).percent:.0f}%"
        except Exception:
            pass
        host = f"{platform.system()} {platform.release()}  ·  {platform.machine()}"
        self.metricsChanged.emit(cpu, ram, disk, host)


def main():
    # Qt Quick selects its best available RHI backend on the current system.
    # User/environment forced software rendering starts in the light mode.
    software = (os.environ.get("QT_QUICK_BACKEND", "").lower() == "software" or
                os.environ.get("QSG_RHI_BACKEND", "").lower() == "software" or
                "--software" in sys.argv)
    if software:
        os.environ.setdefault("QT_QUICK_BACKEND", "software")
    app = QGuiApplication(sys.argv)
    engine = QQmlApplicationEngine()
    bridge = SystemBridge()
    engine.rootContext().setContextProperty("systemBridge", bridge)
    qml_path = os.path.join(os.path.dirname(__file__), "techdrive_glass.qml")
    engine.load(QUrl.fromLocalFile(qml_path))
    if not engine.rootObjects():
        return 2
    if software:
        engine.rootObjects()[0].setProperty("fullGlass", False)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
