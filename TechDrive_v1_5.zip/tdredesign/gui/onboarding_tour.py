#!/usr/bin/env python3
"""
gui/onboarding_tour.py — First-run welcome tour (dispatcher)
==============================================================
The tour itself now lives in gui/assets/welcome_tour.html — a
self-contained, autoplaying HTML/Canvas recreation of the original
13-slide Tkinter tour, matching the app's dark indigo/violet Fluent
palette exactly (same tokens as gui/fluent.py).

WHY A BROWSER, NOT AN EMBEDDED WIDGET:
The HTML tour's animation (every slide, the crossfades, the typed
console lines) is driven by JavaScript drawing to a <canvas>. Tkinter
has no built-in JS engine, and tkinterweb (a pure-Tkinter HTML/CSS
renderer some apps use for lightweight embedded pages) does NOT run
JavaScript — loading this file into it would render a single frozen
frame instead of the tour. Embedding a *real* JS engine cross-platform
means shipping a Chromium/WebView dependency (cefpython, pywebview,
tkwebview2 on Windows only) — a much heavier, more fragile addition
than this feature is worth.

Opening the file in the person's default browser sidesteps that
entirely: real JS engine, zero extra dependencies, works identically
on Windows/macOS/Linux, and it still autoplays immediately with no
click required — the person never has to "start" it themselves.

Shown automatically once per install (tracked via shared.database's
settings table, key "onboarding_tour_shown"), and re-playable any time
from Settings -> "Replay Welcome Tour".

Public API (unchanged from the classic module, so nothing else in the
app has to change):
    maybe_show(app)       -- shows the tour only if it's never been shown
    show(app)             -- always shows it (used by the Settings replay button)
"""

import webbrowser
from pathlib import Path
import tkinter as tk
from gui.tk_dialogs import messagebox

from shared import database as db

_ASSET = Path(__file__).parent / "assets" / "welcome_tour.html"


def _open_html_tour():
    """Opens the bundled HTML tour in the system default browser.
    Returns True if the asset existed and the open call was made."""
    if not _ASSET.exists():
        return False
    webbrowser.open(_ASSET.resolve().as_uri())
    return True


def _open_classic_tour(app):
    """Falls back to the original in-window Tkinter/Canvas tour -- same
    content, same animations, just drawn locally instead of in a
    browser tab. Used only if the HTML asset is missing (e.g. a custom
    build stripped gui/assets/)."""
    from gui import onboarding_tour_canvas
    onboarding_tour_canvas.show(app)


def _first_run_wizard(app):
    """Small native first-run setup: quick, skippable, and fully reversible."""
    win = tk.Toplevel(app)
    win.title("Welcome to TechDrive")
    win.geometry("560x500")
    win.minsize(520, 460)
    win.configure(bg=app.theme["BG"])
    win.transient(app)
    win.grab_set()

    step = tk.IntVar(value=0)
    vars_ = {
        "sounds": tk.BooleanVar(value=db.get_setting("sounds_enabled", False)),
        "notifications": tk.BooleanVar(value=db.get_setting("notifications_enabled", True)),
        "startup": tk.BooleanVar(value=False),
    }

    pages = [
        ("Welcome to TechDrive", "A quick setup takes less than a minute. You can change everything later in Settings."),
        ("Choose your alerts", "Notifications are useful for completed scans, repairs, and important results."),
        ("Choose startup behavior", "TechDrive stays out of your way unless you choose to launch it with Windows."),
        ("You're ready", "Your choices are saved. You can replay the welcome tour or change any option from Settings."),
    ]

    content = tk.Frame(win, bg=app.theme["CARD_BG"], bd=1, relief="solid")
    content.pack(fill="both", expand=True, padx=22, pady=22)
    title = tk.Label(content, bg=app.theme["CARD_BG"], fg=app.theme["FG"], font=("Segoe UI", 20, "bold"))
    title.pack(anchor="w", padx=24, pady=(24, 8))
    subtitle = tk.Label(content, bg=app.theme["CARD_BG"], fg=app.theme["MUTED"], font=("Segoe UI", 10), wraplength=470, justify="left")
    subtitle.pack(anchor="w", padx=24)
    options = tk.Frame(content, bg=app.theme["CARD_BG"])
    options.pack(fill="x", padx=24, pady=22)
    footer = tk.Frame(win, bg=app.theme["BG"])
    footer.pack(fill="x", padx=22, pady=(0, 18))

    def render():
        for w in options.winfo_children(): w.destroy()
        i = step.get(); title.config(text=pages[i][0]); subtitle.config(text=pages[i][1])
        if i == 0:
            tk.Label(options, text="Your real TechDrive settings remain available at any time.", bg=app.theme["CARD_BG"], fg=app.theme["FG"], font=("Segoe UI", 11)).pack(anchor="w", pady=8)
        elif i == 1:
            tk.Checkbutton(options, text="Enable Notification Center", variable=vars_["notifications"], bg=app.theme["CARD_BG"], fg=app.theme["FG"], selectcolor=app.theme["BG"], activebackground=app.theme["CARD_BG"]).pack(anchor="w", pady=8)
            tk.Checkbutton(options, text="Enable TechDrive sounds", variable=vars_["sounds"], bg=app.theme["CARD_BG"], fg=app.theme["FG"], selectcolor=app.theme["BG"], activebackground=app.theme["CARD_BG"]).pack(anchor="w", pady=8)
            tk.Label(options, text="Sounds start OFF by default; you can enable them later and choose your own WAV files.", bg=app.theme["CARD_BG"], fg=app.theme["MUTED"], wraplength=460, justify="left").pack(anchor="w", pady=(4, 8))
        elif i == 2:
            tk.Checkbutton(options, text="Launch TechDrive when Windows starts", variable=vars_["startup"], bg=app.theme["CARD_BG"], fg=app.theme["FG"], selectcolor=app.theme["BG"], activebackground=app.theme["CARD_BG"]).pack(anchor="w", pady=8)
            tk.Label(options, text="This is optional and can be changed later in Settings → Startup.", bg=app.theme["CARD_BG"], fg=app.theme["MUTED"], wraplength=460, justify="left").pack(anchor="w", pady=4)
        else:
            tk.Label(options, text="TechDrive is ready to use.", bg=app.theme["CARD_BG"], fg=app.theme["FG"], font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=8)
            tk.Label(options, text="You can replay the full feature tour from Settings whenever you want.", bg=app.theme["CARD_BG"], fg=app.theme["MUTED"], wraplength=460, justify="left").pack(anchor="w", pady=4)
        back.config(state="normal" if i else "disabled")
        next_.config(text="Finish" if i == len(pages)-1 else "Next")

    def finish():
        db.set_setting("notifications_enabled", bool(vars_["notifications"].get()))
        db.set_setting("sounds_enabled", bool(vars_["sounds"].get()))
        db.set_setting("onboarding_setup_completed", True)
        if vars_["startup"].get():
            try:
                from gui import settings as settings_mod
                settings_mod._set_startup_enabled(True)
            except Exception:
                pass
        try: win.grab_release()
        except Exception: pass
        win.destroy()

    def advance():
        if step.get() >= len(pages)-1: finish()
        else: step.set(step.get()+1); render()
    def retreat():
        if step.get(): step.set(step.get()-1); render()

    back = tk.Button(footer, text="Back", command=retreat, bg=app.theme["BG_LIGHT"], fg=app.theme["FG"], relief="flat", padx=14, pady=6)
    back.pack(side="left")
    next_ = tk.Button(footer, text="Next", command=advance, bg=app.theme["ACCENT"], fg="#ffffff", relief="flat", padx=18, pady=6)
    next_.pack(side="right")
    skip = tk.Button(footer, text="Skip", command=finish, bg=app.theme["BG"], fg=app.theme["MUTED"], relief="flat", padx=12, pady=6)
    skip.pack(side="right", padx=8)
    win.protocol("WM_DELETE_WINDOW", finish)
    render()
    win.wait_window()


def maybe_show(app):
    """Shows the native quick setup once; never interrupts later launches."""
    if db.get_setting("onboarding_setup_completed", False):
        return
    _first_run_wizard(app)


def show(app):
    """Replay the full feature tour from Settings."""
    db.set_setting("onboarding_tour_shown", True)
    opened = _open_html_tour()
    if not opened:
        _open_classic_tour(app)
        return
    try:
        messagebox.showinfo(
            "Welcome to TechDrive",
            "Your welcome tour just opened in your browser -- it plays automatically.",
            parent=app,
        )
    except Exception:
        pass
