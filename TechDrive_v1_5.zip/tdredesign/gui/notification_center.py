#!/usr/bin/env python3
"""Notification Center v2 — grouped cards with quick actions."""

from __future__ import annotations

import tkinter as tk

from gui import fluent as fl
from gui.widgets import GlassCard, FluentButton
from shared import database as db


def open_notification_center(app):
    """Open or focus the Notification Center window."""
    existing = getattr(app, "_notifications_win", None)
    if existing is not None:
        try:
            if existing.winfo_exists():
                _render(app)
                existing.deiconify()
                existing.lift()
                existing.focus_force()
                return existing
        except tk.TclError:
            pass

    th = app.theme
    win = tk.Toplevel(app)
    app._notifications_win = win
    win.title("Notification Center")
    win.geometry("460x600")
    win.minsize(380, 420)
    win.configure(bg=th["BG"])
    win.transient(app)

    def close():
        try:
            win.destroy()
        finally:
            app._notifications_win = None

    win.protocol("WM_DELETE_WINDOW", close)
    win.bind("<Escape>", lambda e: close())

    header = tk.Frame(win, bg=th["BG"])
    header.pack(fill="x", padx=20, pady=(18, 8))
    tk.Label(
        header, text="NOTIFICATION CENTER", bg=th["BG"],
        fg=th.get("ACCENT_GLOW", th["ACCENT"]),
        font=fl.F_TINY() if hasattr(fl, "F_TINY") else ("Segoe UI", 8),
    ).pack(anchor="w")
    title_row = tk.Frame(header, bg=th["BG"])
    title_row.pack(fill="x")
    tk.Label(
        title_row, text="Notifications", bg=th["BG"], fg=th["FG"],
        font=fl.F_TITLE() if hasattr(fl, "F_TITLE") else ("Segoe UI", 18, "bold"),
    ).pack(side="left")
    FluentButton(
        title_row, "CLEAR ALL",
        command=lambda: _clear_all(app),
        theme=th, aero=getattr(app, "is_aero_enabled", lambda: False)(),
        kind="standard", width=100, height=26, backdrop=th["BG"],
    ).pack(side="right")

    controls = tk.Frame(win, bg=th["BG"])
    controls.pack(fill="x", padx=20, pady=(0, 8))
    app._notification_filter = tk.StringVar(value="All")
    for label in ("All", "Unread", "Warnings"):
        tk.Radiobutton(
            controls, text=label, variable=app._notification_filter, value=label,
            command=lambda: _render(app),
            bg=th["BG"], fg=th["FG"], selectcolor=th.get("CARD_BG", th["BG"]),
            activebackground=th["BG"],
        ).pack(side="left", padx=(0, 10))

    body = tk.Frame(win, bg=th["BG"])
    body.pack(fill="both", expand=True, padx=20, pady=(0, 12))
    app._notifications_body = body
    _render(app)
    return win


def _load_rows(app):
    """Best-effort load from app helpers or empty list."""
    rows = []
    for name in ("_notification_rows", "get_notifications", "_get_notification_rows"):
        fn = getattr(app, name, None)
        if callable(fn):
            try:
                rows = list(fn() or [])
                break
            except Exception:
                pass
        elif isinstance(fn, list):
            rows = list(fn)
            break
    # Fallback: try database if app stored notifications there
    if not rows:
        try:
            # common pattern used in earlier techdrive
            raw = db.get_setting("notifications_json")
            if raw:
                import json
                rows = json.loads(raw)
        except Exception:
            rows = []
    return rows


def _render(app):
    body = getattr(app, "_notifications_body", None)
    if body is None:
        return
    for w in body.winfo_children():
        w.destroy()
    th = app.theme
    aero = getattr(app, "is_aero_enabled", lambda: False)()
    filt = "All"
    try:
        filt = app._notification_filter.get()
    except Exception:
        pass

    rows = _load_rows(app)
    # Normalize
    norm = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        level = (r.get("level") or r.get("l") or r.get("kind") or "info").lower()
        read = bool(r.get("read", False))
        if filt == "Unread" and read:
            continue
        if filt == "Warnings" and level not in ("warn", "warning", "error", "bad"):
            continue
        norm.append(r)

    if not norm:
        empty = GlassCard(body, th, aero=aero, backdrop=th["BG"])
        empty.pack(fill="x", pady=(8, 0))
        tk.Label(
            empty.body, text="You're all caught up",
            bg=empty.fill, fg=getattr(fl, "GOOD", th["ACCENT"]),
            font=fl.F_BODY(),
        ).pack(anchor="w", padx=14, pady=(14, 4))
        tk.Label(
            empty.body, text="No notifications in this filter.",
            bg=empty.fill, fg=th["MUTED"], font=fl.F_SMALL(),
        ).pack(anchor="w", padx=14, pady=(0, 14))
        return

    # Group by level
    groups = {"error": [], "warn": [], "info": [], "success": []}
    for r in norm:
        level = (r.get("level") or r.get("l") or r.get("kind") or "info").lower()
        if level in ("error", "bad"):
            groups["error"].append(r)
        elif level in ("warn", "warning"):
            groups["warn"].append(r)
        elif level in ("success", "good"):
            groups["success"].append(r)
        else:
            groups["info"].append(r)

    color_for = {
        "error": getattr(fl, "BAD", "#ff453a"),
        "warn": getattr(fl, "WARN", "#ffd60a"),
        "success": getattr(fl, "GOOD", "#30d158"),
        "info": th["ACCENT"],
    }
    titles = {
        "error": "Needs attention",
        "warn": "Warnings",
        "success": "Completed",
        "info": "Updates",
    }

    for key in ("error", "warn", "info", "success"):
        items = groups[key]
        if not items:
            continue
        tk.Label(
            body, text=titles[key].upper(), bg=th["BG"], fg=th["MUTED"],
            font=("Segoe UI", 9, "bold"), anchor="w",
        ).pack(fill="x", pady=(10, 4))
        for r in items[:12]:
            _card(app, body, r, color_for[key], th, aero)


def _card(app, parent, row, accent, th, aero):
    title = row.get("title") or row.get("t") or "Notification"
    msg = row.get("message") or row.get("m") or row.get("summary") or ""
    nid = row.get("id")
    read = bool(row.get("read", False))

    card = GlassCard(parent, th, aero=aero, backdrop=th["BG"], accent=accent, padding=12)
    card.pack(fill="x", pady=(0, 8))
    body = card.body
    body.configure(bg=card.fill)

    top = tk.Frame(body, bg=card.fill)
    top.pack(fill="x")
    tk.Label(
        top, text=title, bg=card.fill,
        fg=th["MUTED"] if read else th["FG"],
        font=("Segoe UI", 11, "bold"), anchor="w",
    ).pack(side="left", fill="x", expand=True)
    if not read:
        tk.Label(top, text="●", bg=card.fill, fg=accent, font=("Segoe UI", 8)).pack(side="right")

    if msg:
        tk.Label(
            body, text=msg, bg=card.fill, fg=th["MUTED"],
            font=("Segoe UI", 9), anchor="w", justify="left", wraplength=380,
        ).pack(fill="x", pady=(4, 8))

    actions = tk.Frame(body, bg=card.fill)
    actions.pack(fill="x")

    def mark_read():
        try:
            if hasattr(app, "_mark_notification_read") and nid is not None:
                app._mark_notification_read(nid)
            else:
                row["read"] = True
            _render(app)
        except Exception:
            pass

    def delete():
        try:
            if hasattr(app, "_delete_notification") and nid is not None:
                app._delete_notification(nid)
            _render(app)
        except Exception:
            pass

    if not read:
        tk.Button(
            actions, text="Mark read", command=mark_read,
            bg=card.fill, fg=th["ACCENT"], relief="flat", bd=0, cursor="hand2",
        ).pack(side="left")
    tk.Button(
        actions, text="Dismiss", command=delete,
        bg=card.fill, fg=th["MUTED"], relief="flat", bd=0, cursor="hand2",
    ).pack(side="right")


def _clear_all(app):
    try:
        if hasattr(app, "_clear_all_notifications"):
            app._clear_all_notifications()
        else:
            # wipe helper store
            db.set_setting("notifications_json", "[]")
    except Exception:
        pass
    _render(app)
