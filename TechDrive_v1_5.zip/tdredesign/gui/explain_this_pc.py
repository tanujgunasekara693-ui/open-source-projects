#!/usr/bin/env python3
"""
TechDrive Core — Explain This PC
================================
Turns live Windows telemetry into a human-readable explanation.

No sample hardware values are used. Every statement is derived from the
current machine scan. The scanner is read-only: it queries Windows CIM,
Storage, registry startup entries, and psutil where available.
"""

import json
import os
import platform
import subprocess
import threading
import tkinter as tk
from gui.tk_dialogs import filedialog, messagebox

try:
    import psutil
except ImportError:
    psutil = None

from gui import fluent as fl
from gui.scroll_utils import make_scrollable
from gui.widgets import GlassCard

IS_WINDOWS = platform.system() == "Windows"

SCAN_SCRIPT = r"""
$ErrorActionPreference = 'SilentlyContinue'

function Safe-Cim($Class) {
    try { @(Get-CimInstance $Class -ErrorAction Stop) } catch { @() }
}

$os = @(Safe-Cim Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime)
$cpu = @(Safe-Cim Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,CurrentClockSpeed,MaxClockSpeed)
$gpus = @(Safe-Cim Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion,Status)
$disks = @(Get-PhysicalDisk | Select-Object FriendlyName,MediaType,BusType,HealthStatus,OperationalStatus,Size)
$volumes = @(Get-Volume | Where-Object DriveLetter | Select-Object DriveLetter,FileSystemLabel,FileSystem,Size,SizeRemaining,HealthStatus)
$memory = @(Safe-Cim Win32_ComputerSystem | Select-Object TotalPhysicalMemory)
$startup = @()

$runLocations = @(
  'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
  'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
  'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
)

foreach ($path in $runLocations) {
    if (Test-Path $path) {
        try {
            $props = Get-ItemProperty $path
            foreach ($p in $props.PSObject.Properties) {
                if ($p.Name -notmatch '^PS') {
                    $startup += [ordered]@{ Name=$p.Name; Location=$path; Command=[string]$p.Value }
                }
            }
        } catch {}
    }
}

$startupFolder = [Environment]::GetFolderPath('Startup')
if ($startupFolder -and (Test-Path $startupFolder)) {
    Get-ChildItem $startupFolder -File -ErrorAction SilentlyContinue | ForEach-Object {
        $startup += [ordered]@{ Name=$_.Name; Location=$startupFolder; Command=$_.FullName }
    }
}

$thermal = @()
try {
    $thermal = @(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop |
        Select-Object InstanceName,CurrentTemperature)
} catch {}

[ordered]@{
  GeneratedAt = (Get-Date).ToString('o')
  ComputerName = $env:COMPUTERNAME
  OS = $os
  CPU = $cpu
  GPU = $gpus
  Memory = $memory
  PhysicalDisks = $disks
  Volumes = $volumes
  Startup = $startup
  Thermal = $thermal
} | ConvertTo-Json -Depth 8 -Compress
"""


def _run_scan():
    if not IS_WINDOWS:
        return {"ok": False, "error": "Explain This PC requires Windows telemetry APIs."}
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", SCAN_SCRIPT],
            capture_output=True, text=True, errors="replace", timeout=90
        )
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or r.stdout or "Windows scan failed.").strip()}
        raw = (r.stdout or "").strip()
        if not raw:
            return {"ok": False, "error": "Windows returned no telemetry."}
        return {"ok": True, "data": json.loads(raw)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Windows telemetry scan timed out."}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def _one(value):
    if isinstance(value, list):
        return value[0] if value else {}
    return value if isinstance(value, dict) else {}


def _gb(value):
    try:
        return float(value) / (1024 ** 3)
    except (TypeError, ValueError):
        return None


def _temp_c(raw):
    try:
        return float(raw) / 10.0 - 273.15
    except (TypeError, ValueError):
        return None


def _startup_count(data):
    return len(data.get("Startup") or [])


def _disk_findings(data):
    disks = data.get("PhysicalDisks") or []
    nvme = []
    health_bad = []
    health_warn = []
    for d in disks:
        if not isinstance(d, dict):
            continue
        bus = str(d.get("BusType") or "").lower()
        name = str(d.get("FriendlyName") or "")
        media = str(d.get("MediaType") or "")
        if "nvme" in bus or "nvme" in name.lower():
            nvme.append(name or "NVMe drive")
        health = str(d.get("HealthStatus") or "").lower()
        op = str(d.get("OperationalStatus") or "").lower()
        if health and health not in ("healthy", "unknown"):
            health_bad.append((name or "Storage device", health))
        if "degraded" in op or "error" in op or "failed" in op:
            health_warn.append((name or "Storage device", op))
    return nvme, health_bad, health_warn


def _build_explanation(data, cpu_pct=None, mem_pct=None, temps=None):
    os_info = _one(data.get("OS"))
    cpu = _one(data.get("CPU"))
    mem = _one(data.get("Memory"))
    volumes = [v for v in (data.get("Volumes") or []) if isinstance(v, dict)]
    startup = _startup_count(data)
    nvme, disk_bad, disk_warn = _disk_findings(data)

    ram_gb = _gb(mem.get("TotalPhysicalMemory"))
    cpu_name = cpu.get("Name") or "the installed processor"
    logical = cpu.get("NumberOfLogicalProcessors")
    cores = cpu.get("NumberOfCores")
    os_name = os_info.get("Caption") or "Windows"
    build = os_info.get("BuildNumber")
    machine = data.get("ComputerName") or platform.node()

    used_storage = []
    for v in volumes:
        size = _gb(v.get("Size"))
        free = _gb(v.get("SizeRemaining"))
        if size and free is not None and size > 0:
            used = max(0, min(100, (1 - free / size) * 100))
            used_storage.append((v.get("DriveLetter", "?"), used, size, free))

    good = 0
    warn = 0
    bad = 0
    facts = []
    concerns = []
    actions = []

    facts.append(f"This is {machine}, running {os_name}" + (f" (build {build})." if build else "."))
    if ram_gb:
        facts.append(f"The computer has {ram_gb:.1f} GB of physical memory.")
    else:
        facts.append("Windows did not expose the installed physical-memory total during this scan.")

    cpu_text = cpu_name
    if cores and logical:
        cpu_text += f", with {cores} physical cores and {logical} logical processors"
    facts.append(f"The processor is {cpu_text}.")

    if nvme:
        facts.append("Storage includes an NVMe SSD: " + ", ".join(nvme[:3]) + ".")
    elif data.get("PhysicalDisks"):
        facts.append(f"Windows reported {len(data.get('PhysicalDisks') or [])} physical storage device(s).")
    else:
        concerns.append("Windows did not return physical-disk information.")
        warn += 1

    if used_storage:
        fullest = max(used_storage, key=lambda x: x[1])
        if fullest[1] >= 90:
            concerns.append(f"Drive {fullest[0]} is {fullest[1]:.0f}% full. Very low free space can hurt updates and application performance.")
            actions.append(f"Free space on drive {fullest[0]} before it becomes critically full.")
            bad += 1
        elif fullest[1] >= 80:
            concerns.append(f"Drive {fullest[0]} is {fullest[1]:.0f}% full, so storage headroom is getting limited.")
            actions.append(f"Consider freeing some space on drive {fullest[0]}.")
            warn += 1
        else:
            facts.append(f"The fullest mounted volume is {fullest[0]}, using {fullest[1]:.0f}% of its capacity.")
            good += 1

    if disk_bad:
        concerns.append("Windows reports a storage health problem: " +
                        "; ".join(f"{n} ({h})" for n, h in disk_bad[:3]) + ".")
        actions.append("Back up important files and investigate the affected drive.")
        bad += 1
    elif disk_warn:
        concerns.append("Windows reports a non-healthy storage operational state: " +
                        "; ".join(f"{n} ({h})" for n, h in disk_warn[:3]) + ".")
        actions.append("Run Hardware Inventory and inspect the affected storage device.")
        warn += 1
    elif data.get("PhysicalDisks"):
        facts.append("The physical-disk health fields returned no active failure state.")
        good += 1

    if cpu_pct is not None:
        if cpu_pct >= 90:
            concerns.append(f"CPU usage is currently high at {cpu_pct:.0f}%.")
            actions.append("Check Performance Lab for processes driving sustained CPU usage.")
            warn += 1
        else:
            facts.append(f"CPU utilization is currently {cpu_pct:.0f}%, which is not unusually high.")
            good += 1

    if mem_pct is not None:
        if mem_pct >= 90:
            concerns.append(f"Memory utilization is currently high at {mem_pct:.0f}%.")
            actions.append("Check which applications are consuming RAM if the system feels slow.")
            warn += 1
        else:
            facts.append(f"Memory utilization is currently {mem_pct:.0f}%.")
            good += 1

    valid_temps = [t for t in (temps or []) if t is not None]
    if valid_temps:
        hottest = max(valid_temps)
        if hottest >= 90:
            concerns.append(f"A Windows thermal sensor reported about {hottest:.0f} °C.")
            actions.append("Check cooling, airflow, and CPU/GPU load before running heavy workloads.")
            bad += 1
        elif hottest >= 80:
            concerns.append(f"A Windows thermal sensor reported about {hottest:.0f} °C.")
            actions.append("Watch temperatures under load.")
            warn += 1
        else:
            facts.append(f"Windows thermal telemetry is currently around {hottest:.0f} °C at its hottest reported zone.")
            good += 1
    else:
        facts.append("Windows did not expose a usable thermal-zone reading; this does not mean the hardware has no temperature sensors.")

    if startup >= 15:
        concerns.append(f"TechDrive found {startup} startup entries. A large startup list can increase boot time and background activity.")
        actions.append("Review startup applications and disable only items you recognize and do not need at sign-in.")
        warn += 1
    elif startup >= 8:
        concerns.append(f"TechDrive found {startup} startup entries. Some may be worth reviewing.")
        actions.append("Review startup applications if boot time or background load is a concern.")
        warn += 1
    else:
        facts.append(f"TechDrive found {startup} startup entries in the Windows startup locations it checks.")
        good += 1

    if bad:
        status = "ATTENTION NEEDED"
    elif warn:
        status = "HEALTHY WITH ITEMS TO REVIEW"
    else:
        status = "LOOKS HEALTHY"

    # Remove duplicate actions while retaining order.
    actions = list(dict.fromkeys(actions))
    return {
        "status": status,
        "facts": facts,
        "concerns": concerns,
        "actions": actions,
        "good": good, "warn": warn, "bad": bad,
        "ram_gb": ram_gb, "cpu_name": cpu_name, "startup": startup,
        "volumes": used_storage,
        "generated": data.get("GeneratedAt", "")
    }


class ExplainThisPCPage(tk.Frame):
    """Live, read-only system explanation generated from current telemetry."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=app.theme["BG"])
        self.app = app
        self.theme = app.theme
        self.aero = app.is_aero_enabled()
        self.data = None
        self.explanation = None
        self._busy = False
        self._build()
        self.after(100, self.scan)

    def _build(self):
        _, root = make_scrollable(self, self.theme["BG"])
        header = tk.Frame(root, bg=self.theme["BG"])
        header.pack(fill="x", padx=24, pady=(22, 12))
        tk.Label(header, text="TECHDRIVE CORE  •  LIVE EXPLANATION",
                 bg=self.theme["BG"], fg=self.theme["ACCENT_GLOW"],
                 font=fl.F_TINY()).pack(anchor="w")
        row = tk.Frame(header, bg=self.theme["BG"])
        row.pack(fill="x", pady=(4, 4))
        tk.Label(row, text="Explain This PC", bg=self.theme["BG"],
                 fg=self.theme["FG"], font=fl.F_TITLE()).pack(side="left")
        self.scan_btn = tk.Button(row, text="Scan Again", command=self.scan,
                                  bg=self.theme["ACCENT"], fg=self.theme["ON_ACCENT"],
                                  relief="flat", padx=16, pady=7, cursor="hand2")
        self.scan_btn.pack(side="right", padx=(8, 0))
        self.save_btn = tk.Button(row, text="Save Explanation", command=self.save,
                                  bg=self.theme["BG_LIGHT"], fg=self.theme["FG"],
                                  activebackground=self.theme["SELECTION"],
                                  activeforeground=self.theme["FG"], relief="flat",
                                  padx=14, pady=7, cursor="hand2", state=tk.DISABLED)
        self.save_btn.pack(side="right")
        tk.Label(header,
                 text="TechDrive reads the current Windows telemetry and translates it into plain language. "
                      "Nothing is invented and this scan does not change system settings.",
                 bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
                 wraplength=850, justify="left").pack(anchor="w")

        self.body = tk.Frame(root, bg=self.theme["BG"])
        self.body.pack(fill="both", expand=True, padx=24, pady=(4, 24))
        self.status = tk.Label(self.body, text="Scanning this PC…",
                               bg=self.theme["BG"], fg=self.theme["MUTED"],
                               font=fl.F_SMALL())
        self.status.pack(anchor="w", pady=(8, 12))

    def _clear_body(self):
        for child in self.body.winfo_children():
            child.destroy()

    def _card(self, title, items, accent=None):
        card = GlassCard(self.body, self.theme, aero=self.aero,
                         accent=accent or self.theme["ACCENT"])
        card.pack(fill="x", pady=7)
        tk.Label(card.body, text=title, bg=card.fill, fg=self.theme["FG"],
                 font=fl.F_CARD_TITLE()).pack(anchor="w", padx=16, pady=(14, 7))
        for item in items:
            tk.Label(card.body, text="• " + item, bg=card.fill,
                     fg=self.theme["MUTED"], font=fl.F_SMALL(),
                     wraplength=860, justify="left", anchor="w").pack(
                         fill="x", padx=18, pady=(0, 8))
        return card

    def _render(self, data, metrics):
        self._clear_body()
        self.data = data
        self.explanation = _build_explanation(
            data, metrics.get("cpu_pct"), metrics.get("mem_pct"), metrics.get("temps")
        )
        e = self.explanation

        badge = GlassCard(self.body, self.theme, aero=self.aero,
                          accent=self.theme["ACCENT"])
        badge.pack(fill="x", pady=(0, 8))
        top = tk.Frame(badge.body, bg=badge.fill)
        top.pack(fill="x", padx=16, pady=16)
        tk.Label(top, text=e["status"], bg=badge.fill,
                 fg=self.theme["ACCENT_GLOW"], font=fl.F_TITLE()).pack(side="left")
        tk.Label(top, text=f"{e['good']} good  •  {e['warn']} review  •  {e['bad']} critical",
                 bg=badge.fill, fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(side="right")

        self._card("What TechDrive found", e["facts"])
        if e["concerns"]:
            self._card("What deserves attention", e["concerns"], self.theme.get("WARNING", self.theme["ACCENT"]))
        else:
            self._card("What deserves attention", ["TechDrive did not find an obvious issue in the telemetry it could read."])
        if e["actions"]:
            self._card("What I would do next", e["actions"])
        else:
            self._card("What I would do next", ["No immediate action is suggested by this scan."])

        details = [
            f"CPU: {e['cpu_name']}",
            f"RAM: {e['ram_gb']:.1f} GB" if e["ram_gb"] else "RAM: unavailable",
            f"Current CPU usage: {metrics.get('cpu_pct'):.0f}%" if metrics.get("cpu_pct") is not None else "Current CPU usage: unavailable",
            f"Current memory usage: {metrics.get('mem_pct'):.0f}%" if metrics.get("mem_pct") is not None else "Current memory usage: unavailable",
            f"Startup entries found: {e['startup']}",
            f"Volumes inspected: {len(e['volumes'])}",
        ]
        self._card("Scan details", details)
        self.status = tk.Label(self.body, text=f"Live scan completed • {e['generated']}",
                               bg=self.theme["BG"], fg=self.theme["MUTED"],
                               font=fl.F_TINY())
        self.status.pack(anchor="w", pady=(8, 0))
        self.save_btn.config(state=tk.NORMAL)

    def scan(self):
        if self._busy:
            return
        self._busy = True
        self.scan_btn.config(state=tk.DISABLED)
        self.save_btn.config(state=tk.DISABLED)
        self._clear_body()
        self.status = tk.Label(self.body, text="Reading Windows telemetry…",
                               bg=self.theme["BG"], fg=self.theme["MUTED"],
                               font=fl.F_SMALL())
        self.status.pack(anchor="w", pady=(8, 12))

        def worker():
            result = _run_scan()
            metrics = {"cpu_pct": None, "mem_pct": None, "temps": []}
            if result.get("ok") and psutil is not None:
                try:
                    metrics["cpu_pct"] = psutil.cpu_percent(interval=0.8)
                    metrics["mem_pct"] = psutil.virtual_memory().percent
                except Exception:
                    pass
            if result.get("ok"):
                for zone in result["data"].get("Thermal") or []:
                    if isinstance(zone, dict):
                        t = _temp_c(zone.get("CurrentTemperature"))
                        if t is not None and -20 < t < 150:
                            metrics["temps"].append(t)
            self.app._post_ui(lambda result=result, metrics=metrics: self._finish(result, metrics))

        threading.Thread(target=worker, daemon=True).start()

    def _finish(self, result, metrics):
        self._busy = False
        self.scan_btn.config(state=tk.NORMAL)
        if not result.get("ok"):
            self._clear_body()
            self.status = tk.Label(self.body, text="Explain This PC could not complete the scan.",
                                   bg=self.theme["BG"], fg="#ff6b6b", font=fl.F_SMALL())
            self.status.pack(anchor="w", pady=(8, 4))
            tk.Label(self.body, text=result.get("error", "Unknown Windows telemetry error."),
                     bg=self.theme["BG"], fg=self.theme["MUTED"], font=fl.F_SMALL(),
                     wraplength=850, justify="left").pack(anchor="w")
            return
        self._render(result["data"], metrics)

    def save(self):
        if not self.explanation:
            return
        e = self.explanation
        lines = [
            "TECHDRIVE — EXPLAIN THIS PC",
            "=" * 32,
            f"Status: {e['status']}",
            "",
            "WHAT TECHDRIVE FOUND",
            *[f"- {x}" for x in e["facts"]],
            "",
            "WHAT DESERVES ATTENTION",
            *[f"- {x}" for x in (e["concerns"] or ["No obvious issue found."])],
            "",
            "WHAT I WOULD DO NEXT",
            *[f"- {x}" for x in (e["actions"] or ["No immediate action suggested."])],
            "",
            "SCAN DETAILS",
            f"- CPU: {e['cpu_name']}",
            f"- RAM: {e['ram_gb']:.1f} GB" if e["ram_gb"] else "- RAM: unavailable",
            f"- Startup entries: {e['startup']}",
            f"- Generated: {e['generated']}",
        ]
        path = filedialog.asksaveasfilename(
            title="Save TechDrive Explanation",
            defaultextension=".txt",
            filetypes=[("Text file", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
            messagebox.showinfo("TechDrive", f"Explanation saved to:\n{path}")
        except Exception as exc:
            messagebox.showerror("TechDrive", f"Could not save explanation:\n{exc}")
