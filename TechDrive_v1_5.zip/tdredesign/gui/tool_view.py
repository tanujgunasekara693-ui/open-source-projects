#!/usr/bin/env python3
"""
gui/tool_view.py — Card-based tool panel framework
====================================================
Notepad++-style tool panels: a title bar with an icon, title, subtitle and
a Refresh button, followed by clean label/value rows and progress bars
with green/yellow/red color coding - no giant scrolling text dumps.

Usage from a tool_* method in techdrive.py:

    def tool_cpu_info(self, frame):
        panel = CardPanel(frame, self.theme, "▣ CPU Info",
                           "Static and live CPU details",
                           on_refresh=lambda: self._run_bg(gather, redraw))

        def gather():
            ... collect data into a plain dict ...
            return data

        def redraw(data):
            panel.clear()
            panel.stat("Model", data["model"])
            panel.stat("Architecture", data["arch"])
            panel.stat("Cores", f"{data['phys']} Physical / {data['logical']} Logical")
            panel.stat("Frequency", data["freq"])
            panel.stat("Temperature", data["temp"], status=data["temp_status"])
            panel.progress("Usage", data["usage_pct"])

        self._run_bg(gather, redraw)

`status` for stat()/progress() is one of "good" / "warn" / "bad" / None.

For a tool's *final* readout, prefer the common RESULTS/DETAILS layout
via panel.results(...) instead of (or in addition to) loose .stat() rows
- it standardizes the summary box, the checklist below it, and gives
every tool the same Copy / Save TXT / Export JSON / Generate Report
actions for free:

        def redraw(data):
            panel.clear()
            panel.results(
                status="healthy",   # healthy | warning | critical
                stats=[("Temperature", "42\u00b0C"),
                       ("Usage", "18%"),
                       ("Status", "Normal", "good")],   # 3rd item = row status
                details=[("good", "No critical issues"),
                         ("good", "Device responding normally"),
                         ("warn", "One informational event")],
                tool_name="CPU Info",
            )

        self._run_bg(gather, redraw)

Every panel also gets a "✕ Close" button in its header automatically -
CardPanel looks for the enclosing ClosableNotebook tab and wires the
button to close it, so individual tool_* methods don't need to do
anything extra. Pass on_close=<callable> explicitly only if a tool is
hosted somewhere other than a ClosableNotebook tab (or needs custom
close behavior, e.g. confirming unsaved changes first).
"""

import datetime
import json
import re
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from gui.theme import status_color, FONT_CARD_TITLE, FONT_UI, FONT_UI_BOLD, FONT_MONO
from gui import fluent as fl

# --- shared vocabulary for CardPanel.results() -----------------------------
# Overall-status pill: value -> (dot color, display label)
_RESULT_STATUS = {
    "healthy": (fl.GOOD, "HEALTHY"),
    "good":    (fl.GOOD, "HEALTHY"),
    "pass":    (fl.GOOD, "HEALTHY"),
    "warning": (fl.WARN, "NEEDS ATTENTION"),
    "warn":    (fl.WARN, "NEEDS ATTENTION"),
    "critical": (fl.BAD, "CRITICAL"),
    "bad":     (fl.BAD, "CRITICAL"),
    "unknown": ("#95a5a6", "UNKNOWN"),
}
# Details checklist row: kind -> (mark, color)
_DETAIL_MARK = {
    "good": ("✓", fl.GOOD), "ok": ("✓", fl.GOOD), "pass": ("✓", fl.GOOD),
    "warn": ("⚠", fl.WARN), "warning": ("⚠", fl.WARN), "info": ("ℹ", fl.WARN),
    "bad": ("✕", fl.BAD), "fail": ("✕", fl.BAD), "critical": ("✕", fl.BAD),
}

# --- patterns used by CardPanel.report() to turn legacy text dumps into
# stat rows without every tool_* function having to be hand-rewritten ---
_SECTION_RE = re.compile(r"^=+\s*(.+?)\s*=+$")
_STAT_RE = re.compile(r"^(\s*)([A-Za-z][A-Za-z0-9 /_.\-\(\)]{0,48}?)\s*:\s+(\S.*)$")
_PERCENT_RE = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*%")
_BAD_WORDS = ("risk", "error", "fail", "critical", "not found", "not detected",
              "timed out", "unrecognized", "obsolete", "broken")
_WARN_WORDS = ("warning", "warn", "outdated", "congested", "busy", "unknown")
_GOOD_WORDS = ("ok:", " ok", "good", "connected", "up", "clear", "recommended", "pass")


def _guess_status(value_lower):
    if any(w in value_lower for w in _BAD_WORDS):
        return "bad"
    if any(w in value_lower for w in _WARN_WORDS):
        return "warn"
    if any(w in value_lower for w in _GOOD_WORDS):
        return "good"
    return None


class PanelTextProxy:
    """Compatibility text sink for legacy tool panels.

    Older module tools used a Tk Text widget named ``box``.  Newer tools use
    CardPanel rendering instead.  This tiny adapter preserves the old
    ``delete()/insert()`` contract while rendering through CardPanel, so a
    partially migrated tool cannot crash with an undefined ``box`` or keep a
    stale widget alive after ``panel.clear()``.
    """
    def __init__(self, panel):
        self.panel = panel
        self._text = ""

    def delete(self, *_args):
        self._text = ""

    def insert(self, _index, text):
        self._text += str(text)
        try:
            self.panel.clear()
            self.panel.report(self._text)
        except Exception:
            # Rendering errors are handled by the host's background/UI
            # dispatcher; never let a compatibility sink crash a tool.
            pass

    def get(self, *_args):
        return self._text


class CardPanel:
    """A single scrollable card-style tool panel embedded in a notebook tab
    frame. Call .clear() then re-populate with .stat()/.progress()/.card()
    on every refresh, rather than rebuilding the whole panel from scratch -
    keeps the Refresh button and header stable."""

    def __init__(self, parent, theme_colors, title, subtitle="", icon="", on_refresh=None,
                 on_close=None):
        self.theme = theme_colors
        self.parent = parent

        # Every panel lives inside its own scrollable canvas, so tools
        # with lots of stat rows / cards (or a short window) scroll
        # instead of clipping. Mouse-wheel handling itself is app-wide
        # (see gui/scroll_utils.install_global_mousewheel) - it works no
        # matter which child widget under the canvas the cursor is over.
        from gui.scroll_utils import make_scrollable
        self._canvas, self._scroll_root = make_scrollable(
            parent, theme_colors["BG"])
        root = self._scroll_root

        header = tk.Frame(root, bg=theme_colors["BG"])
        header.pack(fill="x", padx=20, pady=(20, 4))

        title_area = tk.Frame(header, bg=theme_colors["BG"])
        title_area.pack(side="left", fill="x", expand=True)
        title_text = f"{icon} {title}".strip()
        self._title = title_text
        from gui import fluent as _fl
        tk.Label(title_area, text=title_text, bg=theme_colors["BG"],
                 fg=theme_colors["FG"], font=_fl.font(22, "bold", display=True)).pack(side="left")
        # Avoid a permanent BETA badge in every panel: it consumes scarce
        # horizontal space on compact windows and makes the interface noisy.

        # Every tool panel gets a visible "✕ Close" button, in addition to
        # whatever tab-level close affordance (e.g. ClosableNotebook's ✕)
        # the host container already provides - this one's guaranteed to
        # be there regardless of which notebook/container ends up hosting
        # the tool, and it's a lot more discoverable than a small tab icon.
        close_fn = on_close or self._make_default_close()
        if close_fn is not None:
            from gui.widgets import FluentButton
            FluentButton(header, "Close", command=close_fn, theme=theme_colors,
                         aero=False, kind="subtle", width=96, height=32,
                         backdrop=theme_colors["BG"]).pack(side="right", padx=(8, 0))

        if on_refresh is not None:
            from gui.widgets import FluentButton
            FluentButton(header, "Refresh", command=on_refresh, theme=theme_colors,
                         aero=False, kind="standard", width=104, height=32,
                         backdrop=theme_colors["BG"]).pack(side="right")

        if subtitle:
            tk.Label(root, text=subtitle, bg=theme_colors["BG"],
                      fg=theme_colors["MUTED"], font=_fl.font(13), wraplength=980,
                      justify="left").pack(anchor="w", padx=20, pady=(0, 10))

        # Card body: bordered container that holds the stat/progress rows.
        # Cleared and repopulated on refresh instead of being torn down,
        # so the panel doesn't flicker/resize on every update.
        outer = tk.Frame(root, bg=theme_colors["CARD_BORDER"], bd=0)
        outer.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.body = tk.Frame(outer, bg=theme_colors["CARD_BG"])
        self.body.pack(fill="both", expand=True, padx=1, pady=1)

    def _make_default_close(self):
        """Walks up from the panel's parent frame looking for the
        ClosableNotebook tab that hosts this tool, and returns a
        zero-arg callable that closes it - so tool_* methods that don't
        pass on_close explicitly still get a working Close button for
        free. Returns None if no such notebook is found (e.g. a tool
        rendered somewhere other than a notebook tab), in which case no
        Close button is shown rather than wiring up something that'd
        silently do nothing.
        """
        # Local import avoids a hard dependency / import-order issue for
        # any caller that imports tool_view before closable_notebook.
        from gui.closable_notebook import ClosableNotebook

        widget = self.parent
        tab_frame = None
        while widget is not None:
            master = widget.nametowidget(widget.winfo_parent()) if widget.winfo_parent() else None
            if isinstance(master, ClosableNotebook):
                tab_frame = widget
                notebook = master
                break
            widget = master
        if tab_frame is None:
            return None

        def _close():
            try:
                notebook.close_tab(tab_frame)
            except tk.TclError:
                pass  # tab already gone (e.g. double-click race)

        return _close

    def clear(self):
        for child in self.body.winfo_children():
            child.destroy()

    def card(self, title=None):
        """Start a new sub-section inside the panel (e.g. grouping related
        stats). Returns the frame to build sub-rows into with the same
        conventions as stat()/progress(), just pass `container=` instead."""
        section = tk.Frame(self.body, bg=self.theme["CARD_BG"])
        section.pack(fill="x", padx=12, pady=(10, 4))
        if title:
            tk.Label(section, text=title, bg=self.theme["CARD_BG"],
                      fg=self.theme["MUTED"], font=FONT_UI_BOLD).pack(anchor="w")
        return section

    def stat(self, label, value, status=None, container=None):
        """One label/value row. status colors the value text (and adds a
        small ✅/⚠/✕ marker) - use for anything with a health reading
        (temperature, disk health, connection state, etc)."""
        row = tk.Frame(container or self.body, bg=self.theme["CARD_BG"])
        row.pack(fill="x", padx=14, pady=3)
        label_widget = tk.Label(row, text=label, bg=self.theme["CARD_BG"], fg=self.theme["MUTED"],
                                font=FONT_UI, width=16, anchor="nw")
        label_widget.pack(side="left", padx=(0, 8), pady=1)

        value_text = str(value)
        color = self.theme["FG"]
        if status:
            color = status_color(status)
            marker = {"good": "✓", "warn": "⚠", "bad": "✕"}.get(status, "")
            if marker:
                value_text = f"{value_text} {marker}"
        value_widget = tk.Label(row, text=value_text, bg=self.theme["CARD_BG"], fg=color,
                                font=FONT_UI_BOLD, anchor="nw", justify="left", wraplength=520)
        value_widget.pack(side="left", fill="x", expand=True, pady=1)
        def _resize_value(event, widget=value_widget):
            try:
                widget.configure(wraplength=max(120, event.width - 145))
            except tk.TclError:
                pass
        row.bind("<Configure>", _resize_value, add="+")
        return row

    def progress(self, label, percent, status=None, thresholds=(60, 85), container=None):
        """Labeled progress bar (0-100). If status isn't given explicitly,
        it's derived from thresholds: below thresholds[0] -> good, below
        thresholds[1] -> warn, else bad (i.e. "high usage is bad" - flip
        the thresholds/status yourself for readings where high is good,
        like battery charge)."""
        percent = max(0, min(100, percent))
        if status is None:
            if percent < thresholds[0]:
                status = "good"
            elif percent < thresholds[1]:
                status = "warn"
            else:
                status = "bad"

        row = tk.Frame(container or self.body, bg=self.theme["CARD_BG"])
        row.pack(fill="x", padx=14, pady=4)
        top = tk.Frame(row, bg=self.theme["CARD_BG"])
        top.pack(fill="x")
        tk.Label(top, text=label, bg=self.theme["CARD_BG"], fg=self.theme["MUTED"],
                  font=FONT_UI, anchor="w").pack(side="left")
        tk.Label(top, text=f"{percent:.0f}%", bg=self.theme["CARD_BG"],
                  fg=status_color(status), font=FONT_UI_BOLD, anchor="e").pack(side="right")

        bar_bg = tk.Frame(row, bg=self.theme["BG_LIGHT"], height=10)
        bar_bg.pack(fill="x", pady=(3, 0))
        bar_bg.pack_propagate(False)
        fill_width_pct = max(2, int(percent))  # keep a sliver visible at 0%
        fill = tk.Frame(bar_bg, bg=status_color(status))
        fill.place(relx=0, rely=0, relwidth=fill_width_pct / 100, relheight=1)
        return row

    def report(self, text, container=None):
        """Render a legacy '=== Section ===' / 'Key: value' text dump (the
        format almost every tool_* gather()/run() function already returns)
        as cards + stat rows instead of dumping it into a scrolling text
        box. This lets existing gather logic stay untouched - only the
        panel-building code around it changes.

        Rules (best-effort, not a strict parser - unrecognized lines still
        show up, just as plain wrapped text instead of being dropped):
          '=== Title ==='        -> new .card(title) sub-section
          'Label: value'         -> .stat(label, value), with status/percent
                                     auto-detected from the value text
          anything else          -> collected and shown as a paragraph
        """
        if text is None or not str(text).strip():
            self.empty_state("No data returned.")
            return

        cur = container or self.body
        freeform = []

        def flush_freeform():
            if freeform:
                joined = "\n".join(freeform).strip("\n")
                if joined:
                    label = tk.Label(cur, text=joined, bg=self.theme["CARD_BG"], fg=self.theme["FG"],
                                     font=FONT_MONO, justify="left", anchor="w", wraplength=680)
                    label.pack(anchor="w", fill="x", expand=True, padx=14, pady=(2, 6))
                    def _resize_report(event, widget=label):
                        try:
                            widget.configure(wraplength=max(180, event.width - 32))
                        except tk.TclError:
                            pass
                    cur.bind("<Configure>", _resize_report, add="+")
                freeform.clear()

        for raw_line in str(text).splitlines():
            line = raw_line.rstrip()
            if not line.strip():
                continue

            m_section = _SECTION_RE.match(line.strip())
            if m_section:
                flush_freeform()
                cur = self.card(m_section.group(1))
                continue

            m_stat = _STAT_RE.match(line)
            if m_stat:
                flush_freeform()
                label, value = m_stat.group(2).strip(), m_stat.group(3).strip()
                status = _guess_status(value.lower())
                pct = _PERCENT_RE.search(value)
                if pct and status is None:
                    self.progress(label, float(pct.group(1)), container=cur)
                else:
                    self.stat(label, value, status=status, container=cur)
                continue

            freeform.append(raw_line)

        flush_freeform()

    def log_box(self, container=None, height=16):
        """A monospace, append-only text box for tools that stream live
        progress (stress tests, long scans) rather than returning one
        final report - kept inside the same card chrome (header, Refresh,
        Close) as every other tool instead of a bare standalone text
        widget. Use .after(...)/box.insert("end", ...) as before; this
        only changes where the box lives, not how it's driven."""
        box = tk.Text(container or self.body, bg=self.theme["CARD_BG"], fg=self.theme["FG"],
                       insertbackground=self.theme["FG"], font=FONT_MONO, height=height,
                       wrap="word", relief="flat", highlightthickness=0)
        box.pack(fill="both", expand=True, padx=14, pady=(4, 12))
        return box

    def empty_state(self, message):
        tk.Label(self.body, text=message, bg=self.theme["CARD_BG"],
                  fg=self.theme["MUTED"], font=FONT_UI, wraplength=520,
                  justify="left").pack(anchor="w", padx=14, pady=14)

    # -- standard RESULTS / DETAILS / actions block -------------------
    def results(self, status, stats, details, tool_name=None, container=None):
        """Render the common results layout every tool should use for its
        final readout:

            RESULTS
            +----------------------+
            | * HEALTHY            |
            |                      |
            | Temperature   42C    |
            | Usage         18%    |
            | Status        Normal |
            +----------------------+

            DETAILS
            v No critical issues
            v Device responding normally
            ! One informational event

            [Copy] [Save TXT] [Export JSON] [Generate Report]

        status:  "healthy"/"warning"/"critical" (aliases "good"/"warn"/
                 "bad"/"pass"/"critical"/"unknown" also accepted) - drives
                 the colored status pill at the top of the results box.
        stats:   list of (label, value) pairs, or (label, value, status)
                 to color-code an individual row the same as .stat().
        details: list of plain strings (assumed "good"), or (kind, text)
                 pairs where kind is good/warn/bad/info - rendered as a
                 checkmark/warning/cross list under DETAILS.
        tool_name: optional label used in Copy/Save/Export/Report output
                 headers; falls back to the panel's own title if omitted.

        Call this instead of (or alongside) .stat()/.report() when a tool
        has reached its final readout - .stat()/.progress()/.card() are
        still fine for anything that isn't part of the final summary
        (live counters, sub-sections, etc).
        """
        cur = container or self.body
        norm_stats = [(s[0], s[1], s[2] if len(s) > 2 else None) for s in stats]
        norm_details = [(d, "good") if isinstance(d, str) else (d[1], d[0]) for d in details]
        self._last_results = {
            "tool": tool_name or getattr(self, "_title", "TechDrive Tool"),
            "status": status,
            "stats": norm_stats,
            "details": norm_details,
            "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        }

        tk.Label(cur, text="RESULTS", bg=self.theme["CARD_BG"], fg=self.theme["MUTED"],
                 font=fl.font(8, "bold")).pack(anchor="w", padx=14, pady=(10, 4))

        dot_color, status_label = _RESULT_STATUS.get(str(status).lower(), _RESULT_STATUS["unknown"])
        box_bg = self.theme["CARD_BG"]
        box = tk.Frame(cur, bg=box_bg, highlightbackground=fl.mix(box_bg, dot_color, 0.5),
                       highlightthickness=1)
        box.pack(fill="x", padx=14, pady=(0, 10))
        head = tk.Frame(box, bg=box_bg); head.pack(fill="x", padx=12, pady=(10, 6))
        tk.Label(head, text="●", bg=box_bg, fg=dot_color, font=fl.font(11, "bold")).pack(side="left")
        tk.Label(head, text=status_label, bg=box_bg, fg=dot_color, font=FONT_UI_BOLD).pack(side="left", padx=(6, 0))
        for label, value, row_status in norm_stats:
            self.stat(label, value, status=row_status, container=box)
        tk.Frame(box, bg=box_bg, height=8).pack()

        tk.Label(cur, text="DETAILS", bg=self.theme["CARD_BG"], fg=self.theme["MUTED"],
                 font=fl.font(8, "bold")).pack(anchor="w", padx=14, pady=(4, 4))
        det_box = tk.Frame(cur, bg=self.theme["CARD_BG"]); det_box.pack(fill="x", padx=14, pady=(0, 6))
        for text, kind in norm_details:
            mark, color = _DETAIL_MARK.get(str(kind).lower(), ("•", self.theme["FG"]))
            row = tk.Frame(det_box, bg=self.theme["CARD_BG"]); row.pack(fill="x", pady=2)
            tk.Label(row, text=mark, bg=self.theme["CARD_BG"], fg=color, font=FONT_UI_BOLD,
                     width=2, anchor="w").pack(side="left")
            tk.Label(row, text=text, bg=self.theme["CARD_BG"], fg=self.theme["FG"], font=FONT_UI,
                     wraplength=640, justify="left", anchor="w").pack(side="left", fill="x", expand=True)

        actions = tk.Frame(cur, bg=self.theme["CARD_BG"]); actions.pack(anchor="w", padx=12, pady=(4, 14))
        for label, cmd in (
            ("Copy", self._results_copy),
            ("Save TXT", self._results_save_txt),
            ("Export JSON", self._results_export_json),
            ("Generate Report", self._results_generate_report),
        ):
            tk.Button(actions, text=label, command=cmd, bg=self.theme["BG_LIGHT"],
                      fg=self.theme["FG"], relief="flat", padx=10, pady=4).pack(side="left", padx=(0, 6))

    # -- results text/JSON serialization -------------------------------
    def _results_as_text(self):
        r = self._last_results
        _, status_label = _RESULT_STATUS.get(str(r["status"]).lower(), _RESULT_STATUS["unknown"])
        lines = [r["tool"], f"Generated: {r['generated_at']}", "", f"RESULTS - {status_label}", ""]
        for label, value, _st in r["stats"]:
            lines.append(f"{label}: {value}")
        lines += ["", "DETAILS"]
        for text, kind in r["details"]:
            mark = {"good": "[OK]", "ok": "[OK]", "pass": "[OK]", "warn": "[WARN]",
                    "warning": "[WARN]", "info": "[INFO]", "bad": "[FAIL]",
                    "fail": "[FAIL]", "critical": "[FAIL]"}.get(str(kind).lower(), "[-]")
            lines.append(f"{mark} {text}")
        return "\n".join(lines)

    def _results_as_json(self):
        r = self._last_results
        return json.dumps({
            "tool": r["tool"],
            "generated_at": r["generated_at"],
            "status": r["status"],
            "stats": [{"label": l, "value": v} for l, v, _st in r["stats"]],
            "details": [{"text": t, "kind": k} for t, k in r["details"]],
        }, indent=2)

    def _require_results(self):
        if not getattr(self, "_last_results", None):
            messagebox.showinfo("No results yet", "Run this tool first, then use these actions.")
            return False
        return True

    def _results_copy(self):
        if not self._require_results():
            return
        try:
            root = self.parent.winfo_toplevel()
            root.clipboard_clear()
            root.clipboard_append(self._results_as_text())
        except tk.TclError:
            pass

    def _results_save_txt(self):
        if not self._require_results():
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Text file", "*.txt")],
            initialfile=f"{self._last_results['tool']}_results.txt".replace(" ", "_"))
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._results_as_text())
        except OSError as e:
            messagebox.showerror("Save failed", str(e))

    def _results_export_json(self):
        if not self._require_results():
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=[("JSON file", "*.json")],
            initialfile=f"{self._last_results['tool']}_results.json".replace(" ", "_"))
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._results_as_json())
        except OSError as e:
            messagebox.showerror("Export failed", str(e))

    def _results_generate_report(self):
        """Writes a readable plain-text report (header block + full
        details) - a friendlier superset of Save TXT for handing to a
        client or filing away. Purely a formatted export; it does not
        change any system state and is independent of the app-wide
        Diagnostics & Reports history."""
        if not self._require_results():
            return
        r = self._last_results
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Report", "*.txt")],
            initialfile=f"{r['tool']}_report.txt".replace(" ", "_"))
        if not path:
            return
        divider = "=" * 60
        # _results_as_text() already starts with "<tool>\nGenerated: ..." -
        # drop those two lines here since the report header repeats them
        # in a more report-like format.
        body_lines = self._results_as_text().split("\n")[2:]
        header = [divider, f"TECHDRIVE REPORT - {r['tool']}".upper(),
                  f"Generated: {r['generated_at']}", divider]
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(header + body_lines))
        except OSError as e:
            messagebox.showerror("Report generation failed", str(e))
