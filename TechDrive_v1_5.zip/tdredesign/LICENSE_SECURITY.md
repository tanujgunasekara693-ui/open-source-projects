# TechDrive license security

TechDrive uses **TD2 Ed25519-signed licenses**.

- `techdrive.py` contains only the public verification key.
- `techdrive_keygen.py` is an offline vendor tool and is excluded from the packaged executable.
- The private signing key must be kept outside the source tree and release archives.
- Set `TECHDRIVE_LICENSE_PRIVATE_KEY` to the private PEM path when issuing a key, or pass `--private-key`.
- Legacy HMAC/salt license keys are intentionally rejected because the old symmetric secret had to be present in the client and could therefore be extracted and used to forge keys.

A sample private key for this development build was generated outside the release archive at `/mnt/data/TechDrive_LICENSE_PRIVATE_KEY.pem`. Keep it private. For a real production release, generate a fresh keypair and replace the public key in `license_signing.py` before shipping.
