# TechDrive Windows Tool Panel Smoke Test

**Host:** Windows-10-10.0.19045-SP0 / Python 3.14.5 / Tk 8.6
**Started:** 2026-10-02T10:58:33+05:30
**Finished:** 2026-10-02T10:58:43+05:30

Full catalogue regression after the reported fixes.
Panels were constructed and Tk idle layout checked. Tool controls were not invoked; background refreshes were deferred; direct processes, threads, browsers, and modal/file dialogs were blocked.

- Total: **551**
- PASS: **492**
- FAIL: **0**
- GUARDED: **59**
- Refreshes deferred: **418**

## System Repair

| Category | Tool | Status | Detail |
|---|---|---|---|
| System Repair | SFC Scan | PASS | Constructor and Tk idle layout completed. |
| System Repair | DISM Restore | PASS | Constructor and Tk idle layout completed. |
| System Repair | BSOD Analyzer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Repair | Registry Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Repair | DLL Fixer | PASS | Constructor and Tk idle layout completed. |
| System Repair | Boot Repair | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Repair | System Restore | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Repair | File Checker | PASS | Constructor and Tk idle layout completed. |
| System Repair | Component Store | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Repair | Health Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Restore | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Compactor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Key Search | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Export | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Import | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Monitor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Defrag | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Tools | Compare | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Editor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Restore | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Compactor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Monitor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Key Finder | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Value Editor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Permission Editor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Registry Advanced | Snapshot | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | DLL Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Register | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Unregister | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Fixer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Search | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Version | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Dependency | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Conflict | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Missing Fix | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| DLL Tools | Path Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## File Management

| Category | Tool | Status | Detail |
|---|---|---|---|
| File Search | Advanced Search | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search by Name | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search by Type | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search by Date | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search by Size | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search Content | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search Extension | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search Location | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search Attributes | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File Search | Search Hash | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Batch Rename | Rename Files | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Rename Folders | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Rename Extensions | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Pattern Rename | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Counter Rename | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Date Rename | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Regex Rename | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Preview | PASS | Constructor and Tk idle layout completed. |
| Batch Rename | Undo | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Batch Rename | Advanced Rules | PASS | Constructor and Tk idle layout completed. |

## Hardware Testing

| Category | Tool | Status | Detail |
|---|---|---|---|
| CPU Test | Stress Test | PASS | Constructor and Tk idle layout completed. |
| CPU Test | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Stability Test | PASS | Constructor and Tk idle layout completed. |
| CPU Test | Prime95 Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Linpack Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Cinebench Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Geekbench Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Thermal Test | PASS | Constructor and Tk idle layout completed. |
| CPU Test | Core Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Test | Thread Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | CPU Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Stress Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Temperature | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Fan Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Core Parking | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Virtualization Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Microcode | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Load Monitor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Tools | Cache Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Stress Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | FurMark-style Load Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | 3DMark-style Score | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | VRAM Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Stability Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Thermal Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Clock Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Voltage Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Test | Driver Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Stress Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | MemTest86 Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Memory Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Cache Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Speed Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | ECC Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Stability Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Error Scan | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Test | Diagnostic Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | RAM Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Stress Test | PASS | Constructor and Tk idle layout completed. |
| RAM Tools | Cache Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Speed Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Slot Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Timings | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | ECC Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Page File Manager | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Tools | Diagnostic Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | Motherboard Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | Chipset Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | PCI Devices | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | USB Controllers | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | SATA Controllers | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | NVMe Controllers | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | Slot Information | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | System Serial | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | Hardware Inventory | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Motherboard Tools | DMI Table Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | BIOS Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Version Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Manufacturer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Date | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Serial | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Boot Order | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | UEFI Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Secure Boot | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | TPM Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| BIOS Tools | Settings Viewer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Display Tools | Display Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Display Tools | Resolution | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Refresh Rate | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Color Calibration | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Multi-Monitor | GUARDED | Blocked before execution: subprocess.run |
| Display Tools | Screen Capture | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Screen Recording | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Night Mode | PASS | Constructor and Tk idle layout completed. |
| Display Tools | Wallpaper | PASS | Constructor and Tk idle layout completed. |
| Display Tools | DPI Settings | PASS | Constructor and Tk idle layout completed. |
| Audio Tools | Device Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Test Playback | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Microphone Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Sound Card Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Driver Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Speaker Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Volume Control | PASS | Constructor and Tk idle layout completed. |
| Audio Tools | Format Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Latency Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Audio Tools | Surround Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Printer List | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Queue | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Driver Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Test Page | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Network Scanner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Sharing | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Fax | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Scanner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Printer Tools | Document Scanning | PASS | Constructor and Tk idle layout completed. |
| Gaming Tools | Game Mode | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | GPU Optimization | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Latency Reduction | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | FPS Monitor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Overclock Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Game Bar | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | DirectX Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Vulkan Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Scheduler | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Gaming Tools | Performance Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| System Summary | System Overview | GUARDED | RuntimeError: Blocked Thread.start |

## OS and Utilities

| Category | Tool | Status | Detail |
|---|---|---|---|
| OS Tools | OS Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Version | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Build | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | License Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Product Key | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Install Date | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Boot Time | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Uptime | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Architecture | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Tools | Edition | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Boot Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Repair | PASS | Constructor and Tk idle layout completed. |
| Boot Tools | Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Manager | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Order | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Menu | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Configuration | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Boot Tools | Error Check | PASS | Constructor and Tk idle layout completed. |
| Boot Tools | Performance | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Terminal Tools | PowerShell Launcher | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | CMD Launcher | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | Multiplexer | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | Script Runner | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | History | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Terminal Tools | Scheduler | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Terminal Tools | Log Viewer | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | Monitor | PASS | Constructor and Tk idle layout completed. |
| Terminal Tools | Shortcuts | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Terminal Tools | Customizer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Magnifier | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Color Filters | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | High Contrast | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Mouse Pointer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Text Size | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Narrator | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Speech Recognition | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | On-Screen Keyboard | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Sticky Keys | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Accessibility Tools | Filter Keys | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## Network and Cloud

| Category | Tool | Status | Detail |
|---|---|---|---|
| Network Tools | Network Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | Adapters | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | IP Config | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | Ping | PASS | Constructor and Tk idle layout completed. |
| Network Tools | Traceroute | PASS | Constructor and Tk idle layout completed. |
| Network Tools | DNS Lookup | PASS | Constructor and Tk idle layout completed. |
| Network Tools | Stats | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | ARP Table | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | Routing Table | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Tools | Monitor | PASS | Constructor and Tk idle layout completed. |
| Network Monitor | Usage Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Network Monitor | Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Packets | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Errors | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Connections | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Latency | PASS | Constructor and Tk idle layout completed. |
| Network Monitor | Bandwidth | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Traffic | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Protocol Stats | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Monitor | Performance Log | PASS | Constructor and Tk idle layout completed. |
| Network Security | Firewall Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | Firewall Rules | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | Security Scan | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | Port Scanner | PASS | Constructor and Tk idle layout completed. |
| Network Security | Vulnerability Scan | PASS | Constructor and Tk idle layout completed. |
| Network Security | SSL/TLS Check | PASS | Constructor and Tk idle layout completed. |
| Network Security | Proxy Settings | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | VPN Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | Encryption Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Network Security | Access Control | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | Bandwidth Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | Stability | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | DNS Flush | PASS | Constructor and Tk idle layout completed. |
| Internet Tools | IP Release/Renew | PASS | Constructor and Tk idle layout completed. |
| Internet Tools | Website Checker | PASS | Constructor and Tk idle layout completed. |
| Internet Tools | Geolocation | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | Port Forwarding | PASS | Constructor and Tk idle layout completed. |
| Internet Tools | ISP Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | Speed Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Internet Tools | Latency Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | WiFi Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Networks | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Connect | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Disconnect | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Password Viewer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Signal Strength | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Channel Analyzer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Profile | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Adapter Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| WiFi Tools | Security Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Ethernet Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Duplex | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Wake-on-LAN | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | MAC Address | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Cable Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Port Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Driver Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | IPv6 Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Ethernet Tools | Jumbo Frame | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Storage Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Sync Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | File Manager | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Backup Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Space Analyzer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Speed Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Sharing | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Security | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Version History | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Cloud Tools | Auto-Sync | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Folder Sync | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | File Sync | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Sync to Cloud | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Sync to USB | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Sync to External Drive | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Sync to NAS | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Sync to Network | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Backup Sync | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Schedule Sync | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Sync Tools | Conflict Resolution | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## Security and Privacy

| Category | Tool | Status | Detail |
|---|---|---|---|
| Security Tools | Windows Security | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | Firewall | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | Defender | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | UAC | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | BitLocker | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | TPM | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | Secure Boot | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | AppLocker | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | Windows Update | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Security Tools | Audit Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Privacy Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Browser Cache | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Cookies | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | History Cleaner | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Recent Documents | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Run History | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Temp Files | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Clipboard | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | DNS Cache | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Privacy Tools | Windows Logs | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | WiFi Password | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Windows Key | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Office Key | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Browser Passwords | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Generator | PASS | Constructor and Tk idle layout completed. |
| Password Tools | Strength Checker | PASS | Constructor and Tk idle layout completed. |
| Password Tools | Manager Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Expiry Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | Policy Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Password Tools | History | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | File Encryption | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | File Decryption | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Folder Encryption | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Folder Decryption | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Disk Encryption Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | BitLocker Enable | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | BitLocker Disable | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Recovery Key | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Certificate Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Encryption Tools | Audit Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## Disk and Storage Management

| Category | Tool | Status | Detail |
|---|---|---|---|
| Cloning & Imaging | Drive to Drive Clone | GUARDED | Blocked before execution: subprocess.run |
| Cloning & Imaging | Create Disk Image | GUARDED | Blocked before execution: subprocess.run |
| Cloning & Imaging | Restore Disk Image | GUARDED | Blocked before execution: subprocess.run |
| Cloning & Imaging | Volume File Clone | PASS | Constructor and Tk idle layout completed. |
| Cloning & Imaging | Clone Verify | PASS | Constructor and Tk idle layout completed. |
| Disk Monitor | Usage Graph | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Read Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Write Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | I/O | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Queue Length | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Response Time | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Active Time | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Heatmap | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Partition Usage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Monitor | Performance Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Write Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Read Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Sequential Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Random Access Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Benchmark | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | CrystalDiskMark Style | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Performance Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Stress Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | Surface Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Test | SMART Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Tools | Disk Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Tools | Cleanup | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | Defrag | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | SMART Health | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Tools | Partition Manager | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Disk Tools | Secure Erase | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | Clone | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | Benchmark | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | Space Analyzer | PASS | Constructor and Tk idle layout completed. |
| Disk Tools | Format Tool | PASS | Constructor and Tk idle layout completed. |
| Partition Tools | Partition Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Partition Tools | Resize | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Create | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Delete | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Format | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Merge | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Split | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Move | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Recovery | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Table Backup | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Table Restore | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Convert to MBR | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Geometry | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Modify MBR/GUID | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | SMART Info | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Speed Test | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Bad Sector Scan | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Delete All Partitions | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Image Backup | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Image Restore | GUARDED | Blocked before execution: subprocess.run |
| Storage Health | SMART Status | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Attributes | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Self-Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Error Log | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Temperature | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Predictive Failure | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Wear Level | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Reallocated Sectors | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Uncorrectable Sectors | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Storage Health | Health Report | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover Deleted | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover Formatted | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover Partitions | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover Photos | PASS | Constructor and Tk idle layout completed. |
| Data Recovery | Recover Documents | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover Emails | PASS | Constructor and Tk idle layout completed. |
| Data Recovery | Recover Crashed Drive | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover USB | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Recover SD | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Data Recovery | Deep Scan | PASS | Constructor and Tk idle layout completed. |
| Recovery Advanced | Data Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Partition Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | File Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Photo Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Video Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Document Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Email Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Database Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | System State Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Recovery Advanced | Full System Recovery | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | System Restore Point | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | Creator | PASS | Constructor and Tk idle layout completed. |
| Restore Tools | Restore | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | Delete | PASS | Constructor and Tk idle layout completed. |
| Restore Tools | Image Backup | PASS | Constructor and Tk idle layout completed. |
| Restore Tools | Image Restore | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | Recovery Partition | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Restore Tools | Recovery Media | PASS | Constructor and Tk idle layout completed. |
| Restore Tools | System State Backup | PASS | Constructor and Tk idle layout completed. |
| Backup Tools | System Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | File Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Folder Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Registry Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Driver Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Application Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | User Data Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Settings Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | System State Backup | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Backup Tools | Automated Schedule | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Find Duplicate Files | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Names | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Sizes | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Hashes | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Content | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Photos | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Documents | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Music | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Duplicate Videos | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Duplicate Finder | Batch Remover | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Shredder Tools | File Shredder | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Folder Shredder | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Disk Wipe 1-Pass | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Disk Wipe 3-Pass | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Disk Wipe 7-Pass | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Disk Wipe DoD | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Free Space Wipe | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Recycle Bin Shredder | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Registry Key Shredder | PASS | Constructor and Tk idle layout completed. |
| Shredder Tools | Secure Delete | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Secure Wipe Drive | GUARDED | Blocked before execution: subprocess.run |
| Wipe Tools | Wipe Partition | GUARDED | Blocked before execution: subprocess.run |
| Wipe Tools | Wipe File | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Wipe Folder | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Wipe Free Space | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Wipe Recycle Bin | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Wipe Registry Key | PASS | Constructor and Tk idle layout completed. |
| Wipe Tools | Wipe USB | GUARDED | Blocked before execution: subprocess.run |
| Wipe Tools | Wipe SD | GUARDED | Blocked before execution: subprocess.run |
| Wipe Tools | Wipe Network Drive | PASS | Constructor and Tk idle layout completed. |
| Archive Tools | Zip | GUARDED | RuntimeError: Blocked tkinter.messagebox.askyesno |
| Archive Tools | Unzip | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| Archive Tools | RAR | GUARDED | RuntimeError: Blocked tkinter.filedialog.askdirectory |
| Archive Tools | UnRAR | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| Archive Tools | 7z | GUARDED | RuntimeError: Blocked tkinter.filedialog.askdirectory |
| Archive Tools | Un7z | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| Archive Tools | Tar | GUARDED | RuntimeError: Blocked tkinter.filedialog.askdirectory |
| Archive Tools | Untar | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| Archive Tools | Gzip | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| Archive Tools | Gunzip | GUARDED | RuntimeError: Blocked tkinter.filedialog.askopenfilename |
| File System Tools | FAT32 Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | NTFS Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | exFAT Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Repair | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Convert | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Mount | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Unmount | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Journal | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| File System Tools | Compression | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Migration & Recovery | OS Migration Wizard | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Backup Partition | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Restore Partition | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Partition Recovery Scanner | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | File Recovery Scanner | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Quick File Undelete | PASS | Constructor and Tk idle layout completed. |
| OS Migration & Recovery | Partition Table Viewer | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| OS Migration & Recovery | Migration Health Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## System and Diagnostics

| Category | Tool | Status | Detail |
|---|---|---|---|
| Live Monitor | CPU Live Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | RAM Live Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | GPU Live Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | Disk Activity Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | Network Live Graph | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | Drive Temperatures | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | Drive Space Map | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | All Sensors Dashboard | GUARDED | RuntimeError: Blocked Thread.start |
| Live Monitor | Sensor Log Export | GUARDED | RuntimeError: Blocked Thread.start |
| CPU Monitor | Usage Graph | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Temperature | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Fan Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Voltage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Load | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Core Usage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Threads | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Processes | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | Interrupts | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| CPU Monitor | C-States | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | GPU Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Usage Graph | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Temperature | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Fan Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Memory Usage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Clock Speed | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Voltage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Driver Version | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Performance | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| GPU Monitor | Multi-Monitor | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Usage Graph | PASS | Constructor and Tk idle layout completed. |
| RAM Monitor | Available | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Used | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Cache | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Page File | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Commit Charge | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Memory Map | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Process Usage | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Performance | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| RAM Monitor | Error Check | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Monitor Test | Pixel Tester | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Color Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Refresh Rate Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Monitor Test | Resolution Test | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| Monitor Test | Dead Pixel Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Burn-in Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Contrast Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Brightness Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Gamma Test | PASS | Constructor and Tk idle layout completed. |
| Monitor Test | Calibration | PASS | Constructor and Tk idle layout completed. |
| NVIDIA GPU | Hotspot Temperature | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | GPU Power & Clocks | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | VRAM Monitor | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | Fan & Cooling | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | Throttle Reasons | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | GPU Process List | GUARDED | RuntimeError: Blocked Thread.start |
| NVIDIA GPU | Card & Driver Info | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |
| NVIDIA GPU | Full Driver Report | PASS | Constructor and Tk idle layout completed. Initial refresh deferred. |

## Guarded operations

Intercepted before execution; these remain unverified by panel construction.

- Hardware Testing / Display Tools / Multi-Monitor: `subprocess.run`
- Hardware Testing / System Summary / System Overview: `Thread.start`
- Network and Cloud / Network Monitor / Usage Graph: `Thread.start`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Create Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Create Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Restore Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Restore Disk Image: `subprocess.run`
- Disk and Storage Management / Partition Tools / Resize: `subprocess.run`
- Disk and Storage Management / Partition Tools / Create: `subprocess.run`
- Disk and Storage Management / Partition Tools / Create: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete: `subprocess.run`
- Disk and Storage Management / Partition Tools / Format: `subprocess.run`
- Disk and Storage Management / Partition Tools / Merge: `subprocess.run`
- Disk and Storage Management / Partition Tools / Merge: `subprocess.run`
- Disk and Storage Management / Partition Tools / Split: `subprocess.run`
- Disk and Storage Management / Partition Tools / Move: `subprocess.run`
- Disk and Storage Management / Partition Tools / Move: `subprocess.run`
- Disk and Storage Management / Partition Tools / Recovery: `subprocess.run`
- Disk and Storage Management / Partition Tools / Recovery: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Convert to MBR: `subprocess.run`
- Disk and Storage Management / Partition Tools / Convert to MBR: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Geometry: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Geometry: `subprocess.run`
- Disk and Storage Management / Partition Tools / Modify MBR/GUID: `subprocess.run`
- Disk and Storage Management / Partition Tools / Modify MBR/GUID: `subprocess.run`
- Disk and Storage Management / Partition Tools / SMART Info: `subprocess.run`
- Disk and Storage Management / Partition Tools / SMART Info: `subprocess.run`
- Disk and Storage Management / Partition Tools / Speed Test: `subprocess.run`
- Disk and Storage Management / Partition Tools / Bad Sector Scan: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete All Partitions: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete All Partitions: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Restore: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Secure Wipe Drive: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Secure Wipe Drive: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Wipe Partition: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Wipe USB: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Wipe USB: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Wipe SD: `subprocess.run`
- Disk and Storage Management / Wipe Tools / Wipe SD: `subprocess.run`
- Disk and Storage Management / Archive Tools / Zip: `tkinter.messagebox.askyesno`
- Disk and Storage Management / Archive Tools / Unzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / RAR: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / UnRAR: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / 7z: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / Un7z: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Tar: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / Untar: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Gzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Gunzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Backup Partition: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Restore Partition: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Partition Recovery Scanner: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Partition Recovery Scanner: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / File Recovery Scanner: `subprocess.run`
- System and Diagnostics / Live Monitor / CPU Live Graph: `subprocess.run`
- System and Diagnostics / Live Monitor / CPU Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / RAM Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / GPU Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Disk Activity Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Network Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Drive Temperatures: `Thread.start`
- System and Diagnostics / Live Monitor / Drive Space Map: `Thread.start`
- System and Diagnostics / Live Monitor / All Sensors Dashboard: `Thread.start`
- System and Diagnostics / Live Monitor / Sensor Log Export: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Hotspot Temperature: `Thread.start`
- System and Diagnostics / NVIDIA GPU / GPU Power & Clocks: `Thread.start`
- System and Diagnostics / NVIDIA GPU / VRAM Monitor: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Fan & Cooling: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Throttle Reasons: `Thread.start`
- System and Diagnostics / NVIDIA GPU / GPU Process List: `Thread.start`
