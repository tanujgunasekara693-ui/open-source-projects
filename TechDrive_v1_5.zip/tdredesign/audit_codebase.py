#!/usr/bin/env python3
"""Fast release-hygiene audit for TechDrive.

This intentionally checks only high-signal patterns that previously caused
maintenance/security problems: bare exception handlers, shell=True outside
run_cmd(), dynamic f-strings passed to run_cmd(), duplicate Core tool panels,
and accidental packaging of development-only scripts.
"""
from __future__ import annotations
import ast
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
PYFILES = [p for p in ROOT.rglob("*.py") if ".git" not in p.parts and "__pycache__" not in p.parts]
errors: list[str] = []
warnings: list[str] = []

for path in PYFILES:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError as e:
        errors.append(f"AST parse failure: {path}:{e.lineno}: {e.msg}")
        continue
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            errors.append(f"bare except: {path}:{node.lineno}")
        if isinstance(node, ast.Call):
            # shell=True is permitted only inside the deliberately shell-backed
            # run_cmd helper. Every other subprocess call must be argv based.
            if isinstance(node.func, ast.Attribute) and node.func.attr in {"run", "Popen", "check_output", "check_call"}:
                if any(k.arg == "shell" and isinstance(k.value, ast.Constant) and k.value.value is True for k in node.keywords):
                    parent_ok = False
                    # locate enclosing function approximately by source line
                    for fn in ast.walk(tree):
                        if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and fn.lineno <= node.lineno <= getattr(fn, "end_lineno", fn.lineno):
                            parent_ok = fn.name == "run_cmd"
                            break
                    if not parent_ok:
                        errors.append(f"shell=True outside run_cmd: {path}:{node.lineno}")
            if isinstance(node.func, ast.Name) and node.func.id == "run_cmd" and node.args and isinstance(node.args[0], ast.JoinedStr):
                errors.append(f"dynamic f-string passed to run_cmd: {path}:{node.lineno}")

# Catch the class of GUI callback regressions where a tool references a
# legacy ``run``, ``redraw`` or ``box`` name that is not actually defined
# in the tool function.  These failures often survive compilation and only
# appear when a user clicks Refresh/Enable/Disable.
for path in PYFILES:
    try:
        module_tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        continue
    module_globals = {n.name for n in module_tree.body
                      if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    for fn in [n for n in module_tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith("tool_")]:
        local_names: set[str] = set()
        for node in ast.walk(fn):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node is not fn:
                local_names.add(node.name)
            elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Param)):
                local_names.add(node.id)
        loaded = {node.id for node in ast.walk(fn)
                  if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
                  and node.id in {"run", "redraw", "box"}}
        missing = loaded - local_names - module_globals
        for name in sorted(missing):
            errors.append(f"undefined GUI callback name {name!r}: {path}:{fn.lineno} ({fn.name})")

        # A nested worker named ``run`` must actually be dispatched.  A
        # surprisingly common copy/paste failure is to define it and then
        # forget the self._run_bg(run, ...) call entirely.
        for child in fn.body:
            if isinstance(child, ast.FunctionDef) and any(
                isinstance(x, ast.FunctionDef) and x.name == "run" for x in child.body
            ):
                if not any(
                    isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute)
                    and x.func.attr == "_run_bg" for x in ast.walk(child)
                ):
                    errors.append(f"nested GUI worker is never dispatched: {path}:{child.lineno} ({fn.name}.{child.name})")

        # CardPanel owns the parent frame's geometry.  Legacy helper rows
        # must therefore be placed in panel.body, not packed alongside the
        # CardPanel canvas in the same parent (Tkinter raises TclError).
        if any(isinstance(x, ast.Call) and isinstance(x.func, ast.Name)
               and x.func.id == "CardPanel" for x in ast.walk(fn)):
            for node in ast.walk(fn):
                if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                        and node.func.attr in {"_button_row", "_entry_row"}):
                    if node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == "frame":
                        errors.append(f"CardPanel geometry conflict (helper uses frame): {path}:{node.lineno} ({fn.name})")

# Detect duplicate panel identity among actual tool implementations.
main = ROOT / "techdrive.py"
tree = ast.parse(main.read_text(encoding="utf-8", errors="replace"))
seen: dict[tuple[str, str], tuple[str, int]] = {}
for fn in [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith("tool_")]:
    for call in ast.walk(fn):
        if isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == "CardPanel" and len(call.args) >= 2:
            title = call.args[1].value if isinstance(call.args[1], ast.Constant) else None
            icon = None
            for kw in call.keywords:
                if kw.arg == "icon" and isinstance(kw.value, ast.Constant):
                    icon = kw.value.value
            if isinstance(title, str) and isinstance(icon, str):
                key = (title, icon)
                if key in seen and seen[key][0] != fn.name:
                    errors.append(f"duplicate tool panel ({title!r}, {icon!r}): {seen[key][0]} and {fn.name}")
                else:
                    seen[key] = (fn.name, call.lineno)

# A release must never contain the old shared license secret. A client-side
# symmetric secret can be extracted from a packaged executable and used to
# forge licenses. TD2 uses public-key verification instead.
for path in PYFILES:
    if path.name in {"techdrive_keygen.py", "generate_license_keypair.py", "audit_codebase.py"}:
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    if "TechDrive-H4ck3r-2026!@#$%^&*()" in text:
        errors.append(f"client-side TechDrive license secret found: {path}")

# TODO/FIXME are warnings rather than hard failures: some can be intentional.
for path in PYFILES:
    if path.name == "audit_codebase.py":
        continue
    for i, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if re.search(r"\b(?:TODO|FIXME)\b", line, re.I):
            warnings.append(f"TODO/FIXME: {path}:{i}: {line.strip()}")

spec = ROOT / "techdrive.spec"
spec_text = spec.read_text(encoding="utf-8", errors="replace")
for dev_file in ("test_ai_key", "techdrive_keygen", "unified_keygen", "generate_license_keypair", "windows_compatibility_verification"):
    if f'"{dev_file}"' not in spec_text:
        errors.append(f"dev/build-only module is not explicitly excluded in spec: {dev_file}")

print(f"Scanned {len(PYFILES)} Python files")
if errors:
    print("FAIL")
    print("\n".join(errors))
    if warnings:
        print("Warnings:")
        print("\n".join(warnings))
    raise SystemExit(1)
print("PASS: no high-signal hygiene findings")
if warnings:
    print("Warnings:")
    print("\n".join(warnings))
