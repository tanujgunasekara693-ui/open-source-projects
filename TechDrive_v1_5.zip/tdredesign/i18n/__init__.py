#!/usr/bin/env python3
"""
i18n — TechDrive translation engine
====================================
Small, dependency-free i18n layer built for this app's existing patterns
(duck-typed modules, `shared.database` for persisted settings, Tk widgets
built directly rather than through a templating layer).

Usage
-----
    from i18n import t, set_language, get_language, LANGUAGES

    tk.Label(parent, text=t("settings.language.title"))

Strings are looked up in `i18n/locales/<code>.json`. Missing keys fall
back to English, then to the raw key itself (so a missing translation is
visibly a bug, never a blank label).

Live language switching
------------------------
Because this app builds its widgets directly (no templating re-render
pass), switching language at runtime does not retroactively re-label
already-built widgets. `on_language_change(callback)` lets any module
register a callback that's invoked after the language changes, so it can
rebuild/relabel itself — the same pattern `app.apply_theme_choice` already
uses for live theme switching. Modules that don't register simply pick up
the new language next time they're opened (same contract the old
"Saved as a preference" language stub described).

Fonts
-----
Sinhala, Tamil, and Japanese are not reliably covered by Tk's default
system font on Windows/Linux (Segoe UI / DejaVu Sans lack most of those
glyph ranges — you'll get "tofu" boxes). `font_for_language()` returns a
font-family fallback chain per language; see FONT_REQUIREMENTS below for
what needs to be installed/bundled for correct rendering.
"""

import json
import os

try:
    from shared import database as db
except Exception:                                  # pragma: no cover - standalone use
    db = None

_LOCALES_DIR = os.path.join(os.path.dirname(__file__), "locales")

# code -> display name, shown in the Settings language dropdown
LANGUAGES = {
    "en": "English",
    "si": "Sinhala (\u0dc3\u0dd2\u0d82\u0dc4\u0dbd)",
    "ta": "Tamil (\u0ba4\u0bae\u0bbf\u0bb4\u0bcd)",
    "ja": "Japanese (\u65e5\u672c\u8a9e)",
    "ru": "Russian (\u0420\u0443\u0441\u0441\u043a\u0438\u0439)",
}

DEFAULT_LANGUAGE = "en"

# Fonts known to cover each script. Listed in priority order; Tk silently
# falls back to the next installed one, and to its own default if none of
# these are present (which is what causes tofu boxes for si/ta/ja).
FONT_REQUIREMENTS = {
    "en": ["Segoe UI", "Arial", "Helvetica"],
    "si": ["Noto Sans Sinhala", "Iskoola Pota", "Nirmala UI"],
    "ta": ["Noto Sans Tamil", "Latha", "Nirmala UI"],
    "ja": ["Noto Sans JP", "Yu Gothic UI", "Meiryo", "MS Gothic"],
    "ru": ["Segoe UI", "Arial", "Helvetica"],   # Cyrillic is covered by the usual UI fonts
}

_cache = {}          # code -> {key: value}
_listeners = []       # callables invoked on language change
_current = None


def _flatten(d, prefix=""):
    """Flatten nested JSON ({"a": {"b": "x"}}) into dotted keys ({"a.b": "x"})."""
    out = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out.update(_flatten(v, key))
        else:
            out[key] = v
    return out


def _load(code):
    if code in _cache:
        return _cache[code]
    path = os.path.join(_LOCALES_DIR, f"{code}.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        flat = _flatten(raw)
    except (FileNotFoundError, json.JSONDecodeError):
        flat = {}
    _cache[code] = flat
    return flat


def get_language():
    global _current
    if _current is None:
        stored = db.get_setting("language_code", DEFAULT_LANGUAGE) if db else DEFAULT_LANGUAGE
        _current = stored if stored in LANGUAGES else DEFAULT_LANGUAGE
    return _current


def set_language(code, persist=True):
    global _current
    if code not in LANGUAGES:
        raise ValueError(f"Unknown language code: {code!r}")
    _current = code
    if persist and db:
        db.set_setting("language_code", code)
        # Keep the legacy display-name setting in sync for anything still
        # reading the old "language" key.
        db.set_setting("language", LANGUAGES[code])
    _load(code)
    for cb in list(_listeners):
        try:
            cb(code)
        except Exception:
            pass  # a broken listener shouldn't break language switching for the rest


def on_language_change(callback):
    """Register a callback(code) invoked whenever the language changes.

    Returns the callback so this can be used as a plain function call at
    module init time without needing a separate unregister step for the
    common case (most listeners live as long as the app).
    """
    _listeners.append(callback)
    return callback


def off_language_change(callback):
    if callback in _listeners:
        _listeners.remove(callback)


def t(key, **kwargs):
    """Translate `key` (dotted path, e.g. 'topbar.search_placeholder').

    Falls back English -> raw key. kwargs are applied with str.format,
    so translators can reorder placeholders per-language, e.g.
    t("welcome", name=user) -> "{name} \u0d94\u0db6\u0dc0 \u0dc3\u0dca\u0dc0\u0dcf\u0d9c\u0dad\u0dba\u0dd2!"
    """
    code = get_language()
    flat = _load(code)
    value = flat.get(key)
    if value is None and code != DEFAULT_LANGUAGE:
        value = _load(DEFAULT_LANGUAGE).get(key)
    if value is None:
        value = key  # visible-but-not-crashing fallback
    if kwargs:
        try:
            return value.format(**kwargs)
        except (KeyError, IndexError):
            return value
    return value


def font_for_language(code=None, size=10, weight="normal"):
    """Return a Tk font tuple using the first installed font for `code`'s
    script. Call this instead of hardcoding font families for any label
    that will render translated text.
    """
    import tkinter.font as tkfont
    code = code or get_language()
    families = set(tkfont.families())
    for name in FONT_REQUIREMENTS.get(code, FONT_REQUIREMENTS["en"]):
        if name in families:
            return (name, size, weight)
    # Nothing from the chain is installed - Tk's default will show tofu
    # boxes for si/ta/ja. Last-resort fallback, at least keeps size/weight.
    return ("TkDefaultFont", size, weight)


def missing_font_warning(code=None):
    """Returns a warning string if the given language's preferred fonts
    aren't installed, else None. Useful for a one-time Settings notice.
    """
    import tkinter.font as tkfont
    code = code or get_language()
    if code in ("en", "ru"):
        return None
    families = set(tkfont.families())
    if any(name in families for name in FONT_REQUIREMENTS[code]):
        return None
    preferred = FONT_REQUIREMENTS[code][0]
    return t("settings.language.font_missing", font=preferred, language=LANGUAGES[code])


# Warm the cache for the active language at import time so the first t()
# call in a hot UI path (topbar build) isn't a cold file read.
_load(get_language() if db else DEFAULT_LANGUAGE)
