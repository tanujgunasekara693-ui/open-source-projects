# TechDrive v1.1 — 100-tool reliability pass

This update keeps the curated catalogue at exactly 100 tools while reducing duplicate concepts and improving guardrails around operations that can alter data or system state.

## Overlap removed

- **GPU Info:** one canonical GPU telemetry tool remains under GPU Monitor. The old extended-diagnostics slot is now **Sensor Availability**, which reports available optional sensor providers and limitations.
- **SMART Health / SMART Status:** detailed SMART health remains under Storage Health. The old Disk Tools duplicate is now **Volume Capacity**, which lists mounted volume capacity and free space.
- **Benchmark:** the duplicate Disk Tools benchmark is replaced by **Free Space Check**. Disk Test retains the main benchmark, with a separate Performance Test mode.
- **Windows Update Status / Windows Update:** the Security Tools Windows Update workflow remains. The old extended-diagnostics duplicate is now **System Uptime**.

## Reliability improvements

- Sensor Availability reports optional providers and explicitly warns that a present provider does not guarantee every sensor is exposed. Existing sensor readers should report unavailable readings rather than invent values.
- File-level Clone refuses identical or nested source/destination paths, preventing recursive self-copy, and warns that same-named destination files can be overwritten.
- Format Tool validates drive letter, filesystem, and volume label; requires Administrator privileges; checks that the target is mounted; refuses the Windows system drive; and fails closed if Windows cannot verify the target is not a boot/system volume. DiskPart return code and diagnostic text are surfaced.
- Disk Test benchmark setup refuses to overwrite an existing `_techdrive_disktest.tmp` and checks free space before writing.
- System Image Backup requires Administrator privileges, a reachable destination on a different drive from Windows, explicit confirmation, and reports command failures rather than treating empty output as success.
- Restore checks the selected sequence number against the current list of restore points before requesting restoration.
- SFC/DISM and boot repair retain explicit elevation checks and confirmations. Partition Manager remains read-only. Image Restore remains a listing/instructions tool; it does not start a destructive restore from the desktop.

## Validation performed

- Full source tree Python compilation (`compileall`) passed.
- All 11 automated tests passed: 8 existing notebook/tab regression tests and 3 new static catalogue/safety checks.
- Static AST catalogue audit passed: 100 catalogue entries across 15 curated modules, with each module's catalogue count matching its top-level `tool_*` function count.
- This environment is not a Windows hardware test bench. No claim is made that the destructive Windows operations or all hardware sensors have been exercised on your PC. Test them on a disposable/test Windows setup and keep a separate backup before release.
