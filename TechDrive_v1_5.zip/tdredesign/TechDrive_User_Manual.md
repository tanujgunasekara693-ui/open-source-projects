# TechDrive v1.1 — User Manual

TechDrive is an all-in-one PC repair and diagnostic utility. This guide
covers the interface, the built-in tools, and how to add more tools
through the Enable / Disable Tools.

---

## 1. Getting Started

When you launch TechDrive, you land on the **Dashboard**, which shows
a live snapshot of your system:

- **CPU / RAM / Storage / GPU / Network** cards with current usage
- A live usage graph (CPU, RAM, Disk, Network) updating in real time
- **System Overview** — OS, processor, uptime, user, system type, power plan
- **Quick Actions** — one-click shortcuts to the most commonly used tools
- **Recent Tools** — tools you've opened recently, for fast access

## 2. The Layout

**Top bar**
- **Search tools…** — type to jump straight to any tool by name
- **Quick Scan** — runs a fast health check across your system
- **Report** — generates a text summary report of your system's current state
- **Upgrade** — view upgrade/license options

**Category bar** (below the top bar)
Groups tools into: **System**, **Disk**, **Network**, **Repair**,
**Settings**. Click any category to browse the tools inside it.

**Left sidebar**
- **Dashboard** — return to the home screen
- **Enable / Disable Tools** — enable or disable bundled tool groups (see Section 4)
- **Settings** — app preferences, theme, and license info
- **About** — version and app info
- **All Tools** — expandable list of every installed tool, organized by category

**Tabs**
Every tool or page you open shows up as a tab along the top of the
main content area, so you can have several tools open side by side.
Click the **×** on a tab to close it.

## 3. Using a Tool

1. Open a tool either from the category bar, the sidebar's "All Tools"
   list, or by searching for it in the top search bar.
2. Most tools open with a **Refresh** button to re-run their scan or
   check.
3. Tools that make changes (cleaning, repairing, shredding files, etc.)
   will typically ask for confirmation before doing anything
   irreversible.
4. Results appear directly in the tool's tab — no separate windows.

### Quick Actions on the Dashboard

The Dashboard's Quick Actions panel gives one-click access to the most
common tools without navigating through categories:

- **Disk Cleanup** — clears temporary files and reclaims space
- **Disk Health** — checks drive status and SMART data
- **Registry Cleaner** — finds and removes invalid registry entries
- **Startup Manager** — enable/disable programs that launch at boot
- **Process Manager** — view and manage running processes
- **Speed Test** — checks your network speed
- **File Shredder** — securely deletes files beyond recovery
- **Duplicate Finder** — finds duplicate files taking up space

## 4. The Enable / Disable Tools

TechDrive ships lightweight — only a small core is installed by
default. All other tools (disk, network, security, repair utilities,
and more) are bundled with TechDrive and can be enabled or disabled from the Enable / Disable Tools.

To open it: click **Enable / Disable Tools** in the left sidebar.

- Each entry shows the tool group's name and how many individual tools
  it provides.
- Click **Disable** to remove that group from the active catalogue and
  search index without deleting its bundled files.
- Click **Enable** to restore a disabled group immediately.
- **Enable all** and **Disable all** provide bulk controls; TechDrive Core
  remains available even when optional groups are disabled.
- Tool state is remembered between app restarts, and no download is
  required for this page.

All bundled tools continue to work offline.

## 5. Generating a Report

Click **Report** in the top bar to save a text file summarizing your
system's current state — useful for keeping records or sharing
details with support.

## 6. Settings

Open **Settings** from the sidebar or the category bar to adjust:
- App theme/appearance
- Preferences for how tools behave
- License / upgrade status

## 7. Tips

- Use the **search bar** at the top instead of digging through
  categories — it's the fastest way to find a specific tool.
- The **Recent Tools** panel on the Dashboard keeps your last-used
  tools one click away.
- If a tool you expect isn't showing up, check the **Enable / Disable Tools** —
  it may not be installed yet.
- Multiple tools can be open in tabs at once; switch between them
  without losing your place.

## 8. What's New in v1.1

- **Help Center** — searchable manual with a contents sidebar, Back/Forward,
  adjustable text size, and its own menu bar (press **F1**).
- **EULA viewer** — jump between sections, find text, adjust text size,
  save or print a copy. The agreement itself is now version 1.1 and opens
  with a plain-language summary.
- **Aero-style Welcome Tour** — replay it any time from
  Settings → Welcome Tour.
- Every optional tool group is bundled and works offline.

## 9. TechDrive Core

TechDrive Core is the home of the first-party tools:

- **Health Center** — the one-click *SCAN MY PC* snapshot. Read-only.
- **Fix My PC** — pick a symptom ("PC is slow", "Apps crash") and TechDrive
  runs a short read-only check, then recommends tools.
- **Repair Center** — controlled, one-click repairs.
- **Security Center** — a read-only security posture review.
- **Network Lab** and **Performance Lab** — live network signals and
  measured performance, with the raw output shown.
- **Explain This PC** — turns your machine's live data into plain language.
- **Snapshot Manager** — named snapshots, optionally paired with a Windows
  restore point.
- **Technician Workspace** — a local support session that exports evidence
  only after you approve it. It never opens a remote-control channel.

## 10. Safety: Preview, Confirm, Execute, Verify

Repairs in the Repair Center always follow four stages. You see the exact
command **before** you confirm, and the result is checked when it finishes.
Health Center, Security Center and Fix My PC only read — they never repair,
delete or change anything.

Tools that can erase data (wipe, shred, format, repartition) can cause
permanent loss. Back up first, and only work on devices you are authorized to
service. In Settings → Keyboard & Shortcuts you can require holding the
button on destructive actions.

## 11. Focus Modes, Themes and Layout

- **Focus Modes** — Default, Repair, Gaming and Quiet. One click retunes
  motion, sounds and density; switch back any time.
- **Themes** — TechDrive Dark and Light, Midnight Blue, Developer,
  High Contrast, Windows 95/98 Classic and OLED Pure Black.
- **Mission Control** — an overview of your open tabs.
- **Stage Manager** — pin two or three tools side by side in one tab.
- **Languages** — English, Japanese, Russian, Sinhala and Tamil
  (Settings → Language).

## 12. The Duck Assistant

The Duck answers common PC-repair questions from a local knowledge base —
no network calls. An online AI lookup happens **only** if you enter your own
API key in Settings → AI Assistant and the local answer has no match.
You can hide the Duck in Settings → Duck Assistant.

## 13. Keyboard Shortcuts

| Keys | Action |
|---|---|
| F1 | Open the Help Center |
| Ctrl+K | Quick Search (tools and actions) |
| Ctrl+W | Close the current tool tab |
| Ctrl+Tab | Cycle between open tabs |
| Ctrl+Shift+R | Switch the ribbon between compact and full |
| Ctrl+Shift+C | Open the Control Center |
| Esc | Close the active dialog |

In the Help Center and EULA viewer: **Ctrl+F** find, **F3 / Shift+F3** next /
previous match, **Ctrl + / Ctrl −** text size, **Alt+← / Alt+→** back and forward.

Shortcuts can be changed in Settings → Keyboard & Shortcuts.

## 14. Troubleshooting

**A tool I expect is missing.** Open the Core Module Manager from the
sidebar; its group may be disabled. Click **Enable**.

**A scan or clone says it needs Administrator rights.** Raw drive access
requires Administrator (Windows) or root (Linux). Restart TechDrive as
Administrator.

**A sensor shows "not available".** Your hardware does not expose it.
TechDrive shows a gap rather than a made-up value.

**The Welcome Tour did not open.** It opens in your default browser.
Replay it from Settings → Welcome Tour.

**Something looks wrong after changing themes or Focus Mode.** Choose the
*Default* Focus Mode, or reset appearance in Settings.

## 15. Legal and Support

- **EULA** — Help → EULA opens the full agreement (version 1.1).
- **License** — Help → License Info, Activate License Key, or Buy License.
- Use **Report** (top bar) to save a system summary to send to support.

---

*TechDrive v1.1 — All-in-One System Utility. Fast. Lightweight. Powerful.*
