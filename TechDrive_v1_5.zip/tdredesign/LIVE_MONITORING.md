# Live Monitoring, NVIDIA Hotspot & Cloning

Three new categories were added to TechDrive. Everything reads real
hardware - there are no simulated or placeholder values anywhere. When a
sensor genuinely is not exposed by your machine, the panel says so and the
graph leaves a gap instead of drawing a fake number.

## Live Monitor  (sidebar group: Monitoring)
| Tool | What it shows |
|---|---|
| CPU Live Graph | load %, package temperature, clock, per-core bars |
| RAM Live Graph | memory + swap over time, installed DIMMs (slot/size/speed/part no.) |
| GPU Live Graph | load, VRAM %, core and hotspot temperature |
| Disk Activity Graph | read/write MB/s and IOPS |
| Drive Temperatures | temperature per physical SSD/HDD/NVMe + SMART health |
| Drive Space Map | used/free capacity per volume |
| All Sensors Dashboard | CPU, RAM, GPU and disk graphs on one screen |
| Sensor Log Export | appends every reading to a CSV you choose |

## NVIDIA GPU  (sidebar group: Monitoring)
Hotspot Temperature, GPU Power & Clocks, VRAM Monitor, Fan & Cooling,
Throttle Reasons, GPU Process List, Card & Driver Info, Full Driver Report.

**How hotspot is obtained:** NVML's public temperature API only returns the
edge sensor. On Ampere/Ada and newer the junction reading is derived from
the T.Limit fields (`shutdown threshold - reported slack`, NVML field IDs
193/195); older cards fall back to `nvidia-smi -q -d TEMPERATURE`, and
finally to LibreHardwareMonitor's WMI namespace if it is running.

## Cloning & Imaging  (sidebar group: Disk)
| Tool | What it does |
|---|---|
| Drive to Drive Clone | sector-by-sector physical drive copy, live MB/s + ETA + cancel |
| Create Disk Image | drive -> `.img` / `.img.gz`, optional SHA-256 sidecar |
| Restore Disk Image | image -> drive |
| Volume File Clone | file-level clone of a volume/folder, keeps timestamps |
| Clone Verify | SHA-256 both sides and compare (optionally first N GB) |

Raw drive access requires **Administrator (Windows) / root (Linux)**. The
panels detect this up front and warn before you start a job.

## Dependencies
```
pip install -r requirements.txt
```
`nvidia-ml-py` unlocks hotspot/VRAM temps, throttle flags and PCIe details.
`smartmontools` (the `smartctl` binary on PATH) unlocks drive temperatures
and SMART attributes. Running LibreHardwareMonitor in the background adds
CPU/AMD/Intel GPU sensors on Windows.

## Files added
```
gui/live_chart.py                  Canvas line-chart widget + background sampler
techdrive_modules/hw_sensors.py    shared real-sensor backend
techdrive_modules/live_monitor.py  Live Monitor category
techdrive_modules/nvidia_gpu.py    NVIDIA GPU category
techdrive_modules/clone_tools.py   Cloning & Imaging category
```
