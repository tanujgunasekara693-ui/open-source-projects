#!/usr/bin/env python3
"""
TechDrive Windows compatibility verification harness.

This is an external audit helper. It does not import a replacement UI, patch
TechDrive, rewrite the catalogue, or alter the application architecture.

Run from the TechDrive source directory on Windows:

    python windows_compatibility_verification.py

The default run performs a real import/plugin scan and constructs the real
TechDriveApp once, without entering its mainloop. To launch the real
application after the probe and keep it open for the manual checklist:

    python windows_compatibility_verification.py --launch

Results are written to:

    windows_compatibility_results.json
    windows_compatibility_results.md

The generated report deliberately distinguishes:
  - modules imported successfully by scan_plugins()
  - modules whose import failed, including the exact captured reason
  - catalogue totals after TechDriveApp installs the bundled plugins
  - probe/launch failures

The GUI behavior checklist remains manual because the test must exercise the
real Windows desktop, native utilities, dialogs, and user-visible effects.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import textwrap
from typing import Any


ROOT = Path(__file__).resolve().parent
RESULT_JSON = ROOT / "windows_compatibility_results.json"
RESULT_MD = ROOT / "windows_compatibility_results.md"

FAILURE_RE = re.compile(
    r"Failed to load plugin module (?P<module>[^:]+): (?P<reason>.*)"
)
REGISTRY_MARKER = "__TD_PLUGIN_MODULES__="
STATS_MARKER = "__TD_RUNTIME_STATS__="


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _probe_code() -> str:
    """Return a child-process probe that uses the unmodified application."""
    return textwrap.dedent(
        f"""
        import json
        import techdrive

        # Importing techdrive runs its real scan_plugins() call at module
        # scope. The registry below records every module that imported.
        print({REGISTRY_MARKER!r} + json.dumps(
            sorted(techdrive.PLUGIN_MODULES.keys()),
            ensure_ascii=False,
        ), flush=True)

        # TechDriveApp performs the real bundled-plugin installation and
        # constructs the real Tk shell. Do not enter mainloop here; this is a
        # bounded verification probe.
        app = techdrive.TechDriveApp()
        app.withdraw()
        try:
            catalogue = techdrive.CATALOGUE
            stats = {{
                "catalogue_categories": len(catalogue),
                "catalogue_tools": sum(len(tools) for _, _, tools in catalogue),
                "unique_categories": len({{cat for cat, _, _ in catalogue}}),
                "unique_tool_names": len({{tool for _, _, tools in catalogue for tool in tools}}),
                "dispatch_methods": sum(
                    1 for name in dir(techdrive.TechDriveApp)
                    if name.startswith("tool_")
                ),
                "plugin_registry_count": len(techdrive.PLUGIN_REGISTRY),
                "installed_plugin_count": len(techdrive.INSTALLED_PLUGINS),
                "window_class": type(app).__name__,
                "tk_version": app.tk.call("info", "patchlevel"),
            }}
            print({STATS_MARKER!r} + json.dumps(stats, ensure_ascii=False), flush=True)
        finally:
            app.destroy()
        """
    )


def _parse_probe_output(output: str) -> dict[str, Any]:
    imported: list[str] = []
    stats: dict[str, Any] = {}
    failures: list[dict[str, str]] = []

    for line in output.splitlines():
        match = FAILURE_RE.search(line)
        if match:
            failures.append(
                {
                    "module": match.group("module").strip(),
                    "reason": match.group("reason").strip(),
                    "raw": line,
                }
            )
        if line.startswith(REGISTRY_MARKER):
            try:
                imported = json.loads(line[len(REGISTRY_MARKER) :])
            except json.JSONDecodeError:
                pass
        if line.startswith(STATS_MARKER):
            try:
                stats = json.loads(line[len(STATS_MARKER) :])
            except json.JSONDecodeError:
                pass

    return {
        "successful_modules": imported,
        "failed_modules": failures,
        "runtime_stats": stats,
        "raw_probe_output": output,
    }


def run_import_and_shell_probe(timeout: int) -> dict[str, Any]:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    command = [sys.executable, "-c", _probe_code()]
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        output = (completed.stdout or "") + (completed.stderr or "")
        parsed = _parse_probe_output(output)
        parsed.update(
            {
                "probe_returncode": completed.returncode,
                "probe_timed_out": False,
            }
        )
        return parsed
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") + (exc.stderr or "")
        parsed = _parse_probe_output(output)
        parsed.update(
            {
                "probe_returncode": None,
                "probe_timed_out": True,
                "probe_timeout_seconds": timeout,
            }
        )
        return parsed
    except Exception as exc:  # Preserve the exact local launch failure.
        return {
            "successful_modules": [],
            "failed_modules": [],
            "runtime_stats": {},
            "raw_probe_output": "",
            "probe_returncode": None,
            "probe_timed_out": False,
            "probe_exception": f"{type(exc).__name__}: {exc}",
        }


def launch_real_application() -> dict[str, Any]:
    """Run the actual python techdrive.py process until the user closes it."""
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    try:
        completed = subprocess.run(
            [sys.executable, "techdrive.py"],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        output = (completed.stdout or "") + (completed.stderr or "")
        return {
            "launch_attempted": True,
            "launch_returncode": completed.returncode,
            "launch_output": output,
        }
    except Exception as exc:
        return {
            "launch_attempted": True,
            "launch_returncode": None,
            "launch_output": "",
            "launch_exception": f"{type(exc).__name__}: {exc}",
        }


MANUAL_CHECKLIST = [
    {
        "id": "dashboard",
        "area": "Dashboard and navigation",
        "steps": [
            "Launch with `python techdrive.py`.",
            "Confirm Dashboard opens and telemetry populates without traceback.",
            "Open All Tools and verify the category/tool totals from the probe.",
            "Open at least one representative tool from System, Disk, Network, Security, Repair, Monitoring, File, and Hardware.",
        ],
    },
    {
        "id": "shell_rebuilds",
        "area": "Settings and shell rebuilds",
        "steps": [
            "Change dark/light theme and confirm the shell rebuilds cleanly.",
            "Change accent color and font scale; confirm Dashboard, nav, top bar, status bar, and Settings remain usable.",
            "Toggle RGB accent master, edges, corners, speed, brightness, color mode, line style, and opacity.",
            "Toggle Aero Glass and XP Theme; confirm each can be disabled without stale overlays or broken controls.",
            "Toggle Duck Assistant and reopen it after a shell rebuild.",
        ],
    },
    {
        "id": "state_and_search",
        "area": "State, search, and tabs",
        "steps": [
            "Open tools and confirm Recent Tools updates.",
            "Favorite and unfavorite tools; verify the state survives closing/reopening the view.",
            "Use All Tools search and the top-bar search; press Ctrl+K and confirm focus moves to search.",
            "Open multiple tools, close tabs, and confirm Dashboard and Settings protection behavior.",
        ],
    },
    {
        "id": "reports_backup",
        "area": "Reports and settings backup",
        "steps": [
            "Generate TXT and PDF reports.",
            "Back up Settings to JSON, change a preference, restore the backup, and confirm the preference returns.",
            "Exercise Reset All Settings only after confirming the destructive prompt.",
        ],
    },
    {
        "id": "process_and_safeguards",
        "area": "Process guards and Windows-only safeguards",
        "steps": [
            "Launch a second TechDrive instance and confirm the single-instance dialog/guard.",
            "Attempt a Windows-only tool on Windows and confirm it runs or reports its exact native error.",
            "Exercise representative destructive/repair actions and confirm the existing confirmation dialogs remain present and accurately worded.",
            "Confirm cancellation paths do not execute the underlying command.",
        ],
    },
    {
        "id": "hidden_and_unusual",
        "area": "Developer, easter-egg, and prank systems",
        "steps": [
            "Verify the developer-mode trigger remains reachable.",
            "Verify Duck Assistant, onboarding tour, sidebar gadgets, and bundled easter-egg assets remain reachable.",
            "Open Prank / Threat Tester and verify its scan/history/report/cleanup flows without running untrusted samples.",
        ],
    },
]


def _checklist_markdown() -> str:
    lines = ["## Manual GUI checklist", ""]
    for item in MANUAL_CHECKLIST:
        lines.append(f"### {item['area']} (`{item['id']}`)")
        lines.append("")
        for step in item["steps"]:
            lines.append(f"- [ ] {step}")
        lines.append("")
    return "\n".join(lines)


def write_results(results: dict[str, Any]) -> None:
    RESULT_JSON.write_text(
        json.dumps(results, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    stats = results.get("runtime_stats", {})
    failures = results.get("failed_modules", [])
    successful = results.get("successful_modules", [])
    lines = [
        "# TechDrive Windows Compatibility Verification",
        "",
        f"**Generated:** {results['generated_at']}",
        f"**Host:** {results['host']['platform']} / Python {results['host']['python']}",
        "",
        "## Probe result",
        "",
        f"- Import/shell probe return code: `{results.get('probe_returncode')}`",
        f"- Probe timed out: `{results.get('probe_timed_out', False)}`",
        f"- Successfully imported modules: **{len(successful)}**",
        f"- Failed module imports: **{len(failures)}**",
        f"- Catalogue categories after real app construction: **{stats.get('catalogue_categories', 'unavailable')}**",
        f"- Catalogue tool entries after real app construction: **{stats.get('catalogue_tools', 'unavailable')}**",
        f"- Unique tool names: **{stats.get('unique_tool_names', 'unavailable')}**",
        f"- Tk version: **{stats.get('tk_version', 'unavailable')}**",
        "",
        "## Successfully loaded modules",
        "",
    ]
    lines.extend(f"- `{name}`" for name in successful)
    if not successful:
        lines.append("- No successful-module marker was captured.")

    lines.extend(["", "## Failed modules and exact reasons", ""])
    if failures:
        for failure in failures:
            lines.append(f"- `{failure['module']}` — `{failure['reason']}`")
    else:
        lines.append("- No module import failures were captured.")

    if results.get("probe_exception"):
        lines.extend(["", "## Probe exception", "", f"`{results['probe_exception']}`"])

    if results.get("launch_attempted"):
        lines.extend(
            [
                "",
                "## Real application launch",
                "",
                f"- Return code after the application closed: `{results.get('launch_returncode')}`",
                f"- Launch exception: `{results.get('launch_exception', 'none')}`",
            ]
        )

    lines.extend(
        [
            "",
            "## Architecture guard",
            "",
            "- This harness does not modify TechDrive source files.",
            "- TechDrive is launched with the existing `python techdrive.py` entry point.",
            "- No web framework, browser UI, replacement shell, or parallel implementation is used.",
            "",
            _checklist_markdown(),
            "",
            "## Raw probe output",
            "",
            "```text",
            results.get("raw_probe_output", "").rstrip(),
            "```",
            "",
        ]
    )
    RESULT_MD.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--launch",
        action="store_true",
        help="After the probe, launch the real TechDrive app and wait until it closes.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=180,
        help="Seconds allowed for the import/shell probe (default: 180).",
    )
    args = parser.parse_args()

    if os.name != "nt":
        print(
            "Refusing to claim Windows verification: this harness must run on Windows.",
            file=sys.stderr,
        )
        print(f"Detected platform: {platform.platform()}", file=sys.stderr)
        return 2

    if not (ROOT / "techdrive.py").is_file():
        print(f"techdrive.py was not found beside {Path(__file__).name}.", file=sys.stderr)
        return 2

    results: dict[str, Any] = {
        "generated_at": _now(),
        "host": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "executable": sys.executable,
            "cwd": str(ROOT),
        },
        "source_entry_point": str(ROOT / "techdrive.py"),
    }
    results.update(run_import_and_shell_probe(max(1, args.timeout)))
    if args.launch:
        results.update(launch_real_application())
    write_results(results)

    print(f"Wrote {RESULT_JSON}")
    print(f"Wrote {RESULT_MD}")
    if results.get("probe_returncode") != 0:
        return 1
    if results.get("failed_modules"):
        print(
            f"Captured {len(results['failed_modules'])} failed module imports; see the report."
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())