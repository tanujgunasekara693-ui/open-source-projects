# TechDrive Windows Compatibility Verification

**Generated:** 2026-09-29T17:57:55+05:30
**Host:** Windows-10-10.0.19045-SP0 / Python 3.14.5

## Probe result

- Import/shell probe return code: `0`
- Probe timed out: `False`
- Successfully imported modules: **71**
- Failed module imports: **0**
- Catalogue categories after real app construction: **69**
- Catalogue tool entries after real app construction: **666**
- Unique tool names: **604**
- Tk version: **8.6.15**

## Successfully loaded modules

- `accessibility_tools`
- `advanced_monitoring`
- `advanced_recovery`
- `ai_provider`
- `archive_tools`
- `audio_tools`
- `backup_tools`
- `batch_rename`
- `benchmark_tools`
- `bios_tools`
- `boot_tools`
- `clone_tools`
- `cloud_tools`
- `cpu_monitor`
- `cpu_test`
- `cpu_tools`
- `data_recovery`
- `disk_monitor`
- `disk_structure_tools`
- `disk_test`
- `disk_tools`
- `display_tools`
- `dll_tools`
- `duplicate_finder`
- `encryption_tools`
- `ethernet_tools`
- `extra_utilities`
- `file_search`
- `file_system_tools`
- `gaming_tools`
- `gpu_monitor`
- `gpu_test`
- `hw_sensors`
- `internet_tools`
- `live_monitor`
- `monitor_test`
- `motherboard_tools`
- `network_monitor`
- `network_tools`
- `nvidia_gpu`
- `os_tools`
- `partition_tools`
- `password_tools`
- `printer_tools`
- `privacy_tools`
- `quick_snapshot`
- `ram_monitor`
- `ram_test`
- `ram_tools`
- `recovery_advanced`
- `recovery_media_tools`
- `registry_advanced`
- `registry_tools`
- `reporting_tools`
- `restore_tools`
- `security_network`
- `security_tools`
- `shredder_tools`
- `storage_health`
- `stress_tools`
- `sync_tools`
- `system_migration`
- `system_repair`
- `system_summary`
- `td_prank_tester`
- `td_sysnote_diagnostics`
- `terminal_tools`
- `virtual_disk_tools`
- `volume_manager`
- `wifi_tools`
- `wipe_tools`

## Failed modules and exact reasons

- No module import failures were captured.

## Architecture guard

- This harness does not modify TechDrive source files.
- TechDrive is launched with the existing `python techdrive.py` entry point.
- No web framework, browser UI, replacement shell, or parallel implementation is used.

## Manual GUI checklist

### Dashboard and navigation (`dashboard`)

- [ ] Launch with `python techdrive.py`.
- [ ] Confirm Dashboard opens and telemetry populates without traceback.
- [ ] Open All Tools and verify the category/tool totals from the probe.
- [ ] Open at least one representative tool from System, Disk, Network, Security, Repair, Monitoring, File, and Hardware.

### Settings and shell rebuilds (`shell_rebuilds`)

- [ ] Change dark/light theme and confirm the shell rebuilds cleanly.
- [ ] Change accent color and font scale; confirm Dashboard, nav, top bar, status bar, and Settings remain usable.
- [ ] Toggle RGB accent master, edges, corners, speed, brightness, color mode, line style, and opacity.
- [ ] Toggle Aero Glass and XP Theme; confirm each can be disabled without stale overlays or broken controls.
- [ ] Toggle Duck Assistant and reopen it after a shell rebuild.

### State, search, and tabs (`state_and_search`)

- [ ] Open tools and confirm Recent Tools updates.
- [ ] Favorite and unfavorite tools; verify the state survives closing/reopening the view.
- [ ] Use All Tools search and the top-bar search; press Ctrl+K and confirm focus moves to search.
- [ ] Open multiple tools, close tabs, and confirm Dashboard and Settings protection behavior.

### Reports and settings backup (`reports_backup`)

- [ ] Generate TXT and PDF reports.
- [ ] Back up Settings to JSON, change a preference, restore the backup, and confirm the preference returns.
- [ ] Exercise Reset All Settings only after confirming the destructive prompt.

### Process guards and Windows-only safeguards (`process_and_safeguards`)

- [ ] Launch a second TechDrive instance and confirm the single-instance dialog/guard.
- [ ] Attempt a Windows-only tool on Windows and confirm it runs or reports its exact native error.
- [ ] Exercise representative destructive/repair actions and confirm the existing confirmation dialogs remain present and accurately worded.
- [ ] Confirm cancellation paths do not execute the underlying command.

### Developer, easter-egg, and prank systems (`hidden_and_unusual`)

- [ ] Verify the developer-mode trigger remains reachable.
- [ ] Verify Duck Assistant, onboarding tour, sidebar gadgets, and bundled easter-egg assets remain reachable.
- [ ] Open Prank / Threat Tester and verify its scan/history/report/cleanup flows without running untrusted samples.


## Raw probe output

```text
Scanned 71 available plugins from techdrive_modules/
__TD_PLUGIN_MODULES__=["accessibility_tools", "advanced_monitoring", "advanced_recovery", "ai_provider", "archive_tools", "audio_tools", "backup_tools", "batch_rename", "benchmark_tools", "bios_tools", "boot_tools", "clone_tools", "cloud_tools", "cpu_monitor", "cpu_test", "cpu_tools", "data_recovery", "disk_monitor", "disk_structure_tools", "disk_test", "disk_tools", "display_tools", "dll_tools", "duplicate_finder", "encryption_tools", "ethernet_tools", "extra_utilities", "file_search", "file_system_tools", "gaming_tools", "gpu_monitor", "gpu_test", "hw_sensors", "internet_tools", "live_monitor", "monitor_test", "motherboard_tools", "network_monitor", "network_tools", "nvidia_gpu", "os_tools", "partition_tools", "password_tools", "printer_tools", "privacy_tools", "quick_snapshot", "ram_monitor", "ram_test", "ram_tools", "recovery_advanced", "recovery_media_tools", "registry_advanced", "registry_tools", "reporting_tools", "restore_tools", "security_network", "security_tools", "shredder_tools", "storage_health", "stress_tools", "sync_tools", "system_migration", "system_repair", "system_summary", "td_prank_tester", "td_sysnote_diagnostics", "terminal_tools", "virtual_disk_tools", "volume_manager", "wifi_tools", "wipe_tools"]
__TD_RUNTIME_STATS__={"catalogue_categories": 69, "catalogue_tools": 666, "unique_categories": 69, "unique_tool_names": 604, "dispatch_methods": 985, "plugin_registry_count": 71, "installed_plugin_count": 71, "window_class": "TechDriveApp", "tk_version": "8.6.15"}
```

## Latest Panel Smoke Test

Repeated on **2026-09-29 17:57 +05:30** using [windows_tool_panel_smoke_results.md](windows_tool_panel_smoke_results.md) and its JSON result. All 551 panels were constructed with no tool-control clicks; initial background refreshes were deferred, and external processes, threads, browser launches, and dialogs were blocked.

| Group | Built | Layout/constructor failures | Guarded | Total |
|---|---:|---:|---:|---:|
| System Repair | 40 | 0 | 0 | 40 |
| File Management | 20 | 0 | 0 | 20 |
| Hardware Testing | 109 | 0 | 2 | 111 |
| OS and Utilities | 39 | 1 | 0 | 40 |
| Network and Cloud | 79 | 0 | 1 | 80 |
| Security and Privacy | 39 | 1 | 0 | 40 |
| Disk and Storage Management | 114 | 12 | 37 | 163 |
| System and Diagnostics | 41 | 1 | 15 | 57 |
| **Total** | **481** | **15** | **55** | **551** |

The 15 current layout failures are: Terminal Tools / Multiplexer; Password Tools / Strength Checker; Data Recovery / Recover Photos and Recover Documents; Shredder Tools / Disk Wipe 1-Pass, 3-Pass, 7-Pass, and DoD; Wipe Tools / Secure Wipe Drive, Wipe Partition, Wipe File, Wipe Folder, Wipe USB, and Wipe SD; and RAM Monitor / Usage Graph. Each fails with a Tk `TclError` about mixing `pack` and `grid` in a single parent frame.

The previous panel run recorded 24 layout failures; nine of those failures (the GPU Test and Display Tools panels) did not recur in this run. A repeat through `app.open_tool` also opened GPU Test / Stress Test without an error. The current 15 failures are the latest observed results; that run-to-run variance is retained here rather than silently treating the earlier count as reproducible.

## Retest of the 70 Non-Pass Tools

Retested the 70 entries marked `FAIL` or `GUARDED` in the latest full-run JSON. The rerun selected exactly 70 entries: **15 layout failures, 55 guarded, 0 clean builds**. Zero clean builds is expected because only prior non-pass entries were selected. Full per-tool outcomes and blocked API details are in [windows_tool_panel_retest_results.md](windows_tool_panel_retest_results.md) and [windows_tool_panel_retest_results.json](windows_tool_panel_retest_results.json).

| Group | Clean build | Layout failure | Guarded | Total retested |
|---|---:|---:|---:|---:|
| Hardware Testing | 0 | 0 | 2 | 2 |
| OS and Utilities | 0 | 1 | 0 | 1 |
| Network and Cloud | 0 | 0 | 1 | 1 |
| Security and Privacy | 0 | 1 | 0 | 1 |
| Disk and Storage Management | 0 | 12 | 37 | 49 |
| System and Diagnostics | 0 | 1 | 15 | 16 |
| **Total** | **0** | **15** | **55** | **70** |

The same 15 `pack`/`grid` geometry failures reproduced: Terminal Tools / Multiplexer; Password Tools / Strength Checker; Data Recovery / Recover Photos and Recover Documents; Shredder Tools / Disk Wipe 1-Pass, 3-Pass, 7-Pass, and DoD; Wipe Tools / Secure Wipe Drive, Wipe Partition, Wipe File, Wipe Folder, Wipe USB, and Wipe SD; RAM Monitor / Usage Graph.

The 55 guarded cases remain unverified because the runner intercepts their initial operations: 52 subprocess calls, 17 direct thread starts, 9 file-picker calls, and 1 confirmation dialog attempt (some tools attempted more than one API). These operations were not executed; state-changing tests remain unrun.

## Safe On-Host Retest

On **2026-10-02**, the previous 70 non-pass entries were retested without virtualization using read-only host probes, one-sample sensor checks, and temporary archive fixtures. **54 passed the bounded checks; 16 produced reproducible UI/rendering errors.** No destructive disk, system-repair, registry, or wipe action was run. The exact methods, results, errors, and limits are documented in [windows_onhost_safe_verification.md](windows_onhost_safe_verification.md).

## Latest Rerun After Fixes

The complete 551-panel suite was rerun after the source updates: **492 clean panel builds, 0 layout failures, and 59 guarded initializations**. Those 59 also passed bounded checks: 32 read-only inventory queries, 17 one-sample telemetry checks, and 10 archive fixture round-trips. The full safe-test details are documented in [windows_onhost_safe_verification.md](windows_onhost_safe_verification.md); the refreshed per-tool panel matrix is in [windows_tool_panel_smoke_results.md](windows_tool_panel_smoke_results.md).

The nine previously failing UI panels (six GPU Test panels, Display Tools / Resolution and Refresh Rate, and Terminal Tools / Monitor) now pass direct construction and the real dispatcher. No GPU stress, display-mode change, terminal command, destructive disk, repair, registry, or wipe action was executed.
