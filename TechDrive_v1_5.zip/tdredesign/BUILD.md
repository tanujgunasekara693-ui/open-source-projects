# Building TechDrive as a standalone .exe

Running `python techdrive.py` directly exposes exactly what it's built
with: the process shows up as `python.exe`, and anyone with access to
the machine (or the folder) can open the `.py` files and read the
source. Packaging it with PyInstaller fixes both:

- The shipped process is `TechDrive.exe`, not `python.exe`.
- Source `.py` files aren't shipped — they're compiled to `.pyc` and
  bundled inside the exe/folder, not readable as plain text.
- The exe carries your own name, version, and icon in its file
  properties instead of Python/PyInstaller defaults.
- No console window pops up on launch.

This does **not** make the app un-reverse-engineerable — someone
determined can still unpack a PyInstaller build with tools like
`pyinstxtractor` and decompile the `.pyc` files. It does stop the
casual case: someone glancing at Task Manager, right-clicking
"Properties," or opening the install folder and immediately seeing
"oh, this is a Python script."

## 1. Set up a clean build environment

Do this on Windows (PyInstaller builds are platform-specific — a
Windows exe has to be built on Windows, not cross-compiled from
Linux/Mac).

```powershell
python -m venv build_env
build_env\Scripts\activate
pip install -r requirements.txt
pip install pyinstaller
```

## 2. Build

A spec file (`techdrive.spec`) and version resource
(`version_info.txt`) are already included in this project. From the
project root:

```powershell
pyinstaller techdrive.spec
```

This produces `dist\TechDrive\TechDrive.exe` (a folder build — faster
startup, easier to debug if something's missing). Everything TechDrive
needs (icon, `i18n/` translations, bundled interpreter, dependencies)
gets copied into `dist\TechDrive\` alongside the exe.

**Note on plugins:** `techdrive_modules/` now only contains
`ai_provider.py` and `hw_sensors.py` locally — the other tools are
bundled with the application and managed locally through Enable / Disable Tools.
That's unaffected by this build process; nothing you download later
gets baked into the exe, it just lands in the running app's
`techdrive_modules/` folder same as it does when running from source.

### Single-file build (optional)

For one `.exe` with nothing else next to it, open `techdrive.spec` and
flip `ONEFILE = True` near the bottom, then rebuild. Trade-off: startup
is slower because it has to unpack itself into a temp folder every
launch, but it's easier to hand someone a single file.

## 3. Fill in real version info before shipping

`version_info.txt` currently has placeholder values
(`CompanyName`, `LegalCopyright`, etc.). Edit these to whatever you
actually want to show up in Explorer's Properties → Details tab —
leaving it as generic placeholder text is its own tell, just like a
raw `python.exe` is.

## 4. Verify the build doesn't leak the stack

After building, a few quick checks:

```powershell
# Should say TechDrive.exe, not python.exe
Get-Process TechDrive

# Right-click dist\TechDrive\TechDrive.exe > Properties > Details
# should show your CompanyName/FileDescription/ProductName, not
# generic Python/PyInstaller defaults
```

Also open `dist\TechDrive\` and confirm there's no stray `.py` file
sitting next to the exe (there shouldn't be, with the spec as
written — everything's bundled into the `_internal` folder as
compiled bytecode).

## 5. Antivirus false positives

PyInstaller-built exes (especially onefile ones) commonly get flagged
by some AV engines as suspicious, purely because that packing
technique is also used by malware to hide payloads — it's a known
false-positive pattern, not specific to this app. If you plan to
distribute this publicly, code-signing the exe with a real
certificate (not self-signed) is the standard fix; unsigned +
packed is the combination that triggers the most warnings.
