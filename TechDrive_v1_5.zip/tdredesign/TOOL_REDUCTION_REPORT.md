# TechDrive v1.1 — 100-tool reduction report

## Result

- **Curated tools retained:** 100
- **Catalogue entries removed:** 567
- **Tool implementation functions removed:** 567
- **Tool modules exposed in the UI:** 15
- **Catalogue/function pairing:** verified for every remaining tool

The supplied ZIP actually contains **667 catalogue entries** when all module catalogues are counted, although the requested starting figure was 666. This release uses the exact 100-tool target: 667 original entries minus 567 removed entries equals 100.

## Curated tool set

### System diagnostics (10)
- Full System Report
- CPU Name & Temp
- Sensor Availability
- Motherboard Info
- BIOS Version & Mode
- Secure Boot Status
- TPM Version
- RAM Details
- Drive Health
- System Uptime

### Windows repair (8)
- SFC Scan
- DISM Restore
- BSOD Analyzer
- Boot Repair
- System Restore
- File Checker
- Component Store
- Health Check

### CPU monitoring (6)
- Usage Graph
- Temperature
- Fan Speed
- Load
- Core Usage
- Processes

### RAM monitoring (6)
- Usage Graph
- Available
- Used
- Cache
- Page File
- Process Usage

### GPU monitoring (5)
- GPU Info
- Usage Graph
- Temperature
- Memory Usage
- Driver Version

### Disk tools (8)
- Disk Info
- Cleanup
- Volume Capacity
- Partition Manager
- Clone
- Free Space Check
- Space Analyzer
- Format Tool

### Storage health (7)
- SMART Status
- Attributes
- Self-Test
- Error Log
- Temperature
- Wear Level
- Health Report

### Disk testing (5)
- Read Test
- Sequential Test
- Benchmark
- Performance Test
- SMART Test

### File search (7)
- Advanced Search
- Search by Name
- Search by Type
- Search by Date
- Search by Size
- Search Content
- Search Hash

### Batch rename (5)
- Rename Files
- Rename Folders
- Rename Extensions
- Pattern Rename
- Preview

### Network tools (8)
- Network Info
- Adapters
- IP Config
- Ping
- Traceroute
- DNS Lookup
- Routing Table
- Monitor

### Wi-Fi tools (5)
- WiFi Info
- Networks
- Signal Strength
- Channel Analyzer
- Security Check

### Security tools (7)
- Windows Security
- Firewall
- Defender
- UAC
- BitLocker
- TPM
- Windows Update

### Backup tools (7)
- System Backup
- File Backup
- Folder Backup
- Registry Backup
- Driver Backup
- User Data Backup
- Settings Backup

### Restore tools (6)
- System Restore Point
- Info
- Creator
- Restore
- Image Backup
- Image Restore

## What changed

- The live catalogue is now limited to the selected 100 tools.
- Non-selected catalogue entries and their paired top-level `tool_*` implementations were removed from the bundled tool modules.
- Legacy module files remain only where needed for shared code/import compatibility; they are not discovered as tools or shown in the Core Module Manager.
- Plugin discovery now loads only the 15 curated tool modules instead of scanning and importing every legacy tool module.
- The existing application structure and UI are preserved; this change does not replace TechDrive with a new app.

## Validation performed

- `python -m compileall -q .` completed successfully.
- Static catalogue audit found exactly 100 remaining tools across 15 modules.
- Every remaining module's catalogue count matches its remaining top-level `tool_*` function count.
- All remaining catalogue entries are unique by `(module, category, tool name)`.

## Validation limits and safety

This archive was inspected and syntax-checked in a non-Windows environment. The Windows-only actions have **not** been run against a real Windows installation in this environment. Before release, test the EXE on a disposable/test Windows machine, especially repair, restore, clone, partition, format, backup, and security controls. Keep backups before running storage or system-changing actions.


## Reliability and overlap update

- Removed the duplicate `GPU Info` entry from extended diagnostics; the dedicated GPU Monitor remains the single GPU telemetry view. Added `Sensor Availability` in the diagnostics slot to explain which optional sensor providers are installed and that hardware/driver support varies.
- Replaced the lightweight `SMART Health` duplicate with `Volume Capacity`; the detailed `SMART Status` remains in Storage Health.
- Removed the second disk `Benchmark` implementation and replaced it with a read-only `Free Space Check`. The Disk Test category remains the one benchmark entry point (with a distinct Performance Test mode).
- Replaced `Windows Update Status` with `System Uptime`; the Security Tools `Windows Update` remains the single update workflow.
- Hardened file-level clone to refuse identical/nested source and destination paths and to make overwrite/file-level-copy limitations explicit before running.
- Hardened format workflow with strict drive/filesystem/label validation, admin checks, mounted-volume checks, and fail-closed boot/system-volume checks. DiskPart output and exit status are now checked and surfaced.
- Disk test tools now refuse to overwrite an already-existing `_techdrive_disktest.tmp` file and check available space before writing their test file.
- System image backup now checks admin rights, requires a reachable destination on a different drive from Windows, reports non-zero exit codes, and tells users to verify the resulting backup.
- System restore validates the chosen restore-point sequence against the current restore-point list before issuing the restore request. Image Restore remains intentionally informational: it lists image versions and does not initiate an overwrite operation from the running desktop.
- SFC/DISM and boot repair retain explicit elevation checks and confirmation dialogs; the partition manager remains read-only.

## Validation after reliability update

- Python `compileall` passed for the full source tree.
- AST-based catalogue audit: 100 entries across 15 curated modules, and each module's catalogue count matches its `tool_*` function count.
- Windows-only actions and sensor readings were not exercised on physical Windows hardware in this environment. Please test on a disposable/test Windows installation before public release, especially formatting, restore, backup, repair, and hardware-sensor paths.
