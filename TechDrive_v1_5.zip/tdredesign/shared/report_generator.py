#!/usr/bin/env python3
"""
Professional TechDrive report generation.

The generator is deliberately independent of Tk so it can be used by the
GUI, tests, and future scheduled-report surfaces. It only reports data read
from the local machine or persisted diagnostic history; it never invents
historical measurements.
"""

import csv
import datetime as _datetime
import html
import io
import json
import os
import platform

from shared import database as db


SENSOR_FIELDS = (
    "occurred_at", "timestamp", "source", "cpu_percent", "ram_percent",
    "storage_percent", "network_adapters_up", "network_bytes_sent",
    "network_bytes_recv", "temperature_c",
)


def _now():
    return _datetime.datetime.now()


def _stamp(value=None):
    value = value or _now()
    return value.strftime("%Y%m%d-%H%M%S")


def _pretty_date(timestamp):
    try:
        return _datetime.datetime.fromtimestamp(float(timestamp)).strftime(
            "%Y-%m-%d %H:%M"
        )
    except (TypeError, ValueError, OSError):
        return "Unknown"


def _score_status(score):
    if score is None:
        return "NOT SCANNED"
    score = int(score)
    if score >= 80:
        return "PASS"
    if score >= 55:
        return "WARNING"
    return "FAIL"


def _health_categories(health):
    rows = []
    for category in (health or {}).get("categories", []):
        checks = category.get("checks") or []
        if checks:
            for check in checks:
                rows.append({
                    "category": category.get("label", "System"),
                    "name": check.get("label", check.get("key", "Check")),
                    "score": check.get("score"),
                    "status": _score_status(check.get("score")),
                    "items": check.get("items", []),
                })
        else:
            rows.append({
                "category": category.get("label", "System"),
                "name": category.get("label", "Category"),
                "score": category.get("score"),
                "status": _score_status(category.get("score")),
                "items": category.get("items", []),
            })
    return rows


def _issues_and_recommendations(health, diagnostic):
    issues = []
    recommendations = []
    seen_issue = set()
    seen_action = set()
    for row in _health_categories(health):
        for item in row.get("items", []):
            severity = item.get("severity", "good")
            if severity in ("warn", "bad"):
                title = item.get("title", row["name"])
                text = f"{row['name']}: {title}"
                if text not in seen_issue:
                    issues.append({
                        "severity": "FAIL" if severity == "bad" else "WARNING",
                        "text": text,
                        "explanation": item.get("explanation", ""),
                    })
                    seen_issue.add(text)
                action = item.get("action", "").strip()
                if action and action not in seen_action:
                    recommendations.append(action)
                    seen_action.add(action)
    if diagnostic:
        for action in diagnostic.get("actions", []):
            action = str(action).strip()
            if action and action not in seen_action:
                recommendations.append(action)
                seen_action.add(action)
        likely = diagnostic.get("likely_area")
        if likely:
            issue = f"Diagnostic Engine focused on {likely}"
            if issue not in seen_issue:
                issues.append({
                    "severity": "INFO",
                    "text": issue,
                    "explanation": diagnostic.get("symptom", ""),
                })
                seen_issue.add(issue)
    if not health:
        issues.append({
            "severity": "INFO",
            "text": "No completed Health Center scan is attached.",
            "explanation": "This bundle contains current sensors and machine "
                           "identity, but no health score was invented.",
        })
        if "Run Health Center before using this report for a health score." \
                not in seen_action:
            recommendations.append(
                "Run Health Center before using this report for a health score."
            )
            seen_action.add(
                "Run Health Center before using this report for a health score."
            )
    if not recommendations and health:
        recommendations.append("No immediate action was identified by the completed checks.")
    return issues, recommendations


def current_sensor_sample():
    """Get one current sensor sample without importing the Tk health page."""
    sample = {
        "occurred_at": _now().timestamp(),
        "timestamp": _now().isoformat(timespec="seconds"),
        "cpu_percent": None,
        "ram_percent": None,
        "storage_percent": None,
        "network_adapters_up": None,
        "network_bytes_sent": None,
        "network_bytes_recv": None,
        "temperature_c": None,
    }
    try:
        import psutil
    except ImportError:
        return sample
    try:
        sample["cpu_percent"] = round(float(psutil.cpu_percent(interval=0.15)), 1)
    except Exception:
        pass
    try:
        sample["ram_percent"] = round(float(psutil.virtual_memory().percent), 1)
    except Exception:
        pass
    try:
        root = os.environ.get("SystemDrive", os.path.abspath(os.sep))
        sample["storage_percent"] = round(float(psutil.disk_usage(root).percent), 1)
    except Exception:
        pass
    try:
        sample["network_adapters_up"] = sum(
            1 for data in psutil.net_if_stats().values() if data.isup
        )
    except Exception:
        pass
    try:
        network = psutil.net_io_counters()
        sample["network_bytes_sent"] = int(network.bytes_sent)
        sample["network_bytes_recv"] = int(network.bytes_recv)
    except Exception:
        pass
    try:
        readings = [
            float(entry.current)
            for entries in psutil.sensors_temperatures().values()
            for entry in entries
            if entry.current is not None
        ]
        if readings:
            sample["temperature_c"] = round(max(readings), 1)
    except Exception:
        pass
    return sample


def build_report_data():
    """Assemble a complete, JSON-serializable professional report bundle."""
    current = current_sensor_sample()
    db.add_sensor_sample(current, source="report_generator")
    health_history = db.get_health_history(limit=50)
    diagnostic_history = db.get_diagnostic_history(limit=50)
    sensor_history = db.get_sensor_history(limit=1000)
    latest_health_entry = health_history[0] if health_history else None
    latest_diagnostic_entry = (
        diagnostic_history[0] if diagnostic_history else None
    )
    health = latest_health_entry.get("report") if latest_health_entry else None
    diagnostic = (
        latest_diagnostic_entry.get("report")
        if latest_diagnostic_entry else None
    )
    issues, recommendations = _issues_and_recommendations(health, diagnostic)
    generated = _now()
    return {
        "report_version": "1.0",
        "generated_at": generated.isoformat(timespec="seconds"),
        "computer": {
            "name": platform.node() or "Unknown computer",
            "system": platform.system() or "Unknown",
            "release": platform.release() or "",
            "version": platform.version() or "",
            "machine": platform.machine() or "",
            "processor": platform.processor() or "",
        },
        "health_score": health.get("score") if health else None,
        "health_status": health.get("status") if health else "Not scanned",
        "health_scan": health,
        "latest_diagnostic": diagnostic,
        "issues": issues,
        "recommendations": recommendations,
        "current_sensors": current,
        "health_history": [
            {
                "id": entry.get("id"),
                "occurred_at": entry.get("occurred_at"),
                "score": entry.get("score"),
                "status": (entry.get("report") or {}).get("status"),
                "summary": entry.get("summary"),
            }
            for entry in health_history
        ],
        "diagnostic_history": [
            {
                "id": entry.get("id"),
                "occurred_at": entry.get("occurred_at"),
                "score": entry.get("score"),
                "title": entry.get("title"),
                "summary": entry.get("summary"),
                "session_id": (entry.get("report") or {}).get("session_id"),
            }
            for entry in diagnostic_history
        ],
        "sensor_history": sensor_history,
    }


def _text_report(data):
    computer = data["computer"]
    score = data["health_score"]
    score_text = f"{score}/100" if score is not None else "Not available"
    lines = [
        "TECHDRIVE SYSTEM REPORT",
        "─" * 72,
        "",
        f"Computer: {computer['name']}",
        f"OS: {computer['system']} {computer['release']}".strip(),
        f"Generated: {data['generated_at']}",
        f"Health Score: {score_text}",
        "",
        "HARDWARE / SYSTEM CHECKS",
        "─" * 72,
    ]
    rows = _health_categories(data.get("health_scan"))
    if rows:
        for row in rows:
            lines.append(f"{row['name']:<24} {row['status']}")
    else:
        lines.append("No completed Health Center scan is attached.")
    lines.extend(["", "ISSUES FOUND", "─" * 72])
    if data["issues"]:
        for issue in data["issues"]:
            prefix = "[!]" if issue["severity"] == "WARNING" else "[X]" \
                if issue["severity"] == "FAIL" else "[i]"
            lines.append(f"{prefix} {issue['text']}")
            if issue.get("explanation"):
                lines.append(f"    {issue['explanation']}")
    else:
        lines.append("None reported by the completed checks.")
    lines.extend(["", "RECOMMENDATIONS", "─" * 72])
    for recommendation in data["recommendations"]:
        lines.append(f"• {recommendation}")
    diagnostic = data.get("latest_diagnostic")
    if diagnostic:
        lines.extend([
            "", "LATEST DIAGNOSTIC SESSION", "─" * 72,
            f"Session: {diagnostic.get('session_id', 'Unknown')}",
            f"Symptom: {diagnostic.get('symptom', 'Not recorded')}",
            f"Likely area: {diagnostic.get('likely_area', 'Not recorded')}",
            f"Confidence snapshot: {diagnostic.get('overall', 'Not recorded')}/100",
        ])
    sensors = data["current_sensors"]
    lines.extend([
        "", "CURRENT SENSOR SNAPSHOT", "─" * 72,
        f"CPU: {sensors.get('cpu_percent', 'unavailable')}%",
        f"RAM: {sensors.get('ram_percent', 'unavailable')}% used",
        f"Storage: {sensors.get('storage_percent', 'unavailable')}% used",
        f"Network adapters up: {sensors.get('network_adapters_up', 'unavailable')}",
        f"Temperature: {sensors.get('temperature_c', 'unavailable')}°C",
        "",
        "This report is read-only evidence collected by TechDrive.",
    ])
    return "\n".join(lines)


def _html_report(data):
    esc = lambda value: html.escape(str(value if value is not None else ""))
    computer = data["computer"]
    score = data["health_score"]
    score_text = f"{score}/100" if score is not None else "Not available"
    score_class = "good" if score is not None and score >= 80 else \
        "warn" if score is not None and score >= 55 else "bad"
    rows = _health_categories(data.get("health_scan"))
    checks_html = "".join(
        f"<tr><td>{esc(row['name'])}</td><td>{esc(row['category'])}</td>"
        f"<td class='{row['status'].lower().replace(' ', '-')}'>{esc(row['status'])}</td>"
        f"<td>{esc(row['score'])}</td></tr>"
        for row in rows
    ) or "<tr><td colspan='4'>No completed Health Center scan is attached.</td></tr>"
    issues_html = "".join(
        f"<li class='{issue['severity'].lower()}'><strong>{esc(issue['text'])}</strong>"
        f"<br><span>{esc(issue.get('explanation', ''))}</span></li>"
        for issue in data["issues"]
    )
    recommendations_html = "".join(
        f"<li>{esc(item)}</li>" for item in data["recommendations"]
    )
    sensors = data["current_sensors"]
    sensor_rows = "".join(
        f"<tr><td>{esc(label)}</td><td>{esc(sensors.get(key, 'unavailable'))}"
        f"{'%' if key.endswith('_percent') else '°C' if key == 'temperature_c' else ''}</td></tr>"
        for label, key in (
            ("CPU load", "cpu_percent"), ("RAM used", "ram_percent"),
            ("Storage used", "storage_percent"),
            ("Network adapters up", "network_adapters_up"),
            ("Temperature", "temperature_c"),
        )
    )
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>TechDrive System Report</title>
<style>
body{{font:14px Segoe UI,Arial,sans-serif;color:#1e293b;background:#f1f5f9;
margin:0;padding:32px}}main{{max-width:960px;margin:auto;background:#fff;
padding:38px;box-shadow:0 4px 20px #0f172a18}}h1{{margin:0;color:#0f172a;
letter-spacing:.04em}}h2{{border-bottom:2px solid #e2e8f0;padding-bottom:8px;
margin-top:30px;color:#1e3a8a}}.meta{{color:#64748b;margin:8px 0 20px}}
.score{{font-size:28px;font-weight:700;color:#16a34a}}.score.warn{{color:#d97706}}
.score.bad{{color:#dc2626}}table{{width:100%;border-collapse:collapse}}
th,td{{padding:10px;border-bottom:1px solid #e2e8f0;text-align:left}}
th{{background:#f8fafc}}.pass{{color:#16a34a;font-weight:700}}
.warning{{color:#d97706;font-weight:700}}.fail{{color:#dc2626;font-weight:700}}
li{{margin:8px 0}}li.warning{{color:#92400e}}li.fail{{color:#991b1b}}
li.info{{color:#475569}}.note{{color:#64748b;font-size:12px;margin-top:30px}}
@media print{{body{{background:#fff;padding:0}}main{{box-shadow:none;padding:10px}}}}
</style></head><body><main>
<h1>TECHDRIVE SYSTEM REPORT</h1>
<div class="meta"><strong>Computer:</strong> {esc(computer['name'])}<br>
<strong>OS:</strong> {esc(computer['system'])} {esc(computer['release'])}<br>
<strong>Generated:</strong> {esc(data['generated_at'])}</div>
<div class="score {score_class}">Health Score: {esc(score_text)}</div>
<h2>Hardware / System Checks</h2><table>
<tr><th>Check</th><th>Area</th><th>Status</th><th>Score</th></tr>{checks_html}</table>
<h2>Issues Found</h2><ul>{issues_html or '<li>None reported by the completed checks.</li>'}</ul>
<h2>Recommendations</h2><ul>{recommendations_html}</ul>
<h2>Current Sensor Snapshot</h2><table><tr><th>Sensor</th><th>Value</th></tr>
{sensor_rows}</table>
<p class="note">This report is read-only evidence collected by TechDrive.
No repair or system change was performed.</p>
</main></body></html>"""


def _json_report(data):
    return json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True)


def _csv_sensors(data):
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=SENSOR_FIELDS, extrasaction="ignore")
    writer.writeheader()
    for sample in data.get("sensor_history", []):
        writer.writerow({field: sample.get(field, "") for field in SENSOR_FIELDS})
    return output.getvalue()


def _write_pdf(path, text):
    """Write a dependency-free, multi-page Courier PDF."""
    lines = text.replace("\t", "    ").splitlines() or [""]
    chunks = [lines[i:i + 45] for i in range(0, len(lines), 45)]
    objects = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        None,
        "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>",
    ]
    page_indexes = []
    for chunk in chunks:
        page_index = len(objects) + 1
        stream_index = page_index + 1
        page_indexes.append(page_index)
        objects.append(
            f"<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 3 0 R >> >> "
            f"/MediaBox [0 0 612 792] /Contents {stream_index} 0 R >>"
        )
        content = "BT /F1 10 Tf 40 780 Td 14 TL\n"
        for line in chunk:
            safe = line.encode("latin-1", "replace").decode("latin-1")
            safe = safe.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
            content += f"({safe}) Tj T*\n"
        objects.append(("STREAM", content + "ET"))
    objects[1] = (
        f"<< /Type /Pages /Kids [{' '.join(f'{i} 0 R' for i in page_indexes)}] "
        f"/Count {len(page_indexes)} >>"
    )
    with open(path, "wb") as handle:
        handle.write(b"%PDF-1.4\n")
        offsets = [0]
        for index, obj in enumerate(objects, start=1):
            offsets.append(handle.tell())
            if isinstance(obj, tuple):
                stream = obj[1].encode("latin-1", "replace")
                handle.write(f"{index} 0 obj\n<< /Length {len(stream)} >>\nstream\n".encode())
                handle.write(stream)
                handle.write(b"\nendstream\nendobj\n")
            else:
                handle.write(f"{index} 0 obj\n{obj}\nendobj\n".encode())
        startxref = handle.tell()
        handle.write(f"xref\n0 {len(objects) + 1}\n".encode())
        handle.write(b"0000000000 65535 f \n")
        for offset in offsets[1:]:
            handle.write(f"{offset:010d} 00000 n \n".encode())
        handle.write(
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{startxref}\n%%EOF".encode()
        )


def write_report_bundle(output_dir, data=None):
    """Write HTML, PDF, TXT, JSON, and sensor CSV files to output_dir."""
    data = data or build_report_data()
    os.makedirs(output_dir, exist_ok=True)
    computer = data["computer"]["name"] or "computer"
    safe_computer = "".join(
        char if char.isalnum() or char in "-_" else "_"
        for char in computer
    ).strip("_") or "computer"
    base = f"techdrive-system-report-{safe_computer}-{_stamp()}"
    text = _text_report(data)
    paths = {
        "html": os.path.join(output_dir, base + ".html"),
        "pdf": os.path.join(output_dir, base + ".pdf"),
        "txt": os.path.join(output_dir, base + ".txt"),
        "json": os.path.join(output_dir, base + "-diagnostic-bundle.json"),
        "csv": os.path.join(output_dir, base + "-sensor-history.csv"),
    }
    with open(paths["html"], "w", encoding="utf-8") as handle:
        handle.write(_html_report(data))
    with open(paths["txt"], "w", encoding="utf-8") as handle:
        handle.write(text)
    with open(paths["json"], "w", encoding="utf-8") as handle:
        handle.write(_json_report(data))
    with open(paths["csv"], "w", encoding="utf-8", newline="") as handle:
        handle.write(_csv_sensors(data))
    _write_pdf(paths["pdf"], text)
    return paths


__all__ = [
    "build_report_data", "write_report_bundle", "current_sensor_sample",
    "_text_report", "_html_report", "_csv_sensors",
]