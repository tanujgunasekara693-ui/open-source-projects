#!/usr/bin/env python3
"""
shared/database.py — small SQLite store for local app state
==============================================================
Backs three things that used to live nowhere (or in memory only):
  - favorites: which (category, tool) pairs the user starred
  - recent: an MRU list of opened tools, for a future "Recently used" view
  - settings: arbitrary key/value app preferences (theme, language, etc)
  - diagnostic history: completed Health Center scans and Diagnostic Engine
    sessions, kept locally so the app can show a real system timeline

One file, ~/.techdrive/techdrive.db, created on first use. Every function
opens its own short-lived connection (sqlite3 connections aren't free to
share across threads, and every call here is quick), so nothing needs to
be kept open across the app's lifetime.
"""

import json
import os
import sqlite3
import time

DB_DIR = os.path.join(os.path.expanduser("~"), ".techdrive")
DB_PATH = os.path.join(DB_DIR, "techdrive.db")


class _TechDriveConnection(sqlite3.Connection):
    """SQLite connection whose context manager also closes the connection.

    ``sqlite3.Connection.__exit__`` commits/rolls back but deliberately does
    not close the connection. TechDrive opens a short-lived connection for
    each database operation, so leaving those connections open leaks file
    descriptors and can eventually trigger SQLite locking/resource warnings.
    """

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def _connect():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, factory=_TechDriveConnection)
    conn.execute("""CREATE TABLE IF NOT EXISTS favorites (
        category TEXT NOT NULL,
        tool TEXT NOT NULL,
        PRIMARY KEY (category, tool)
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS recent (
        category TEXT NOT NULL,
        tool TEXT NOT NULL,
        opened_at REAL NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS diagnostic_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL,
        occurred_at REAL NOT NULL,
        score INTEGER,
        title TEXT NOT NULL,
        summary TEXT NOT NULL,
        payload TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS sensor_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        occurred_at REAL NOT NULL,
        source TEXT NOT NULL,
        payload TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label TEXT NOT NULL,
        created_at REAL NOT NULL,
        restore_point_number INTEGER,
        restore_point_time TEXT,
        restore_point_description TEXT,
        restore_error TEXT,
        payload TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at REAL NOT NULL,
        level TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        source TEXT,
        read INTEGER NOT NULL DEFAULT 0
    )""")
    return conn


# ---------------------------------------------------------------------------
# Favorites
# ---------------------------------------------------------------------------
def is_favorite(category, tool):
    with _connect() as conn:
        row = conn.execute(
            "SELECT 1 FROM favorites WHERE category=? AND tool=?", (category, tool)
        ).fetchone()
        return row is not None


def toggle_favorite(category, tool):
    """Returns the new favorite state (True if now favorited)."""
    with _connect() as conn:
        if conn.execute(
            "SELECT 1 FROM favorites WHERE category=? AND tool=?", (category, tool)
        ).fetchone():
            conn.execute("DELETE FROM favorites WHERE category=? AND tool=?", (category, tool))
            conn.commit()
            return False
        conn.execute("INSERT INTO favorites (category, tool) VALUES (?, ?)", (category, tool))
        conn.commit()
        return True


def get_favorites():
    """Returns a list of (category, tool) tuples."""
    with _connect() as conn:
        return conn.execute("SELECT category, tool FROM favorites ORDER BY category, tool").fetchall()


# ---------------------------------------------------------------------------
# Recently used
# ---------------------------------------------------------------------------
def add_recent(category, tool, keep=25):
    with _connect() as conn:
        conn.execute(
            "INSERT INTO recent (category, tool, opened_at) VALUES (?, ?, ?)",
            (category, tool, time.time()),
        )
        # Trim to the most recent `keep` rows so this table doesn't grow forever.
        conn.execute("""DELETE FROM recent WHERE rowid NOT IN (
            SELECT rowid FROM recent ORDER BY opened_at DESC LIMIT ?
        )""", (keep,))
        conn.commit()


def get_recent(limit=10):
    with _connect() as conn:
        return conn.execute(
            "SELECT category, tool, opened_at FROM recent ORDER BY opened_at DESC LIMIT ?", (limit,)
        ).fetchall()


def clear_recent():
    with _connect() as conn:
        conn.execute("DELETE FROM recent")
        conn.commit()


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------
# A single persistent feed backing the Notification Center. This is the
# replacement for scattering one-off popups/messageboxes across the app:
# anything worth telling the user about gets logged here (and may *also*
# raise a transient toast), so it's still visible later even if a toast
# was missed. Kept intentionally small - callers just need level/title/
# message, everything else has a sane default.
def add_notification(title, message, level="info", source=None, keep=200):
    """level is one of 'info' / 'success' / 'warning' / 'error', matching
    the same vocabulary show_toast() already uses. Returns the new row id."""
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO notifications (created_at, level, title, message, source, read) "
            "VALUES (?, ?, ?, ?, ?, 0)",
            (time.time(), level, title, message, source),
        )
        # Trim to the most recent `keep` rows so this table doesn't grow forever.
        conn.execute("""DELETE FROM notifications WHERE rowid NOT IN (
            SELECT rowid FROM notifications ORDER BY created_at DESC LIMIT ?
        )""", (keep,))
        conn.commit()
        return cur.lastrowid


def get_notifications(limit=50):
    """Returns rows as dicts, most recent first."""
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, created_at, level, title, message, source, read "
            "FROM notifications ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        cols = ("id", "created_at", "level", "title", "message", "source", "read")
        return [dict(zip(cols, row)) for row in rows]


def unread_notification_count():
    with _connect() as conn:
        row = conn.execute("SELECT COUNT(*) FROM notifications WHERE read=0").fetchone()
        return row[0] if row else 0


def mark_all_notifications_read():
    with _connect() as conn:
        conn.execute("UPDATE notifications SET read=1 WHERE read=0")
        conn.commit()


def clear_notifications():
    with _connect() as conn:
        conn.execute("DELETE FROM notifications")
        conn.commit()


def mark_notification_read(notification_id):
    with _connect() as conn:
        conn.execute("UPDATE notifications SET read=1 WHERE id=?", (int(notification_id),))
        conn.commit()

def delete_notification(notification_id):
    with _connect() as conn:
        conn.execute("DELETE FROM notifications WHERE id=?", (int(notification_id),))
        conn.commit()


# ---------------------------------------------------------------------------
# Diagnostic history
# ---------------------------------------------------------------------------
def _add_history(kind, score, title, summary, payload, keep=200):
    """Persist one completed diagnostic result and retain recent history.

    The payload is local JSON rather than a rendered string, so future UI
    versions can recalculate trends from the category/test evidence without
    losing the original scan details.
    """
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO diagnostic_history "
            "(kind, occurred_at, score, title, summary, payload) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (kind, time.time(), score, title, summary,
             json.dumps(payload, ensure_ascii=False)),
        )
        conn.execute("""DELETE FROM diagnostic_history WHERE id NOT IN (
            SELECT id FROM diagnostic_history ORDER BY occurred_at DESC LIMIT ?
        )""", (keep,))
        conn.commit()
        return cursor.lastrowid


def add_health_scan(report):
    """Store a completed Health Center report."""
    categories = ", ".join(
        f"{category.get('label', 'Category')} "
        f"{category.get('score', 0)}"
        for category in report.get("categories", [])
    )
    summary = f"{report.get('status', 'Scan')} — {categories}"
    row_id = _add_history(
        "health",
        int(report.get("score", 0)),
        "Health scan",
        summary,
        report,
    )
    if report.get("sensors"):
        add_sensor_sample(report["sensors"], source="health_scan")
    return row_id


def add_diagnostic_session(report):
    """Store a completed symptom-driven Diagnostic Engine session."""
    summary = (
        f"{report.get('profile', 'Diagnostic session')}: "
        f"{report.get('likely_area', 'No likely area recorded')}"
    )
    return _add_history(
        "diagnostic",
        int(report.get("overall", 0)),
        report.get("profile", "Diagnostic session"),
        summary,
        report,
    )


def add_network_lab_run(report):
    """Persist one completed read-only Network Lab snapshot."""
    checks = report.get("checks", [])
    passed = sum(1 for check in checks if check.get("ok"))
    summary = (
        f"{report.get('status', 'Unknown')} — "
        f"{passed}/{len(checks)} checks passed"
    )
    return _add_history(
        "network_lab",
        int(report.get("score", 0)),
        "Network Lab",
        summary,
        report,
    )


def _history_rows(kind, limit):
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, occurred_at, score, title, summary, payload "
            "FROM diagnostic_history WHERE kind=? "
            "ORDER BY occurred_at DESC LIMIT ?",
            (kind, limit),
        ).fetchall()
    output = []
    for row_id, occurred_at, score, title, summary, payload in rows:
        try:
            decoded = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            decoded = {}
        output.append({
            "id": row_id,
            "occurred_at": occurred_at,
            "score": score,
            "title": title,
            "summary": summary,
            "report": decoded,
        })
    return output


def get_health_history(limit=50):
    return _history_rows("health", limit)


def get_diagnostic_history(limit=50):
    return _history_rows("diagnostic", limit)


def get_network_lab_history(limit=50):
    return _history_rows("network_lab", limit)


def add_disk_scan(report):
    """Persist one completed Disk Health workspace scan (Overview +
    per-drive + SMART summary) so the workspace's History tab has real
    data instead of starting empty every launch."""
    drives = report.get("drives", [])
    healthy = sum(1 for d in drives if d.get("status") == "good")
    summary = f"{report.get('status', 'Scan')} — {healthy}/{len(drives)} drives healthy"
    return _add_history(
        "disk_health",
        int(report.get("score", 0)),
        "Disk Health scan",
        summary,
        report,
    )


def get_disk_history(limit=50):
    return _history_rows("disk_health", limit)


def add_performance_run(report):
    """Persist one completed 'Run Full Performance Lab' pass."""
    summary = (
        f"{report.get('passed', 0)}/{report.get('total', 0)} measurements passed"
    )
    return _add_history(
        "performance",
        int(report.get("score", 0)),
        "Performance Lab run",
        summary,
        report,
    )


def get_performance_history(limit=50):
    return _history_rows("performance", limit)


def add_security_audit(report):
    """Persist one completed defensive Security Center audit."""
    measured = [
        item for item in report.get("findings", [])
        if item.get("score") is not None
    ]
    summary = (
        f"{report.get('status', 'Unknown')} — "
        f"{len(measured)}/{len(report.get('findings', []))} findings measured"
    )
    return _add_history(
        "security_center",
        int(report.get("score") or 0),
        "Security Center",
        summary,
        report,
    )


def get_security_audit_history(limit=50):
    return _history_rows("security_center", limit)


# ---------------------------------------------------------------------------
# Snapshot Manager
# ---------------------------------------------------------------------------
def add_snapshot(label, payload, restore_point_number=None,
                 restore_point_time=None, restore_point_description=None,
                 restore_error=None):
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO snapshots "
            "(label, created_at, restore_point_number, restore_point_time, "
            "restore_point_description, restore_error, payload) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                label,
                time.time(),
                restore_point_number,
                restore_point_time,
                restore_point_description,
                restore_error,
                json.dumps(payload, ensure_ascii=False),
            ),
        )
        conn.commit()
        return cursor.lastrowid


def get_snapshots(limit=100):
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, label, created_at, restore_point_number, "
            "restore_point_time, restore_point_description, restore_error, payload "
            "FROM snapshots ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    output = []
    for row in rows:
        try:
            payload = json.loads(row[7])
        except (json.JSONDecodeError, TypeError):
            payload = {}
        output.append({
            "id": row[0],
            "label": row[1],
            "created_at": row[2],
            "restore_point_number": row[3],
            "restore_point_time": row[4],
            "restore_point_description": row[5],
            "restore_error": row[6],
            "payload": payload,
        })
    return output


# ---------------------------------------------------------------------------
# Sensor history
# ---------------------------------------------------------------------------
def add_sensor_sample(sample, source="manual", keep=1000):
    """Persist one real local telemetry sample for report CSV exports."""
    if not isinstance(sample, dict):
        return None
    occurred_at = float(sample.get("occurred_at") or time.time())
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO sensor_history (occurred_at, source, payload) "
            "VALUES (?, ?, ?)",
            (occurred_at, str(source), json.dumps(sample)),
        )
        conn.execute("""DELETE FROM sensor_history WHERE id NOT IN (
            SELECT id FROM sensor_history ORDER BY occurred_at DESC LIMIT ?
        )""", (keep,))
        conn.commit()
        return cursor.lastrowid


def get_sensor_history(limit=500):
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, occurred_at, source, payload FROM sensor_history "
            "ORDER BY occurred_at DESC LIMIT ?", (limit,)
        ).fetchall()
    output = []
    for row_id, occurred_at, source, payload in rows:
        try:
            decoded = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            decoded = {}
        decoded.setdefault("occurred_at", occurred_at)
        decoded["id"] = row_id
        decoded["source"] = source
        output.append(decoded)
    return output


# ---------------------------------------------------------------------------
# Settings (arbitrary key/value, JSON-encoded so values can be non-strings)
# ---------------------------------------------------------------------------
def get_setting(key, default=None):
    with _connect() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row[0])
        except (json.JSONDecodeError, TypeError):
            return row[0]


def set_setting(key, value):
    with _connect() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )
        conn.commit()


def get_all_settings():
    with _connect() as conn:
        rows = conn.execute("SELECT key, value FROM settings").fetchall()
    out = {}
    for k, v in rows:
        try:
            out[k] = json.loads(v)
        except (json.JSONDecodeError, TypeError):
            out[k] = v
    return out


def reset_all():
    """Wipes settings AND favorites/recent - used by Settings > Reset."""
    with _connect() as conn:
        conn.execute("DELETE FROM settings")
        conn.execute("DELETE FROM favorites")
        conn.execute("DELETE FROM recent")
        conn.execute("DELETE FROM diagnostic_history")
        conn.execute("DELETE FROM sensor_history")
        conn.execute("DELETE FROM snapshots")
        conn.commit()


def export_backup(path):
    """Write a versioned TechDrive settings backup atomically.

    The backup contains preferences, favorites and diagnostic history.  A
    small schema/version marker makes future restores safer, while writing
    through a temporary file prevents a failed export from leaving a
    half-written JSON backup.
    """
    import os
    import tempfile
    data = {
        "schema": "techdrive-settings-backup",
        "version": 2,
        "created_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
        "settings": get_all_settings(),
        "favorites": get_favorites(),
        "diagnostic_history": {
            "health": get_health_history(200),
            "diagnostic": get_diagnostic_history(200),
            "network_lab": get_network_lab_history(200),
            "security_center": get_security_audit_history(200),
        },
        "sensor_history": get_sensor_history(1000),
        "snapshots": get_snapshots(100),
        "notifications": get_notifications(200),
    }
    target = os.path.abspath(os.fspath(path))
    folder = os.path.dirname(target) or "."
    fd, tmp = tempfile.mkstemp(prefix=".techdrive_backup_", suffix=".tmp", dir=folder, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def import_backup(path):
    """Validate and restore a TechDrive backup without crashing on bad JSON.

    Settings are merged (existing behavior), while malformed entries are
    ignored rather than being allowed to corrupt the database.
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError("Backup must contain a JSON object.")
    schema = data.get("schema")
    if schema not in (None, "techdrive-settings-backup"):
        raise ValueError("This file is not a TechDrive settings backup.")
    version = data.get("version", 1)
    if not isinstance(version, int) or version < 1 or version > 2:
        raise ValueError(f"Unsupported TechDrive backup version: {version}")

    settings = data.get("settings", {})
    if not isinstance(settings, dict):
        raise ValueError("Backup settings section is invalid.")
    for key, value in settings.items():
        if isinstance(key, str) and len(key) <= 200:
            set_setting(key, value)

    favorites = data.get("favorites", [])
    if not isinstance(favorites, list):
        raise ValueError("Backup favorites section is invalid.")
    with _connect() as conn:
        for item in favorites:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                category, tool = item
                if isinstance(category, str) and isinstance(tool, str):
                    conn.execute(
                        "INSERT OR IGNORE INTO favorites (category, tool) VALUES (?, ?)",
                        (category, tool),
                    )
        conn.commit()

    # Notification history is restored when present.  IDs/timestamps from
    # the backup are intentionally not reused; the local database owns IDs.
    notifications = data.get("notifications", [])
    if isinstance(notifications, list):
        for item in notifications:
            if isinstance(item, dict):
                title = item.get("title")
                message = item.get("message")
                if isinstance(title, str) and isinstance(message, str):
                    add_notification(title[:200], message[:2000], item.get("level", "info"), item.get("source"))

    history = data.get("diagnostic_history", {})
    if isinstance(history, dict):
        for entry in history.get("health", []):
            if isinstance(entry, dict):
                report = entry.get("report") or {}
                if report:
                    add_health_scan(report)
        for entry in history.get("diagnostic", []):
            if isinstance(entry, dict):
                report = entry.get("report") or {}
                if report:
                    add_diagnostic_session(report)
        for entry in history.get("network_lab", []):
            if isinstance(entry, dict):
                report = entry.get("report") or {}
                if report:
                    add_network_lab_run(report)
        for entry in history.get("security_center", []):
            if isinstance(entry, dict):
                report = entry.get("report") or {}
                if report:
                    add_security_audit(report)


def set_baseline(payload):
    with _connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS baselines (id INTEGER PRIMARY KEY CHECK(id=1), captured_at REAL NOT NULL, payload TEXT NOT NULL)")
        conn.execute("INSERT INTO baselines(id,captured_at,payload) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET captured_at=excluded.captured_at,payload=excluded.payload", (time.time(), json.dumps(payload, ensure_ascii=False)))
        conn.commit()

def get_baseline():
    with _connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS baselines (id INTEGER PRIMARY KEY CHECK(id=1), captured_at REAL NOT NULL, payload TEXT NOT NULL)")
        row=conn.execute("SELECT payload FROM baselines WHERE id=1").fetchone()
    if not row: return None
    try: return json.loads(row[0])
    except (TypeError,json.JSONDecodeError): return None
