# techdrive.spec — PyInstaller build spec for TechDrive
#
# ONEFILE ONLY. Produces exactly one file: dist/TechDrive.exe.
# Nothing else - no PluginHost.exe (all 93 tools now run in-process,
# bundled directly - see techdrive_modules/), no hosted_plugins/
# runtime dependency, no companion folder.
#
# Startup is a little slower than an onedir build (onefile has to
# unpack itself into a temp dir every launch), but "one file, nothing
# more" was the explicit ask - this is the tradeoff that buys it.
#
# Build with:  pyinstaller techdrive.spec
# Output:      dist/TechDrive.exe

from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

# collect_submodules("techdrive_modules") needs to actually `import
# techdrive_modules` to introspect it - but PyInstaller executes this
# .spec file in a context where the current directory isn't guaranteed
# to be on sys.path yet, so that import can silently fail (caught
# internally by collect_submodules, which just returns [] rather than
# raising) BEFORE Analysis() below ever gets a chance to add pathex to
# sys.path itself. Confirmed by directly instrumenting this file: all
# three collect_submodules() calls returned empty until this path was
# added explicitly - "collect_submodules found 131 modules when I
# tested it in a plain python3 shell" doesn't guarantee the SAME call
# succeeds when made from inside the spec's own execution environment.
import sys
import os
_spec_dir = os.getcwd()
if _spec_dir not in sys.path:
    sys.path.insert(0, _spec_dir)

hidden_imports = (
    collect_submodules("techdrive_modules")
    + collect_submodules("gui")
    + collect_submodules("shared")
    + [
        "wmi", "win32com.client", "win32api", "win32con",
        "pynvml", "GPUtil", "cpuinfo",
        "reportlab.pdfgen", "fpdf", "openpyxl",
        "barcode", "barcode.writer",
        "markdown", "winpty",
        "rarfile", "py7zr", "pycdlib",
    ]
)

a = Analysis(
    ["techdrive.py"],
    pathex=["."],
    binaries=[],
    datas=[
        ("techdrive_icon.ico", "."),
        ("i18n", "i18n"),
        ("TechDrive_User_Manual.md", "."),
        ("EULA_FULL.txt", "."),
        ("gui/assets", "gui/assets"),
        ("gui/assets/sounds", "gui/assets/sounds"),
        ("techdrive_modules/totaldrive_data", "techdrive_modules/totaldrive_data"),
    ],
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Test/build-only stdlib modules never needed at runtime.
        # (distutils/lib2to3 deliberately left out - PyInstaller's own
        # hooks alias distutils internally and conflict with excluding
        # it explicitly; not worth fighting for the few KB it'd save.)
        "test", "unittest", "pydoc_data",
        "tkinter.test", "idlelib",
        # Standalone developer/build utilities are never runtime dependencies.
        "test_ai_key", "techdrive_keygen", "unified_keygen", "generate_license_keypair", "windows_compatibility_verification",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name="TechDrive",
    debug=False,
    bootloader_ignore_signals=False,
    strip=True,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # no console window
    icon="techdrive_icon.ico",
    version="version_info.txt",  # exe file properties: name/version/company
)
