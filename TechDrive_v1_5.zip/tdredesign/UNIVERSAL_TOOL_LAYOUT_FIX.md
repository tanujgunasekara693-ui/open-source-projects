# Universal Tool Layout Fix

## Problem
Tool panels shared a navigation shell but rendered their contents directly into an unconstrained frame. Older tools use different sizing and packing assumptions, so long content and action rows could be clipped in the tab viewport.

## Change
The shared `_build_tool_navigation()` now returns a content frame inside a responsive canvas viewport with vertical scrolling. The content window follows the available width, allowing labels and controls to wrap rather than force horizontal overflow. The scrollbar is shown only when content exceeds the viewport. Mouse-wheel scrolling is handled locally for Windows/macOS and X11 wheel events.

## Scope
This fixes the common viewport constraint for all tools that are opened through `open_tool()`. Individual tools that print raw command output or construct intrinsically wide tables may still need their own formatting changes; the shared viewport cannot automatically turn console output into a native data table.

## Validation
Run Python syntax compilation and the existing test suite. GUI verification on a real Windows desktop and display scaling is still required before release.
