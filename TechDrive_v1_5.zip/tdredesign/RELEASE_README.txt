TECHDRIVE BETA v1.1 RELEASE BUILD

This folder contains the customer-facing TechDrive release/build contents.
The private license signing key and license issuer scripts are intentionally excluded.
