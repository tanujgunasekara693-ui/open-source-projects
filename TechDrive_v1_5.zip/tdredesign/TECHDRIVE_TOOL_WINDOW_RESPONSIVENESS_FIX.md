# TechDrive v1.1 — Tool Window Responsiveness Fix

## Changes
- New launches use a larger screen-adaptive window (up to 94% of screen width and 90% of screen height) so tool panels have more usable room.
- Stale remembered window geometries that are smaller than the adaptive minimum are ignored; valid saved geometries are retained.
- Minimum window size adapts to small displays instead of forcing 1040x640 on every monitor.
- The shared tool navigation strip collapses its breadcrumb and shortens navigation button labels below 820 px, keeping navigation controls usable in narrow windows.
- Existing 100-tool curated catalogue and reliability/safety changes are retained.

## Validation performed
- `python -m py_compile techdrive.py` passed.
- `python -m unittest tests.test_tool_catalogue_and_safety tests.test_closable_notebook_titles -v`: 7 tests passed.
- ZIP integrity check performed after packaging.

## Limitations
- GUI interaction was not tested on the user's actual Windows desktop in this environment.
- These changes improve the shared app window and navigation strip; they do not prove every legacy tool operation works on every Windows version or hardware configuration.
- Destructive disk, image-restore, and system-repair workflows should be tested only on a disposable test machine or with verified backups before release.
