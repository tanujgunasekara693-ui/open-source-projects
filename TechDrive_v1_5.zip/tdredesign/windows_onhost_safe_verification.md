# TechDrive On-Host Safe Verification

**Run date:** 2026-10-02  
**Host:** Windows 10 22H2, build 19045; Python 3.14.5; Tk 8.6.15  
**Scope:** Retest the 70 entries previously marked `FAIL` or `GUARDED`, without a VM and without invoking destructive tool actions.

## Summary

| Result | Count |
|---|---:|
| Passed safe operational checks | 54 |
| Reproducible UI/rendering failures | 16 |
| Unclassified | 0 |
| **Total retested** | **70** |

A pass means the specified bounded check ran without an exception and, for archive operations, the temporary fixture round-trip was verified. It does not certify every option or all possible device configurations.

## Safe operational checks passed

- **Archive tools (10):** Zip, Unzip, RAR, UnRAR, 7z, Un7z, Tar, Untar, Gzip, and Gunzip were run against synthetic files in a temporary directory. Archive integrity or extracted fixture bytes were checked. RAR preserved its source path inside the archive; extracted files and contents were present. The temporary fixture directory was removed after testing.
- **Read-only disk/volume panels (27):** Drive to Drive Clone, Create Disk Image, Restore Disk Image, and the 19 Partition Tools panels (Resize, Create, Delete, Format, Merge, Split, Move, Recovery, Table Backup, Table Restore, Convert to MBR, Disk Geometry, Modify MBR/GUID, SMART Info, Speed Test, Bad Sector Scan, Delete All Partitions, Disk Image Backup, Disk Image Restore), plus OS Migration Wizard, Backup Partition, Restore Partition, Partition Recovery Scanner, and File Recovery Scanner. Their initialization-time inventory queries completed using allowlisted read-only PowerShell/SMART/NVIDIA commands; action buttons and raw-device opens were not invoked.
- **Multi-Monitor:** initial read-only WMI monitor enumeration completed; no display-mode switch was requested.
- **Network Monitor / Usage Graph:** one live psutil counter sample completed without starting a sampler thread.
- **Live Monitor (9):** CPU Live Graph, RAM Live Graph, GPU Live Graph, Disk Activity Graph, Network Live Graph, Drive Temperatures, Drive Space Map, All Sensors Dashboard, and Sensor Log Export each completed one bounded read-only sample without a background thread.
- **NVIDIA GPU (6):** Hotspot Temperature, GPU Power & Clocks, VRAM Monitor, Fan & Cooling, Throttle Reasons, and GPU Process List each completed one bounded read-only sample without a background thread. The host GPU was exposed through `Win32_VideoController`; values unavailable from its driver remain hardware-specific.

The 43 non-archive/non-sampler panel checks issued 140 allowlisted read-only process queries. No non-allowlisted process was run.

## Reproducible failures

All 15 previously observed `pack`/`grid` geometry conflicts reproduced. System Overview also failed during a bounded one-sample render with a separate Tk error.

| Group | Category | Tool | Observed error |
|---|---|---|---|
| Hardware Testing | System Summary | System Overview | `TclError: unknown option "-fg"`; `_tile_set` queries `fg` from a `Frame` |
| OS and Utilities | Terminal Tools | Multiplexer | `TclError` mixing `pack` and `grid` in one parent |
| Security and Privacy | Password Tools | Strength Checker | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Data Recovery | Recover Photos | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Data Recovery | Recover Documents | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Shredder Tools | Disk Wipe 1-Pass | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Shredder Tools | Disk Wipe 3-Pass | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Shredder Tools | Disk Wipe 7-Pass | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Shredder Tools | Disk Wipe DoD | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Secure Wipe Drive | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Wipe Partition | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Wipe File | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Wipe Folder | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Wipe USB | `TclError` mixing `pack` and `grid` in one parent |
| Disk and Storage Management | Wipe Tools | Wipe SD | `TclError` mixing `pack` and `grid` in one parent |
| System and Diagnostics | RAM Monitor | Usage Graph | `TclError` mixing `pack` and `grid` in one parent |

## Host read-only probes

The actual CPU, GPU, memory, physical disk, mounted-volume, monitor, and network-counter helper paths all returned without exceptions. On this host they reported CPU/WMI data, one GPU through `Win32_VideoController`, two memory modules, three physical disks, three mounted volumes, one monitor, and readable counters for six network interfaces. Identifiers and serial numbers were intentionally omitted.

## Not executed

- Disk partition creation/deletion/format/resize, diskpart `clean`, MBR/GUID modification, raw-device writes, clone/restore jobs, and partition-table restore.
- File shredding, secure wipe, system repair, registry modifications, display-mode changes, scheduled-task creation, or other state-changing controls.
- Archive operations against user files; only disposable fixtures were used.

These are not marked PASS. They need a disposable disk/VM or carefully scoped test data before operational behavior can be validated.

## Follow-Up After Source Fixes

**Rerun date:** 2026-10-02. The full panel constructor/layout suite was rerun for all 551 tools.

| Result | Count |
|---|---:|
| Panel constructors/layout clean | 483 |
| Panel layout failures | 9 |
| Guarded during constructor-only run | 59 |
| Total | 551 |

The nine remaining constructor failures, all confirmed through the real `app.open_tool` dispatcher, are GPU Test / Stress Test, FurMark-style Load Test, VRAM Test, Stability Test, Thermal Test, and Clock Test; Display Tools / Resolution and Refresh Rate; and Terminal Tools / Monitor. Each reports a Tk `pack`/`grid` geometry conflict. The earlier 15 geometry failures and System Overview `-fg` rendering error no longer reproduced.

The 59 previously guarded entries were then retested with bounded safe operations: all **32** read-only inventory/monitor queries passed with 162 allowlisted process calls and zero blocked calls; all **17** live sampler panels passed a single real read-only sample without starting persistent threads; and all **10** archive tools passed temporary-fixture round trips. Their former GUARDED statuses are therefore superseded for those bounded checks. This still does not validate disk writes, repair actions, or other button-triggered state changes.

## Geometry Fix Validation

After the nine UI fixes, the full 551-panel regression produced **492 PASS, 0 FAIL, and 59 GUARDED**. The nine affected panels all passed direct constructor/layout checks and were also opened through the normal `app.open_tool` dispatcher without error panels. The 59 guarded entries are still not action-level passes; their bounded read-only, one-sample, and temporary-archive results are recorded above. No GPU stress load, display-mode change, terminal command, disk mutation, repair, or wipe action was run.
