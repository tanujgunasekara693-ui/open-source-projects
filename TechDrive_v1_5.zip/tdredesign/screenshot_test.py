import tkinter as tk
from PIL import ImageGrab
import techdrive
app = techdrive.TechDriveApp()
app.update_idletasks(); app.update()
# Capture the application window area.
x, y = app.winfo_rootx(), app.winfo_rooty()
w, h = app.winfo_width(), app.winfo_height()
img = ImageGrab.grab(bbox=(x, y, x+w, y+h))
img.save('/mnt/data/TechDrive_Real_Icon_Preview.png')
app.destroy()
