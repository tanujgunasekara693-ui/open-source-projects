# TechDrive Compatibility Audit

**Audit type:** read-only Phase 1 inventory
**Source:** `techdrive_full_project_updated_(2)_1788778903956.zip`
**Audit date:** 2026-09-07 (Asia/Colombo)

## Executive result

- **Native desktop architecture confirmed.** The application is Python 3 + Tkinter/ttk; there is no React/Vite/Next/Electron/Tauri web shell in the archive.
- **Source code was not modified.** This audit only inspected the attached archive and ran static checks.
- **Static syntax is clean:** `python -m compileall -q .` passed; AST parsing also passed for the inspected entry point and shell modules.
- **GUI launch was not possible in this sandbox:** the runtime has no `_tkinter` module. That is an environment limitation, so Windows launch behavior remains to be verified on a Windows development machine.
- **Primary follow-up:** run the app on Windows and verify dynamic plugin discovery/install, because the catalogue is assembled at import time rather than declared entirely in `techdrive.py`.

## 1. Architecture inventory

| Area | Finding |
|---|---|
| Entry point | `techdrive.py` → `main()` → `TechDriveApp(tk.Tk)` |
| GUI framework | Tkinter + ttk, with custom Canvas/Frame widgets |
| Shell modules | `gui/topbar.py`, `gui/navrail.py`, `gui/dashboard.py`, `gui/module_gallery.py`, `gui/closable_notebook.py`, `gui/widgets.py`, `gui/fluent.py` |
| State | SQLite at `~/.techdrive/techdrive.db`; license at `~/.techdrive_license.json`; single-instance lock under the database directory |
| Tool dispatch | `(category, tool_name)` → `TOOL_DISPATCH` or `tool_<slug>` method; plugin modules are installed onto `TechDriveApp` |
| Packaging | PyInstaller one-file build via `techdrive.spec`; Windows installer script at `installer/TechDrive.iss` |
| Localization | `i18n/locales/{en,si,ta,ru,ja}.json` plus `i18n/__init__.py` |

## 2. Source footprint

- Python files: **113**
- GUI Python modules: **24**
- Tool/support modules under `techdrive_modules`: **79**
- Tool modules declaring `CATALOGUE`: **69**
- Catalogue categories: **69 unique**
- Catalogue tool entries: **665**; unique display names: **603**
- `tool_*` implementations found: **665**

### Tool/support module list

`_ide_editor`, `_ide_languages`, `_ide_markdown_preview`, `_ide_split_editor`, `_ide_terminal_widget`, `_ide_themes`, `_prank_backend`, `_sysnote_diag`, `accessibility_tools`, `advanced_monitoring`, `advanced_recovery`, `ai_provider`, `archive_tools`, `audio_tools`, `backup_tools`, `batch_rename`, `benchmark_tools`, `bios_tools`, `boot_tools`, `clone_tools`, `cloud_tools`, `cpu_monitor`, `cpu_test`, `cpu_tools`, `data_recovery`, `disk_monitor`, `disk_structure_tools`, `disk_test`, `disk_tools`, `display_tools`, `dll_tools`, `duplicate_finder`, `encryption_tools`, `ethernet_tools`, `extra_utilities`, `file_search`, `file_system_tools`, `gaming_tools`, `gpu_monitor`, `gpu_test`, `hw_sensors`, `internet_tools`, `live_monitor`, `monitor_test`, `motherboard_tools`, `network_monitor`, `network_tools`, `nvidia_gpu`, `os_tools`, `partition_tools`, `password_tools`, `printer_tools`, `privacy_tools`, `quick_snapshot`, `ram_monitor`, `ram_test`, `ram_tools`, `recovery_advanced`, `recovery_media_tools`, `registry_advanced`, `registry_tools`, `reporting_tools`, `restore_tools`, `security_network`, `security_tools`, `shredder_tools`, `storage_health`, `stress_tools`, `sync_tools`, `system_migration`, `system_repair`, `system_summary`, `td_prank_tester`, `td_sysnote_diagnostics`, `terminal_tools`, `virtual_disk_tools`, `volume_manager`, `wifi_tools`, `wipe_tools`

## 3. Tool/category compatibility checklist

The following catalogue is statically extracted from each module's `CATALOGUE` declaration. It is the compatibility checklist for the shell and All Tools page:

- **Accessibility Tools** — 10 tools (`accessibility_tools.py`)
- **Advanced Monitoring Tools** — 2 tools (`advanced_monitoring.py`)
- **Advanced Recovery & Cloning** — 17 tools (`advanced_recovery.py`)
- **Archive Tools** — 10 tools (`archive_tools.py`)
- **Audio Tools** — 10 tools (`audio_tools.py`)
- **BIOS Tools** — 10 tools (`bios_tools.py`)
- **Backup Tools** — 10 tools (`backup_tools.py`)
- **Batch Rename** — 10 tools (`batch_rename.py`)
- **Benchmarking Tools** — 3 tools (`benchmark_tools.py`)
- **Boot Tools** — 10 tools (`boot_tools.py`)
- **CPU Monitor** — 10 tools (`cpu_monitor.py`)
- **CPU Test** — 10 tools (`cpu_test.py`)
- **CPU Tools** — 10 tools (`cpu_tools.py`)
- **Cloning & Imaging** — 5 tools (`clone_tools.py`)
- **Cloud Tools** — 10 tools (`cloud_tools.py`)
- **DLL Tools** — 10 tools (`dll_tools.py`)
- **Data Recovery** — 10 tools (`data_recovery.py`)
- **Disk Monitor** — 10 tools (`disk_monitor.py`)
- **Disk Structure Tools** — 18 tools (`disk_structure_tools.py`)
- **Disk Test** — 10 tools (`disk_test.py`)
- **Disk Tools** — 10 tools (`disk_tools.py`)
- **Display Tools** — 10 tools (`display_tools.py`)
- **Duplicate Finder** — 10 tools (`duplicate_finder.py`)
- **Encryption Tools** — 10 tools (`encryption_tools.py`)
- **Ethernet Tools** — 10 tools (`ethernet_tools.py`)
- **Extra Utilities** — 3 tools (`extra_utilities.py`)
- **File Search** — 10 tools (`file_search.py`)
- **File System Tools** — 10 tools (`file_system_tools.py`)
- **GPU Monitor** — 10 tools (`gpu_monitor.py`)
- **GPU Test** — 10 tools (`gpu_test.py`)
- **Gaming Tools** — 10 tools (`gaming_tools.py`)
- **Internet Tools** — 10 tools (`internet_tools.py`)
- **Live Monitor** — 8 tools (`live_monitor.py`)
- **Monitor Test** — 10 tools (`monitor_test.py`)
- **Motherboard Tools** — 10 tools (`motherboard_tools.py`)
- **NVIDIA GPU** — 8 tools (`nvidia_gpu.py`)
- **Network Monitor** — 10 tools (`network_monitor.py`)
- **Network Security** — 10 tools (`security_network.py`)
- **Network Tools** — 10 tools (`network_tools.py`)
- **OS Migration & Recovery** — 8 tools (`system_migration.py`)
- **OS Tools** — 10 tools (`os_tools.py`)
- **Partition Tools** — 20 tools (`partition_tools.py`)
- **Password Tools** — 10 tools (`password_tools.py`)
- **Prank / Threat Tester** — 5 tools (`td_prank_tester.py`)
- **Printer Tools** — 10 tools (`printer_tools.py`)
- **Privacy Tools** — 10 tools (`privacy_tools.py`)
- **Quick Snapshot Tools** — 5 tools (`quick_snapshot.py`)
- **RAM Monitor** — 10 tools (`ram_monitor.py`)
- **RAM Test** — 10 tools (`ram_test.py`)
- **RAM Tools** — 10 tools (`ram_tools.py`)
- **Recovery Advanced** — 10 tools (`recovery_advanced.py`)
- **Recovery Media & Wipe Tools** — 2 tools (`recovery_media_tools.py`)
- **Registry Advanced** — 10 tools (`registry_advanced.py`)
- **Registry Tools** — 10 tools (`registry_tools.py`)
- **Reporting & Sharing Tools** — 2 tools (`reporting_tools.py`)
- **Restore Tools** — 10 tools (`restore_tools.py`)
- **Security Tools** — 10 tools (`security_tools.py`)
- **Shredder Tools** — 10 tools (`shredder_tools.py`)
- **Storage Health** — 10 tools (`storage_health.py`)
- **Stress & Stability Tools** — 2 tools (`stress_tools.py`)
- **Sync Tools** — 10 tools (`sync_tools.py`)
- **SysNote: Extended Diagnostics** — 29 tools (`td_sysnote_diagnostics.py`)
- **System Repair** — 10 tools (`system_repair.py`)
- **System Summary** — 1 tools (`system_summary.py`)
- **Terminal Tools** — 10 tools (`terminal_tools.py`)
- **Virtual Disk Tools** — 10 tools (`virtual_disk_tools.py`)
- **Volume Manager** — 17 tools (`volume_manager.py`)
- **WiFi Tools** — 10 tools (`wifi_tools.py`)
- **Wipe Tools** — 10 tools (`wipe_tools.py`)

### Non-catalogue support modules that must remain reachable

- `_ide_editor.py`, `_ide_languages.py`, `_ide_markdown_preview.py`, `_ide_split_editor.py`, `_ide_terminal_widget.py`, `_ide_themes.py` — IDE toolkit support components.
- `_prank_backend.py` — monitored execution, detection, persistence/history helpers for the Prank / Threat Tester plugin.
- `_sysnote_diag.py` — SysNote diagnostic helper functions.
- `ai_provider.py` — AI provider configuration/requests helper.
- `hw_sensors.py` — hardware sensor command/query helper.

## 4. Screens, routes, and navigation

### Main shell

- Top bar: branding, search field (`Ctrl+K`), clock/date, theme/Aero controls, profile/tier, notifications/settings/window controls.
- Command bar: quick category jumps, Quick Scan, and report actions.
- Left navigation rail: Dashboard, All Tools, Enable / Disable Tools, grouped tool shortcuts, Reports, Settings.
- Main workspace: closable notebook; Dashboard and Settings are protected tabs; tools open in separate closable tabs.
- Status bar: status message, hardware ID prefix, tool count, license tier, CPU, and RAM.

### Explicit app routes

- `show_dashboard()` — permanent live Dashboard tab.
- `open_all_tools_tab()` — searchable/filterable `ModuleGalleryPage`.
- `open_tool_group_tab(group_key)` — All Tools pre-filtered to a `TOOL_GROUPS` bucket.
- `open_enable_disable_tools_tab()` — plugin management page.
- `open_settings_tab()` / `show_preferences()` — Settings tab.
- `open_tool(category, tool_name)` — dispatches a tool into a new tab, records recents, and shows an error panel instead of crashing if implementation is missing.
- Help routes: User Manual, About, License Info, Activate License Key, Buy License, EULA.
- Reports: TXT Report and PDF Report.
- Startup/recovery/support routes are exposed through the tool catalogue and existing tool methods rather than separate web routes.

### Tool group buckets

`System`, `Disk`, `Network`, `Security`, `Repair`, `Monitoring`, `File`, `Hardware` — with unmapped categories falling back to `System` per the source comments.

## 5. Settings and persistence inventory

The SQLite settings store currently has these statically discoverable keys:

`accent_color`, `aero_glass_enabled`, `aero_glass_intensity`, `ai_api_key`, `ai_provider`, `always_on_top`, `clear_recent_on_exit`, `confirm_on_exit`, `date_format`, `default_tab`, `desktop_notifications`, `duck_assistant_enabled`, `duck_personality_mode`, `font_scale`, `fuzzy_search_enabled`, `hw_accel_ui`, `installed_plugins`, `language`, `language_code`, `launch_minimized`, `launch_on_startup`, `low_power_mode`, `minimize_to_tray`, `monitor_refresh_ms`, `notification_volume`, `onboarding_tour_shown`, `remember_window_geometry`, `rgb_accent_brightness`, `rgb_accent_color_mode`, `rgb_accent_corners_enabled`, `rgb_accent_edges_enabled`, `rgb_accent_enabled`, `rgb_accent_line_opacity`, `rgb_accent_line_style`, `rgb_accent_speed`, `search_history_size`, `sidebar_gadgets_enabled`, `single_instance_only`, `sound_on_complete`, `temp_unit`, `theme_choice`, `use_24h_clock`, `window_geometry`, `xp_theme_enabled`

Additional persisted state:

- Favorites: `(category, tool)` pairs.
- Recent tools: capped MRU history, default retention 25 rows.
- Installed plugin IDs.
- License/trial state and machine identifier.
- Window geometry and shell appearance state.
- Settings backup/restore to JSON and full reset with confirmation.

### Settings UI sections

License; Theme; Accent Color; Font Scale; Language; Duck Assistant; AI Assistant; Welcome Tour; RGB Accent; Aero Glass; XP Theme; Sidebar Gadgets; Interface; Notifications; Search Performance; Date/Time/Units; Window; Accessibility; File Operations; Network/Updates; Privacy/Data; Dashboard Display; Advanced; Keyboard; Security; Appearance Extras; Tool Behavior; Diagnostics; System Integration; Startup; Backup; Reset.

## 6. Shortcuts and interaction surfaces

- Top-bar global search focus: `<Control-k>`.
- Tool/search interactions: Return/Enter submission, double-click file/list activation, mouse-wheel scrolling for gallery/settings/long panels, Escape to dismiss several dialogs/overlays.
- Notebook interactions: left-click tab close behavior, right-click tab context menu.
- Developer/easter-egg arming: repeated click sequence handled in `gui/_td_devmode.py` (`arm(..., clicks=7, window_ms=2000)`).
- Many tool-specific canvas, editor, terminal, monitor, and dialog bindings are local to their panel; these must be regression-tested after shell changes.

## 7. Diagnostics, repair, recovery, reporting, and safeguards

### Capability families represented

- Diagnostics/telemetry: live monitor, CPU/RAM/GPU/storage/network monitors, system summary, hardware sensors, benchmark/stress/monitor tests, SysNote extended diagnostics.
- Repair/maintenance: system repair, disk cleanup/health/defrag, registry tools, DLL tools, printer tools, driver tools, Windows utilities, batch rename, archive/file-system helpers.
- Recovery: advanced recovery, data recovery, recovery media, restore, backup, cloning/imaging, disk/partition/volume management, system migration.
- Security/privacy: security tools, encryption, password tools, privacy tools, network security, shredding/wiping, prank/threat testing.
- Reporting/export: TXT/PDF reporting in the app; several tools also export HTML/PDF/JSON/XLSX depending on capability.
- Developer/utility: terminal, code editor, split editor, markdown preview, language/theme support, cloud/sync utilities.

### Safeguard surfaces

- Central command wrappers: `run_cmd()` and `run_cmd_argv()` with timeout/error handling; Windows-only notices for unsupported platforms.
- Confirmation flows: `70` `_confirm_then()` call sites detected, plus messagebox confirmation dialogs.
- Error surfaces: `105` messagebox calls and tool-level `_error_panel()` fallback.
- File selection/export surfaces: `176` file-dialog call sites.
- Native process/command surfaces: `240` command-wrapper calls and `136` direct `subprocess.run()` calls detected.
- High-impact tools are not placeholders: the source includes real command execution for disk, partition, recovery, registry, networking, driver, service, and system operations.
- Destructive operations should remain behind their existing confirmation paths; do not move them into generic shell actions without preserving the confirmation copy and Windows-only guards.

## 8. Hidden functionality and easter eggs

- `gui/_td_devmode.py` is an explicit developer-mode/hidden-interaction module.
- `_prank_backend.py` and `td_prank_tester.py` are intentionally unusual functionality and must be preserved.
- `gui/duck_assistant.py` contains the assistant, personality data, multilang responses, and interaction state.
- `gui/onboarding_tour.py` / `gui/onboarding_tour_canvas.py` contain welcome-tour behavior.
- `gui/sidebar_gadgets.py`, `gui/rgb_accent.py`, `gui/xp_theme.py`, and `gui/aero_effect.py` are optional shell behaviors controlled by settings.
- `gui/assets/_eggpix/` contains three bundled image assets under the easter-egg asset path.
- The source contains explicit developer/test/prank references; no cleanup or removal should be performed without tracing its trigger path first.

## 9. Launch/build verification

| Check | Result |
|---|---|
| Archive extraction | Pass |
| Python syntax compilation | Pass (`compileall`) |
| AST parse of entry point and shell modules | Pass |
| Import/app construction | Blocked: sandbox Python has no `_tkinter` |
| Native Windows command behavior | Not testable in Linux sandbox |
| Tkinter visual regression | Not testable in Linux sandbox |
| PyInstaller Windows build | Not run; requires Windows/PyInstaller environment |
| Installer behavior | Not run; requires Windows/Inno Setup environment |

## 10. Risks to resolve before shell changes

1. **Runtime catalogue assembly:** `CATALOGUE` starts empty in `techdrive.py`; `scan_plugins()` imports bundled modules and `install_plugin()` merges their catalogue/tool methods. Verify that all 69 catalogue modules load on Windows with the installed dependency set and that the final tool count matches the expected 665 entries.
2. **Optional dependency coverage:** several modules depend on Windows-only or optional packages (`WMI`, `pywin32`, `pynvml`, `GPUtil`, `pywinpty`, audio/PDF/archive packages). A failed module import can remove its tools from discovery, so the Enable / Disable Tools and startup logs should make failures visible.
3. **Shell rebuild behavior:** theme/accent/font changes destroy and rebuild top-level chrome. Verify Dashboard, Settings, active tool tabs, RGB accents, Aero, XP theme, assistant visibility, and recent-tool state after each rebuild.
4. **Command safety:** `run_cmd()` intentionally uses `shell=True` for Windows shell built-ins, while `run_cmd_argv()` exists for safer argument-list execution. Preserve the distinction and audit any user-controlled path interpolation before changing command code.
5. **Windows-only launch path:** single-instance lock, DPI awareness, startup registry integration, Windows sensors, and native utilities need a real Windows smoke test.

## Recommended next test sequence

1. On Windows, install `requirements.txt` and launch `python techdrive.py` from the source tree.
2. Capture startup output from plugin scanning and record loaded/failed modules.
3. Confirm the All Tools count, category count, and one representative tool from each group.
4. Exercise Dashboard → All Tools → tool tab → Settings → theme/accent/font rebuild → return to the tool tab.
5. Verify report export, settings backup/restore/reset, single-instance behavior, and the hidden/dev/prank flows without removing or changing them.
6. Only after this baseline passes, make the next small shell change.

---

*This report is an inventory and risk checklist, not a claim that Windows runtime behavior has been fully verified.*
