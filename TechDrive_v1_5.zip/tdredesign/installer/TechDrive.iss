; TechDrive.iss — Inno Setup installer script
;
; Produces a single TechDriveSetup.exe: LZMA-compressed, EULA acceptance
; built in, Start Menu + optional desktop shortcut, clean uninstaller.
; No 7-Zip, no manual zip/unzip step for you or your users.
;
; BUILD PREREQUISITES (one-time, on your Windows machine):
;   1. pyinstaller techdrive.spec
;   2. pyinstaller pluginhost.spec
;   3. Copy dist\PluginHost\* into dist\TechDrive\PluginHost\
;      (same layout described in techdrive.spec's header comment)
;   4. Install Inno Setup: https://jrsoftware.org/isinfo.php
;
; BUILD:
;   Open this file in the Inno Setup Compiler (or run: iscc TechDrive.iss)
;   Output: Output\TechDriveSetup.exe
;
; WHY {localappdata} AND NOT {autopf} (Program Files)
; -----------------------------------------------------
; Enable / Disable Tools manages bundled tool groups locally
; into the app's own folder at runtime (see import_plugin_zip() in
; techdrive.py and _default_app_base_dir() in
; shared/plugin_host_client.py) - not a separate writable user-data
; folder. Program Files is read-only for standard (non-admin) users,
; so installing there would make every plugin download fail with a
; permissions error unless the app is always run elevated - not a
; reasonable ask for an end user. Installing per-user under
; {localappdata} instead means the app's own folder is always
; writable by whoever is running it, no admin rights needed for
; enable/disable bundled tool groups after installation.

#define MyAppName "TechDrive"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "TechDrive"
#define MyAppExeName "TechDrive.exe"
#define MyAppURL "https://curly-leaf-5ede.tanujgunasekara693.workers.dev"

[Setup]
; Unique per-app GUID - generate your own with Inno Setup's Tools >
; Generate GUID, or any GUID generator. Keeping this stable across
; versions is what makes future installers upgrade in place instead
; of creating a second copy.
AppId={{B7E1B9F0-4C2A-4C7E-9B6A-TECHDRIVE0001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}

; Per-user install - see the note above for why this isn't {autopf}.
DefaultDirName={localappdata}\{#MyAppName}
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

DisableProgramGroupPage=yes
LicenseFile=..\EULA_FULL.txt
SetupIconFile=..\techdrive_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
OutputDir=Output
OutputBaseFilename=TechDriveSetup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Files]
; Pulls in everything PyInstaller produced - TechDrive.exe, its
; _internal\ folder, and the PluginHost\ subfolder you copied in per
; the build prerequisites above. recursesubdirs+createallsubdirs keeps
; the whole tree intact.
Source: "..\dist\TechDrive\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Bundled tool groups live inside the installed TechDrive package
; and {app}\techdrive_modules at runtime (see the note above) - without
; this, uninstalling would leave those behind since Inno Setup only
; tracks files it itself installed, not ones the app wrote later.
Type: filesandordirs; Name: "{app}\hosted_plugins"
Type: filesandordirs; Name: "{app}\techdrive_modules"
Type: files; Name: "{app}\pluginhost.log"
