# TotalDrive → TechDrive plugin port

All three TotalDrive suites (Business, Tax, Gov — 22 modules, 220 tools total)
are now TechDrive plugins, unlocked, no license/HWID gating. They'll show up
in the Enable / Disable Tools the same as the built-in techdrive_modules/ plugins.

## Suite names (renamed, no TotalDrive/BizDrive/TaxDrive/TechGov branding)

- Business suite → **Ledger Suite** (`td_business_*.py`)
- Tax suite → **Levy Suite** (`td_tax_*.py`)
- Gov suite → **Civic Suite** (`td_gov_*.py`)

Each tool's category is prefixed with its suite, e.g. `"Ledger Suite:
Expenses"`, `"Levy Suite: Income & Expense Tracker"`, `"Civic Suite: Task &
Time Management"` — so in the Enable / Disable Tools's category filter dropdown you
can filter down to just one suite at a time, even though there's no
separate "suite" concept in the underlying plugin registry (each module is
still its own installable plugin card, just grouped by the category-name
prefix).

## What moved where (all under techdrive_modules/)

- `td_tax_*.py` (5 files, 50 tools) and `td_gov_*.py` (10 files, 130 tools) —
  these suites already used the exact `tool_*(self, frame)` / `CATEGORY_NAME`
  + `TOOLS` convention TechDrive plugins use, so they ported almost as-is.
  I just fixed their imports and added a `CATALOGUE` line (TechDrive's loader
  expects that name, not `CATEGORY_NAME`+`TOOLS` alone).
- `td_business_*.py` (5 files, 50 tools) — Business suite was built
  differently: full `ttk`-based Tab *classes* rather than `tool_*` functions.
  These are thin adapters — one `tool_*` per Tab class — that instantiate the
  original class into the panel frame unchanged. The real logic lives in
  `_impl_business_*.py`.
- `_shared_tax_*.py`, `_shared_gov_*.py`, `_shared_business_*.py` — each
  suite's database/charts/pdf/ui helpers, copied over and renamed so they
  can't collide with TechDrive's own `shared/` package or with each other.
  Filenames start with `_` so the plugin scanner skips them (they're support
  code, not plugins themselves) — I added that one-line skip to
  `scan_plugins()` in techdrive.py.

## Licensing

Stripped entirely. None of the tool/module code touched `fortknox_license.py`
or `unified_keygen.py` to begin with — those only lived in the three app
shells (`bizdrive.py`, `taxdrive.py`, `techgov.py`), none of which are part
of this port. I didn't copy them.

## Data

Each suite keeps its own local SQLite file, now stored under
`techdrive_modules/totaldrive_data/` (bizdrive.db, taxdrive.db, techgov.db)
instead of colliding with TechDrive's own database.

## New TechDriveApp method

Added `_entry_row()` (label + entry row helper) — Tax/Gov tools use it and
TechDrive didn't have one yet. Copied from the original apps, restyled to
match TechDrive's existing `_text_input`/`_text_output` look.

## Dependencies

Added to requirements.txt: matplotlib, reportlab, fpdf2 (PDF fallback),
pillow, python-barcode, openpyxl.

## RetEngineer — removed

RetEngineer (binary/RE analysis toolkit) was ported in an earlier version of
this build but was pulled back out. Its README claimed MIT license, but the
zip had no actual LICENSE file, no copyright notice, and no traceable
authorship — not enough to safely bundle into a commercial product. Nothing
of it remains in techdrive_modules/ and its requirements entries were
removed too. If you can track down its canonical source and confirm the
license there, it can be re-added.


## Trovix (developer-tool suite)

Also ported: **Trovix**, a 10-module developer-tool suite (TestBench,
LogLens, ProjectDoctor, BuildDiff, FileHash, DirStats, TextFinder,
Dashboard, DependencyChecker, ReleaseGuard). Category:
`"Trovix: Developer Tools"`, 10 tools (one panel per module, `td_trovix_toolkit.py`).

Unlike RetEngineer, Trovix's backend logic (`src/modules/*.py`) was already
plain tkinter-free classes with no GUI coupling, so this one is a proper
native port — each tool is built with TechDrive's own widgets
(`_panel_header`/`_entry_row`/`_button_row`/`_text_output`), not an embedded
copy of Trovix's own GUI. Trovix's original `src/gui/` was not carried over.
The backend classes live at `techdrive_modules/_trovix/` (underscore-prefixed,
skipped by the plugin scanner same as the other suites' shared code).

One thing worth knowing: each module's backend class is a single
module-level singleton shared across that tool's session (mirroring how
Trovix's own app kept one instance per module) — e.g. TestBench's "Compare
Last 2 Runs" and the Dashboard tool both depend on state from earlier runs
in the same TechDrive session, not just the current click.

**Licensing:** Trovix shipped with *no* LICENSE file, no README license
section, and no copyright/author headers anywhere — less info than
RetEngineer had, which was already thin. You confirmed you own the rights
to it, so it was ported as-is; that confirmation is worth keeping on record
somewhere durable (e.g. attach a LICENSE file with your own name/terms to
`techdrive_modules/_trovix/`) since nothing in the source itself documents it.



RetEngineer (binary/RE analysis toolkit) was ported in an earlier version of
this build but has been pulled out. Its README claimed MIT license, but the
zip had no actual LICENSE file, no copyright notice, and no traceable
authorship — not enough to safely bundle into a commercial product. Nothing
of it remains in techdrive_modules/ and its requirements entries were
removed too. If you can track down its canonical source and confirm the
license there, it can be re-added.



## Not verified
so this is a careful static port (import wiring + tool-count checks, all
220 pass), not a runtime-tested one. Worth a smoke test on a real desktop
before shipping — Enable / Disable Tools → install each new plugin → open a few
tools per suite.
