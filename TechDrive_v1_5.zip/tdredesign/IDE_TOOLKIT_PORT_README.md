# WebDevIDE → TechDrive: IDE Toolkit plugin

## Scope
Only 4 of the IDE's 74 files were ported: `editor.py`, `split_editor.py`,
`markdown_preview.py`, `terminal_widget.py` — the only ones with no
PySimpleGUI import. The other 61 files import PySimpleGUI, which requires
its own commercial license to bundle in a paid product; that's a separate
question from anything about the IDE's own authorship, and out of scope
for this port. Skipped entirely, nothing from them was copied.

## What was added
New category **"IDE Toolkit"**, 4 tools, one plugin module:

- `techdrive_modules/td_ide_toolkit.py` — the plugin itself (`CATALOGUE`,
  4 `tool_*` adapters), following the same thin-adapter pattern as the
  Business suite port (`td_business_*.py`): each adapter builds a
  container frame and instantiates the original widget/class into it.
- `techdrive_modules/_ide_editor.py` — `CodeEditor` (from `editor.py`),
  import fixed to `._ide_themes` / `._ide_languages`.
- `techdrive_modules/_ide_themes.py`, `_ide_languages.py` — copied as-is.
- `techdrive_modules/_ide_split_editor.py` — `SplitEditor`, copied as-is.
- `techdrive_modules/_ide_markdown_preview.py` — `MarkdownPreview`, copied
  as-is.
- `techdrive_modules/_ide_terminal_widget.py` — `TerminalWidget`, copied
  as-is (PTY on Unix, WinPTY on Windows).

All `_ide_*` files are underscore-prefixed support code, skipped by
`scan_plugins()` the same as the other suites' shared modules — they
don't show up as their own Enable / Disable Tools entries.

## The 4 tools
- **Code Editor** — `CodeEditor` with a language/theme picker and
  Open…/Save… buttons.
- **Split Editor** — pick two files, get them side-by-side with diff
  highlighting (`SplitEditor.compare_files`) and synced scrolling.
- **Markdown Preview** — a `CodeEditor` (plain text) next to a live
  preview pane, updated on keystroke; Export as HTML… button.
- **Terminal** — `TerminalWidget` embedded directly, real interactive
  shell (bash/zsh via PTY on Unix, cmd/PowerShell via WinPTY on Windows).

## Dependencies added to requirements.txt
- `markdown` — used by the Markdown Preview tool.
- `pywinpty` (Windows only) — used by the Terminal tool for a real
  interactive shell; on Unix it uses the stdlib `pty` module instead, no
  extra dependency there. Note the Terminal tool falls back to an error
  message if `pywinpty` isn't installed on Windows (same behavior as the
  original `terminal_widget.py`).

## Not verified
Static port + a headless (Xvfb) smoke test of all 4 tools rendering and
of `techdrive.py`'s real `scan_plugins()` / `install_plugin()` — not a
tested-on-a-real-desktop pass. Worth opening each tool once for real
before shipping, same caveat as the TotalDrive port.
