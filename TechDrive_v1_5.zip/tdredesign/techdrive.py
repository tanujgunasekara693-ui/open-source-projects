#!/usr/bin/env python3
"""
TechDrive Ultimate Repair Toolkit
==================================
A Notepad++-styled Windows PC repair/diagnostic suite built on tkinter.

Single-file app: techdrive.py
Python 3.8+

Install dependencies:
    pip install psutil wmi cryptography pyinstaller requests pillow

Generate the .ico file once, before packaging (uses the built-in
programmatic gear/wrench icon generator — no third-party image assets):
    python techdrive.py --make-icon

Package as a standalone .exe:
    pyinstaller --onefile --windowed --icon=techdrive_icon.ico --name TechDriveUltimate techdrive.py

NOTE ON PLATFORM: many tools shell out to native Windows utilities
(wmic, diskpart, sfc, dism, netsh, powershell, etc). On non-Windows
systems those calls fail gracefully and the tool reports "Windows-only
feature" instead of crashing, so the app can still be explored/tested
on macOS/Linux during development.
"""

import os
import sys
import re
import io
import csv
import json
import time
import shutil
import socket
import hashlib
import uuid
import platform
import subprocess
import logging
from pathlib import Path
import traceback
from license_signing import verify_license
from logging.handlers import RotatingFileHandler
import threading
import queue
from gui import ui_dispatch
from gui import sounds

logger = logging.getLogger("TechDrive")

def _configure_logging():
    """Configure a small rotating local log for diagnostics and GUI failures.

    Logging is intentionally file-only and warning/error oriented so normal
    users do not get a console window or noisy output.
    """
    if logger.handlers:
        return
    try:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
        log_dir = os.path.join(base, "TechDrive", "logs")
        os.makedirs(log_dir, exist_ok=True)
        handler = RotatingFileHandler(
            os.path.join(log_dir, "techdrive.log"), maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    except Exception:
        # Logging must never prevent TechDrive from starting.
        pass
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog, messagebox, simpledialog
from datetime import datetime, timedelta

try:
    import psutil
except ImportError:
    psutil = None


def _app_base_dir():
    """Directory to resolve bundled data files (icon, manual, i18n/) from -
    the folder next to techdrive.py when running from source, or the
    PyInstaller extraction dir (sys._MEIPASS) when running as a built
    exe, since techdrive.spec bundles those files under `datas`."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def _find_bundled_file(*relative_path_parts):
    """Resolves a bundled data file (the User Manual, the EULA, etc.)
    against every location it could plausibly end up in, rather than
    trusting a single computed path.

    WHY THIS EXISTS: sys._MEIPASS's relationship to "where PyInstaller
    actually put the datas/ files" has changed across PyInstaller
    versions - the exe's own folder for older onedir layouts, an
    _internal/ subfolder for PyInstaller >= 6.x's onedir layout, and a
    temp extraction dir for --onefile builds. Rather than hardcoding
    which of those applies, this tries all of them in order and returns
    the first one that actually exists, so a person building with a
    different PyInstaller version than was used to test this doesn't
    hit a false "file not found" for a file that IS bundled, just not
    where a single fixed guess expected it.

    Returns the first existing path, or None if it isn't found anywhere
    (the caller then shows every path that WAS tried, so the actual
    error is diagnosable instead of a bare "couldn't find it")."""
    exe_dir = os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) else None
    candidates = [
        os.path.join(_app_base_dir(), *relative_path_parts),
    ]
    if exe_dir:
        candidates.append(os.path.join(exe_dir, *relative_path_parts))
        candidates.append(os.path.join(exe_dir, "_internal", *relative_path_parts))
    candidates.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), *relative_path_parts))

    seen = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if os.path.isfile(path):
            return path
    return None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

try:
    import requests
except ImportError:
    requests = None

try:
    from PIL import Image, ImageDraw, ImageTk, ImageFont, ImageFilter
except ImportError:
    Image = ImageDraw = ImageTk = ImageFont = ImageFilter = None

try:
    import techdrive_protection as protection
except ImportError:
    protection = None

IS_WINDOWS = platform.system() == "Windows"


# ---------------------------------------------------------------------------
# Custom icon generator (PIL) — draws a simple gear/wrench glyph so the app
# ships with zero third-party or Microsoft icon assets.
# ---------------------------------------------------------------------------

def generate_icon(size=64):
    """Programmatically draw the TechDrive mark: a "TD" monogram (Poppins
    Bold) on a rounded-square Fluent-blue gradient badge, with a small
    accent underline for a "speed/drive" cue. Returns a PIL.Image (RGBA)
    or None if Pillow isn't installed.

    Rendered at 4x and downsampled with LANCZOS so it stays crisp at
    every requested size, including 16px taskbar/tray icons."""
    if Image is None:
        return None

    scale = 4
    s = size * scale
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))

    # Rounded-square badge, diagonal gradient from near-black to the app's
    # neon cyan accent (#00e5ff) - echoes the in-app dark-neon palette
    # instead of introducing a new, unrelated color.
    radius = int(s * 0.24)
    top_rgb = (7, 11, 20, 255)       # matches the app's near-black backdrop
    bottom_rgb = (0, 200, 230, 255)  # neon cyan accent
    grad = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(grad)
    for y in range(s):
        t = y / s
        col = tuple(int(top_rgb[i] + (bottom_rgb[i] - top_rgb[i]) * t) for i in range(4))
        gdraw.line([(0, y), (s, y)], fill=col)
    mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, s - 1, s - 1], radius=radius, fill=255)
    img.paste(grad, (0, 0), mask)

    # Subtle glassy sheen across the top - ties the icon to the app's own
    # Aero/Fluent header treatment without needing real translucency here.
    sheen = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(sheen).rounded_rectangle(
        [int(s * 0.06), int(s * 0.05), int(s * 0.94), int(s * 0.42)],
        radius=int(radius * 0.8), fill=(255, 255, 255, 22))
    img = Image.alpha_composite(img, sheen)

    cx, cy = s / 2, s / 2

    # "TD" monogram - falls back to the default PIL bitmap font (still
    # legible, just less polished) if Poppins isn't present on this
    # machine, so icon generation never hard-fails on font lookup.
    font = None
    for candidate in (
        "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ):
        try:
            font = ImageFont.truetype(candidate, int(s * 0.46))
            break
        except Exception:
            continue
    text = "TD"
    tmp_draw = ImageDraw.Draw(img)
    if font is not None:
        bbox = tmp_draw.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        tx, ty = cx - tw / 2 - bbox[0], cy - th / 2 - bbox[1] - s * 0.02
    else:
        tx, ty = cx - s * 0.2, cy - s * 0.15
    y0 = cy + s * 0.28

    # Neon glow behind the glyph: draw the mark in cyan on its own layer,
    # blur it, composite it under the crisp white glyph on top - a soft
    # halo rather than a flat silhouette.
    glow = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    gdraw2 = ImageDraw.Draw(glow)
    if font is not None:
        gdraw2.text((tx, ty), text, font=font, fill=(0, 229, 255, 255))
    else:
        gdraw2.text((tx, ty), text, fill=(0, 229, 255, 255))
    gdraw2.line([(cx - s * 0.16, y0), (cx + s * 0.16, y0 - s * 0.045)],
                fill=(0, 229, 255, 255), width=int(s * 0.028))
    glow = glow.filter(ImageFilter.GaussianBlur(s * 0.018))
    img = Image.alpha_composite(img, glow)

    draw = ImageDraw.Draw(img)
    if font is not None:
        draw.text((tx, ty), text, font=font, fill=(255, 255, 255, 255))
    else:
        draw.text((tx, ty), text, fill=(255, 255, 255, 255))
    # Small angled accent underline - a "speed/drive" cue beneath the mark.
    draw.line([(cx - s * 0.16, y0), (cx + s * 0.16, y0 - s * 0.045)],
              fill=(255, 255, 255, 245), width=int(s * 0.026))

    return img.resize((size, size), Image.LANCZOS)


def save_icon(path="techdrive_icon.ico"):
    """Generate and save the .ico file used for PyInstaller packaging:
        pyinstaller --onefile --windowed --icon=techdrive_icon.ico --name TechDriveUltimate techdrive.py
    Run this once (e.g. `python techdrive.py --make-icon`) before building
    the .exe. Requires Pillow (pip install pillow)."""
    if Image is None:
        print("Pillow is not installed. Run: pip install pillow")
        return False
    img = generate_icon(256)
    sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    img.save(path, format="ICO", sizes=sizes)
    print(f"Icon saved to {path}")
    return True

# ---------------------------------------------------------------------------
# License system (Ed25519-signed).
# ---------------------------------------------------------------------------

TIER_INFO = {
    "F": {"name": "Free", "price": "$0", "validity": "Lifetime (nag popup after 30-day trial)"},
    "P": {"name": "Personal Pro", "price": "$9.99 / 30 days", "validity": "30 days"},
    "B": {"name": "Business", "price": "$29.99 / 365 days / PC", "validity": "365 days"},
}

# All three tiers unlock every tool. Paid tiers are activated with an
# Ed25519-signed license key issued by the private vendor key. The shipped
# application contains only the public verification key (license_signing.py).
TRIAL_DAYS = 30
LICENSE_FILE = os.path.join(os.path.expanduser("~"), ".techdrive_license.json")

def get_machine_id():
    """Stable per-machine identifier derived from the MAC address."""
    try:
        mid = str(uuid.getnode())
    except Exception:
        mid = "UNKNOWNMACHINE"
    return hashlib.sha256(mid.encode()).hexdigest()[:12]

# ---------------------------------------------------------------------------
# 30-day free trial tracking (WinRAR-style nag popup, not a hard lock).
# Stored encrypted (HWID-derived key via fortknox_license/techdrive_protection
# when available) so it's not trivially editable in a text editor, though
# per fortknox_license's honest-limits note, nothing client-side is
# tamper-proof - see that module's docstring.
# ---------------------------------------------------------------------------
TRIAL_FILE = os.path.join(os.path.expanduser("~"), ".techdrive_trial.dat")



# ---------------------------------------------------------------------------
# Trial tracking helpers
# ---------------------------------------------------------------------------
def _load_trial_data():
    if not os.path.exists(TRIAL_FILE):
        return {}
    if protection is not None:
        try:
            data = protection.load_encrypted_license(TRIAL_FILE)
            if data is not None:
                return data
        except Exception:
            # Optional crypto support must never make Settings or first-run
            # startup unusable. Fall through to the legacy JSON format.
            pass
    try:
        with open(TRIAL_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_trial_data(data):
    if protection is not None:
        try:
            protection.save_encrypted_license(data, TRIAL_FILE)
            return
        except Exception:
            pass
    try:
        with open(TRIAL_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def get_first_run_date():
    """Records (once) and returns the date TechDrive was first launched on
    this machine - the anchor for the 30-day free trial."""
    data = _load_trial_data()
    if "first_run" in data:
        try:
            return datetime.strptime(data["first_run"], "%Y-%m-%d").date()
        except Exception:
            pass
    today = datetime.now().date()
    data["first_run"] = today.isoformat()
    _save_trial_data(data)
    return today


def days_since_first_run():
    return (datetime.now().date() - get_first_run_date()).days


def get_trial_status():
    """Returns whether the WinRAR-style nag popup should show. Only
    meaningful for the Free tier - Personal Pro / Business never see it."""
    elapsed = days_since_first_run()
    days_left = max(0, TRIAL_DAYS - elapsed)
    return {"show_popup": elapsed >= TRIAL_DAYS, "days_left": days_left, "elapsed": elapsed}


class LicenseManager:
    """Three tiers only: Free ($0, lifetime, nag popup after a 30-day
    trial), Personal Pro ($9.99/30 days), Business ($29.99/365 days/PC).
    All three unlock every tool - there is no per-tool locking anymore.
    Paid tiers are activated with a single license key (see
    _verify_simple_key for the spec) issued by techdrive_keygen.py.

    On startup, also runs techdrive_protection.evaluate_environment() (if
    that module is available) and forces the Free tier if the running
    binary looks tampered with or a debugger is attached - see that
    module's docstring for the honest limits of client-side protection.
    """

    def __init__(self):
        self.tier = "F"
        self.expires = None
        self.licensed_to = "Free User"
        self.environment_report = None
        self._environment_safe = True
        self._check_environment()
        self._load()

    def _check_environment(self):
        if protection is None:
            return
        try:
            safe, report = protection.evaluate_environment()
            self._environment_safe = safe
            self.environment_report = report
        except Exception:
            # Never let a protection-layer bug prevent the app from
            # starting - fail open on our own errors, not on the user.
            self._environment_safe = True

    def _load(self):
        if not self._environment_safe:
            self.tier = "F"
            self.licensed_to = "License disabled (integrity/debugger check failed)"
            return

        if not os.path.exists(LICENSE_FILE):
            self.tier = "F"
            self.licensed_to = "Free User"
            return
        try:
            with open(LICENSE_FILE, "r") as f:
                data = json.load(f)

            ok, tier, expires, err = self._verify_simple_key(data.get("key", ""))
            if not ok:
                self.tier = "F"
                self.licensed_to = err or "Invalid License Key"
                return
            self.tier = tier
            self.expires = expires.isoformat() if expires else None
            self.licensed_to = data.get("licensed_to", "Licensed User")
            if expires and expires.date() < datetime.now().date():
                self.tier = "F"
                self.licensed_to = "Expired License"
        except Exception:
            self.tier = "F"

    def _verify_simple_key(self, key):
        """Verify a TD2 Ed25519-signed TechDrive license.

        The executable never contains the private signing key. Legacy HMAC
        keys are intentionally rejected because the old shared secret was
        client-side and therefore forgeable once the executable was inspected.
        """
        try:
            obj, expires = verify_license(key)
        except Exception as e:
            logger.warning("License verification failed: %s", e)
            return False, None, None, str(e) or "Invalid license key."

        machine_tag = str(obj.get("machine", "FFFF")).upper()
        if machine_tag != "FFFF":
            this_machine = get_machine_id().upper()[:4]
            if machine_tag != this_machine:
                return False, None, None, "This key is licensed to a different machine."

        # License expiry is date-based; the customer gets the entire
        # advertised expiry date rather than losing it at midnight.
        if expires.date() < datetime.now().date():
            return False, None, expires, "Expired license key."

        return True, obj["tier"], expires, None

    def activate_free(self):
        self.tier = "F"
        self.licensed_to = "Free User"
        try:
            os.remove(LICENSE_FILE)
        except FileNotFoundError:
            pass
        except Exception:
            pass

    def activate_key_string(self, key, licensed_to="Licensed User"):
        ok, tier, expires, err = self._verify_simple_key(key)
        if not ok:
            return False, err or "Invalid license key."
        with open(LICENSE_FILE, "w") as f:
            json.dump({
                "key": key.strip().upper(),
                "licensed_to": licensed_to,
            }, f)
        self._load()
        if self.tier == "F" and tier != "F":
            return False, "Key parsed but did not apply - it may already be expired."
        return True, f"License activated - {TIER_INFO[self.tier]['name']} tier."

    def tool_allowed(self, index):
        """Every tool is unlocked on every tier now - kept as a method
        (rather than removed outright) so call sites don't need to change."""
        return True


# WinRAR-style trial-expired popup (Free tier only, shown once per launch) -
# see gui/trial_popup.py; show_trial_popup is imported near the other gui.*
# imports below.

CATALOGUE = [
    # Built-in tools have been removed. Tools are now provided exclusively
    # via the Core Module Manager (see gui/enable_disable_tools.py).
]


def slugify(name):
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def _relative_time(epoch_seconds):
    """Short human-relative timestamp ('just now', '5m ago', '3h ago',
    '2d ago') for the Notification Center feed."""
    delta = max(0, time.time() - epoch_seconds)
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta // 60)}m ago"
    if delta < 86400:
        return f"{int(delta // 3600)}h ago"
    return f"{int(delta // 86400)}d ago"


# Unique accent color per category, used to tint category rows in the
# sidebar tree (see _populate_tree / _build_style's per-category tag).
CATEGORY_COLORS = {
    "Live Monitor": "#00cec9",
    "NVIDIA GPU": "#76b900",
    "Cloning & Imaging": "#9b59b6",
    "System Info": "#3498db",
    "Disk Management": "#2ecc71",
    "Data Recovery": "#e74c3c",
    "Hardware Testing": "#f39c12",
    "Security & Privacy": "#6c3483",
    "Network Tools": "#00bcd4",
    "System Repair": "#f1c40f",
    "File Management": "#2c3e50",
    "Monitoring & Logs": "#16a085",
    "Advanced Utilities": "#7f8c8d",
    "Audio Tools": "#ff6b6b",
    "Display Tools": "#ff9ff3",
    "Power & Cooling": "#5dade2",
    "Boot & Recovery": "#a0522d",
    "Developer Tools": "#4a4a4a",
    "Cloud Tools": "#2e86de",
    "Gaming Tools": "#badc58",
    "Internet Tools": "#a3cb38",
    "Accessibility Tools": "#f8c291",
    "Miscellaneous": "#c0392b",
    "Printer Tools": "#48c9b0",
    "Driver Tools": "#3b5998",
    "Advanced Plus": "#9b59b6",
    "Gaming Advanced": "#e67e22",
    "Security Suite": "#8e44ad",
    "Performance Tools": "#1abc9c",
    "Backup & Restore": "#27ae60",
    "Windows Tweaks": "#d35400",
    "Hardware Inventory": "#34495e",
    "Diagnostics & Reports": "#e84393",
    "OS Migration & Recovery": "#e74c3c",
    "System Summary": "#5dade2",
}

# ---------------------------------------------------------------------------
# Groups the 80+ CATALOGUE categories into the 8 top-level buckets shown in
# the Tools menu and the toolbar's quick-category buttons (System, Disk,
# Network, Security, Repair, Monitoring, File, Hardware). Categories not
# listed here fall back to "System" rather than being dropped.
# ---------------------------------------------------------------------------
TOOL_GROUPS = {
    "System": ["System Info", "OS Tools", "Windows Tweaks", "Boot Tools", "Boot & Recovery",
               "Terminal Tools", "Advanced Utilities", "Advanced Plus", "Accessibility Tools",
               "Miscellaneous", "Diagnostics & Reports", "Developer Tools"],
    "Disk": ["Disk Management", "Cloning & Imaging", "Disk Monitor", "Disk Test", "Disk Tools", "Partition Tools",
             "Storage Health", "Data Recovery", "Recovery Advanced", "Restore Tools",
             "Backup & Restore", "Backup Tools", "Duplicate Finder", "Shredder Tools",
             "Wipe Tools", "Archive Tools", "File System Tools", "OS Migration & Recovery"],
    "Network": ["Network Tools", "Network Monitor", "Network Security", "Internet Tools",
                "WiFi Tools", "Ethernet Tools", "Cloud Tools", "Sync Tools"],
    "Security": ["Security & Privacy", "Security Tools", "Security Suite", "Privacy Tools",
                 "Password Tools", "Encryption Tools"],
    "Repair": ["System Repair", "Registry Tools", "Registry Advanced", "DLL Tools", "Driver Tools"],
    "Monitoring": ["Live Monitor", "Monitoring & Logs", "CPU Monitor", "GPU Monitor", "RAM Monitor",
                   "Performance Tools", "Monitor Test", "NVIDIA GPU"],
    "File": ["File Management", "File Search", "Batch Rename"],
    "Hardware": ["Hardware Testing", "Hardware Inventory", "CPU Test", "CPU Tools", "GPU Test",
                 "RAM Test", "RAM Tools", "Motherboard Tools", "BIOS Tools", "Display Tools",
                 "Audio Tools", "Printer Tools", "Power & Cooling", "Gaming Tools", "Gaming Advanced",
                 "System Summary"],
}

TOOL_GROUP_ICONS = {
    "System": "⌕", "Disk": "▣", "Network": "◎", "Security": "⬢",
    "Repair": "⚒", "Monitoring": "▥", "File": "□", "Hardware": "▣",
}


# Display (icon, label) for each TOOL_GROUPS key - used by the "All
# Tools" gallery page's grouped rail/sections. Purely cosmetic; the
# grouping itself is TOOL_GROUPS above, so the gallery can never drift
# out of sync with the toolbar's existing group buttons.
GROUP_LABELS = {
    "Monitoring": ("▥", "System Diagnostics & Testing"),
    "Disk": ("▤", "Disk & Storage Management"),
    "Security": ("⬢", "Security & Privacy"),
    "Network": ("◎", "Network & Cloud"),
    "System": ("▣", "OS & Utilities"),
    "Hardware": ("◇", "Hardware Testing"),
    "File": ("▤", "File Management"),
    "Repair": ("▣", "System Repair"),
}


def _category_group(cat_name):
    for group, names in TOOL_GROUPS.items():
        if cat_name in names:
            return group
    return "System"


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def run_cmd(cmd, timeout=20):
    """Run a shell command and return (ok, output). `cmd` runs through
    cmd.exe/sh (shell=True) — that's needed for the shell built-ins a lot
    of call sites rely on (`start`, `|`, output redirection, etc). NEVER
    build `cmd` by interpolating raw user-typed input into the string —
    shell metacharacters (`&`, `|`, `;`, backticks, ...) in that input get
    interpreted by the shell, not treated as literal text. For any
    command that includes user-typed input (a hostname, IP, or similar),
    use run_cmd_argv() below instead, which passes arguments as a list
    with no shell involved, so injection isn't possible regardless of
    what the user types."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        out = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "Command timed out."
    except Exception as e:
        return False, str(e)


def run_cmd_argv(argv, timeout=20):
    """Run a command with no shell involved (argv list, shell=False).
    Use this instead of run_cmd() whenever any part of the command comes
    from user-typed input — a list of literal argv tokens can't be
    reinterpreted by a shell no matter what characters they contain, so
    there's no injection surface. Returns (ok, output) just like run_cmd()."""
    try:
        result = subprocess.run(
            argv, shell=False, capture_output=True, text=True, timeout=timeout
        )
        out = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "Command timed out."
    except FileNotFoundError:
        return False, f"{argv[0]}: command not found."
    except Exception as e:
        return False, str(e)


# Conservative hostname/IP charset: letters, digits, dots, hyphens (DNS
# labels + IPv4), and colons (IPv6). No shell metacharacters, no spaces.
# Anything outside this - "8.8.8.8 & calc.exe", "$(rm -rf /)", etc. - is
# rejected outright rather than passed to a command at all.
_HOST_RE = re.compile(r"^[A-Za-z0-9.\-:]{1,253}$")


def valid_host(s):
    """True if `s` is safe to use as a hostname/IP argument. Used to
    gate every network tool that takes free-typed host/subnet input
    before it's ever passed to ping/tracert/etc."""
    return bool(s) and bool(_HOST_RE.match(s.strip()))


def windows_only_notice():
    return ("This feature relies on native Windows utilities "
            "(wmic/diskpart/netsh/powershell) and is unavailable on this OS.\n"
            "Run TechDrive on Windows for full functionality.")


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB", "PB"]:
        if abs(n) < 1024:
            return f"{n:.2f} {unit}"
        n /= 1024
    return f"{n:.2f} EB"


# ---------------------------------------------------------------------------
# Main Application
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Theme palettes now live in gui/theme.py. BG/BG_LIGHT/FG/ACCENT/SURFACE
# stay as mutable module-level globals so toggling the theme (see
# TechDriveApp.toggle_theme) updates colors everywhere they're referenced
# by name, including inside the 300+ generated tool_* methods that build
# their own widgets on the fly.
# ---------------------------------------------------------------------------
from gui.theme import DARK_THEME, LIGHT_THEME, FONT_MONO, status_color, THEMES
from gui.tool_view import CardPanel
from gui.closable_notebook import ClosableNotebook
from gui.liquid_glass import TabNavBar
from gui.duck_assistant import DuckAssistant
from gui.duck_mascot import DuckAssistantWindow as DuckMascotWindow
from gui import onboarding_tour
from gui import aero_effect
from gui import xp_theme
from gui import sidebar_gadgets
from gui import achievements, classic_theme, screensaver
from gui.trial_popup import show_trial_popup
from gui import settings as settings_tab
from gui import enable_disable_tools
from shared import database as db

# Redesign layer (Fluent / Aero shell). These modules are presentation
# only - they route into the same open_tool()/settings/about entry points
# the app has always used, so no tool logic lives here.
from gui import fluent as fl
from gui.motion import ease_in_out, ease_out_quint, ease_apple, motion_enabled, tween, page_enter, spring
from gui.topbar import TopBar
from gui.navrail import NavRail
from gui.rgb_accent import RGBAccentBar, CornerGlow, CORNERS, SPEED_PRESETS, hex_to_hue
from gui.dashboard import DashboardPage
from gui.widgets import FluentButton, GlassCard
from gui.scroll_utils import make_scrollable
from gui.module_gallery import ModuleGalleryPage
from gui.ribbon import TechDriveRibbon
from gui.command_palette import toggle as toggle_command_palette
from gui.control_center import attach_control_center
from gui.system_tray import start_tray, stop_tray
from gui import notification_center as notif_center
from gui import focus_modes
from gui.share_sheet import show_share_sheet
from gui import tool_resume
from gui import haptics
from gui import onboarding_tour_v2
from gui.acrylic import apply_acrylic
from gui.stage_manager import open_stage_tab
from gui.mission_control import open_mission_control
from gui.privacy_dots import signal_probe
from gui.snap_layouts import show_snap_layouts
from gui import accessibility as a11y
from gui import genius_tips
from gui.context_tooltips import show_tooltip_for_tool
from gui.core_modules import CoreModulesPage
from gui.health_center import HealthCenterPage
from gui.diagnostic_engine import DiagnosticEnginePage
from gui.diagnostic_history import DiagnosticHistoryPage
from gui.core_picker import show_core_picker
from gui.report_generator import ReportGeneratorPage
from gui.repair_center import RepairCenterPage
from gui.performance_lab import PerformanceLabPage
from gui.troubleshooting_wizard import TroubleshootingWizardPage
from gui.hardware_inventory import HardwareInventoryPage
from gui.network_lab import NetworkLabPage
from gui.security_center import SecurityCenterPage
from gui.snapshot_manager import SnapshotManagerPage
from gui.technician_workspace import TechnicianWorkspacePage
from gui.explain_this_pc import ExplainThisPCPage
from gui.event_log_analyzer import EventLogAnalyzerPage
from gui.baseline_monitor import BaselineMonitorPage
from gui.easter_egg_vault import EasterEggVaultPage
from gui.boot_post import BootPostWindow
from gui.vault_arcade import (
    CORE_EXPLORER_ACHIEVEMENT_KEY,
    VAULT_DISCOVERY_PROGRESS_KEY,
    VAULT_DISCOVERY_STEPS,
    VaultArcadePage,
)
from gui.techdrive_terminal import TechDriveTerminalPage
from gui.fix_my_pc import FixMyPCPage
from shared import report_generator as report_builder


BG = DARK_THEME["BG"]
BG_LIGHT = DARK_THEME["BG_LIGHT"]
FG = DARK_THEME["FG"]
ACCENT = DARK_THEME["ACCENT"]
SURFACE = DARK_THEME["SURFACE"]
TEXT_FG = DARK_THEME["TEXT_FG"]
FONT_UI = ("Segoe UI", 9)


def _apply_theme_globals(theme_dict):
    """Rebind the module-level color globals in place. Any code elsewhere
    in the file that reads BG/BG_LIGHT/FG/ACCENT/SURFACE/TEXT_FG by name at
    call time (i.e. inside a function body, not a default argument baked in
    at import time) will automatically pick up the new values."""
    global BG, BG_LIGHT, FG, ACCENT, SURFACE, TEXT_FG
    BG = theme_dict["BG"]
    BG_LIGHT = theme_dict["BG_LIGHT"]
    FG = theme_dict["FG"]
    ACCENT = theme_dict["ACCENT"]
    SURFACE = theme_dict["SURFACE"]
    TEXT_FG = theme_dict["TEXT_FG"]


class _StartupExperience(tk.Frame):
    """Short, non-blocking TechDrive startup overlay.

    It sits inside the main window rather than creating a second native
    window, so it behaves well with DPI scaling, Aero, and multi-monitor
    setups. It gives users visible progress while the dashboard initializes.
    """
    def __init__(self, parent, theme):
        super().__init__(parent, bg=theme["BG"], bd=0, highlightthickness=0)
        self.theme = theme
        self._step = 0
        self._steps = (
            "Loading TechDrive",
            "Starting system monitors",
            "Preparing your workspace",
        )
        self.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.lift()
        self._icon = None
        icon_path = Path(__file__).resolve().parent / "assets" / "ui_icons" / "techdrive_brand_32.png"
        if icon_path.exists():
            try:
                self._icon = tk.PhotoImage(master=self, file=str(icon_path))
            except Exception:
                self._icon = None
        box = tk.Frame(self, bg=theme["CARD_BG"], bd=0, highlightthickness=1,
                       highlightbackground=fl.mix(theme["ACCENT"], theme["BG"], 0.35))
        box.place(relx=.5, rely=.5, anchor="center", width=390, height=190)
        if self._icon:
            tk.Label(box, image=self._icon, bg=theme["CARD_BG"], bd=0).pack(pady=(24, 7))
        tk.Label(box, text="TechDrive", bg=theme["CARD_BG"], fg=theme["FG"],
                 font=fl.font(18, "bold", True)).pack()
        self.status = tk.Label(box, text=self._steps[0], bg=theme["CARD_BG"],
                               fg=theme["MUTED"], font=fl.F_SMALL())
        self.status.pack(pady=(8, 10))
        self.bar = ttk.Progressbar(box, mode="determinate", maximum=100, length=250)
        self.bar.pack()
        self._animate()

    def _animate(self):
        if not self.winfo_exists():
            return
        self._step += 1
        progress = min(100, self._step * 34)
        self.bar["value"] = progress
        self.status.config(text=self._steps[min(self._step, len(self._steps)-1)])
        if progress >= 100:
            self.after(180, self.destroy)
        else:
            self.after(230, self._animate)


class TechDriveApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TechDrive 1.1 — All-in-One System Utility")

        # One app-wide mouse-wheel router: lets the dashboard and every
        # tool panel scroll on hover, no matter which child widget the
        # cursor happens to be over. See gui/scroll_utils.py.
        from gui.scroll_utils import install_global_mousewheel
        install_global_mousewheel(self)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        # Start large enough that legacy tool panels and their action rows are
        # not immediately clipped. Keep geometry adaptive for smaller screens.
        min_w = min(1120, max(820, sw - 32))
        min_h = min(700, max(520, sh - 64))
        # Prefer a roomy workspace for legacy tool panels; clamp to the usable
        # screen area so the app never opens beyond the user's display.
        default_w = max(min_w, min(1640, int(sw * 0.97)))
        default_h = max(min_h, min(1000, int(sh * 0.94)))
        default_geometry = f"{default_w}x{default_h}"
        saved_geometry = db.get_setting("window_geometry", None)
        used_saved_geometry = False
        if saved_geometry and db.get_setting("remember_window_geometry", True):
            try:
                import re
                match = re.match(r"^\s*(\d+)x(\d+)(?:[+-]\d+[+-]\d+)?\s*$", str(saved_geometry))
                if match and int(match.group(1)) >= min_w and int(match.group(2)) >= min_h:
                    self.geometry(saved_geometry)
                    used_saved_geometry = True
            except Exception:
                used_saved_geometry = False
        if not used_saved_geometry:
            self.geometry(default_geometry)
        self.configure(bg=BG)
        self.minsize(min_w, min_h)
        self.after_idle(self._clamp_window_to_screen)

        if db.get_setting("always_on_top", False):
            try:
                self.attributes("-topmost", True)
            except Exception:
                pass

        self.license = LicenseManager()
        saved_theme_choice = db.get_setting("theme_choice", "dark")
        # "system" was a legacy choice from the dark/light-only era with no
        # reliable cross-platform read of the OS theme; it now just maps to
        # the default theme. Any other unrecognized id (e.g. a theme that
        # existed in an older build) also falls back safely.
        if saved_theme_choice not in THEMES:
            saved_theme_choice = "dark"
        self.theme_id = saved_theme_choice
        self.dark_mode = THEMES[self.theme_id]["dark"]
        self.theme = THEMES[self.theme_id]["palette"]

        # Restore a saved accent color / font scale before anything reads
        # theme tokens, so the very first frame drawn already matches.
        saved_accent = db.get_setting("accent_color", None)
        if saved_accent:
            for theme_id, entry in THEMES.items():
                palette = entry["palette"]
                on_accent = "#03151c" if entry["dark"] else "#ffffff"
                # High Contrast keeps its own accent so it stays a
                # deliberately different, accessibility-first look rather
                # than inheriting whatever color the user picked elsewhere.
                if theme_id in ("high_contrast", "classic"):
                    continue
                palette["ACCENT"] = saved_accent
                palette["ACCENT_SOFT"] = fl.mix(palette["BG"], saved_accent, 0.35)
                palette["ACCENT_GLOW"] = fl.lighten(saved_accent, 0.25)
                palette["ON_ACCENT"] = on_accent
        fl.set_font_scale(db.get_setting("font_scale", 1.0))

        _apply_theme_globals(self.theme)

        # Re-install whatever plugins were installed last session, before
        # anything below snapshots CATALOGUE. All 93 tools now ship
        # bundled with the app (no more cloud download step - see
        # scan_plugins() below), so on top of restoring last session's
        # explicit installs, also auto-install every bundled tool that
        # isn't installed yet. Trusted because it's bundled at build
        # time, not fetched at runtime - the checksum/manifest
        # validation that applied to downloaded plugins doesn't apply
        # here, same as ai_provider.py/hw_sensors.py were never
        # validated either.
        disabled_set = set(db.get_setting("disabled_plugins", []))
        # All bundled optional modules are enabled by default. The persistent
        # disabled_plugins setting is the only source of truth for a module
        # that the user has explicitly turned off.
        for modname in PLUGIN_REGISTRY:
            if modname not in disabled_set:
                install_plugin(modname)
        enabled_set = sorted(m for m in PLUGIN_REGISTRY if m not in disabled_set)
        db.set_setting("installed_plugins", enabled_set)
        db.set_setting("disabled_plugins", sorted(disabled_set & set(PLUGIN_REGISTRY)))

        self.flat_tools = []  # (category, icon, tool_name, method_name)
        for cat, icon, tools in CATALOGUE:
            for t in tools:
                self.flat_tools.append((cat, icon, t))

        # Resolve Segoe UI Variable (or the closest installed family) once.
        fl.init_fonts(self)
        self.dashboard = None
        self._gpu_cache = None
        self._closing = False
        self._status_job = None
        self._trial_job = None
        self._ui_pump_job = None
        self._bg_poll_jobs = set()
        self._last_error_category = None  # exception type name; feeds the feedback dialog's
                                            # "Error category" field, cleared once reported
        self._aero_active = bool(
            db.get_setting("aero_glass_enabled", False) and aero_effect.is_supported()
        )

        self._apply_window_icon()
        self._build_style()
        self._start_ui_dispatcher()
        self._startup_post_active = False
        self._startup_post_window = None
        self._startup_tour_job = None
        self._vault_arcade_page = None
        # The native File/Tools/Reports/Help/Settings menu bar is retired.
        # The Fluent top bar, toolbar, nav rail, and in-app Settings surface
        # now provide the same reachable commands without the extra Windows
        # menu strip consuming dashboard height.
        self._build_layout()
        classic_theme.apply(self, enabled=self.theme_id == "classic")
        # Keep subtle UI clicks behind the global sound preference. The
        # handler only reacts to actual controls and hand-cursor affordances.
        self.bind_all("<ButtonPress-1>", self._play_ui_click, add="+")
        # Remove only the native Windows caption. The app's own TopBar keeps
        # its minimize / maximize / close controls and provides a drag area.
        # Apply after Tk has created the native window handle.
        self.after(120, self._remove_native_titlebar)
        # Do not place a full-window startup overlay over the application.
        # Some Windows/Tk rendering configurations can fail to repaint child
        # widgets beneath a covering Frame, leaving a blank dark window.
        # The main UI must be visible immediately; startup work is already
        # performed non-blockingly by the existing status updater.
        self._startup_experience = None
        # Developer-supplied startup cue; best-effort and non-blocking.
        sounds.play("startup")
        self._start_status_updater()


        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Real tray icon (pystray) - see gui/tray_icon.py. sync() only
        # actually creates anything if "show_in_system_tray" is on;
        # otherwise this is a harmless no-op object, same as before.
        from gui.tray_icon import TrayIcon
        self._tray = TrayIcon(self)
        self._tray.sync()
        self._minimize_to_tray_armed = True
        self.bind("<Unmap>", self._on_unmap)

        if db.get_setting("launch_minimized", False):
            try:
                self.iconify()
            except Exception:
                pass


        # ── Launch order ──────────────────────────────────────────────────
        # The dashboard is the first view.  The dashboard already contains
        # the live System Overview panel, so opening the standalone System
        # Overview tool here only creates a duplicate tab on launch.

        # Trial/licensing reminders must never block the first paint, so the
        # nag (when the Free tier's 30-day trial has elapsed) is scheduled
        # via after() rather than shown synchronously here. See
        # gui/trial_popup.py for the "WinRAR-style" toothless-nag mechanics.
        self._trial_job = self.after(300, self._maybe_show_trial_popup)

    def _maybe_show_trial_popup(self):
        """Shows the trial nag once per launch for every Free-tier user,
        regardless of how many days remain in the trial. Purely a reminder -
        never blocks or disables anything - see gui/trial_popup.py."""
        self._trial_job = None
        try:
            if self.license.tier != "F":
                return
            show_trial_popup(self)
        except Exception:
            # A bug in the reminder must never crash or block the app.
            pass

    def _remove_native_titlebar(self):
        """Hide the Windows title strip while retaining a normal resizable window.

        The custom TechDrive TopBar supplies the visible window controls. This
        is deliberately Windows-only; other platforms keep their native frame.
        """
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            # Explicit pointer-sized signatures are required on 64-bit Windows.
            user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
            user32.GetAncestor.restype = wintypes.HWND
            user32.GetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int)
            user32.GetWindowLongW.restype = ctypes.c_long
            user32.SetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_long)
            user32.SetWindowLongW.restype = ctypes.c_long
            user32.SetWindowPos.argtypes = (
                wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                ctypes.c_int, ctypes.c_int, wintypes.UINT,
            )
            user32.SetWindowPos.restype = wintypes.BOOL
            hwnd = user32.GetAncestor(wintypes.HWND(self.winfo_id()), 2)  # GA_ROOT
            if not hwnd:
                hwnd = wintypes.HWND(self.winfo_id())
            GWL_STYLE = -16
            WS_CAPTION = 0x00C00000
            SWP_NOSIZE = 0x0001
            SWP_NOMOVE = 0x0002
            SWP_NOZORDER = 0x0004
            SWP_FRAMECHANGED = 0x0020
            style = user32.GetWindowLongW(hwnd, GWL_STYLE)
            user32.SetWindowLongW(hwnd, GWL_STYLE, style & ~WS_CAPTION)
            user32.SetWindowPos(
                hwnd, 0, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
            )
        except Exception:
            # A frame-style failure must never prevent TechDrive from running.
            pass

    # ------------------------------------------------------------------
    # Maximize that respects the Windows taskbar
    # ------------------------------------------------------------------
    def _monitor_work_area(self):
        """Return (x, y, w, h) of the usable work area (screen minus the
        taskbar) of the monitor this window is on, or None if unknown."""
        if sys.platform != "win32":
            return None
        try:
            import ctypes
            from ctypes import wintypes

            class MONITORINFO(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD),
                            ("rcMonitor", wintypes.RECT),
                            ("rcWork", wintypes.RECT),
                            ("dwFlags", wintypes.DWORD)]

            user32 = ctypes.windll.user32
            user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
            user32.GetAncestor.restype = wintypes.HWND
            user32.MonitorFromWindow.argtypes = (wintypes.HWND, wintypes.DWORD)
            user32.MonitorFromWindow.restype = wintypes.HANDLE
            user32.GetMonitorInfoW.argtypes = (wintypes.HANDLE, ctypes.POINTER(MONITORINFO))
            user32.GetMonitorInfoW.restype = wintypes.BOOL
            hwnd = user32.GetAncestor(wintypes.HWND(self.winfo_id()), 2)  # GA_ROOT
            if not hwnd:
                hwnd = wintypes.HWND(self.winfo_id())
            mon = user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
            info = MONITORINFO()
            info.cbSize = ctypes.sizeof(MONITORINFO)
            if not user32.GetMonitorInfoW(mon, ctypes.byref(info)):
                return None
            r = info.rcWork
            return (r.left, r.top, r.right - r.left, r.bottom - r.top)
        except Exception:
            return None

    def is_window_maximized(self):
        return bool(getattr(self, "_td_maximized", False))

    def _win32_root(self):
        """(user32, hwnd) for this window's top-level handle, or (None, None)."""
        if sys.platform != "win32":
            return None, None
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
        user32.GetAncestor.restype = wintypes.HWND
        user32.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
        user32.GetWindowRect.restype = wintypes.BOOL
        user32.GetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int)
        user32.GetWindowLongW.restype = ctypes.c_long
        user32.SetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_long)
        user32.SetWindowLongW.restype = ctypes.c_long
        user32.SetWindowPos.argtypes = (
            wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, wintypes.UINT)
        user32.SetWindowPos.restype = wintypes.BOOL
        hwnd = user32.GetAncestor(wintypes.HWND(self.winfo_id()), 2)  # GA_ROOT
        if not hwnd:
            hwnd = wintypes.HWND(self.winfo_id())
        return user32, hwnd

    def _win32_place(self, x, y, w, h, thickframe):
        """Move/size the OUTER window rectangle in one call and toggle the
        sizing border. Using SetWindowPos (not Tk geometry) means the
        window fills the rectangle exactly, with no invisible frame overhang."""
        import ctypes
        user32, hwnd = self._win32_root()
        GWL_STYLE, WS_THICKFRAME = -16, 0x00040000
        SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED = 0x0004, 0x0010, 0x0020
        style = user32.GetWindowLongW(hwnd, GWL_STYLE)
        style = (style | WS_THICKFRAME) if thickframe else (style & ~WS_THICKFRAME)
        user32.SetWindowLongW(hwnd, GWL_STYLE, style)
        user32.SetWindowPos(hwnd, 0, int(x), int(y), int(w), int(h),
                            SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED)

    def toggle_maximize(self):
        """Maximize to the monitor work area (taskbar stays visible) / restore."""
        if self.is_window_maximized():
            self.restore_from_maximize()
        else:
            self.maximize_to_work_area()

    def maximize_to_work_area(self):
        try:
            if self.state() == "zoomed":      # e.g. native Win+Up
                self.state("normal")
                self.update_idletasks()
            area = self._monitor_work_area()
            if area is None:                  # non-Windows: native behaviour
                self.state("zoomed")
                return
            import ctypes
            from ctypes import wintypes
            user32, hwnd = self._win32_root()
            rect = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(rect))
            self._td_restore_rect = (rect.left, rect.top,
                                     rect.right - rect.left,
                                     rect.bottom - rect.top)
            x, y, w, h = area
            self._td_maximized = True
            # Border removed while maximized: the window IS the work area.
            self._win32_place(x, y, w, h, thickframe=False)
        except Exception:
            self._td_maximized = False

    def restore_from_maximize(self, pointer=None):
        """Leave the maximized state. `pointer` (x_root, y_root) keeps the
        window under the cursor when restoring by dragging the title area."""
        if not self.is_window_maximized():
            return
        try:
            x, y, w, h = getattr(self, "_td_restore_rect", None) or (
                100, 100, 1200, 760)
            if pointer is not None:
                cur = self._monitor_work_area() or (0, 0, w, h)
                frac = (pointer[0] - cur[0]) / max(1, cur[2])
                x = int(pointer[0] - w * frac)
                y = int(pointer[1] - 18)
            self._td_maximized = False
            self._win32_place(x, y, w, h, thickframe=True)
        except Exception:
            self._td_maximized = False

    def _clamp_window_to_screen(self):
        """Keep remembered geometry usable after monitor/DPI changes."""
        try:
            self.update_idletasks()
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            w, h = self.winfo_width(), self.winfo_height()
            w = max(1040, min(w, max(1040, sw - 24)))
            h = max(640, min(h, max(640, sh - 48)))
            x = min(max(0, self.winfo_x()), max(0, sw - w))
            y = min(max(0, self.winfo_y()), max(0, sh - h))
            self.geometry(f"{w}x{h}+{x}+{y}")
        except (tk.TclError, ValueError):
            pass

    def _apply_window_icon(self):
        """Uses the built-in PIL icon generator instead of any bundled
        Microsoft/Windows icon asset — avoids any icon copyright issues."""
        if Image is None:
            return
        try:
            icon_img = generate_icon(64)
            self._icon_photo = ImageTk.PhotoImage(icon_img)  # keep a ref
            self.iconphoto(True, self._icon_photo)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # UI scaffolding
    # ------------------------------------------------------------------
    def _build_style(self):
        """Fluent-flavoured ttk styling: flat surfaces, generous padding,
        accent-tinted selection, Segoe UI Variable typography. Every style
        name that existed before still exists, so the 300+ tool panels
        render unchanged - just prettier."""
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        th = self.theme
        body = fl.F_BODY()

        style.configure("Treeview", background=th["BG_LIGHT"],
                        fieldbackground=th["BG_LIGHT"], foreground=th["FG"],
                        borderwidth=0, font=body, rowheight=26)
        style.map("Treeview",
                  background=[("selected", th["SELECTION"])],
                  foreground=[("selected", th["FG"])])
        style.configure("TFrame", background=th["BG"])
        style.configure("TLabel", background=th["BG"], foreground=th["FG"],
                        font=body)
        style.configure("Header.TLabel", background=th["BG"],
                        foreground=th["FG"], font=fl.F_SUBTITLE())
        style.configure("Muted.TLabel", background=th["BG"],
                        foreground=th["MUTED"], font=fl.F_SMALL())
        classic = self.theme_id == "classic"
        style.configure("TButton", background=th["LAYER_2"],
                        foreground=th["FG"], font=body,
                        borderwidth=2 if classic else 0,
                        relief="raised" if classic else "flat",
                        focuscolor=th["BG"],
                        padding=(8, 4) if classic else (12, 6))
        style.map("TButton",
                  background=[("active", th["LAYER_3"]), ("pressed", th["ACCENT_SOFT"])],
                  foreground=[("disabled", th["MUTED"])])
        # Keep legacy/third-party tool pages visually consistent with the
        # Fluent shell.  These styles are intentionally conservative: they
        # change surfaces, typography and focus states without changing tool
        # behavior or requiring every one of the 70+ modules to be rewritten.
        style.configure("TCheckbutton", background=th["BG"], foreground=th["FG"],
                        font=body, padding=(4, 3), focuscolor=th["ACCENT"])
        style.map("TCheckbutton", background=[("active", th["LAYER_2"])],
                  foreground=[("disabled", th["MUTED"])])
        style.configure("TRadiobutton", background=th["BG"], foreground=th["FG"],
                        font=body, padding=(4, 3), focuscolor=th["ACCENT"])
        style.map("TRadiobutton", background=[("active", th["LAYER_2"])],
                  foreground=[("disabled", th["MUTED"])])
        style.configure("TScale", background=th["BG"], troughcolor=th["LAYER_2"],
                        borderwidth=0)
        style.configure("Tool.TButton", background=th["LAYER_2"], foreground=th["FG"],
                        font=body, borderwidth=0, padding=(10, 5), focuscolor=th["ACCENT"])
        style.map("Tool.TButton", background=[("active", th["LAYER_3"]),
                                               ("pressed", th["ACCENT_SOFT"]),
                                               ("disabled", th["BG_LIGHT"])],
                  foreground=[("disabled", th["MUTED"])])
        style.configure("Accent.TButton", background=th["ACCENT"],
                        foreground=th["ON_ACCENT"], borderwidth=0,
                        padding=(12, 6))
        style.map("Accent.TButton",
                  background=[("active", fl.lighten(th["ACCENT"], 0.12))])
        # Apple-inspired, quiet chrome: tabs read as separate workspaces,
        # with a restrained accent on the active tab instead of a full-width
        # saturated blue block. Kept in ttk so it remains lightweight on older PCs.
        style.configure("TNotebook", background=th["BG"], borderwidth=0,
                        tabmargins=(8, 7, 8, 0), padding=0)
        style.configure("TNotebook.Tab", background=th["LAYER_1"],
                        foreground=th["MUTED"], padding=(16, 9),
                        borderwidth=0, font=body, focuscolor=th["BG"])
        style.map("TNotebook.Tab",
                  background=[("selected", th["CARD_BG"]),
                              ("active", th["LAYER_2"])],
                  foreground=[("selected", th["ACCENT"]),
                              ("active", th["FG"])])
        style.configure("TEntry", fieldbackground=th["LAYER_2"],
                        foreground=th["FG"], borderwidth=0, padding=6)
        style.configure("TCombobox", fieldbackground=th["LAYER_2"],
                        background=th["LAYER_2"], foreground=th["FG"],
                        borderwidth=0, padding=4)
        style.configure("Vertical.TScrollbar", background=th["LAYER_2"],
                        troughcolor=th["BG"], borderwidth=0, arrowsize=12)
        style.configure("Horizontal.TProgressbar", background=th["ACCENT"],
                        troughcolor=th["LAYER_2"], borderwidth=0)


    def toggle_theme(self):
        """Quick-toggle affordance (e.g. a header button): flips between
        the two most common picks, Dark and Light. The full picker also
        includes the Windows 95/98 Classic theme.
        see Settings, which calls apply_theme_choice() directly with any
        theme id."""
        self.apply_theme_choice("light" if self.dark_mode else "dark")

    def apply_theme_choice(self, choice):
        """choice: any id from gui.theme.THEMES ('dark', 'light',
        'midnight_blue', 'developer', 'high_contrast', 'classic'). Legacy value
        'system' has no reliable cross-platform way to read the OS theme
        from plain Tk, so it falls back to the default theme; any other
        unrecognized id does the same rather than silently guessing wrong.

        Rebuilds the ttk style and the whole window chrome (header/
        sidebar/status/notebook) so every widget picks up the new colors
        immediately. Any tool panel that was open is closed and needs to
        be reopened from the sidebar/menu - it will render in the new
        theme when reopened."""
        if choice not in THEMES:
            choice = "dark"
        db.set_setting("theme_choice", choice)

        self.theme_id = choice
        self.dark_mode = THEMES[choice]["dark"]
        self.theme = THEMES[choice]["palette"]
        _apply_theme_globals(self.theme)
        self._crossfade_rebuild()

    def _crossfade_rebuild(self):
        """Rebuild the chrome with a cross-fade instead of an instant
        repaint: grab a screenshot of the window as it looks right now
        (old theme), swap every widget to the new theme underneath (this
        part is still instant - Tk has no way around that), then lay the
        old screenshot back on top and wipe it away to reveal the new
        look. Same reveal technique as the dashboard's card entrance
        animation, just applied to the whole window.

        Falls back to a plain instant rebuild if a screenshot can't be
        captured - e.g. Pillow missing, or ImageGrab unsupported on this
        platform/display (common outside Windows) - so theme switching
        never breaks, it just loses the transition.
        """
        overlay_image = None
        try:
            from PIL import ImageGrab, ImageTk
            self.update_idletasks()
            x, y = self.winfo_rootx(), self.winfo_rooty()
            w, h = self.winfo_width(), self.winfo_height()
            if w > 4 and h > 4:
                shot = ImageGrab.grab(bbox=(x, y, x + w, y + h))
                overlay_image = ImageTk.PhotoImage(shot)
        except Exception:
            overlay_image = None

        old_overlay = getattr(self, "_theme_overlay", None)
        old_job = getattr(self, "_theme_overlay_job", None)
        if old_job:
            try:
                self.after_cancel(old_job)
            except tk.TclError:
                pass
        if old_overlay is not None:
            try:
                old_overlay.destroy()
            except tk.TclError:
                pass
        self._theme_overlay = None
        self._theme_overlay_job = None

        self._rebuild_chrome()

        if overlay_image is None:
            return

        overlay = tk.Label(self, image=overlay_image, bd=0,
                           highlightthickness=0)
        overlay.image = overlay_image  # keep the PhotoImage reference alive
        overlay.place(x=0, y=0, relwidth=1.0, relheight=1.0)
        overlay.lift()
        self._theme_overlay = overlay

        steps, duration = 10, 220

        def _wipe(i=0):
            if not overlay.winfo_exists() or getattr(self, "_theme_overlay", None) is not overlay:
                return
            frac = (i + 1) / steps
            try:
                overlay.place_configure(rely=frac, relheight=max(0.0, 1.0 - frac))
            except tk.TclError:
                return
            if frac < 1.0:
                self.after(max(1, duration // steps), lambda: _wipe(i + 1))
            else:
                try:
                    overlay.destroy()
                except tk.TclError:
                    pass
                if getattr(self, "_theme_overlay", None) is overlay:
                    self._theme_overlay = None
                    self._theme_overlay_job = None

        self._theme_overlay_job = self.after(16, lambda: _wipe(0))

    def set_accent_color(self, hex_color):
        """Overrides the accent color on every palette in place (so the
        pick sticks whichever theme is active) and rebuilds the chrome so
        it takes effect immediately, same as a theme switch. High Contrast
        keeps its own fixed accent - accent-color picking is a "make it
        match my taste" feature, and that theme's whole point is a
        deliberately fixed, accessibility-tuned palette."""
        db.set_setting("accent_color", hex_color)
        for theme_id, entry in THEMES.items():
            if theme_id in ("high_contrast", "classic"):
                continue
            palette = entry["palette"]
            on_accent = "#03151c" if entry["dark"] else "#ffffff"
            palette["ACCENT"] = hex_color
            palette["ACCENT_SOFT"] = fl.mix(palette["BG"], hex_color, 0.35)
            palette["ACCENT_GLOW"] = fl.lighten(hex_color, 0.25)
            palette["ON_ACCENT"] = on_accent
        _apply_theme_globals(self.theme)
        self._rebuild_chrome()

    def set_font_scale(self, scale):
        """Scale is a multiplier (1.0 = default) applied to every Fluent
        font helper (gui/fluent.py:font()). Widgets that read fonts fresh
        on each rebuild (toolbar, dashboard, nav rail, Settings tab) pick
        this up immediately; a handful of tool panels built from the
        legacy gui.theme.FONT_* tuples were sized at import time and will
        pick up the new scale next time the app is launched."""
        db.set_setting("font_scale", scale)
        fl.set_font_scale(scale)
        self._rebuild_chrome()

    def _rebuild_chrome(self):
        """Rebuild the shell without making a theme/font change destroy the
        user's open work.  The old implementation tore down the notebook
        and silently discarded every open tool tab.  Capture the lightweight
        tab identities first, rebuild the chrome, then reopen the same
        surfaces and restore the selected tab. Tool state that belongs to a
        live process is intentionally refreshed, but the user's navigation
        context is preserved."""
        open_tabs = []
        selected_title = None
        notebook = getattr(self, "notebook", None)
        if notebook is not None and notebook.winfo_exists():
            try:
                selected = notebook.select()
                for tab_id in notebook.tabs():
                    title = notebook.tab(tab_id, "text")
                    display = notebook._display_title(title)
                    if display != "Dashboard":
                        open_tabs.append(display)
                    if tab_id == selected:
                        selected_title = display
            except tk.TclError:
                open_tabs = []

        for child in list(self.winfo_children()):
            child.destroy()
        # Any XP-theme snapshot taken before this pointed at widgets that
        # just got destroyed - drop it so a fresh one gets taken against
        # the newly-rebuilt header, or remove() later would silently do
        # nothing (all its stored widget references would be dead).
        if hasattr(self, "_xp_snapshot"):
            del self._xp_snapshot
        if hasattr(self, "_xp_border_frame"):
            self._xp_border_frame = None

        self.configure(bg=BG)
        self._build_style()
        self._build_layout()

        if db.get_setting("aero_glass_enabled", False):
            self.after(100, self.apply_aero_glass)

        if db.get_setting("xp_theme_enabled", False) and self.theme_id != "classic":
            self.after(100, lambda: xp_theme.apply(self))

        # Restore the surfaces that were open before the visual rebuild.
        # Use method bridges for first-party Core pages and the normal
        # catalogue dispatcher for plugin-backed tools. Unknown/stale tabs
        # are skipped rather than producing another error during a theme
        # change.
        core_reopen = {
            "Health Center": self.open_health_center_tab,
            "Diagnostic Engine": self.open_diagnostic_engine_tab,
            "Diagnostic History": self.open_diagnostic_history_tab,
            "Report Generator": self.open_report_generator_tab,
            "Repair Center": self.open_repair_center_tab,
            "Troubleshooting Wizard": self.open_troubleshooting_wizard_tab,
            "Performance Lab": self.open_performance_lab_tab,
            "Hardware Inventory": self.open_hardware_inventory_tab,
            "Network Lab": self.open_network_lab_tab,
            "Security Center": self.open_security_center_tab,
            "Snapshot Manager": self.open_snapshot_manager_tab,
            "Technician Workspace": self.open_technician_workspace_tab,
            "Explain This PC": self.open_explain_this_pc_tab,
            "Event Log Analyzer": self.open_event_log_analyzer_tab,
            "Baseline Monitor": self.open_baseline_monitor_tab,
            "TechDrive Vault": self.open_techdrive_vault_tab,
            "TechDrive Terminal": self.open_techdrive_terminal_tab,
            "FIX MY PC": self.open_fix_my_pc_tab,
            "All Tools": self.open_all_tools_tab,
            "Core Module Manager": self.open_enable_disable_tools_tab,
            "Settings": self.open_settings_tab,
        }
        for title in open_tabs:
            try:
                if title in core_reopen:
                    core_reopen[title]()
                else:
                    category = self._tool_category_for_name(title)
                    if any(title in tools for _cat, _icon, tools in CATALOGUE):
                        self.open_tool(category, title)
            except Exception as exc:
                try:
                    self.show_toast(f"Could not restore {title}: {exc}", kind="warning")
                except Exception:
                    pass

        if selected_title:
            try:
                for tab_id in self.notebook.tabs():
                    if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == selected_title:
                        self.notebook.select(tab_id)
                        break
            except tk.TclError:
                pass

        classic_theme.apply(self, enabled=self.theme_id == "classic")
        if db.get_setting("sidebar_gadgets_enabled", False):
            self.after_idle(lambda: sidebar_gadgets.refresh(self))

    # ------------------------------------------------------------------
    # Small bridges used by gui/settings.py (kept duck-typed rather than
    # having that module import techdrive.py directly, to avoid a circular
    # import - techdrive.py imports gui.settings, not the other way round).
    # ------------------------------------------------------------------
    def get_trial_status(self):
        return get_trial_status()

    def get_machine_id(self):
        return get_machine_id()

    def activate_license_key(self, key):
        ok, msg = self.license.activate_key_string(key)
        if ok:
            self.tier_label.config(text=self._tier_text())
            self._refresh_tool_widgets()
        return ok, msg

    def set_duck_assistant_enabled(self, enabled):
        db.set_setting("duck_assistant_enabled", enabled)
        if enabled:
            self.duck_assistant.show()
        else:
            self.duck_assistant.hide()

    def set_duck_mascot_enabled(self, enabled):
        """Show or hide the animated duck mascot without affecting AI chat."""
        enabled = bool(enabled)
        db.set_setting("duck_mascot_enabled", enabled)
        if enabled:
            mascot = getattr(self, "duck_mascot", None)
            if mascot is None or not mascot.winfo_exists():
                self.duck_mascot = DuckMascotWindow(self)
            else:
                mascot.show()
        else:
            mascot = getattr(self, "duck_mascot", None)
            if mascot is not None:
                try:
                    if mascot.winfo_exists():
                        mascot.hide()
                except tk.TclError:
                    pass
        if hasattr(self, "ribbon"):
            self.ribbon.set_duck_toggle(enabled)

    def set_duck_daily_tip_enabled(self, enabled):
        """Persist the optional daily-tip preference and update the live mascot."""
        enabled = bool(enabled)
        db.set_setting("duck_daily_tip_enabled", enabled)
        mascot = getattr(self, "duck_mascot", None)
        if mascot is not None:
            try:
                mascot.set_daily_tip_enabled(enabled)
            except (AttributeError, tk.TclError):
                pass

    # ------------------------------------------------------------------
    # Toast / snackbar notifications
    # ------------------------------------------------------------------
    def show_toast(self, message, kind="info", duration=2600, persist=True):
        """Small auto-dismissing notification, bottom-right of the window.

        `kind` is one of "info" / "success" / "warning" / "error" and
        just picks the accent color + icon - callers that only have a
        status-bar-style message can drop this in with no other changes.
        Multiple toasts stack upward from the bottom-right corner and
        each dismisses independently on its own timer, so a burst of
        actions doesn't clobber earlier notifications.
        """
        # Every user-visible toast is also a persistent notification unless
        # the caller explicitly opts out.  This keeps the bell useful even
        # after a toast disappears, and fixes the old situation where the
        # Notification Center could be empty because only the standalone
        # notify() helper wrote to the database.  notify() passes persist=False
        # because it already creates the database row itself.
        if persist:
            try:
                clean_message = "" if message is None else str(message)
                db.add_notification("TechDrive", clean_message, level=kind)
                self._refresh_notification_badge()
            except Exception:
                pass

        theme = self.theme
        color = {
            "info": theme["ACCENT"], "success": fl.GOOD,
            "warning": fl.WARN, "error": fl.BAD,
        }.get(kind, theme["ACCENT"])
        icon = {"info": "ℹ", "success": "✓",
                "warning": "⚠", "error": "✕"}.get(kind, "ℹ")

        container = getattr(self, "_toast_container", None)
        if container is None or not container.winfo_exists():
            container = tk.Frame(self, bg=theme["BG"])
            container.place(relx=1.0, rely=0.0, anchor="ne", x=-18, y=72)
            self._toast_container = container

        card_bg = fl.mix(theme["CARD_BG"], color, 0.10)
        toast = tk.Frame(
            container, bg=card_bg, highlightthickness=1,
            highlightbackground=fl.mix(theme["STROKE"], color, 0.35),
        )
        bar = tk.Frame(toast, bg=color, width=4)
        bar.pack(side="left", fill="y")
        inner = tk.Frame(toast, bg=card_bg)
        inner.pack(side="left", fill="both", expand=True, padx=(8, 14), pady=8)
        tk.Label(inner, text=icon, bg=card_bg, fg=color,
                font=fl.font(11, "bold")).pack(side="left", padx=(0, 8))
        tk.Label(inner, text=message, bg=card_bg, fg=theme["FG"],
                font=fl.F_SMALL(), wraplength=240, justify="left",
                anchor="w").pack(side="left", fill="both", expand=True)

        toast.pack(fill="x", pady=(0, 8), anchor="e")
        self.update_idletasks()
        full_h = max(30, toast.winfo_reqheight())
        full_w = max(260, toast.winfo_reqwidth())
        toast.configure(height=1)
        toast.pack_propagate(False)

        tween(
            toast, fl.MOTION_NORMAL,
            lambda progress: toast.configure(
                height=max(1, round(full_h * progress)),
                width=max(1, round(full_w * progress)),
            ),
            easing=ease_out_quint,
        )

        def _dismiss():
            if not toast.winfo_exists():
                return
            tween(
                toast, fl.MOTION_NORMAL,
                lambda progress: toast.configure(
                    height=max(1, round(full_h * (1.0 - progress))),
                    width=max(1, round(full_w * (1.0 - progress))),
                ),
                complete=toast.destroy,
                easing=ease_out_quint,
            )

        self.after(duration, _dismiss)
        return toast

    # ------------------------------------------------------------------
    # Notification Center
    # ------------------------------------------------------------------
    def notify(self, title, message, kind="info", toast=True, source=None):
        """Log an entry to the persistent Notification Center (the bell
        icon in the top bar) and, unless the caller opts out, also raise
        a transient toast.

        This is the preferred way for a tool to tell the user something
        happened - it replaces one-off messagebox popups scattered
        through the app: the message survives after the toast fades, and
        it doesn't interrupt the user with a modal dialog they have to
        dismiss before continuing to work.
        """
        # Respect the global Notification Center switch. The setting is
        # intentionally checked here (the central notification API) so
        # individual tools cannot accidentally bypass the user's choice.
        if not db.get_setting("notifications_enabled", True):
            return
        # If a notification is triggered by the click itself, let its event
        # cue win rather than replacing it with the generic click sound.
        self._notification_sound_until = time.monotonic() + 0.2
        sounds.play("notification")
        try:
            db.add_notification(title, message, level=kind, source=source)
        except Exception:
            pass  # the feed is best-effort; it must never block the caller
        self._refresh_notification_badge()
        if toast:
            try:
                self.show_toast(
                    f"{title}: {message}" if title else message,
                    kind=kind, persist=False,
                )
            except Exception:
                pass

    def _play_ui_click(self, event):
        """Play the selected theme's click cue for interactive controls."""
        try:
            if time.monotonic() < getattr(self, "_notification_sound_until", 0):
                return
            widget = event.widget
            widget_class = widget.winfo_class()
            if widget_class in {
                "Button", "Checkbutton", "Radiobutton", "TButton",
                "TCheckbutton", "TRadiobutton", "Menubutton", "TMenubutton",
            }:
                sounds.play("click")
                return
            cursor = widget.cget("cursor")
            if cursor in ("hand2", "pointinghand"):
                sounds.play("click")
        except Exception:
            pass

    def _refresh_notification_badge(self):
        """Update the bell icon's unread-count badge, if the top bar is
        currently built. Safe to call from any thread-marshalled UI
        callback; silently no-ops if the chrome isn't up yet."""
        topbar = getattr(self, "topbar", None)
        if topbar is not None and topbar.winfo_exists():
            try:
                topbar.set_unread_count(db.unread_notification_count())
            except Exception:
                pass

    @staticmethod
    def _hex_to_rgb(hex_color):
        h = hex_color.lstrip("#")
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

    def _refresh_aero_sheen(self):
        """Classic Windows 7-style glossy highlight strip across the very
        top of the header - purely decorative, shown only while Aero
        Glass Effect is on, so the transparency actually reads as
        'glass' rather than just a see-through window. Safe to add or
        remove at any time without disturbing the rest of the layout."""
        header = getattr(self, "_header_frame", None)
        if header is None or not header.winfo_exists():
            return
        want = db.get_setting("aero_glass_enabled", False) and aero_effect.is_supported()
        have = getattr(self, "_aero_sheen", None) is not None and self._aero_sheen.winfo_exists()
        if want and not have:
            top_rgb = aero_effect.AERO_BLUE
            bottom_rgb = self._hex_to_rgb(self.theme["SURFACE"])
            sheen = tk.Canvas(header, height=16, bg=self.theme["SURFACE"], highlightthickness=0)
            sheen.pack(side="top", fill="x")

            def draw(event=None, sheen=sheen, top_rgb=top_rgb, bottom_rgb=bottom_rgb):
                sheen.delete("all")
                w = sheen.winfo_width() or self.winfo_width() or 800
                for y in range(16):
                    t = y / 16
                    r = round(top_rgb[0] + (bottom_rgb[0] - top_rgb[0]) * t)
                    g = round(top_rgb[1] + (bottom_rgb[1] - top_rgb[1]) * t)
                    b = round(top_rgb[2] + (bottom_rgb[2] - top_rgb[2]) * t)
                    sheen.create_line(0, y, w, y, fill=f"#{r:02x}{g:02x}{b:02x}")

            sheen.bind("<Configure>", draw)
            self._aero_sheen = sheen
        elif not want and have:
            self._aero_sheen.destroy()
            self._aero_sheen = None

    def apply_aero_glass(self):
        """Apply the OS backdrop without making the entire Tk client area
        translucent.  The previous implementation used Tk ``-alpha`` on
        the whole window, which made child controls/text look washed out and
        caused Aero to fight the app's own Fluent surfaces.  DWM now owns the
        backdrop while TechDrive keeps an opaque, readable client area.
        """
        intensity = db.get_setting("aero_glass_intensity", "light")
        ok, method = aero_effect.enable(self, intensity=intensity, dark=self.dark_mode)
        self._aero_active = bool(ok)
        return ok, method

    def disable_aero_glass(self):
        ok = aero_effect.disable(self)
        self._aero_active = False
        return ok

    def set_aero_glass_enabled(self, enabled):
        """Persist Aero only after the OS compositor actually accepts it.
        A failed enable therefore cannot leave the rest of the UI believing
        Aero is active when it is not.
        """
        enabled = bool(enabled)
        if enabled:
            ok, method = self.apply_aero_glass()
            if ok:
                db.set_setting("aero_glass_enabled", True)
                self._refresh_aero_sheen()
                return True, method
            db.set_setting("aero_glass_enabled", False)
            self._aero_active = False
            self._refresh_aero_sheen()
            return False, None
        self.disable_aero_glass()
        db.set_setting("aero_glass_enabled", False)
        self._refresh_aero_sheen()
        return True, None

    # ------------------------------------------------------------------
    # Tk-safe worker -> UI bridge
    # ------------------------------------------------------------------
    def _post_ui(self, callback):
        if not getattr(self, "_closing", False):
            ui_dispatch.post(callback)

    def _start_ui_dispatcher(self):
        def pump():
            if getattr(self, "_closing", False):
                return
            ui_dispatch.drain(64)
            try:
                self._ui_pump_job = self.after(25, pump)
            except tk.TclError:
                self._ui_pump_job = None
        self._ui_pump_job = self.after(25, pump)

    def is_aero_enabled(self):
        """Return the runtime state, not merely the saved preference."""
        return bool(getattr(self, "_aero_active", False))

    def toggle_aero_glass(self):
        enabled = not self.is_aero_enabled()
        ok, _method = self.set_aero_glass_enabled(enabled)
        if ok:
            self.apply_theme_choice("dark" if self.dark_mode else "light")
        return bool(ok and enabled)

    def get_user_name(self):
        """Display name for the profile chip / dashboard greeting."""
        try:
            return (os.environ.get("USERNAME") or os.environ.get("USER")
                    or "TechDrive User")
        except Exception:
            return "TechDrive User"

    def get_cpu_name(self):
        """Short CPU description for the CPU card subtitle (cached - the
        WMI/cpuinfo lookups behind it are slow, and it never changes).

        Prefers the human-readable brand string ("Intel(R) Core(TM)
        i7-8700K", "AMD Ryzen 7 5800X", ...) from py-cpuinfo over the raw
        platform.processor() codename dump ("Intel64 Family 6 Model 42
        Stepping 9, GenuineIntel"), which is accurate but meaningless to
        most people looking at the dashboard.
        """
        if getattr(self, "_cpu_name", None):
            return self._cpu_name
        from gui.cpu_label import format_cpu_label
        brand = self._friendly_cpu_name()
        physical = max_ghz = None
        if psutil:
            try:
                physical = psutil.cpu_count(logical=False)
            except Exception:
                pass
            try:
                freq = psutil.cpu_freq()
                if freq and freq.max:
                    max_ghz = freq.max / 1000
            except Exception:
                pass
        # About This Mac style: "3.1 GHz Quad-Core Intel Core i5".
        self._cpu_name = format_cpu_label(brand, physical, max_ghz)[:48]
        return self._cpu_name

    @staticmethod
    def _friendly_cpu_name():
        """Best-effort human-readable CPU brand string.

        Tries py-cpuinfo's brand_raw first (e.g. "Intel(R) Core(TM)
        i7-8700K CPU @ 3.70GHz"). Falls back to a short vendor label
        ("Intel Processor" / "AMD Processor") parsed out of
        platform.processor(), and only falls back to the raw codename
        string as a last resort.
        """
        try:
            import cpuinfo
            brand = (cpuinfo.get_cpu_info() or {}).get("brand_raw")
            if brand:
                return brand.strip()
        except Exception:
            pass

        raw = platform.processor() or platform.machine() or "Processor"
        lowered = raw.lower()
        if "genuineintel" in lowered or "intel" in lowered:
            return "Intel Processor"
        if "authenticamd" in lowered or "amd" in lowered:
            return "AMD Processor"
        return raw

    def get_power_plan(self):
        """Active Windows power plan; a harmless placeholder elsewhere."""
        if getattr(self, "_power_plan", None):
            return self._power_plan
        plan = "Balanced"
        if IS_WINDOWS:
            try:
                out = run_cmd("powercfg /getactivescheme")
                match = re.search(r"\((.*?)\)", out)
                if match:
                    plan = match.group(1)
            except Exception:
                pass
        self._power_plan = plan
        return plan

    def get_gpu_snapshot(self):
        """(value_text, subtitle, sample) for the dashboard GPU card.

        Reuses NVML if the existing nvidia_gpu module/library is present,
        otherwise falls back to a name-only read so the card never blocks
        or crashes on machines without a discrete GPU."""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8", "ignore")
            util = pynvml.nvmlDeviceGetUtilizationRates(handle).gpu
            try:
                temp = pynvml.nvmlDeviceGetTemperature(handle, 0)
                value = f"{temp}°C"
            except Exception:
                value = f"{util}%"
            return value, name[:32], float(util)
        except Exception:
            pass
        if self._gpu_cache is None and IS_WINDOWS:
            try:
                # run_cmd() returns (ok, output) - it was previously being
                # treated as a bare string here, so .splitlines() always
                # raised and silently fell through to the "GPU" placeholder
                # below regardless of whether the query actually worked.
                ok, out = run_cmd("wmic path win32_VideoController get name")
                lines = [l.strip() for l in out.splitlines() if l.strip()]
                name = lines[1] if ok and len(lines) > 1 else None
                if not name:
                    # wmic is removed on newer Windows builds - fall back
                    # to the modern CIM cmdlet before giving up.
                    ok, out = run_cmd(
                        "powershell -NoProfile -Command "
                        "\"(Get-CimInstance Win32_VideoController | "
                        "Select-Object -First 1 -ExpandProperty Name)\"")
                    name = out.strip() if ok and out.strip() else None
                self._gpu_cache = name or "No GPU telemetry"
            except Exception:
                self._gpu_cache = "No GPU telemetry"
        return "—", (self._gpu_cache or "No GPU telemetry"), None

    def get_recent_tools(self, limit=10):
        """Recently opened tools as [(category, tool), ...] - reads the
        existing recents table, so the dashboard shows real history."""
        try:
            rows = db.get_recent(limit)
        except Exception:
            return []
        out = []
        for row in rows:
            try:
                out.append((row[0], row[1]))
            except Exception:
                continue
        return out

    def get_pinned_tools(self):
        """Starred/pinned tools as [(category, tool), ...] for the
        dashboard's Quick Access card - same favorites the All Tools
        gallery's star toggle and Pinned Favorites view read from."""
        try:
            return [(row[0], row[1]) for row in db.get_favorites()]
        except Exception:
            return []

    def _on_favorites_changed(self):
        """Keep the dashboard's Quick Access card in sync when a star is
        toggled from inside the All Tools gallery."""
        if getattr(self, "dashboard", None) is not None:
            try:
                self.dashboard.refresh_pinned()
            except Exception:
                pass


    def set_xp_theme_enabled(self, enabled):
        db.set_setting("xp_theme_enabled", enabled)
        if enabled:
            return xp_theme.apply(self)
        else:
            xp_theme.remove(self)
            return True

    def set_sidebar_gadgets_enabled(self, enabled):
        db.set_setting("sidebar_gadgets_enabled", enabled)
        if enabled:
            sidebar_gadgets.show(self)
        else:
            sidebar_gadgets.hide()
        return True

    def set_monitor_visual_skin(self, skin):
        if skin not in ("standard", "crt", "winamp"):
            skin = "standard"
        db.set_setting("monitor_visual_skin", skin)

        def visit(parent):
            for child in parent.winfo_children():
                apply_skin = getattr(child, "set_visual_skin", None)
                if callable(apply_skin):
                    try:
                        apply_skin(skin)
                    except tk.TclError:
                        pass
                visit(child)

        visit(self)
        return True

    def configure_idle_screensaver(self):
        job = getattr(self, "_screensaver_job", None)
        if job:
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass
        self._screensaver_job = None
        if getattr(self, "_screensaver_active", False):
            return
        try:
            minutes = max(0, int(db.get_setting("screensaver_idle_minutes", 0)))
        except (TypeError, ValueError):
            minutes = 0
        self._screensaver_idle_minutes = minutes if minutes in (5, 10, 15) else 0
        self._schedule_idle_screensaver()

    def _screensaver_activity(self, _event=None):
        if (not getattr(self, "_screensaver_active", False)
                and getattr(self, "_screensaver_idle_minutes", 0)):
            self._schedule_idle_screensaver()

    def _schedule_idle_screensaver(self):
        job = getattr(self, "_screensaver_job", None)
        if job:
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass
        self._screensaver_job = None
        minutes = getattr(self, "_screensaver_idle_minutes", 0)
        if minutes and not getattr(self, "_screensaver_active", False):
            self._screensaver_job = self.after(
                minutes * 60_000, self._launch_idle_screensaver)

    def _launch_idle_screensaver(self):
        self._screensaver_job = None
        try:
            minutes = int(db.get_setting("screensaver_idle_minutes", 0))
        except (TypeError, ValueError):
            minutes = 0
        if minutes <= 0 or self._screensaver_active:
            return
        self._open_screensaver()

    def start_screensaver(self):
        if self._screensaver_active:
            return
        if self._screensaver_job:
            try:
                self.after_cancel(self._screensaver_job)
            except tk.TclError:
                pass
            self._screensaver_job = None
        self._open_screensaver()

    def _open_screensaver(self):
        style = db.get_setting("screensaver_style", "mystify")
        self._screensaver_active = True
        try:
            screensaver.start(self, style=style, on_close=self._screensaver_closed)
        except tk.TclError:
            self._screensaver_active = False
            self.configure_idle_screensaver()

    def _screensaver_closed(self):
        self._screensaver_active = False
        self._screensaver_window = None
        self.configure_idle_screensaver()

    def _build_rgb_accent(self):
        """Creates the 4 edge accent strips + 4 corner glows once per
        chrome build. Always constructed (cheap, idle until start()ed) so
        toggling any Settings switch/slider is just show/hide/reconfigure,
        not a rebuild."""
        theme_bg = self.theme["BG"]

        self.rgb_accent_bottom = RGBAccentBar(self, bg=theme_bg, hue_offset=0.5)
        self.rgb_accent_bottom.pack(side="bottom", fill="x")

        self.rgb_accent_top = RGBAccentBar(self, bg=theme_bg, hue_offset=0.0)
        self.rgb_accent_top.pack(side="top", fill="x")

        self.rgb_accent_left = RGBAccentBar(self, bg=theme_bg, hue_offset=0.25,
                                             orientation="vertical")
        self.rgb_accent_left.pack(side="left", fill="y")

        self.rgb_accent_right = RGBAccentBar(self, bg=theme_bg, hue_offset=0.75,
                                              orientation="vertical")
        self.rgb_accent_right.pack(side="right", fill="y")

        self.rgb_corners = [
            CornerGlow(self, corner=c, bg=theme_bg, hue_offset=i * 0.25)
            for i, c in enumerate(CORNERS)
        ]

        self._apply_rgb_accent_settings()

    def _rgb_accent_widgets(self):
        edges = [self.rgb_accent_top, self.rgb_accent_bottom,
                  self.rgb_accent_left, self.rgb_accent_right]
        corners = list(self.rgb_corners)
        return edges, corners

    def _apply_rgb_accent_settings(self):
        """Re-reads every RGB-accent setting from the database and
        applies it to the live widgets: master on/off, edges-only vs
        corners-only, speed, brightness, and color mode (rainbow cycle
        vs a fixed color synced to the current accent color). Safe to
        call any time after _build_rgb_accent() has run - every Settings
        control for this feature just calls this after writing its
        own setting."""
        master_on = db.get_setting("rgb_accent_enabled", False)
        edges_on = db.get_setting("rgb_accent_edges_enabled", True)
        corners_on = db.get_setting("rgb_accent_corners_enabled", True)
        speed = db.get_setting("rgb_accent_speed", "normal")
        brightness = db.get_setting("rgb_accent_brightness", 1.0)
        color_mode = db.get_setting("rgb_accent_color_mode", "rainbow")
        line_style = db.get_setting("rgb_accent_line_style", "solid")
        line_opacity = db.get_setting("rgb_accent_line_opacity", 0.6)

        speed_ms = SPEED_PRESETS.get(speed, SPEED_PRESETS["normal"])
        hue_step = None if color_mode == "rainbow" else 0.0
        fixed_hue = None
        if color_mode == "static":
            fixed_hue = hex_to_hue(self.theme["ACCENT"])

        edges, corners = self._rgb_accent_widgets()
        edge_sides = [("top", "x"), ("bottom", "x"), ("left", "y"), ("right", "y")]

        for w, (side, fill) in zip(edges, edge_sides):
            show = master_on and edges_on
            w.configure_animation(speed_ms=speed_ms, hue_step=hue_step,
                                  value=brightness, fixed_hue=fixed_hue,
                                  style=line_style, opacity=line_opacity)
            if show:
                w.pack(side=side, fill=fill)
                w.start()
            else:
                w.stop()
                w.pack_forget()

        for w in corners:
            show = master_on and corners_on
            w.configure_animation(speed_ms=speed_ms, hue_step=hue_step,
                                  value=brightness, fixed_hue=fixed_hue)
            if show:
                w._place_in_corner()
                w.start()
            else:
                w.stop()
                w.place_forget()

    def set_rgb_accent_enabled(self, enabled):
        db.set_setting("rgb_accent_enabled", enabled)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_edges_enabled(self, enabled):
        db.set_setting("rgb_accent_edges_enabled", enabled)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_corners_enabled(self, enabled):
        db.set_setting("rgb_accent_corners_enabled", enabled)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_speed(self, speed):
        """speed: 'slow' | 'normal' | 'fast'."""
        db.set_setting("rgb_accent_speed", speed)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_brightness(self, brightness):
        """brightness: float 0.3-1.0 (HSV 'value')."""
        db.set_setting("rgb_accent_brightness", brightness)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_color_mode(self, mode):
        """mode: 'rainbow' (hue-cycling, default) | 'static' (locked to
        the current theme accent color, see set_accent_color())."""
        db.set_setting("rgb_accent_color_mode", mode)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_line_style(self, style):
        """style: 'solid' (default, opaque bar) | 'line' (thin, blended
        toward the background to look semi-transparent) | 'mist' (soft
        multi-band fade, like a glow instead of a hard edge). Only
        affects the top/bottom edge bars, not the corner glows."""
        if style not in ("solid", "line", "mist"):
            return False
        db.set_setting("rgb_accent_line_style", style)
        self._apply_rgb_accent_settings()
        return True

    def set_rgb_accent_line_opacity(self, opacity):
        """opacity: float 0.0-1.0. Blend strength for 'line'/'mist'
        styles (ignored by 'solid', which is always fully opaque)."""
        opacity = max(0.0, min(1.0, opacity))
        db.set_setting("rgb_accent_line_opacity", opacity)
        self._apply_rgb_accent_settings()
        return True

    def refresh_settings_tab(self):
        """Rebuilds the Settings tab in place after something changes its
        own state (license activated, backup restored, settings reset)."""
        if getattr(self, "_settings_tab_frame", None) is None:
            return
        for child in self._settings_tab_frame.winfo_children():
            child.destroy()
        settings_tab.build_settings_tab(self._settings_tab_frame, self)

    def refresh_language(self):
        """Called after the language changes in Settings. Relabels the
        parts of the app shell that were built once at startup rather
        than rebuilt from a live data source (topbar search placeholder,
        nav rail, dashboard). The Settings tab itself is rebuilt by the
        caller. Individual tool panels (the 40+ modules under gui/ and
        techdrive_modules/) are NOT retranslated here - each one picks up
        the new language the next time it's opened, same contract
        font-scale changes already use for open panels.
        """
        try:
            from i18n import t
            if hasattr(self, "topbar") and hasattr(self.topbar, "search"):
                self.topbar.search.placeholder = t("topbar.search_placeholder")
                if getattr(self.topbar.search, "_showing_placeholder", False):
                    self.topbar.search.entry.delete(0, "end")
                    self.topbar.search.entry.insert(0, self.topbar.search.placeholder)
            if hasattr(self, "_all_tools_page") and hasattr(self._all_tools_page, "fav_btn"):
                self._all_tools_page.fav_btn.config(text=f"\u2b50 {t('sidebar.favorites')}")
            # Nav rail: rebuild in place with freshly-translated labels
            # rather than leaving the old-language labels stuck until the
            # whole app restarts.
            if hasattr(self, "navrail") and self.navrail.winfo_exists():
                parent = self.navrail.master
                side_before = "left"
                self.navrail.destroy()
                self.navrail = NavRail(parent, self, self._nav_destinations(),
                                       on_dashboard=self.show_dashboard)
                self.navrail.pack(side=side_before, fill="y", before=self._content_frame)
            # Dashboard: rebuild if it's the currently-open tab so its
            # section headers pick up the new language immediately instead
            # of only "next time it's opened" (it's usually always open).
            if getattr(self, "_dashboard_frame", None) is not None:
                current_tab = self.notebook.select() if self.notebook.tabs() else None
                self.show_dashboard(force_rebuild=True)
                # Only steal focus onto the dashboard tab if it was already
                # the frontmost tab - don't yank the user off whatever tool
                # panel they're looking at just because they changed language.
                if current_tab and current_tab != str(self._dashboard_frame):
                    try:
                        self.notebook.select(current_tab)
                    except Exception:
                        pass
        except Exception:
            pass  # language switching must never crash the app shell

    def _build_menu(self):
        menubar = tk.Menu(self)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        tools_menu = tk.Menu(menubar, tearoff=0)
        grouped = {g: [] for g in TOOL_GROUPS}
        for cat, icon, tools in CATALOGUE:
            grouped[_category_group(cat)].append((cat, icon, tools))
        for group in TOOL_GROUPS:
            group_menu = tk.Menu(tools_menu, tearoff=0)
            for cat, icon, tools in grouped[group]:
                sub = tk.Menu(group_menu, tearoff=0)
                for t in tools:
                    sub.add_command(label=t, command=lambda c=cat, n=t: self.open_tool(c, n))
                group_menu.add_cascade(label=f"{icon} {cat}", menu=sub)
            icon = TOOL_GROUP_ICONS.get(group, "")
            tools_menu.add_cascade(label=f"{icon} {group}", menu=group_menu)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        reports_menu = tk.Menu(menubar, tearoff=0)
        reports_menu.add_command(label="TXT Report", command=self.generate_report_txt)
        reports_menu.add_command(label="PDF Report", command=self.generate_report_pdf)
        reports_menu.add_command(label="Professional Report Generator",
                                 command=self.open_report_generator_tab)
        menubar.add_cascade(label="Reports", menu=reports_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        self._populate_help_menu(help_menu)
        menubar.add_cascade(label="Help", menu=help_menu)

        settings_menu = tk.Menu(menubar, tearoff=0)
        settings_menu.add_command(label="Preferences...", command=self.show_preferences)
        settings_menu.add_command(label="Control Center\tCtrl+Shift+C",
                                  command=lambda: getattr(self, "control_center", None) and self.control_center.toggle())
        settings_menu.add_command(label="Theme", command=self.toggle_theme)
        menubar.add_cascade(label="Settings", menu=settings_menu)

        self.config(menu=menubar)

    def _build_toolbar(self, parent):
        """Fluent command bar: quick category jumps plus the Quick Scan /
        Report actions. Same commands as before, now rounded buttons with
        hover lighting instead of flat grey tk.Buttons."""
        from gui.widgets import FluentButton, GlassCard

        bar_bg = fl.glass(self.theme, "BG", self.is_aero_enabled(), 0.10)
        toolbar = tk.Frame(parent, bg=bar_bg, height=48)
        toolbar.pack(side="top", fill="x")
        self._toolbar_frame = toolbar
        toolbar.pack_propagate(False)

        self._toolbar_buttons = {}
        self._toolbar_more = None

        def add(label, icon, command, kind="subtle", key=None):
            btn = FluentButton(toolbar, label, icon=icon, command=command,
                               theme=self.theme, aero=self.is_aero_enabled(),
                               kind=kind, height=32, backdrop=bar_bg,
                               font_=fl.F_SMALL()).pack(side="left", padx=(4, 0),
                                                        pady=8)
            # pack() returns None, so find the newly-created child. Keeping
            # explicit references lets the compact toolbar hide secondary
            # actions without destroying their commands.
            child = toolbar.winfo_children()[-1]
            if key:
                self._toolbar_buttons[key] = child
            return child

        for label, icon, group in (("System", "⌕", "System"),
                                   ("Disk", "▣", "Disk"),
                                   ("Network", "◎", "Network"),
                                   ("Repair", "⚒", "Repair")):
            add(label, icon, lambda g=group: self._open_group(g))
        add("Settings", "⚙", self.show_preferences)
        add("Controls", "◉", lambda: getattr(self, "control_center", None) and self.control_center.toggle())
        add("Stage", "⧉", self.open_stage_manager)
        add("Exposé", "▦", self.open_mission_control_view)

        tk.Frame(toolbar, bg=self.theme["STROKE"], width=1).pack(
            side="left", padx=8, pady=12, fill="y")

        add("Quick Scan", "↯", self.run_quick_scan, kind="accent", key="scan")
        add("Report", "▤", self.open_report_generator_tab, key="report")
        add("Upgrade", "⬆", self.show_upgrade, key="upgrade")
        add("Help", "?", self._open_help_menu, key="help")

        # At the minimum supported window width the original command bar
        # could put the last button flush against the window edge. Keep all
        # commands reachable, but move secondary actions into one overflow
        # button when space is tight.
        more = FluentButton(toolbar, "More", icon="⋯", command=self._open_toolbar_more,
                             theme=self.theme, aero=self.is_aero_enabled(),
                             kind="subtle", height=32, width=82,
                             backdrop=bar_bg, font_=fl.F_SMALL())
        more.pack(side="left", padx=(4, 6), pady=8)
        self._toolbar_more = more
        toolbar.bind("<Configure>", self._responsive_toolbar, add="+")
        self._responsive_toolbar()

    def _responsive_toolbar(self, _event=None):
        toolbar = getattr(self, "_toolbar_frame", None)
        if toolbar is None:
            # _build_toolbar may call this before the frame reference is set.
            toolbar = _event.widget if _event is not None else None
        if toolbar is None or not hasattr(toolbar, "winfo_width"):
            return
        try:
            compact = toolbar.winfo_width() < 1160
            for key in ("upgrade", "help"):
                btn = self._toolbar_buttons.get(key)
                if btn is None:
                    continue
                if compact:
                    btn.pack_forget()
                elif not btn.winfo_ismapped():
                    # Reinsert secondary buttons immediately before More so
                    # expanding the window restores the original command-bar
                    # order instead of appending them after the overflow menu.
                    if self._toolbar_more is not None:
                        btn.pack(side="left", before=self._toolbar_more,
                                padx=(4, 0), pady=8)
                    else:
                        btn.pack(side="left", padx=(4, 0), pady=8)
            if self._toolbar_more is not None:
                if compact:
                    self._toolbar_more.pack(side="left", padx=(4, 6), pady=8)
                else:
                    self._toolbar_more.pack_forget()
        except tk.TclError:
            return

    def _open_toolbar_more(self):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Upgrade", command=self.show_upgrade)
        menu.add_command(label="Help", command=self._open_help_menu)
        menu.add_separator()
        menu.add_command(label="All Tools", command=self.open_all_tools_tab)
        menu.add_command(label="TechDrive Core", command=self.open_core_picker_window)
        try:
            menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            menu.grab_release()

    def _open_help_menu(self):
        """Compact replacement for the retired native menu-bar Help menu."""
        menu = tk.Menu(self, tearoff=0)
        self._populate_help_menu(menu)
        try:
            menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            menu.grab_release()


    def _open_group(self, group):
        """Expand the sidebar to the first category in a toolbar/menu group
        and open its first tool, as a fast way in from the quick-category
        buttons - matches Notepad++'s "just get me there" toolbar feel."""
        for cat, icon, tools in CATALOGUE:
            if _category_group(cat) == group and tools:
                self.open_tool(cat, tools[0])
                return

    def run_quick_scan(self):
        """No built-in system-info tools ship anymore - point the user at
        the Core Module Manager instead of trying to open tools that don't
        exist."""
        self.open_health_center_tab()

    def show_preferences(self):
        self.open_settings_tab()

    def _setup_keyboard_shortcuts(self):
        """Global, app-wide shortcuts for keyboard-first navigation.

        These are bound on the root window (self), same pattern TopBar
        already uses for Ctrl+K, so they fire regardless of which tab is
        focused. Widgets that need their own Return/Escape/arrow handling
        (search entry, dialogs, tool prev/next) bind those locally and
        return "break", which stops the event before it reaches here -
        so this never steals a keystroke out of a text field.
        """
        def _shortcut(_event, action):
            action()
            return "break"

        bindings = {
            "<Control-Key-1>": self.show_dashboard,
            "<Control-Key-2>": self.open_all_tools_tab,
            "<Control-Key-3>": self.open_report_generator_tab,
            "<Control-comma>": self.open_settings_tab,
            "<F1>": self.show_help_center,
            "<Control-Shift-P>": self.open_pinned_tools_tab,
            "<Control-Shift-KeyPress-P>": self.open_pinned_tools_tab,
            "<Control-Shift-C>": lambda: getattr(self, "control_center", None) and self.control_center.toggle(),
            "<Control-Shift-c>": lambda: getattr(self, "control_center", None) and self.control_center.toggle(),
        }
        for sequence, action in bindings.items():
            self.bind(sequence, lambda e, a=action: _shortcut(e, a))

    def open_pinned_tools_tab(self):
        """Ctrl+Shift+P - jump straight to the All Tools gallery, filtered
        to pinned/favorite tools. Reuses ModuleGalleryPage's existing
        favorites view rather than building a second tool list."""
        self.open_all_tools_tab()
        if getattr(self, "_all_tools_page", None):
            self._all_tools_page.show_favorites()

    def open_settings_tab(self):
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Settings":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add_closable(frame, text="⚙ Settings")
        self.notebook.select(frame)
        self._settings_tab_frame = frame
        settings_tab.build_settings_tab(frame, self)

    def open_all_tools_tab(self):
        """Beautified, icon-tile grid over the same CATALOGUE the sidebar
        tree uses - a visual alternative to the plain text list, not a
        replacement for it (the searchable tree in the nav rail still
        works exactly as before)."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "All Tools":
                self.notebook.select(tab_id)
                if getattr(self, "_all_tools_page", None):
                    self._all_tools_page.show()
                return
        frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add_closable(frame, text="◎ All Tools")
        self.notebook.select(frame)
        self._all_tools_page = ModuleGalleryPage(
            frame, self.theme, CATALOGUE, CATEGORY_COLORS,
            on_open_tool=self.open_tool,
            is_favorite=db.is_favorite,
            toggle_favorite=db.toggle_favorite,
            aero=self.is_aero_enabled(),
            tool_groups=TOOL_GROUPS,
            group_labels=GROUP_LABELS,
            get_recent=db.get_recent,
            clear_recent=db.clear_recent,
            on_favorites_changed=self._on_favorites_changed,
        )
        self._all_tools_page.pack(fill="both", expand=True)

    def open_tool_group_tab(self, group_key):
        """Open All Tools pre-filtered to one TOOL_GROUPS bucket - used by
        the nav rail's category shortcuts (System Scan, Storage Mgmt,
        Network, Security, Maintenance, Reports) added to match the
        concept mockup's sidebar. Reuses the exact same ModuleGalleryPage
        as "All Tools"; nothing is duplicated, it's just opened already
        scrolled to one group via show_group()."""
        self.open_all_tools_tab()
        if getattr(self, "_all_tools_page", None):
            self._all_tools_page.show_group(group_key)

    def open_enable_disable_tools_tab(self):
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Core Module Manager":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add_closable(frame, text="◈ Core Module Manager")
        self.notebook.select(frame)
        self._enable_disable_tools_tab_frame = frame
        enable_disable_tools.build_enable_disable_tools_tab(frame, self)

    def _rebuild_flat_tools(self):
        self.flat_tools = []
        for cat, icon, tools in CATALOGUE:
            for t in tools:
                self.flat_tools.append((cat, icon, t))

    def _refresh_tool_widgets(self):
        """Called after a tool enable/disable or a license change so
        the All Tools gallery and the top-bar search box reflect the
        live CATALOGUE."""
        self._rebuild_flat_tools()
        if getattr(self, "topbar", None) is not None:
            self.topbar.refresh_catalogue(CATALOGUE)
        if getattr(self, "_all_tools_page", None) is not None:
            self._all_tools_page.refresh_catalogue(CATALOGUE)

    def enable_app_plugin(self, modname):
        """Enable a bundled tool group and persist the choice."""
        ok = enable_plugin(modname)
        if ok:
            disabled = set(db.get_setting("disabled_plugins", []))
            disabled.discard(modname)
            db.set_setting("disabled_plugins", sorted(disabled))
            installed = set(db.get_setting("installed_plugins", []))
            installed.add(modname)
            db.set_setting("installed_plugins", sorted(installed))
            self._refresh_tool_widgets()
        return ok

    def disable_app_plugin(self, modname):
        """Disable a bundled tool group and persist the choice."""
        if modname not in PLUGIN_REGISTRY:
            return False
        ok = disable_plugin(modname)
        if ok:
            disabled = set(db.get_setting("disabled_plugins", []))
            disabled.add(modname)
            db.set_setting("disabled_plugins", sorted(disabled))
            installed = set(db.get_setting("installed_plugins", []))
            installed.discard(modname)
            db.set_setting("installed_plugins", sorted(installed))
            self._refresh_tool_widgets()
        return ok

    # Compatibility bridges for developer/import code. The UI uses the
    # explicit enable/disable names above; these do not mean network install.
    def install_app_plugin(self, modname):
        return self.enable_app_plugin(modname)

    def uninstall_app_plugin(self, modname):
        return self.disable_app_plugin(modname)

    def import_app_plugin_from_source(self, source):
        """Downloads/reads a plugin .zip (URL or local path), extracts it
        into techdrive_modules/, imports it, and installs it into the
        running app. Returns (True, modname) or (False, error_message) -
        see import_plugin_zip() for the exact zip layout it expects."""
        ok, result = import_plugin_zip(source, install=False)
        if not ok:
            self.status_text.set(f"Plugin import failed: {result}")
            return False, result
        modname = result
        self.install_app_plugin(modname)
        self.status_text.set(f"Imported and installed plugin: "
                              f"{PLUGIN_REGISTRY.get(modname, {}).get('name', modname)}")
        return True, modname

    def import_app_plugins_by_names(self, base_url, tool_names, on_progress=None):
        """Bulk version: builds '<base_url>/<tool_name>.zip' for each name
        in tool_names, imports and installs each one. Returns the list of
        (tool_name, ok, result) tuples from import_plugins_by_names()."""
        def _progress(tool_name, ok, result):
            if ok:
                self.install_app_plugin(result)
            if on_progress:
                on_progress(tool_name, ok, result)
        results = import_plugins_by_names(base_url, tool_names, install=False,
                                           on_progress=_progress)
        succeeded = sum(1 for _n, ok, _r in results if ok)
        self.status_text.set(f"Imported {succeeded}/{len(tool_names)} plugins from {base_url}")
        return results

    def open_core_modules_tab(self):
        """Open the bundled TechDrive Core module browser."""
        title = "TechDrive Core"
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == title:
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=BG)
        page = CoreModulesPage(frame, self, PLUGIN_REGISTRY, self.open_core_module)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="◈ TechDrive Core")
        self.notebook.select(frame)
        self._core_modules_page = page
        self.status_text.set("Opened: TechDrive Core")

    def open_core_module(self, modname):
        """Open all catalogue tools belonging to one bundled module."""
        info = PLUGIN_REGISTRY.get(modname, {})
        categories = list(info.get("categories", []))
        if not categories:
            self.status_text.set(f"{modname}: support module")
            return
        self.open_all_tools_tab()
        page = getattr(self, "_all_tools_page", None)
        if page is not None:
            if hasattr(page, "show_categories"):
                page.show_categories(categories)
            else:
                page.show_category(categories[0])

    def _set_theme_from_ribbon(self, choice):
        try:
            self.apply_theme_choice(choice)
        except Exception:
            self.toggle_theme()

    def toggle_sidebar_from_ribbon(self):
        rail = getattr(self, "navrail", None)
        if rail is None:
            return
        if rail.winfo_ismapped():
            rail.pack_forget()
            self._ribbon_sidebar_hidden = True
        else:
            rail.pack(side="left", fill="y", before=getattr(self, "_content_frame", None))
            self._ribbon_sidebar_hidden = False

    def toggle_statusbar_from_ribbon(self):
        status = getattr(self, "_status_frame", None)
        if status is None:
            return
        if status.winfo_ismapped():
            status.pack_forget()
            self._ribbon_status_hidden = True
        else:
            status.pack(side="bottom", fill="x")
            self._ribbon_status_hidden = False

    def _nav_destinations(self):
        """Apple-inspired, task-first sidebar matching the TechDrive workspace brief.

        Category entries reuse the existing All Tools gallery and its real
        catalogue groups; this is navigation only, not duplicate tool code.
        """
        return [
            {"kind": "item", "label": "Overview", "icon": "dashboard",
             "action": self.show_dashboard},
            {"kind": "item", "label": "System", "icon": "core",
             "action": lambda: self.open_tool_group_tab("System")},
            {"kind": "item", "label": "Maintenance", "icon": "repair",
             "action": lambda: self.open_tool_group_tab("Repair")},
            {"kind": "item", "label": "Files", "icon": "file",
             "action": lambda: self.open_tool_group_tab("File")},
            {"kind": "item", "label": "Hardware", "icon": "hardware",
             "action": lambda: self.open_tool_group_tab("Hardware")},
            {"kind": "item", "label": "Network", "icon": "network",
             "action": lambda: self.open_tool_group_tab("Network")},
            {"kind": "item", "label": "Security", "icon": "security",
             "action": lambda: self.open_tool_group_tab("Security")},
            {"kind": "item", "label": "All Tools", "icon": "tools",
             "action": self.open_all_tools_tab},
            {"kind": "section", "label": "PREFERENCES"},
            {"kind": "item", "label": "Settings", "icon": "settings",
             "action": self.open_settings_tab},
        ]

    def _build_layout(self):
        """Fluent shell: top bar → command bar → (nav rail | tab area) →
        status bar. The notebook, sidebar tree, duck assistant, Aero, XP
        theme and gadgets all behave exactly as before."""
        aero = self.is_aero_enabled()

        # --- RGB accent: hue-cycling top/bottom strips + 4 corner glows.
        #     Purely decorative, cheap by design (see gui/rgb_accent.py),
        #     and fully gated by the "RGB Accent" Settings toggle (default
        #     on) — set_rgb_accent_enabled() shows/hides + starts/stops
        #     these without needing a full chrome rebuild.
        self._build_rgb_accent()

        # --- Top bar (search, clock, theme + aero switches, profile,
        #     window controls). Kept as the aero-sheen host so the classic
        #     Windows 7 gloss strip still lands on the chrome.
        self.topbar = TopBar(self, self, CATALOGUE)
        self.topbar.pack(side="top", fill="x")
        self._header_frame = self.topbar
        self._aero_sheen = None
        self._refresh_aero_sheen()
        self.tier_label = self.topbar.tier_label

        self.ribbon = TechDriveRibbon(self, self)
        self.ribbon.pack(side="top", fill="x")
        self._toolbar_frame = self.ribbon

        # Body: nav rail + content
        body = tk.Frame(self, bg=BG)
        body.pack(side="top", fill="both", expand=True)

        # Nav rail: pinned shortcuts (Dashboard, All Tools, Core Module Manager,
        # Settings, About). "All Tools" opens the gallery tab built in
        # gui/module_gallery.py - see open_all_tools_tab() below. The
        # rail no longer hosts its own tool tree/drawer.
        self.navrail = NavRail(body, self, self._nav_destinations(),
                               on_dashboard=self.show_dashboard)
        self.navrail.pack(side="left", fill="y")


        # Content area (closable-tab notebook so multiple tools can stay
        # open, each with its own ✕ button - see gui/closable_notebook.py)
        content = tk.Frame(body, bg=BG)
        self._content_frame = content
        content.pack(side="left", fill="both", expand=True)
        self.notebook = ClosableNotebook(
            content, protected_titles={"Dashboard", "Settings"},
            on_close=self._on_tab_closed,
        )
        self.notebook.accent_color = self.theme["ACCENT"]
        # Previous / next arrows for the open tabs (liquid-glass capsule).
        # Packed before the notebook so it sits directly above the tab row.
        self.tab_nav = TabNavBar(content, self.notebook, self.theme)
        self.tab_nav.pack(side="top", fill="x", pady=(6, 0))
        # Let the dashboard hero sit at the very top of the available content
        # area; the tab-navigation row above it already provides separation.
        self.notebook.pack(fill="both", expand=True, padx=(fl.GAP, fl.GAP),
                           pady=(0, 6))
        self._welcome_tab()
        self._settings_tab_frame = None

        # Status bar
        status_bg = fl.glass(self.theme, "SURFACE", aero, 0.18)
        status = tk.Frame(self, bg=status_bg, height=28)
        self._status_frame = status
        status.pack(side="bottom", fill="x")
        status.pack_propagate(False)
        small = fl.F_SMALL()

        def chip(text=None, variable=None, fg_key="MUTED", side="right"):
            lbl = tk.Label(status, text=text, textvariable=variable,
                           bg=status_bg, fg=self.theme[fg_key], font=small,
                           anchor="w")
            lbl.pack(side=side, padx=12)
            return lbl

        self.status_text = tk.StringVar(value="Ready")
        chip(variable=self.status_text, fg_key="FG", side="left")
        hwid = get_machine_id().upper()
        chip(text=f"HWID: {hwid[:8]}…")
        tool_count = sum(len(tools) for _, _, tools in CATALOGUE)
        chip(text=f"Tools: {tool_count}")
        chip(text=f"Tier: {TIER_INFO[self.license.tier]['name']}",
             fg_key="ACCENT")
        self.status_cpu = tk.StringVar(value="CPU: --%")
        self.status_ram = tk.StringVar(value="RAM: --%")
        chip(variable=self.status_ram)
        chip(variable=self.status_cpu)
        self._status_labels = status.winfo_children()
        status.bind("<Configure>", self._responsive_status, add="+")
        self.after_idle(self._responsive_status)


        # Keyboard-first navigation (Ctrl+1/2/3, Ctrl+, , Ctrl+Shift+P).
        # Ctrl+K is bound separately inside TopBar; Alt+Left/Right and
        # Esc are bound locally per-tab/per-dialog (see _build_tool_nav_bar
        # and the individual dialog modules) so they don't steal focus
        # from text fields.
        self._setup_keyboard_shortcuts()

        # Floating Apple-style Control Center (Ctrl+Shift+C)
        attach_control_center(self)
        try:
            a11y.bootstrap(self)
        except Exception:
            pass

        # System tray Live Activity (optional: needs pystray)
        try:
            start_tray(self)
        except Exception:
            pass

        # Duck Assistant - floating help button (see gui/duck_assistant.py).
        # Placed last so it floats above everything else in the window.
        self.duck_assistant = DuckAssistant(self, self.theme, host=self.ribbon._tabbar)
        if not db.get_setting("duck_assistant_enabled", True):
            self.duck_assistant.hide()
        mascot_enabled = bool(db.get_setting("duck_mascot_enabled", True))
        self.duck_mascot = DuckMascotWindow(self) if mascot_enabled else None
        self.ribbon.add_duck_toggle(mascot_enabled)
        self.notebook.bind(
            "<<NotebookTabChanged>>", self._on_notebook_tab_changed, add="+"
        )

        # RGB corner glows are built at the very start of this method (see
        # _build_rgb_accent() above), before the topbar / nav rail / status
        # bar exist - Tk stacks later-created siblings on top, so without
        # this, the topbar (full-width, top) and nav rail (full-height,
        # left) end up covering top_left, top_right, and bottom_left,
        # leaving only bottom_right visibly on top. Re-raise them now that
        # the rest of the chrome exists, so all 4 corners actually show.
        for w in getattr(self, "rgb_corners", []):
            tk.Misc.lift(w)

        # First-run welcome tour - shows once, ever, then never again unless
        # replayed from Settings. Delayed slightly so the main window is
        # fully drawn (and correctly positioned/sized) before centering it.
        if db.get_setting("boot_post_enabled", False):
            self.after(250, self._show_startup_post)
        self._startup_tour_job = self.after(
            600, self._maybe_show_onboarding_tour
        )

        # Aero Glass Effect - off by default, only applied if the user
        # already turned it on via Settings in a previous session.
        if db.get_setting("aero_glass_enabled", False):
            def _restore_aero():
                ok, _method = self.apply_aero_glass()
                if not ok:
                    db.set_setting("aero_glass_enabled", False)
                    self._aero_active = False
                    self._rebuild_chrome()
            self.after(300, _restore_aero)

        # Classic Blue window styling - same off-by-default pattern.
        if db.get_setting("xp_theme_enabled", False) and self.theme_id != "classic":
            self.after(300, lambda: xp_theme.apply(self))

        # Sidebar Gadgets - same off-by-default pattern.
        if db.get_setting("sidebar_gadgets_enabled", False):
            self.after(300, lambda: sidebar_gadgets.show(self))

        self._screensaver_window = None
        self._screensaver_active = False
        self._screensaver_job = None
        self.bind_all("<KeyPress>", self._screensaver_activity, add="+")
        self.bind_all("<Button>", self._screensaver_activity, add="+")
        self.bind_all("<Motion>", self._screensaver_activity, add="+")
        self.configure_idle_screensaver()
        self.after_idle(lambda: achievements.record_app_launch(self))

    def _responsive_status(self, _event=None):
        """Keep the bottom status rail readable on compact windows.

        HWID and total-tool count are useful diagnostics but are secondary
        to live CPU/RAM/tier state. Hide only those secondary chips below
        1160px; they remain available through the existing About/diagnostic
        surfaces.
        """
        try:
            width = self.winfo_width()
            children = list(getattr(self, "_status_labels", []))
            # Right-side chips were packed in this order: HWID, Tools, Tier,
            # RAM, CPU. The first two are safe to collapse.
            for idx in (1, 2):
                if idx >= len(children):
                    continue
                w = children[idx]
                if width < 1160:
                    w.pack_forget()
                elif not w.winfo_ismapped():
                    w.pack(side="right", padx=12)
        except tk.TclError:
            return

    def _tier_text(self):
        info = TIER_INFO[self.license.tier]
        return f"[{info['name']}]"

    def _welcome_tab(self):
        """The permanent first tab is now the live Fluent dashboard rather
        than a static welcome blurb."""
        # Rebuilds and defensive navigation calls can reach this method more
        # than once. Reuse the existing protected tab instead of creating a
        # second Dashboard tab.
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Dashboard":
                frame = self.notebook.nametowidget(tab_id)
                self._dashboard_frame = frame
                self.notebook.select(frame)
                return frame
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        self.dashboard = DashboardPage(frame, self)
        self.dashboard.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Dashboard")
        self._dashboard_frame = frame
        return frame

    def show_dashboard(self, force_rebuild=False):
        """Bring the dashboard tab forward (nav rail 'Dashboard' item).
        force_rebuild=True tears down and re-creates it even if already
        open - used by refresh_language() so dashboard section headers
        pick up a language change immediately rather than on next open."""
        frame = getattr(self, "_dashboard_frame", None)
        if force_rebuild and frame is not None and frame.winfo_exists():
            frame.destroy()
            frame = None
        if frame is None or not frame.winfo_exists():
            self._welcome_tab()
            frame = self._dashboard_frame
        self.notebook.select(frame)

    def open_health_center_tab(self):
        """Open the one-click read-only PC health scan."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Health Center":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = HealthCenterPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Health Center")
        self.notebook.select(frame)
        self.status_text.set("Opened: Health Center")

    def open_diagnostic_engine_tab(self):
        """Open the symptom-driven evidence workflow."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Diagnostic Engine":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = DiagnosticEnginePage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Diagnostic Engine")
        self.notebook.select(frame)
        self.status_text.set("Opened: Diagnostic Engine")

    def open_diagnostic_history_tab(self):
        """Open the persistent system and diagnostic timeline."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Diagnostic History":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = DiagnosticHistoryPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Diagnostic History")
        self.notebook.select(frame)
        self.status_text.set("Opened: Diagnostic History")

    def open_core_picker_window(self):
        """Open the TechDrive Core tool picker: a separate, closeable
        window (not a tab) listing bundled TechDrive Core modules for the
        user to pick from. Picking one opens it as a normal tab, same as
        clicking it directly in the sidebar."""
        show_core_picker(self)

    def open_report_generator_tab(self):
        """Open the technician-ready multi-format report builder."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Report Generator":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = ReportGeneratorPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Report Generator")
        self.notebook.select(frame)
        self.status_text.set("Opened: Report Generator")

    def open_repair_center_tab(self):
        """Open the controlled Preview -> Confirm -> Execute -> Verify flow."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Repair Center":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = RepairCenterPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Repair Center")
        self.notebook.select(frame)
        self.status_text.set("Opened: Repair Center")

    def open_troubleshooting_wizard_tab(self):
        """Open the read-only Internet Problems troubleshooting wizard."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Troubleshooting Wizard":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = TroubleshootingWizardPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Troubleshooting Wizard")
        self.notebook.select(frame)
        self.status_text.set("Opened: Troubleshooting Wizard")

    def open_performance_lab_tab(self):
        """Open the real Boot/CPU/GPU/RAM/Storage performance measurements."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Performance Lab":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = PerformanceLabPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Performance Lab")
        self.notebook.select(frame)
        self.status_text.set("Opened: Performance Lab")

    def open_hardware_inventory_tab(self):
        """Open the real Windows hardware inventory and export surface."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Hardware Inventory":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = HardwareInventoryPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Hardware Inventory")
        self.notebook.select(frame)
        self.status_text.set("Opened: Hardware Inventory")

    def open_network_lab_tab(self):
        """Open the unified read-only network status and diagnostics surface."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Network Lab":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = NetworkLabPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Network Lab")
        self.notebook.select(frame)
        self.status_text.set("Opened: Network Lab")

    def open_security_center_tab(self):
        """Open the defensive, read-only Windows security posture audit."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Security Center":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = SecurityCenterPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Security Center")
        self.notebook.select(frame)
        self.status_text.set("Opened: Security Center")

    def open_snapshot_manager_tab(self):
        """Open named TechDrive baselines and explicit Windows restore controls."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Snapshot Manager":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = SnapshotManagerPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Snapshot Manager")
        self.notebook.select(frame)
        self.status_text.set("Opened: Snapshot Manager")

    def open_technician_workspace_tab(self):
        """Open the local-only technician session and export workspace."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Technician Workspace":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = TechnicianWorkspacePage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Technician Workspace")
        self.notebook.select(frame)
        self.status_text.set("Opened: Technician Workspace")


    def open_explain_this_pc_tab(self):
        """Open the live, read-only human-readable system explanation."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Explain This PC":
                self.notebook.select(tab_id)
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        page = ExplainThisPCPage(frame, self)
        page.pack(fill="both", expand=True)
        self.notebook.add_closable(frame, text="Explain This PC")
        self.notebook.select(frame)
        self.status_text.set("Opened: Explain This PC")

    def open_event_log_analyzer_tab(self):
        """Open the real Windows Event Log analysis surface."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Event Log Analyzer":
                self.notebook.select(tab_id); return
        frame=tk.Frame(self.notebook,bg=self.theme["BG"]); page=EventLogAnalyzerPage(frame,self); page.pack(fill="both",expand=True)
        self.notebook.add_closable(frame,text="Event Log Analyzer"); self.notebook.select(frame); self.status_text.set("Opened: Event Log Analyzer")

    def open_baseline_monitor_tab(self):
        """Open the local baseline comparison surface."""
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "Baseline Monitor":
                self.notebook.select(tab_id); return
        frame=tk.Frame(self.notebook,bg=self.theme["BG"]); page=BaselineMonitorPage(frame,self); page.pack(fill="both",expand=True)
        self.notebook.add_closable(frame,text="Baseline Monitor"); self.notebook.select(frame); self.status_text.set("Opened: Baseline Monitor")

    def _on_notebook_tab_changed(self, _event=None):
        """Connect user navigation to Vault progress and Duck context hints."""
        try:
            selected = self.notebook.select()
            if not selected:
                return
            title = self.notebook._display_title(
                self.notebook.tab(selected, "text")
            )
        except (AttributeError, tk.TclError):
            return

        discovery_titles = {
            step_title for step_title, _ in VAULT_DISCOVERY_STEPS
        }
        if title in discovery_titles:
            progress = db.get_setting(VAULT_DISCOVERY_PROGRESS_KEY, [])
            if not isinstance(progress, (list, tuple, set)):
                progress = []
            if title not in progress:
                progress = list(progress) + [title]
                db.set_setting(VAULT_DISCOVERY_PROGRESS_KEY, progress)

            all_steps_seen = all(
                step_title in progress for step_title, _ in VAULT_DISCOVERY_STEPS
            )
            already_earned = bool(
                db.get_setting(CORE_EXPLORER_ACHIEVEMENT_KEY, False)
            )
            if all_steps_seen and not already_earned:
                db.set_setting(CORE_EXPLORER_ACHIEVEMENT_KEY, True)
                self.notify(
                    "Achievement unlocked",
                    "Core Explorer — you visited Hardware Inventory, Performance Lab, and Diagnostic Engine. Signal Sweep is now unlocked in the Vault.",
                    kind="success",
                )

            arcade = getattr(self, "_vault_arcade_page", None)
            if arcade is not None:
                try:
                    if arcade.winfo_exists():
                        arcade.refresh_progress()
                except (AttributeError, tk.TclError):
                    self._vault_arcade_page = None

        if title not in {"Dashboard", "Settings", "Welcome"}:
            mascot = getattr(self, "duck_mascot", None)
            if mascot is not None:
                try:
                    mascot.suggest_for_tool(title)
                except (AttributeError, tk.TclError):
                    pass

    def _show_startup_post(self):
        if not db.get_setting("boot_post_enabled", False):
            return
        if getattr(self, "_closing", False):
            return
        self._startup_post_active = True
        try:
            self._startup_post_window = BootPostWindow(
                self,
                on_close=self._startup_post_closed,
                cpu_name_provider=self.get_cpu_name,
            )
        except tk.TclError:
            self._startup_post_active = False
            self._startup_post_window = None

    def _startup_post_closed(self):
        self._startup_post_active = False
        self._startup_post_window = None

    def _maybe_show_onboarding_tour(self):
        if getattr(self, "_startup_post_active", False):
            self._startup_tour_job = self.after(
                500, self._maybe_show_onboarding_tour
            )
            return
        self._startup_tour_job = None
        if not onboarding_tour_v2.maybe_show(self):
            onboarding_tour.maybe_show(self)

    def open_techdrive_vault_tab(self):
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "TechDrive Vault":
                self.notebook.select(tab_id)
                arcade = getattr(self, "_vault_arcade_page", None)
                if arcade is not None:
                    try:
                        if arcade.winfo_exists():
                            arcade.refresh_progress()
                    except tk.TclError:
                        self._vault_arcade_page = None
                return
        frame = tk.Frame(self.notebook, bg=self.theme["BG"])
        vault_tabs = ttk.Notebook(frame)
        vault_tabs.pack(fill="both", expand=True)
        page = EasterEggVaultPage(vault_tabs, self)
        vault_tabs.add(page, text="Easter Eggs")
        self._vault_arcade_page = VaultArcadePage(vault_tabs, self)
        vault_tabs.add(self._vault_arcade_page, text="???")
        self._vault_arcade_page.refresh_progress()
        self.notebook.add_closable(frame,text="TechDrive Vault"); self.notebook.select(frame); self.status_text.set("Opened: TechDrive Vault")

    def open_techdrive_terminal_tab(self):
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "TechDrive Terminal":
                self.notebook.select(tab_id); return
        frame=tk.Frame(self.notebook,bg=self.theme["BG"]); page=TechDriveTerminalPage(frame,self); page.pack(fill="both",expand=True)
        self.notebook.add_closable(frame,text="TechDrive Terminal"); self.notebook.select(frame); self.status_text.set("Opened: TechDrive Terminal")

    def open_fix_my_pc_tab(self):
        for tab_id in self.notebook.tabs():
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == "FIX MY PC":
                self.notebook.select(tab_id); return
        frame=tk.Frame(self.notebook,bg=self.theme["BG"]); page=FixMyPCPage(frame,self); page.pack(fill="both",expand=True)
        self.notebook.add_closable(frame,text="FIX MY PC"); self.notebook.select(frame); self.status_text.set("Opened: FIX MY PC")

    def _on_tab_closed(self, tab_text):
        """Bookkeeping fired by ClosableNotebook right before a tab is
        actually removed - currently only Settings needs this, so a later
        open_settings_tab() knows to rebuild rather than assuming it's
        still open."""
        if self.notebook._display_title(tab_text) == "Settings":
            self._settings_tab_frame = None

    def open_notifications(self):
        """Open the Notification Center v2 (grouped cards + actions)."""
        try:
            return notif_center.open_notification_center(self)
        except Exception:
            pass
        # Fallback to legacy implementation
        existing = getattr(self, "_notifications_win", None)
        if existing is not None and existing.winfo_exists():
            self._render_notifications_list()
            existing.deiconify(); existing.lift(); existing.focus_force(); return existing
        win = tk.Toplevel(self); self._notifications_win = win
        win.title("TechDrive Notifications"); win.geometry("440x560"); win.minsize(380,420); win.configure(bg=self.theme["BG"]); win.transient(self)
        def close():
            try: win.destroy()
            finally: self._notifications_win = None
        win.protocol("WM_DELETE_WINDOW", close); win.bind("<Escape>", lambda _e: close())
        header=tk.Frame(win,bg=self.theme["BG"]); header.pack(fill="x",padx=20,pady=(18,10))
        tk.Label(header,text="NOTIFICATION CENTER",bg=self.theme["BG"],fg=self.theme["ACCENT_GLOW"],font=fl.F_TINY()).pack(anchor="w")
        title_row=tk.Frame(header,bg=self.theme["BG"]); title_row.pack(fill="x")
        tk.Label(title_row,text="Notifications",bg=self.theme["BG"],fg=self.theme["FG"],font=fl.F_TITLE()).pack(side="left")
        FluentButton(title_row,"CLEAR ALL",command=self._clear_all_notifications,theme=self.theme,aero=self.is_aero_enabled(),kind="standard",width=100,height=26,backdrop=self.theme["BG"]).pack(side="right")

        controls=tk.Frame(win,bg=self.theme["BG"]); controls.pack(fill="x",padx=20,pady=(0,6))
        self._notification_filter=tk.StringVar(value="All")
        for label in ("All", "Unread"):
            tk.Radiobutton(controls,text=label,variable=self._notification_filter,value=label,
                           command=self._render_notifications_list,bg=self.theme["BG"],fg=self.theme["FG"],
                           selectcolor=self.theme["CARD_BG"],activebackground=self.theme["BG"]).pack(side="left",padx=(0,8))
        self._notifications_body=tk.Frame(win,bg=self.theme["BG"]); self._notifications_body.pack(fill="both",expand=True,padx=20)
        self._render_notifications_list()

        recent=db.get_recent(5)
        if recent:
            activity=GlassCard(win,self.theme,aero=self.is_aero_enabled(),accent=self.theme["ACCENT"])
            activity.pack(fill="x",padx=20,pady=(0,4))
            tk.Label(activity.body,text="RECENTLY OPENED",bg=activity.fill,fg=self.theme["MUTED"],font=fl.F_TINY()).pack(anchor="w",padx=14,pady=(10,4))
            for category,tool,opened_at in recent:
                row=tk.Frame(activity.body,bg=activity.fill); row.pack(fill="x",padx=14,pady=2)
                tk.Label(row,text=tool,bg=activity.fill,fg=self.theme["FG"],font=fl.F_SMALL()).pack(side="left",fill="x",expand=True)
                tk.Label(row,text=category,bg=activity.fill,fg=self.theme["MUTED"],font=fl.F_TINY()).pack(side="right",pady=(0,8))

        FluentButton(win,"CLOSE",command=close,theme=self.theme,aero=self.is_aero_enabled(),kind="standard",width=90,height=32,backdrop=self.theme["BG"]).pack(anchor="e",padx=20,pady=16)

        # Opening the panel is the natural "seen it" moment, same as the OS
        # action center - clear the unread badge once the list has rendered.
        try:
            db.mark_all_notifications_read()
        except Exception:
            pass
        self._refresh_notification_badge()
        return win

    def _clear_all_notifications(self):
        try:
            db.clear_notifications()
        except Exception:
            pass
        self._render_notifications_list()
        self._refresh_notification_badge()

    def _render_notifications_list(self):
        body = getattr(self, "_notifications_body", None)
        if body is None or not body.winfo_exists():
            return
        for child in body.winfo_children():
            child.destroy()
        rows = db.get_notifications(50)
        if getattr(self, "_notification_filter", None) is not None and self._notification_filter.get() == "Unread":
            rows = [r for r in rows if not r.get("read")]
        if not rows:
            empty = GlassCard(body, self.theme, aero=self.is_aero_enabled(), accent=fl.GOOD)
            empty.pack(fill="x", pady=(0, 10))
            tk.Label(empty.body, text="✓  You're all caught up", bg=empty.fill,
                     fg=fl.GOOD, font=fl.F_BODY()).pack(anchor="w", padx=14, pady=(14, 4))
            tk.Label(empty.body, text="Nothing to report right now.", bg=empty.fill,
                     fg=self.theme["MUTED"], font=fl.F_SMALL()).pack(anchor="w", padx=14, pady=(0, 14))
            return
        icon_for = {"success": "✓", "warning": "⚠", "error": "✕", "info": "ℹ"}
        color_for = {"success": fl.GOOD, "warning": fl.WARN, "error": fl.BAD, "info": self.theme["ACCENT"]}
        # make_scrollable() already grids the canvas + scrollbar into `body`.
        # Do not pack the returned canvas again: mixing pack and grid in the
        # same parent raises TclError and used to make the Notification
        # Center fail before it could render any messages.
        _canvas, scroll_body = make_scrollable(body, self.theme["BG"])
        for row in rows:
            level = row["level"] if row["level"] in icon_for else "info"
            color = color_for[level]
            card = GlassCard(scroll_body, self.theme, aero=self.is_aero_enabled(), accent=color)
            card.pack(fill="x", pady=(0, 8))
            top = tk.Frame(card.body, bg=card.fill)
            top.pack(fill="x", padx=14, pady=(10, 2))
            tk.Label(top, text=icon_for[level], bg=card.fill, fg=color,
                     font=fl.F_BODY()).pack(side="left", padx=(0, 8))
            tk.Label(top, text=row["title"], bg=card.fill, fg=self.theme["FG"],
                     font=fl.F_SUBTITLE()).pack(side="left", fill="x", expand=True)
            tk.Label(top, text=_relative_time(row["created_at"]), bg=card.fill,
                     fg=self.theme["MUTED"], font=fl.F_TINY()).pack(side="right")
            if row["message"]:
                tk.Label(card.body, text=row["message"], bg=card.fill,
                         fg=self.theme["MUTED"], font=fl.F_SMALL(), wraplength=360,
                         justify="left", anchor="w").pack(anchor="w", padx=14, pady=(0, 8))
            actions=tk.Frame(card.body,bg=card.fill); actions.pack(fill="x",padx=14,pady=(0,10))
            if not row.get("read"):
                tk.Button(actions,text="Mark read",command=lambda nid=row["id"]: self._mark_notification_read(nid),
                          bg=card.fill,fg=self.theme["ACCENT"],relief="flat",bd=0).pack(side="left")
            tk.Button(actions,text="Delete",command=lambda nid=row["id"]: self._delete_notification(nid),
                      bg=card.fill,fg=self.theme["MUTED"],relief="flat",bd=0).pack(side="right")

    # ------------------------------------------------------------------
    # Tool dispatch
    # ------------------------------------------------------------------
    def open_mission_control_view(self):
        """Exposé-style overview of open tabs."""
        return open_mission_control(self)

    def open_stage_manager(self):
        """Open Stage Manager multi-panel workspace."""
        return open_stage_tab(self)

    def show_genius_tip(self, key="default", value=None):
        genius_tips.show_tip_dialog(self, key=key, value=value)

    def share_report(self, text="", file_path=None, title="Share report"):
        """Open the Share Sheet for a report or text summary."""
        try:
            haptics.sheet_open()
        except Exception:
            pass
        show_share_sheet(self, title=title, text=text, file_path=file_path)

    def open_tool(self, category, tool_name):
        method = TOOL_DISPATCH.get((category, tool_name))
        if method is None:
            method_name = "tool_" + slugify(tool_name)
            method = getattr(self, method_name, None)
        else:
            method = method.__get__(self, TechDriveApp)
        tab_title = tool_name
        # avoid duplicate tabs
        for tab_id in self.notebook.tabs():
            # ClosableNotebook appends a visible × to closable titles. Compare
            # normalized display titles so opening a tool again focuses the
            # existing tab instead of spawning duplicates.
            if self.notebook._display_title(self.notebook.tab(tab_id, "text")) == \
                    self.notebook._display_title(tab_title):
                self.notebook.select(tab_id)
                return
        frame = ttk.Frame(self.notebook)
        self.notebook.add_closable(frame, text=tab_title)
        self.notebook.select(frame)
        self._grow_window_for_tool()
        # Springy page entrance (Apple-style)
        try:
            self.after(30, lambda f=frame: page_enter(f, duration_ms=300, direction="up", distance=22))
        except Exception:
            pass
        self.status_text.set(f"Opened: {tool_name}")
        try:
            db.add_recent(category, tool_name)
        except Exception:
            pass  # recents tracking is best-effort, never blocks opening a tool

        try:
            prev = tool_resume.load_state(category, tool_name)
            if prev:
                self.after(400, lambda: self.show_toast(
                    "Continuing previous session", kind="info", duration=2000))
            tool_resume.save_state(category, tool_name, prev or {"opened": True})
        except Exception:
            pass
        try:
            haptics.click()
        except Exception:
            pass
        try:
            kind = "disk" if "disk" in (category or "").lower() or "disk" in (tool_name or "").lower() else "scan"
            if "network" in (category or "").lower():
                kind = "network"
            signal_probe(self, kind, 2.5)
        except Exception:
            pass

        # Every tool gets the same lightweight navigation shell.  This is
        # intentionally outside the individual tool implementations so even
        # legacy modules immediately gain Back/Previous/Next/Pinned controls
        # without having their diagnostic logic rewritten.
        tool_host = self._build_tool_navigation(frame, category, tool_name)
        if method:
            try:
                method(tool_host)
            except Exception as e:
                self._error_panel(tool_host, tool_name, e)
        else:
            self._error_panel(tool_host, tool_name, "Tool implementation missing.")
        try:
            self.after(350, lambda c=category, t=tool_name: show_tooltip_for_tool(self, c, t))
        except Exception:
            pass

    def _build_tool_navigation(self, frame, category, tool_name):
        """Build the shared navigation/action strip used by every tool tab.

        The actual tool receives a child host below this strip, so old tool
        implementations keep their existing geometry and do not need to
        know about the new navigation UI.
        """
        th = self.theme
        aero = self.is_aero_enabled()
        icon = "▣"
        for cat, cat_icon, tools in CATALOGUE:
            if cat == category:
                icon = cat_icon or icon
                break

        bar_bg = fl.glass(th, "SURFACE", aero, 0.10)
        bar = tk.Frame(frame, bg=bar_bg, highlightbackground=th["STROKE_SOFT"],
                       highlightthickness=1, height=52)
        bar.pack(side="top", fill="x", padx=10, pady=(10, 6))
        bar.pack_propagate(False)

        def nav_button(text, command, kind="subtle", width=78):
            return FluentButton(bar, text, command=command, theme=th, aero=aero,
                                kind=kind, width=width, height=28, backdrop=bar_bg)

        back = nav_button("← TOOLS", self.open_all_tools_tab, width=82)
        back.pack(side="left", padx=(7, 5), pady=8)

        def close_this_tool():
            try:
                self.notebook.close_tab(frame)
            except (tk.TclError, AttributeError):
                pass

        # Close lives in the always-visible strip, so a tool can always be
        # closed even when its own header is clipped in a narrow window.
        close_btn = nav_button("✕ CLOSE", close_this_tool, width=86)
        close_btn.pack(side="right", padx=(5, 7), pady=8)

        crumb = tk.Label(bar, text=f"{icon}  {category.upper()}  /  {tool_name.upper()}",
                         bg=bar_bg, fg=th["MUTED"], font=fl.font(8, "bold"), anchor="w")
        crumb.pack(side="left", fill="x", expand=True, padx=(4, 8))

        idx = self._tool_index(category, tool_name)
        total = len(self.flat_tools)

        def open_relative(delta):
            if idx is None or not total:
                return
            target = (idx + delta) % total
            target_category, _target_icon, target_tool = self.flat_tools[target]
            self.open_tool(target_category, target_tool)

        prev_btn = nav_button("‹ PREV", lambda: open_relative(-1), width=70)
        prev_btn.pack(side="left", padx=3, pady=8)
        next_btn = nav_button("NEXT ›", lambda: open_relative(1), width=70)
        next_btn.pack(side="left", padx=3, pady=8)

        # Keep the action strip usable on compact displays: the breadcrumb is
        # informational, while navigation actions must remain visible/clickable.
        def adapt_tool_nav(_event=None):
            try:
                compact = frame.winfo_width() < 820
                if compact:
                    crumb.pack_forget()
                    back.configure(text="← Tools")
                    prev_btn.configure(text="‹")
                    next_btn.configure(text="›")
                else:
                    if not crumb.winfo_manager():
                        crumb.pack(side="left", fill="x", expand=True, padx=(4, 8), before=prev_btn)
                    back.configure(text="← TOOLS")
                    prev_btn.configure(text="‹ PREV")
                    next_btn.configure(text="NEXT ›")
            except (tk.TclError, AttributeError):
                pass
        frame.bind("<Configure>", adapt_tool_nav, add="+")
        try:
            self.after_idle(adapt_tool_nav)
        except Exception:
            pass

        fav_state = False
        try:
            fav_state = db.is_favorite(category, tool_name)
        except Exception:
            pass

        def toggle_pin():
            nonlocal fav_state
            try:
                fav_state = db.toggle_favorite(category, tool_name)
                pin_btn.set_text("★ PINNED" if fav_state else "☆ PIN")
                self.status_text.set("Pinned: " + tool_name if fav_state else "Unpinned: " + tool_name)
                if getattr(self, "_all_tools_page", None):
                    self._all_tools_page._render()
            except Exception:
                pass

        pin_btn = nav_button("★ PINNED" if fav_state else "☆ PIN", toggle_pin, width=82)
        pin_btn.pack(side="left", padx=(5, 8), pady=8)

        # Keyboard navigation is local to the active tab, so it cannot steal
        # shortcuts from text fields or the global search box.
        frame.bind("<Alt-Left>", lambda _e: (self.open_all_tools_tab(), "break")[1])
        frame.bind("<Alt-Right>", lambda _e: (open_relative(1), "break")[1])
        frame.bind("<Control-Shift-Left>", lambda _e: (open_relative(-1), "break")[1])
        frame.bind("<Control-Shift-Right>", lambda _e: (open_relative(1), "break")[1])

        # Universal responsive tool viewport. Legacy tool implementations were
        # written with different assumptions about available height; putting
        # them directly in the tab clips longer panels on compact displays.
        # A single shared scroll container keeps every tool usable without
        # rewriting each of the 100 individual implementations.
        viewport = tk.Frame(frame, bg=th["BG"], bd=0, highlightthickness=0)
        viewport.pack(fill="both", expand=True, padx=0, pady=0)
        canvas = tk.Canvas(
            viewport, bg=th["BG"], bd=0, highlightthickness=0,
            relief="flat", yscrollincrement=24,
        )
        scrollbar = ttk.Scrollbar(viewport, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=th["BG"], bd=0, highlightthickness=0)
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _sync_scroll_region(_event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
                # Match the content width to the viewport so tool panels wrap
                # instead of forcing horizontal clipping.
                # Stretch the tool page to fill the whole tab, both width and
                # height. Without the height, every tool panel stayed at its
                # natural (small) size instead of using the available window.
                canvas.itemconfigure(
                    window_id,
                    width=max(1, canvas.winfo_width()),
                    height=max(canvas.winfo_height(), inner.winfo_reqheight()),
                )
                bbox = canvas.bbox("all")
                needs_scroll = bool(bbox and bbox[3] > canvas.winfo_height() + 2)
                if needs_scroll and not scrollbar.winfo_manager():
                    scrollbar.pack(side="right", fill="y")
                elif not needs_scroll and scrollbar.winfo_manager():
                    scrollbar.pack_forget()
            except tk.TclError:
                pass

        inner.bind("<Configure>", _sync_scroll_region, add="+")
        canvas.bind("<Configure>", _sync_scroll_region, add="+")
        # Mouse wheel support across Windows, macOS and Linux. Bind locally as
        # well as using the app-wide router, so the viewport works standalone.
        def _wheel(event):
            try:
                if getattr(event, "delta", 0):
                    canvas.yview_scroll(-1 * int(event.delta / 120), "units")
                elif getattr(event, "num", None) == 4:
                    canvas.yview_scroll(-3, "units")
                elif getattr(event, "num", None) == 5:
                    canvas.yview_scroll(3, "units")
            except tk.TclError:
                pass
            return "break"
        for widget in (canvas, inner):
            widget.bind("<MouseWheel>", _wheel, add="+")
            widget.bind("<Button-4>", _wheel, add="+")
            widget.bind("<Button-5>", _wheel, add="+")

        inner.pack_propagate(True)
        return inner

    def _grow_window_for_tool(self):
        """Tools open as a full tab inside the main window. If the window is
        small (or not already maximized), size it to fill the usable screen
        so the tool has room and never looks like a small floating panel.
        Windows that are already maximized are left alone."""
        try:
            if self.is_window_maximized() or self.state() == "zoomed":
                return
            area = self._monitor_work_area()
            if area is None:                      # non-Windows: native zoom
                self.state("zoomed")
                return
            _x, _y, aw, ah = area
            w, h = self.winfo_width(), self.winfo_height()
            if w < 0.9 * aw or h < 0.9 * ah:
                self.maximize_to_work_area()
        except (tk.TclError, AttributeError, ValueError):
            pass

    def _tool_index(self, category, tool_name):
        for i, (c, icon, t) in enumerate(self.flat_tools):
            if c == category and t == tool_name:
                return i
        return None

    def _error_panel(self, frame, tool_name, err):
        """Show tool failures as a calm, actionable diagnostic panel."""
        bg = self.theme["BG"]
        wrap = tk.Frame(frame, bg=bg)
        wrap.pack(fill="both", expand=True, padx=22, pady=22)
        card_bg = fl.glass(self.theme, "CARD_BG", self.is_aero_enabled())
        card = tk.Frame(wrap, bg=card_bg, highlightbackground=self.theme["STROKE"], highlightthickness=1)
        card.pack(fill="x", anchor="n")
        tk.Label(card, text="TOOL COULD NOT START", bg=card_bg, fg=fl.WARN, font=fl.F_SUBTITLE()).pack(anchor="w", padx=18, pady=(16, 4))
        tk.Label(card, text=tool_name, bg=card_bg, fg=self.theme["FG"], font=fl.F_CARD_TITLE()).pack(anchor="w", padx=18)
        tk.Label(card, text="TechDrive caught the error and kept the rest of the app running.", bg=card_bg, fg=self.theme["MUTED"], font=fl.F_SMALL(), wraplength=680, justify="left").pack(anchor="w", padx=18, pady=(4, 12))
        details = tk.Text(card, height=5, bg=fl.mix(card_bg, self.theme["FG"], 0.04), fg=self.theme["FG"], insertbackground=self.theme["FG"], relief="flat", bd=0, font=("Consolas", 9), wrap="word")
        details.pack(fill="x", padx=18, pady=(0, 12))
        details.insert("1.0", str(err)); details.configure(state="disabled")
        full_report = f"TechDrive tool error\nTool: {tool_name}\nError: {err}\n"
        if isinstance(err, self._BgError) and err.traceback_text:
            full_report += "\nTraceback:\n" + err.traceback_text
        actions = tk.Frame(card, bg=card_bg); actions.pack(fill="x", padx=18, pady=(0, 16))
        FluentButton(actions, "RETRY", theme=self.theme, aero=self.is_aero_enabled(), kind="accent", width=92, height=32, backdrop=card_bg, command=lambda: self.open_tool(self._tool_category_for_name(tool_name), tool_name)).pack(side="left")
        FluentButton(actions, "COPY REPORT", theme=self.theme, aero=self.is_aero_enabled(), kind="subtle", width=118, height=32, backdrop=card_bg, command=lambda: self._copy_to_clipboard(full_report)).pack(side="left", padx=8)
        FluentButton(actions, "OPEN LOG FOLDER", theme=self.theme, aero=self.is_aero_enabled(), kind="subtle", width=132, height=32, backdrop=card_bg, command=self._open_log_folder).pack(side="left")
        tk.Label(actions, text="The detailed traceback is kept in TechDrive's local log.", bg=card_bg, fg=self.theme["MUTED"], font=fl.F_TINY()).pack(side="left", padx=8)

    def _open_log_folder(self):
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
        path = os.path.join(base, "TechDrive", "logs")
        try:
            os.makedirs(path, exist_ok=True)
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            self.show_toast("Could not open the log folder", kind="error")

    def _copy_to_clipboard(self, text):
        try:
            self.clipboard_clear(); self.clipboard_append(text); self.update()
            self.show_toast("Error copied to clipboard", kind="success")
        except tk.TclError:
            self.show_toast("Could not access the clipboard", kind="error")

    def _tool_category_for_name(self, tool_name):
        for category, _icon, tools in CATALOGUE:
            if tool_name in tools:
                return category
        return "System"

    # ------------------------------------------------------------------
    # Shared widget helpers used by many tool panels
    # ------------------------------------------------------------------
    def _panel_header(self, frame, title, subtitle="", status="Ready"):
        """Shared header for every tool panel - old and new alike, since
        every legacy tool already calls this one method. Renders the same
        title / description / status structure as the newer CardPanel-based
        tools, so switching between an old tool and a new one no longer
        feels like switching apps.

        Returns a small controller with .set_status(text, kind) so any
        tool that wants to reflect "Running…"/"Error" can opt in; tools
        that ignore the return value (nearly all of them) simply keep the
        default "Ready" status, which is still a big step up from the old
        plain ttk label.
        """
        th = self.theme
        aero = self.is_aero_enabled()
        wrap = tk.Frame(frame, bg=th["BG"])
        wrap.pack(fill="x", anchor="n")

        tk.Label(
            wrap, text=title, bg=th["BG"], fg=fl.glow_color(th, aero),
            font=fl.F_TITLE(), anchor="w", justify="left",
        ).pack(fill="x", padx=16, pady=(14, 2), anchor="w")

        if subtitle:
            tk.Label(
                wrap, text=subtitle, bg=th["BG"], fg=th["MUTED"],
                font=fl.F_SMALL(), anchor="w", justify="left", wraplength=760,
            ).pack(fill="x", padx=16, anchor="w")

        status_row = tk.Frame(wrap, bg=th["BG"])
        status_row.pack(fill="x", padx=16, pady=(10, 0), anchor="w")
        tk.Label(
            status_row, text="STATUS", bg=th["BG"], fg=th["MUTED"],
            font=fl.font(8, "bold"),
        ).pack(side="left")
        dot = tk.Label(status_row, text="●", bg=th["BG"], font=fl.font(10))
        dot.pack(side="left", padx=(9, 4))
        status_lbl = tk.Label(
            status_row, text=status, bg=th["BG"], fg=th["FG"], font=fl.F_SMALL(),
        )
        status_lbl.pack(side="left")

        tk.Frame(wrap, bg=th["STROKE"], height=1).pack(
            fill="x", padx=16, pady=(10, 8),
        )

        controller = self._ToolStatus(dot, status_lbl, th)
        controller.set_status(status)
        frame._td_status = controller
        return controller

    class _ToolStatus:
        """Tiny opt-in status API returned by _panel_header."""
        _COLORS = {
            "ready": None,        # resolved against theme's ACCENT_GLOW
            "busy": fl.WARN,
            "error": "#ff5c5c",
            "done": None,
        }

        def __init__(self, dot, label, theme):
            self._dot = dot
            self._label = label
            self._theme = theme

        def set_status(self, text, kind="ready"):
            color = self._COLORS.get(kind) or self._theme["ACCENT_GLOW"]
            try:
                self._dot.config(fg=color)
                self._label.config(text=text)
            except tk.TclError:
                pass  # tab was closed mid-update

    def _button_row(self, frame, buttons):
        """Themed action-button strip (e.g. [ Scan ] [ Export Report ])
        shared by every legacy tool - upgraded from plain tk.Button so old
        tools' actions match the Fluent styling used everywhere else."""
        th = self.theme
        aero = self.is_aero_enabled()
        row = tk.Frame(frame, bg=th["BG"])
        row.pack(anchor="w", fill="x", padx=16, pady=(4, 10))
        for index, (text, cmd) in enumerate(buttons):
            FluentButton(
                row, text, command=cmd, theme=th, aero=aero,
                kind="accent" if index == 0 else "standard",
                height=32, backdrop=row["bg"],
            ).pack(side="left", padx=(0, 8))
        return row

    def _text_output(self, frame, height=22):
        box = tk.Text(frame, bg=SURFACE, fg=TEXT_FG, insertbackground="white",
                       font=FONT_MONO, height=height, wrap="word")
        box.pack(fill="both", expand=True, padx=16, pady=10)
        return box

    def _text_input(self, frame, height=8):
        """Editable text box for tools that need user-supplied input
        (JSON/XML/RegEx/Base64/Hash/URL tools)."""
        ttk.Label(frame, text="Input:", foreground="#9aa0a6").pack(anchor="w", padx=16)
        box = tk.Text(frame, bg=SURFACE, fg=TEXT_FG, insertbackground="white",
                       font=FONT_MONO, height=height, wrap="word")
        box.pack(fill="both", expand=False, padx=16, pady=(2, 8))
        return box

    def _entry_row(self, frame, label, default=""):
        row = ttk.Frame(frame)
        row.pack(fill="x", padx=16, pady=2)
        ttk.Label(row, text=label, width=32).pack(side="left")
        var = tk.StringVar(value=default)
        tk.Entry(row, textvariable=var, bg=SURFACE, fg=TEXT_FG, insertbackground=TEXT_FG,
                  relief="flat", font=("Consolas", 10)).pack(side="left", fill="x", expand=True)
        return var

    class _BgError:
        """Wraps an exception from a background gather() call so redraw()
        callbacks can tell 'real data' apart from 'something went wrong' -
        a bare string was ambiguous (e.g. RAM info's data is normally a
        dict, but if gather() raised, the old code silently handed redraw()
        a string instead, which then blew up trying to do data["total"])."""
        def __init__(self, message, traceback_text=""):
            self.message = message
            self.traceback_text = traceback_text

        def __str__(self):
            return self.message

    def _run_bg(self, fn, on_done):
        """Run fn() off the Tk thread and deliver its result safely.

        Worker exceptions are converted to _BgError. UI callback exceptions
        are also contained and surfaced as a toast, so a malformed redraw
        cannot take down the Tk callback loop. Pending poll jobs are tracked
        and cancelled during shutdown.
        """
        q = queue.Queue()

        def worker():
            try:
                result = fn()
            except Exception as e:
                logger.exception("Background tool failed")
                sounds.play("error")
                result = self._BgError(
                    f"{type(e).__name__}: {e}",
                    traceback.format_exc(),
                )
                self._last_error_category = type(e).__name__
            q.put(result)

        threading.Thread(target=worker, daemon=True, name="TechDriveWorker").start()

        job_ref = [None]
        def poll():
            job = job_ref[0]
            if job is not None:
                self._bg_poll_jobs.discard(job)
            if getattr(self, "_closing", False):
                return
            try:
                if not self.winfo_exists():
                    return
            except tk.TclError:
                return
            try:
                result = q.get_nowait()
            except queue.Empty:
                try:
                    job_ref[0] = self.after(100, poll)
                    self._bg_poll_jobs.add(job_ref[0])
                except tk.TclError:
                    return
                return
            try:
                on_done(result)
            except Exception as e:
                logger.exception("GUI redraw callback failed")
                sounds.play("error")
                self._last_error_category = type(e).__name__
                try:
                    self.show_toast(f"Tool display error: {type(e).__name__}", kind="error")
                except Exception:
                    pass

        try:
            job_ref[0] = self.after(100, poll)
            self._bg_poll_jobs.add(job_ref[0])
        except tk.TclError:
            return

    # ==================================================================
    # CATEGORY 1: SYSTEM INFO
    # ==================================================================
    def tool_cpu_info(self, frame):
        def gather():
            data = {
                "model": platform.processor() or "Unknown",
                "arch": platform.machine(),
                "platform": platform.platform(),
                "phys": "N/A",
                "logical": "N/A",
                "freq": None,
                "usage": None,
            }
            if psutil:
                try:
                    data["phys"] = psutil.cpu_count(logical=False)
                    data["logical"] = psutil.cpu_count(logical=True)
                except Exception:
                    pass
                try:
                    freq = psutil.cpu_freq()
                    if freq:
                        data["freq"] = f"{freq.current / 1000:.2f} GHz"
                except Exception:
                    pass
                try:
                    data["usage"] = psutil.cpu_percent(interval=0.3)
                except Exception:
                    pass
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read CPU info: {data}")
                return
            panel.stat("Model", data["model"])
            panel.stat("Architecture", data["arch"])
            panel.stat("Cores", f"{data['phys']} Physical / {data['logical']} Logical")
            panel.stat("Frequency", data["freq"] or "N/A")
            if data["usage"] is not None:
                panel.progress("Usage", data["usage"])
            else:
                panel.empty_state("Live usage unavailable on this system.")

        panel = CardPanel(frame, self.theme, "CPU Info", "Static and live CPU details",
                           icon="▣", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def _set_text(self, box, text):
        box.delete("1.0", "end")
        box.insert("end", text)

    def tool_ram_info(self, frame):
        def gather():
            if not psutil:
                return None
            vm = psutil.virtual_memory()
            data = {
                "total": bytes_fmt(vm.total), "available": bytes_fmt(vm.available),
                "used": bytes_fmt(vm.used), "free": bytes_fmt(vm.free), "percent": vm.percent,
                "swap_total": None, "swap_used": None, "swap_pct": None,
            }
            try:
                sm = psutil.swap_memory()
                data["swap_total"] = bytes_fmt(sm.total)
                data["swap_used"] = bytes_fmt(sm.used)
                data["swap_pct"] = sm.percent
            except Exception:
                pass  # swap info can be unavailable/restricted on some systems
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read RAM info: {data}")
                return
            if data is None:
                panel.empty_state("psutil not installed.")
                return
            panel.stat("Total RAM", data["total"])
            panel.stat("Available", data["available"])
            panel.stat("Free", data["free"])
            panel.progress("Used", data["percent"])
            if data["swap_total"] is not None:
                swap = panel.card("Swap")
                panel.stat("Swap Total", data["swap_total"], container=swap)
                panel.progress("Swap Used", data["swap_pct"], container=swap)
            else:
                panel.card("Swap")
                panel.empty_state("Swap info unavailable on this system.")

        panel = CardPanel(frame, self.theme, "RAM Info", "Installed and available memory",
                           icon="▣", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_disk_info(self, frame):
        def gather():
            if not psutil:
                return None
            parts = []
            for part in psutil.disk_partitions(all=False):
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    parts.append({
                        "device": part.device, "mount": part.mountpoint, "fstype": part.fstype,
                        "total": bytes_fmt(usage.total), "used": bytes_fmt(usage.used),
                        "free": bytes_fmt(usage.free), "percent": usage.percent,
                    })
                except (PermissionError, OSError) as e:
                    # OSError covers e.g. an empty CD/DVD drive on Windows,
                    # not just permission issues.
                    parts.append({"device": part.device, "error": str(e) or "Unavailable"})
            return parts

        def redraw(parts):
            panel.clear()
            if isinstance(parts, self._BgError):
                panel.empty_state(f"Could not read disk info: {parts}")
                return
            if parts is None:
                panel.empty_state("psutil not installed.")
                return
            if not parts:
                panel.empty_state("No partitions found.")
                return
            for p in parts:
                section = panel.card(f"{p['device']}  ({p.get('mount', '')})")
                if "error" in p:
                    panel.stat("Status", p["error"], status="bad", container=section)
                    continue
                panel.stat("Filesystem", p["fstype"], container=section)
                panel.stat("Total", p["total"], container=section)
                panel.stat("Free", p["free"], container=section)
                panel.progress("Used", p["percent"], container=section)

        panel = CardPanel(frame, self.theme, "Disk Info", "All mounted partitions",
                           icon="▤", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_gpu_info(self, frame):
        self._panel_header(frame, "▦ GPU Info", "Graphics adapter details")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_VideoController get Name,AdapterRAM,DriverVersion /format:list")
                if ok and out.strip():
                    return out
            ok, out = run_cmd("lspci | grep -i vga") if not IS_WINDOWS else (False, "")
            if ok and out:
                return out
            return "GPU details require Windows (wmic) or Linux (lspci)."

        self._button_row(frame, [("Refresh", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])
        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_os_info(self, frame):
        self._panel_header(frame, "▣ OS Info")
        box = self._text_output(frame)
        info = (f"System: {platform.system()}\n"
                f"Release: {platform.release()}\n"
                f"Version: {platform.version()}\n"
                f"Node name: {platform.node()}\n"
                f"Python: {platform.python_version()}\n"
                f"Boot time: {datetime.fromtimestamp(psutil.boot_time()) if psutil else 'N/A'}")
        self._set_text(box, info)

    def tool_bios_info(self, frame):
        self._panel_header(frame, "▤ BIOS Info")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic bios get Manufacturer,SMBIOSBIOSVersion,ReleaseDate /format:list")
                return out if ok else "Could not query BIOS info."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_motherboard_info(self, frame):
        self._panel_header(frame, "⌁ Motherboard Info")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic baseboard get Manufacturer,Product,Version,SerialNumber /format:list")
                return out if ok else "Could not query motherboard info."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_battery_info(self, frame):
        self._panel_header(frame, "▰ Battery Info")
        box = self._text_output(frame)

        def gather():
            if not psutil or not hasattr(psutil, "sensors_battery"):
                return "Battery sensors not available."
            batt = psutil.sensors_battery()
            if not batt:
                return "No battery detected (desktop system)."
            mins = batt.secsleft // 60 if batt.secsleft and batt.secsleft > 0 else None
            return (f"Charge: {batt.percent}%\n"
                    f"Plugged in: {batt.power_plugged}\n"
                    f"Time remaining: {f'{mins} min' if mins else 'N/A'}")

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_network_info(self, frame):
        self._panel_header(frame, "◎ Network Info")
        box = self._text_output(frame)

        def gather():
            lines = []
            hostname = socket.gethostname()
            lines.append(f"Hostname: {hostname}")
            try:
                lines.append(f"Local IP: {socket.gethostbyname(hostname)}")
            except Exception:
                pass
            if psutil:
                for name, addrs in psutil.net_if_addrs().items():
                    lines.append(f"\nInterface: {name}")
                    for a in addrs:
                        lines.append(f"   {a.family.name if hasattr(a.family, 'name') else a.family}: {a.address}")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_monitor_info(self, frame):
        self._panel_header(frame, "▣ Monitor Info")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic desktopmonitor get Name,ScreenHeight,ScreenWidth /format:list")
                return out if ok else "Could not query monitor info."
            w, h = self.winfo_screenwidth(), self.winfo_screenheight()
            return f"Detected display resolution: {w}x{h} (limited info on non-Windows)."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 2: DISK MANAGEMENT
    # ==================================================================
    def tool_disk_cleanup(self, frame):
        self._panel_header(frame, "⌁ Disk Cleanup", "Scans and clears temp files")
        box = self._text_output(frame)
        targets = []
        if IS_WINDOWS:
            targets = [os.environ.get("TEMP", ""), os.environ.get("TMP", ""),
                       os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Temp")]
        else:
            targets = ["/tmp"]

        def scan():
            total = 0
            details = []
            for t in targets:
                if t and os.path.isdir(t):
                    size = 0
                    count = 0
                    for root, dirs, files in os.walk(t):
                        for f in files:
                            try:
                                size += os.path.getsize(os.path.join(root, f))
                                count += 1
                            except OSError:
                                pass
                    details.append(f"{t}: {count} files, {bytes_fmt(size)}")
                    total += size
            details.append(f"\nTOTAL reclaimable: {bytes_fmt(total)}")
            return "\n".join(details)

        def clean():
            freed = 0
            errors = 0
            for t in targets:
                if t and os.path.isdir(t):
                    for root, dirs, files in os.walk(t, topdown=False):
                        for f in files:
                            fp = os.path.join(root, f)
                            try:
                                freed += os.path.getsize(fp)
                                os.remove(fp)
                            except OSError:
                                errors += 1
            return f"Cleanup complete. Freed approx {bytes_fmt(freed)}. Skipped {errors} locked files."

        self._button_row(frame, [
            ("Scan", lambda: self._run_bg(scan, lambda r: self._set_text(box, r))),
            ("Clean Now", lambda: self._confirm_then(
                "This will permanently delete temp files. Continue?",
                lambda: self._run_bg(clean, lambda r: self._set_text(box, r)))),
        ])

    def _confirm_then(self, msg, action):
        if messagebox.askyesno("Confirm", msg):
            action()

    def tool_disk_defragmenter(self, frame):
        self._panel_header(frame, "◇ Disk Defragmenter", "Analyzes/defrags HDD volumes (no-op on SSD)")
        box = self._text_output(frame)
        drive_var = tk.StringVar(value="C:")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=drive_var, width=6).pack(side="left")

        def analyze():
            if not IS_WINDOWS:
                return windows_only_notice()
            d = drive_var.get().strip()
            if not re.match(r"^[A-Za-z]:$", d):
                return "Enter a drive letter like C: (e.g. 'C:')."
            ok, out = run_cmd_argv(["defrag", d, "/A", "/V"], timeout=60)
            return out if ok else "Analysis failed (needs admin rights)."

        def run_defrag():
            if not IS_WINDOWS:
                return windows_only_notice()
            d = drive_var.get().strip()
            if not re.match(r"^[A-Za-z]:$", d):
                return "Enter a drive letter like C: (e.g. 'C:')."
            ok, out = run_cmd_argv(["defrag", d, "/O"], timeout=600)
            return out if ok else "Defrag failed (needs admin rights)."

        self._button_row(frame, [
            ("Analyze", lambda: self._run_bg(analyze, lambda r: self._set_text(box, r))),
            ("Optimize", lambda: self._run_bg(run_defrag, lambda r: self._set_text(box, r))),
        ])

    def tool_disk_health_check(self, frame):
        # Rebuilt as a "tool workspace" (Overview / Drives / SMART /
        # History tabs) instead of a single WMIC text dump - see
        # gui/workspace_panel.py and gui/disk_health_workspace.py.
        from gui.disk_health_workspace import build as build_disk_health_workspace
        build_disk_health_workspace(frame, self.theme, self.is_aero_enabled(), self._run_bg)

    def tool_partition_manager(self, frame):
        self._panel_header(frame, "▤ Partition Manager", "Lists partitions (list-only for safety)")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('echo list disk | diskpart')
                return out if ok else "Requires Administrator privileges."
            if psutil:
                return "\n".join(f"{p.device} -> {p.mountpoint} [{p.fstype}]"
                                  for p in psutil.disk_partitions())
            return "No partition data available."

        ttk.Label(frame, text="Note: destructive partition edits are not automated here — "
                               "use Windows Disk Management for changes.", foreground="#e0a030",
                  wraplength=600).pack(anchor="w", padx=16)
        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_secure_erase(self, frame):
        self._panel_header(frame, "△ Secure Erase", "Overwrites a chosen FILE beyond recovery (not whole disks)")
        box = self._text_output(frame)
        path_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=60).pack(side="left", padx=(0, 8))
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askopenfilename() or path_var.get())).pack(side="left")

        def erase():
            p = path_var.get()
            if not p or not os.path.isfile(p):
                return "Select a valid file first."
            try:
                size = os.path.getsize(p)
                with open(p, "r+b") as f:
                    for _ in range(3):
                        f.seek(0)
                        f.write(os.urandom(size))
                        f.flush()
                        os.fsync(f.fileno())
                os.remove(p)
                return f"Securely erased and deleted: {p} (3-pass random overwrite)"
            except Exception as e:
                return f"Error: {e}"

        self._button_row(frame, [("Secure Erase File", lambda: self._confirm_then(
            "This permanently destroys the file's contents. Continue?",
            lambda: self._run_bg(erase, lambda r: self._set_text(box, r))))])

    def tool_disk_clone(self, frame):
        self._panel_header(frame, "▥ Disk Clone", "Byte-for-byte clone of a FOLDER/volume to a target folder")
        box = self._text_output(frame)
        src_var, dst_var = tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x", pady=2)
        ttk.Label(row, text="Source:").pack(side="left")
        ttk.Entry(row, textvariable=src_var, width=40).pack(side="left", padx=6)
        tk.Button(row, text="Browse", command=lambda: src_var.set(
            filedialog.askdirectory() or src_var.get())).pack(side="left")
        row2 = ttk.Frame(frame)
        row2.pack(anchor="w", padx=16, fill="x", pady=2)
        ttk.Label(row2, text="Target:").pack(side="left")
        ttk.Entry(row2, textvariable=dst_var, width=40).pack(side="left", padx=6)
        tk.Button(row2, text="Browse", command=lambda: dst_var.set(
            filedialog.askdirectory() or dst_var.get())).pack(side="left")

        def clone():
            s, d = src_var.get(), dst_var.get()
            if not os.path.isdir(s) or not d:
                return "Choose a valid source folder and target path."
            try:
                dest = os.path.join(d, os.path.basename(s.rstrip("/\\")) + "_clone")
                shutil.copytree(s, dest, dirs_exist_ok=True)
                return f"Clone complete -> {dest}"
            except Exception as e:
                return f"Error: {e}"

        self._button_row(frame, [("Start Clone", lambda: self._run_bg(clone, lambda r: self._set_text(box, r)))])

    def tool_disk_benchmark(self, frame):
        self._panel_header(frame, "⏱ Disk Benchmark", "Sequential read/write speed test")
        box = self._text_output(frame)

        def bench():
            test_dir = os.path.join(os.getcwd(), ".techdrive_bench")
            os.makedirs(test_dir, exist_ok=True)
            fpath = os.path.join(test_dir, "bench.tmp")
            data = os.urandom(1024 * 1024)  # 1MB chunk
            chunks = 64  # 64MB
            start = time.time()
            with open(fpath, "wb") as f:
                for _ in range(chunks):
                    f.write(data)
                f.flush()
                os.fsync(f.fileno())
            write_time = time.time() - start
            write_speed = (chunks) / write_time if write_time else 0

            start = time.time()
            with open(fpath, "rb") as f:
                while f.read(1024 * 1024):
                    pass
            read_time = time.time() - start
            read_speed = (chunks) / read_time if read_time else 0

            os.remove(fpath)
            shutil.rmtree(test_dir, ignore_errors=True)
            return (f"Write speed: {write_speed:.1f} MB/s\n"
                    f"Read speed: {read_speed:.1f} MB/s\n"
                    f"(64MB test file, sequential)")

        self._button_row(frame, [("Run Benchmark", lambda: self._run_bg(bench, lambda r: self._set_text(box, r)))])

    def tool_space_analyzer(self, frame):
        self._panel_header(frame, "▥ Space Analyzer", "Largest folders under a chosen path")
        box = self._text_output(frame)
        path_var = tk.StringVar(value=os.path.expanduser("~"))
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=50).pack(side="left", padx=(0, 8))
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left")

        def analyze():
            root = path_var.get()
            sizes = {}
            for entry in os.scandir(root):
                if entry.is_dir(follow_symlinks=False):
                    total = 0
                    for r, d, files in os.walk(entry.path):
                        for f in files:
                            try:
                                total += os.path.getsize(os.path.join(r, f))
                            except OSError:
                                pass
                    sizes[entry.path] = total
            ranked = sorted(sizes.items(), key=lambda x: -x[1])[:20]
            return "\n".join(f"{bytes_fmt(sz):>12}   {p}" for p, sz in ranked) or "No subfolders found."

        self._button_row(frame, [("Analyze", lambda: self._run_bg(analyze, lambda r: self._set_text(box, r)))])

    def tool_file_explorer(self, frame):
        self._build_file_explorer(frame)

    def _build_file_explorer(self, frame):
        self._panel_header(frame, "□ File Explorer")
        path_var = tk.StringVar(value=os.path.expanduser("~"))
        row = ttk.Frame(frame)
        row.pack(anchor="w", fill="x", padx=16)
        ttk.Entry(row, textvariable=path_var, width=60).pack(side="left", padx=(0, 8))
        listbox = tk.Listbox(frame, bg=SURFACE, fg=FG, font=FONT_MONO, height=22)
        listbox.pack(fill="both", expand=True, padx=16, pady=10)

        def refresh():
            listbox.delete(0, "end")
            p = path_var.get()
            try:
                listbox.insert("end", "□ ..")
                for entry in sorted(os.scandir(p), key=lambda e: (not e.is_dir(), e.name.lower())):
                    icon = "□" if entry.is_dir() else "▤"
                    size = "" if entry.is_dir() else f"  ({bytes_fmt(entry.stat().st_size)})"
                    listbox.insert("end", f"{icon} {entry.name}{size}")
            except Exception as e:
                listbox.insert("end", f"Error: {e}")

        def on_double(event):
            sel = listbox.curselection()
            if not sel:
                return
            text = listbox.get(sel[0])
            name = text.split(" ", 1)[1].split("  (")[0]
            if name == "..":
                path_var.set(os.path.dirname(path_var.get().rstrip("/\\")) or path_var.get())
            else:
                newp = os.path.join(path_var.get(), name)
                if os.path.isdir(newp):
                    path_var.set(newp)
            refresh()

        listbox.bind("<Double-Button-1>", on_double)
        self._button_row(frame, [("Go", refresh), ("Browse...", lambda: (
            path_var.set(filedialog.askdirectory() or path_var.get()), refresh()))])
        refresh()

    def tool_format_tool(self, frame):
        self._panel_header(frame, "⌁ Format Tool", "Formats a REMOVABLE drive letter (Windows only)")
        box = self._text_output(frame)
        drive_var = tk.StringVar(value="E:")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Label(row, text="Drive:").pack(side="left")
        ttk.Entry(row, textvariable=drive_var, width=6).pack(side="left", padx=6)

        def do_format():
            if not IS_WINDOWS:
                return windows_only_notice()
            d = drive_var.get().strip().rstrip("\\")
            if not re.match(r"^[D-Zd-z]:$", d):
                return "Refusing to format system-adjacent drives. Use a drive letter D: or higher."
            ok, out = run_cmd_argv(["format", d, "/FS:NTFS", "/Q", "/Y"], timeout=120)
            return out if ok else "Format failed (needs admin rights, and confirmation input)."

        self._button_row(frame, [("Format Drive", lambda: self._confirm_then(
            f"This will ERASE ALL DATA on {drive_var.get()}. Continue?",
            lambda: self._run_bg(do_format, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 3: DATA RECOVERY
    # (implemented as a common undelete-scan engine using filesystem +
    #  recycle-bin scanning; deep/raw carving works file-type by
    #  signature scanning across a chosen drive)
    # ==================================================================
    def _recovery_panel(self, frame, title, extensions, subtitle):
        self._panel_header(frame, title, subtitle)
        box = self._text_output(frame)
        path_var = tk.StringVar(value="C:\\" if IS_WINDOWS else "/")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Label(row, text="Scan location:").pack(side="left")
        ttk.Entry(row, textvariable=path_var, width=40).pack(side="left", padx=6)
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left")

        def scan():
            found = []
            recycle_paths = []
            if IS_WINDOWS:
                recycle_paths = [os.path.join(path_var.get(), "$Recycle.Bin")]
            else:
                recycle_paths = [os.path.expanduser("~/.local/share/Trash")]
            for rp in recycle_paths:
                if os.path.isdir(rp):
                    for root, dirs, files in os.walk(rp):
                        for f in files:
                            if not extensions or os.path.splitext(f)[1].lower() in extensions:
                                found.append(os.path.join(root, f))
            return (f"Recoverable-candidate scan complete.\n"
                    f"Checked recycle/trash locations under: {path_var.get()}\n"
                    f"Candidates found: {len(found)}\n\n" + "\n".join(found[:200]) +
                    ("\n... (truncated)" if len(found) > 200 else "") +
                    "\n\nTip: for permanently deleted (non-recycled) files, run 'Deep Scan Recovery' "
                    "which performs raw signature scanning of free space.")

        self._button_row(frame, [("Scan", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_recover_deleted_files(self, frame):
        self._recovery_panel(frame, "⌫ Recover Deleted Files", None,
                              "Scans Recycle Bin / Trash for recoverable items")

    def tool_recover_formatted_drive(self, frame):
        self._panel_header(frame, "▤ Recover Formatted Drive", "Raw signature scan of a drive root")
        box = self._text_output(frame)
        path_var = tk.StringVar(value="D:\\" if IS_WINDOWS else "/mnt")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=path_var, width=30).pack(side="left")

        def scan():
            root = path_var.get()
            if not os.path.isdir(root):
                return "Path not accessible. Note: recovering a truly formatted volume " \
                       "requires raw sector access (admin) — this scans what the OS can still see."
            count = sum(len(files) for _, _, files in os.walk(root))
            return f"{count} files currently visible under {root}.\nFor deeper recovery use 'Deep Scan Recovery'."

        self._button_row(frame, [("Scan", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_recover_lost_partitions(self, frame):
        self._panel_header(frame, "◎ Recover Lost Partitions", "Lists current vs. expected partition table")
        box = self._text_output(frame)

        def scan():
            if IS_WINDOWS:
                ok, out = run_cmd('echo list volume | diskpart')
                return out if ok else "Requires Administrator privileges."
            return windows_only_notice()

        self._run_bg(scan, lambda r: self._set_text(box, r))

    def tool_recover_photos(self, frame):
        self._recovery_panel(frame, "▧ Recover Photos", {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".heic"},
                              "Filters recoverable candidates to image formats")

    def tool_recover_documents(self, frame):
        self._recovery_panel(frame, "▤ Recover Documents", {".doc", ".docx", ".pdf", ".xls", ".xlsx", ".txt"},
                              "Filters recoverable candidates to document formats")

    def tool_recover_emails(self, frame):
        self._recovery_panel(frame, "▤ Recover Emails", {".pst", ".ost", ".eml", ".msg"},
                              "Filters recoverable candidates to mail store formats")

    def tool_recover_crashed_drive(self, frame):
        self._panel_header(frame, "✦ Recover Crashed Drive", "Attempts a resilient file copy off a failing drive")
        box = self._text_output(frame)
        src_var, dst_var = tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=src_var, width=35).pack(side="left")
        tk.Button(row, text="Src", command=lambda: src_var.set(
            filedialog.askdirectory() or src_var.get())).pack(side="left", padx=4)
        ttk.Entry(row, textvariable=dst_var, width=35).pack(side="left")
        tk.Button(row, text="Dst", command=lambda: dst_var.set(
            filedialog.askdirectory() or dst_var.get())).pack(side="left", padx=4)

        def copy_resilient():
            s, d = src_var.get(), dst_var.get()
            if not os.path.isdir(s) or not d:
                return "Choose valid source and target folders."
            ok_count, fail_count = 0, 0
            for root, dirs, files in os.walk(s):
                rel = os.path.relpath(root, s)
                target_root = os.path.join(d, rel)
                os.makedirs(target_root, exist_ok=True)
                for f in files:
                    try:
                        shutil.copy2(os.path.join(root, f), os.path.join(target_root, f))
                        ok_count += 1
                    except Exception:
                        fail_count += 1
            return f"Resilient copy finished. Recovered: {ok_count} files. Unreadable/skipped: {fail_count}."

        self._button_row(frame, [("Start Recovery Copy",
                                   lambda: self._run_bg(copy_resilient, lambda r: self._set_text(box, r)))])

    def tool_recover_usb_drive(self, frame):
        self._recovery_panel(frame, "⌁ Recover USB Drive", None, "Scans a USB drive letter/mount for recoverable items")

    def tool_recover_sd_card(self, frame):
        self._recovery_panel(frame, "▥ Recover SD Card", {".jpg", ".jpeg", ".mp4", ".mov", ".raw", ".cr2"},
                              "Optimized for camera/SD card file types")

    def tool_deep_scan_recovery(self, frame):
        self._panel_header(frame, "⌕ Deep Scan Recovery",
                            "Raw file-signature carving across free space (slow, thorough)")
        box = self._text_output(frame)
        path_var = tk.StringVar(value="C:\\" if IS_WINDOWS else "/")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=path_var, width=30).pack(side="left")

        SIGNATURES = {
            b"\xff\xd8\xff": ".jpg",
            b"\x89PNG\r\n\x1a\n": ".png",
            b"%PDF": ".pdf",
            b"PK\x03\x04": ".zip/.docx/.xlsx",
        }

        def scan():
            root = path_var.get()
            hits = {ext: 0 for ext in SIGNATURES.values()}
            scanned = 0
            for r, dirs, files in os.walk(root):
                for f in files[:50]:  # sample cap per dir to keep it responsive
                    fp = os.path.join(r, f)
                    try:
                        with open(fp, "rb") as fh:
                            head = fh.read(16)
                        for sig, ext in SIGNATURES.items():
                            if head.startswith(sig):
                                hits[ext] += 1
                        scanned += 1
                    except Exception:
                        pass
                if scanned > 5000:
                    break
            lines = [f"Signature-matched files scanned: {scanned}"]
            for ext, count in hits.items():
                lines.append(f"  {ext}: {count} matches")
            return "\n".join(lines)

        self._button_row(frame, [("Start Deep Scan", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 4: HARDWARE TESTING
    # ==================================================================
    def tool_cpu_stress_test(self, frame):
        self._panel_header(frame, "△ CPU Stress Test", "Loads all cores for a set duration")
        box = self._text_output(frame)
        duration_var = tk.IntVar(value=10)
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Label(row, text="Duration (sec):").pack(side="left")
        ttk.Entry(row, textvariable=duration_var, width=6).pack(side="left", padx=6)
        stop_flag = {"stop": False}

        def burn(duration):
            end = time.time() + duration
            x = 0
            while time.time() < end and not stop_flag["stop"]:
                x = (x * x + 1) % 999999937

        def run_test():
            stop_flag["stop"] = False
            n = os.cpu_count() or 4
            threads = [threading.Thread(target=burn, args=(duration_var.get(),), daemon=True) for _ in range(n)]
            start = time.time()
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            return f"Stress test complete: {n} threads for {time.time()-start:.1f}s. " \
                   f"Peak CPU: {psutil.cpu_percent(interval=1) if psutil else 'N/A'}%"

        self._button_row(frame, [
            ("Start", lambda: self._run_bg(run_test, lambda r: self._set_text(box, r))),
            ("Stop", lambda: stop_flag.update(stop=True)),
        ])

    def tool_ram_stress_test(self, frame):
        self._panel_header(frame, "△ RAM Stress Test", "Allocates and verifies memory blocks")
        box = self._text_output(frame)
        mb_var = tk.IntVar(value=256)
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Label(row, text="MB to test:").pack(side="left")
        ttk.Entry(row, textvariable=mb_var, width=8).pack(side="left", padx=6)

        def run_test():
            mb = mb_var.get()
            try:
                blocks = []
                pattern = bytearray([0xAA] * 1024 * 1024)
                for _ in range(mb):
                    blocks.append(bytearray(pattern))
                errors = sum(1 for b in blocks if bytes(b[:16]) != bytes(pattern[:16]))
                del blocks
                return f"Allocated & verified {mb} MB. Pattern mismatches: {errors} (0 = healthy)."
            except MemoryError:
                return "MemoryError — reduce test size."

        self._button_row(frame, [("Run Test", lambda: self._run_bg(run_test, lambda r: self._set_text(box, r)))])

    def tool_gpu_stress_test(self, frame):
        self._panel_header(frame, "△ GPU Stress Test", "Renders heavy geometry via Tk canvas to load the GPU/driver")
        box = self._text_output(frame)
        canvas = tk.Canvas(frame, bg="black", height=200)
        canvas.pack(fill="x", padx=16, pady=8)

        def run_test():
            start = time.time()
            frames = 0
            while time.time() - start < 5:
                canvas.delete("all")
                import random
                for _ in range(300):
                    x, y = random.randint(0, 400), random.randint(0, 200)
                    canvas.create_oval(x, y, x + 10, y + 10, fill="#00e5ff", outline="")
                canvas.update()
                frames += 1
            return f"Rendered {frames} frames in 5s (~{frames/5:.1f} FPS). " \
                   "For full GPU load, run a native benchmark like FurMark."

        self._button_row(frame, [("Run Render Test", lambda: self._run_bg(run_test, lambda r: self._set_text(box, r)))])

    def tool_disk_stress_test(self, frame):
        self._panel_header(frame, "△ Disk Stress Test", "Sustained read/write loop")
        box = self._text_output(frame)

        def run_test():
            test_dir = os.path.join(os.getcwd(), ".techdrive_stress")
            os.makedirs(test_dir, exist_ok=True)
            fpath = os.path.join(test_dir, "stress.tmp")
            data = os.urandom(1024 * 1024)
            start = time.time()
            writes = 0
            while time.time() - start < 5:
                with open(fpath, "wb") as f:
                    f.write(data)
                    f.flush()
                    os.fsync(f.fileno())
                writes += 1
            shutil.rmtree(test_dir, ignore_errors=True)
            return f"Completed {writes} write cycles (1MB each) in 5 seconds."

        self._button_row(frame, [("Run Test", lambda: self._run_bg(run_test, lambda r: self._set_text(box, r)))])

    def tool_psu_voltage_check(self, frame):
        self._panel_header(frame, "↯ PSU Voltage Check", "Reads voltage rails via hardware sensors, if exposed")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_battery"):
                pass
            if IS_WINDOWS:
                ok, out = run_cmd('wmic /namespace:\\\\root\\wmi PATH MSAcpi_ThermalZoneTemperature get CurrentTemperature')
                note = "\n\nNote: most consumer motherboards don't expose PSU rail voltages to " \
                       "software without vendor tools (e.g. HWiNFO, motherboard app)."
                return (out if ok else "No sensor data exposed by this system.") + note
            return "Voltage rail sensors are typically OS/vendor-specific; not available here."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_motherboard_health(self, frame):
        self._panel_header(frame, "✚ Motherboard Health", "Combines board info + available thermal sensors")
        box = self._text_output(frame)

        def gather():
            lines = []
            if IS_WINDOWS:
                ok, out = run_cmd("wmic baseboard get Manufacturer,Product,Status /format:list")
                lines.append(out if ok else "Board info unavailable.")
            if psutil and hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        for e in entries:
                            lines.append(f"{name} - {e.label or 'sensor'}: {e.current}°C")
            return "\n".join(lines) or "No health telemetry available on this system."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_monitor_pixel_tester(self, frame):
        self._panel_header(frame, "▧ Monitor Pixel Tester", "Cycle full-screen colors to spot dead/stuck pixels")
        colors = ["black", "white", "red", "green", "blue"]
        idx = {"i": 0}
        win_holder = {}

        def open_fullscreen():
            win = tk.Toplevel(self)
            win.attributes("-fullscreen", True)
            win.configure(bg=colors[0])
            win_holder["win"] = win

            def next_color(event=None):
                idx["i"] = (idx["i"] + 1) % len(colors)
                win.configure(bg=colors[idx["i"]])

            def close(event=None):
                win.destroy()

            win.bind("<Button-1>", next_color)
            win.bind("<Escape>", close)

        self._panel_header  # noop to keep structure
        ttk.Label(frame, text="Click 'Launch' then click the screen to cycle colors, Esc to exit.",
                  wraplength=500).pack(anchor="w", padx=16, pady=6)
        self._button_row(frame, [("Launch Fullscreen Test", open_fullscreen)])

    def tool_keyboard_tester(self, frame):
        self._panel_header(frame, "⌨ Keyboard Tester", "Press keys to confirm they register")
        box = self._text_output(frame, height=6)
        pressed = set()

        def on_key(event):
            if not box.winfo_exists():
                return
            pressed.add(event.keysym)
            self._set_text(box, "Keys detected so far:\n" + ", ".join(sorted(pressed)))

        frame.bind_all("<KeyPress>", on_key)

        def cleanup(_event=None):
            # bind_all is global - without this, every keystroke anywhere
            # else in the app (other tabs, text fields, dialogs) keeps
            # getting captured forever, and it throws once `box` is gone.
            try:
                frame.unbind_all("<KeyPress>")
            except Exception:
                pass

        frame.bind("<Destroy>", cleanup, add="+")
        ttk.Label(frame, text="Start typing anywhere in this window...").pack(anchor="w", padx=16)

    def tool_mouse_tester(self, frame):
        self._panel_header(frame, "▣ Mouse Tester", "Move/click to test tracking and buttons")
        canvas = tk.Canvas(frame, bg=SURFACE, height=300)
        canvas.pack(fill="both", expand=True, padx=16, pady=10)
        label = ttk.Label(frame, text="Move mouse over the canvas / click buttons")
        label.pack(anchor="w", padx=16)

        def on_move(event):
            canvas.delete("cursor")
            canvas.create_oval(event.x - 4, event.y - 4, event.x + 4, event.y + 4, fill=ACCENT, tags="cursor")
            label.config(text=f"Position: ({event.x}, {event.y})")

        def on_click(event, btn):
            label.config(text=f"{btn} click at ({event.x}, {event.y})")

        canvas.bind("<Motion>", on_move)
        canvas.bind("<Button-1>", lambda e: on_click(e, "Left"))
        canvas.bind("<Button-3>", lambda e: on_click(e, "Right"))
        canvas.bind("<Button-2>", lambda e: on_click(e, "Middle"))

    def tool_usb_port_tester(self, frame):
        self._panel_header(frame, "⌁ USB Port Tester", "Lists connected USB devices; unplug/replug to test")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path Win32_USBHub get DeviceID,Description /format:list")
                return out if ok else "Could not enumerate USB devices."
            ok, out = run_cmd("lsusb") if not IS_WINDOWS else (False, "")
            return out if ok else windows_only_notice()

        self._button_row(frame, [("Refresh Device List", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])
        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 5: SECURITY & PRIVACY
    # ==================================================================
    def tool_wifi_password_viewer(self, frame):
        self._panel_header(frame, "))) WiFi Password Viewer", "Reveals saved WiFi keys on THIS machine")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd_argv(["netsh", "wlan", "show", "profiles"])
            if not ok:
                return "Could not list WiFi profiles."
            names = re.findall(r":\s(.+)", out)
            results = []
            for name in names:
                name = name.strip()
                ok2, out2 = run_cmd_argv(["netsh", "wlan", "show", "profile",
                                          f"name={name}", "key=clear"])
                m = re.search(r"Key Content\s*:\s*(.+)", out2)
                results.append(f"{name}: {m.group(1).strip() if m else '(no password / open network)'}")
            return "\n".join(results) or "No saved WiFi profiles found."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_windows_key_finder(self, frame):
        self._panel_header(frame, "◆ Windows Key Finder", "Reads the OEM product key from firmware/registry")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "(Get-CimInstance -query \'select * from SoftwareLicensingService\').OA3xOriginalProductKey"')
            return out if ok and out.strip() else "No embedded OEM key found (common on digitally-licensed Win10/11 installs)."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_virus_scanner(self, frame):
        self._panel_header(frame, "◇ Virus Scanner", "Triggers a Windows Defender quick scan")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "Start-MpScan -ScanType QuickScan"', timeout=300)
            return "Quick scan triggered via Windows Defender." if ok else \
                   "Could not start Defender scan (requires admin + Defender enabled)."

        self._button_row(frame, [("Run Quick Scan", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_startup_manager(self, frame):
        self._panel_header(frame, "→ Startup Manager", "Lists programs that launch at boot")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('wmic startup get Caption,Command,Location /format:list')
                return out if ok else "Could not list startup items."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_process_manager(self, frame):
        self._panel_header(frame, "⚙ Process Manager", "Live process list — select and end task")
        cols = ("PID", "Name", "CPU%", "Mem MB")
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=18)
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=140)
        tree.pack(fill="both", expand=True, padx=16, pady=8)

        def refresh():
            for i in tree.get_children():
                tree.delete(i)
            if not psutil:
                return
            for p in sorted(psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]),
                             key=lambda p: -(p.info.get("cpu_percent") or 0))[:100]:
                mem = p.info["memory_info"].rss / (1024 * 1024) if p.info.get("memory_info") else 0
                tree.insert("", "end", values=(p.info["pid"], p.info["name"],
                                                f"{p.info.get('cpu_percent', 0):.1f}", f"{mem:.1f}"))

        def end_task():
            sel = tree.selection()
            if not sel or not psutil:
                return
            pid = tree.item(sel[0])["values"][0]
            try:
                psutil.Process(pid).terminate()
                messagebox.showinfo("Process Manager", f"Terminated PID {pid}")
            except Exception as e:
                messagebox.showerror("Process Manager", str(e))
            refresh()

        self._button_row(frame, [("Refresh", refresh), ("End Task", end_task)])
        refresh()

    def tool_browser_cache_cleaner(self, frame):
        self._panel_header(frame, "⌁ Browser Cache Cleaner", "Clears common browser cache folders")
        box = self._text_output(frame)

        def clean():
            home = os.path.expanduser("~")
            candidates = [
                os.path.join(home, "AppData", "Local", "Google", "Chrome", "User Data", "Default", "Cache"),
                os.path.join(home, "AppData", "Local", "Microsoft", "Edge", "User Data", "Default", "Cache"),
                os.path.join(home, "AppData", "Local", "Mozilla", "Firefox", "Profiles"),
                os.path.join(home, ".cache", "google-chrome"),
                os.path.join(home, "Library", "Caches", "Google", "Chrome"),
            ]
            freed = 0
            cleared = []
            for c in candidates:
                if os.path.isdir(c):
                    try:
                        size = sum(os.path.getsize(os.path.join(r, f))
                                   for r, d, fs in os.walk(c) for f in fs)
                        shutil.rmtree(c, ignore_errors=True)
                        os.makedirs(c, exist_ok=True)
                        freed += size
                        cleared.append(c)
                    except Exception:
                        pass
            return f"Cleared {len(cleared)} cache folders, freed ~{bytes_fmt(freed)}." if cleared else \
                   "No known browser cache folders found on this machine."

        self._button_row(frame, [("Clear Caches", lambda: self._confirm_then(
            "This clears browser cache (you may need to sign in again). Continue?",
            lambda: self._run_bg(clean, lambda r: self._set_text(box, r))))])

    def tool_file_shredder(self, frame):
        self._panel_header(frame, "△ File Shredder", "Multi-pass overwrite + delete for selected files")
        box = self._text_output(frame)
        files_var = []
        listbox = tk.Listbox(frame, bg=SURFACE, fg=FG, height=8)
        listbox.pack(fill="x", padx=16, pady=6)

        def add_files():
            paths = filedialog.askopenfilenames()
            for p in paths:
                files_var.append(p)
                listbox.insert("end", p)

        def shred():
            count = 0
            for p in files_var:
                try:
                    size = os.path.getsize(p)
                    with open(p, "r+b") as f:
                        for _ in range(3):
                            f.seek(0)
                            f.write(os.urandom(size))
                    os.remove(p)
                    count += 1
                except Exception:
                    pass
            listbox.delete(0, "end")
            files_var.clear()
            return f"Shredded {count} file(s)."

        self._button_row(frame, [
            ("Add Files", add_files),
            ("Shred Selected", lambda: self._confirm_then(
                "Files will be unrecoverable. Continue?",
                lambda: self._run_bg(shred, lambda r: self._set_text(box, r)))),
        ])

    def tool_file_encryption(self, frame):
        self._panel_header(frame, "◆ File Encryption", "AES (Fernet) encrypt/decrypt a file with a password")
        box = self._text_output(frame)
        path_var, pass_var = tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=45).pack(side="left", padx=(0, 6))
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askopenfilename() or path_var.get())).pack(side="left")
        row2 = ttk.Frame(frame)
        row2.pack(anchor="w", padx=16, pady=6)
        ttk.Label(row2, text="Password:").pack(side="left")
        ttk.Entry(row2, textvariable=pass_var, show="*", width=25).pack(side="left", padx=6)

        def _key_from_pass(pw):
            import base64
            digest = hashlib.sha256(pw.encode()).digest()
            return base64.urlsafe_b64encode(digest)

        def encrypt():
            try:
                from cryptography.fernet import Fernet
            except ImportError:
                return "Install 'cryptography' package: pip install cryptography"
            p, pw = path_var.get(), pass_var.get()
            if not os.path.isfile(p) or not pw:
                return "Select a file and enter a password."
            f = Fernet(_key_from_pass(pw))
            with open(p, "rb") as fh:
                data = fh.read()
            enc = f.encrypt(data)
            with open(p + ".enc", "wb") as fh:
                fh.write(enc)
            return f"Encrypted -> {p}.enc"

        def decrypt():
            try:
                from cryptography.fernet import Fernet
            except ImportError:
                return "Install 'cryptography' package: pip install cryptography"
            p, pw = path_var.get(), pass_var.get()
            if not os.path.isfile(p) or not pw:
                return "Select an .enc file and enter its password."
            f = Fernet(_key_from_pass(pw))
            with open(p, "rb") as fh:
                data = fh.read()
            try:
                dec = f.decrypt(data)
            except Exception:
                return "Wrong password or corrupted file."
            out_path = p[:-4] if p.endswith(".enc") else p + ".dec"
            with open(out_path, "wb") as fh:
                fh.write(dec)
            return f"Decrypted -> {out_path}"

        self._button_row(frame, [
            ("Encrypt", lambda: self._run_bg(encrypt, lambda r: self._set_text(box, r))),
            ("Decrypt", lambda: self._run_bg(decrypt, lambda r: self._set_text(box, r))),
        ])

    def tool_password_generator(self, frame):
        self._panel_header(frame, "◇ Password Generator")
        box = self._text_output(frame, height=4)
        length_var = tk.IntVar(value=16)
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Label(row, text="Length:").pack(side="left")
        ttk.Entry(row, textvariable=length_var, width=6).pack(side="left", padx=6)

        def generate():
            import secrets, string
            n = max(4, length_var.get())
            alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
            pw = "".join(secrets.choice(alphabet) for _ in range(n))
            self._set_text(box, pw)

        self._button_row(frame, [("Generate", generate)])
        generate()

    def tool_privacy_cleaner(self, frame):
        self._panel_header(frame, "◉ Privacy Cleaner", "Clears recent-files lists, run history, clipboard")
        box = self._text_output(frame)

        def clean():
            cleared = []
            if IS_WINDOWS:
                ok, _ = run_cmd('reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU" /va /f')
                if ok:
                    cleared.append("Run history")
                ok, _ = run_cmd('reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RecentDocs" /va /f')
                if ok:
                    cleared.append("Recent documents")
            try:
                self.clipboard_clear()
                cleared.append("Clipboard")
            except Exception:
                pass
            return f"Cleared: {', '.join(cleared)}" if cleared else "Nothing cleared (may need admin rights)."

        self._button_row(frame, [("Clean Privacy Traces",
                                   lambda: self._confirm_then("Clear recent history & clipboard?",
                                                               lambda: self._run_bg(clean, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 5b: SECURITY TOOLS (Windows Security / Firewall / Defender /
    # UAC / BitLocker / TPM / Secure Boot / AppLocker / Windows Update /
    # Audit Log). Most of these need admin rights and/or a UEFI-capable
    # board to return real values (Secure Boot/TPM in particular will
    # correctly report "not supported" on older legacy-BIOS hardware -
    # that's expected, not a bug).
    # ==================================================================
    def _firewall_profile_states(self):
        """Returns {'Domain': 'ON'/'OFF'/None, 'Private': ..., 'Public': ...}
        parsed from `netsh advfirewall show allprofiles state`. None means
        the parse couldn't find that profile in the output."""
        states = {"Domain": None, "Private": None, "Public": None}
        ok, out = run_cmd("netsh advfirewall show allprofiles state")
        if not ok:
            return states
        current = None
        for line in out.splitlines():
            line = line.strip()
            for profile in states:
                if line.startswith(f"{profile} Profile"):
                    current = profile
            if current and re.match(r"^State\s+(ON|OFF)", line, re.IGNORECASE):
                states[current] = "ON" if "ON" in line.upper() else "OFF"
                current = None
        return states

    def tool_windows_security(self, frame):
        """One-screen overview pulling from Defender + Firewall + UAC -
        the other tools in this category go deeper on each of those."""
        def gather():
            if not IS_WINDOWS:
                return None
            data = {}
            ok, out = run_cmd(
                'powershell -Command "Get-MpComputerStatus | Select-Object '
                'AntivirusEnabled,RealTimeProtectionEnabled,AntispywareEnabled | Format-List"',
                timeout=30,
            )
            data["defender_av"] = "True" in out if ok and "AntivirusEnabled" in out else None
            data["defender_rtp"] = "RealTimeProtectionEnabled" in out and \
                re.search(r"RealTimeProtectionEnabled\s*:\s*True", out) is not None
            fw = self._firewall_profile_states()
            data["firewall"] = fw
            ok2, out2 = run_cmd(
                'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA'
            )
            data["uac"] = "0x1" in out2 if ok2 else None
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read security status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            av = data.get("defender_av")
            panel.stat("Antivirus (Defender)", "Enabled" if av else "Disabled/Unknown",
                       status="good" if av else "warn")
            rtp = data.get("defender_rtp")
            panel.stat("Real-Time Protection", "On" if rtp else "Off/Unknown",
                       status="good" if rtp else "warn")
            fw = data.get("firewall", {})
            fw_section = panel.card("Firewall Profiles")
            for profile, state in fw.items():
                panel.stat(profile, state or "Unknown",
                           status="good" if state == "ON" else ("bad" if state == "OFF" else None),
                           container=fw_section)
            uac = data.get("uac")
            panel.stat("UAC (User Account Control)", "Enabled" if uac else "Disabled/Unknown",
                       status="good" if uac else "warn")

        panel = CardPanel(frame, self.theme, "Windows Security", "Defender + Firewall + UAC at a glance",
                           icon="⬢", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_firewall(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            return self._firewall_profile_states()

        def redraw(states):
            panel.clear()
            if isinstance(states, self._BgError):
                panel.empty_state(f"Could not read firewall status: {states}")
                return
            if states is None:
                panel.empty_state(windows_only_notice())
                return
            for profile, state in states.items():
                panel.stat(f"{profile} Profile", state or "Unknown",
                           status="good" if state == "ON" else ("bad" if state == "OFF" else None))

        panel = CardPanel(frame, self.theme, "Firewall", "Windows Defender Firewall state per profile",
                           icon="▰", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_defender(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd(
                'powershell -Command "Get-MpComputerStatus | Select-Object '
                'AMServiceEnabled,AntivirusEnabled,AntispywareEnabled,RealTimeProtectionEnabled,'
                'AntivirusSignatureLastUpdated,AntivirusSignatureVersion | Format-List"',
                timeout=30,
            )
            if not ok:
                return {"error": out or "Get-MpComputerStatus failed (Defender may be disabled or replaced)."}
            data = {}
            for key in ("AMServiceEnabled", "AntivirusEnabled", "AntispywareEnabled",
                        "RealTimeProtectionEnabled"):
                m = re.search(rf"{key}\s*:\s*(\w+)", out)
                data[key] = m.group(1) if m else "Unknown"
            m = re.search(r"AntivirusSignatureLastUpdated\s*:\s*(.+)", out)
            data["sig_updated"] = m.group(1).strip() if m else "Unknown"
            m = re.search(r"AntivirusSignatureVersion\s*:\s*(.+)", out)
            data["sig_version"] = m.group(1).strip() if m else "Unknown"
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read Defender status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            if "error" in data:
                panel.empty_state(data["error"])
                return
            for label, key in (("Service Enabled", "AMServiceEnabled"), ("Antivirus Enabled", "AntivirusEnabled"),
                                ("Antispyware Enabled", "AntispywareEnabled"),
                                ("Real-Time Protection", "RealTimeProtectionEnabled")):
                val = data.get(key, "Unknown")
                panel.stat(label, val, status="good" if val == "True" else ("bad" if val == "False" else None))
            panel.stat("Signature Version", data.get("sig_version", "Unknown"))
            panel.stat("Signatures Last Updated", data.get("sig_updated", "Unknown"))

        panel = CardPanel(frame, self.theme, "Defender", "Windows Defender antivirus status",
                           icon="◇", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_uac(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd(
                'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA'
            )
            enabled = "0x1" in out if ok else None
            ok2, out2 = run_cmd(
                'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v ConsentPromptBehaviorAdmin'
            )
            m = re.search(r"0x([0-9a-fA-F]+)", out2) if ok2 else None
            level = int(m.group(1), 16) if m else None
            return {"enabled": enabled, "level": level}

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read UAC settings: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            enabled = data["enabled"]
            panel.stat("UAC Enabled", "Yes" if enabled else "No" if enabled is not None else "Unknown",
                       status="good" if enabled else "bad" if enabled is not None else None)
            level_names = {0: "Never notify", 2: "Notify (dim desktop)",
                           5: "Notify (default, no dim)"}
            level = data["level"]
            panel.stat("Prompt Behavior", level_names.get(level, f"Level {level}" if level is not None else "Unknown"))

        panel = CardPanel(frame, self.theme, "UAC", "User Account Control settings",
                           icon="◆", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_bitlocker(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd(
                'powershell -Command "Get-BitLockerVolume | Select-Object MountPoint,VolumeStatus,'
                'ProtectionStatus,EncryptionPercentage | Format-Table -AutoSize"',
                timeout=30,
            )
            if not ok or not out.strip():
                return {"error": out or "Get-BitLockerVolume failed (needs admin, or BitLocker unavailable "
                                          "on this Windows edition)."}
            volumes = []
            for line in out.splitlines():
                m = re.match(r"^([A-Z]:)\s+(\S+)\s+(\S+)\s+(\d+)", line.strip())
                if m:
                    volumes.append({
                        "mount": m.group(1), "status": m.group(2),
                        "protection": m.group(3), "pct": int(m.group(4)),
                    })
            return {"volumes": volumes}

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read BitLocker status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            if "error" in data:
                panel.empty_state(data["error"])
                return
            if not data["volumes"]:
                panel.empty_state("No volumes reported.")
                return
            for v in data["volumes"]:
                section = panel.card(v["mount"])
                panel.stat("Volume Status", v["status"], container=section)
                on = v["protection"].lower() == "on"
                panel.stat("Protection", v["protection"], status="good" if on else "warn", container=section)
                panel.progress("Encrypted", v["pct"], status="good" if v["pct"] == 100 else "warn",
                               container=section)

        panel = CardPanel(frame, self.theme, "BitLocker", "Drive encryption status per volume",
                           icon="◆", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_tpm(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd(
                'powershell -Command "Get-Tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,'
                'ManufacturerVersion | Format-List"',
                timeout=30,
            )
            if not ok:
                return {"error": out or "Get-Tpm failed. This board may not have a TPM, or it's disabled in BIOS."}
            data = {}
            for key in ("TpmPresent", "TpmReady", "TpmEnabled"):
                m = re.search(rf"{key}\s*:\s*(\w+)", out)
                data[key] = m.group(1) if m else "Unknown"
            m = re.search(r"ManufacturerVersion\s*:\s*(.+)", out)
            data["version"] = m.group(1).strip() if m else "Unknown"
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read TPM status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            if "error" in data:
                panel.empty_state(data["error"])
                return
            for label, key in (("Present", "TpmPresent"), ("Ready", "TpmReady"), ("Enabled", "TpmEnabled")):
                val = data.get(key, "Unknown")
                panel.stat(label, val, status="good" if val == "True" else ("bad" if val == "False" else None))
            panel.stat("Manufacturer Version", data.get("version", "Unknown"))

        panel = CardPanel(frame, self.theme, "TPM", "Trusted Platform Module status",
                           icon="◆", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_secure_boot(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd('powershell -Command "Confirm-SecureBootUEFI"', timeout=20)
            if "True" in out:
                return {"status": "Enabled"}
            if "False" in out:
                return {"status": "Disabled"}
            # Confirm-SecureBootUEFI throws on legacy BIOS systems - that's
            # an expected, correct result on older boards, not a failure.
            return {"status": "Not supported (legacy BIOS / CSM mode — common on older motherboards)"}

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read Secure Boot status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            status = data["status"]
            is_enabled = status == "Enabled"
            panel.stat("Secure Boot", status,
                       status="good" if is_enabled else ("bad" if status == "Disabled" else "warn"))

        panel = CardPanel(frame, self.theme, "Secure Boot", "UEFI Secure Boot status",
                           icon="→", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_applocker(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            svc_ok, svc_out = run_cmd(
                'powershell -Command "(Get-Service -Name AppIDSvc).Status"'
            )
            policy_ok, policy_out = run_cmd(
                'powershell -Command "Get-AppLockerPolicy -Effective | Select-Object -ExpandProperty RuleCollections '
                '| Measure-Object | Select-Object -ExpandProperty Count"',
                timeout=30,
            )
            return {
                "service": svc_out.strip() if svc_ok else "Unknown",
                "rule_collections": policy_out.strip() if policy_ok and policy_out.strip().isdigit() else None,
            }

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read AppLocker status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            svc = data["service"]
            panel.stat("Application Identity Service", svc,
                       status="good" if svc == "Running" else "warn")
            rc = data["rule_collections"]
            if rc is not None:
                panel.stat("Effective Rule Collections", rc)
            else:
                panel.empty_state("No AppLocker policy found — AppLocker is an Enterprise/Education "
                                   "feature and typically isn't configured on Home/Pro editions.")

        panel = CardPanel(frame, self.theme, "AppLocker", "Application control policy status",
                           icon="△", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_windows_update(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            svc_ok, svc_out = run_cmd('powershell -Command "(Get-Service -Name wuauserv).Status"')
            ok, out = run_cmd(
                'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update\\Results\\Install" /v LastSuccessTime'
            )
            m = re.search(r"LastSuccessTime\s+REG_SZ\s+(.+)", out) if ok else None
            return {
                "service": svc_out.strip() if svc_ok else "Unknown",
                "last_success": m.group(1).strip() if m else "Unknown (or no successful install logged here)",
            }

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read Windows Update status: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            svc = data["service"]
            panel.stat("Windows Update Service", svc, status="good" if svc == "Running" else "warn")
            panel.stat("Last Successful Install", data["last_success"])

        panel = CardPanel(frame, self.theme, "Windows Update", "Update service status + last install",
                           icon="⟳", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_audit_log(self, frame):
        def gather():
            if not IS_WINDOWS:
                return None
            ok, out = run_cmd(
                'powershell -Command "Get-WinEvent -LogName Security -MaxEvents 15 | '
                'Select-Object TimeCreated,Id,LevelDisplayName,Message | Format-Table -AutoSize -Wrap"',
                timeout=30,
            )
            if not ok or not out.strip():
                return {"error": out or "Could not read the Security event log (usually requires "
                                          "running TechDrive as Administrator)."}
            return {"raw": out}

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read audit log: {data}")
                return
            if data is None:
                panel.empty_state(windows_only_notice())
                return
            if "error" in data:
                panel.empty_state(data["error"])
                return
            box = tk.Text(panel.body, bg=self.theme["SURFACE"], fg=self.theme["FG"], height=20,
                           wrap="none", relief="flat", font=("Consolas", 9))
            box.pack(fill="both", expand=True, padx=14, pady=10)
            box.insert("end", data["raw"])
            box.config(state="disabled")

        panel = CardPanel(frame, self.theme, "Audit Log", "Recent Security event log entries (needs admin)",
                           icon="▤", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    # ==================================================================
    # CATEGORY 6: NETWORK TOOLS
    # ==================================================================
    def tool_ping_tool(self, frame):
        """Compatibility alias for the canonical Ping implementation."""
        return self.tool_ping(frame)

    def tool_traceroute_tool(self, frame):
        """Compatibility alias for the canonical Traceroute implementation."""
        return self.tool_traceroute(frame)

    def tool_dns_lookup_tool(self, frame):
        """Compatibility alias for the canonical DNS Lookup implementation."""
        return self.tool_dns_lookup(frame)

    def tool_ip_scanner(self, frame):
        self._panel_header(frame, "◎ IP Scanner", "Sweeps a /24 subnet for live hosts (ping)")
        box = self._text_output(frame)
        subnet_var = tk.StringVar(value="192.168.1")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=subnet_var, width=20).pack(side="left")
        flag = "-n" if IS_WINDOWS else "-c"

        def scan():
            subnet = subnet_var.get().strip()
            if not valid_host(subnet):
                return "Invalid subnet: only letters, digits, '.', '-' are allowed."
            alive = []
            for i in range(1, 255):
                ip = f"{subnet}.{i}"
                ok, _ = run_cmd_argv(["ping", flag, "1", ip], timeout=1)
                if ok:
                    alive.append(ip)
            return "\n".join(alive) if alive else "No hosts responded (scan may be slow/blocked by firewall)."

        self._button_row(frame, [("Scan Subnet (slow)", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_port_scanner(self, frame):
        self._panel_header(frame, "□ Port Scanner", "Checks common TCP ports on a host")
        box = self._text_output(frame)
        host_var = tk.StringVar(value="127.0.0.1")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=host_var, width=30).pack(side="left")
        COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 8080]

        def scan():
            results = []
            for port in COMMON_PORTS:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(0.5)
                res = s.connect_ex((host_var.get(), port))
                results.append(f"Port {port}: {'OPEN' if res == 0 else 'closed'}")
                s.close()
            return "\n".join(results)

        self._button_row(frame, [("Scan Common Ports", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_bandwidth_speed_test(self, frame):
        self._panel_header(frame, "))) Bandwidth Speed Test", "Downloads a test file to estimate throughput")
        box = self._text_output(frame)

        def test():
            if not requests:
                return "Install 'requests' package: pip install requests"
            url = "https://speed.hetzner.de/100MB.bin"
            try:
                start = time.time()
                r = requests.get(url, stream=True, timeout=10)
                total = 0
                for chunk in r.iter_content(chunk_size=1024 * 256):
                    total += len(chunk)
                    if time.time() - start > 8:
                        break
                elapsed = time.time() - start
                mbps = (total * 8 / 1_000_000) / elapsed if elapsed else 0
                return f"Downloaded {bytes_fmt(total)} in {elapsed:.1f}s -> {mbps:.1f} Mbps"
            except Exception as e:
                return f"Speed test failed: {e}"

        self._button_row(frame, [("Run Speed Test", lambda: self._run_bg(test, lambda r: self._set_text(box, r)))])

    def tool_wifi_analyzer(self, frame):
        self._panel_header(frame, "))) WiFi Analyzer", "Nearby networks and signal strength")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("netsh wlan show networks mode=bssid")
                return out if ok else "Could not scan WiFi (adapter may be off)."
            ok, out = run_cmd("nmcli dev wifi list") if not IS_WINDOWS else (False, "")
            return out if ok else windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_network_reset_tool(self, frame):
        self._panel_header(frame, "⟳ Network Reset Tool", "Flushes DNS and resets Winsock/TCP-IP stack")
        box = self._text_output(frame)

        def reset():
            if not IS_WINDOWS:
                return windows_only_notice()
            steps = [["ipconfig", "/flushdns"], ["ipconfig", "/release"], ["ipconfig", "/renew"],
                     ["netsh", "winsock", "reset"], ["netsh", "int", "ip", "reset"]]
            out_all = []
            for s in steps:
                ok, out = run_cmd_argv(s, timeout=30)
                out_all.append(f"$ {' '.join(s)}\n{out}")
            return "\n\n".join(out_all) + "\n\nRestart your PC to complete the reset."

        self._button_row(frame, [("Reset Network Stack", lambda: self._confirm_then(
            "This resets network settings and may require a restart. Continue?",
            lambda: self._run_bg(reset, lambda r: self._set_text(box, r))))])

    def tool_firewall_checker(self, frame):
        self._panel_header(frame, "▰ Firewall Checker")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("netsh advfirewall show allprofiles")
                return out if ok else "Could not query firewall status."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_proxy_manager(self, frame):
        self._panel_header(frame, "◎ Proxy Manager", "View/set the system HTTP proxy")
        box = self._text_output(frame)
        proxy_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=proxy_var, width=30).pack(side="left")

        def get_current():
            if IS_WINDOWS:
                ok, out = run_cmd_argv(["reg", "query",
                    "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
                    "/v", "ProxyServer"])
                return out if ok else "No proxy configured."
            return windows_only_notice()

        def set_proxy():
            if not IS_WINDOWS:
                return windows_only_notice()
            p = proxy_var.get()
            key = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"
            ok, out = run_cmd_argv(["reg", "add", key, "/v", "ProxyServer", "/d", p, "/f"])
            ok2, out2 = run_cmd_argv(["reg", "add", key, "/v", "ProxyEnable",
                                      "/t", "REG_DWORD", "/d", "1", "/f"])
            return f"Proxy set to {p}" if ok and ok2 else "Failed to set proxy."

        self._button_row(frame, [
            ("Show Current", lambda: self._run_bg(get_current, lambda r: self._set_text(box, r))),
            ("Apply Proxy", lambda: self._run_bg(set_proxy, lambda r: self._set_text(box, r))),
        ])

    # ------------------------------------------------------------------
    # "Network Tools" (2nd category) - Adapters / IP Config / Ping /
    # Traceroute / DNS Lookup / Stats / ARP Table / Routing Table / Monitor
    # ------------------------------------------------------------------
    def tool_adapters(self, frame):
        def gather():
            if not psutil:
                return None
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()
            out = []
            for name, addr_list in addrs.items():
                st = stats.get(name)
                ipv4 = next((a.address for a in addr_list if a.family == socket.AF_INET), "—")
                mac = next((a.address for a in addr_list
                            if a.family.name in ("AF_LINK", "AF_PACKET")), "—")
                out.append({
                    "name": name, "ip": ipv4, "mac": mac,
                    "up": bool(st.isup) if st else None,
                    "speed": f"{st.speed} Mbps" if st and st.speed else "N/A",
                })
            return out

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read adapters: {data}")
                return
            if data is None:
                panel.empty_state("psutil not installed.")
                return
            if not data:
                panel.empty_state("No network adapters found.")
                return
            for a in data:
                section = panel.card(a["name"])
                panel.stat("IPv4 Address", a["ip"], container=section)
                panel.stat("MAC Address", a["mac"], container=section)
                panel.stat("Status", "Up" if a["up"] else "Down",
                           status="good" if a["up"] else "bad", container=section)
                panel.stat("Link Speed", a["speed"], container=section)

        panel = CardPanel(frame, self.theme, "Adapters", "All detected network interfaces",
                           icon="⌁", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_ip_config(self, frame):
        def gather():
            data = {"hostname": "N/A", "local_ip": "N/A", "gateway": "N/A", "dns": []}
            try:
                data["hostname"] = socket.gethostname()
            except Exception:
                pass
            try:
                # Doesn't actually send traffic - UDP connect() just picks the
                # local interface/IP the OS would use to reach that address.
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                    s.connect(("8.8.8.8", 80))
                    data["local_ip"] = s.getsockname()[0]
            except Exception:
                pass
            if IS_WINDOWS:
                ok, out = run_cmd("ipconfig /all")
                if ok:
                    gw = re.search(r"Default Gateway[ .]*:\s*([\d.]+)", out)
                    if gw:
                        data["gateway"] = gw.group(1)
                    data["dns"] = re.findall(r"DNS Servers[ .]*:\s*([\d.]+)", out)
            else:
                ok, out = run_cmd("ip route show default")
                if ok:
                    gw = re.search(r"default via ([\d.]+)", out)
                    if gw:
                        data["gateway"] = gw.group(1)
                ok2, out2 = run_cmd("cat /etc/resolv.conf 2>/dev/null")
                if ok2:
                    data["dns"] = re.findall(r"nameserver\s+([\d.:a-fA-F]+)", out2)
            return data

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read IP config: {data}")
                return
            panel.stat("Hostname", data["hostname"])
            panel.stat("Local IP", data["local_ip"])
            panel.stat("Default Gateway", data["gateway"])
            panel.stat("DNS Servers", ", ".join(data["dns"]) if data["dns"] else "N/A")

        panel = CardPanel(frame, self.theme, "IP Config", "Local IP, gateway, and DNS",
                           icon="◎", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_ping(self, frame):
        panel = CardPanel(frame, self.theme, "Ping", "Send ICMP echo requests to a host", icon="⌁")
        input_row = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        input_row.pack(fill="x", padx=14, pady=(10, 4))
        host_var = tk.StringVar(value="8.8.8.8")
        tk.Entry(input_row, textvariable=host_var, bg=self.theme["SURFACE"], fg=self.theme["FG"],
                  insertbackground=self.theme["FG"], relief="flat", width=28).pack(side="left", ipady=3)
        flag = "-n" if IS_WINDOWS else "-c"
        results_frame = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        results_frame.pack(fill="both", expand=True)

        def gather():
            host = host_var.get().strip()
            if not valid_host(host):
                return "Invalid host: only letters, digits, '.', '-', ':' are allowed."
            ok, out = run_cmd_argv(["ping", flag, "4", host])
            return out

        def redraw(out):
            for child in results_frame.winfo_children():
                child.destroy()
            if isinstance(out, self._BgError):
                tk.Label(results_frame, text=f"Ping failed: {out}", bg=self.theme["CARD_BG"],
                          fg=status_color("bad")).pack(anchor="w", padx=14, pady=10)
                return
            sub_panel = CardPanel.__new__(CardPanel)  # reuse stat()/progress() helpers on this sub-area
            sub_panel.theme = self.theme
            sub_panel.body = results_frame

            loss = re.search(r"(\d+)% (?:packet )?loss", out)
            avg = re.search(r"(?:Average|avg)[^=\d]*=?\s*(\d+(?:\.\d+)?)\s*ms", out, re.IGNORECASE)
            if loss:
                loss_pct = int(loss.group(1))
                sub_panel.stat("Packet Loss", f"{loss_pct}%",
                               status="good" if loss_pct == 0 else ("warn" if loss_pct < 50 else "bad"))
            if avg:
                sub_panel.stat("Average Latency", f"{avg.group(1)} ms")
            raw = sub_panel.card("Raw Output")
            box = tk.Text(raw, bg=self.theme["SURFACE"], fg=self.theme["FG"], height=10,
                           wrap="word", relief="flat")
            box.pack(fill="both", expand=True, padx=14, pady=(0, 10))
            box.insert("end", out)
            box.config(state="disabled")

        tk.Button(input_row, text="Ping", command=lambda: self._run_bg(gather, redraw),
                  bg=self.theme["ACCENT"], fg="white", relief="flat", padx=12).pack(side="left", padx=8)

    def tool_traceroute(self, frame):
        panel = CardPanel(frame, self.theme, "Traceroute", "Trace the network path to a host", icon="◎")
        input_row = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        input_row.pack(fill="x", padx=14, pady=(10, 4))
        host_var = tk.StringVar(value="8.8.8.8")
        tk.Entry(input_row, textvariable=host_var, bg=self.theme["SURFACE"], fg=self.theme["FG"],
                  insertbackground=self.theme["FG"], relief="flat", width=28).pack(side="left", ipady=3)
        cmd = "tracert" if IS_WINDOWS else "traceroute"
        results_frame = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        results_frame.pack(fill="both", expand=True)

        def gather():
            host = host_var.get().strip()
            if not valid_host(host):
                return "Invalid host: only letters, digits, '.', '-', ':' are allowed."
            ok, out = run_cmd_argv([cmd, host], timeout=60)
            return out

        def redraw(out):
            for child in results_frame.winfo_children():
                child.destroy()
            if isinstance(out, self._BgError):
                tk.Label(results_frame, text=f"Traceroute failed: {out}", bg=self.theme["CARD_BG"],
                          fg=status_color("bad")).pack(anchor="w", padx=14, pady=10)
                return
            box = tk.Text(results_frame, bg=self.theme["SURFACE"], fg=self.theme["FG"], height=16,
                           wrap="none", relief="flat")
            box.pack(fill="both", expand=True, padx=14, pady=10)
            box.insert("end", out or "(no output)")
            box.config(state="disabled")

        tk.Button(input_row, text="Trace", command=lambda: self._run_bg(gather, redraw),
                  bg=self.theme["ACCENT"], fg="white", relief="flat", padx=12).pack(side="left", padx=8)

    def tool_dns_lookup(self, frame):
        panel = CardPanel(frame, self.theme, "DNS Lookup", "Resolve a hostname to its IP addresses", icon="⌕")
        input_row = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        input_row.pack(fill="x", padx=14, pady=(10, 4))
        host_var = tk.StringVar(value="example.com")
        tk.Entry(input_row, textvariable=host_var, bg=self.theme["SURFACE"], fg=self.theme["FG"],
                  insertbackground=self.theme["FG"], relief="flat", width=28).pack(side="left", ipady=3)
        results_frame = tk.Frame(panel.body, bg=self.theme["CARD_BG"])
        results_frame.pack(fill="both", expand=True)

        def gather():
            host = host_var.get().strip()
            try:
                ip = socket.gethostbyname(host)
                try:
                    _, aliases, all_ips = socket.gethostbyname_ex(host)
                except Exception:
                    all_ips = [ip]
                return {"host": host, "ip": ip, "all_ips": all_ips}
            except Exception as e:
                return {"error": str(e)}

        def redraw(data):
            for child in results_frame.winfo_children():
                child.destroy()
            if isinstance(data, self._BgError) or "error" in data:
                msg = data if isinstance(data, self._BgError) else data["error"]
                tk.Label(results_frame, text=f"Lookup failed: {msg}", bg=self.theme["CARD_BG"],
                          fg=status_color("bad")).pack(anchor="w", padx=14, pady=10)
                return
            sub_panel = CardPanel.__new__(CardPanel)
            sub_panel.theme = self.theme
            sub_panel.body = results_frame
            sub_panel.stat("Hostname", data["host"])
            sub_panel.stat("Primary IP", data["ip"])
            sub_panel.stat("All IPs", ", ".join(data["all_ips"]))

        tk.Button(input_row, text="Lookup", command=lambda: self._run_bg(gather, redraw),
                  bg=self.theme["ACCENT"], fg="white", relief="flat", padx=12).pack(side="left", padx=8)

    def tool_stats(self, frame):
        def gather():
            if not psutil:
                return None
            io = psutil.net_io_counters()
            return {
                "sent": bytes_fmt(io.bytes_sent), "recv": bytes_fmt(io.bytes_recv),
                "packets_sent": io.packets_sent, "packets_recv": io.packets_recv,
                "errin": io.errin, "errout": io.errout, "dropin": io.dropin, "dropout": io.dropout,
            }

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not read network stats: {data}")
                return
            if data is None:
                panel.empty_state("psutil not installed.")
                return
            panel.stat("Bytes Sent", data["sent"])
            panel.stat("Bytes Received", data["recv"])
            panel.stat("Packets Sent", data["packets_sent"])
            panel.stat("Packets Received", data["packets_recv"])
            errors = data["errin"] + data["errout"] + data["dropin"] + data["dropout"]
            panel.stat("Errors + Drops", errors, status="good" if errors == 0 else "warn")

        panel = CardPanel(frame, self.theme, "Stats", "Cumulative network I/O since boot",
                           icon="▥", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_arp_table(self, frame):
        def gather():
            ok, out = run_cmd("arp -a")
            if not ok:
                return []
            entries = []
            for line in out.splitlines():
                m = re.search(r"([\d]{1,3}(?:\.[\d]{1,3}){3})\s+([0-9a-fA-F:-]{11,17})\s*(\S*)", line)
                if m:
                    entries.append({"ip": m.group(1), "mac": m.group(2), "type": m.group(3) or "N/A"})
            return entries

        def redraw(entries):
            panel.clear()
            if isinstance(entries, self._BgError):
                panel.empty_state(f"Could not read ARP table: {entries}")
                return
            if not entries:
                panel.empty_state("No ARP entries found (or 'arp' command unavailable).")
                return
            for e in entries:
                section = panel.card(e["ip"])
                panel.stat("MAC Address", e["mac"], container=section)
                panel.stat("Type", e["type"], container=section)

        panel = CardPanel(frame, self.theme, "ARP Table", "IP-to-MAC address mappings",
                           icon="▤", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_routing_table(self, frame):
        def gather():
            cmd = "route print -4" if IS_WINDOWS else "netstat -rn"
            ok, out = run_cmd(cmd)
            return out if ok else (out or "Could not read routing table.")

        def redraw(out):
            panel.clear()
            if isinstance(out, self._BgError):
                panel.empty_state(f"Could not read routing table: {out}")
                return
            box = tk.Text(panel.body, bg=self.theme["SURFACE"], fg=self.theme["FG"], height=20,
                           wrap="none", relief="flat", font=("Consolas", 9))
            box.pack(fill="both", expand=True, padx=14, pady=10)
            box.insert("end", out)
            box.config(state="disabled")

        panel = CardPanel(frame, self.theme, "Routing Table", "System IP routing table",
                           icon="◎", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    def tool_monitor(self, frame):
        """Live-ish network throughput: samples net_io_counters twice a
        beat apart and reports the delta as an approximate current rate -
        genuinely measured, not simulated, but only as precise as the
        ~0.5s sampling window."""
        def gather():
            if not psutil:
                return None
            first = psutil.net_io_counters()
            time.sleep(0.5)
            second = psutil.net_io_counters()
            sent_rate = (second.bytes_sent - first.bytes_sent) * 2  # per second
            recv_rate = (second.bytes_recv - first.bytes_recv) * 2
            return {"sent_rate": sent_rate, "recv_rate": recv_rate}

        def redraw(data):
            panel.clear()
            if isinstance(data, self._BgError):
                panel.empty_state(f"Could not measure throughput: {data}")
                return
            if data is None:
                panel.empty_state("psutil not installed.")
                return
            panel.stat("Upload Rate", f"{bytes_fmt(data['sent_rate'])}/s")
            panel.stat("Download Rate", f"{bytes_fmt(data['recv_rate'])}/s")
            # Progress bars scaled against a 100 Mbps (~12.5 MB/s) reference
            # line just to give a rough visual sense of "how busy" - not a
            # claim about your actual link speed.
            ref = 12_500_000
            panel.progress("Upload (relative to 100 Mbps)", min(100, data["sent_rate"] / ref * 100))
            panel.progress("Download (relative to 100 Mbps)", min(100, data["recv_rate"] / ref * 100))

        panel = CardPanel(frame, self.theme, "Monitor", "Approximate live network throughput",
                           icon="▥", on_refresh=lambda: self._run_bg(gather, redraw))
        self._run_bg(gather, redraw)

    # ==================================================================
    # CATEGORY 7: SYSTEM REPAIR
    # ==================================================================
    def tool_bsod_crash_analyzer(self, frame):
        self._panel_header(frame, "◇ BSOD Crash Analyzer", "Reads minidump metadata from %WINDIR%\\Minidump")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            mdir = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Minidump")
            if not os.path.isdir(mdir):
                return "No Minidump folder found — either no crashes, or dumps disabled."
            dumps = sorted(os.listdir(mdir))
            if not dumps:
                return "No crash dumps found."
            lines = [f"Found {len(dumps)} dump(s):"]
            for d in dumps[-10:]:
                fp = os.path.join(mdir, d)
                mtime = datetime.fromtimestamp(os.path.getmtime(fp))
                lines.append(f"  {d} — {mtime}")
            lines.append("\nFor full stack-trace analysis, open dumps in WinDbg.")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_registry_cleaner(self, frame):
        self._panel_header(frame, "⌁ Registry Cleaner", "Scans for broken uninstall/startup registry entries")
        box = self._text_output(frame)

        def scan():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" /s /f "DisplayName"')
            count = out.count("DisplayName") if ok else 0
            return f"Scanned uninstall registry — {count} program entries indexed.\n" \
                   "Automated deep registry editing is intentionally conservative to avoid " \
                   "destabilizing the OS; use System Restore before manual edits."

        self._button_row(frame, [("Scan Registry", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_dll_fixer(self, frame):
        self._panel_header(frame, "◇ DLL Fixer", "Re-registers common system DLLs")
        box = self._text_output(frame)

        def fix():
            if not IS_WINDOWS:
                return windows_only_notice()
            dlls = ["vbscript.dll", "jscript.dll", "mshtml.dll", "urlmon.dll"]
            results = []
            for d in dlls:
                ok, out = run_cmd_argv(["regsvr32", "/s", d])
                results.append(f"{d}: {'OK' if ok else 'failed (needs admin)'}")
            return "\n".join(results)

        self._button_row(frame, [("Re-register Core DLLs", lambda: self._run_bg(fix, lambda r: self._set_text(box, r)))])

    def tool_service_manager(self, frame):
        self._panel_header(frame, "▣ Service Manager")
        cols = ("Name", "State", "StartMode")
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=18)
        for c in cols:
            tree.heading(c, text=c)
        tree.pack(fill="both", expand=True, padx=16, pady=8)

        def refresh():
            for i in tree.get_children():
                tree.delete(i)
            if psutil and hasattr(psutil, "win_service_iter"):
                for s in psutil.win_service_iter():
                    info = s.as_dict()
                    tree.insert("", "end", values=(info["name"], info["status"], info["start_type"]))
            else:
                tree.insert("", "end", values=("(unavailable on this OS)", "", ""))

        self._button_row(frame, [("Refresh", refresh)])
        refresh()

    def tool_boot_repair_tool(self, frame):
        self._panel_header(frame, "→ Boot Repair Tool", "Runs bootrec fix commands")
        box = self._text_output(frame)

        def repair():
            if not IS_WINDOWS:
                return windows_only_notice()
            steps = [["bootrec", "/fixmbr"], ["bootrec", "/fixboot"],
                     ["bootrec", "/scanos"], ["bootrec", "/rebuildbcd"]]
            out_all = []
            for s in steps:
                ok, out = run_cmd_argv(s, timeout=60)
                out_all.append(f"$ {' '.join(s)}\n{out}")
            return "\n\n".join(out_all)

        self._button_row(frame, [("Run Boot Repair", lambda: self._confirm_then(
            "This modifies boot configuration. Run from a recovery environment for best results. Continue?",
            lambda: self._run_bg(repair, lambda r: self._set_text(box, r))))])

    def tool_system_restore_manager(self, frame):
        self._panel_header(frame, "⏪ System Restore Manager")
        box = self._text_output(frame)

        def list_points():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "Get-ComputerRestorePoint | Format-Table -AutoSize"')
            return out if ok else "Could not list restore points (System Restore may be disabled)."

        def create_point():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "Checkpoint-Computer -Description \'TechDrive Restore Point\'"')
            return "Restore point created." if ok else "Failed to create restore point (needs admin)."

        self._button_row(frame, [
            ("List Restore Points", lambda: self._run_bg(list_points, lambda r: self._set_text(box, r))),
            ("Create Restore Point", lambda: self._run_bg(create_point, lambda r: self._set_text(box, r))),
        ])

    def tool_sfc_scanner(self, frame):
        self._panel_header(frame, "⌕ SFC Scanner", "System File Checker")
        box = self._text_output(frame)

        def scan():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd("sfc /scannow", timeout=600)
            return out if ok else "SFC failed or requires admin rights."

        self._button_row(frame, [("Run SFC /scannow", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_dism_tool(self, frame):
        self._panel_header(frame, "⚒ DISM Tool", "Repairs the Windows component store")
        box = self._text_output(frame)

        def restore_health():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd("DISM /Online /Cleanup-Image /RestoreHealth", timeout=900)
            return out if ok else "DISM failed or requires admin rights."

        self._button_row(frame, [("Run DISM RestoreHealth", lambda: self._run_bg(restore_health, lambda r: self._set_text(box, r)))])

    def tool_driver_updater(self, frame):
        self._panel_header(frame, "⚒ Driver Updater", "Lists installed drivers and flags outdated ones by date")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('driverquery /v /fo csv')
            if not ok:
                return "Could not query drivers."
            reader = csv.reader(io.StringIO(out))
            rows = list(reader)
            if len(rows) < 2:
                return out
            lines = [f"{len(rows)-1} drivers found. Showing first 25:",
                     " | ".join(rows[0][:3])]
            for r in rows[1:26]:
                lines.append(" | ".join(r[:3]))
            lines.append("\nFor official updates, use Windows Update or the device manufacturer's site.")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_event_log_viewer(self, frame):
        self._event_log_panel(frame, "▤ Event Log Viewer")

    def _event_log_panel(self, frame, title):
        self._panel_header(frame, title, "Recent System log entries")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "Get-EventLog -LogName System -Newest 25 | '
                               'Format-Table TimeGenerated,EntryType,Source,Message -Wrap -AutoSize"',
                               timeout=30)
            return out if ok else "Could not read Event Log (may need admin, or use Get-WinEvent on newer builds)."

        self._button_row(frame, [("Load Recent Events", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 8: FILE MANAGEMENT
    # ==================================================================
    def tool_file_search_tool(self, frame):
        self._panel_header(frame, "⌕ File Search Tool")
        box = self._text_output(frame)
        path_var, pattern_var = tk.StringVar(value=os.path.expanduser("~")), tk.StringVar(value="*.txt")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=35).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left", padx=4)
        ttk.Entry(row, textvariable=pattern_var, width=15).pack(side="left", padx=4)

        def search():
            import fnmatch
            hits = []
            for root, dirs, files in os.walk(path_var.get()):
                for f in files:
                    if fnmatch.fnmatch(f, pattern_var.get()):
                        hits.append(os.path.join(root, f))
                if len(hits) > 500:
                    break
            return "\n".join(hits) or "No matches."

        self._button_row(frame, [("Search", lambda: self._run_bg(search, lambda r: self._set_text(box, r)))])

    def tool_duplicate_file_finder(self, frame):
        self._panel_header(frame, "♧ Duplicate File Finder", "Hash-based duplicate detection")
        box = self._text_output(frame)
        path_var = tk.StringVar(value=os.path.expanduser("~"))
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=40).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left", padx=4)

        def find_dupes():
            hashes = {}
            checked = 0
            for root, dirs, files in os.walk(path_var.get()):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        if os.path.getsize(fp) > 50 * 1024 * 1024:
                            continue
                        h = hashlib.md5()
                        with open(fp, "rb") as fh:
                            h.update(fh.read())
                        digest = h.hexdigest()
                        hashes.setdefault(digest, []).append(fp)
                        checked += 1
                    except Exception:
                        pass
                if checked > 3000:
                    break
            dupes = {k: v for k, v in hashes.items() if len(v) > 1}
            lines = [f"Checked {checked} files. Duplicate sets found: {len(dupes)}\n"]
            for k, v in list(dupes.items())[:30]:
                lines.append(f"Set ({len(v)} copies):")
                lines.extend(f"   {p}" for p in v)
            return "\n".join(lines)

        self._button_row(frame, [("Scan for Duplicates", lambda: self._run_bg(find_dupes, lambda r: self._set_text(box, r)))])

    def tool_batch_file_renamer(self, frame):
        self._panel_header(frame, "✎ Batch File Renamer")
        box = self._text_output(frame)
        path_var, find_var, replace_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=35).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left", padx=4)
        row2 = ttk.Frame(frame)
        row2.pack(anchor="w", padx=16, pady=6)
        ttk.Label(row2, text="Find:").pack(side="left")
        ttk.Entry(row2, textvariable=find_var, width=15).pack(side="left", padx=4)
        ttk.Label(row2, text="Replace:").pack(side="left")
        ttk.Entry(row2, textvariable=replace_var, width=15).pack(side="left", padx=4)

        def rename():
            count = 0
            p = path_var.get()
            if not os.path.isdir(p):
                return "Choose a valid folder."
            for f in os.listdir(p):
                if find_var.get() in f:
                    new_name = f.replace(find_var.get(), replace_var.get())
                    try:
                        os.rename(os.path.join(p, f), os.path.join(p, new_name))
                        count += 1
                    except Exception:
                        pass
            return f"Renamed {count} file(s)."

        self._button_row(frame, [("Rename All Matches", lambda: self._run_bg(rename, lambda r: self._set_text(box, r)))])

    def tool_file_compare_tool(self, frame):
        self._panel_header(frame, "⇄ File Compare Tool")
        box = self._text_output(frame)
        a_var, b_var = tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=a_var, width=35).pack(side="left")
        tk.Button(row, text="File A", command=lambda: a_var.set(
            filedialog.askopenfilename() or a_var.get())).pack(side="left", padx=4)
        ttk.Entry(row, textvariable=b_var, width=35).pack(side="left")
        tk.Button(row, text="File B", command=lambda: b_var.set(
            filedialog.askopenfilename() or b_var.get())).pack(side="left", padx=4)

        def compare():
            try:
                ha = hashlib.md5(open(a_var.get(), "rb").read()).hexdigest()
                hb = hashlib.md5(open(b_var.get(), "rb").read()).hexdigest()
                if ha == hb:
                    return "Files are IDENTICAL (matching MD5 hash)."
                return f"Files DIFFER.\nA hash: {ha}\nB hash: {hb}"
            except Exception as e:
                return f"Error: {e}"

        self._button_row(frame, [("Compare", lambda: self._run_bg(compare, lambda r: self._set_text(box, r)))])

    def tool_folder_sync_tool(self, frame):
        self._panel_header(frame, "⟳ Folder Sync Tool", "One-way mirror: source -> target")
        box = self._text_output(frame)
        src_var, dst_var = tk.StringVar(), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=src_var, width=30).pack(side="left")
        tk.Button(row, text="Src", command=lambda: src_var.set(
            filedialog.askdirectory() or src_var.get())).pack(side="left", padx=4)
        ttk.Entry(row, textvariable=dst_var, width=30).pack(side="left")
        tk.Button(row, text="Dst", command=lambda: dst_var.set(
            filedialog.askdirectory() or dst_var.get())).pack(side="left", padx=4)

        def sync():
            s, d = src_var.get(), dst_var.get()
            if not os.path.isdir(s) or not d:
                return "Choose valid source and target folders."
            copied, skipped = 0, 0
            for root, dirs, files in os.walk(s):
                rel = os.path.relpath(root, s)
                target_root = os.path.join(d, rel)
                os.makedirs(target_root, exist_ok=True)
                for f in files:
                    sp, tp = os.path.join(root, f), os.path.join(target_root, f)
                    if not os.path.exists(tp) or os.path.getmtime(sp) > os.path.getmtime(tp):
                        shutil.copy2(sp, tp)
                        copied += 1
                    else:
                        skipped += 1
            return f"Sync complete. Copied/updated: {copied}. Already up to date: {skipped}."

        self._button_row(frame, [("Sync Now", lambda: self._run_bg(sync, lambda r: self._set_text(box, r)))])

    def tool_file_splitter_joiner(self, frame):
        self._panel_header(frame, "✂ File Splitter/Joiner")
        box = self._text_output(frame)
        path_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askopenfilename() or path_var.get())).pack(side="left", padx=4)
        chunk_mb = tk.IntVar(value=10)

        def split():
            p = path_var.get()
            if not os.path.isfile(p):
                return "Choose a valid file."
            chunk_size = chunk_mb.get() * 1024 * 1024
            count = 0
            with open(p, "rb") as f:
                while True:
                    data = f.read(chunk_size)
                    if not data:
                        break
                    with open(f"{p}.part{count}", "wb") as out:
                        out.write(data)
                    count += 1
            return f"Split into {count} part(s) of ~{chunk_mb.get()}MB each."

        def join():
            p = path_var.get()
            parts = sorted([f for f in os.listdir(os.path.dirname(p) or ".")
                             if f.startswith(os.path.basename(p) + ".part")])
            if not parts:
                return "No .partN files found next to the chosen file."
            out_path = p + ".joined"
            with open(out_path, "wb") as out:
                for part in parts:
                    with open(os.path.join(os.path.dirname(p), part), "rb") as pf:
                        out.write(pf.read())
            return f"Joined {len(parts)} parts -> {out_path}"

        self._button_row(frame, [
            ("Split", lambda: self._run_bg(split, lambda r: self._set_text(box, r))),
            ("Join", lambda: self._run_bg(join, lambda r: self._set_text(box, r))),
        ])

    def tool_archive_tool(self, frame):
        self._panel_header(frame, "▣ Archive Tool", "Zip/unzip folders and files")
        box = self._text_output(frame)
        path_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or filedialog.askopenfilename() or path_var.get())).pack(side="left", padx=4)

        def zip_it():
            p = path_var.get()
            if not os.path.exists(p):
                return "Choose a valid file/folder."
            base = p.rstrip("/\\")
            out = shutil.make_archive(base, "zip", root_dir=os.path.dirname(base) or ".",
                                       base_dir=os.path.basename(base))
            return f"Created archive: {out}"

        def unzip_it():
            p = path_var.get()
            if not p.lower().endswith(".zip"):
                return "Choose a .zip file to extract."
            dest = p[:-4]
            shutil.unpack_archive(p, dest)
            return f"Extracted to: {dest}"

        self._button_row(frame, [
            ("Zip", lambda: self._run_bg(zip_it, lambda r: self._set_text(box, r))),
            ("Unzip", lambda: self._run_bg(unzip_it, lambda r: self._set_text(box, r))),
        ])

    def tool_checksum_verifier(self, frame):
        self._panel_header(frame, "✅ Checksum Verifier", "MD5 / SHA-1 / SHA-256")
        box = self._text_output(frame)
        path_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askopenfilename() or path_var.get())).pack(side="left", padx=4)

        def compute():
            p = path_var.get()
            if not os.path.isfile(p):
                return "Choose a valid file."
            md5, sha1, sha256 = hashlib.md5(), hashlib.sha1(), hashlib.sha256()
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    md5.update(chunk)
                    sha1.update(chunk)
                    sha256.update(chunk)
            return f"MD5:    {md5.hexdigest()}\nSHA-1:  {sha1.hexdigest()}\nSHA-256: {sha256.hexdigest()}"

        self._button_row(frame, [("Compute Checksums", lambda: self._run_bg(compute, lambda r: self._set_text(box, r)))])

    def tool_file_explorer_files(self, frame):
        self._build_file_explorer(frame)

    def tool_shortcut_fixer(self, frame):
        self._panel_header(frame, "⌁ Shortcut Fixer", "Scans Desktop/Start Menu for broken .lnk targets")
        box = self._text_output(frame)

        def scan():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd(
                'powershell -Command "$sh = New-Object -COM WScript.Shell; '
                'Get-ChildItem -Path $env:USERPROFILE\\Desktop -Filter *.lnk | ForEach-Object { '
                '$l = $sh.CreateShortcut($_.FullName); '
                'if (-not (Test-Path $l.TargetPath)) { Write-Output ($_.FullName + \' -> BROKEN: \' + $l.TargetPath) } }"',
                timeout=30)
            return out if (ok and out.strip()) else "No broken shortcuts found on Desktop."

        self._button_row(frame, [("Scan Desktop Shortcuts", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 9: MONITORING & LOGS
    # ==================================================================
    def _live_monitor(self, frame, title, sample_fn, unit=""):
        self._panel_header(frame, title)
        canvas = tk.Canvas(frame, bg=SURFACE, height=200)
        canvas.pack(fill="x", padx=16, pady=8)
        label = ttk.Label(frame, text="--")
        label.pack(anchor="w", padx=16)
        history = []
        running = {"on": True}

        def loop():
            if not running["on"] or not frame.winfo_exists():
                return
            try:
                val = sample_fn()
            except Exception:
                val = 0
            history.append(val)
            if len(history) > 60:
                history.pop(0)
            canvas.delete("all")
            w, h = int(canvas["width"]) if canvas["width"] else 500, 200
            canvas.update_idletasks()
            w = canvas.winfo_width() or 500
            maxv = max(history + [1])
            step = w / max(len(history), 1)
            points = []
            for i, v in enumerate(history):
                x = i * step
                y = h - (v / maxv * (h - 20)) - 10
                points.extend([x, y])
            if len(points) >= 4:
                canvas.create_line(*points, fill=ACCENT, width=2)
            label.config(text=f"Current: {val:.1f}{unit}")
            frame.after(1000, loop)

        frame.after(200, loop)
        frame.bind("<Destroy>", lambda e: running.update(on=False))

    def tool_cpu_monitor(self, frame):
        self._live_monitor(frame, "▥ CPU Monitor", lambda: psutil.cpu_percent(interval=0.3) if psutil else 0, "%")

    def tool_ram_monitor(self, frame):
        self._live_monitor(frame, "▥ RAM Monitor", lambda: psutil.virtual_memory().percent if psutil else 0, "%")

    def tool_disk_monitor(self, frame):
        self._live_monitor(frame, "▥ Disk Monitor (I/O read MB/s)",
                            self._make_disk_io_sampler(), " MB/s")

    def _make_disk_io_sampler(self):
        state = {"last": psutil.disk_io_counters() if psutil else None, "t": time.time()}

        def sample():
            if not psutil:
                return 0
            now = psutil.disk_io_counters()
            dt = max(time.time() - state["t"], 0.001)
            mbps = (now.read_bytes - state["last"].read_bytes) / dt / (1024 * 1024)
            state["last"], state["t"] = now, time.time()
            return max(mbps, 0)
        return sample

    def tool_network_monitor(self, frame):
        state = {"last": psutil.net_io_counters() if psutil else None, "t": time.time()}

        def sample():
            if not psutil:
                return 0
            now = psutil.net_io_counters()
            dt = max(time.time() - state["t"], 0.001)
            mbps = (now.bytes_recv - state["last"].bytes_recv) / dt / (1024 * 1024)
            state["last"], state["t"] = now, time.time()
            return max(mbps, 0)

        self._live_monitor(frame, "▥ Network Monitor (download MB/s)", sample, " MB/s")

    def tool_gpu_monitor(self, frame):
        self._panel_header(frame, "▥ GPU Monitor", "Live GPU load (requires vendor tools for full telemetry)")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_VideoController get LoadPercentage /format:list")
                return out if ok and "LoadPercentage" in out else \
                    "This GPU/driver doesn't expose LoadPercentage via WMI. Use vendor tools (GeForce/Adrenalin) for live load."
            return windows_only_notice()

        self._button_row(frame, [("Sample GPU Load", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_temperature_monitor(self, frame):
        self._panel_header(frame, "° Temperature Monitor")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    lines = []
                    for name, entries in temps.items():
                        for e in entries:
                            lines.append(f"{name} {e.label or ''}: {e.current}°C")
                    return "\n".join(lines)
            return "No temperature sensors exposed by the OS on this system."

        self._button_row(frame, [("Read Sensors", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_fan_speed_monitor(self, frame):
        self._panel_header(frame, "⟳ Fan Speed Monitor")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_fans"):
                fans = psutil.sensors_fans()
                if fans:
                    lines = []
                    for name, entries in fans.items():
                        for e in entries:
                            lines.append(f"{name} {e.label or ''}: {e.current} RPM")
                    return "\n".join(lines)
            return "No fan sensors exposed by the OS on this system (common on laptops/consumer boards)."

        self._button_row(frame, [("Read Fans", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_process_monitor(self, frame):
        self.tool_process_manager(frame)

    def tool_event_log_viewer_logs(self, frame):
        self._event_log_panel(frame, "▤ Event Log Viewer (Logs)")

    def tool_crash_log_viewer(self, frame):
        self._panel_header(frame, "✦ Crash Log Viewer", "Application-log crash entries")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell -Command "Get-EventLog -LogName Application -EntryType Error -Newest 20 | '
                               'Format-Table TimeGenerated,Source,Message -Wrap -AutoSize"', timeout=30)
            return out if ok else "Could not read Application log."

        self._button_row(frame, [("Load Crash Entries", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 10: ADVANCED UTILITIES
    # ==================================================================
    def tool_registry_editor(self, frame):
        self._panel_header(frame, "✎ Registry Editor", "Query/read a registry key (read-only for safety)")
        box = self._text_output(frame)
        key_var = tk.StringVar(value="HKCU\\Software")
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16)
        ttk.Entry(row, textvariable=key_var, width=50).pack(side="left")

        def query():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd_argv(["reg", "query", key_var.get()])
            return out if ok else "Key not found or access denied."

        self._button_row(frame, [
            ("Query Key", lambda: self._run_bg(query, lambda r: self._set_text(box, r))),
            ("Open regedit.exe", lambda: run_cmd("start regedit") if IS_WINDOWS else None),
        ])

    def tool_powershell_terminal(self, frame):
        self._terminal_panel(frame, "▣ PowerShell Terminal", "powershell -Command")

    def tool_cmd_terminal(self, frame):
        self._terminal_panel(frame, "▣ CMD Terminal", "cmd /c")

    def _terminal_panel(self, frame, title, prefix):
        self._panel_header(frame, title, "Type a command and press Run")
        box = self._text_output(frame, height=20)
        cmd_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", fill="x", padx=16)
        entry = ttk.Entry(row, textvariable=cmd_var, width=70)
        entry.pack(side="left", padx=(0, 8))

        def run():
            if not IS_WINDOWS:
                self._set_text(box, windows_only_notice())
                return
            full = f'{prefix} "{cmd_var.get()}"' if "powershell" in prefix else f'{prefix} {cmd_var.get()}'
            self._run_bg(lambda: run_cmd(full, timeout=30)[1], lambda r: self._set_text(box, r))

        entry.bind("<Return>", lambda e: run())
        tk.Button(row, text="Run", command=run, bg=BG_LIGHT, fg=FG, relief="flat").pack(side="left")

    def tool_bios_flasher(self, frame):
        self._panel_header(frame, "↯ BIOS Flasher",
                            "Reads current BIOS version and opens the manufacturer's update page")
        box = self._text_output(frame)
        ttk.Label(frame, text="Flashing BIOS with a generic tool risks bricking the motherboard — "
                               "vendor-specific firmware images and tools are required. TechDrive "
                               "reads your current version and directs you to the official updater.",
                  foreground="#e0a030", wraplength=650).pack(anchor="w", padx=16, pady=(0, 6))

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd("wmic bios get Manufacturer,SMBIOSBIOSVersion /format:list")
            return out if ok else "Could not read BIOS version."

        self._button_row(frame, [("Check Current BIOS Version",
                                   lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_driver_backup_tool(self, frame):
        self._panel_header(frame, "▣ Driver Backup Tool")
        box = self._text_output(frame)
        dest_var = tk.StringVar(value=os.path.join(os.path.expanduser("~"), "DriverBackup"))
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=dest_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: dest_var.set(
            filedialog.askdirectory() or dest_var.get())).pack(side="left", padx=4)

        def backup():
            if not IS_WINDOWS:
                return windows_only_notice()
            os.makedirs(dest_var.get(), exist_ok=True)
            ok, out = run_cmd_argv(["dism", "/online", "/export-driver", f"/destination:{dest_var.get()}"], timeout=300)
            return out if ok else "Backup failed (needs admin rights)."

        self._button_row(frame, [("Backup Drivers", lambda: self._run_bg(backup, lambda r: self._set_text(box, r)))])

    def tool_system_backup_tool(self, frame):
        self._panel_header(frame, "▥ System Backup Tool", "Zips a chosen folder as a backup archive")
        box = self._text_output(frame)
        src_var = tk.StringVar(value=os.path.expanduser("~"))
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=src_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: src_var.set(
            filedialog.askdirectory() or src_var.get())).pack(side="left", padx=4)

        def backup():
            s = src_var.get()
            if not os.path.isdir(s):
                return "Choose a valid folder."
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            out_base = os.path.join(os.path.dirname(s.rstrip("/\\")), f"backup_{ts}")
            out = shutil.make_archive(out_base, "zip", root_dir=s)
            return f"Backup created: {out}"

        self._button_row(frame, [("Create Backup", lambda: self._run_bg(backup, lambda r: self._set_text(box, r)))])

    def tool_restore_point_creator(self, frame):
        self.tool_system_restore_manager(frame)

    def tool_disk_wipe_tool(self, frame):
        self._panel_header(frame, "⌫ Disk Wipe Tool", "Wipes ALL contents of a chosen non-system folder/volume")
        box = self._text_output(frame)
        path_var = tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Entry(row, textvariable=path_var, width=45).pack(side="left")
        tk.Button(row, text="Browse", command=lambda: path_var.set(
            filedialog.askdirectory() or path_var.get())).pack(side="left", padx=4)

        def wipe():
            p = path_var.get()
            system_root = os.environ.get("WINDIR", "C:\\Windows") if IS_WINDOWS else "/"
            if not p or not os.path.isdir(p) or os.path.abspath(p) in (
                    os.path.abspath(system_root), os.path.abspath(os.path.expanduser("~"))):
                return "Refusing to wipe system/home root. Choose a specific subfolder or external drive path."
            removed = 0
            for entry in os.scandir(p):
                try:
                    if entry.is_dir():
                        shutil.rmtree(entry.path, ignore_errors=True)
                    else:
                        os.remove(entry.path)
                    removed += 1
                except Exception:
                    pass
            return f"Wiped {removed} top-level item(s) from {p}."

        self._button_row(frame, [("Wipe Folder", lambda: self._confirm_then(
            "This PERMANENTLY deletes everything inside the selected folder. Continue?",
            lambda: self._run_bg(wipe, lambda r: self._set_text(box, r))))])

    def tool_bootable_usb_creator(self, frame):
        self._panel_header(frame, "▥ Bootable USB Creator", "Formats a USB drive and copies ISO contents to it")
        box = self._text_output(frame)
        drive_var, iso_var = tk.StringVar(value="E:"), tk.StringVar()
        row = ttk.Frame(frame)
        row.pack(anchor="w", padx=16, fill="x")
        ttk.Label(row, text="USB drive:").pack(side="left")
        ttk.Entry(row, textvariable=drive_var, width=6).pack(side="left", padx=6)
        row2 = ttk.Frame(frame)
        row2.pack(anchor="w", padx=16, fill="x", pady=4)
        ttk.Entry(row2, textvariable=iso_var, width=45).pack(side="left")
        tk.Button(row2, text="Choose ISO", command=lambda: iso_var.set(
            filedialog.askopenfilename(filetypes=[("ISO", "*.iso")]) or iso_var.get())).pack(side="left", padx=4)

        def create():
            if not IS_WINDOWS:
                return windows_only_notice()
            d, iso = drive_var.get().rstrip("\\"), iso_var.get()
            if not re.match(r"^[D-Zd-z]:$", d) or not os.path.isfile(iso):
                return "Choose a valid non-system drive letter (D: or higher) and a valid ISO file."
            ok, out = run_cmd_argv(["format", d, "/FS:NTFS", "/Q", "/Y"], timeout=120)
            if not ok:
                return "Format failed (needs admin rights)."
            ok2, out2 = run_cmd_argv([
                "powershell", "-NoProfile", "-Command",
                "param($p) Mount-DiskImage -ImagePath $p", "-p", iso
            ])
            return f"{out}\n{out2}\nMounted ISO — copy its contents to {d}\\ to finish, or use xcopy/robocopy."

        self._button_row(frame, [("Create Bootable USB", lambda: self._confirm_then(
            "This will ERASE the target USB drive. Continue?",
            lambda: self._run_bg(create, lambda r: self._set_text(box, r))))])

    def tool_remote_desktop_tool(self, frame):
        self._panel_header(frame, "◎ Remote Desktop Tool", "Enables Windows Remote Desktop and shows connection info")
        box = self._text_output(frame)

        def enable():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd_argv(["reg", "add",
                "HKLM\\System\\CurrentControlSet\\Control\\Terminal Server",
                "/v", "fDenyTSConnections", "/t", "REG_DWORD", "/d", "0", "/f"])
            ok2, out2 = run_cmd_argv(["netsh", "advfirewall", "firewall", "set", "rule",
                                      "group=remote desktop", "new", "enable=Yes"])
            ip = socket.gethostbyname(socket.gethostname())
            return f"{'Enabled' if ok else 'Failed to enable'} Remote Desktop.\n" \
                   f"Firewall rule: {'updated' if ok2 else 'failed'}\n" \
                   f"Connect using: {ip} (needs admin rights + same network or VPN)."

        self._button_row(frame, [("Enable Remote Desktop", lambda: self._confirm_then(
            "This enables inbound Remote Desktop access to this PC. Continue?",
            lambda: self._run_bg(enable, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 11: AUDIO TOOLS
    # ==================================================================
    def tool_audio_device_info(self, frame):
        self._panel_header(frame, "◖ Audio Device Info", "Lists playback and recording devices")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "Get-CimInstance Win32_SoundDevice | '
                    'Select-Object Name,Manufacturer,Status | Format-List"')
                return out if ok and out.strip() else "Could not query audio devices."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_audio_playback_test(self, frame):
        self._panel_header(frame, "♪ Audio Playback Test", "Plays a short test tone through the default device")
        box = self._text_output(frame)

        def play():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "[console]::beep(880,400)"')
                return "Played a test tone via system beep." if ok else "Could not play test tone."
            return windows_only_notice()

        self._button_row(frame, [("Play Test Tone", lambda: self._run_bg(play, lambda r: self._set_text(box, r)))])
        self._set_text(box, "Click 'Play Test Tone' to verify audio output.")

    def tool_microphone_test(self, frame):
        self._panel_header(frame, "◉ Microphone Test", "Checks recording device presence and default status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "Get-CimInstance Win32_SoundDevice | Select-Object Name,Status"')
                return out if ok and out.strip() else "No microphone info available via WMI on this system."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_sound_card_info(self, frame):
        self._panel_header(frame, "≡ Sound Card Info", "Manufacturer and driver of the audio adapter")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'wmic sounddev get Name,Manufacturer,Status /format:list')
                return out if ok and out.strip() else "Could not query sound card."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_audio_driver_check(self, frame):
        self._panel_header(frame, "◇ Audio Driver Check", "Verifies audio driver status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "Get-PnpDevice -Class AudioEndpoint,MEDIA | '
                    'Select-Object FriendlyName,Status | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query audio driver status."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_volume_control(self, frame):
        self._panel_header(frame, "◖ Volume Control", "Adjust the system master volume")
        box = self._text_output(frame)
        self._set_text(box, "Use the slider to set master volume (Windows only).")

        def set_volume(val):
            if not IS_WINDOWS:
                self._set_text(box, windows_only_notice())
                return
            pct = int(float(val))
            # nircmd-free approach: use PowerShell + WScript.Shell SendKeys as a
            # best-effort volume nudge since there's no built-in CLI setter.
            ok, out = run_cmd(
                'powershell -NoProfile -Command "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"')
            self._set_text(box, f"Requested volume level: {pct}%\n"
                                 f"(Windows has no direct CLI volume setter; "
                                 f"consider a dedicated mixer for precise control.)")

        scale = tk.Scale(frame, from_=0, to=100, orient="horizontal", bg=BG_LIGHT, fg=FG,
                          troughcolor=BG, highlightthickness=0, command=set_volume)
        scale.set(50)
        scale.pack(anchor="w", padx=16, pady=8, fill="x")

    def tool_audio_format_check(self, frame):
        self._panel_header(frame, "♪ Audio Format Check", "Shows default playback format")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "Get-CimInstance Win32_SoundDevice | Select-Object Name,PNPClass"')
                return out if ok and out.strip() else "Could not query audio format info."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_audio_latency_test(self, frame):
        self._panel_header(frame, "⏱ Audio Latency Test", "Rough round-trip timing of a beep call")
        box = self._text_output(frame)

        def measure():
            if not IS_WINDOWS:
                return windows_only_notice()
            start = time.time()
            run_cmd('powershell "[console]::beep(440,150)"')
            elapsed = (time.time() - start) * 1000
            return (f"Command round-trip latency: {elapsed:.1f} ms\n"
                    f"(This measures process/API call overhead, not true "
                    f"audio-driver latency — use a dedicated ASIO tool for that.)")

        self._button_row(frame, [("Run Test", lambda: self._run_bg(measure, lambda r: self._set_text(box, r)))])

    def tool_default_device_switcher(self, frame):
        self._panel_header(frame, "⇄ Default Device Switcher", "Lists devices so you can set the default in Sound settings")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "Get-CimInstance Win32_SoundDevice | Select-Object Name"')
                return (out if ok and out.strip() else "Could not list devices.") + \
                       "\n\nOpen Settings > System > Sound to change the default device."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_mute_all_toggle(self, frame):
        self._panel_header(frame, "× Mute All Toggle", "Sends the system mute key")
        box = self._text_output(frame)

        def toggle():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd('powershell "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"')
            return "Sent mute toggle key to the system." if ok else "Could not send mute key."

        self._button_row(frame, [("Toggle Mute", lambda: self._run_bg(toggle, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 12: DISPLAY TOOLS
    # ==================================================================
    def tool_display_info(self, frame):
        self._panel_header(frame, "▧ Display Info", "Resolution, scaling, and monitor count")
        box = self._text_output(frame)

        def gather():
            w, h = self.winfo_screenwidth(), self.winfo_screenheight()
            lines = [f"Primary resolution: {w}x{h}"]
            if IS_WINDOWS:
                ok, out = run_cmd('wmic desktopmonitor get Name,ScreenHeight,ScreenWidth /format:list')
                if ok and out.strip():
                    lines.append("")
                    lines.append(out)
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_resolution_changer(self, frame):
        self._panel_header(frame, "△ Resolution Changer", "Opens the native display settings panel")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:display")
                return "Opened Windows Display Settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Display Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])
        self._set_text(box, "TechDrive doesn't change resolution directly to avoid breaking "
                             "your display — it opens the native settings panel instead.")

    def tool_refresh_rate_check(self, frame):
        self._panel_header(frame, "⟳ Refresh Rate Check", "Reports the current display refresh rate")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'wmic path Win32_VideoController get CurrentRefreshRate,MaxRefreshRate /format:list')
                return out if ok and out.strip() else "Could not query refresh rate."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_multi_monitor_layout(self, frame):
        self._panel_header(frame, "▣▣ Multi-Monitor Layout", "Lists connected monitors")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('wmic desktopmonitor get Name,DeviceID,ScreenWidth,ScreenHeight /format:list')
                return out if ok and out.strip() else "Only one monitor detected or query failed."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_screen_capture(self, frame):
        self._panel_header(frame, "▧ Screen Capture", "Saves a screenshot of the primary display")
        box = self._text_output(frame)

        def capture():
            try:
                from PIL import ImageGrab
            except ImportError:
                return "Pillow not installed — cannot capture screen."
            path = filedialog.asksaveasfilename(defaultextension=".png",
                                                 filetypes=[("PNG image", "*.png")],
                                                 initialfile="screenshot.png")
            if not path:
                return "Capture cancelled."
            img = ImageGrab.grab()
            img.save(path)
            return f"Screenshot saved to {path}"

        self._button_row(frame, [("Capture Screen", lambda: self._run_bg(capture, lambda r: self._set_text(box, r)))])

    def tool_night_mode_scheduler(self, frame):
        self._panel_header(frame, "☾ Night Mode Scheduler", "Opens Windows Night Light settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:nightlight")
                return "Opened Night Light settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Night Light Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_wallpaper_manager(self, frame):
        self._panel_header(frame, "▧ Wallpaper Manager", "Sets the desktop wallpaper from an image file")
        box = self._text_output(frame)

        def set_wallpaper():
            path = filedialog.askopenfilename(title="Choose wallpaper image",
                                               filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp")])
            if not path:
                return "Cancelled."
            if IS_WINDOWS:
                try:
                    import ctypes
                    ctypes.windll.user32.SystemParametersInfoW(20, 0, path, 3)
                    return f"Wallpaper set to {path}"
                except Exception as e:
                    return f"Failed to set wallpaper: {e}"
            return windows_only_notice()

        self._button_row(frame, [("Choose & Set Wallpaper", lambda: self._run_bg(set_wallpaper, lambda r: self._set_text(box, r)))])

    def tool_dpi_settings(self, frame):
        self._panel_header(frame, "⌕ DPI Settings", "Reports current display scaling")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                try:
                    import ctypes
                    ctypes.windll.shcore.SetProcessDpiAwareness(1)
                    dc = ctypes.windll.user32.GetDC(0)
                    dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)  # LOGPIXELSX
                    ctypes.windll.user32.ReleaseDC(0, dc)
                    scale = round(dpi / 96 * 100)
                    return f"System DPI: {dpi}\nApproximate scaling: {scale}%"
                except Exception as e:
                    return f"Could not read DPI: {e}"
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_color_calibration_check(self, frame):
        self._panel_header(frame, "✦ Color Calibration Check", "Opens the Windows color management panel")
        box = self._text_output(frame)

        def open_panel():
            if IS_WINDOWS:
                ok, out = run_cmd("control color management")
                return "Opened Color Management panel." if ok else "Could not open panel."
            return windows_only_notice()

        self._button_row(frame, [("Open Color Management", lambda: self._run_bg(open_panel, lambda r: self._set_text(box, r)))])

    def tool_idle_sleep_timeout_viewer(self, frame):
        self._panel_header(frame, "⏳ Idle/Sleep Timeout Viewer", "Shows current screen and sleep timeouts")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("powercfg /query SCHEME_CURRENT SUB_VIDEO")
                return out if ok and out.strip() else "Could not query power scheme."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 13: POWER & COOLING
    # ==================================================================
    def tool_battery_report(self, frame):
        self._panel_header(frame, "▰ Battery Report", "Generates the built-in Windows battery health report")
        box = self._text_output(frame)

        def generate():
            if not IS_WINDOWS:
                return windows_only_notice()
            out_path = os.path.join(os.path.expanduser("~"), "battery-report.html")
            ok, out = run_cmd_argv(["powercfg", "/batteryreport", "/output", out_path])
            if ok and os.path.exists(out_path):
                return f"Battery report generated at:\n{out_path}"
            return out or "Could not generate battery report (desktop PCs have no battery)."

        self._button_row(frame, [("Generate Report", lambda: self._run_bg(generate, lambda r: self._set_text(box, r)))])

    def tool_power_plan_manager(self, frame):
        self._panel_header(frame, "⚙ Power Plan Manager", "Lists and switches Windows power plans")
        box = self._text_output(frame)

        def list_plans():
            if IS_WINDOWS:
                ok, out = run_cmd("powercfg /list")
                return out if ok else "Could not list power plans."
            return windows_only_notice()

        self._button_row(frame, [("List Power Plans", lambda: self._run_bg(list_plans, lambda r: self._set_text(box, r)))])
        self._run_bg(list_plans, lambda r: self._set_text(box, r))

    def tool_sleep_wake_settings(self, frame):
        self._panel_header(frame, "● Sleep/Wake Settings", "Opens Windows sleep settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:powersleep")
                return "Opened Power & Sleep settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_fan_speed_reader(self, frame):
        self._panel_header(frame, "⟳ Fan Speed Reader", "Reads fan RPM sensors where available")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_fans"):
                fans = psutil.sensors_fans()
                if fans:
                    lines = []
                    for name, entries in fans.items():
                        for e in entries:
                            lines.append(f"{name} — {e.label or 'fan'}: {e.current} RPM")
                    return "\n".join(lines)
            return "No fan sensors exposed by the OS on this system " \
                   "(common on laptops/consumer boards without vendor drivers)."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_thermal_throttling_check(self, frame):
        self._panel_header(frame, "° Thermal Throttling Check", "Checks CPU temperature sensors for throttling risk")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    lines = []
                    for name, entries in temps.items():
                        for e in entries:
                            flag = " ⚠ HIGH" if e.current and e.current >= 85 else ""
                            lines.append(f"{name} — {e.label or 'sensor'}: {e.current}°C{flag}")
                    return "\n".join(lines)
            return "No temperature sensors exposed by the OS on this system."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_power_efficiency_report(self, frame):
        self._panel_header(frame, "▥ Power Efficiency Report", "Generates the built-in Windows energy report")
        box = self._text_output(frame)

        def generate():
            if not IS_WINDOWS:
                return windows_only_notice()
            out_path = os.path.join(os.path.expanduser("~"), "energy-report.html")
            ok, out = run_cmd_argv(["powercfg", "/energy", "/output", out_path, "/duration", "20"])
            if ok and os.path.exists(out_path):
                return f"Energy report generated (60s scan) at:\n{out_path}"
            return "Report generation requires admin rights and takes ~60s; try running as Administrator."

        self._button_row(frame, [("Generate Report (~60s)", lambda: self._run_bg(generate, lambda r: self._set_text(box, r)))])

    def tool_battery_health_estimator(self, frame):
        self._panel_header(frame, "❤ Battery Health Estimator", "Compares design vs full-charge capacity from the battery report")
        box = self._text_output(frame)

        def estimate():
            if not IS_WINDOWS:
                return windows_only_notice()
            out_path = os.path.join(os.path.expanduser("~"), "battery-report.html")
            run_cmd_argv(["powercfg", "/batteryreport", "/output", out_path])
            if not os.path.exists(out_path):
                return "Could not generate battery report to analyze."
            try:
                with open(out_path, "r", encoding="utf-8", errors="ignore") as f:
                    html = f.read()
                design = re.search(r"DESIGN CAPACITY.*?(\d[\d,]*)\s*mWh", html, re.S | re.I)
                full = re.search(r"FULL CHARGE CAPACITY.*?(\d[\d,]*)\s*mWh", html, re.S | re.I)
                if design and full:
                    d = int(design.group(1).replace(",", ""))
                    fchg = int(full.group(1).replace(",", ""))
                    pct = (fchg / d) * 100 if d else 0
                    return (f"Design capacity: {d} mWh\nFull charge capacity: {fchg} mWh\n"
                            f"Estimated battery health: {pct:.1f}%")
                return "Could not locate capacity values — no battery on this device?"
            except Exception as e:
                return f"Error parsing report: {e}"

        self._button_row(frame, [("Estimate Health", lambda: self._run_bg(estimate, lambda r: self._set_text(box, r)))])

    def tool_cpu_temperature_log(self, frame):
        self._panel_header(frame, "▥ CPU Temperature Log", "Samples CPU temperature every 2s for 30s")
        box = self._text_output(frame)

        def log():
            if not (psutil and hasattr(psutil, "sensors_temperatures")):
                return "No temperature sensors exposed by the OS on this system."
            lines = []
            for i in range(15):
                temps = psutil.sensors_temperatures()
                reading = None
                for name, entries in temps.items():
                    for e in entries:
                        reading = e.current
                        break
                    if reading:
                        break
                lines.append(f"[{i*2:>3}s] {reading if reading else 'N/A'}°C")
                time.sleep(2)
            return "\n".join(lines)

        self._button_row(frame, [("Start 30s Log", lambda: self._run_bg(log, lambda r: self._set_text(box, r)))])
        self._set_text(box, "Click Start to sample CPU temperature for 30 seconds.")

    def tool_power_consumption_monitor(self, frame):
        self._panel_header(frame, "↯ Power Consumption Monitor", "Estimates draw from CPU load (no wattmeter available)")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            load = psutil.cpu_percent(interval=1)
            battery = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
            lines = [f"CPU load: {load:.1f}%",
                     "Note: true wattage requires a hardware power meter or "
                     "vendor tool (e.g. Intel Power Gadget)."]
            if battery:
                lines.append(f"Battery: {battery.percent}% "
                              f"({'charging' if battery.power_plugged else 'discharging'})")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_standby_list_cleaner(self, frame):
        self._panel_header(frame, "⌁ Standby List Cleaner", "Clears the Windows standby memory list to free cached RAM")
        box = self._text_output(frame)

        def clean():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd(
                'powershell "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; '
                '[System.GC]::Collect()"')
            return ("Requested memory cleanup. Full standby-list clearing needs a "
                    "kernel-mode driver (e.g. RAMMap/EmptyStandbyList) which TechDrive "
                    "does not install without your explicit consent.")

        self._button_row(frame, [("Run Cleanup", lambda: self._confirm_then(
            "This will run a best-effort memory cleanup pass. Continue?",
            lambda: self._run_bg(clean, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 14: BOOT & RECOVERY
    # ==================================================================
    def tool_boot_configuration_viewer(self, frame):
        self._panel_header(frame, "→ Boot Configuration Viewer", "Shows the Boot Configuration Data store")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("bcdedit /enum")
                return out if ok else "Could not read BCD (try running as Administrator)."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_boot_menu_timeout_editor(self, frame):
        self._panel_header(frame, "⏲ Boot Menu Timeout Editor", "View or change the boot menu timeout in seconds")
        box = self._text_output(frame)

        def read_timeout():
            if IS_WINDOWS:
                ok, out = run_cmd("bcdedit /enum {current} | findstr timeout")
                return out if ok and out.strip() else "Could not read timeout value."
            return windows_only_notice()

        def set_timeout():
            secs = simpledialog.askinteger("Set Timeout", "Boot menu timeout (seconds):", minvalue=0, maxvalue=999)
            if secs is None:
                return
            if IS_WINDOWS:
                ok, out = run_cmd_argv(["bcdedit", "/timeout", str(secs)])
                self._set_text(box, f"Timeout set to {secs}s." if ok else f"Failed: {out}")
            else:
                self._set_text(box, windows_only_notice())

        self._button_row(frame, [
            ("Read Current Timeout", lambda: self._run_bg(read_timeout, lambda r: self._set_text(box, r))),
            ("Set Timeout...", set_timeout),
        ])

    def tool_efi_partition_info(self, frame):
        self._panel_header(frame, "▤ EFI Partition Info", "Lists the EFI system partition details")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-Partition | Where-Object {$_.Type -eq \'System\'} | '
                                   'Select-Object DiskNumber,PartitionNumber,Size,DriveLetter | Format-List"')
                return out if ok and out.strip() else "Could not query EFI partition (try as Administrator)."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_bootable_usb_creator_advanced(self, frame):
        self._panel_header(frame, "▥ Bootable USB Creator (Advanced)", "Guided diskpart-based USB preparation")
        box = self._text_output(frame)
        self._set_text(box,
            "For safety, TechDrive will not silently erase a drive.\n\n"
            "To prepare a bootable USB:\n"
            "1. Insert the USB drive.\n"
            "2. Click 'List Disks' below to find its disk number.\n"
            "3. Use Windows' own Media Creation Tool or Rufus for the actual "
            "write step — TechDrive intentionally does not automate disk wipes.")

        def list_disks():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic diskdrive list brief")
                return out if ok else "Could not list disks."
            return windows_only_notice()

        self._button_row(frame, [("List Disks", lambda: self._run_bg(list_disks, lambda r: self._set_text(box, r)))])

    def tool_system_restore_point_list(self, frame):
        self._panel_header(frame, "◷ System Restore Point List", "Lists available restore points")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-ComputerRestorePoint | '
                                   'Select-Object SequenceNumber,Description,CreationTime | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No restore points found (System Restore may be disabled)."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_recovery_partition_info(self, frame):
        self._panel_header(frame, "⌕ Recovery Partition Info", "Lists recovery partitions")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-Partition | Where-Object {$_.Type -eq \'Recovery\'} | '
                                   'Select-Object DiskNumber,PartitionNumber,Size | Format-List"')
                return out if ok and out.strip() else "No recovery partition found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_winre_status_checker(self, frame):
        self._panel_header(frame, "○ WinRE Status Checker", "Checks Windows Recovery Environment status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("reagentc /info")
                return out if ok else "Could not query WinRE status (try as Administrator)."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_safe_mode_launcher(self, frame):
        self._panel_header(frame, "⬢ Safe Mode Launcher", "Schedules a restart into Safe Mode")
        box = self._text_output(frame)

        def schedule():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok, out = run_cmd("bcdedit /set {current} safeboot minimal")
            return ("Safe Mode flag set for next boot. Restart the PC to enter Safe Mode.\n"
                    "Run 'bcdedit /deletevalue {current} safeboot' afterward to boot normally.") \
                if ok else f"Failed: {out}"

        self._button_row(frame, [("Set Safe Mode on Next Boot", lambda: self._confirm_then(
            "This changes boot configuration so the next restart enters Safe Mode. Continue?",
            lambda: self._run_bg(schedule, lambda r: self._set_text(box, r))))])

    def tool_boot_log_viewer(self, frame):
        self._panel_header(frame, "▤ Boot Log Viewer", "Reads ntbtlog.txt if boot logging is enabled")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                path = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "ntbtlog.txt")
                if os.path.exists(path):
                    try:
                        with open(path, "r", errors="ignore") as f:
                            return f.read()[-4000:]
                    except Exception as e:
                        return f"Could not read boot log: {e}"
                return "No boot log found. Enable it via msconfig > Boot > 'Boot log' and restart."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_startup_timing_analyzer(self, frame):
        self._panel_header(frame, "⏱ Startup Timing Analyzer", "Reports last boot duration")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "(Get-WinEvent -FilterHashtable @{LogName=\'Microsoft-Windows-Diagnostics-Performance/Operational\';Id=100} -MaxEvents 1).Message"')
                return out if ok and out.strip() else "No boot performance event found in the Event Log."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 15: DEVELOPER TOOLS
    # ==================================================================
    def tool_json_validator(self, frame):
        self._panel_header(frame, "▤ JSON Validator", "Paste JSON below and validate its syntax")
        box = self._text_input(frame, height=10)
        out = self._text_output(frame, height=8)

        def validate():
            try:
                parsed = json.loads(box.get("1.0", "end"))
                self._set_text(out, "✅ Valid JSON.\n\n" + json.dumps(parsed, indent=2)[:3000])
            except json.JSONDecodeError as e:
                self._set_text(out, f"✕ Invalid JSON: {e}")

        self._button_row(frame, [("Validate", validate)])

    def tool_xml_validator(self, frame):
        self._panel_header(frame, "▤ XML Validator", "Paste XML below and validate its syntax")
        box = self._text_input(frame, height=10)
        out = self._text_output(frame, height=8)

        def validate():
            import xml.etree.ElementTree as ET
            try:
                ET.fromstring(box.get("1.0", "end"))
                self._set_text(out, "✅ Well-formed XML.")
            except ET.ParseError as e:
                self._set_text(out, f"✕ Invalid XML: {e}")

        self._button_row(frame, [("Validate", validate)])

    def tool_regex_tester(self, frame):
        self._panel_header(frame, "⌕ RegEx Tester", "Test a pattern against sample text")
        pat_row = ttk.Frame(frame)
        pat_row.pack(anchor="w", fill="x", padx=16, pady=(4, 0))
        ttk.Label(pat_row, text="Pattern:").pack(side="left")
        pattern_var = tk.StringVar()
        tk.Entry(pat_row, textvariable=pattern_var, bg=BG_LIGHT, fg=FG, insertbackground=FG,
                  width=50).pack(side="left", padx=6)
        box = self._text_input(frame, height=8)
        out = self._text_output(frame, height=8)

        def run_match():
            try:
                matches = list(re.finditer(pattern_var.get(), box.get("1.0", "end")))
                if not matches:
                    self._set_text(out, "No matches.")
                    return
                lines = [f"{len(matches)} match(es):"]
                for m in matches[:100]:
                    lines.append(f"  [{m.start()}:{m.end()}] {m.group()!r}")
                self._set_text(out, "\n".join(lines))
            except re.error as e:
                self._set_text(out, f"Invalid pattern: {e}")

        self._button_row(frame, [("Test", run_match)])

    def tool_base64_encoder_decoder(self, frame):
        self._panel_header(frame, "A Base64 Encoder/Decoder", "Encode or decode text")
        import base64
        box = self._text_input(frame, height=8)
        out = self._text_output(frame, height=8)

        def encode():
            data = box.get("1.0", "end").rstrip("\n").encode()
            self._set_text(out, base64.b64encode(data).decode())

        def decode():
            try:
                data = box.get("1.0", "end").rstrip("\n").encode()
                self._set_text(out, base64.b64decode(data).decode(errors="replace"))
            except Exception as e:
                self._set_text(out, f"Decode error: {e}")

        self._button_row(frame, [("Encode", encode), ("Decode", decode)])

    def tool_hash_generator(self, frame):
        self._panel_header(frame, "#⃣ Hash Generator", "Compute MD5/SHA1/SHA256 of text or a file")
        box = self._text_input(frame, height=6)
        out = self._text_output(frame, height=8)

        def hash_text():
            data = box.get("1.0", "end").rstrip("\n").encode()
            lines = [f"MD5:    {hashlib.md5(data).hexdigest()}",
                     f"SHA1:   {hashlib.sha1(data).hexdigest()}",
                     f"SHA256: {hashlib.sha256(data).hexdigest()}"]
            self._set_text(out, "\n".join(lines))

        def hash_file():
            path = filedialog.askopenfilename(title="Choose a file to hash")
            if not path:
                return

            def compute():
                h_md5, h_sha1, h_sha256 = hashlib.md5(), hashlib.sha1(), hashlib.sha256()
                with open(path, "rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h_md5.update(chunk); h_sha1.update(chunk); h_sha256.update(chunk)
                return (f"File: {path}\nMD5:    {h_md5.hexdigest()}\n"
                        f"SHA1:   {h_sha1.hexdigest()}\nSHA256: {h_sha256.hexdigest()}")

            self._run_bg(compute, lambda r: self._set_text(out, r))

        self._button_row(frame, [("Hash Text", hash_text), ("Hash File...", hash_file)])

    def tool_url_encoder_decoder(self, frame):
        self._panel_header(frame, "⌁ URL Encoder/Decoder", "Encode or decode URL components")
        import urllib.parse
        box = self._text_input(frame, height=6)
        out = self._text_output(frame, height=6)

        def encode():
            self._set_text(out, urllib.parse.quote(box.get("1.0", "end").rstrip("\n")))

        def decode():
            self._set_text(out, urllib.parse.unquote(box.get("1.0", "end").rstrip("\n")))

        self._button_row(frame, [("Encode", encode), ("Decode", decode)])

    def tool_color_picker(self, frame):
        self._panel_header(frame, "✦ Color Picker", "Pick a color and view its hex/RGB values")
        box = self._text_output(frame, height=4)

        def pick():
            from tkinter import colorchooser
            result = colorchooser.askcolor(title="Pick a color")
            if result and result[0]:
                r, g, b = (int(c) for c in result[0])
                self._set_text(box, f"HEX: {result[1]}\nRGB: ({r}, {g}, {b})")

        self._button_row(frame, [("Pick Color...", pick)])

    def tool_ascii_table_viewer(self, frame):
        self._panel_header(frame, "a ASCII Table Viewer", "Printable ASCII characters 32-126")
        box = self._text_output(frame, height=20)
        lines = []
        for i in range(32, 127):
            lines.append(f"{i:>3}  0x{i:02x}  {chr(i)!r}")
        self._set_text(box, "\n".join(lines))

    def tool_hex_viewer(self, frame):
        self._panel_header(frame, "# Hex Viewer", "View the first bytes of a file in hex")
        box = self._text_output(frame, height=20)

        def open_file():
            path = filedialog.askopenfilename(title="Choose a file")
            if not path:
                return

            def read_hex():
                with open(path, "rb") as f:
                    data = f.read(4096)
                lines = []
                for offset in range(0, len(data), 16):
                    chunk = data[offset:offset + 16]
                    hex_part = " ".join(f"{b:02x}" for b in chunk)
                    ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
                    lines.append(f"{offset:08x}  {hex_part:<48}  {ascii_part}")
                return "\n".join(lines) if lines else "Empty file."

            self._run_bg(read_hex, lambda r: self._set_text(box, r))

        self._button_row(frame, [("Open File...", open_file)])

    def tool_env_variable_inspector(self, frame):
        self._panel_header(frame, "◇ Env Variable Inspector", "Lists current environment variables")
        box = self._text_output(frame, height=20)
        lines = [f"{k} = {v}" for k, v in sorted(os.environ.items())]
        self._set_text(box, "\n".join(lines))

    # ==================================================================
    # CATEGORY 16: CLOUD TOOLS
    # ==================================================================
    def tool_cloud_storage_status(self, frame):
        self._panel_header(frame, "☁ Cloud Storage Status", "Detects common cloud-sync folders on this PC")
        box = self._text_output(frame)

        def gather():
            home = os.path.expanduser("~")
            candidates = {
                "OneDrive": os.path.join(home, "OneDrive"),
                "Google Drive": os.path.join(home, "Google Drive"),
                "Dropbox": os.path.join(home, "Dropbox"),
                "iCloudDrive": os.path.join(home, "iCloudDrive"),
                "Box": os.path.join(home, "Box"),
            }
            lines = []
            for name, path in candidates.items():
                if os.path.isdir(path):
                    lines.append(f"{name}: found at {path}")
                else:
                    lines.append(f"{name}: not found")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_cloud_sync_check(self, frame):
        self._panel_header(frame, "⟳ Cloud Sync Check", "Checks whether known cloud sync processes are running")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            targets = {"onedrive", "googledrivesync", "dropbox", "icloud", "boxsync"}
            found = []
            for p in psutil.process_iter(["name"]):
                name = (p.info.get("name") or "").lower()
                for t in targets:
                    if t in name:
                        found.append(p.info["name"])
            return ("Running cloud sync processes:\n" + "\n".join(found)) if found \
                else "No known cloud sync client processes detected."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_cloud_file_manager(self, frame):
        self._panel_header(frame, "□ Cloud File Manager", "Browses a detected cloud sync folder")
        box = self._text_output(frame)

        def browse():
            home = os.path.expanduser("~")
            for name, path in [("OneDrive", os.path.join(home, "OneDrive")),
                                ("Google Drive", os.path.join(home, "Google Drive")),
                                ("Dropbox", os.path.join(home, "Dropbox"))]:
                if os.path.isdir(path):
                    try:
                        entries = os.listdir(path)[:50]
                        return f"{name} ({path}):\n" + "\n".join(entries)
                    except Exception as e:
                        return f"Could not list {name}: {e}"
            return "No cloud sync folder detected on this PC."

        self._run_bg(browse, lambda r: self._set_text(box, r))

    def tool_cloud_backup_status(self, frame):
        self._panel_header(frame, "▥ Cloud Backup Status", "Checks Windows Backup / File History status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-WBSummary" ')
                if ok and out.strip():
                    return out
                return "Windows Server Backup module not present, or no backup configured. " \
                       "Check Settings > Update & Security > Backup for File History status."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_cloud_space_analyzer(self, frame):
        self._panel_header(frame, "▥ Cloud Space Analyzer", "Estimates local disk space used by cloud sync folders")
        box = self._text_output(frame)

        def analyze():
            home = os.path.expanduser("~")
            lines = []
            for name, path in [("OneDrive", os.path.join(home, "OneDrive")),
                                ("Google Drive", os.path.join(home, "Google Drive")),
                                ("Dropbox", os.path.join(home, "Dropbox"))]:
                if os.path.isdir(path):
                    total = 0
                    for root, dirs, files in os.walk(path):
                        for f in files:
                            try:
                                total += os.path.getsize(os.path.join(root, f))
                            except OSError:
                                pass
                    lines.append(f"{name}: {bytes_fmt(total)} on local disk")
            return "\n".join(lines) if lines else "No cloud sync folder detected."

        self._button_row(frame, [("Scan (may take a moment)", lambda: self._run_bg(analyze, lambda r: self._set_text(box, r)))])

    def tool_cloud_speed_test(self, frame):
        self._panel_header(frame, "→ Cloud Speed Test", "Times a small download from a public endpoint")
        box = self._text_output(frame)

        def test():
            try:
                import urllib.request
                url = "https://www.gstatic.com/generate_204"
                start = time.time()
                urllib.request.urlopen(url, timeout=10)
                elapsed = (time.time() - start) * 1000
                return f"Round-trip to test endpoint: {elapsed:.0f} ms\n" \
                       "(A latency probe, not a full bandwidth test — use a dedicated " \
                       "speed test service for throughput figures.)"
            except Exception as e:
                return f"Network test failed: {e}"

        self._button_row(frame, [("Run Test", lambda: self._run_bg(test, lambda r: self._set_text(box, r)))])

    def tool_cloud_sharing_manager(self, frame):
        self._panel_header(frame, "⌁ Cloud Sharing Manager", "Opens your default cloud provider's web sharing page")
        box = self._text_output(frame)
        self._set_text(box, "Choose a provider to open its sharing/management page in your browser.")

        def open_url(url):
            import webbrowser
            webbrowser.open(url)

        self._button_row(frame, [
            ("OneDrive", lambda: open_url("https://onedrive.live.com/")),
            ("Google Drive", lambda: open_url("https://drive.google.com/")),
            ("Dropbox", lambda: open_url("https://www.dropbox.com/home")),
        ])

    def tool_cloud_security_check(self, frame):
        self._panel_header(frame, "⬢ Cloud Security Check", "Reminds you to verify 2FA on cloud accounts")
        box = self._text_output(frame)
        self._set_text(box,
            "TechDrive can't inspect your cloud account security settings directly "
            "(that requires signing in via each provider's own app/website).\n\n"
            "Recommended checks:\n"
            "  • Two-factor authentication enabled\n"
            "  • Recent sign-in activity reviewed\n"
            "  • No unfamiliar linked devices or third-party app access")

    def tool_cloud_version_history(self, frame):
        self._panel_header(frame, "◷ Cloud Version History", "Opens version history for a file in a cloud folder")
        box = self._text_output(frame)

        def pick_and_open():
            path = filedialog.askopenfilename(title="Choose a file inside a cloud sync folder")
            if not path:
                return "Cancelled."
            if IS_WINDOWS:
                ok, out = run_cmd_argv(["explorer.exe", f"/select,{path}"])
                return f"Opened Explorer at {path}.\nRight-click the file and choose " \
                       f"'Version history' or 'View online' to see cloud revisions."
            return "Locate the file in your cloud provider's web UI for version history."

        self._button_row(frame, [("Choose File...", lambda: self._run_bg(pick_and_open, lambda r: self._set_text(box, r)))])

    def tool_cloud_auto_sync(self, frame):
        self._panel_header(frame, "⟳ Cloud Auto-Sync", "Checks whether known sync clients are set to auto-start")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_StartupCommand | '
                                   'Where-Object {$_.Name -match \'OneDrive|Dropbox|Drive\'} | '
                                   'Select-Object Name,Command | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No cloud sync auto-start entries found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 17: GAMING TOOLS
    # ==================================================================
    def tool_game_mode_manager(self, frame):
        self._panel_header(frame, "▦ Game Mode Manager", "Checks and opens Windows Game Mode settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:gaming-gamemode")
                return "Opened Game Mode settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Game Mode Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_gpu_optimization(self, frame):
        self._panel_header(frame, "⚙ GPU Optimization", "Opens Windows Graphics preferences for per-app GPU selection")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:display-advancedgraphics")
                return "Opened Graphics settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Graphics Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_latency_reduction(self, frame):
        self._panel_header(frame, "))) Latency Reduction", "Pings a common gaming DNS target to gauge network latency")
        box = self._text_output(frame)

        def gather():
            ok, out = run_cmd("ping -n 4 1.1.1.1" if IS_WINDOWS else "ping -c 4 1.1.1.1")
            return out if ok or out else "Ping failed — check your network connection."

        self._button_row(frame, [("Run Ping Test", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_fps_monitor(self, frame):
        self._panel_header(frame, "▧ FPS Monitor", "TechDrive can't hook into games directly — opens the Xbox Game Bar overlay")
        box = self._text_output(frame)

        def open_bar():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "(New-Object -ComObject WScript.Shell).SendKeys(\'^{g}\')"')
                return "Sent Win+G shortcut to open Game Bar (has a built-in FPS/performance overlay)."
            return windows_only_notice()

        self._button_row(frame, [("Open Game Bar Overlay", lambda: self._run_bg(open_bar, lambda r: self._set_text(box, r)))])

    def tool_gpu_overclock_check(self, frame):
        self._panel_header(frame, "△ GPU Overclock Check", "Reports current GPU clock/driver info")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_VideoController get Name,DriverVersion,AdapterRAM /format:list")
                return (out if ok and out.strip() else "Could not query GPU info.") + \
                       "\n\nNote: reading real-time GPU clocks/voltages needs vendor tools " \
                       "(NVIDIA/AMD) — TechDrive avoids touching those to prevent instability."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_game_bar_settings(self, frame):
        self._panel_header(frame, "≡ Game Bar Settings", "Opens Xbox Game Bar settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:gaming-gamebar")
                return "Opened Game Bar settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_directx_diagnostic(self, frame):
        self._panel_header(frame, "◇ DirectX Diagnostic", "Launches the built-in dxdiag tool")
        box = self._text_output(frame)

        def run_dxdiag():
            if IS_WINDOWS:
                out_path = os.path.join(os.path.expanduser("~"), "dxdiag-report.txt")
                ok, out = run_cmd_argv(["dxdiag.exe", "/t", out_path])
                time.sleep(2)
                if os.path.exists(out_path):
                    return f"DirectX report generated at:\n{out_path}"
                return "dxdiag launched — check for the report window/file."
            return windows_only_notice()

        self._button_row(frame, [("Run dxdiag", lambda: self._run_bg(run_dxdiag, lambda r: self._set_text(box, r)))])

    def tool_vulkan_check(self, frame):
        self._panel_header(frame, "△ Vulkan Check", "Checks for a Vulkan runtime installation")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                sys_dir = os.environ.get("WINDIR", "C:\\Windows") + "\\System32"
                vulkan_dll = os.path.join(sys_dir, "vulkan-1.dll")
                return f"vulkan-1.dll found at {vulkan_dll}" if os.path.exists(vulkan_dll) \
                    else "vulkan-1.dll not found — install your GPU vendor's latest driver, " \
                         "which bundles the Vulkan runtime."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_game_scheduler(self, frame):
        self._panel_header(frame, "▦ Game Scheduler", "Opens Task Scheduler so you can launch a game at a set time")
        box = self._text_output(frame)

        def open_scheduler():
            if IS_WINDOWS:
                ok, out = run_cmd("control schedtasks")
                return "Opened Task Scheduler." if ok else "Could not open Task Scheduler."
            return windows_only_notice()

        self._button_row(frame, [("Open Task Scheduler", lambda: self._run_bg(open_scheduler, lambda r: self._set_text(box, r)))])

    def tool_game_performance_log(self, frame):
        self._panel_header(frame, "▥ Game Performance Log", "Samples CPU/RAM/GPU-adjacent load for 20s while you play")
        box = self._text_output(frame)

        def log():
            if not psutil:
                return "psutil not installed."
            lines = []
            for i in range(10):
                cpu = psutil.cpu_percent(interval=1)
                ram = psutil.virtual_memory().percent
                lines.append(f"[{i*2:>3}s] CPU {cpu:.1f}%  RAM {ram:.1f}%")
            return "\n".join(lines)

        self._button_row(frame, [("Start 20s Log", lambda: self._run_bg(log, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 18: INTERNET TOOLS
    # ==================================================================
    def tool_internet_speed_test(self, frame):
        self._panel_header(frame, "→ Internet Speed Test", "Downloads a test file and measures throughput")
        box = self._text_output(frame)

        def test():
            try:
                import urllib.request
                url = "https://speed.hetzner.de/100MB.bin"
                start = time.time()
                with urllib.request.urlopen(url, timeout=15) as resp:
                    data = resp.read(5_000_000)
                elapsed = time.time() - start
                mbps = (len(data) * 8 / 1_000_000) / elapsed if elapsed else 0
                return f"Downloaded {bytes_fmt(len(data))} in {elapsed:.2f}s\nApprox speed: {mbps:.1f} Mbps"
            except Exception as e:
                return f"Speed test failed: {e}"

        self._button_row(frame, [("Run Test", lambda: self._run_bg(test, lambda r: self._set_text(box, r)))])

    def tool_connection_stability_test(self, frame):
        self._panel_header(frame, "))) Connection Stability Test", "Pings a target 10 times and reports packet loss")
        box = self._text_output(frame)

        def gather():
            ok, out = run_cmd("ping -n 10 8.8.8.8" if IS_WINDOWS else "ping -c 10 8.8.8.8")
            return out if out else "Ping failed."

        self._button_row(frame, [("Run Test", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_dns_flush(self, frame):
        self._panel_header(frame, "⌁ DNS Flush", "Clears the local DNS resolver cache")
        box = self._text_output(frame)

        def flush():
            if IS_WINDOWS:
                ok, out = run_cmd_argv(["ipconfig", "/flushdns"])
                return out if ok else "Could not flush DNS."
            return windows_only_notice()

        self._button_row(frame, [("Flush DNS", lambda: self._run_bg(flush, lambda r: self._set_text(box, r)))])

    def tool_tcp_ip_reset(self, frame):
        self._panel_header(frame, "⌁ TCP/IP Reset", "Resets the Windows network stack (requires restart)")
        box = self._text_output(frame)

        def reset():
            if not IS_WINDOWS:
                return windows_only_notice()
            ok1, out1 = run_cmd_argv(["netsh", "int", "ip", "reset"])
            ok2, out2 = run_cmd_argv(["netsh", "winsock", "reset"])
            return f"{out1}\n\n{out2}\n\nRestart your PC for the reset to take effect."

        self._button_row(frame, [("Reset TCP/IP", lambda: self._confirm_then(
            "This resets your network stack and requires a restart. Continue?",
            lambda: self._run_bg(reset, lambda r: self._set_text(box, r))))])

    def tool_ping_sweep(self, frame):
        self._panel_header(frame, "))) Ping Sweep", "Pings the first 20 hosts on your local subnet")
        box = self._text_output(frame)

        def sweep():
            try:
                hostname = socket.gethostname()
                local_ip = socket.gethostbyname(hostname)
                base = ".".join(local_ip.split(".")[:3])
                lines = []
                for i in range(1, 21):
                    ip = f"{base}.{i}"
                    ok, _ = run_cmd_argv(["ping", "-n" if IS_WINDOWS else "-c", "1", "-w" if IS_WINDOWS else "-W", "300" if IS_WINDOWS else "1", ip])
                    lines.append(f"{ip}: {'up' if ok else 'no response'}")
                return "\n".join(lines)
            except Exception as e:
                return f"Sweep failed: {e}"

        self._button_row(frame, [("Sweep Subnet (.1-.20)", lambda: self._run_bg(sweep, lambda r: self._set_text(box, r)))])

    def tool_traceroute_map(self, frame):
        self._panel_header(frame, "▧ Traceroute Map", "Shows the network hops to a destination")
        box = self._text_output(frame)

        def trace():
            ok, out = run_cmd("tracert -h 15 8.8.8.8" if IS_WINDOWS else "traceroute -m 15 8.8.8.8")
            return out if out else "Traceroute failed."

        self._button_row(frame, [("Run Traceroute", lambda: self._run_bg(trace, lambda r: self._set_text(box, r)))])

    def tool_website_checker(self, frame):
        self._panel_header(frame, "◎ Website Checker", "Checks if a website is reachable and its status code")
        row = ttk.Frame(frame)
        row.pack(anchor="w", fill="x", padx=16, pady=(4, 0))
        ttk.Label(row, text="URL:").pack(side="left")
        url_var = tk.StringVar(value="https://")
        tk.Entry(row, textvariable=url_var, bg=BG_LIGHT, fg=FG, insertbackground=FG, width=50).pack(side="left", padx=6)
        box = self._text_output(frame)

        def check():
            try:
                import urllib.request
                start = time.time()
                with urllib.request.urlopen(url_var.get(), timeout=10) as resp:
                    elapsed = (time.time() - start) * 1000
                    return f"Status: {resp.status}\nResponse time: {elapsed:.0f} ms"
            except Exception as e:
                return f"Site unreachable or error: {e}"

        self._button_row(frame, [("Check", lambda: self._run_bg(check, lambda r: self._set_text(box, r)))])

    def tool_ip_geolocation(self, frame):
        self._panel_header(frame, "• IP Geolocation", "Looks up your public IP's approximate location via a public API")
        box = self._text_output(frame)

        def gather():
            try:
                import urllib.request, json as _json
                with urllib.request.urlopen("https://ipapi.co/json/", timeout=10) as resp:
                    data = _json.loads(resp.read().decode())
                return (f"IP: {data.get('ip')}\nCity: {data.get('city')}\nRegion: {data.get('region')}\n"
                        f"Country: {data.get('country_name')}\nISP: {data.get('org')}")
            except Exception as e:
                return f"Lookup failed: {e}"

        self._button_row(frame, [("Look Up", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_port_forwarding_check(self, frame):
        self._panel_header(frame, "⇄ Port Forwarding Check", "Tests whether a local port is open and listening")
        row = ttk.Frame(frame)
        row.pack(anchor="w", fill="x", padx=16, pady=(4, 0))
        ttk.Label(row, text="Port:").pack(side="left")
        port_var = tk.StringVar(value="80")
        tk.Entry(row, textvariable=port_var, bg=BG_LIGHT, fg=FG, insertbackground=FG, width=10).pack(side="left", padx=6)
        box = self._text_output(frame)

        def check():
            try:
                port = int(port_var.get())
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(2)
                result = s.connect_ex(("127.0.0.1", port))
                s.close()
                return f"Port {port} is {'OPEN (something is listening locally)' if result == 0 else 'closed on localhost'}.\n" \
                       "Note: checking forwarding from the internet requires an external " \
                       "port-check service since this only tests from inside your network."
            except Exception as e:
                return f"Check failed: {e}"

        self._button_row(frame, [("Check Port", lambda: self._run_bg(check, lambda r: self._set_text(box, r)))])

    def tool_isp_information(self, frame):
        self._panel_header(frame, "▥ ISP Information", "Looks up your ISP via a public IP API")
        box = self._text_output(frame)

        def gather():
            try:
                import urllib.request, json as _json
                with urllib.request.urlopen("https://ipapi.co/json/", timeout=10) as resp:
                    data = _json.loads(resp.read().decode())
                return f"ISP / Org: {data.get('org')}\nASN: {data.get('asn')}\nCountry: {data.get('country_name')}"
            except Exception as e:
                return f"Lookup failed: {e}"

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 19: ACCESSIBILITY TOOLS
    # ==================================================================
    def tool_screen_magnifier(self, frame):
        self._panel_header(frame, "⌕ Screen Magnifier", "Launches the built-in Windows Magnifier")
        box = self._text_output(frame)

        def launch():
            if IS_WINDOWS:
                ok, out = run_cmd("magnify")
                return "Launched Windows Magnifier." if ok else "Could not launch Magnifier."
            return windows_only_notice()

        self._button_row(frame, [("Launch Magnifier", lambda: self._run_bg(launch, lambda r: self._set_text(box, r)))])

    def tool_color_filters(self, frame):
        self._panel_header(frame, "✦ Color Filters", "Opens Windows color filter settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-colorfilter")
                return "Opened Color Filters settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_high_contrast_mode(self, frame):
        self._panel_header(frame, "◐ High Contrast Mode", "Opens Windows high contrast theme settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-highcontrast")
                return "Opened High Contrast settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_mouse_pointer_size(self, frame):
        self._panel_header(frame, "▣ Mouse Pointer Size", "Opens mouse pointer settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-cursorandpointersize")
                return "Opened Cursor & Pointer settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_text_size_adjust(self, frame):
        self._panel_header(frame, "A Text Size Adjust", "Opens display text scaling settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-display")
                return "Opened Text Size settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_narrator_settings(self, frame):
        self._panel_header(frame, "◉ Narrator Settings", "Opens Windows Narrator settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-narrator")
                return "Opened Narrator settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_speech_recognition_check(self, frame):
        self._panel_header(frame, "◉ Speech Recognition Check", "Opens Windows Speech Recognition settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("control /name Microsoft.SpeechRecognition")
                return "Opened Speech Recognition settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_on_screen_keyboard(self, frame):
        self._panel_header(frame, "⌨ On-Screen Keyboard", "Launches the built-in on-screen keyboard")
        box = self._text_output(frame)

        def launch():
            if IS_WINDOWS:
                ok, out = run_cmd("osk")
                return "Launched On-Screen Keyboard." if ok else "Could not launch it."
            return windows_only_notice()

        self._button_row(frame, [("Launch", lambda: self._run_bg(launch, lambda r: self._set_text(box, r)))])

    def tool_sticky_keys(self, frame):
        self._panel_header(frame, "◆ Sticky Keys", "Opens Ease of Access keyboard settings (Sticky Keys)")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-keyboard")
                return "Opened Keyboard accessibility settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_filter_keys(self, frame):
        self._panel_header(frame, "⌁ Filter Keys", "Opens Ease of Access keyboard settings (Filter Keys)")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:easeofaccess-keyboard")
                return "Opened Keyboard accessibility settings (Filter Keys toggle is here)." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 20: MISCELLANEOUS
    # ==================================================================
    def tool_system_uptime(self, frame):
        self._panel_header(frame, "⏱ System Uptime", "How long since the last boot")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            boot = datetime.fromtimestamp(psutil.boot_time())
            uptime = datetime.now() - boot
            return f"Boot time: {boot}\nUptime: {uptime}"

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_system_clock_sync(self, frame):
        self._panel_header(frame, "◷ System Clock Sync", "Forces a resync with the Windows time service")
        box = self._text_output(frame)

        def sync():
            if IS_WINDOWS:
                ok, out = run_cmd("w32tm /resync")
                return out if ok else "Could not resync (time service may not be running)."
            return windows_only_notice()

        self._button_row(frame, [("Resync Clock", lambda: self._run_bg(sync, lambda r: self._set_text(box, r)))])

    def tool_time_zone_manager(self, frame):
        self._panel_header(frame, "◎ Time Zone Manager", "Shows and opens time zone settings")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("tzutil /g")
                return f"Current time zone: {out}" if ok else "Could not read time zone."
            return time.tzname[0]

        self._button_row(frame, [
            ("Refresh", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
            ("Open Settings", lambda: run_cmd("start ms-settings:dateandtime") if IS_WINDOWS else None),
        ])
        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_international_settings(self, frame):
        self._panel_header(frame, "◎ International Settings", "Opens regional/language settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:regionlanguage")
                return "Opened Region & Language settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_keyboard_layout_changer(self, frame):
        self._panel_header(frame, "⌨ Keyboard Layout Changer", "Opens keyboard layout settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:regionlanguage")
                return "Opened Region & Language settings (add/change keyboard layouts here)." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_file_type_association_fix(self, frame):
        self._panel_header(frame, "⌁ File Type Association Fix", "Opens the default apps settings page")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:defaultapps")
                return "Opened Default Apps settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_system_log_viewer(self, frame):
        self._panel_header(frame, "▤ System Log Viewer", "Shows the most recent System event log entries")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-WinEvent -LogName System -MaxEvents 20 | '
                                   'Select-Object TimeCreated,Id,LevelDisplayName,Message | Format-List"')
                return out if ok and out.strip() else "Could not read System event log."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_performance_report(self, frame):
        self._panel_header(frame, "▥ Performance Report", "Generates the Windows System Diagnostics report")
        box = self._text_output(frame)

        def generate():
            if IS_WINDOWS:
                ok, out = run_cmd('perfmon /report')
                return "Launched System Diagnostics report (perfmon) — it collects data for ~60s."
            return windows_only_notice()

        self._button_row(frame, [("Generate Report", lambda: self._run_bg(generate, lambda r: self._set_text(box, r)))])

    def tool_system_diagnostic_log(self, frame):
        self._panel_header(frame, "✚ System Diagnostic Log", "Shows the most recent Application event log entries")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-WinEvent -LogName Application -MaxEvents 20 | '
                                   'Select-Object TimeCreated,Id,LevelDisplayName,Message | Format-List"')
                return out if ok and out.strip() else "Could not read Application event log."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_windows_version_checker(self, frame):
        self._panel_header(frame, "□ Windows Version Checker", "Reports the exact OS build and version")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic os get Caption,Version,BuildNumber,OSArchitecture /format:list")
                return out if ok and out.strip() else "Could not query OS version."
            return f"{platform.system()} {platform.release()} ({platform.version()})"

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 21: PRINTER TOOLS
    # ==================================================================
    def tool_printer_list(self, frame):
        self._panel_header(frame, "▤ Printer List", "Lists installed printers")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic printer get Name,Default,PrinterStatus /format:list")
                return out if ok and out.strip() else "No printers found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_printer_status(self, frame):
        self._panel_header(frame, "● Printer Status", "Shows detailed printer status codes")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-Printer | Select-Object Name,PrinterStatus,JobCount | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query printer status."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_print_queue_manager(self, frame):
        self._panel_header(frame, "▤ Print Queue Manager", "Lists and clears pending print jobs")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PrintJob -PrinterName * -ErrorAction SilentlyContinue | '
                                   'Select-Object DocumentName,JobStatus | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No pending print jobs."
            return windows_only_notice()

        def clear_all():
            if IS_WINDOWS:
                ok, out = run_cmd('net stop spooler && del /Q "%WINDIR%\\System32\\spool\\PRINTERS\\*.*" && net start spooler')
                return "Print spooler cleared and restarted." if ok else f"Failed: {out}"
            return windows_only_notice()

        self._button_row(frame, [
            ("Refresh Queue", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
            ("Clear All Jobs", lambda: self._confirm_then(
                "This clears the print spooler and restarts the service. Continue?",
                lambda: self._run_bg(clear_all, lambda r: self._set_text(box, r)))),
        ])
        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_printer_driver_check(self, frame):
        self._panel_header(frame, "◇ Printer Driver Check", "Lists installed printer drivers")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic printerdriver get Name,Version /format:list")
                return out if ok and out.strip() else "Could not query printer drivers."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_test_page_print(self, frame):
        self._panel_header(frame, "▤ Test Page Print", "Sends a test page to the default printer")
        box = self._text_output(frame)

        def print_test():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_Printer | '
                                   'Where-Object {$_.Default -eq $true} | '
                                   'ForEach-Object { (New-Object -ComObject WScript.Network).AddWindowsPrinterConnection($_.Name); '
                                   '$_.PrintTestPage() }"')
                return "Requested a test page on the default printer." if ok else f"Failed: {out}"
            return windows_only_notice()

        self._button_row(frame, [("Print Test Page", lambda: self._run_bg(print_test, lambda r: self._set_text(box, r)))])

    def tool_network_printer_scanner(self, frame):
        self._panel_header(frame, "⌕ Network Printer Scanner", "Lists network (non-local) printers")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-Printer | Where-Object {$_.Type -eq \'Connection\' -or $_.Shared} | '
                                   'Select-Object Name,PortName,Shared | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No network/shared printers found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_printer_sharing_manager(self, frame):
        self._panel_header(frame, "⌁ Printer Sharing Manager", "Lists shared printers on this PC")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-Printer | Where-Object {$_.Shared} | Select-Object Name,ShareName"')
                return out if ok and out.strip() else "No printers are currently shared from this PC."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_fax_settings(self, frame):
        self._panel_header(frame, "▤ Fax Settings", "Opens the Windows Fax and Scan app")
        box = self._text_output(frame)

        def launch():
            if IS_WINDOWS:
                ok, out = run_cmd("start WFS.exe")
                return "Launched Windows Fax and Scan." if ok else "Windows Fax and Scan may not be installed on this edition."
            return windows_only_notice()

        self._button_row(frame, [("Open Fax and Scan", lambda: self._run_bg(launch, lambda r: self._set_text(box, r)))])

    def tool_scanner_detection(self, frame):
        self._panel_header(frame, "▤ Scanner Detection", "Lists imaging devices (scanners) recognized by Windows")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice -Class Image,Camera | '
                                   'Select-Object FriendlyName,Status | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No scanner/imaging devices detected."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_document_scanning(self, frame):
        self._panel_header(frame, "▤ Document Scanning", "Opens the Windows Scan app")
        box = self._text_output(frame)

        def launch():
            if IS_WINDOWS:
                ok, out = run_cmd("start microsoft.windows.wsa:")
                ok2, out2 = run_cmd("start ms-screensketch:")  # fallback-safe no-op if unavailable
                return "Attempted to open the Windows Scan app. If it doesn't open, " \
                       "install 'Windows Scan' from the Microsoft Store."
            return windows_only_notice()

        self._button_row(frame, [("Open Scan App", lambda: self._run_bg(launch, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 22: DRIVER TOOLS
    # ==================================================================
    def tool_driver_list(self, frame):
        self._panel_header(frame, "□ Driver List", "Lists all installed device drivers")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("driverquery /fo list")
                return out if ok and out.strip() else "Could not query drivers."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_driver_version_check(self, frame):
        self._panel_header(frame, "# Driver Version Check", "Shows driver versions for all PnP devices")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_PnPSignedDriver | '
                                   'Select-Object DeviceName,DriverVersion | Sort-Object DeviceName | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query driver versions."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_driver_update_check(self, frame):
        self._panel_header(frame, "⟳ Driver Update Check", "Opens Windows Update to check for optional driver updates")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:windowsupdate-optionalupdates")
                return "Opened Windows Update optional updates page (drivers appear here)." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Check for Driver Updates", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_driver_backup(self, frame):
        self._panel_header(frame, "▣ Driver Backup", "Exports all third-party drivers to a folder")
        box = self._text_output(frame)

        def backup():
            if not IS_WINDOWS:
                return windows_only_notice()
            folder = filedialog.askdirectory(title="Choose backup destination")
            if not folder:
                return "Cancelled."
            ok, out = run_cmd_argv(["dism", "/online", "/export-driver", f"/destination:{folder}"])
            return out if ok else f"Backup failed: {out}"

        self._button_row(frame, [("Backup Drivers...", lambda: self._run_bg(backup, lambda r: self._set_text(box, r)))])

    def tool_driver_restore(self, frame):
        self._panel_header(frame, "⟳ Driver Restore", "Installs drivers from a previously backed-up folder")
        box = self._text_output(frame)

        def restore():
            if not IS_WINDOWS:
                return windows_only_notice()
            folder = filedialog.askdirectory(title="Choose backup folder to restore from")
            if not folder:
                return "Cancelled."
            ok, out = run_cmd_argv(["pnputil", "/add-driver", os.path.join(folder, "*.inf"), "/subdirs", "/install"])
            return out if ok else f"Restore failed: {out}"

        self._button_row(frame, [("Restore Drivers...", lambda: self._confirm_then(
            "This installs driver packages from the chosen folder. Continue?",
            lambda: self._run_bg(restore, lambda r: self._set_text(box, r))))])

    def tool_driver_signature_check(self, frame):
        self._panel_header(frame, "✅ Driver Signature Check", "Verifies driver signing on this system")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_PnPSignedDriver | '
                                   'Where-Object {$_.IsSigned -eq $false} | Select-Object DeviceName"')
                if ok and out.strip():
                    return "Unsigned drivers found:\n" + out
                return "All queried drivers report as digitally signed."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_driver_installation(self, frame):
        self._panel_header(frame, "＋ Driver Installation", "Installs a driver from an .inf file")
        box = self._text_output(frame)

        def install():
            if not IS_WINDOWS:
                return windows_only_notice()
            path = filedialog.askopenfilename(title="Choose .inf driver file", filetypes=[("INF files", "*.inf")])
            if not path:
                return "Cancelled."
            ok, out = run_cmd_argv(["pnputil", "/add-driver", path, "/install"])
            return out if ok else f"Install failed: {out}"

        self._button_row(frame, [("Install Driver...", lambda: self._confirm_then(
            "This installs a driver package. Continue?",
            lambda: self._run_bg(install, lambda r: self._set_text(box, r))))])

    def tool_driver_uninstall(self, frame):
        self._panel_header(frame, "− Driver Uninstall", "Opens Device Manager to uninstall a driver")
        box = self._text_output(frame)

        def open_devmgmt():
            if IS_WINDOWS:
                ok, out = run_cmd("devmgmt.msc")
                return "Opened Device Manager — right-click a device to uninstall its driver."
            return windows_only_notice()

        self._button_row(frame, [("Open Device Manager", lambda: self._run_bg(open_devmgmt, lambda r: self._set_text(box, r)))])

    def tool_driver_rollback(self, frame):
        self._panel_header(frame, "⏪ Driver Rollback", "Opens Device Manager for driver rollback (per-device only)")
        box = self._text_output(frame)

        def open_devmgmt():
            if IS_WINDOWS:
                ok, out = run_cmd("devmgmt.msc")
                return "Opened Device Manager — select a device > Properties > Driver tab > Roll Back Driver."
            return windows_only_notice()

        self._button_row(frame, [("Open Device Manager", lambda: self._run_bg(open_devmgmt, lambda r: self._set_text(box, r)))])

    def tool_driver_conflict_checker(self, frame):
        self._panel_header(frame, "⚠ Driver Conflict Checker", "Lists devices reporting an error status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice | Where-Object {$_.Status -ne \'OK\'} | '
                                   'Select-Object FriendlyName,Status,Class | Format-Table -AutoSize"')
                return out if ok and out.strip() else "No devices reporting errors — no conflicts detected."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 23: ADVANCED PLUS
    # ==================================================================
    def tool_system_cloning(self, frame):
        self._panel_header(frame, "⌬ System Cloning", "Opens the built-in Windows backup/image tool")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("control /name Microsoft.BackupAndRestore")
                return "Opened Backup and Restore (Windows 7) — supports full system image creation." if ok else "Could not open tool."
            return windows_only_notice()

        self._button_row(frame, [("Open System Image Tool", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_virtual_machine_creator(self, frame):
        self._panel_header(frame, "▣ Virtual Machine Creator", "Opens Hyper-V Manager if the Windows feature is available")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("virtmgmt.msc")
                return "Opened Hyper-V Manager." if ok else \
                    "Hyper-V isn't enabled. Enable it via 'Turn Windows features on or off' > Hyper-V (Pro/Enterprise editions only)."
            return windows_only_notice()

        self._button_row(frame, [("Open Hyper-V Manager", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_iso_mounter(self, frame):
        self._panel_header(frame, "▥ ISO Mounter", "Mounts an .iso file as a virtual drive")
        box = self._text_output(frame)

        def mount():
            if not IS_WINDOWS:
                return windows_only_notice()
            path = filedialog.askopenfilename(title="Choose .iso file", filetypes=[("ISO images", "*.iso")])
            if not path:
                return "Cancelled."
            safe_path = path.replace("'", "''")
            ok, out = run_cmd_argv(["powershell.exe", "-NoProfile", "-Command", f"Mount-DiskImage -ImagePath '{safe_path}'"])
            return f"Mounted {path}." if ok else f"Mount failed: {out}"

        self._button_row(frame, [("Mount ISO...", lambda: self._run_bg(mount, lambda r: self._set_text(box, r)))])

    def tool_certificate_manager(self, frame):
        self._panel_header(frame, "▤ Certificate Manager", "Opens the Windows Certificate Manager")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("certmgr.msc")
                return "Opened Certificate Manager." if ok else "Could not open Certificate Manager."
            return windows_only_notice()

        self._button_row(frame, [("Open Certificate Manager", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_hardware_inventory_export(self, frame):
        self._panel_header(frame, "▤ Hardware Inventory Export", "Exports a full hardware summary to a text file")
        box = self._text_output(frame)

        def export():
            if not IS_WINDOWS:
                return windows_only_notice()
            path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="hardware-inventory.txt")
            if not path:
                return "Cancelled."
            sections = []
            for cmd, title in [("wmic cpu get Name,NumberOfCores /format:list", "CPU"),
                                ("wmic memorychip get Capacity,Speed /format:list", "RAM"),
                                ("wmic diskdrive get Model,Size /format:list", "Disks"),
                                ("wmic path win32_VideoController get Name /format:list", "GPU")]:
                ok, out = run_cmd(cmd)
                sections.append(f"=== {title} ===\n{out}\n")
            content = "\n".join(sections)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return f"Hardware inventory exported to:\n{path}"

        self._button_row(frame, [("Export Inventory...", lambda: self._run_bg(export, lambda r: self._set_text(box, r)))])

    def tool_system_restore_scheduler(self, frame):
        self._panel_header(frame, "▦ System Restore Scheduler", "Creates a restore point right now")
        box = self._text_output(frame)

        def create():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Checkpoint-Computer -Description \'TechDrive Scheduled Point\' -RestorePointType MODIFY_SETTINGS"')
                return "Restore point created." if ok else f"Could not create restore point: {out}"
            return windows_only_notice()

        self._button_row(frame, [("Create Restore Point Now", lambda: self._run_bg(create, lambda r: self._set_text(box, r)))])

    def tool_automated_maintenance(self, frame):
        self._panel_header(frame, "◇ Automated Maintenance", "Triggers the built-in Windows maintenance task")
        box = self._text_output(frame)

        def run_maint():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Start-ScheduledTask -TaskName \'\\Microsoft\\Windows\\TaskScheduler\\Regular Maintenance\'"')
                return "Triggered scheduled maintenance task." if ok else \
                    "Could not trigger via Task Scheduler API — try Control Panel > Security and Maintenance > Start maintenance."
            return windows_only_notice()

        self._button_row(frame, [("Run Maintenance", lambda: self._run_bg(run_maint, lambda r: self._set_text(box, r)))])

    def tool_task_scheduler_gui(self, frame):
        self._panel_header(frame, "▦ Task Scheduler GUI", "Opens the Windows Task Scheduler")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("taskschd.msc")
                return "Opened Task Scheduler." if ok else "Could not open Task Scheduler."
            return windows_only_notice()

        self._button_row(frame, [("Open Task Scheduler", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_performance_booster(self, frame):
        self._panel_header(frame, "↯ Performance Booster", "Switches to the High Performance power plan")
        box = self._text_output(frame)

        def boost():
            if IS_WINDOWS:
                ok, out = run_cmd('powercfg /setactive SCHEME_MIN')
                return "Switched to High Performance power plan." if ok else \
                    "Could not switch plan (it may not be available on this device)."
            return windows_only_notice()

        self._button_row(frame, [("Boost Performance", lambda: self._run_bg(boost, lambda r: self._set_text(box, r)))])

    def tool_custom_action_script_runner(self, frame):
        self._panel_header(frame, "✎ Custom Action Script Runner", "Runs a user-provided PowerShell/batch script")
        box = self._text_output(frame)

        def run_script():
            path = filedialog.askopenfilename(title="Choose a script to run",
                                               filetypes=[("Scripts", "*.ps1 *.bat *.cmd *.sh"), ("All files", "*.*")])
            if not path:
                return "Cancelled."
            if path.lower().endswith(".ps1"):
                cmd = f'powershell -ExecutionPolicy Bypass -File "{path}"'
            elif path.lower().endswith((".bat", ".cmd")):
                cmd = f'"{path}"'
            else:
                cmd = f'bash "{path}"' if not IS_WINDOWS else f'"{path}"'
            ok, out = run_cmd(cmd, timeout=60)
            return out if out else ("Script completed with no output." if ok else "Script failed.")

        self._button_row(frame, [("Choose & Run Script...", lambda: self._confirm_then(
            "This will execute an external script file you choose, with your user permissions. "
            "Only run scripts you trust. Continue?",
            lambda: self._run_bg(run_script, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 24: GAMING ADVANCED
    # ==================================================================
    def tool_game_recording(self, frame):
        self._panel_header(frame, "▧ Game Recording", "Sends the Game Bar record shortcut (Win+Alt+R)")
        box = self._text_output(frame)

        def toggle():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "(New-Object -ComObject WScript.Shell).SendKeys(\'^%{r}\')"')
                return "Sent Win+Alt+R to toggle Game Bar recording." if ok else "Could not send shortcut."
            return windows_only_notice()

        self._button_row(frame, [("Toggle Recording", lambda: self._run_bg(toggle, lambda r: self._set_text(box, r)))])

    def tool_streaming_optimizer(self, frame):
        self._panel_header(frame, "))) Streaming Optimizer", "Checks upload bandwidth suitability for streaming")
        box = self._text_output(frame)

        def gather():
            try:
                import urllib.request
                url = "https://speed.hetzner.de/100MB.bin"
                start = time.time()
                with urllib.request.urlopen(url, timeout=15) as resp:
                    data = resp.read(3_000_000)
                elapsed = time.time() - start
                mbps = (len(data) * 8 / 1_000_000) / elapsed if elapsed else 0
                verdict = "good for 1080p60 streaming" if mbps > 25 else \
                          "OK for 720p streaming" if mbps > 8 else "may struggle with live streaming"
                return f"Approx download speed: {mbps:.1f} Mbps ({verdict}).\n" \
                       "Note: upload speed (what matters most for streaming) usually differs " \
                       "from download — check your ISP plan or run a dedicated upload test."
            except Exception as e:
                return f"Test failed: {e}"

        self._button_row(frame, [("Run Check", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_input_lag_reducer(self, frame):
        self._panel_header(frame, "▦ Input Lag Reducer", "Opens Game Mode / pointer settings that affect input latency")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                run_cmd("start ms-settings:gaming-gamemode")
                return "Opened Game Mode settings. Also consider disabling mouse pointer " \
                       "acceleration (\"Enhance pointer precision\") for more consistent input."
            return windows_only_notice()

        self._button_row(frame, [("Open Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_gpu_overclock_tool(self, frame):
        self._panel_header(frame, "△ GPU Overclock Tool", "Read-only GPU info — TechDrive doesn't apply overclocks directly")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_VideoController get Name,DriverVersion /format:list")
                return (out if ok and out.strip() else "Could not query GPU.") + \
                       "\n\nApplying real clock/voltage changes safely requires your GPU vendor's " \
                       "own tool (MSI Afterburner, NVIDIA/AMD control panel) — TechDrive won't " \
                       "write those registers directly to avoid instability or hardware damage."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_fan_curve_editor(self, frame):
        self._panel_header(frame, "⟳ Fan Curve Editor", "Reads available fan sensors; editing curves needs vendor software")
        box = self._text_output(frame)

        def gather():
            if psutil and hasattr(psutil, "sensors_fans"):
                fans = psutil.sensors_fans()
                if fans:
                    lines = [f"{n} — {e.label or 'fan'}: {e.current} RPM" for n, es in fans.items() for e in es]
                    return "\n".join(lines) + "\n\nCustom fan curves require your motherboard/laptop " \
                           "vendor's utility — the OS doesn't expose a generic write API for this."
            return "No fan sensors exposed by this OS/hardware combination."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_game_library_manager(self, frame):
        self._panel_header(frame, "▤ Game Library Manager", "Scans common install folders for games")
        box = self._text_output(frame)

        def scan():
            candidates = [
                "C:\\Program Files (x86)\\Steam\\steamapps\\common",
                "C:\\Program Files\\Epic Games",
                "C:\\XboxGames",
            ]
            lines = []
            for path in candidates:
                if os.path.isdir(path):
                    try:
                        entries = os.listdir(path)
                        lines.append(f"{path}:\n  " + "\n  ".join(entries[:30]))
                    except Exception as e:
                        lines.append(f"{path}: error reading ({e})")
            return "\n\n".join(lines) if lines else "No common game library folders found on this PC."

        self._button_row(frame, [("Scan for Games", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_controller_calibration(self, frame):
        self._panel_header(frame, "▦ Controller Calibration", "Opens the Windows game controller settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("joy.cpl")
                return "Opened Game Controllers panel." if ok else "Could not open panel."
            return windows_only_notice()

        self._button_row(frame, [("Open Game Controllers", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_vr_headset_check(self, frame):
        self._panel_header(frame, "◇ VR Headset Check", "Looks for a connected VR headset device")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice | Where-Object {$_.FriendlyName -match '
                                   '\'Oculus|Vive|Rift|Quest|Mixed Reality|Valve Index\'} | Select-Object FriendlyName,Status"')
                return out if ok and out.strip() else "No known VR headset detected via Plug and Play."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_hdr_settings(self, frame):
        self._panel_header(frame, "≋ HDR Settings", "Opens Windows HDR display settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:display-hdr")
                return "Opened HDR display settings." if ok else "Could not open settings (HDR requires a compatible display)."
            return windows_only_notice()

        self._button_row(frame, [("Open HDR Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_ray_tracing_toggle(self, frame):
        self._panel_header(frame, "✦ Ray Tracing Toggle", "Opens graphics settings — ray tracing is toggled per-game/driver")
        box = self._text_output(frame)
        self._set_text(box,
            "Ray tracing isn't a single system-wide OS toggle — it's controlled per-game "
            "(graphics settings menu) and by your GPU vendor's control panel.\n\n"
            "Opening your GPU control panel and the Windows Graphics settings below "
            "as the closest relevant entry points.")

        def open_settings():
            if IS_WINDOWS:
                run_cmd("start ms-settings:display-advancedgraphics")
                return "Opened Windows Graphics settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Graphics Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 25: SECURITY SUITE
    # ==================================================================
    def tool_password_manager_integration(self, frame):
        self._panel_header(frame, "◆ Password Manager Integration", "Checks for common password manager installs")
        box = self._text_output(frame)

        def gather():
            home = os.path.expanduser("~")
            checks = {
                "Windows Credential Manager": True,
                "1Password": os.path.isdir(os.path.join(home, "AppData", "Local", "1Password")) if IS_WINDOWS else False,
                "Bitwarden": os.path.isdir(os.path.join(home, "AppData", "Local", "Bitwarden")) if IS_WINDOWS else False,
                "LastPass (browser ext only, not detectable here)": None,
            }
            lines = []
            for name, present in checks.items():
                if present is None:
                    lines.append(f"{name}: check your browser's extension list")
                else:
                    lines.append(f"{name}: {'detected' if present else 'not found'}")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_two_factor_auth_check(self, frame):
        self._panel_header(frame, "◆ Two-Factor Auth Check", "Checks Windows Hello / PIN sign-in status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-ItemProperty -Path '
                                   '\'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\'
                                   'PassportForWork\' -ErrorAction SilentlyContinue"')
                return ("Windows Hello / PIN configuration detected on this machine." if ok and out.strip()
                        else "No Windows Hello for Business policy detected. Check "
                             "Settings > Accounts > Sign-in options for PIN/biometric 2FA status.\n\n"
                             "Account-level 2FA (Google, Microsoft, banking, etc.) must be checked "
                             "on each service directly.")
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_security_audit_log(self, frame):
        self._panel_header(frame, "▤ Security Audit Log", "Shows recent Security event log entries")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-WinEvent -LogName Security -MaxEvents 20 -ErrorAction SilentlyContinue | '
                                   'Select-Object TimeCreated,Id,Message | Format-List"')
                return out if ok and out.strip() else "Could not read Security log (requires Administrator rights)."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_malware_scanner(self, frame):
        self._panel_header(frame, "◇ Malware Scanner", "Triggers a Windows Defender quick scan")
        box = self._text_output(frame)

        def scan():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Start-MpScan -ScanType QuickScan"', timeout=120)
                return "Quick scan completed." if ok else f"Scan failed or Defender unavailable: {out}"
            return windows_only_notice()

        self._button_row(frame, [("Run Quick Scan", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])
        self._set_text(box, "Click to run a Windows Defender quick scan (may take a few minutes).")

    def tool_rootkit_detector(self, frame):
        self._panel_header(frame, "◉ Rootkit Detector", "Runs a Windows Defender full scan focused offline boot-time check")
        box = self._text_output(frame)

        def scan():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Start-MpWDOScan"')
                return ("Windows Defender Offline scan scheduled — the PC will restart to run it. "
                        "Save your work first.") if ok else f"Could not schedule offline scan: {out}"
            return windows_only_notice()

        self._button_row(frame, [("Schedule Offline Scan", lambda: self._confirm_then(
            "This schedules a Windows Defender Offline scan, which restarts your PC. Continue?",
            lambda: self._run_bg(scan, lambda r: self._set_text(box, r))))])

    def tool_integrity_checker(self, frame):
        self._panel_header(frame, "✅ Integrity Checker", "Runs the System File Checker (sfc /scannow)")
        box = self._text_output(frame)

        def scan():
            if IS_WINDOWS:
                ok, out = run_cmd("sfc /scannow", timeout=600)
                return out if out else "SFC scan completed with no captured output."
            return windows_only_notice()

        self._button_row(frame, [("Run SFC Scan (may take several minutes)", lambda: self._run_bg(scan, lambda r: self._set_text(box, r)))])

    def tool_network_isolation(self, frame):
        self._panel_header(frame, "◆ Network Isolation", "Disables all network adapters (isolates the PC)")
        box = self._text_output(frame)

        def isolate():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-NetAdapter | Disable-NetAdapter -Confirm:$false"')
                return "All network adapters disabled. Re-enable via Device Manager or " \
                       "'Get-NetAdapter | Enable-NetAdapter' in PowerShell." if ok else f"Failed: {out}"
            return windows_only_notice()

        self._button_row(frame, [("Isolate Network Now", lambda: self._confirm_then(
            "This disables ALL network adapters immediately, cutting off internet/LAN access. Continue?",
            lambda: self._run_bg(isolate, lambda r: self._set_text(box, r))))])

    def tool_dns_security_check(self, frame):
        self._panel_header(frame, "⬢ DNS Security Check", "Checks the configured DNS servers against known public/secure resolvers")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-DnsClientServerAddress | '
                                   'Select-Object InterfaceAlias,ServerAddresses | Format-Table -AutoSize"')
                known_secure = {"1.1.1.1": "Cloudflare", "8.8.8.8": "Google", "9.9.9.9": "Quad9"}
                note = "\n\nKnown secure/public resolvers: " + ", ".join(f"{k} ({v})" for k, v in known_secure.items())
                return (out if ok and out.strip() else "Could not query DNS configuration.") + note
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_ssl_tls_checker(self, frame):
        self._panel_header(frame, "◆ SSL/TLS Checker", "Checks a website's certificate details")
        row = ttk.Frame(frame)
        row.pack(anchor="w", fill="x", padx=16, pady=(4, 0))
        ttk.Label(row, text="Host:").pack(side="left")
        host_var = tk.StringVar(value="example.com")
        tk.Entry(row, textvariable=host_var, bg=BG_LIGHT, fg=FG, insertbackground=FG, width=40).pack(side="left", padx=6)
        box = self._text_output(frame)

        def check():
            try:
                import ssl
                ctx = ssl.create_default_context()
                with socket.create_connection((host_var.get(), 443), timeout=10) as sock:
                    with ctx.wrap_socket(sock, server_hostname=host_var.get()) as ssock:
                        cert = ssock.getpeercert()
                        subject = dict(x[0] for x in cert.get("subject", []))
                        issuer = dict(x[0] for x in cert.get("issuer", []))
                        return (f"Subject: {subject.get('commonName')}\n"
                                f"Issuer: {issuer.get('commonName')}\n"
                                f"Valid from: {cert.get('notBefore')}\n"
                                f"Valid until: {cert.get('notAfter')}\n"
                                f"TLS version: {ssock.version()}")
            except Exception as e:
                return f"Could not retrieve certificate: {e}"

        self._button_row(frame, [("Check Certificate", lambda: self._run_bg(check, lambda r: self._set_text(box, r)))])

    def tool_social_engineering_simulator(self, frame):
        self._panel_header(frame, "◇ Social Engineering Simulator", "Shows a sample phishing email for awareness training")
        box = self._text_output(frame)
        self._set_text(box,
            "SAMPLE (for training/awareness only — not a real message):\n\n"
            "Subject: Urgent: Verify your account within 24 hours\n"
            "From: security-alert@your-bank-support.example\n\n"
            "Common red flags to point out to users:\n"
            "  • Urgency / fear-based language ('act now or your account is suspended')\n"
            "  • Sender domain that looks similar to, but isn't, the real company domain\n"
            "  • A link whose visible text doesn't match its actual destination\n"
            "  • Requests for passwords, OTP codes, or payment details via email\n"
            "  • Generic greeting instead of your actual name\n\n"
            "Use this as a talking point for training staff/family — TechDrive does not "
            "send simulated phishing emails to real inboxes.")

    # ==================================================================
    # CATEGORY 26: PERFORMANCE TOOLS
    # ==================================================================
    def tool_system_performance_index(self, frame):
        self._panel_header(frame, "◆ System Performance Index", "A rough composite score from CPU/RAM/disk metrics")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            cpu = 100 - psutil.cpu_percent(interval=1)
            ram = 100 - psutil.virtual_memory().percent
            disk_free_pct = 100 - psutil.disk_usage(os.path.abspath(os.sep)).percent
            score = round((cpu + ram + disk_free_pct) / 3, 1)
            return (f"CPU headroom: {cpu:.1f}%\nRAM headroom: {ram:.1f}%\n"
                    f"Disk free: {disk_free_pct:.1f}%\n\nComposite index: {score}/100\n"
                    f"(A simple headroom-based heuristic, not an industry benchmark score.)")

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_benchmark_suite(self, frame):
        self._panel_header(frame, "△ Benchmark Suite", "Runs a quick CPU + disk micro-benchmark")
        box = self._text_output(frame)

        def bench():
            start = time.time()
            total = 0
            for i in range(5_000_000):
                total += i * i
            cpu_time = time.time() - start

            tmp = os.path.join(os.path.expanduser("~"), "._techdrive_bench.tmp")
            start = time.time()
            with open(tmp, "wb") as f:
                f.write(os.urandom(20 * 1024 * 1024))
            write_time = time.time() - start
            start = time.time()
            with open(tmp, "rb") as f:
                f.read()
            read_time = time.time() - start
            os.remove(tmp)

            return (f"CPU micro-benchmark: {cpu_time:.2f}s (lower is faster)\n"
                    f"Disk write (20MB): {write_time:.2f}s ({20/write_time:.1f} MB/s)\n"
                    f"Disk read (20MB): {read_time:.2f}s ({20/read_time:.1f} MB/s)")

        self._button_row(frame, [("Run Benchmark", lambda: self._run_bg(bench, lambda r: self._set_text(box, r)))])

    def tool_latency_checker(self, frame):
        self._panel_header(frame, "))) Latency Checker", "Pings several common targets and compares")
        box = self._text_output(frame)

        def gather():
            targets = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]
            lines = []
            for ip in targets:
                ok, out = run_cmd_argv(["ping", "-n" if IS_WINDOWS else "-c", "2", ip])
                m = re.search(r"Average\s*=\s*(\d+)ms", out) or re.search(r"avg[^=]*=\s*[\d.]+/([\d.]+)/", out)
                latency = m.group(1) if m else "n/a"
                lines.append(f"{ip}: {latency} ms avg")
            return "\n".join(lines)

        self._button_row(frame, [("Run Check", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_startup_speed_test(self, frame):
        self._panel_header(frame, "→ Startup Speed Test", "Reads the last recorded boot duration from the Event Log")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "(Get-WinEvent -FilterHashtable @{LogName=\'Microsoft-Windows-Diagnostics-Performance/Operational\';Id=100} -MaxEvents 1).Message"')
                return out if ok and out.strip() else "No boot performance event found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_shutdown_speed_test(self, frame):
        self._panel_header(frame, "■ Shutdown Speed Test", "Reads the last recorded shutdown duration from the Event Log")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd(
                    'powershell "(Get-WinEvent -FilterHashtable @{LogName=\'Microsoft-Windows-Diagnostics-Performance/Operational\';Id=200} -MaxEvents 1).Message"')
                return out if ok and out.strip() else "No shutdown performance event found."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_app_launch_speed_test(self, frame):
        self._panel_header(frame, "→ App Launch Speed Test", "Times how long a chosen executable takes to spawn")
        box = self._text_output(frame)

        def measure(path):
            start = time.perf_counter()
            proc = None
            try:
                proc = subprocess.Popen([path])
                elapsed = time.perf_counter() - start
                # This is a spawn benchmark, not an app-session launcher.
                # Close the child so repeated tests do not leave unrelated
                # application windows/processes running behind TechDrive.
                try:
                    proc.terminate()
                    proc.wait(timeout=2)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait(timeout=1)
                    except Exception:
                        pass
                return f"Process spawn time: {elapsed*1000:.0f} ms\n" \
                       "(The test launches the executable briefly, then closes it.)"
            except Exception as e:
                return f"Could not launch: {e}"

        def choose_and_run():
            path = filedialog.askopenfilename(
                title="Choose an executable",
                filetypes=[("Executable", "*.exe")] if IS_WINDOWS else [("All files", "*.*")],
                parent=frame.winfo_toplevel(),
            )
            if path:
                self._run_bg(lambda: measure(path), lambda r: self._set_text(box, r))
            else:
                self._set_text(box, "Cancelled.")

        self._button_row(frame, [("Choose & Time Launch...", choose_and_run)])

    def tool_file_transfer_speed_test(self, frame):
        self._panel_header(frame, "↑ File Transfer Speed Test", "Times copying a chosen file to a destination folder")
        box = self._text_output(frame)

        def measure():
            src = filedialog.askopenfilename(title="Choose a file to copy")
            if not src:
                return "Cancelled."
            dest_dir = filedialog.askdirectory(title="Choose destination folder")
            if not dest_dir:
                return "Cancelled."
            dest = os.path.join(dest_dir, "techdrive_transfer_test_" + os.path.basename(src))
            size = os.path.getsize(src)
            start = time.time()
            shutil.copyfile(src, dest)
            elapsed = time.time() - start
            os.remove(dest)
            mbps = (size / 1_000_000) / elapsed if elapsed else 0
            return f"Copied {bytes_fmt(size)} in {elapsed:.2f}s ({mbps:.1f} MB/s)"

        self._button_row(frame, [("Choose Files & Test...", lambda: self._run_bg(measure, lambda r: self._set_text(box, r)))])

    def tool_memory_bandwidth_test(self, frame):
        self._panel_header(frame, "◉ Memory Bandwidth Test", "Times a large in-memory buffer copy")
        box = self._text_output(frame)

        def measure():
            size = 200 * 1024 * 1024
            data = bytearray(size)
            start = time.time()
            copy = data[:]
            elapsed = time.time() - start
            mbps = (size / 1_000_000) / elapsed if elapsed else 0
            return f"Copied {bytes_fmt(size)} in memory in {elapsed*1000:.1f} ms (~{mbps:.0f} MB/s)\n" \
                   "(Python-level estimate; real bandwidth benchmarks use native code and are much higher.)"

        self._button_row(frame, [("Run Test", lambda: self._run_bg(measure, lambda r: self._set_text(box, r)))])

    def tool_cache_performance_test(self, frame):
        self._panel_header(frame, "⟳ Cache Performance Test", "Compares sequential vs random access timing over a list")
        box = self._text_output(frame)

        def measure():
            import random
            n = 2_000_000
            data = list(range(n))
            start = time.time()
            total = 0
            for i in range(0, n, 1000):
                total += data[i]
            seq_time = time.time() - start

            indices = [random.randrange(n) for _ in range(2000)]
            start = time.time()
            total2 = 0
            for i in indices:
                total2 += data[i]
            rand_time = time.time() - start

            return (f"Sequential-ish access (2000 samples): {seq_time*1000:.2f} ms\n"
                    f"Random access (2000 samples): {rand_time*1000:.2f} ms\n"
                    f"(Illustrates cache-locality effects; Python overhead dominates absolute numbers.)")

        self._button_row(frame, [("Run Test", lambda: self._run_bg(measure, lambda r: self._set_text(box, r)))])

    def tool_i_o_performance_test(self, frame):
        self._panel_header(frame, "▤ I/O Performance Test", "Measures small random-write I/O throughput to disk")
        box = self._text_output(frame)

        def measure():
            tmp = os.path.join(os.path.expanduser("~"), "._techdrive_io_bench.tmp")
            chunk = os.urandom(4096)
            start = time.time()
            with open(tmp, "wb") as f:
                for _ in range(2000):
                    f.write(chunk)
                    f.flush()
                    os.fsync(f.fileno())
            elapsed = time.time() - start
            os.remove(tmp)
            total_mb = (4096 * 2000) / 1_000_000
            return f"Wrote {total_mb:.1f} MB in {2000} sync'd 4KB writes: {elapsed:.2f}s " \
                   f"({total_mb/elapsed:.2f} MB/s sustained sync write)"

        self._button_row(frame, [("Run Test (fsync'd writes)", lambda: self._run_bg(measure, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 27: BACKUP & RESTORE
    # ==================================================================
    def tool_full_system_backup(self, frame):
        self._panel_header(frame, "▣ Full System Backup", "Opens the Windows system image backup tool")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("control /name Microsoft.BackupAndRestore")
                return "Opened Backup and Restore (Windows 7) — choose 'Create a system image'." if ok else "Could not open tool."
            return windows_only_notice()

        self._button_row(frame, [("Open Backup Tool", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_incremental_backup(self, frame):
        self._panel_header(frame, "＋ Incremental Backup", "Copies only files changed since a chosen date")
        box = self._text_output(frame)

        def run_backup():
            src = filedialog.askdirectory(title="Choose source folder")
            if not src:
                return "Cancelled."
            dest = filedialog.askdirectory(title="Choose backup destination")
            if not dest:
                return "Cancelled."
            since_days = simpledialog.askinteger("Incremental Backup", "Include files modified in the last N days:",
                                                  minvalue=1, maxvalue=3650, initialvalue=7)
            if since_days is None:
                return "Cancelled."
            cutoff = time.time() - since_days * 86400
            copied = 0
            for root, dirs, files in os.walk(src):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    try:
                        if os.path.getmtime(fpath) >= cutoff:
                            rel = os.path.relpath(fpath, src)
                            dest_path = os.path.join(dest, rel)
                            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                            shutil.copy2(fpath, dest_path)
                            copied += 1
                    except OSError:
                        pass
            return f"Incremental backup complete: {copied} file(s) modified in the last {since_days} day(s) copied to {dest}"

        self._button_row(frame, [("Run Incremental Backup...", lambda: self._run_bg(run_backup, lambda r: self._set_text(box, r)))])

    def tool_differential_backup(self, frame):
        self._panel_header(frame, "⇄ Differential Backup", "Copies files that differ in size/mtime from a prior backup")
        box = self._text_output(frame)

        def run_backup():
            src = filedialog.askdirectory(title="Choose source folder")
            if not src:
                return "Cancelled."
            baseline = filedialog.askdirectory(title="Choose the original full-backup folder to diff against")
            if not baseline:
                return "Cancelled."
            dest = filedialog.askdirectory(title="Choose destination for differential backup")
            if not dest:
                return "Cancelled."
            copied = 0
            for root, dirs, files in os.walk(src):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, src)
                    base_path = os.path.join(baseline, rel)
                    try:
                        differs = (not os.path.exists(base_path) or
                                   os.path.getsize(base_path) != os.path.getsize(fpath) or
                                   os.path.getmtime(base_path) < os.path.getmtime(fpath))
                        if differs:
                            dest_path = os.path.join(dest, rel)
                            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                            shutil.copy2(fpath, dest_path)
                            copied += 1
                    except OSError:
                        pass
            return f"Differential backup complete: {copied} changed file(s) copied to {dest}"

        self._button_row(frame, [("Run Differential Backup...", lambda: self._run_bg(run_backup, lambda r: self._set_text(box, r)))])

    def tool_cloud_backup(self, frame):
        self._panel_header(frame, "☁ Cloud Backup", "Copies a folder into a detected local cloud sync folder")
        box = self._text_output(frame)

        def run_backup():
            home = os.path.expanduser("~")
            cloud_folder = None
            for name, path in [("OneDrive", os.path.join(home, "OneDrive")),
                                ("Google Drive", os.path.join(home, "Google Drive")),
                                ("Dropbox", os.path.join(home, "Dropbox"))]:
                if os.path.isdir(path):
                    cloud_folder = path
                    break
            if not cloud_folder:
                return "No local cloud sync folder detected. Install OneDrive/Google Drive/Dropbox first."
            src = filedialog.askdirectory(title="Choose folder to back up to the cloud")
            if not src:
                return "Cancelled."
            dest = os.path.join(cloud_folder, "TechDrive_Backup_" + os.path.basename(src))
            shutil.copytree(src, dest, dirs_exist_ok=True)
            return f"Copied {src} into {dest} — it will sync automatically once your cloud client uploads it."

        self._button_row(frame, [("Back Up Folder to Cloud...", lambda: self._run_bg(run_backup, lambda r: self._set_text(box, r)))])

    def tool_backup_scheduler(self, frame):
        self._panel_header(frame, "▦ Backup Scheduler", "Registers a daily backup task via Task Scheduler")
        box = self._text_output(frame)

        def schedule():
            if not IS_WINDOWS:
                return windows_only_notice()
            src = filedialog.askdirectory(title="Folder to back up daily")
            if not src:
                return "Cancelled."
            dest = filedialog.askdirectory(title="Backup destination")
            if not dest:
                return "Cancelled."
            cmd = (f'schtasks /Create /TN "TechDrive Daily Backup" /TR '
                   f'"robocopy \\"{src}\\" \\"{dest}\\" /MIR" /SC DAILY /ST 02:00 /F')
            ok, out = run_cmd(cmd)
            return "Daily backup task registered (2:00 AM)." if ok else f"Failed: {out}"

        self._button_row(frame, [("Schedule Daily Backup...", lambda: self._confirm_then(
            "This registers a scheduled task that mirrors the source into the destination "
            "folder every night at 2 AM (deleting files in destination not present in source). Continue?",
            lambda: self._run_bg(schedule, lambda r: self._set_text(box, r))))])

    def tool_restore_wizard(self, frame):
        self._panel_header(frame, "◇ Restore Wizard", "Copies files back from a backup folder to their original location")
        box = self._text_output(frame)

        def restore():
            backup = filedialog.askdirectory(title="Choose backup folder to restore from")
            if not backup:
                return "Cancelled."
            dest = filedialog.askdirectory(title="Choose restore destination")
            if not dest:
                return "Cancelled."
            count = 0
            for root, dirs, files in os.walk(backup):
                for fname in files:
                    rel = os.path.relpath(os.path.join(root, fname), backup)
                    dest_path = os.path.join(dest, rel)
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    shutil.copy2(os.path.join(root, fname), dest_path)
                    count += 1
            return f"Restored {count} file(s) to {dest}"

        self._button_row(frame, [("Restore Files...", lambda: self._confirm_then(
            "This copies files from the backup folder into the destination, overwriting matches. Continue?",
            lambda: self._run_bg(restore, lambda r: self._set_text(box, r))))])

    def tool_disaster_recovery_plan(self, frame):
        self._panel_header(frame, "▤ Disaster Recovery Plan", "Generates a basic checklist based on this system")
        box = self._text_output(frame)

        def generate():
            lines = ["TechDrive Disaster Recovery Checklist", "=" * 40, ""]
            if IS_WINDOWS:
                ok, out = run_cmd("wmic os get Caption,Version /format:list")
                lines.append(out)
            lines += ["",
                      "1. Verify a recent system image or file backup exists off this PC.",
                      "2. Note your Windows product key / Microsoft account used for activation.",
                      "3. Keep a bootable USB recovery drive prepared and tested.",
                      "4. Record BitLocker recovery keys somewhere separate from this PC.",
                      "5. List critical software + license keys needed for a clean reinstall.",
                      "6. Store this checklist and your backups off-device (cloud or external drive)."]
            return "\n".join(lines)

        self._button_row(frame, [("Generate Checklist", lambda: self._run_bg(generate, lambda r: self._set_text(box, r)))])

    def tool_bootable_backup(self, frame):
        self._panel_header(frame, "▥ Bootable Backup", "Guidance for creating a bootable recovery image")
        box = self._text_output(frame)
        self._set_text(box,
            "TechDrive won't silently image or format a drive. To create a bootable "
            "backup safely:\n\n"
            "1. Use 'Full System Backup' in this category to create a Windows system image.\n"
            "2. Use 'Bootable USB Creator' (Boot & Recovery category) to also prepare "
            "recovery media.\n"
            "3. Test the recovery media on a spare drive before relying on it.")

    def tool_clone_backup(self, frame):
        self._panel_header(frame, "⌬ Clone Backup", "Mirrors one folder's contents onto another (robocopy /MIR)")
        box = self._text_output(frame)

        def clone():
            src = filedialog.askdirectory(title="Source folder")
            if not src:
                return "Cancelled."
            dest = filedialog.askdirectory(title="Destination folder (will be mirrored to match source)")
            if not dest:
                return "Cancelled."
            if IS_WINDOWS:
                ok, out = run_cmd_argv(["robocopy", src, dest, "/MIR"], timeout=600)
                return out if out else "Clone complete."
            ok, out = run_cmd_argv(["rsync", "-a", "--delete", src + os.sep, dest + os.sep], timeout=600)
            return out if out else "Clone complete (rsync)."

        self._button_row(frame, [("Clone Folder...", lambda: self._confirm_then(
            "This mirrors the destination to exactly match the source, deleting extra files "
            "in the destination. Continue?",
            lambda: self._run_bg(clone, lambda r: self._set_text(box, r))))])

    def tool_versioned_backup(self, frame):
        self._panel_header(frame, "◷ Versioned Backup", "Copies a folder into a timestamped backup destination")
        box = self._text_output(frame)

        def backup():
            src = filedialog.askdirectory(title="Folder to back up")
            if not src:
                return "Cancelled."
            base_dest = filedialog.askdirectory(title="Backup root destination")
            if not base_dest:
                return "Cancelled."
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(base_dest, f"{os.path.basename(src)}_{stamp}")
            shutil.copytree(src, dest)
            return f"Versioned backup created at:\n{dest}"

        self._button_row(frame, [("Create Versioned Backup...", lambda: self._run_bg(backup, lambda r: self._set_text(box, r)))])

    # ==================================================================
    # CATEGORY 28: WINDOWS TWEAKS
    # ==================================================================
    def tool_windows_registry_tweaks(self, frame):
        self._panel_header(frame, "▣ Windows Registry Tweaks", "Opens the Registry Editor for manual tweaks")
        box = self._text_output(frame)

        def open_regedit():
            if IS_WINDOWS:
                ok, out = run_cmd("regedit")
                return "Opened Registry Editor. Back up any key before editing it."
            return windows_only_notice()

        self._button_row(frame, [("Open Registry Editor", lambda: self._confirm_then(
            "Editing the registry incorrectly can cause system issues. Continue?",
            lambda: self._run_bg(open_regedit, lambda r: self._set_text(box, r))))])

    def tool_performance_tweaks(self, frame):
        self._panel_header(frame, "↯ Performance Tweaks", "Opens 'Adjust for best performance' visual effects panel")
        box = self._text_output(frame)

        def open_panel():
            if IS_WINDOWS:
                ok, out = run_cmd("SystemPropertiesPerformance")
                return "Opened Performance Options." if ok else "Could not open panel."
            return windows_only_notice()

        self._button_row(frame, [("Open Performance Options", lambda: self._run_bg(open_panel, lambda r: self._set_text(box, r)))])

    def tool_privacy_tweaks(self, frame):
        self._panel_header(frame, "◇ Privacy Tweaks", "Opens Windows privacy settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:privacy")
                return "Opened Privacy settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Privacy Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_network_tweaks(self, frame):
        self._panel_header(frame, "◎ Network Tweaks", "Opens Network & Internet settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:network")
                return "Opened Network settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Network Settings", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_visual_tweaks(self, frame):
        self._panel_header(frame, "✦ Visual Tweaks", "Opens Windows personalization settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("start ms-settings:personalization")
                return "Opened Personalization settings." if ok else "Could not open settings."
            return windows_only_notice()

        self._button_row(frame, [("Open Personalization", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_startup_tweaks(self, frame):
        self._panel_header(frame, "→ Startup Tweaks", "Lists startup programs and lets you view Task Manager's Startup tab")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_StartupCommand | '
                                   'Select-Object Name,Command,Location | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query startup items."
            return windows_only_notice()

        self._button_row(frame, [
            ("Refresh List", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
            ("Open Task Manager", lambda: run_cmd("taskmgr") if IS_WINDOWS else None),
        ])
        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_service_tweaks(self, frame):
        self._panel_header(frame, "⚙ Service Tweaks", "Opens the Services management console")
        box = self._text_output(frame)

        def open_services():
            if IS_WINDOWS:
                ok, out = run_cmd("services.msc")
                return "Opened Services console." if ok else "Could not open Services."
            return windows_only_notice()

        self._button_row(frame, [("Open Services", lambda: self._run_bg(open_services, lambda r: self._set_text(box, r)))])

    def tool_power_tweaks(self, frame):
        self._panel_header(frame, "▰ Power Tweaks", "Opens advanced power plan settings")
        box = self._text_output(frame)

        def open_settings():
            if IS_WINDOWS:
                ok, out = run_cmd("powercfg.cpl")
                return "Opened Power Options." if ok else "Could not open Power Options."
            return windows_only_notice()

        self._button_row(frame, [("Open Power Options", lambda: self._run_bg(open_settings, lambda r: self._set_text(box, r)))])

    def tool_security_tweaks(self, frame):
        self._panel_header(frame, "⬢ Security Tweaks", "Opens Windows Security app")
        box = self._text_output(frame)

        def open_security():
            if IS_WINDOWS:
                ok, out = run_cmd("start windowsdefender:")
                return "Opened Windows Security." if ok else "Could not open Windows Security."
            return windows_only_notice()

        self._button_row(frame, [("Open Windows Security", lambda: self._run_bg(open_security, lambda r: self._set_text(box, r)))])

    def tool_custom_script_runner(self, frame):
        self._panel_header(frame, "✎ Custom Script Runner", "Runs a user-chosen tweak script (PowerShell/batch)")
        box = self._text_output(frame)

        def run_script():
            path = filedialog.askopenfilename(title="Choose a tweak script",
                                               filetypes=[("Scripts", "*.ps1 *.bat *.cmd"), ("All files", "*.*")])
            if not path:
                return "Cancelled."
            if path.lower().endswith(".ps1"):
                cmd = f'powershell -ExecutionPolicy Bypass -File "{path}"'
            else:
                cmd = f'"{path}"'
            ok, out = run_cmd(cmd, timeout=60)
            return out if out else ("Script completed with no output." if ok else "Script failed.")

        self._button_row(frame, [("Choose & Run Script...", lambda: self._confirm_then(
            "This runs an external script with your user permissions. Only run scripts you trust. Continue?",
            lambda: self._run_bg(run_script, lambda r: self._set_text(box, r))))])

    # ==================================================================
    # CATEGORY 29: HARDWARE INVENTORY
    # ==================================================================
    def tool_complete_hardware_inventory(self, frame):
        self._panel_header(frame, "▣ Complete Hardware Inventory", "Full CPU/RAM/GPU/disk summary")
        box = self._text_output(frame, height=24)

        def gather():
            sections = []
            for cmd, title in [("wmic cpu get Name,NumberOfCores,NumberOfLogicalProcessors /format:list", "CPU"),
                                ("wmic memorychip get Capacity,Manufacturer,Speed /format:list", "RAM"),
                                ("wmic diskdrive get Model,Size,InterfaceType /format:list", "Disks"),
                                ("wmic path win32_VideoController get Name,AdapterRAM /format:list", "GPU"),
                                ("wmic baseboard get Manufacturer,Product /format:list", "Motherboard")]:
                if IS_WINDOWS:
                    ok, out = run_cmd(cmd)
                    sections.append(f"=== {title} ===\n{out}\n")
            return "\n".join(sections) if sections else windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_bios_efi_inventory(self, frame):
        self._panel_header(frame, "▤ BIOS/EFI Inventory", "BIOS/firmware manufacturer and version")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic bios get Manufacturer,SMBIOSBIOSVersion,ReleaseDate,SerialNumber /format:list")
                return out if ok else "Could not query BIOS info."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_network_adapter_inventory(self, frame):
        self._panel_header(frame, "◎ Network Adapter Inventory", "Lists all network adapters and their status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-NetAdapter | Select-Object Name,InterfaceDescription,Status,MacAddress | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query network adapters."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_storage_controller_inventory(self, frame):
        self._panel_header(frame, "▤ Storage Controller Inventory", "Lists storage controllers (SATA/NVMe/RAID)")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_scsicontroller get Name,Manufacturer /format:list")
                return out if ok and out.strip() else "Could not query storage controllers."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_usb_device_inventory(self, frame):
        self._panel_header(frame, "⌁ USB Device Inventory", "Lists connected USB devices")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice -Class USB | Select-Object FriendlyName,Status | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query USB devices."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_pci_device_inventory(self, frame):
        self._panel_header(frame, "⚒ PCI Device Inventory", "Lists PCI/PCIe devices")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice -PresentOnly | Where-Object {$_.InstanceId -match \'^PCI\'} | '
                                   'Select-Object FriendlyName,Status | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query PCI devices."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_pnp_device_inventory(self, frame):
        self._panel_header(frame, "◇ PNP Device Inventory", "Lists all Plug and Play devices")
        box = self._text_output(frame, height=24)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-PnpDevice -PresentOnly | Select-Object FriendlyName,Class,Status | '
                                   'Sort-Object Class | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query PnP devices."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_driver_inventory(self, frame):
        self._panel_header(frame, "□ Driver Inventory", "Full list of installed drivers with dates")
        box = self._text_output(frame, height=24)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("driverquery /v /fo list")
                return out if ok and out.strip() else "Could not query driver inventory."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_firmware_inventory(self, frame):
        self._panel_header(frame, "⚙ Firmware Inventory", "Lists BIOS/UEFI and firmware-level device details")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-CimInstance Win32_BIOS | '
                                   'Select-Object Manufacturer,SMBIOSBIOSVersion,ReleaseDate | Format-List"')
                return out if ok and out.strip() else "Could not query firmware info."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_system_slots_inventory(self, frame):
        self._panel_header(frame, "⌕ System Slots Inventory", "RAM slot count and populated/empty status")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic memphysical get MaxCapacity,MemoryDevices /format:list")
                ok2, out2 = run_cmd("wmic memorychip get DeviceLocator,Capacity /format:list")
                return f"{out}\n\nPopulated slots:\n{out2}" if ok else "Could not query memory slots."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ==================================================================
    # CATEGORY 30: DIAGNOSTICS & REPORTS
    # ==================================================================
    def tool_diagnostic_summary(self, frame):
        self._panel_header(frame, "✎ Diagnostic Summary", "One-page snapshot of CPU/RAM/disk/uptime")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            vm = psutil.virtual_memory()
            disk = psutil.disk_usage(os.path.abspath(os.sep))
            boot = datetime.fromtimestamp(psutil.boot_time())
            return (f"CPU usage: {psutil.cpu_percent(interval=1):.1f}%\n"
                    f"RAM usage: {vm.percent}% ({bytes_fmt(vm.used)} / {bytes_fmt(vm.total)})\n"
                    f"Disk usage (system drive): {disk.percent}% ({bytes_fmt(disk.used)} / {bytes_fmt(disk.total)})\n"
                    f"Uptime since: {boot}")

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_health_check_report(self, frame):
        self._panel_header(frame, "❤ Health Check Report", "Flags common warning signs across CPU/RAM/disk")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            issues = []
            cpu = psutil.cpu_percent(interval=1)
            if cpu > 90:
                issues.append(f"CPU usage very high: {cpu:.1f}%")
            ram = psutil.virtual_memory().percent
            if ram > 90:
                issues.append(f"RAM usage very high: {ram:.1f}%")
            disk = psutil.disk_usage(os.path.abspath(os.sep)).percent
            if disk > 90:
                issues.append(f"System drive nearly full: {disk:.1f}% used")
            if hasattr(psutil, "sensors_battery"):
                batt = psutil.sensors_battery()
                if batt and batt.percent < 15 and not batt.power_plugged:
                    issues.append(f"Battery low: {batt.percent}% and not charging")
            return ("Potential issues found:\n" + "\n".join(issues)) if issues else "No obvious issues detected."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_performance_snapshot_report(self, frame):
        self._panel_header(frame, "▥ Performance Snapshot Report", "Per-core CPU and RAM snapshot")
        box = self._text_output(frame)

        def gather():
            if not psutil:
                return "psutil not installed."
            per_core = psutil.cpu_percent(percpu=True, interval=1)
            vm = psutil.virtual_memory()
            lines = [f"Core {i}: {p:.1f}%" for i, p in enumerate(per_core)]
            lines.append(f"\nRAM: {vm.percent}% used ({bytes_fmt(vm.used)} / {bytes_fmt(vm.total)})")
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_security_report(self, frame):
        self._panel_header(frame, "⬢ Security Report", "Windows Defender and firewall status summary")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-MpComputerStatus | '
                                   'Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated"')
                ok2, out2 = run_cmd('netsh advfirewall show allprofiles state')
                return f"{out}\n\nFirewall:\n{out2}" if ok else "Could not query security status."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_network_report(self, frame):
        self._panel_header(frame, "◎ Network Report", "Adapter status + current IP config summary")
        box = self._text_output(frame)

        def gather():
            ok, out = run_cmd("ipconfig /all" if IS_WINDOWS else "ifconfig")
            return out if ok and out.strip() else "Could not gather network info."

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_hardware_report(self, frame):
        self._panel_header(frame, "▣ Hardware Report", "CPU/RAM/disk/GPU summary in one view")
        box = self._text_output(frame, height=24)

        def gather():
            lines = [f"Processor: {platform.processor() or 'Unknown'}"]
            if psutil:
                lines.append(f"Cores: {psutil.cpu_count(logical=False)} physical / {psutil.cpu_count(logical=True)} logical")
                lines.append(f"RAM: {bytes_fmt(psutil.virtual_memory().total)}")
                lines.append(f"Disk: {bytes_fmt(psutil.disk_usage(os.path.abspath(os.sep)).total)}")
            if IS_WINDOWS:
                ok, out = run_cmd("wmic path win32_VideoController get Name /format:list")
                if ok:
                    lines.append(out)
            return "\n".join(lines)

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_software_report(self, frame):
        self._panel_header(frame, "□ Software Report", "Lists installed applications")
        box = self._text_output(frame, height=24)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd('powershell "Get-ItemProperty HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\'
                                   'CurrentVersion\\Uninstall\\* -ErrorAction SilentlyContinue | '
                                   'Select-Object DisplayName,DisplayVersion | Where-Object {$_.DisplayName} | '
                                   'Sort-Object DisplayName | Format-Table -AutoSize"')
                return out if ok and out.strip() else "Could not query installed software."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    def tool_system_stability_report(self, frame):
        self._panel_header(frame, "▥ System Stability Report", "Opens the Windows Reliability Monitor")
        box = self._text_output(frame)

        def open_tool():
            if IS_WINDOWS:
                ok, out = run_cmd("perfmon /rel")
                return "Opened Reliability Monitor." if ok else "Could not open Reliability Monitor."
            return windows_only_notice()

        self._button_row(frame, [("Open Reliability Monitor", lambda: self._run_bg(open_tool, lambda r: self._set_text(box, r)))])

    def tool_battery_health_report(self, frame):
        self._panel_header(frame, "▰ Battery Health Report", "Design vs full-charge capacity summary")
        box = self._text_output(frame)

        def gather():
            if not IS_WINDOWS:
                return windows_only_notice()
            out_path = os.path.join(os.path.expanduser("~"), "battery-report.html")
            run_cmd_argv(["powercfg", "/batteryreport", "/output", out_path])
            if not os.path.exists(out_path):
                return "Could not generate battery report — this may be a desktop PC with no battery."
            try:
                with open(out_path, "r", encoding="utf-8", errors="ignore") as f:
                    html = f.read()
                design = re.search(r"DESIGN CAPACITY.*?(\d[\d,]*)\s*mWh", html, re.S | re.I)
                full = re.search(r"FULL CHARGE CAPACITY.*?(\d[\d,]*)\s*mWh", html, re.S | re.I)
                if design and full:
                    d = int(design.group(1).replace(",", ""))
                    fchg = int(full.group(1).replace(",", ""))
                    pct = (fchg / d) * 100 if d else 0
                    return f"Design: {d} mWh\nFull charge: {fchg} mWh\nHealth: {pct:.1f}%\n\nFull report: {out_path}"
                return f"Could not parse capacity values. Full report saved to: {out_path}"
            except Exception as e:
                return f"Error reading report: {e}"

        self._button_row(frame, [("Generate Report", lambda: self._run_bg(gather, lambda r: self._set_text(box, r)))])

    def tool_disk_health_report(self, frame):
        self._panel_header(frame, "▤ Disk Health Report", "SMART status for all physical disks")
        box = self._text_output(frame)

        def gather():
            if IS_WINDOWS:
                ok, out = run_cmd("wmic diskdrive get Model,Status,SerialNumber /format:list")
                return out if ok and out.strip() else "Could not query disk health."
            return windows_only_notice()

        self._run_bg(gather, lambda r: self._set_text(box, r))

    # ------------------------------------------------------------------
    # License / upgrade UI
    # ------------------------------------------------------------------
    def start_free(self):
        self.license.activate_free()
        self.tier_label.config(text=self._tier_text())
        self._refresh_tool_widgets()
        messagebox.showinfo("TechDrive", "Switched to the Free tier. All tools remain available; "
                                          "the reminder popup returns once your 30-day trial has elapsed.")

    def activate_license_key_dialog(self):
        machine_id = get_machine_id().upper()[:4]
        key = simpledialog.askstring(
            "Activate License Key",
            "Enter your TechDrive license key "
            "(Personal Pro or Business):\n\n"
            f"(Your machine tag, if you need a machine-bound key issued: {machine_id})",
        )
        if not key:
            return
        ok, msg = self.license.activate_key_string(key)
        messagebox.showinfo("TechDrive License", msg)
        if ok:
            self.tier_label.config(text=self._tier_text())
            self._refresh_tool_widgets()

    def show_license_info(self):
        info = TIER_INFO[self.license.tier]
        lines = [f"Tier: {info['name']}", f"Licensed to: {self.license.licensed_to}"]
        if self.license.tier == "F":
            trial_status = get_trial_status()
            if trial_status["show_popup"]:
                lines.append("Your 30-day free trial has expired.")
            else:
                lines.append(f"Free trial: {trial_status['days_left']} day(s) left.")
        elif self.license.expires:
            lines.append(f"Expires: {self.license.expires}")
        messagebox.showinfo("License Info", "\n".join(lines))

    def show_upgrade(self):
        win = tk.Toplevel(self)
        win.title("Upgrade Plan")
        win.configure(bg=BG)
        win.geometry("460x320")
        ttk.Label(win, text="TechDrive Pricing", style="Header.TLabel").pack(anchor="w", padx=16, pady=10)
        for code, info in TIER_INFO.items():
            ttk.Label(win, text=f"[{code}] {info['name']} — {info['price']} — {info['validity']}",
                      background=BG, foreground=FG, wraplength=420).pack(anchor="w", padx=20, pady=4)
        ttk.Label(win, text="Activate a purchased license via File > Activate License Key...",
                  background=BG, foreground="#9aa0a6", wraplength=400).pack(anchor="w", padx=16, pady=12)

    # ------------------------------------------------------------------
    # Help Center / EULA viewer (gui/doc_viewer.py) - each falls back to
    # the original plain-text window if the viewer ever fails to open.
    # ------------------------------------------------------------------
    def _viewer_help_items(self, kind):
        items = []
        if kind != "help":
            items.append(("Open Help Center\tF1", self.show_help_center))
        if kind != "eula":
            items.append(("Open EULA", self.show_eula))
        items += [None,
                  ("Keyboard Shortcuts", lambda: self.show_help_center("Keyboard Shortcuts")),
                  ("What's New in v1.1", lambda: self.show_help_center("What's New")),
                  ("Replay Welcome Tour", self.replay_welcome_tour),
                  None,
                  ("License Info", self.show_license_info),
                  ("About TechDrive", self.show_about)]
        return items

    def _populate_help_menu(self, menu):
        """Shared by the toolbar Help popup and the native menu bar."""
        menu.add_command(label="Help Center\tF1", command=self.show_help_center)
        menu.add_command(label="Quick Start", command=lambda: self.show_help_center("Getting Started"))
        menu.add_command(label="Keyboard Shortcuts", command=lambda: self.show_help_center("Keyboard Shortcuts"))
        menu.add_command(label="What's New in v1.1", command=lambda: self.show_help_center("What's New"))
        menu.add_command(label="Troubleshooting", command=lambda: self.show_help_center("Troubleshooting"))
        menu.add_command(label="Replay Welcome Tour", command=self.replay_welcome_tour)
        menu.add_separator()
        menu.add_command(label="License Info", command=self.show_license_info)
        menu.add_command(label="Activate License Key...", command=self.activate_license_key_dialog)
        menu.add_command(label="Buy License", command=self.show_upgrade)
        menu.add_separator()
        menu.add_command(label="EULA", command=self.show_eula)
        menu.add_command(label="About TechDrive", command=self.show_about)

    def replay_welcome_tour(self):
        try:
            onboarding_tour.show(self)
        except Exception as e:
            messagebox.showerror("Welcome Tour", f"Couldn't open the welcome tour:\n{e}")

    def show_help_center(self, topic=None):
        manual_path = _find_bundled_file("TechDrive_User_Manual.md")
        if manual_path is None:
            return self._show_user_manual_legacy()
        try:
            from gui import doc_viewer
            doc_viewer.show_help(self, manual_path, topic=topic,
                                 help_items=self._viewer_help_items("help"))
        except Exception as e:
            print(f"Help Center failed, using plain viewer: {e}")
            self._show_user_manual_legacy()

    def show_user_manual(self):
        self.show_help_center()

    def show_eula(self, section=None):
        eula_path = _find_bundled_file("EULA_FULL.txt")
        if eula_path is None:
            return self._show_eula_legacy()
        try:
            from gui import doc_viewer
            doc_viewer.show_eula(self, eula_path, section=section,
                                 help_items=self._viewer_help_items("eula"))
        except Exception as e:
            print(f"EULA viewer failed, using plain viewer: {e}")
            self._show_eula_legacy()

    def _show_user_manual_legacy(self):
        manual_path = _find_bundled_file("TechDrive_User_Manual.md")
        if manual_path is None:
            messagebox.showerror("User Manual",
                                  "Couldn't find TechDrive_User_Manual.md in any expected "
                                  "location. If you're running a built .exe, make sure it "
                                  "was built with 'pyinstaller techdrive.spec' (not a plain "
                                  "'pyinstaller techdrive.py'), which is what actually bundles "
                                  "this file.")
            return
        try:
            with open(manual_path, "r", encoding="utf-8") as f:
                manual_text = f.read()
        except OSError as e:
            messagebox.showerror("User Manual", f"Found {manual_path} but couldn't read it:\n{e}")
            return

        win = tk.Toplevel(self)
        win.title("TechDrive - User Manual")
        win.configure(bg=BG)
        win.geometry("700x600")

        text = tk.Text(win, wrap="word", bg=BG_LIGHT, fg=FG, insertbackground=FG,
                        relief="flat", padx=14, pady=14, font=("Segoe UI", 9))
        scroll = ttk.Scrollbar(win, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=(10, 4))
        scroll.pack(side="left", fill="y", pady=(10, 4))

        # Light styling for common markdown so it doesn't read as a wall
        # of raw '#'/'**' characters, without pulling in a full markdown
        # rendering dependency just for this viewer. Handles headings and
        # inline **bold** - the two markers actually used in
        # TechDrive_User_Manual.md - not general markdown.
        import re
        text.tag_configure("h1", font=("Segoe UI", 14, "bold"), spacing3=6)
        text.tag_configure("h2", font=("Segoe UI", 11, "bold"), spacing3=4)
        text.tag_configure("h3", font=("Segoe UI", 9, "bold"), spacing3=2)
        text.tag_configure("bold", font=("Segoe UI", 9, "bold"))

        bold_re = re.compile(r"\*\*(.+?)\*\*")

        def _insert_with_inline_bold(line, extra_tag=None):
            pos = 0
            for m in bold_re.finditer(line):
                if m.start() > pos:
                    text.insert("end", line[pos:m.start()], extra_tag or ())
                tags = ("bold",) if extra_tag is None else (extra_tag, "bold")
                text.insert("end", m.group(1), tags)
                pos = m.end()
            text.insert("end", line[pos:] + "\n", extra_tag or ())

        for line in manual_text.splitlines():
            if line.startswith("### "):
                _insert_with_inline_bold(line[4:], "h3")
            elif line.startswith("## "):
                _insert_with_inline_bold(line[3:], "h2")
            elif line.startswith("# "):
                _insert_with_inline_bold(line[2:], "h1")
            else:
                _insert_with_inline_bold(line)

        text.configure(state="disabled")

        ttk.Button(win, text="Close", command=win.destroy).pack(pady=(0, 10))

    def _show_eula_legacy(self):
        eula_path = _find_bundled_file("EULA_FULL.txt")
        if eula_path is None:
            messagebox.showerror("EULA",
                                  "Couldn't find EULA_FULL.txt in any expected location. "
                                  "If you're running a built .exe, make sure it was built "
                                  "with 'pyinstaller techdrive.spec' (not a plain "
                                  "'pyinstaller techdrive.py'), which is what actually "
                                  "bundles this file.")
            return
        try:
            with open(eula_path, "r", encoding="utf-8") as f:
                eula_text = f.read()
        except OSError as e:
            messagebox.showerror("EULA", f"Found {eula_path} but couldn't read it:\n{e}")
            return

        win = tk.Toplevel(self)
        win.title("EULA / Terms of Use")
        win.configure(bg=BG)
        win.geometry("700x600")

        text = tk.Text(win, wrap="word", bg=BG_LIGHT, fg=FG, insertbackground=FG,
                        relief="flat", padx=14, pady=14, font=("Consolas", 9))
        scroll = ttk.Scrollbar(win, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=(10, 4))
        scroll.pack(side="left", fill="y", pady=(10, 4))

        text.insert("1.0", eula_text)
        text.configure(state="disabled")

        ttk.Label(win, text="Scroll to the end to review the full Agreement.",
                  background=BG, foreground="#9aa0a6").pack(anchor="w", padx=14, pady=(0, 4))
        ttk.Button(win, text="Close", command=win.destroy).pack(pady=(0, 10))

    def show_about(self):
        messagebox.showinfo("About TechDrive",
                             "TechDrive v1.1 - All-in-One System Utility\n"
                             "PC repair & diagnostic tools in one lightweight app.\n"
                             "Fast. Lightweight. Powerful.\n\n"
                             "Help Center: F1   |   Legal: Help > EULA")

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------
    def _collect_report_data(self):
        lines = [f"TechDrive System Report — {datetime.now()}", "=" * 50]
        lines.append(f"OS: {platform.platform()}")
        if psutil:
            lines.append(f"CPU cores: {psutil.cpu_count(logical=True)}  Usage: {psutil.cpu_percent(interval=0.3)}%")
            vm = psutil.virtual_memory()
            lines.append(f"RAM: {bytes_fmt(vm.total)} total, {vm.percent}% used")
            for part in psutil.disk_partitions():
                try:
                    u = psutil.disk_usage(part.mountpoint)
                    lines.append(f"Disk {part.device}: {bytes_fmt(u.total)} total, {u.percent}% used")
                except PermissionError:
                    pass
        lines.append(f"License tier: {self.license.tier} ({TIER_INFO[self.license.tier]['name']})")
        return "\n".join(lines)

    def generate_report_txt(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="techdrive_report.txt")
        if not path:
            return
        data = report_builder.build_report_data()
        with open(path, "w", encoding="utf-8") as f:
            f.write(report_builder._text_report(data))
        messagebox.showinfo("Report", f"Report saved to {path}")

    def generate_report_pdf(self):
        path = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile="techdrive_report.pdf")
        if not path:
            return
        try:
            data = report_builder.build_report_data()
            report_builder._write_pdf(path, report_builder._text_report(data))
            messagebox.showinfo("Report", f"PDF report saved to {path}")
        except Exception as e:
            messagebox.showerror("Report", f"Could not generate PDF: {e}")

    def _write_simple_pdf(self, path, text):
        """Minimal single-page-per-chunk PDF writer (no external deps)."""
        lines = text.split("\n")
        chunks = [lines[i:i + 45] for i in range(0, len(lines), 45)] or [[""]]
        def esc(s):
            return s.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")

        content_objs = []
        for chunk in chunks:
            content = "BT /F1 10 Tf 40 780 Td 14 TL\n"
            for line in chunk:
                content += f"({esc(line)}) Tj T*\n"
            content += "ET"
            content_objs.append(content)

        pdf_objs = []
        pdf_objs.append("<< /Type /Catalog /Pages 2 0 R >>")
        kids = " ".join(f"{4 + 2*i} 0 R" for i in range(len(content_objs)))
        pdf_objs.append(f"<< /Type /Pages /Kids [{kids}] /Count {len(content_objs)} >>")
        pdf_objs.append("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")
        page_objs = []
        stream_objs = []
        for i, content in enumerate(content_objs):
            page_objs.append(
                f"<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 3 0 R >> >> "
                f"/MediaBox [0 0 612 792] /Contents {5 + 2*i} 0 R >>")
            stream_objs.append(content)

        all_objs = [pdf_objs[0], pdf_objs[1], pdf_objs[2]]
        for p, s in zip(page_objs, stream_objs):
            all_objs.append(p)
            all_objs.append(("STREAM", s))

        with open(path, "wb") as f:
            f.write(b"%PDF-1.4\n")
            offsets = [0]
            for idx, obj in enumerate(all_objs, start=1):
                offsets.append(f.tell())
                if isinstance(obj, tuple):
                    stream = obj[1].encode("latin-1", "replace")
                    f.write(f"{idx} 0 obj\n<< /Length {len(stream)} >>\nstream\n".encode())
                    f.write(stream)
                    f.write(b"\nendstream\nendobj\n")
                else:
                    f.write(f"{idx} 0 obj\n{obj}\nendobj\n".encode())
            xref_start = f.tell()
            f.write(f"xref\n0 {len(all_objs)+1}\n".encode())
            f.write(b"0000000000 65535 f \n")
            for off in offsets[1:]:
                f.write(f"{off:010d} 00000 n \n".encode())
            f.write(f"trailer\n<< /Size {len(all_objs)+1} /Root 1 0 R >>\nstartxref\n{xref_start}\n%%EOF".encode())

    # ------------------------------------------------------------------
    # Status bar updater
    # ------------------------------------------------------------------
    def _start_status_updater(self):
        self._status_job = None
        def update():
            if getattr(self, "_closing", False):
                return
            if psutil:
                self.status_cpu.set(f"CPU: {psutil.cpu_percent(interval=None):.0f}%")
                self.status_ram.set(f"RAM: {psutil.virtual_memory().percent:.0f}%")
            interval = db.get_setting("monitor_refresh_ms", 1000)
            if db.get_setting("low_power_mode", False):
                interval = max(interval, 2000)
            self._status_job = self.after(interval, update)
        update()

    def _on_unmap(self, event):
        """Fires on every iconify (and on some platforms, other unmaps of
        child widgets that bubble here too — guarded by checking this is
        the toplevel itself and that it's really iconic). When both
        "minimize_to_tray" is on and a real tray icon exists, hide to tray
        instead of leaving a taskbar-only minimized window, mirroring how
        Windows-native tray apps behave."""
        if event.widget is not self:
            return
        if not self._minimize_to_tray_armed:
            return
        if not db.get_setting("minimize_to_tray", False):
            return
        if self._tray is None or self._tray._icon is None:
            return  # no tray icon running - fall back to a normal minimize
        try:
            if self.state() == "iconic":
                self._minimize_to_tray_armed = False
                self.withdraw()
                self._minimize_to_tray_armed = True
        except Exception:
            pass

    def _on_close(self, force_quit=False):
        if getattr(self, "_closing", False):
            return
        if (not force_quit and db.get_setting("close_to_tray", False)
                and self._tray is not None and self._tray._icon is not None):
            # Hide to tray instead of quitting - the tray menu's Exit item
            # (or force_quit=True) is what actually closes the app now.
            self.withdraw()
            return
        if db.get_setting("confirm_on_exit", False):
            if not messagebox.askyesno("Exit TechDrive", "Close TechDrive now?"):
                return
        if db.get_setting("remember_window_geometry", True):
            try:
                db.set_setting("window_geometry", self.geometry())
            except Exception:
                pass
        if db.get_setting("clear_recent_on_exit", False):
            try:
                db.clear_recent()
            except Exception:
                pass
        self._closing = True
        for job in list(getattr(self, "_bg_poll_jobs", set())):
            try:
                self.after_cancel(job)
            except Exception:
                pass
        getattr(self, "_bg_poll_jobs", set()).clear()
        # Stop timers owned by the long-lived shell explicitly. Cancelling
        # only the jobs TechDrive owns avoids Tk's double-delete problem that
        # occurs when every pending Tcl callback is cancelled indiscriminately.
        if self._ui_pump_job:
            try:
                self.after_cancel(self._ui_pump_job)
            except Exception:
                pass
            self._ui_pump_job = None
        for attr in ("_status_job", "_trial_job"):
            job = getattr(self, attr, None)
            if job:
                try:
                    self.after_cancel(job)
                except Exception:
                    pass
                setattr(self, attr, None)
        if hasattr(self, "_rgb_accent_widgets"):
            try:
                edges, corners = self._rgb_accent_widgets()
                for widget in list(edges) + list(corners):
                    try:
                        widget.stop()
                    except Exception:
                        pass
            except Exception:
                pass
        if getattr(self, "_tray", None) is not None:
            try:
                self._tray._destroy()
            except Exception:
                pass
        # Developer-supplied shutdown cue; start it before destroying Tk.
        sounds.play("shutdown")
        self.destroy()


# ---------------------------------------------------------------------------
# Plugin system
# ---------------------------------------------------------------------------
# Every module in techdrive_modules/ is an optional bundled tool group. A
# disabled group is simply removed from the live catalogue/dispatch table;
# its source remains bundled so it can be enabled again without downloading.
#
# TOOL_DISPATCH maps (category, tool_name) -> bound function. It exists to
# fix a real bug: most plugin modules define their functions as
# tool_<modulename>_<toolname> (e.g. tool_partition_tools_table_backup),
# but open_tool() below only ever looked up tool_<toolname> (no prefix) -
# so those functions were never reachable; clicking the tool showed "Tool
# implementation missing". Rather than renaming ~500 functions across ~70
# files (and running into the cases where two different categories happen
# to use the same tool name, which would collide if everything were
# flattened onto one tool_<name> attribute), each module's own tool_*
# functions are paired up 1:1, in source-definition order, with that same
# module's own CATALOGUE tool list - the two lists are always the same
# length and order for every plugin module - and the pairing is stored
# here keyed by the exact (category, tool_name) tuple. open_tool() checks
# this table first.
TOOL_DISPATCH = {}

# modname -> {"id", "name", "icon", "category", "tools": [...], "desc"}
# Populated once by scan_plugins(), used by the Core Module Manager to list
# what's available regardless of install state.
PLUGIN_REGISTRY = {}

# modname -> imported module object, cached so install/uninstall don't
# need to re-import.
PLUGIN_MODULES = {}

# modname -> the exact list of (category, icon, tools) tuples that were
# appended to CATALOGUE for that module, so disable can remove exactly
# those and nothing else.
_INSTALLED_CATALOGUE_ENTRIES = {}

# Set of currently enabled module names (kept in memory so the live
# catalogue/dispatch operations remain cheap).
INSTALLED_PLUGINS = set()


# Explicit, known-correct list of every tool module bundled in
# techdrive_modules/ (generated from the actual files present). This
# exists because scan_plugins() used to rely SOLELY on
# pkgutil.iter_modules(techdrive_modules.__path__) to discover which
# modules exist - that works perfectly against a real filesystem
# directory (source/dev mode), but is a well-known PyInstaller pitfall:
# against a frozen/bundled package, pkgutil's introspection of
# PyInstaller's internal PYZ-archive importer can silently enumerate
# few or none of the actual bundled submodules, even though every
# module genuinely got compiled in via collect_submodules() in the
# spec. That mismatch is exactly what "tools work with `python
# techdrive.py` but are missing from the built .exe" looks like.
# Keeping this list explicit means plugin discovery no longer depends
# on that fragile introspection at all, in either environment.
_KNOWN_PLUGIN_MODULES = [
    # Curated TechDrive 100-tool release. Keep this list explicit so the
    # frozen build and source build expose the same focused tool set.
    'backup_tools', 'batch_rename', 'cpu_monitor', 'disk_test', 'disk_tools',
    'file_search', 'gpu_monitor', 'network_tools', 'ram_monitor', 'restore_tools',
    'security_tools', 'storage_health', 'system_repair', 'td_sysnote_diagnostics',
    'wifi_tools',
]


def scan_plugins():
    """Imports every module under techdrive_modules/ once, to read its
    CATALOGUE for display metadata. Importing does NOT install it -
    CATALOGUE/TOOL_DISPATCH/TechDriveApp are left untouched here.

    Discovery is driven primarily by _KNOWN_PLUGIN_MODULES (reliable in
    both source and frozen builds), with a pkgutil-based scan layered
    on top ONLY to catch a module added to techdrive_modules/ during
    development that hasn't been added to that list yet. In a frozen
    build the pkgutil pass typically finds nothing extra (or fails
    silently) - that's fine, the explicit list already covers
    everything that matters there."""
    import importlib
    try:
        import techdrive_modules
    except ImportError:
        print("techdrive_modules package not found next to techdrive.py; no plugins available.")
        return

    candidates = list(_KNOWN_PLUGIN_MODULES)

    for modname in candidates:
        if modname.startswith("_"):
            # Shared/support code (db helpers, ui helpers, implementation
            # classes), not a plugin in its own right — skip it so it
            # doesn't show up as an empty entry in the Core Module Manager.
            continue
        try:
            mod = importlib.import_module(f"techdrive_modules.{modname}")
        except Exception as e:
            print(f"Failed to load plugin module {modname}: {e}")
            continue
        PLUGIN_MODULES[modname] = mod
        cat_list = getattr(mod, "CATALOGUE", [])
        tool_count = sum(len(tools) for _cat, _icon, tools in cat_list)
        # Empty legacy modules are retained only when needed as shared code;
        # they are not advertised as modules or tools in the product UI.
        if tool_count <= 0:
            continue
        primary_cat, primary_icon = (cat_list[0][0], cat_list[0][1])
        PLUGIN_REGISTRY[modname] = {
            "id": modname,
            "name": primary_cat,
            "icon": primary_icon,
            "categories": [c for c, _i, _t in cat_list],
            "tool_count": tool_count,
        }
    print(f"Scanned {len(PLUGIN_REGISTRY)} available plugins from techdrive_modules/")


def is_plugin_installed(modname):
    return modname in INSTALLED_PLUGINS


def is_plugin_enabled(modname):
    """Return whether a bundled optional tool group is currently enabled."""
    return modname in INSTALLED_PLUGINS and modname not in set(db.get_setting("disabled_plugins", []))


def enable_plugin(modname):
    """Enable a bundled tool group in the current process."""
    if modname not in PLUGIN_REGISTRY:
        return False
    ok = install_plugin(modname)
    if ok:
        disabled = set(db.get_setting("disabled_plugins", []))
        disabled.discard(modname)
        db.set_setting("disabled_plugins", sorted(disabled))
    return ok


def disable_plugin(modname):
    """Disable a bundled tool group without deleting its source files."""
    if modname not in PLUGIN_REGISTRY:
        return False
    # If it is already disabled, keep the requested state idempotent.
    if modname not in INSTALLED_PLUGINS:
        disabled = set(db.get_setting("disabled_plugins", []))
        disabled.add(modname)
        db.set_setting("disabled_plugins", sorted(disabled))
        return True
    ok = uninstall_plugin(modname)
    if ok:
        disabled = set(db.get_setting("disabled_plugins", []))
        disabled.add(modname)
        db.set_setting("disabled_plugins", sorted(disabled))
    return ok


def install_plugin(modname):
    """Merges one plugin module's tools into the live app. Safe to call
    more than once for the same modname (no-ops if already installed)."""
    import inspect
    if modname in INSTALLED_PLUGINS:
        return True
    mod = PLUGIN_MODULES.get(modname)
    if mod is None:
        return False
    for name in dir(mod):
        if name.startswith("tool_"):
            setattr(TechDriveApp, name, getattr(mod, name))
    added_entries = []
    if hasattr(mod, "CATALOGUE"):
        own_funcs = [getattr(mod, n) for n in vars(mod) if n.startswith("tool_")
                    and inspect.isfunction(getattr(mod, n))
                    and inspect.getmodule(getattr(mod, n)) is mod]
        own_funcs.sort(key=lambda f: f.__code__.co_firstlineno)
        own_tools = [(cat, t) for cat, _icon, tools in mod.CATALOGUE for t in tools]
        if len(own_funcs) == len(own_tools):
            for (cat, tool_name), func in zip(own_tools, own_funcs):
                TOOL_DISPATCH[(cat, tool_name)] = func
        else:
            print(f"{modname}: {len(own_tools)} catalogue tools but {len(own_funcs)} "
                  f"tool_* functions - couldn't pair them up, falling back to name lookup.")
        # Same "only ship tools with a real implementation" trim the old
        # startup loader did, just scoped to this one plugin now.
        for cat, icon, tools in mod.CATALOGUE:
            working = [t for t in tools
                      if (cat, t) in TOOL_DISPATCH or hasattr(TechDriveApp, "tool_" + slugify(t))]
            if working:
                entry = (cat, icon, working)
                CATALOGUE.append(entry)
                added_entries.append(entry)
    _INSTALLED_CATALOGUE_ENTRIES[modname] = added_entries
    INSTALLED_PLUGINS.add(modname)
    return True


def uninstall_plugin(modname):
    """Removes exactly the CATALOGUE entries and dispatch entries that
    install_plugin(modname) added. The plugin's tool_* methods stay
    attached to TechDriveApp (harmless dead weight) since other installed
    plugins may coincidentally share method names generated by the same
    template - only the catalogue/dispatch wiring is undone."""
    if modname not in INSTALLED_PLUGINS:
        return False
    for entry in _INSTALLED_CATALOGUE_ENTRIES.pop(modname, []):
        try:
            CATALOGUE.remove(entry)
        except ValueError:
            pass
        cat, _icon, tools = entry
        for t in tools:
            TOOL_DISPATCH.pop((cat, t), None)
    INSTALLED_PLUGINS.discard(modname)
    return True


def _plugins_dir():
    import techdrive_modules
    return techdrive_modules.__path__[0]


def _scan_plugin_dependencies(py_source):
    """Static scan (no import/execution) for module-level references to
    OTHER techdrive_modules files - e.g. `from techdrive_modules import
    live_monitor` or `from techdrive_modules.partition_tools import X`.

    WHY THIS EXISTS: several of the 93 tools were originally written
    assuming every module in techdrive_modules/ would always be present
    together (a monolithic app), not as independently-downloadable
    single-file plugins. Once tools became individually zipped/fetched,
    any tool that imports a SIBLING tool module at its own top level
    fails immediately on import unless that sibling happens to already
    be installed - discovered by actually installing all 91 tools
    headlessly and finding 6 fail with 'No module named
    techdrive_modules.X'. This scan is what lets import_plugin_zip()
    fetch that sibling automatically instead of just failing.

    Returns a set of sibling modnames referenced (e.g. {"live_monitor",
    "partition_tools"}), NOT including the module's own name or
    underscore-prefixed shared/support files (those ship with the base
    app, never fetched as plugins - see import_plugin_zip's own name
    validation)."""
    import ast
    try:
        tree = ast.parse(py_source)
    except SyntaxError:
        return set()

    deps = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module == "techdrive_modules":
                for alias in node.names:
                    deps.add(alias.name)
            elif node.module and node.module.startswith("techdrive_modules."):
                sub = node.module[len("techdrive_modules."):].split(".")[0]
                deps.add(sub)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith("techdrive_modules.") and alias.name.count(".") == 1:
                    deps.add(alias.name.split(".")[1])

    deps = {d for d in deps if d and not d.startswith("_")}
    return deps


def import_plugin_zip(source, install=True, _base_url=None, _seen=None):
    """Adds a plugin from a .zip file, either a local path or a URL.

    The zip must contain exactly one top-level module: either a single
    ``<name>.py`` file, or a ``<name>/`` package directory with an
    ``__init__.py``. That name becomes the plugin's modname. Existing
    files are never silently overwritten - if a module with that name
    is already on disk, this refuses and returns an error string so the
    caller can ask the user to confirm/rename instead of clobbering it.

    If the plugin's source references a SIBLING techdrive_modules file
    at module level (see _scan_plugin_dependencies) that isn't already
    installed, this fetches and installs that dependency first,
    recursively - _base_url is the same host the top-level plugin came
    from (siblings are assumed to live at the same base URL, which is
    true for everything published through the Core Module Manager today), and
    _seen guards against a dependency cycle turning into infinite
    recursion. Only applies when source is a URL; a local-file caller
    (e.g. a test harness) gets today's behavior unchanged.

    Returns (True, modname) on success, or (False, error_message). On a
    dependency failure, the error message names which dependency failed
    and why, not just the top-level symptom.
    """
    import zipfile
    import tempfile
    import importlib
    import pkgutil

    is_url = source.startswith("http://") or source.startswith("https://")
    if _base_url is None and is_url:
        _base_url = source.rsplit("/", 1)[0]
    if _seen is None:
        _seen = set()

    try:
        if is_url:
            import urllib.request
            req = urllib.request.Request(source, headers={"User-Agent": "TechDrive-PluginImporter"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = resp.read()
            tmp_fd, tmp_path = tempfile.mkstemp(suffix=".zip")
            with os.fdopen(tmp_fd, "wb") as f:
                f.write(data)
            zip_path = tmp_path
        else:
            zip_path = source
            if not os.path.isfile(zip_path):
                return False, f"No such file: {zip_path}"

        try:
            if not zipfile.is_zipfile(zip_path):
                return False, "Not a valid zip file."

            with zipfile.ZipFile(zip_path) as zf:
                names = [n for n in zf.namelist() if not n.endswith("/")]
                if not names:
                    return False, "Zip is empty."

                # Reject anything trying to escape the plugin dir, and
                # anything that isn't plain "<name>.py" or "<pkg>/...".
                top_level = set()
                for n in names:
                    if n.startswith("/") or ".." in n.split("/"):
                        return False, f"Unsafe path in zip: {n}"
                    top_level.add(n.split("/")[0])

                if len(top_level) != 1:
                    return False, ("Zip must contain exactly one top-level module "
                                    "(a single .py file or one package folder), "
                                    f"found: {sorted(top_level)}")

                entry = next(iter(top_level))
                if entry.endswith(".py"):
                    modname = entry[:-3]
                else:
                    modname = entry
                    if f"{entry}/__init__.py" not in names:
                        return False, f"Package '{entry}/' has no __init__.py"

                if modname.startswith("_"):
                    return False, ("Plugin name can't start with '_' - that prefix "
                                    "is reserved for shared/support modules.")

                dest_dir = _plugins_dir()
                dest_path = os.path.join(dest_dir, entry)
                already_present = os.path.exists(dest_path)
                if already_present and modname not in _seen:
                    # Already installed (e.g. as a dependency of an
                    # earlier plugin in this same bulk-install run, or
                    # from a previous session) - not an error, just
                    # nothing further to do for this one.
                    if modname in PLUGIN_MODULES:
                        return True, modname
                elif already_present:
                    return False, (f"A module named '{modname}' already exists in "
                                    "techdrive_modules/. Remove it first or rename "
                                    "the plugin before importing.")

                if not already_present:
                    # Dependency scan happens BEFORE extraction: if a
                    # sibling is missing, fetch+install it first so the
                    # import below (which runs the plugin's top-level
                    # code, including any `from techdrive_modules import
                    # X`) doesn't fail.
                    py_bytes = zf.read(entry) if entry.endswith(".py") else zf.read(f"{entry}/__init__.py")
                    deps = _scan_plugin_dependencies(py_bytes.decode("utf-8", errors="replace"))
                    deps.discard(modname)
                    for dep in sorted(deps):
                        dep_path = os.path.join(dest_dir, f"{dep}.py")
                        if os.path.isfile(dep_path) or dep in PLUGIN_MODULES:
                            continue
                        if dep in _seen:
                            return False, (f"Dependency cycle detected installing '{modname}': "
                                            f"'{dep}' was already being installed.")
                        if _base_url is None:
                            return False, (f"'{modname}' needs '{dep}', which isn't installed, "
                                            "and no source URL is available to fetch it "
                                            "automatically (local-file install).")
                        dep_ok, dep_result = import_plugin_zip(
                            f"{_base_url}/{dep}.zip", install=True,
                            _base_url=_base_url, _seen=_seen | {modname})
                        if not dep_ok:
                            return False, (f"'{modname}' requires '{dep}', which failed to "
                                            f"install automatically: {dep_result}")

                    zf.extractall(dest_dir, members=names)
        finally:
            if is_url:
                try:
                    os.remove(zip_path)
                except OSError:
                    pass
    except Exception as e:
        return False, f"Import failed: {e}"

    # Re-import the package fresh so pkgutil picks up the new module,
    # then scan just this one plugin into the registries.
    importlib.invalidate_caches()
    try:
        mod = importlib.import_module(f"techdrive_modules.{modname}")
    except Exception as e:
        return False, f"Plugin extracted but failed to import: {e}"

    PLUGIN_MODULES[modname] = mod
    cat_list = getattr(mod, "CATALOGUE", [])
    tool_count = sum(len(tools) for _cat, _icon, tools in cat_list)
    primary_cat, primary_icon = (cat_list[0][0], cat_list[0][1]) if cat_list else (modname, "◇")
    PLUGIN_REGISTRY[modname] = {
        "id": modname,
        "name": primary_cat,
        "icon": primary_icon,
        "categories": [c for c, _i, _t in cat_list],
        "tool_count": tool_count,
    }

    if install:
        install_plugin(modname)

    return True, modname


def import_plugin_by_name(base_url, tool_name, install=True):
    """Builds '<base_url>/<tool_name>.zip' and imports it. This is just
    a thin convenience wrapper around import_plugin_zip() for the common
    case where plugins are published one zip per tool, named after the
    tool itself (which is how the 93 techdrive_modules plugins are
    packaged)."""
    base = base_url.rstrip("/")
    url = f"{base}/{tool_name}.zip"
    return import_plugin_zip(url, install=install)


def import_plugins_by_names(base_url, tool_names, install=True, on_progress=None):
    """Imports multiple tools by name from the same base URL. Does not
    stop on individual failures (a plugin that's already present, or a
    404 from the host, shouldn't block the rest of the batch) - collects
    every result instead.

    on_progress(tool_name, ok, result), if given, is called after each
    one so a caller can update a progress bar / log line live.

    Returns a list of (tool_name, ok, result) tuples in the same order
    as tool_names.
    """
    results = []
    for tool_name in tool_names:
        ok, result = import_plugin_by_name(base_url, tool_name, install=install)
        results.append((tool_name, ok, result))
        if on_progress:
            on_progress(tool_name, ok, result)
    return results


scan_plugins()



def _enable_windows_dpi_awareness():
    """Tell Windows we handle scaling ourselves, before any Tk window is
    created.

    Without this, Windows treats the process as DPI-unaware: Tk lays out
    and measures every widget (fonts, the dynamically-measured nav rail
    width, etc.) at the standard 96 DPI, and then Windows bitmap-stretches
    the *entire already-rendered window* to match the display's real scale
    factor (125%/150% are common on laptops). Tk's own frame boundaries
    stay exactly where it calculated them, but the glyphs get magnified
    past those boundaries by that OS-level stretch - which is what makes
    long nav-rail labels ("Dashboard", "CPU & RAM", "Backup & Recovery")
    look clipped even though _required_rail_width() measured them
    correctly. Declaring per-monitor DPI awareness up front makes Windows
    render natively at the real DPI instead of stretching a bitmap, so
    Tk's measurements and the actual on-screen pixels agree.
    """
    if sys.platform != "win32":
        return
    import ctypes
    try:
        # Per-Monitor v2 (most accurate, matches modern Windows behavior).
        ctypes.windll.user32.SetProcessDpiAwarenessContext(-4)
        return
    except (AttributeError, OSError):
        pass
    try:
        # Per-Monitor v1 fallback (Windows 8.1+).
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except (AttributeError, OSError):
        pass
    try:
        # System-DPI-aware fallback (Vista+) - better than nothing.
        ctypes.windll.user32.SetProcessDPIAware()
    except (AttributeError, OSError):
        pass


def _sync_tk_scaling(app):
    """Once the Tk root exists, match Tk's own widget-geometry scaling to
    the real system DPI so fonts/pixel measurements line up with what
    Windows actually paints (relevant once the process is DPI-aware)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        dc = ctypes.windll.user32.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)  # LOGPIXELSX
        ctypes.windll.user32.ReleaseDC(0, dc)
        if dpi:
            app.tk.call("tk", "scaling", dpi / 72.0)
    except (AttributeError, OSError):
        pass


def _acquire_single_instance_lock():
    """Best-effort, cross-platform-ish single-instance guard: a lock file
    under the same ~/.techdrive dir the settings DB already uses, holding
    this process's PID plus its executable name. Not bulletproof (a
    crashed process can leave a stale lock) - if the recorded PID isn't
    actually running anymore, OR is running but is no longer a TechDrive
    process (Windows recycles PIDs - a crashed/killed TechDrive's old PID
    can get reused by a completely unrelated process, which would make a
    naive "does this PID exist" check wrongly report TechDrive as still
    running forever, blocking every future launch until the stale lock
    file is manually deleted), the lock is treated as stale and
    reclaimed rather than blocking."""
    lock_path = os.path.join(db.DB_DIR, "techdrive.lock")
    os.makedirs(db.DB_DIR, exist_ok=True)
    if os.path.exists(lock_path):
        try:
            with open(lock_path) as f:
                raw = f.read().strip()
            # New format: "PID|exe_name". Old format (just digits) is
            # also accepted for one release, then treated as stale below
            # since it has no exe name to verify against.
            parts = raw.split("|", 1)
            old_pid = int(parts[0])
            old_exe_name = parts[1] if len(parts) > 1 else None

            still_running = False
            if psutil and old_exe_name and psutil.pid_exists(old_pid):
                try:
                    proc_name = psutil.Process(old_pid).name()
                    # Compare case-insensitively; exact match only - a
                    # coincidentally-similar process name is treated as
                    # NOT us, erring toward letting the new launch
                    # proceed rather than blocking on a false positive.
                    still_running = proc_name.lower() == old_exe_name.lower()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    still_running = False
            elif psutil and old_exe_name is None and psutil.pid_exists(old_pid):
                # Old-format lock file, can't verify identity - assume
                # stale rather than risk blocking forever on a reused PID.
                still_running = False

            if still_running:
                return False
        except Exception:
            pass  # unreadable/garbage lock file - treat as stale
    try:
        if psutil:
            exe_name = psutil.Process(os.getpid()).name()
        else:
            exe_name = os.path.basename(sys.executable)
        with open(lock_path, "w") as f:
            f.write(f"{os.getpid()}|{exe_name}")
    except Exception:
        pass
    return True


def main():
    if "--make-icon" in sys.argv:
        save_icon("techdrive_icon.ico")
        return
    if db.get_setting("single_instance_only", True) and not _acquire_single_instance_lock():
        try:
            tk.Tk().withdraw()
            messagebox.showinfo("TechDrive", "TechDrive is already running.")
        except Exception:
            print("TechDrive is already running.")
        return
    _enable_windows_dpi_awareness()
    _configure_logging()
    app = TechDriveApp()
    _sync_tk_scaling(app)
    app.mainloop()


def _report_fatal_startup_error():
    """With the console hidden, a startup crash would otherwise be silent
    ("I double-click and nothing happens"). Write the traceback to a log
    file and show it in a message box."""
    tb = traceback.format_exc()
    log_path = ""
    try:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".techdrive")
        log_dir = os.path.join(base, "TechDrive", "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, "startup_crash.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"\n===== {datetime.now()} =====\n{tb}\n")
    except Exception:
        pass
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "TechDrive failed to start",
            (tb[-1500:] + (f"\n\nFull details saved to:\n{log_path}" if log_path else "")),
        )
        root.destroy()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        import multiprocessing
        multiprocessing.freeze_support()  # needed for compiled Windows builds
    except Exception:
        pass
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        _report_fatal_startup_error()
        raise


# ===========================================================================
# License keys are now TD2 Ed25519-signed strings. The executable contains
# only the public verification key; the private signing key stays with the
# vendor/developer. Tier must be "P" or "B" - there is no Free-tier key.
# ===========================================================================
