# TechDrive Roomier Workspace Update

## Changes
- Increased the default main window target to use up to 97% of screen width and 94% of screen height, with caps that keep it within typical desktop bounds.
- Raised the minimum workspace dimensions for panels that need more room, while keeping the size adaptive to smaller displays.
- Increased shared tool-navigation strip height and outer spacing to improve readability and reduce cramped tool headers.
- Preserved the existing app, tool implementations, navigation, and catalogue rather than replacing it with a mockup.

## Validation
- `python -m compileall -q techdrive.py gui` passed.
- `python -m unittest discover -s tests -p 'test_tool_catalogue_and_safety.py'` passed (3 tests).
- A real Windows visual/runtime check has not been performed in this environment.

## Notes
This is a first workspace-sizing pass. It does not claim to have rebuilt every dashboard section into a pixel-identical implementation of the text wireframe. The existing dashboard remains live and functional; a full dashboard information-architecture rewrite should be tested separately to avoid breaking existing navigation and monitoring widgets.
