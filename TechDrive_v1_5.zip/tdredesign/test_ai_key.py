#!/usr/bin/env python3
"""
test_ai_key.py — standalone AI-key diagnostic (no GUI, no TechDrive settings)
================================================================================
Run this directly to see EXACTLY what happens when TechDrive tries to reach
your AI provider, with the full raw response - not a summarized message.

Usage:
    python3 test_ai_key.py

It will prompt for a provider and key (or you can hardcode them below for a
quick one-off test - just don't commit that file anywhere).
"""

import sys
import json

try:
    import requests
except ImportError:
    print("ERROR: the 'requests' package isn't installed.")
    print("Run:  pip install requests")
    sys.exit(1)

PROVIDERS = {
    "1": ("openrouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
    "2": ("groq", "https://api.groq.com/openai/v1", "llama-3.1-8b-instant"),
}


def main():
    print("Which provider?")
    print("  1) OpenRouter")
    print("  2) Groq")
    choice = input("> ").strip()
    if choice not in PROVIDERS:
        print("Invalid choice.")
        sys.exit(1)

    name, base_url, default_model = PROVIDERS[choice]
    key = input(f"Paste your {name} API key: ").strip()

    if not key:
        print("No key entered.")
        sys.exit(1)

    print(f"\nKey length: {len(key)} chars")
    print(f"Key starts with: {key[:8]}...")
    print(f"Key ends with: ...{key[-4:]}")
    if key != key.strip():
        print("WARNING: key has leading/trailing whitespace in the raw string you pasted.")

    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    # Step 1: connectivity check
    print(f"\n--- Step 1: reaching {base_url} ---")
    try:
        resp = requests.get(f"{base_url}/models", headers=headers, timeout=15)
        print(f"HTTP status: {resp.status_code}")
        print(f"Raw response body (first 1000 chars):\n{resp.text[:1000]}")
    except requests.exceptions.ConnectionError as e:
        print("CONNECTION ERROR - could not reach the server at all.")
        print(f"This means the network TechDrive is running on cannot reach {base_url}.")
        print("Check firewall/proxy/corporate network restrictions.")
        print(f"Raw error: {e}")
        sys.exit(1)
    except requests.exceptions.Timeout:
        print("TIMEOUT - the server didn't respond within 15 seconds.")
        sys.exit(1)
    except Exception as e:
        print(f"UNEXPECTED ERROR reaching the server: {type(e).__name__}: {e}")
        sys.exit(1)

    if resp.status_code == 401:
        print("\n=> 401 Unauthorized: the key itself is invalid or revoked.")
        print("   Generate a fresh key from the provider's dashboard and try again.")
        sys.exit(1)
    if resp.status_code == 403:
        print("\n=> 403 Forbidden: key valid but lacks permission (check account status/billing).")
        sys.exit(1)
    if resp.status_code >= 400:
        print(f"\n=> Unexpected error status {resp.status_code} on /models - see raw body above.")

    available_models = []
    try:
        data = resp.json().get("data", [])
        available_models = [m["id"] for m in data if "id" in m]
        print(f"\nModels available to this key ({len(available_models)}):")
        for m in available_models[:20]:
            print(f"  - {m}")
    except Exception as e:
        print(f"Could not parse model list: {e}")

    model = default_model if default_model in available_models else (
        available_models[0] if available_models else default_model
    )
    print(f"\n--- Step 2: sending a real chat completion using model '{model}' ---")

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "Say 'ready' if you can read this."}],
        "max_tokens": 20,
    }
    if name == "openrouter":
        headers["X-Title"] = "TechDrive Duck Assistant"

    try:
        resp2 = requests.post(f"{base_url}/chat/completions", headers=headers,
                               json=payload, timeout=20)
        print(f"HTTP status: {resp2.status_code}")
        print(f"Raw response body:\n{resp2.text[:2000]}")
    except Exception as e:
        print(f"REQUEST FAILED: {type(e).__name__}: {e}")
        sys.exit(1)

    if resp2.status_code == 200:
        try:
            content = resp2.json()["choices"][0]["message"]["content"]
            print(f"\n\u2713 SUCCESS. Model replied: {content!r}")
        except Exception as e:
            print(f"\nGot HTTP 200 but couldn't parse expected fields: {e}")
    else:
        print(f"\n\u2717 FAILED at chat completion step. See raw body above for the provider's own explanation.")


if __name__ == "__main__":
    main()
