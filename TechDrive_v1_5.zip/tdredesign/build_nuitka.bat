@echo off
REM ============================================================
REM  TechDrive 1.1 - Nuitka build, maximum size reduction
REM  Output: dist\TechDrive.exe  (single file, zstd-compressed)
REM  Needs : Python 3.10-3.14 (64-bit). A C compiler is downloaded
REM          automatically by Nuitka if none is installed.
REM  Usage : build_nuitka.bat              (default, any compiler)
REM          build_nuitka.bat msvc         (use Visual Studio Build Tools)
REM          build_nuitka.bat msvc lto     (MSVC + LTO = smallest exe)
REM          build_nuitka.bat console      (DEBUG: shows a console window so
REM                                         startup errors are visible)
REM          build_nuitka.bat upx          (also UPX-pack inner DLLs;
REM                                         needs upx.exe next to this file)
REM  NOTE  : LTO is OFF by default. The Zig compiler that Nuitka
REM          auto-downloads fails to link with LTO (undefined symbols
REM          frexpf / wmemchr / ... from zigc.lib). Only use "lto" with MSVC.
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1/3] Installing build + runtime requirements...
python -m pip install --upgrade pip || goto :err
python -m pip install -r requirements.txt || goto :err
REM zstandard is REQUIRED - without it Nuitka onefile is NOT compressed.
python -m pip install --upgrade nuitka zstandard ordered-set || goto :err

set UPXFLAGS=
set LTOFLAG=--lto=no
set CCFLAG=
set WANTUPX=
set CONSOLEFLAG=--windows-console-mode=disable
for %%A in (%*) do (
    if /i "%%A"=="lto"  set LTOFLAG=--lto=yes
    if /i "%%A"=="msvc" set CCFLAG=--msvc=latest
    if /i "%%A"=="upx"  set WANTUPX=1
    if /i "%%A"=="console" set CONSOLEFLAG=--windows-console-mode=force
)
if defined WANTUPX (
    if not exist "%~dp0upx.exe" goto :noupx
    set UPXFLAGS=--enable-plugins=upx --upx-binary="%~dp0upx.exe"
)

REM Clear leftovers from any previously failed build.
if exist dist\techdrive.dist  rmdir /s /q dist\techdrive.dist
if exist dist\techdrive.build rmdir /s /q dist\techdrive.build

echo [2/3] Compiling (this takes a while)...
python -m nuitka ^
  --onefile ^
  --assume-yes-for-downloads ^
  %LTOFLAG% ^
  %CCFLAG% ^
  --jobs=%NUMBER_OF_PROCESSORS% ^
  --remove-output ^
  --deployment ^
  --python-flag=no_docstrings ^
  --python-flag=no_asserts ^
  --python-flag=no_warnings ^
  --enable-plugins=tk-inter ^
  %CONSOLEFLAG% ^
  --windows-icon-from-ico=techdrive_icon.ico ^
  --output-dir=dist ^
  --output-filename=TechDrive.exe ^
  --company-name="TechDrive" ^
  --product-name="TechDrive" ^
  --file-description="TechDrive - All-in-One System Utility" ^
  --file-version=1.1.0.0 ^
  --product-version=1.1.0.0 ^
  --copyright="(c) 2026 TechDrive. All rights reserved." ^
  --include-package=techdrive_modules ^
  --include-package=gui ^
  --include-package=shared ^
  --include-package=i18n ^
  --include-module=techdrive_protection ^
  --include-module=fortknox_license ^
  --include-module=wmi --include-module=win32com.client --include-module=pythoncom ^
  --include-module=win32api --include-module=win32con ^
  --include-module=pynvml --include-module=GPUtil --include-module=cpuinfo ^
  --include-module=reportlab.pdfgen --include-module=fpdf --include-module=openpyxl ^
  --include-module=barcode --include-module=barcode.writer --include-module=markdown ^
  --include-module=winpty --include-module=rarfile --include-module=py7zr ^
  --include-module=pycdlib --include-module=pystray._win32 --include-module=sounddevice ^
  --include-data-dir=gui/assets=gui/assets ^
  --include-data-dir=i18n=i18n ^
  --include-data-files=techdrive_icon.ico=techdrive_icon.ico ^
  --include-data-files=TechDrive_User_Manual.md=TechDrive_User_Manual.md ^
  --include-data-files=EULA_FULL.txt=EULA_FULL.txt ^
  --nofollow-import-to=pydoc_data,idlelib,tkinter.test,lib2to3,pytest,IPython,PySide6 ^
  --nofollow-import-to=test_ai_key,windows_compatibility_verification,audit_codebase,screenshot_test ^
  --include-module=license_signing ^
  --noinclude-pytest-mode=nofollow ^
  --noinclude-IPython-mode=nofollow ^
  %UPXFLAGS% ^
  techdrive.py
if errorlevel 1 goto :err

echo [3/3] Done.
for %%F in (dist\TechDrive.exe) do echo Size: %%~zF bytes
exit /b 0

:noupx
echo upx.exe not found next to this script.

:err
echo BUILD FAILED - scroll up for the first error.
exit /b 1
