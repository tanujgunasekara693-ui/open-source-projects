#!/usr/bin/env python3
r"""
techdrive_modules/terminal_tools.py - Terminal Tools category
======================================================================
Real, working terminal utilities. This app runs whatever command the
user explicitly types into these panels, on their own machine, the
same way a built-in "run a command" box in any admin tool does -
it does not generate, obfuscate, or inject code of its own.

- PowerShell/CMD Launcher: run one real command and see its real
  output, or open a real interactive console window.
- Multiplexer: run several real commands in sequence.
- Script Runner: execute a real .ps1/.bat/.cmd file the user picks.
- History: a real on-disk log of commands run through this module.
- Scheduler: real Windows Task Scheduler via schtasks (list/create/delete).
- Log Viewer: real tail of a chosen log file, or recent Windows Event
  Log entries.
- Monitor: live real CPU/RAM readout alongside the terminal.
- Shortcuts: real user-defined saved commands (label + command),
  persisted to disk.
- Customizer: real console appearance settings (font size, buffer,
  QuickEdit) via the actual HKCU\Console registry key Windows itself
  reads for new console windows.
"""

import json
import os
import platform
import subprocess
import time
import tkinter as tk

try:
    import psutil
except ImportError:
    psutil = None

try:
    import winreg
except ImportError:
    winreg = None

from gui.tk_dialogs import filedialog
from gui.tool_view import CardPanel
from shared import database as db

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0
NEW_CONSOLE = subprocess.CREATE_NEW_CONSOLE if IS_WINDOWS and hasattr(subprocess, "CREATE_NEW_CONSOLE") else 0

_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".techdrive")
_HISTORY_PATH = os.path.join(_CONFIG_DIR, "terminal_history.json")
_SHORTCUTS_PATH = os.path.join(_CONFIG_DIR, "terminal_shortcuts.json")


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []


def _run(args, timeout=60, input_text=None):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           input=input_text, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip() or "(no output)"
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Command timed out."
    except Exception as e:
        return f"Error: {e}"


def _terminal_report(panel, result, app):
    """Render normal reports by default, or a phosphor terminal in CRT mode."""
    if db.get_setting("monitor_visual_skin", "standard") != "crt":
        panel.report(result)
        return
    panel.clear()
    lines = str(result or "(no output)").splitlines() or ["(no output)"]
    tk.Label(panel.body, text="CRT PHOSPHOR OUTPUT",
             bg="#031009", fg="#8dff9f",
             font=("Consolas", 8, "bold")).pack(anchor="w", padx=14, pady=(8, 3))
    output = tk.Text(
        panel.body,
        bg="#020803",
        fg="#a1ffad",
        insertbackground="#a1ffad",
        selectbackground="#174b22",
        font=("Consolas", 10, "bold"),
        height=min(28, max(8, len(lines))),
        wrap="none",
        relief="flat",
        highlightthickness=1,
        highlightbackground="#17542a",
        padx=8,
        pady=6,
    )
    output.tag_configure("scanline", background="#06140a")
    for index, line in enumerate(lines):
        output.insert("end", line + "\n", ("scanline",) if index % 2 else ())
    output.configure(state="disabled")
    output.pack(fill="both", expand=True, padx=14, pady=(0, 12))


def _log_history(shell, command):
    os.makedirs(_CONFIG_DIR, exist_ok=True)
    entries = []
    try:
        with open(_HISTORY_PATH, "r", encoding="utf-8") as f:
            entries = json.load(f)
    except (OSError, json.JSONDecodeError):
        pass
    entries.append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "shell": shell, "command": command})
    entries = entries[-200:]
    try:
        with open(_HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2)
    except OSError:
        pass


def _load_shortcuts():
    try:
        with open(_SHORTCUTS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return []


def _save_shortcuts(items):
    os.makedirs(_CONFIG_DIR, exist_ok=True)
    with open(_SHORTCUTS_PATH, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------



















