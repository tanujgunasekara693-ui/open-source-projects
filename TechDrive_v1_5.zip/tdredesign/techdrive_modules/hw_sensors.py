#!/usr/bin/env python3
"""
techdrive_modules/hw_sensors.py - Real hardware sampling back-end.
==================================================================
No CATALOGUE / no tool_* functions on purpose: this is the shared data
layer used by live_monitor.py, nvidia_gpu.py and clone_tools.py.

Every reading here comes from an actual sensor source. When a source
isn't present (no NVIDIA card, no admin rights, no SMART support) the
function returns None / an explanatory string - it never invents a value.

Sources, in the order each getter tries them:
  CPU/RAM/disk IO  psutil
  CPU temperature  LibreHardwareMonitor WMI -> OpenHardwareMonitor WMI ->
                   MSAcpi_ThermalZoneTemperature -> psutil.sensors_temperatures
  GPU              NVML (pynvml) -> nvidia-smi -> LibreHardwareMonitor ->
                   Win32_VideoController (static info only)
  Drive temp/SMART smartctl (smartmontools) -> LibreHardwareMonitor ->
                   MSStorageDriver_ATAPISmartData (attribute 0xC2)
"""

import json
import os
import platform
import re
import shutil
import subprocess
import time

try:
    import psutil
except ImportError:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def run(cmd, timeout=15):
    """Run an argv list, return (ok, stdout+stderr). Never raises."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           creationflags=NO_WINDOW)
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except FileNotFoundError:
        return False, f"{cmd[0]} not found"
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as e:
        return False, str(e)


def powershell(script, timeout=25):
    return run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


def which(name):
    return shutil.which(name)


def bytes_fmt(n):
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def temp_status(c, warn=70, bad=85):
    if c is None:
        return None
    if c < warn:
        return "good"
    return "warn" if c < bad else "bad"


# ---------------------------------------------------------------------------
# Hardware-monitor WMI bridges (LibreHardwareMonitor / OpenHardwareMonitor)
# ---------------------------------------------------------------------------
_LHM_CACHE = {"ns": None, "checked": 0}


def _hwmon_namespace():
    """Return the WMI namespace of a running LibreHardwareMonitor /
    OpenHardwareMonitor instance, or None. Re-probed every 30s so starting
    LHM while TechDrive is open is picked up."""
    if not IS_WINDOWS:
        return None
    if time.time() - _LHM_CACHE["checked"] < 30:
        return _LHM_CACHE["ns"]
    _LHM_CACHE["checked"] = time.time()
    _LHM_CACHE["ns"] = None
    try:
        import wmi  # noqa
    except Exception:
        return None
    for ns in ("root\\LibreHardwareMonitor", "root\\OpenHardwareMonitor"):
        try:
            import wmi
            c = wmi.WMI(namespace=ns)
            c.Sensor()
            _LHM_CACHE["ns"] = ns
            return ns
        except Exception:
            continue
    return None


def hwmon_sensors(sensor_type=None):
    """[(name, value, parent)] from LibreHardwareMonitor, [] if not running."""
    ns = _hwmon_namespace()
    if not ns:
        return []
    try:
        import wmi
        c = wmi.WMI(namespace=ns)
        out = []
        for s in c.Sensor():
            if sensor_type and s.SensorType != sensor_type:
                continue
            out.append((s.Name or "", float(s.Value) if s.Value is not None else None,
                        getattr(s, "Parent", "") or "", s.SensorType))
        return out
    except Exception:
        return []


# ---------------------------------------------------------------------------
# CPU
# ---------------------------------------------------------------------------
def cpu_temperature():
    """CPU package temperature in C, or None if no sensor is reachable."""
    for name, value, parent, stype in hwmon_sensors("Temperature"):
        if "/cpu/" in (parent or "").lower() and value:
            if "package" in name.lower() or "tctl" in name.lower() or "core" in name.lower():
                return round(value, 1)
    if psutil and hasattr(psutil, "sensors_temperatures"):
        try:
            temps = psutil.sensors_temperatures() or {}
            for key in ("coretemp", "k10temp", "zenpower", "acpitz", "cpu_thermal"):
                if key in temps and temps[key]:
                    entries = temps[key]
                    pkg = [e for e in entries if e.label and "package" in e.label.lower()]
                    return round((pkg or entries)[0].current, 1)
            for entries in temps.values():
                if entries:
                    return round(entries[0].current, 1)
        except Exception:
            pass
    if IS_WINDOWS:
        ok, out = powershell(
            "Get-CimInstance -Namespace root/WMI -ClassName MSAcpi_ThermalZoneTemperature "
            "-ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty CurrentTemperature")
        if ok and out.strip().isdigit():
            return round(int(out.strip()) / 10.0 - 273.15, 1)
    return None


def cpu_fan_rpm():
    for name, value, parent, stype in hwmon_sensors("Fan"):
        if value:
            return int(value)
    return None


def cpu_sample():
    if psutil is None:
        return {"error": "psutil is required (pip install psutil)"}
    freq = None
    try:
        f = psutil.cpu_freq()
        freq = round(f.current, 0) if f else None
    except Exception:
        pass
    return {
        "usage": psutil.cpu_percent(interval=None),
        "per_core": psutil.cpu_percent(interval=None, percpu=True),
        "freq_mhz": freq,
        "temp_c": cpu_temperature(),
        "processes": len(psutil.pids()),
        "threads": _thread_count(),
        "load1": (os.getloadavg()[0] if hasattr(os, "getloadavg") else None),
    }


def _thread_count():
    total = 0
    try:
        for p in psutil.process_iter(["num_threads"]):
            total += p.info.get("num_threads") or 0
    except Exception:
        return None
    return total


def cpu_static():
    info = {"model": platform.processor() or platform.machine(),
            "arch": platform.machine()}
    if psutil:
        try:
            info["physical"] = psutil.cpu_count(logical=False)
            info["logical"] = psutil.cpu_count(logical=True)
            f = psutil.cpu_freq()
            if f:
                info["max_mhz"] = round(f.max)
        except Exception:
            pass
    if IS_WINDOWS:
        ok, out = powershell("(Get-CimInstance Win32_Processor).Name")
        if ok and out.strip():
            info["model"] = out.strip().splitlines()[0]
    else:
        try:
            with open("/proc/cpuinfo") as fh:
                for line in fh:
                    if line.lower().startswith("model name"):
                        info["model"] = line.split(":", 1)[1].strip()
                        break
        except Exception:
            pass
    return info


# ---------------------------------------------------------------------------
# RAM
# ---------------------------------------------------------------------------
def ram_sample():
    if psutil is None:
        return {"error": "psutil is required (pip install psutil)"}
    vm = psutil.virtual_memory()
    try:
        sm = psutil.swap_memory()
        swap_total, swap_used, swap_percent = sm.total, sm.used, sm.percent
    except RuntimeError:
        # Some Windows machines have a broken/misconfigured PDH ("Performance
        # Data Helper") counter set, which makes psutil.swap_memory() raise
        # RuntimeError: PdhAddEnglishCounterW instead of returning data.
        # RAM itself still works fine via vm above - swap is just unknown.
        swap_total = swap_used = swap_percent = 0
    return {
        "total": vm.total, "used": vm.used, "available": vm.available,
        "percent": vm.percent, "cached": getattr(vm, "cached", 0),
        "swap_total": swap_total, "swap_used": swap_used, "swap_percent": swap_percent,
    }


def ram_modules():
    """Physical DIMMs (Windows via CIM, Linux via dmidecode when permitted)."""
    mods = []
    if IS_WINDOWS:
        ok, out = powershell(
            "Get-CimInstance Win32_PhysicalMemory | Select-Object BankLabel,Capacity,"
            "Speed,Manufacturer,PartNumber,ConfiguredClockSpeed | ConvertTo-Json -Compress")
        if ok and out.strip().startswith(("[", "{")):
            try:
                data = json.loads(out)
                for m in (data if isinstance(data, list) else [data]):
                    mods.append({
                        "slot": (m.get("BankLabel") or "?").strip(),
                        "size": int(m.get("Capacity") or 0),
                        "speed": m.get("ConfiguredClockSpeed") or m.get("Speed"),
                        "vendor": (m.get("Manufacturer") or "").strip(),
                        "part": (m.get("PartNumber") or "").strip(),
                    })
            except Exception:
                pass
    else:
        ok, out = run(["dmidecode", "-t", "memory"], timeout=10)
        if ok:
            cur = {}
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("Memory Device"):
                    if cur.get("size"):
                        mods.append(cur)
                    cur = {}
                if line.startswith("Size:") and "No Module" not in line:
                    m = re.search(r"(\d+)\s*(MB|GB)", line)
                    if m:
                        cur["size"] = int(m.group(1)) * (1024 ** 2 if m.group(2) == "MB" else 1024 ** 3)
                elif line.startswith("Locator:"):
                    cur["slot"] = line.split(":", 1)[1].strip()
                elif line.startswith("Configured Memory Speed:"):
                    cur["speed"] = line.split(":", 1)[1].strip()
                elif line.startswith("Manufacturer:"):
                    cur["vendor"] = line.split(":", 1)[1].strip()
                elif line.startswith("Part Number:"):
                    cur["part"] = line.split(":", 1)[1].strip()
            if cur.get("size"):
                mods.append(cur)
    return mods


# ---------------------------------------------------------------------------
# GPU
# ---------------------------------------------------------------------------
_NVML = {"ok": None, "mod": None}


def nvml():
    """Initialised pynvml module or None."""
    if _NVML["ok"] is not None:
        return _NVML["mod"]
    try:
        import pynvml
        pynvml.nvmlInit()
        _NVML["ok"] = True
        _NVML["mod"] = pynvml
    except Exception:
        _NVML["ok"] = False
        _NVML["mod"] = None
    return _NVML["mod"]


def nvidia_smi(query, timeout=10):
    exe = which("nvidia-smi")
    if not exe and IS_WINDOWS:
        cand = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"),
                            "System32", "nvidia-smi.exe")
        exe = cand if os.path.exists(cand) else None
    if not exe:
        return None
    ok, out = run([exe, f"--query-gpu={query}", "--format=csv,noheader,nounits"], timeout)
    if not ok:
        return None
    rows = []
    for line in out.splitlines():
        if not line.strip():
            continue
        rows.append([c.strip() for c in line.split(",")])
    return rows or None


def _f(v):
    try:
        if v in (None, "", "[N/A]", "N/A", "[Not Supported]", "Not Supported"):
            return None
        return float(v)
    except Exception:
        return None


def gpu_list():
    """All GPUs with live values. Each entry always has 'name' + 'source'."""
    gpus = []
    m = nvml()
    if m:
        try:
            for i in range(m.nvmlDeviceGetCount()):
                h = m.nvmlDeviceGetHandleByIndex(i)
                g = {"index": i, "source": "NVML", "vendor": "NVIDIA",
                     "name": _decode(m.nvmlDeviceGetName(h))}
                try:
                    u = m.nvmlDeviceGetUtilizationRates(h)
                    g["util"], g["mem_util"] = float(u.gpu), float(u.memory)
                except Exception:
                    pass
                try:
                    mi = m.nvmlDeviceGetMemoryInfo(h)
                    g["mem_total"], g["mem_used"] = float(mi.total), float(mi.used)
                except Exception:
                    pass
                try:
                    g["temp_c"] = float(m.nvmlDeviceGetTemperature(h, m.NVML_TEMPERATURE_GPU))
                except Exception:
                    pass
                for key, fn in (("power_w", lambda: m.nvmlDeviceGetPowerUsage(h) / 1000.0),
                                ("fan_pct", lambda: float(m.nvmlDeviceGetFanSpeed(h))),
                                ("clock_core", lambda: float(m.nvmlDeviceGetClockInfo(h, m.NVML_CLOCK_GRAPHICS))),
                                ("clock_mem", lambda: float(m.nvmlDeviceGetClockInfo(h, m.NVML_CLOCK_MEM)))):
                    try:
                        g[key] = fn()
                    except Exception:
                        pass
                hot, mem_t = nvidia_hotspot(i)
                g["hotspot_c"], g["vram_temp_c"] = hot, mem_t
                gpus.append(g)
        except Exception:
            pass
    if not gpus:
        rows = nvidia_smi("index,name,utilization.gpu,utilization.memory,memory.total,"
                          "memory.used,temperature.gpu,power.draw,fan.speed,clocks.sm,clocks.mem")
        for r in rows or []:
            if len(r) < 11:
                continue
            gpus.append({"index": int(_f(r[0]) or 0), "source": "nvidia-smi", "vendor": "NVIDIA",
                         "name": r[1], "util": _f(r[2]), "mem_util": _f(r[3]),
                         "mem_total": (_f(r[4]) or 0) * 1024 ** 2,
                         "mem_used": (_f(r[5]) or 0) * 1024 ** 2,
                         "temp_c": _f(r[6]), "power_w": _f(r[7]), "fan_pct": _f(r[8]),
                         "clock_core": _f(r[9]), "clock_mem": _f(r[10]),
                         "hotspot_c": None, "vram_temp_c": None})
    if not gpus:
        # Non-NVIDIA / no driver tools: LibreHardwareMonitor still exposes AMD + Intel
        sensors = hwmon_sensors()
        by_parent = {}
        for name, value, parent, stype in sensors:
            if "/gpu" not in (parent or "").lower():
                continue
            g = by_parent.setdefault(parent, {"source": "LibreHardwareMonitor",
                                              "name": parent.split("/")[-1], "vendor": "GPU"})
            n = name.lower()
            if stype == "Temperature" and "core" in n:
                g["temp_c"] = value
            elif stype == "Temperature" and "hot" in n:
                g["hotspot_c"] = value
            elif stype == "Temperature" and ("memory" in n or "vram" in n):
                g["vram_temp_c"] = value
            elif stype == "Load" and "core" in n:
                g["util"] = value
            elif stype == "Load" and "memory" in n:
                g["mem_util"] = value
            elif stype == "Power" and "package" in n:
                g["power_w"] = value
            elif stype == "Fan":
                g["fan_rpm"] = value
            elif stype == "Clock" and "core" in n:
                g["clock_core"] = value
        gpus = list(by_parent.values())
    if not gpus and IS_WINDOWS:
        ok, out = powershell("Get-CimInstance Win32_VideoController | "
                             "Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress")
        if ok and out.strip().startswith(("[", "{")):
            try:
                data = json.loads(out)
                for d in (data if isinstance(data, list) else [data]):
                    gpus.append({"source": "Win32_VideoController", "name": d.get("Name"),
                                 "mem_total": float(d.get("AdapterRAM") or 0),
                                 "driver": d.get("DriverVersion"), "vendor": "GPU"})
            except Exception:
                pass
    return gpus


def _decode(v):
    return v.decode() if isinstance(v, bytes) else str(v)


def nvidia_hotspot(index=0):
    """(hotspot_c, vram_temp_c) for an NVIDIA GPU.

    Hotspot is not part of the plain NVML temperature API. On Ada/Ampere
    and newer NVML exposes thermal *limits* instead: the T.Limit fields
    report how many degrees the hotspot sensor is below its shutdown
    threshold, so hotspot = shutdown_threshold - shutdown_tlimit. Older
    cards fall back to nvidia-smi -q and finally LibreHardwareMonitor.
    Returns (None, None) when the driver exposes neither.
    """
    m = nvml()
    hot = vram = None
    if m:
        try:
            h = m.nvmlDeviceGetHandleByIndex(index)
            # T.Limit route (field IDs from nvml.h: 193 shutdown, 195 mem max)
            try:
                fields = m.nvmlDeviceGetFieldValues(h, [193, 195])
                shutdown_thr = m.nvmlDeviceGetTemperatureThreshold(
                    h, m.NVML_TEMPERATURE_THRESHOLD_SHUTDOWN)
                for fv in fields:
                    if fv.nvmlReturn != 0:
                        continue
                    val = fv.value.siVal if hasattr(fv.value, "siVal") else None
                    if val is None:
                        continue
                    if fv.fieldId == 193 and shutdown_thr:
                        hot = float(shutdown_thr) - float(val)
                    elif fv.fieldId == 195:
                        mem_thr = None
                        try:
                            mem_thr = m.nvmlDeviceGetTemperatureThreshold(
                                h, m.NVML_TEMPERATURE_THRESHOLD_MEM_MAX)
                        except Exception:
                            pass
                        if mem_thr:
                            vram = float(mem_thr) - float(val)
            except Exception:
                pass
            if vram is None:
                try:  # NVML_FI_DEV_MEMORY_TEMP
                    fv = m.nvmlDeviceGetFieldValues(h, [82])[0]
                    if fv.nvmlReturn == 0:
                        vram = float(fv.value.siVal)
                except Exception:
                    pass
        except Exception:
            pass
    if hot is None or vram is None:
        exe = which("nvidia-smi")
        if exe:
            ok, out = run([exe, "-q", "-i", str(index), "-d", "TEMPERATURE"], timeout=10)
            if ok:
                for line in out.splitlines():
                    low = line.lower()
                    val = _f(re.sub(r"[^0-9.]", "", line.split(":")[-1])) if ":" in line else None
                    if val is None:
                        continue
                    if hot is None and ("hotspot" in low or "gpu t.limit" in low and False):
                        hot = val
                    if vram is None and "memory current temp" in low:
                        vram = val
    if hot is None or vram is None:
        for name, value, parent, stype in hwmon_sensors("Temperature"):
            n = name.lower()
            if "/gpu" not in (parent or "").lower() or value is None:
                continue
            if hot is None and "hot" in n:
                hot = value
            if vram is None and ("memory" in n or "vram" in n):
                vram = value
    return (round(hot, 1) if hot is not None else None,
            round(vram, 1) if vram is not None else None)


def nvidia_processes():
    exe = which("nvidia-smi")
    if not exe:
        return []
    ok, out = run([exe, "--query-compute-apps=pid,process_name,used_memory",
                   "--format=csv,noheader,nounits"], timeout=10)
    procs = []
    if ok:
        for line in out.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 3 and parts[0].isdigit():
                procs.append({"pid": int(parts[0]), "name": parts[1],
                              "mem_mb": _f(parts[2])})
    return procs


def nvidia_query_block(section):
    """Raw `nvidia-smi -q -d <section>` text, or an explanatory string."""
    exe = which("nvidia-smi")
    if not exe:
        return "nvidia-smi not found - install the NVIDIA driver (no NVIDIA GPU detected)."
    ok, out = run([exe, "-q", "-d", section], timeout=15)
    return out if ok else f"nvidia-smi failed: {out}"


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
def disk_io_sample(previous=None):
    """Per-second read/write throughput since the previous sample."""
    if psutil is None:
        return {"error": "psutil is required"}
    now = time.time()
    try:
        io = psutil.disk_io_counters()
    except Exception:
        io = None
    if io is None:
        return {"t": now, "read": 0, "write": 0, "read_count": 0, "write_count": 0,
                "read_bps": 0.0, "write_bps": 0.0, "iops": 0.0,
                "error": "This system does not expose per-disk I/O counters."}
    cur = {"t": now, "read": io.read_bytes, "write": io.write_bytes,
           "read_count": io.read_count, "write_count": io.write_count}
    if previous:
        dt = max(0.001, now - previous["t"])
        cur["read_bps"] = max(0, (cur["read"] - previous["read"]) / dt)
        cur["write_bps"] = max(0, (cur["write"] - previous["write"]) / dt)
        cur["iops"] = max(0, ((cur["read_count"] - previous["read_count"]) +
                              (cur["write_count"] - previous["write_count"])) / dt)
    else:
        cur["read_bps"] = cur["write_bps"] = cur["iops"] = 0.0
    return cur


def net_io_sample(previous=None):
    """Per-second upload/download throughput since the previous sample,
    summed across every network interface (same shape as disk_io_sample
    above, for the Network Live Graph)."""
    if psutil is None:
        return {"error": "psutil is required"}
    now = time.time()
    try:
        io = psutil.net_io_counters()
    except Exception:
        io = None
    if io is None:
        return {"t": now, "sent": 0, "recv": 0, "up_bps": 0.0, "down_bps": 0.0,
                "error": "This system does not expose network I/O counters."}
    cur = {"t": now, "sent": io.bytes_sent, "recv": io.bytes_recv}
    if previous and "sent" in previous:
        dt = max(0.001, now - previous["t"])
        cur["up_bps"] = max(0, (cur["sent"] - previous["sent"]) / dt)
        cur["down_bps"] = max(0, (cur["recv"] - previous["recv"]) / dt)
    else:
        cur["up_bps"] = cur["down_bps"] = 0.0
    try:
        up_adapters = [n for n, s in (psutil.net_if_stats() or {}).items() if s.isup]
        cur["adapters_up"] = len(up_adapters)
    except Exception:
        cur["adapters_up"] = None
    return cur


def partitions():
    out = []
    if psutil is None:
        return out
    for p in psutil.disk_partitions(all=False):
        try:
            u = psutil.disk_usage(p.mountpoint)
        except Exception:
            continue
        out.append({"device": p.device, "mount": p.mountpoint, "fs": p.fstype,
                    "total": u.total, "used": u.used, "free": u.free, "percent": u.percent})
    return out


def physical_disks():
    """Physical drives with model / size / bus / media type."""
    disks = []
    if IS_WINDOWS:
        ok, out = powershell(
            "Get-PhysicalDisk | Select-Object DeviceId,FriendlyName,MediaType,BusType,"
            "Size,HealthStatus,SerialNumber | ConvertTo-Json -Compress")
        if ok and out.strip().startswith(("[", "{")):
            try:
                data = json.loads(out)
                for d in (data if isinstance(data, list) else [data]):
                    disks.append({
                        "id": str(d.get("DeviceId")),
                        "path": f"\\\\.\\PhysicalDrive{d.get('DeviceId')}",
                        "model": (d.get("FriendlyName") or "").strip(),
                        "media": d.get("MediaType") if isinstance(d.get("MediaType"), str) else
                                 {3: "HDD", 4: "SSD", 5: "SCM"}.get(d.get("MediaType"), "Unspecified"),
                        "bus": d.get("BusType") if isinstance(d.get("BusType"), str) else str(d.get("BusType")),
                        "size": float(d.get("Size") or 0),
                        "health": d.get("HealthStatus") if isinstance(d.get("HealthStatus"), str) else
                                  {0: "Healthy", 1: "Warning", 2: "Unhealthy"}.get(d.get("HealthStatus"), "?"),
                        "serial": (d.get("SerialNumber") or "").strip(),
                    })
            except Exception:
                pass
        if not disks:
            ok, out = powershell("Get-CimInstance Win32_DiskDrive | Select-Object Index,Model,"
                                 "Size,InterfaceType,SerialNumber,DeviceID | ConvertTo-Json -Compress")
            if ok and out.strip().startswith(("[", "{")):
                try:
                    data = json.loads(out)
                    for d in (data if isinstance(data, list) else [data]):
                        disks.append({"id": str(d.get("Index")), "path": d.get("DeviceID"),
                                      "model": d.get("Model"), "media": "?",
                                      "bus": d.get("InterfaceType"),
                                      "size": float(d.get("Size") or 0),
                                      "health": "?", "serial": (d.get("SerialNumber") or "").strip()})
                except Exception:
                    pass
    else:
        ok, out = run(["lsblk", "-dJ", "-o", "NAME,MODEL,SIZE,ROTA,TRAN,SERIAL"], timeout=10)
        if ok:
            try:
                for d in json.loads(out).get("blockdevices", []):
                    disks.append({"id": d.get("name"), "path": f"/dev/{d.get('name')}",
                                  "model": (d.get("model") or "").strip(),
                                  "media": "HDD" if d.get("rota") in (True, "1", 1) else "SSD",
                                  "bus": d.get("tran") or "?", "size": _size_to_bytes(d.get("size")),
                                  "health": "?", "serial": (d.get("serial") or "").strip()})
            except Exception:
                pass
    for d in disks:
        d["temp_c"] = drive_temperature(d)
    return disks


def _size_to_bytes(txt):
    if not txt:
        return 0.0
    m = re.match(r"([\d.]+)\s*([KMGTP]?)", str(txt).upper())
    if not m:
        return 0.0
    mult = {"": 1, "K": 1024, "M": 1024 ** 2, "G": 1024 ** 3, "T": 1024 ** 4, "P": 1024 ** 5}
    return float(m.group(1)) * mult.get(m.group(2), 1)


def smartctl_info(device):
    """Parsed smartctl JSON for a device, or None when smartctl is absent
    or the call needs elevation."""
    exe = which("smartctl")
    if not exe:
        return None
    ok, out = run([exe, "-j", "-a", device], timeout=25)
    if not out.strip().startswith("{"):
        return None
    try:
        return json.loads(out)
    except Exception:
        return None


def drive_temperature(disk):
    """Drive temperature in C from smartctl -> LHM -> Windows SMART WMI."""
    data = smartctl_info(disk.get("path") or "")
    if data:
        t = (data.get("temperature") or {}).get("current")
        if t:
            return float(t)
        for a in ((data.get("ata_smart_attributes") or {}).get("table") or []):
            if a.get("id") in (190, 194):
                raw = (a.get("raw") or {}).get("value")
                if raw:
                    return float(int(raw) & 0xFF)
    model = (disk.get("model") or "").lower()
    for name, value, parent, stype in hwmon_sensors("Temperature"):
        p = (parent or "").lower()
        if "/hdd" in p or "/nvme" in p or "/storage" in p:
            if value and (not model or model.split()[0] in (name + p)):
                return round(value, 1)
    if IS_WINDOWS:
        ok, out = powershell(
            "Get-CimInstance -Namespace root/WMI -ClassName MSStorageDriver_ATAPISmartData "
            "-ErrorAction SilentlyContinue | ForEach-Object { $_.VendorSpecific -join ',' }")
        if ok and out.strip():
            for line in out.strip().splitlines():
                nums = [int(x) for x in line.split(",") if x.strip().isdigit()]
                # 12-byte attribute records start at offset 2; id 194 = temperature
                for i in range(2, len(nums) - 11, 12):
                    if nums[i] in (194, 190):
                        return float(nums[i + 5])
        ok, out = powershell("(Get-CimInstance -Namespace root/Microsoft/Windows/Storage "
                             "-ClassName MSFT_PhysicalDisk -ErrorAction SilentlyContinue | "
                             f"Where-Object DeviceId -eq '{disk.get('id')}').Temperature")
        if ok and out.strip().isdigit() and int(out.strip()) > 0:
            return float(out.strip())
    return None


def smart_health(disk):
    """(status_text, [(attribute, value)]) - real SMART data only."""
    data = smartctl_info(disk.get("path") or "")
    if data:
        status = data.get("smart_status", {}).get("passed")
        text = "PASSED" if status else ("FAILED" if status is False else "Unknown")
        attrs = []
        for a in ((data.get("ata_smart_attributes") or {}).get("table") or []):
            attrs.append((f"{a.get('id')} {a.get('name')}",
                          (a.get("raw") or {}).get("string", a.get("value"))))
        nvme = data.get("nvme_smart_health_information_log")
        if nvme:
            for k in ("percentage_used", "available_spare", "power_on_hours",
                      "unsafe_shutdowns", "media_errors", "data_units_written"):
                if k in nvme:
                    attrs.append((k.replace("_", " ").title(), nvme[k]))
        return text, attrs
    if IS_WINDOWS:
        ok, out = powershell(
            f"(Get-PhysicalDisk -DeviceNumber {disk.get('id')} -ErrorAction SilentlyContinue | "
            "Get-StorageReliabilityCounter | Select-Object Wear,Temperature,PowerOnHours,"
            "ReadErrorsTotal,WriteErrorsTotal | ConvertTo-Json -Compress)")
        if ok and out.strip().startswith("{"):
            try:
                d = json.loads(out)
                attrs = [(k, v) for k, v in d.items() if v is not None]
                return disk.get("health", "?"), attrs
            except Exception:
                pass
        return disk.get("health", "?"), []
    return "smartctl not installed (install smartmontools for SMART data)", []


# ---------------------------------------------------------------------------
# Motherboard / BIOS / CPU clock detail (added for Quick Snapshot Tools etc.)
# ---------------------------------------------------------------------------
def motherboard_info():
    """Manufacturer/model/chipset-ish info. Windows has no direct 'chipset'
    WMI class - Win32_BaseBoard's Product/Manufacturer is the closest
    generic source without a vendor-specific driver."""
    if not IS_WINDOWS:
        info = {}
        for path, key in (("/sys/class/dmi/id/board_vendor", "manufacturer"),
                          ("/sys/class/dmi/id/board_name", "model")):
            try:
                with open(path) as f:
                    info[key] = f.read().strip()
            except Exception:
                pass
        return info
    ok, out = powershell(
        "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,Version,"
        "SerialNumber | ConvertTo-Json -Compress")
    if ok and out.strip().startswith("{"):
        try:
            d = json.loads(out)
            return {"manufacturer": d.get("Manufacturer"), "model": d.get("Product"),
                   "version": d.get("Version"), "serial": d.get("SerialNumber")}
        except Exception:
            pass
    return {}


def bios_info():
    if not IS_WINDOWS:
        info = {}
        for path, key in (("/sys/class/dmi/id/bios_vendor", "vendor"),
                          ("/sys/class/dmi/id/bios_version", "version"),
                          ("/sys/class/dmi/id/bios_date", "date")):
            try:
                with open(path) as f:
                    info[key] = f.read().strip()
            except Exception:
                pass
        return info
    ok, out = powershell(
        "Get-CimInstance Win32_BIOS | Select-Object Manufacturer,SMBIOSBIOSVersion,"
        "ReleaseDate | ConvertTo-Json -Compress")
    if ok and out.strip().startswith("{"):
        try:
            d = json.loads(out)
            return {"vendor": d.get("Manufacturer"), "version": d.get("SMBIOSBIOSVersion"),
                   "date": d.get("ReleaseDate")}
        except Exception:
            pass
    return {}


def cpu_clock_detail():
    """Per-core current clock plus a best-effort multiplier (current/bus
    clock). Many systems don't report ExtClock via WMI, in which case
    multiplier is left as None rather than guessed."""
    result = {"per_core_mhz": [], "multiplier": None, "bus_mhz": None}
    if psutil:
        try:
            freqs = psutil.cpu_freq(percpu=True)
            if freqs:
                result["per_core_mhz"] = [round(f.current) for f in freqs]
        except Exception:
            pass
    if IS_WINDOWS:
        ok, out = powershell(
            "Get-CimInstance Win32_Processor | Select-Object CurrentClockSpeed,ExtClock "
            "| ConvertTo-Json -Compress")
        if ok and out.strip().startswith("{"):
            try:
                d = json.loads(out)
                cur = d.get("CurrentClockSpeed")
                bus = d.get("ExtClock")
                if cur and bus:
                    result["bus_mhz"] = bus
                    result["multiplier"] = round(cur / bus, 2)
                if not result["per_core_mhz"] and cur:
                    result["per_core_mhz"] = [cur]
            except Exception:
                pass
    return result
