#!/usr/bin/env python3
"""
techdrive_modules/live_monitor.py - Live Monitor category
=========================================================
Real-time charts for CPU, RAM, GPU, disk throughput, drive temperatures
and drive space. Every value comes from hw_sensors.py (psutil / NVML /
nvidia-smi / SMART / LibreHardwareMonitor). Nothing here is simulated:
when a sensor is missing the panel says so and the line shows a gap.
"""

import os
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog, messagebox
from datetime import datetime

from gui.live_chart import LiveChart, LiveSampler
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw

CATALOGUE = []

C_BLUE, C_GREEN, C_ORANGE, C_PINK, C_CYAN, C_YELLOW = (
    "#00e5ff", "#2ecc71", "#e67e22", "#e84393", "#00cec9", "#f1c40f")


# ---------------------------------------------------------------------------
# shared panel scaffolding
# ---------------------------------------------------------------------------
def _shell(self, frame, title, subtitle):
    theme = self.theme
    tk.Label(frame, text=title, bg=theme["BG"], fg=theme["FG"],
             font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16, pady=(14, 0))
    tk.Label(frame, text=subtitle, bg=theme["BG"], fg=theme["MUTED"],
             font=FONT_UI, wraplength=760, justify="left").pack(anchor="w", padx=16, pady=(2, 8))
    body = tk.Frame(frame, bg=theme["BG"])
    body.pack(fill="both", expand=True, padx=16, pady=(0, 12))
    return body


def _stat_grid(parent, theme, columns=4):
    grid = tk.Frame(parent, bg=theme["BG"])
    grid.pack(fill="x", pady=(8, 4))
    for c in range(columns):
        grid.columnconfigure(c, weight=1, uniform="stat")
    return grid


class _Tiles:
    """Small value tiles that are updated in place (no flicker)."""

    def __init__(self, parent, theme, names, columns=4):
        self.theme = theme
        self.vars = {}
        grid = _stat_grid(parent, theme, columns)
        for i, name in enumerate(names):
            cell = tk.Frame(grid, bg=theme["CARD_BG"], highlightthickness=1,
                            highlightbackground=theme["CARD_BORDER"])
            cell.grid(row=i // columns, column=i % columns, sticky="nsew", padx=4, pady=4)
            tk.Label(cell, text=name, bg=theme["CARD_BG"], fg=theme["MUTED"],
                     font=FONT_UI).pack(anchor="w", padx=10, pady=(8, 0))
            v = tk.StringVar(value="--")
            lbl = tk.Label(cell, textvariable=v, bg=theme["CARD_BG"], fg=theme["FG"],
                           font=("Segoe UI", 14, "bold"))
            lbl.pack(anchor="w", padx=10, pady=(0, 8))
            self.vars[name] = (v, lbl)

    def set(self, name, value, status=None):
        if name not in self.vars:
            return
        v, lbl = self.vars[name]
        v.set(value)
        lbl.config(fg=status_color(status) if status else self.theme["FG"])


def _controls(self, parent, sampler, extra=None):
    theme = self.theme
    row = tk.Frame(parent, bg=theme["BG"])
    row.pack(fill="x", pady=(6, 0))
    pause_btn = tk.Button(row, text="⏸ Pause", bg=theme["BG_LIGHT"], fg=theme["FG"],
                          relief="flat", padx=12, pady=4)

    def toggle():
        paused = sampler.toggle_pause()
        pause_btn.config(text="▶ Resume" if paused else "⏸ Pause")

    pause_btn.config(command=toggle)
    pause_btn.pack(side="left", padx=(0, 8))
    for text, cmd in (extra or []):
        tk.Button(row, text=text, command=cmd, bg=theme["BG_LIGHT"], fg=theme["FG"],
                  relief="flat", padx=12, pady=4).pack(side="left", padx=(0, 8))
    return row


def _missing(self, body, message):
    tk.Label(body, text=message, bg=self.theme["BG"], fg=status_color("warn"),
             font=FONT_UI, wraplength=760, justify="left").pack(anchor="w", pady=6)


# ---------------------------------------------------------------------------
# CPU
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# RAM
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# GPU
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Disk activity
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Network traffic
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Drive temperatures
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Space map
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Combined dashboard
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def _n(v):
    return "" if v is None else (f"{v:.1f}" if isinstance(v, float) else str(v))
