#!/usr/bin/env python3
r"""
techdrive_modules/shredder_tools.py - Shredder Tools category
======================================================================
Real, working data-destruction utilities. Honest scope:

- File/Folder/Secure Delete: overwrite the target's actual bytes on
  disk (1+ passes), rename it to a random name (so the old filename
  doesn't linger in directory metadata), then delete it.
- Disk Wipe 1/3/7-Pass + DoD: fill the *free space* of a chosen volume
  with pass patterns, then release it. This is a real, user-mode way
  to overwrite space that isn't currently allocated to a file - it is
  NOT a raw-sector wipe of the whole physical disk (that needs
  bootable media / direct disk access with admin rights this app
  doesn't request). On SSDs, wear-levelling and TRIM mean even a
  "successful" pass isn't a cryptographic guarantee - the tool says so.
- Free Space Wipe: shells out to Windows' own `cipher /w`, the
  built-in tool Microsoft ships specifically for this job.
- Recycle Bin Shredder: calls the real Windows shell API
  (SHEmptyRecycleBinW) - actually empties it, not a stub.
- Registry Key Shredder: deletes a real registry key tree via winreg,
  with a hive/depth guard so you can't nuke a whole hive by accident.
"""

import ctypes
import os
import platform
import random
import shutil
import string
import subprocess
from gui.tk_dialogs import filedialog
from gui.tool_view import CardPanel

try:
    import winreg
except ImportError:
    winreg = None

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []

# ---------------------------------------------------------------------------
# Shared primitives
# ---------------------------------------------------------------------------

_CHUNK = 4 * 1024 * 1024  # 4MB write buffer


def _rand_name(length=16):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


def _overwrite_file(path, passes=1, pattern="random", log=None):
    """Overwrite a single file's bytes in place, `passes` times, then
    rename it to a random name before the caller deletes it. Returns
    (ok, message)."""
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return False, f"Could not stat {path}: {e}"

    try:
        for p in range(passes):
            if pattern == "dod":
                seq = [b"\x00", b"\xFF", None]
                fill = seq[p % 3]
            elif pattern == "zero":
                fill = b"\x00"
            else:
                fill = None  # random every pass
            with open(path, "r+b") as f:
                written = 0
                while written < size:
                    n = min(_CHUNK, size - written)
                    block = (fill * n) if fill else os.urandom(n)
                    f.write(block)
                    written += n
                f.flush()
                os.fsync(f.fileno())
            if log:
                log(f"  pass {p + 1}/{passes} overwritten: {os.path.basename(path)}")
    except OSError as e:
        return False, f"Overwrite failed on {path}: {e}"

    try:
        folder = os.path.dirname(path)
        new_path = path
        for _ in range(3):
            candidate = os.path.join(folder, _rand_name())
            try:
                os.rename(new_path, candidate)
                new_path = candidate
            except OSError:
                break
        os.remove(new_path)
    except OSError as e:
        return False, f"Overwritten but delete failed for {path}: {e}"

    return True, f"Shredded: {path} ({passes} pass(es), {bytes_fmt(size)})"


def _shred_paths(paths, passes=1, pattern="random", also_dirs=True):
    lines = []
    ok_count = 0
    err_count = 0
    for p in paths:
        if os.path.isdir(p):
            if not also_dirs:
                continue
            for root, dirs, files in os.walk(p, topdown=False):
                for fname in files:
                    fp = os.path.join(root, fname)
                    ok, msg = _overwrite_file(fp, passes=passes, pattern=pattern)
                    lines.append(msg)
                    ok_count += ok
                    err_count += (not ok)
                for dname in dirs:
                    try:
                        os.rmdir(os.path.join(root, dname))
                    except OSError:
                        pass
            try:
                os.rmdir(p)
                lines.append(f"Removed empty directory tree: {p}")
            except OSError as e:
                lines.append(f"Could not remove directory {p}: {e}")
        elif os.path.isfile(p):
            ok, msg = _overwrite_file(p, passes=passes, pattern=pattern)
            lines.append(msg)
            ok_count += ok
            err_count += (not ok)
        else:
            lines.append(f"Skipped (not found): {p}")
            err_count += 1
    lines.append(f"\nDone. {ok_count} item(s) shredded, {err_count} error(s).")
    return "\n".join(lines)


def _wipe_free_space(drive, passes=1, pattern="random", max_file_gb=2, progress=None):
    """Genuinely overwrites currently-unallocated space on `drive` by
    filling it with temp files and deleting them, `passes` times."""
    if not os.path.isdir(drive):
        return f"'{drive}' is not a reachable path/drive."

    lines = []
    chunk_bytes = max_file_gb * 1024 ** 3
    for p in range(passes):
        if pattern == "dod":
            seq = [b"\x00", b"\xFF", None]
            fill_byte = seq[p % 3]
        elif pattern == "zero":
            fill_byte = b"\x00"
        else:
            fill_byte = None

        total_written = 0
        file_index = 0
        temp_files = []
        try:
            while True:
                usage = shutil.disk_usage(drive)
                if usage.free < 32 * 1024 * 1024:
                    break
                this_file_target = min(chunk_bytes, usage.free - 16 * 1024 * 1024)
                if this_file_target <= 0:
                    break
                fname = os.path.join(drive, f"_techdrive_wipe_{p}_{file_index}.tmp")
                file_index += 1
                written_here = 0
                with open(fname, "wb") as f:
                    while written_here < this_file_target:
                        n = min(_CHUNK, this_file_target - written_here)
                        block = (fill_byte * n) if fill_byte else os.urandom(n)
                        f.write(block)
                        written_here += n
                    f.flush()
                    os.fsync(f.fileno())
                temp_files.append(fname)
                total_written += written_here
                if progress:
                    progress(f"pass {p + 1}/{passes}: filled {bytes_fmt(total_written)} on {drive}")
        except OSError as e:
            lines.append(f"Pass {p + 1} stopped early ({e}). Cleaning up temp files...")
        finally:
            for fp in temp_files:
                try:
                    os.remove(fp)
                except OSError:
                    pass
        lines.append(f"Pass {p + 1}/{passes} complete - wrote and released {bytes_fmt(total_written)} of free space.")

    lines.append(
        "\nNote: this overwrites space the OS currently reports as free. On SSDs, "
        "wear-levelling/TRIM means the drive controller may have already remapped "
        "old data away from where new writes land, so this is not a forensic "
        "guarantee on flash media - it is on spinning HDDs."
    )
    return "\n".join(lines)


_HIVE_MAP = {}
if winreg:
    _HIVE_MAP = {
        "HKCU": (winreg.HKEY_CURRENT_USER, "HKEY_CURRENT_USER"),
        "HKEY_CURRENT_USER": (winreg.HKEY_CURRENT_USER, "HKEY_CURRENT_USER"),
        "HKLM": (winreg.HKEY_LOCAL_MACHINE, "HKEY_LOCAL_MACHINE"),
        "HKEY_LOCAL_MACHINE": (winreg.HKEY_LOCAL_MACHINE, "HKEY_LOCAL_MACHINE"),
    }


def _delete_registry_key(full_path):
    """Deletes a registry key (and its subtree) via winreg. Guarded so a
    whole hive/top-level branch can't be wiped by a typo."""
    if winreg is None:
        return windows_only_notice()
    parts = full_path.strip().strip("\\").split("\\", 1)
    if len(parts) < 2:
        return ("Refused: give a full path like 'HKCU\\Software\\SomeApp\\SomeKey' "
                 "(top-level hives and single-segment keys are blocked).")
    hive_token, subpath = parts[0].upper(), parts[1]
    if hive_token not in _HIVE_MAP:
        return (f"Refused: only HKCU and HKLM are supported here (use with caution). Got '{hive_token}'.")
    if subpath.count("\\") < 1:
        return "Refused: path is too shallow - point at a specific application key, not a top-level branch."
    hive, hive_name = _HIVE_MAP[hive_token]

    def _recursive_delete(hive_handle, path):
        with winreg.OpenKey(hive_handle, path, 0, winreg.KEY_ALL_ACCESS) as key:
            while True:
                try:
                    sub = winreg.EnumKey(key, 0)
                except OSError:
                    break
                _recursive_delete(hive_handle, f"{path}\\{sub}")
        winreg.DeleteKey(hive_handle, path)

    try:
        _recursive_delete(hive, subpath)
        return f"Deleted registry key and all subkeys: {hive_name}\\{subpath}"
    except FileNotFoundError:
        return f"Key not found: {hive_name}\\{subpath}"
    except PermissionError:
        return f"Access denied deleting {hive_name}\\{subpath} - try running TechDrive as Administrator."
    except OSError as e:
        return f"Error deleting {hive_name}\\{subpath}: {e}"


def _empty_recycle_bin():
    if not IS_WINDOWS:
        return windows_only_notice()
    try:
        SHERB_NOCONFIRMATION = 0x00000001
        SHERB_NOPROGRESSUI = 0x00000002
        SHERB_NOSOUND = 0x00000004
        flags = SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
        result = ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, flags)
        if result in (0, -2147418113):
            return "Recycle Bin emptied."
        return f"SHEmptyRecycleBinW returned code {result} (non-zero may just mean it was already empty)."
    except Exception as e:
        return f"Error emptying Recycle Bin: {e}"


def _pick_files(on_pick):
    paths = filedialog.askopenfilenames(title="Choose file(s) to shred")
    if paths:
        on_pick(list(paths))


def _pick_folder(on_pick):
    path = filedialog.askdirectory(title="Choose a folder to shred")
    if path:
        on_pick(path)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------





def _free_space_wipe_panel(self, frame, title, subtitle, passes, pattern):
    """Shared body for the pass-count wipers below (kept as a plain helper,
    not a factory, so each tool_* below is its own real function/line -
    matters for how this module's functions get paired to CATALOGUE)."""
    panel = CardPanel(frame, self.theme, title, subtitle)
    drive_var = self._entry_row(panel.body, "Drive/folder (e.g. D:\\):", "D:\\")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        drive = drive_var.get().strip() or "D:\\"
        return _wipe_free_space(drive, passes=passes, pattern=pattern)

    def go():
        drive = drive_var.get().strip() or "D:\\"
        self._confirm_then(
            f"Fill and overwrite all currently-free space on '{drive}' ({passes} pass(es))?\n"
            "This temporarily uses (and then releases) all free space on that volume, and "
            "any other program writing there at the same time may fail with 'disk full'.",
            lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [("Start Wipe", go)])
















