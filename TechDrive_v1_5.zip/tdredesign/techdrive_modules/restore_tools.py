#!/usr/bin/env python3
"""
Module: restore_tools
Generated for TechDrive 500
Category: Restore Tools
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def _win_only():
    return "Windows-only feature (this tool relies on System Restore / Windows Backup)."


def _admin_notice():
    return "\n\n(Note: most restore/backup operations require running TechDrive as Administrator.)"


def _ps(cmd, timeout=25):
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True, text=True, timeout=timeout
        )
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        if r.returncode != 0 and not out:
            return False, err or "Command failed."
        return True, out or "(no output)"
    except FileNotFoundError:
        return False, "PowerShell not found on this system."
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except Exception as e:
        return False, f"Error: {e}"


CATALOGUE = [('Restore Tools',
  '⟳',
  ['System Restore Point', 'Info', 'Creator', 'Restore', 'Image Backup', 'Image Restore'])]


def tool_restore_tools_system_restore_point(self, frame):
    """System Restore Point — Restore Tools"""
    panel = CardPanel(frame, self.theme, "System Restore Point", "Whether System Protection is enabled, and on which drives",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return _win_only()
        ok, out = _ps(
            "Get-CimInstance -Namespace root\\default -ClassName SystemRestoreConfig -ErrorAction SilentlyContinue | "
            "Out-String; "
            "vssadmin list volumes 2>&1"
        )
        return (out if ok and out.strip() not in ("", "(no output)")
                else "Could not read System Protection status." ) + _admin_notice()

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_restore_tools_info(self, frame):
    """Info — Restore Tools"""
    panel = CardPanel(frame, self.theme, "Info", "Existing restore points on this system",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return _win_only()
        ok, out = _ps(
            "Get-ComputerRestorePoint | "
            "Select-Object SequenceNumber,Description,RestorePointType,CreationTime | "
            "Format-Table -AutoSize | Out-String -Width 200"
        )
        if ok and out.strip() not in ("", "(no output)"):
            return out
        return "No restore points found (or System Protection is disabled)." + _admin_notice()

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_restore_tools_creator(self, frame):
    """Creator — Restore Tools"""
    panel = CardPanel(frame, self.theme, "Creator", "Create a new System Restore point")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def create():
        desc = simpledialog.askstring(
            "Create Restore Point", "Description for this restore point:",
            initialvalue="TechDrive manual checkpoint"
        )
        if not desc:
            return

        def run():
            if not IS_WINDOWS:
                return _win_only()
            safe_desc = desc.replace('"', "'")
            ok, out = _ps(
                f'Checkpoint-Computer -Description "{safe_desc}" -RestorePointType "MODIFY_SETTINGS"'
            )
            if ok:
                return f"Restore point '{desc}' created (if System Protection is enabled)." + _admin_notice()
            return f"Could not create restore point: {out}" + _admin_notice()

        self._run_bg(run, redraw)

    redraw("Click 'Create Restore Point' to make a new System Restore checkpoint.")
    self._button_row(panel.body, [("Create Restore Point", create)])


def tool_restore_tools_restore(self, frame):
    """Restore — Restore Tools"""
    panel = CardPanel(frame, self.theme, "Restore", "Roll the system back to an existing restore point (reboots the PC)",
                       on_refresh=lambda: self._run_bg(list_points, redraw))

    def redraw(r):
        panel.clear()
        panel.report(r)

    def list_points():
        if not IS_WINDOWS:
            return _win_only()
        ok, out = _ps(
            "Get-ComputerRestorePoint | Select-Object SequenceNumber,Description,CreationTime | "
            "Format-Table -AutoSize | Out-String -Width 200"
        )
        return out if ok else f"Could not list restore points: {out}"

    def do_restore():
        if not IS_WINDOWS:
            redraw(_win_only())
            return
        seq = simpledialog.askinteger("Restore", "Sequence number of the restore point to use:")
        if seq is None:
            return

        def action():
            def run():
                if seq <= 0:
                    return "Invalid restore-point sequence number. Nothing was changed."
                listed, list_output = _ps(
                    "Get-ComputerRestorePoint | Select-Object -ExpandProperty SequenceNumber | Out-String",
                    timeout=30)
                if not listed:
                    return f"Could not validate restore point #{seq}: {list_output}. Nothing was changed."
                valid_ids = {int(line.strip()) for line in list_output.splitlines() if line.strip().isdigit()}
                if seq not in valid_ids:
                    return f"Restore point #{seq} is not in the current restore-point list. Nothing was changed. Refresh the list and choose an existing sequence number."
                ok, out = _ps(f"Restore-Computer -RestorePoint {seq} -Confirm:$false", timeout=180)
                if ok:
                    return f"Restore to point #{seq} initiated. Windows will restart to complete it."
                return f"Restore failed: {out}" + _admin_notice()

            self._run_bg(run, redraw)

        self._confirm_then(
            f"This will restore Windows to restore point #{seq} and REBOOT the computer.\n"
            "Unsaved work will be lost. Continue?",
            action
        )

    self._run_bg(list_points, redraw)
    self._button_row(panel.body, [("Restore to Point...", do_restore)])




def tool_restore_tools_image_backup(self, frame):
    """Image Backup — Restore Tools"""
    panel = CardPanel(frame, self.theme, "Image Backup", "Create a full system image with the Windows Backup engine (wbadmin)")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def start_backup():
        target = filedialog.askdirectory(title="Choose a folder on a separate backup drive or supported network share")
        if not target:
            return

        def action():
            def run():
                if not IS_WINDOWS:
                    return _win_only()
                try:
                    import ctypes
                    if not bool(ctypes.windll.shell32.IsUserAnAdmin()):
                        return "System image backup requires Administrator privileges. Nothing was started."
                    if not os.path.isdir(target):
                        return "The selected backup destination is not a reachable folder. Nothing was started."
                    system_drive = os.path.splitdrive(os.path.abspath(os.environ.get("SystemDrive", "C:\\")))[0].casefold()
                    target_drive = os.path.splitdrive(os.path.abspath(target))[0].casefold()
                    if not target_drive or target_drive == system_drive:
                        return ("Safety stop: choose a destination on a different drive from Windows. "
                                "A backup on the same drive will not protect you if that drive fails.")
                    # wbadmin expects a target volume (or supported network share), not an arbitrary local subfolder.
                    backup_target = target_drive if re.fullmatch(r"[A-Za-z]:", target_drive) else target
                    r = subprocess.run(
                        ["wbadmin", "start", "backup", f"-backupTarget:{backup_target}",
                         "-include:C:", "-allCritical", "-quiet"],
                        capture_output=True, text=True, timeout=1800,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
                    )
                    out = (r.stdout or r.stderr or "").strip()
                    if r.returncode != 0:
                        return f"System image backup failed (exit {r.returncode}).\n{out or 'Windows returned no diagnostic output.'}"
                    return (out or "Windows Backup returned success.") + "\n\nVerify that a new backup version is listed before relying on it."
                except subprocess.TimeoutExpired:
                    return "The backup command timed out waiting for completion. Check wbadmin backup versions before retrying; do not assume the backup failed or completed."
                except Exception as e:
                    return f"Error: {e}"

            redraw(f"Backing up C: to {target} — this can take a long time...")
            self._run_bg(run, redraw)

        self._confirm_then(
            f"Create a full system image backup of C: using destination '{target}'? For a local drive, Windows Backup targets the selected volume (not just this folder), so existing contents on the destination volume matter. The destination must be a different drive from Windows, and Administrator rights are required. Keep another backup copy if the data matters. Continue?",
            action
        )

    redraw("Click 'Start Image Backup' and choose a destination on a separate drive or a supported network share. For a local drive, wbadmin targets the volume, not an arbitrary subfolder.")
    self._button_row(panel.body, [("Start Image Backup", start_backup)])


def tool_restore_tools_image_restore(self, frame):
    """Image Restore — Restore Tools"""
    panel = CardPanel(frame, self.theme, "Image Restore", "List available system-image backup versions (wbadmin)",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return _win_only()
        try:
            r = subprocess.run(["wbadmin", "get", "versions"], capture_output=True, text=True, timeout=30)
            out = (r.stdout or r.stderr or "").strip()
            return (out or "No image backups found.") + (
                "\n\nTo restore, boot from Windows Recovery Environment and use "
                "'System Image Recovery', or run 'wbadmin start sysrecovery -version:<id>' "
                "from an elevated recovery prompt. Full image restore is intentionally not "
                "triggered automatically from here, since it overwrites the running system."
            )
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)






