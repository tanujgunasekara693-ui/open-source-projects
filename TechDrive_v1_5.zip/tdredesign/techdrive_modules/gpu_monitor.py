#!/usr/bin/env python3
"""
Module: gpu_monitor
Category: GPU Monitor

Real GPU telemetry - reuses the same hw_sensors data layer as the NVIDIA
GPU category (NVML -> nvidia-smi -> LibreHardwareMonitor -> WMI fallback
chain), so it works on NVIDIA, AMD and Intel where the underlying tooling
exposes the value, and says "not exposed" rather than inventing a number
when it doesn't.
"""

import time
import platform
import subprocess

from techdrive_modules import hw_sensors as hw
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    n = float(n or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('GPU Monitor', '▦', ['GPU Info', 'Usage Graph', 'Temperature', 'Memory Usage', 'Driver Version'])]


def _gpus():
    try:
        return hw.gpu_list()
    except Exception:
        return []


def _no_gpu_msg():
    return ("No GPU could be read. This needs at least one of: an NVIDIA driver "
            "(nvidia-smi/NVML), LibreHardwareMonitor running, or - on Windows - WMI's "
            "Win32_VideoController class.")


def _fmt_gpu_block(g, index):
    name = g.get("name") or "Unknown GPU"
    lines = [f"GPU {index}: {name}  (source: {g.get('source', '?')}, vendor: {g.get('vendor', '?')})"]
    if g.get("util") is not None:
        lines.append(f"  Core utilization : {g['util']:.0f}%")
    if g.get("mem_util") is not None:
        lines.append(f"  Memory controller utilization : {g['mem_util']:.0f}%")
    if g.get("mem_total"):
        used = g.get("mem_used") or 0
        lines.append(f"  VRAM : {bytes_fmt(used)} / {bytes_fmt(g['mem_total'])} "
                      f"({(used / g['mem_total'] * 100) if g['mem_total'] else 0:.0f}%)")
    if g.get("temp_c") is not None:
        lines.append(f"  Core temperature : {g['temp_c']:.0f}°C")
    if g.get("hotspot_c") is not None:
        lines.append(f"  Hotspot temperature : {g['hotspot_c']:.0f}°C")
    if g.get("vram_temp_c") is not None:
        lines.append(f"  VRAM temperature : {g['vram_temp_c']:.0f}°C")
    if g.get("power_w") is not None:
        lines.append(f"  Power draw : {g['power_w']:.1f} W")
    if g.get("fan_pct") is not None:
        lines.append(f"  Fan speed : {g['fan_pct']:.0f}%")
    if g.get("fan_rpm") is not None:
        lines.append(f"  Fan speed : {g['fan_rpm']:.0f} RPM")
    if g.get("clock_core") is not None:
        lines.append(f"  Core clock : {g['clock_core']:.0f} MHz")
    if g.get("clock_mem") is not None:
        lines.append(f"  Memory clock : {g['clock_mem']:.0f} MHz")
    if g.get("driver"):
        lines.append(f"  Driver version : {g['driver']}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 1. GPU Info
# ---------------------------------------------------------------------------

def tool_gpu_monitor_gpu_info(self, frame):
    """GPU Info — GPU Monitor"""
    panel = CardPanel(frame, self.theme, "GPU Info", "Every GPU detected on this machine, with live values.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        gpus = _gpus()
        if not gpus:
            return _no_gpu_msg()
        return "\n\n".join(_fmt_gpu_block(g, i) for i, g in enumerate(gpus))

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 2. Usage Graph (text sparkline over a real short sampling window)
# ---------------------------------------------------------------------------

def tool_gpu_monitor_usage_graph(self, frame):
    """Usage Graph — GPU Monitor"""
    panel = CardPanel(frame, self.theme, "Usage Graph", "Samples real GPU core utilization once a second for 10 seconds.",
                       on_refresh=lambda: self._run_bg(run, redraw))
    BLOCKS = " ▁▂▃▄▅▆▇█"

    def spark(vals):
        return "".join(BLOCKS[min(8, max(0, int(v / 100 * 8)))] for v in vals)

    def run():
        gpus = _gpus()
        if not gpus:
            return _no_gpu_msg()
        history = {i: [] for i in range(len(gpus))}
        names = {i: g.get("name", f"GPU {i}") for i, g in enumerate(gpus)}
        for _ in range(10):
            for i, g in enumerate(_gpus()):
                if i in history and g.get("util") is not None:
                    history[i].append(g["util"])
            time.sleep(1)
        lines = [f"10-second GPU utilization sample ({time.strftime('%H:%M:%S')}):", ""]
        any_data = False
        for i, vals in history.items():
            if vals:
                any_data = True
                lines.append(f"{names[i]}: {spark(vals)}  "
                              f"(min {min(vals):.0f}%  avg {sum(vals) / len(vals):.0f}%  "
                              f"max {max(vals):.0f}%)")
        if not any_data:
            return "GPU utilization isn't exposed by the available driver tools on this system."
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 3. Temperature
# ---------------------------------------------------------------------------

def tool_gpu_monitor_temperature(self, frame):
    """Temperature — GPU Monitor"""
    panel = CardPanel(frame, self.theme, "Temperature", "Core, hotspot and VRAM temperature per GPU.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        gpus = _gpus()
        if not gpus:
            return _no_gpu_msg()
        lines = []
        for i, g in enumerate(gpus):
            name = g.get("name", f"GPU {i}")
            core = f"{g['temp_c']:.0f}°C" if g.get("temp_c") is not None else "not exposed"
            hot = f"{g['hotspot_c']:.0f}°C" if g.get("hotspot_c") is not None else "not exposed"
            vram = f"{g['vram_temp_c']:.0f}°C" if g.get("vram_temp_c") is not None else "not exposed"
            status = ""
            if g.get("temp_c") is not None:
                status = hw.temp_status(g["temp_c"], warn=80, bad=90)
            lines.append(f"{name}\n  Core: {core}  |  Hotspot: {hot}  |  VRAM: {vram}"
                         + (f"  [{status}]" if status else ""))
        return "\n\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 4. Fan Speed
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 5. Memory Usage
# ---------------------------------------------------------------------------

def tool_gpu_monitor_memory_usage(self, frame):
    """Memory Usage — GPU Monitor"""
    panel = CardPanel(frame, self.theme, "Memory Usage", "VRAM used vs total, and top VRAM-consuming processes.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        gpus = _gpus()
        if not gpus:
            return _no_gpu_msg()
        lines = []
        for i, g in enumerate(gpus):
            name = g.get("name", f"GPU {i}")
            if g.get("mem_total"):
                used = g.get("mem_used") or 0
                pct = used / g["mem_total"] * 100 if g["mem_total"] else 0
                bar_len = 30
                filled = int(bar_len * pct / 100)
                bar = "█" * filled + "░" * (bar_len - filled)
                lines.append(f"{name}\n  [{bar}] {pct:.0f}%\n  {bytes_fmt(used)} / {bytes_fmt(g['mem_total'])}")
            else:
                lines.append(f"{name}: VRAM totals not exposed.")
        try:
            procs = hw.nvidia_processes()
        except Exception:
            procs = None
        if procs:
            lines.append("\nPer-process VRAM (NVIDIA):")
            for p in procs[:15]:
                mem = f"{p['mem_mb']:.0f} MB" if p.get("mem_mb") is not None else "?"
                lines.append(f"  PID {p['pid']}  {p['name']}  — {mem}")
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 6. Clock Speed
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 7. Voltage
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 8. Driver Version
# ---------------------------------------------------------------------------

def tool_gpu_monitor_driver_version(self, frame):
    """Driver Version — GPU Monitor"""
    panel = CardPanel(frame, self.theme, "Driver Version", "Installed GPU driver version(s).",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        lines = []
        rows = hw.nvidia_smi("name,driver_version") if hasattr(hw, "nvidia_smi") else None
        if rows:
            for r in rows:
                if len(r) >= 2:
                    lines.append(f"{r[0]}: driver {r[1]} (NVIDIA)")
        if not lines and IS_WINDOWS:
            ok, out = hw.powershell(
                "Get-CimInstance Win32_VideoController | "
                "Select-Object Name,DriverVersion,DriverDate | ConvertTo-Json -Compress")
            if ok and out.strip().startswith(("[", "{")):
                import json
                try:
                    data = json.loads(out)
                    for d in (data if isinstance(data, list) else [data]):
                        lines.append(f"{d.get('Name')}: driver {d.get('DriverVersion')} "
                                     f"({d.get('DriverDate', 'date unknown')})")
                except Exception:
                    pass
        if not lines:
            gpus = _gpus()
            for g in gpus:
                if g.get("driver"):
                    lines.append(f"{g.get('name')}: driver {g['driver']}")
        if not lines:
            return ("Driver version couldn't be read - install nvidia-smi (NVIDIA) or run this "
                     "on Windows where WMI can query Win32_VideoController.")
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 9. Performance (P-state / throttle reasons where available)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 10. Multi-Monitor
# ---------------------------------------------------------------------------

