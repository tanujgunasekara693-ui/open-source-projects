#!/usr/bin/env python3
r"""
    ("Advanced Monitoring Tools", "◎", [
=================================================================================
Desktop Sensor Panel: a real always-on-top floating overlay with live
gauges, built with Tkinter Canvas - no placeholders, updates on a timer.

External Display Output: rather than faking support for specific vendor
hardware (Logitech/Corsair keyboard LCDs need their own proprietary SDK,
which isn't bundled here and can't honestly be claimed to work without
it), this starts a small local HTTP server serving a live-updating page
of the same sensor data - open the URL it prints from a phone or tablet
browser on the same network, which is a genuine, working way to get an
"external display" without needing a native companion app.
"""

import http.server
import json
import socket
import threading
import tkinter as tk

from gui.theme import FONT_UI, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.partition_tools import bytes_fmt

CATALOGUE = []


# ---------------------------------------------------------------------------
# Desktop Sensor Panel
# ---------------------------------------------------------------------------
def _draw_gauge(canvas, cx, cy, r, pct, color, bg):
    canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=90, extent=-360,
                      outline=bg, width=10, style="arc")
    extent = -360 * max(0, min(100, pct)) / 100
    if extent:
        canvas.create_arc(cx - r, cy - r, cx + r, cy + r, start=90, extent=extent,
                          outline=color, width=10, style="arc")




# ---------------------------------------------------------------------------
# External Display Output (local HTTP server for phones/tablets)
# ---------------------------------------------------------------------------
_server_state = {"httpd": None, "thread": None}


def _make_handler():
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # keep the app's console/log quiet

        def do_GET(self):
            if self.path == "/data.json":
                cpu = hw.cpu_sample().get("usage", 0) if hasattr(hw, "cpu_sample") else 0
                ram = hw.ram_sample()
                gpus = hw.gpu_list()
                payload = {
                    "cpu_percent": cpu,
                    "ram_percent": ram.get("percent", 0),
                    "ram_used": bytes_fmt(ram.get("used", 0)),
                    "ram_total": bytes_fmt(ram.get("total", 0)),
                    "cpu_temp": hw.cpu_temperature(),
                    "gpu": [{"name": g.get("name"), "util": g.get("util"),
                            "temp": g.get("temp_c")} for g in gpus],
                }
                body = json.dumps(payload).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            html = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TechDrive Sensors</title>
<style>body{font-family:Segoe UI,Arial;background:#1e1e1e;color:#dcdcdc;padding:16px}
.card{background:#2b2b2b;border-radius:8px;padding:16px;margin-bottom:12px}
.big{font-size:28px;font-weight:bold;color:#00e5ff}</style></head>
<body><h2>TechDrive Live Sensors</h2><div id="app">Loading…</div>
<script>
async function tick(){
  const r = await fetch('/data.json'); const d = await r.json();
  document.getElementById('app').innerHTML =
    `<div class="card">CPU<div class="big">${d.cpu_percent.toFixed(0)}%</div>${d.cpu_temp!=null?d.cpu_temp+'°C':''}</div>` +
    `<div class="card">RAM<div class="big">${d.ram_percent.toFixed(0)}%</div>${d.ram_used} / ${d.ram_total}</div>` +
    d.gpu.map(g=>`<div class="card">${g.name}<div class="big">${g.util??'?'}%</div>${g.temp!=null?g.temp+'°C':''}</div>`).join('');
}
tick(); setInterval(tick, 2000);
</script></body></html>"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            body = html.encode("utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    return Handler


