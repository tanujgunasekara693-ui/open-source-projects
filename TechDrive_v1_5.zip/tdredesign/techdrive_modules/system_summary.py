#!/usr/bin/env python3
"""
techdrive_modules/system_summary.py  –  System Summary category
================================================================
A single rich tool with four tabs:
  CPU      – live active-clock / effective-clock / temp graph + full static
             CPU spec (brand, codename, stepping, MCU, TDP, socket, cache,
             instruction-set features, P-state operating points).
  GPU      – card name, graphics chipset, VRAM, driver version, core and
             memory clocks, bus interface.
  Memory   – total size, type, channel mode, current & reference clock,
             clock ratio, timings (CL tRCD tRP tRAS tRC tRFC …),
             command rate, per-module table (size, max speed, type, ECC,
             manufacturer, part number).
  System   – OS, kernel, motherboard make/model, chipset, BIOS version.

Every value comes from a real hardware or OS source.  When a source is
unavailable (e.g. py-cpuinfo not installed, LHM not running, elevation
missing) the panel says exactly why and what to do – it never invents
or approximates a value.
"""

import json
import os
import platform
import re
import tkinter as tk
from tkinter import ttk

from gui.live_chart import LiveChart, LiveSampler
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw

CATALOGUE = []

C_BLUE   = "#00e5ff"
C_ORANGE = "#e67e22"
C_GREEN  = "#2ecc71"
C_PINK   = "#e84393"
C_CYAN   = "#00cec9"
C_YELLOW = "#f1c40f"
C_MUTED  = "#9aa0a6"

# ---------------------------------------------------------------------------
# Scrollable inner frame (standard Canvas+Scrollbar pattern)
# ---------------------------------------------------------------------------
class _ScrollFrame(tk.Frame):
    """A tk.Frame with a vertical scrollbar; add children to .inner."""

    def __init__(self, parent, theme):
        super().__init__(parent, bg=theme["BG"])
        self._theme = theme
        vbar = tk.Scrollbar(self, orient="vertical")
        vbar.pack(side="right", fill="y")
        self._canvas = tk.Canvas(self, bg=theme["BG"],
                                 yscrollcommand=vbar.set,
                                 highlightthickness=0)
        self._canvas.pack(side="left", fill="both", expand=True)
        vbar.config(command=self._canvas.yview)
        self.inner = tk.Frame(self._canvas, bg=theme["BG"])
        self._win = self._canvas.create_window((0, 0), window=self.inner,
                                                anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self._canvas.bind("<Configure>", self._on_canvas)
        self._canvas.bind("<Enter>",  self._bind_wheel)
        self._canvas.bind("<Leave>",  self._unbind_wheel)

    def _on_inner(self, _e):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas(self, e):
        self._canvas.itemconfig(self._win, width=e.width)

    def _bind_wheel(self, _e):
        self._canvas.bind_all("<MouseWheel>",   self._wheel)
        self._canvas.bind_all("<Button-4>",      self._wheel)
        self._canvas.bind_all("<Button-5>",      self._wheel)

    def _unbind_wheel(self, _e):
        self._canvas.unbind_all("<MouseWheel>")
        self._canvas.unbind_all("<Button-4>")
        self._canvas.unbind_all("<Button-5>")

    def _wheel(self, e):
        if e.num == 4:
            self._canvas.yview_scroll(-1, "units")
        elif e.num == 5:
            self._canvas.yview_scroll(1, "units")
        else:
            self._canvas.yview_scroll(-1 * (e.delta // 120), "units")


# ---------------------------------------------------------------------------
# Small UI helpers
# ---------------------------------------------------------------------------
def _section(parent, theme, title):
    """Renders a section heading and returns a frame for children."""
    tk.Frame(parent, bg=theme["CARD_BORDER"], height=1).pack(
        fill="x", pady=(12, 0), padx=4)
    tk.Label(parent, text=title, bg=theme["BG"], fg=theme["ACCENT"],
             font=FONT_UI_BOLD).pack(anchor="w", padx=8, pady=(4, 2))
    body = tk.Frame(parent, bg=theme["BG"])
    body.pack(fill="x", padx=16)
    return body


def _kv(parent, theme, key, value, value_color=None):
    """One key → value row."""
    row = tk.Frame(parent, bg=theme["BG"])
    row.pack(fill="x", pady=1)
    tk.Label(row, text=key, bg=theme["BG"], fg=theme["MUTED"],
             font=FONT_UI, width=30, anchor="w").pack(side="left")
    vc = value_color or theme["FG"]
    tk.Label(row, text=str(value) if value not in (None, "") else "—",
             bg=theme["BG"], fg=vc, font=FONT_MONO,
             anchor="w", wraplength=520, justify="left").pack(side="left")


def _badge_row(parent, theme, items, good_items=()):
    """Render a wrapping row of coloured feature badges."""
    frame = tk.Frame(parent, bg=theme["BG"])
    frame.pack(fill="x", pady=(4, 0))
    col = 0
    for item in items:
        is_good = item.lower() in {x.lower() for x in good_items}
        bg = theme["CARD_BG"]
        fg = C_GREEN if is_good else theme["FG"]
        tk.Label(frame, text=item, bg=bg, fg=fg,
                 font=("Segoe UI", 8), relief="flat",
                 bd=0, padx=5, pady=2,
                 highlightthickness=1,
                 highlightbackground=theme["CARD_BORDER"]
                 ).grid(row=col // 8, column=col % 8,
                        sticky="w", padx=2, pady=2)
        col += 1


def _note(parent, theme, text, color=None):
    tk.Label(parent, text=text, bg=theme["BG"],
             fg=color or theme["MUTED"],
             font=FONT_UI, wraplength=700,
             justify="left").pack(anchor="w", pady=(2, 0), padx=4)


def _loading(parent, theme, text="Loading…"):
    lbl = tk.Label(parent, text=text, bg=theme["BG"],
                   fg=theme["MUTED"], font=FONT_UI)
    lbl.pack(anchor="w", pady=6, padx=4)
    return lbl


def _stat_tiles(parent, theme, names, cols=4):
    """Compact stat tiles (same style as live_monitor)."""
    grid = tk.Frame(parent, bg=theme["BG"])
    grid.pack(fill="x", pady=(6, 4))
    for c in range(cols):
        grid.columnconfigure(c, weight=1, uniform="t")
    vars_ = {}
    for i, name in enumerate(names):
        cell = tk.Frame(grid, bg=theme["CARD_BG"], highlightthickness=1,
                        highlightbackground=theme["CARD_BORDER"])
        cell.grid(row=i // cols, column=i % cols,
                  sticky="nsew", padx=3, pady=3)
        tk.Label(cell, text=name, bg=theme["CARD_BG"],
                 fg=theme["MUTED"], font=FONT_UI).pack(
                     anchor="w", padx=8, pady=(6, 0))
        v = tk.StringVar(value="—")
        lbl = tk.Label(cell, textvariable=v, bg=theme["CARD_BG"],
                       fg=theme["FG"],
                       font=("Segoe UI", 13, "bold"))
        lbl.pack(anchor="w", padx=8, pady=(0, 6))
        vars_[name] = (v, lbl)
    return vars_


def _tile_set(vars_, name, value, status=None):
    if name not in vars_:
        return
    v, lbl = vars_[name]
    v.set(value)
    lbl.config(fg=status_color(status) if status else lbl.cget("fg"))


# ---------------------------------------------------------------------------
# Data gatherers (run on background threads)
# ---------------------------------------------------------------------------

def _cpu_detail():
    """
    Returns a dict with every discoverable static CPU field.
    Sources tried in order:
      1. py-cpuinfo  (codename, flags, L-cache sizes, CPUID family/model/stepping)
      2. psutil      (core counts, min/max/current freq)
      3. Win32_Processor via PowerShell (socket, arch, microcode registry key)
      4. /proc/cpuinfo  (Linux: brand, stepping, microcode, current MHz)
      5. /sys/cpufreq   (Linux: available P-state frequencies)
      6. LibreHardwareMonitor WMI  (measured TDP / package power)
    Never raises; always returns a dict (may have "_source_notes" key explaining gaps).
    """
    info = {"_source_notes": []}

    # ── 1. py-cpuinfo ────────────────────────────────────────────────────────
    try:
        import cpuinfo as _ci
        raw = _ci.get_cpu_info()
        if raw:
            info["brand"]        = raw.get("brand_raw", "")
            info["codename"]     = raw.get("codename", "")
            info["vendor_id"]    = raw.get("vendor_id_raw", "")
            info["arch"]         = raw.get("arch_string_raw") or raw.get("arch", "")
            info["stepping"]     = raw.get("stepping", "")
            info["model_id"]     = raw.get("model", "")
            info["family"]       = raw.get("family", "")
            info["flags"]        = sorted(raw.get("flags") or [])
            info["hz_actual"]    = raw.get("hz_actual_friendly", "")
            info["hz_advertised"]= raw.get("hz_advertised_friendly", "")
            info["l1_data_kb"]   = _parse_cache(raw.get("l1_data_cache_size"))
            info["l1_instr_kb"]  = _parse_cache(raw.get("l1_instruction_cache_size"))
            info["l2_kb"]        = _parse_cache(raw.get("l2_cache_size"))
            info["l3_kb"]        = _parse_cache(raw.get("l3_cache_size"))
            info["_cpuinfo_ok"]  = True
    except ImportError:
        info["_source_notes"].append(
            "py-cpuinfo not installed — install it with  pip install py-cpuinfo  "
            "to unlock CPU codename, instruction-set flags and cache sizes.")
    except Exception as exc:
        info["_source_notes"].append(f"py-cpuinfo error: {exc}")

    # ── 2. psutil ────────────────────────────────────────────────────────────
    if hw.psutil:
        try:
            info.setdefault("physical_cores", hw.psutil.cpu_count(logical=False))
            info.setdefault("logical_cpus",   hw.psutil.cpu_count(logical=True))
            f = hw.psutil.cpu_freq()
            if f:
                if f.min:
                    info["min_mhz"] = round(f.min)
                info.setdefault("max_mhz",     round(f.max) if f.max else None)
                info.setdefault("current_mhz", round(f.current) if f.current else None)
        except Exception:
            pass

    # ── 3. WMI / PowerShell (Windows) ───────────────────────────────────────
    if hw.IS_WINDOWS:
        ok, out = hw.powershell(
            "Get-CimInstance Win32_Processor | Select-Object Name,CurrentClockSpeed,"
            "MaxClockSpeed,ExtClock,SocketDesignation,Architecture,Revision,Stepping,"
            "L2CacheSize,L3CacheSize,NumberOfCores,NumberOfLogicalProcessors,"
            "ProcessorId,Description | ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                d = json.loads(out)
                if isinstance(d, list): d = d[0]
                info.setdefault("brand",         (d.get("Name") or "").strip())
                info.setdefault("current_mhz",    d.get("CurrentClockSpeed"))
                info.setdefault("max_mhz",         d.get("MaxClockSpeed"))
                info["ext_clock_mhz"]            = d.get("ExtClock")
                info["socket"]                   = (d.get("SocketDesignation") or "").strip()
                _arch = {0:"x86",1:"MIPS",2:"Alpha",3:"PowerPC",
                         5:"ARM",6:"IA-64",9:"x86-64"}
                info.setdefault("arch",
                    _arch.get(d.get("Architecture"), str(d.get("Architecture",""))))
                # Revision encodes CPUID model/stepping: high byte = model, low byte = stepping
                rev = d.get("Revision")
                if rev is not None:
                    info.setdefault("model_id", (rev >> 8) & 0xFF)
                    info.setdefault("stepping",  rev & 0xFF)
                info["wmi_description"]          = (d.get("Description") or "").strip()
                info.setdefault("l2_kb", d.get("L2CacheSize"))
                info.setdefault("l3_kb", d.get("L3CacheSize"))
                info.setdefault("physical_cores", d.get("NumberOfCores"))
                info.setdefault("logical_cpus",   d.get("NumberOfLogicalProcessors"))
                info["processor_id"]             = (d.get("ProcessorId") or "").strip()
            except Exception:
                pass

        # Microcode (MCU) from registry
        ok2, mc = hw.powershell(
            r"$v = (Get-ItemProperty "
            r"'HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0' "
            r"-Name 'Update Revision' -ErrorAction SilentlyContinue).'Update Revision';"
            r"if($v){($v | ForEach-Object{'{0:X2}' -f $_}) -join ' '}")
        if ok2 and mc.strip():
            parts = mc.strip().split()
            # bytes are in little-endian pairs; microcode revision = bytes 4-7
            try:
                if len(parts) >= 8:
                    rev_hex = "".join(reversed(parts[4:8]))
                    info["microcode"] = "0x" + rev_hex.lstrip("0") or "0x00"
                else:
                    info["microcode"] = "0x" + "".join(parts)
            except Exception:
                info["microcode"] = mc.strip()

    # ── 4. /proc/cpuinfo (Linux) ─────────────────────────────────────────────
    else:
        try:
            with open("/proc/cpuinfo") as fh:
                for line in fh:
                    if ":" not in line:
                        continue
                    k, v = line.split(":", 1)
                    k, v = k.strip().lower(), v.strip()
                    if k == "model name":
                        info.setdefault("brand", v)
                    elif k == "stepping":
                        info.setdefault("stepping", v)
                    elif k == "microcode":
                        info.setdefault("microcode", v)
                    elif k == "cpu family":
                        info.setdefault("family", v)
                    elif k == "model":
                        info.setdefault("model_id", v)
                    elif k == "cpu mhz":
                        try:
                            info.setdefault("current_mhz", round(float(v)))
                        except Exception:
                            pass
        except Exception:
            pass

        # ── 5. P-state frequencies (/sys/cpufreq) ────────────────────────────
        try:
            path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies"
            with open(path) as fh:
                freqs = sorted({int(x) // 1000 for x in fh.read().split()
                                if x.strip().isdigit()}, reverse=True)
                if freqs:
                    info["p_states_mhz"] = freqs
        except Exception:
            pass
        # governor + driver
        for fname, key in (
                ("scaling_governor", "cpufreq_governor"),
                ("scaling_driver",   "cpufreq_driver")):
            try:
                with open(f"/sys/devices/system/cpu/cpu0/cpufreq/{fname}") as fh:
                    info[key] = fh.read().strip()
            except Exception:
                pass

    # ── 6. LibreHardwareMonitor: measured package power (TDP proxy) ──────────
    for name, value, parent, stype in hw.hwmon_sensors("Power"):
        if "/cpu" in (parent or "").lower() and value and "package" in name.lower():
            info["tdp_measured_w"] = round(value, 1)
            break

    # ── Hyperthreading / SMT ──────────────────────────────────────────────────
    phys = info.get("physical_cores")
    logi = info.get("logical_cpus")
    if phys and logi:
        info["smt"] = logi > phys
        info["threads_per_core"] = logi // phys if phys else None

    return info


def _parse_cache(v):
    """Convert a py-cpuinfo cache string ('512 KB', '32768') to KB int."""
    if v is None:
        return None
    if isinstance(v, int):
        return v // 1024 if v > 65536 else v
    s = str(v).lower().strip()
    m = re.match(r"([\d.]+)\s*([kmg]?)[b]?", s)
    if not m:
        return None
    n, u = float(m.group(1)), (m.group(2) or "k")
    return int(n if u == "k" else n * 1024 if u == "m" else n * 1024 * 1024)


# ─── GPU ─────────────────────────────────────────────────────────────────────

def _gpu_detail():
    """
    Returns a list of GPU dicts.  Each has as many fields as the available
    driver stack exposes:
      name, chipset, vram_bytes, driver_version, driver_date,
      clock_core_mhz, clock_mem_mhz, bus_interface, vendor, source
    """
    gpus = []

    # nvidia-smi -q gives chipset ("Product Architecture"), driver version, bus
    _smi_q = {}
    exe = hw.which("nvidia-smi")
    if exe:
        ok, out = hw.run([exe, "-q"], timeout=15)
        if ok:
            _smi_q = _parse_smi_q(out)

    # Base GPU list from hw_sensors (NVML / nvidia-smi / LHM / WMI)
    base = hw.gpu_list()

    for g in base:
        entry = dict(g)
        idx = str(g.get("index", 0))
        blk = _smi_q.get(idx, {})
        # chipset / architecture
        entry["chipset"]         = blk.get("chip_sku") or blk.get("product_architecture") or ""
        entry["driver_version"]  = blk.get("driver_version") or ""
        entry["driver_date"]     = blk.get("driver_date") or ""
        entry["bus_interface"]   = blk.get("bus_interface") or blk.get("bus_info") or ""
        entry["vbios_version"]   = blk.get("vbios_version") or ""
        entry["inforom_version"] = blk.get("inforom_image_version") or ""
        entry["power_limit_w"]   = blk.get("power_limit_w")
        entry["fan_speed_pct"]   = blk.get("fan_speed_pct")
        gpus.append(entry)

    if not gpus:
        # No NVML/nvidia-smi → try WMI VideoController for any GPU
        if hw.IS_WINDOWS:
            ok, out = hw.powershell(
                "Get-CimInstance Win32_VideoController | Select-Object Name,"
                "AdapterRAM,DriverVersion,DriverDate,VideoProcessor,DeviceID,"
                "AdapterDACType,InstalledDisplayDrivers,CurrentRefreshRate,"
                "VideoArchitecture,VideoModeDescription | ConvertTo-Json -Compress")
            if ok and out.strip()[:1] in ("{", "["):
                try:
                    data = json.loads(out)
                    for d in (data if isinstance(data, list) else [data]):
                        ram = d.get("AdapterRAM") or 0
                        dd  = d.get("DriverDate") or ""
                        # WMI DriverDate is a DMTF datetime string "20230101000000.000000+000"
                        if dd and len(dd) >= 8:
                            try:
                                dd = f"{dd[0:4]}-{dd[4:6]}-{dd[6:8]}"
                            except Exception:
                                pass
                        gpus.append({
                            "source":         "Win32_VideoController",
                            "name":            (d.get("Name") or "").strip(),
                            "chipset":         (d.get("VideoProcessor") or "").strip(),
                            "vram_bytes":      float(ram),
                            "driver_version":  (d.get("DriverVersion") or "").strip(),
                            "driver_date":     dd,
                            "bus_interface":   "",
                            "vendor":          "",
                        })
                except Exception:
                    pass

    return gpus


def _parse_smi_q(text):
    """
    Parse `nvidia-smi -q` text into a dict keyed by GPU index string.
    Only extracts fields we care about for System Summary.
    """
    result = {}
    current_gpu = None
    global_driver = None
    for line in text.splitlines():
        stripped = line.strip()
        # "Driver Version                          : 535.154.05"
        if stripped.startswith("Driver Version") and ":" in stripped:
            global_driver = stripped.split(":", 1)[1].strip()
        # "GPU 00000000:01:00.0"
        m = re.match(r"^GPU [\dA-Fa-f:\.]+", stripped)
        if m:
            current_gpu = str(len(result))
            result[current_gpu] = {"driver_version": global_driver or ""}
            continue
        if current_gpu is None:
            continue
        blk = result[current_gpu]
        if ":" not in stripped:
            continue
        k, v = stripped.split(":", 1)
        k, v = k.strip().lower(), v.strip()

        mapping = {
            "product architecture":   "product_architecture",
            "product brand":          "product_brand",
            "product name":           "product_name",
            "chip sku":               "chip_sku",
            "vbios version":          "vbios_version",
            "bus info":               "bus_info",
            "inforom image version":  "inforom_image_version",
            "current driver model":   "current_driver_model",
            "driver version":         "driver_version",
        }
        if k in mapping:
            blk[mapping[k]] = v
        elif k == "pcie generation":
            blk.setdefault("bus_interface", f"PCIe Gen{v}")
        elif k == "link width":
            prev = blk.get("bus_interface", "PCIe")
            blk["bus_interface"] = f"{prev} ×{v.replace('x','')}"
        elif k == "power limit" and v.endswith("W"):
            try:
                blk["power_limit_w"] = float(v.replace("W", "").strip())
            except Exception:
                pass
        elif k == "fan speed" and "%" in v:
            try:
                blk["fan_speed_pct"] = float(v.replace("%", "").strip())
            except Exception:
                pass

    # propagate global driver version to all GPUs
    for blk in result.values():
        blk.setdefault("driver_version", global_driver or "")
    return result


# ─── Memory ──────────────────────────────────────────────────────────────────

def _mem_detail():
    """
    Returns a dict with memory summary + per-module list.
    Sources:
      Windows : Win32_PhysicalMemory + Win32_PhysicalMemoryArray (WMI)
                LibreHardwareMonitor WMI sensors (timings, channel mode)
      Linux   : dmidecode -t memory
    Timings beyond what WMI exposes (CL, tRCD, tRP, tRAS, tRC, tRFC)
    come from LibreHardwareMonitor sensors or dmidecode; if neither
    is available the panel says so clearly.
    """
    result = {
        "total_bytes": None,
        "mem_type":    "",
        "mem_mode":    "",     # Single / Dual / Quad channel
        "current_mhz": None,
        "max_mhz":     None,
        "ref_mhz":     None,
        "ratio":       None,
        "command_rate":"",
        "ecc":         "",
        "timings":     {},     # {"CL": 18, "tRCD": 22, ...}
        "modules":     [],
        "_source_notes": [],
    }

    if hw.psutil:
        try:
            result["total_bytes"] = hw.psutil.virtual_memory().total
        except Exception:
            pass

    # ── LHM: channel mode + timings ──────────────────────────────────────────
    lhm_timing_map = {
        "cas latency":             "CL",
        "ras to cas delay":        "tRCD",
        "row precharge time":      "tRP",
        "active to precharge":     "tRAS",
        "row cycle time":          "tRC",
        "row refresh cycle time":  "tRFC",
        "row to row delay":        "tRRD",
        "write recovery time":     "tWR",
        "write to read delay":     "tWTR",
        "read to precharge":       "tRTP",
        "four activate window":    "tFAW",
        "command rate":            "CMD_RATE",
        "channel":                 "CHANNEL_MODE",
        "memory frequency":        "LHM_FREQ",
    }
    lhm_found_any = False
    for name, value, parent, stype in hw.hwmon_sensors():
        p = (parent or "").lower()
        n = (name or "").lower()
        if "/ram" not in p and "memory" not in p and "dram" not in p:
            continue
        lhm_found_any = True
        for needle, key in lhm_timing_map.items():
            if needle in n and value is not None:
                if key == "CHANNEL_MODE":
                    result["mem_mode"] = _channel_label(value)
                elif key == "LHM_FREQ":
                    result.setdefault("current_mhz") or None
                    result["lhm_freq_mhz"] = round(float(value))
                elif key == "CMD_RATE":
                    result["command_rate"] = f"{int(value)}T"
                else:
                    result["timings"][key] = int(value)
                break

    # ── Windows WMI ──────────────────────────────────────────────────────────
    if hw.IS_WINDOWS:
        # Physical memory array → ECC type + total slots
        ok, out = hw.powershell(
            "Get-CimInstance Win32_PhysicalMemoryArray | "
            "Select-Object MemoryDevices,MaxCapacity,ErrorCorrection | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                d = json.loads(out)
                if isinstance(d, list): d = d[0]
                result["total_slots"] = d.get("MemoryDevices")
                ecc_map = {1:"Other",2:"Unknown",3:"None",4:"Parity",
                           5:"Single-bit ECC",6:"Multi-bit ECC",7:"CRC"}
                ec = d.get("ErrorCorrection")
                result["ecc"] = ecc_map.get(ec, str(ec) if ec else "")
            except Exception:
                pass

        # Per-module info
        ok, out = hw.powershell(
            "Get-CimInstance Win32_PhysicalMemory | "
            "Select-Object BankLabel,DeviceLocator,Capacity,Speed,"
            "ConfiguredClockSpeed,ConfiguredVoltage,Manufacturer,"
            "PartNumber,SerialNumber,SMBIOSMemoryType,TypeDetail,"
            "DataWidth,TotalWidth,MinVoltage,MaxVoltage | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                data = json.loads(out)
                mods = data if isinstance(data, list) else [data]
                for m in mods:
                    cap = m.get("Capacity") or 0
                    spd = m.get("ConfiguredClockSpeed") or m.get("Speed")
                    mtype = _smbios_mem_type(m.get("SMBIOSMemoryType"))
                    result["modules"].append({
                        "slot":      (m.get("DeviceLocator") or
                                      m.get("BankLabel") or "?").strip(),
                        "size":      int(cap),
                        "type":      mtype,
                        "max_mhz":   m.get("Speed"),
                        "cfg_mhz":   spd,
                        "voltage_v": (m.get("ConfiguredVoltage") or 0) / 1000.0,
                        "vendor":    (m.get("Manufacturer") or "").strip(),
                        "part":      (m.get("PartNumber") or "").strip(),
                        "serial":    (m.get("SerialNumber") or "").strip(),
                    })
                    result["mem_type"] = result["mem_type"] or mtype
                    if spd:
                        result["current_mhz"] = result["current_mhz"] or spd
                    if m.get("Speed"):
                        result["max_mhz"] = max(
                            result["max_mhz"] or 0, m["Speed"]) or None
            except Exception:
                pass

        if not result["modules"]:
            result["_source_notes"].append(
                "Win32_PhysicalMemory returned no rows — try running TechDrive "
                "as Administrator.")

    # ── Linux dmidecode ───────────────────────────────────────────────────────
    else:
        ok, out = hw.run(["dmidecode", "-t", "memory"], timeout=15)
        if ok:
            cur = {}
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("Memory Device"):
                    if cur.get("size"):
                        result["modules"].append(cur)
                    cur = {}
                elif line.startswith("Memory Array Mapped Address"):
                    pass
                elif ":" in line:
                    k, v = line.split(":", 1)
                    k, v = k.strip(), v.strip()
                    if k == "Size" and "No Module" not in v:
                        m = re.search(r"(\d+)\s*(MB|GB)", v)
                        if m:
                            n = int(m.group(1))
                            cur["size"] = n * (1024**2 if m.group(2)=="MB"
                                               else 1024**3)
                    elif k == "Locator":
                        cur["slot"] = v
                    elif k == "Type":
                        cur["type"] = v
                        result["mem_type"] = result["mem_type"] or v
                    elif k == "Speed":
                        m = re.search(r"(\d+)", v)
                        if m:
                            cur["max_mhz"] = int(m.group(1))
                    elif k == "Configured Memory Speed":
                        m = re.search(r"(\d+)", v)
                        if m:
                            spd = int(m.group(1))
                            cur["cfg_mhz"] = spd
                            result["current_mhz"] = result["current_mhz"] or spd
                    elif k == "Manufacturer":
                        cur["vendor"] = v
                    elif k == "Part Number":
                        cur["part"] = v
                    elif k == "Serial Number":
                        cur["serial"] = v
                    elif k == "Error Correction Type":
                        result["ecc"] = v
                    # CAS Latency field (dmidecode sometimes has it)
                    elif k == "CAS Latency" and v.isdigit():
                        result["timings"].setdefault("CL", int(v))
            if cur.get("size"):
                result["modules"].append(cur)
        else:
            result["_source_notes"].append(
                "dmidecode not found or needs root — "
                "install dmidecode and run TechDrive with sudo for module details.")

    # ── Reference clock + ratio ───────────────────────────────────────────────
    mhz = result.get("current_mhz")
    if mhz:
        # DDR transfers data on both edges of the clock; WMI ConfiguredClockSpeed
        # is often reported in MT/s for DDR4 (e.g. 3200 for DDR4-3200).
        # Actual clock frequency = MT/s / 2.
        # Reference base clocks are 100 MHz (Intel/AMD standard) or
        # 133.33 MHz (older platforms).
        # We pick the common base that gives the nearest integer ratio.
        # Actual clock hz = mhz if reported as MT/s/2, else mhz/2 if in full MT/s
        # Modern WMI returns the full data rate on newer Windows (3200 for DDR4-3200)
        actual_hz = mhz / 2.0 if mhz > 800 else mhz  # MT/s → clock Hz

        for ref in (100, 133):
            ratio = round(actual_hz / ref)
            if ratio > 0 and abs(actual_hz - ratio * ref) / ref < 0.05:
                result["ref_mhz"] = ref
                result["ratio"]   = f"{ratio}× ({ref} MHz × {ratio})"
                break

    # ── Channel mode heuristic (if not from LHM) ─────────────────────────────
    if not result["mem_mode"] and result["modules"]:
        n = len(result["modules"])
        total = result.get("total_slots")
        if n == 1:
            result["mem_mode"] = "Single channel (1 module)"
        elif n in (2, 4, 6, 8) and n == total:
            result["mem_mode"] = (f"Dual channel likely ({n} modules / {total} slots) "
                                  "— verify with LibreHardwareMonitor")
        elif n == 4 and total and total >= 4:
            result["mem_mode"] = (f"Dual or Quad channel possible ({n}/{total} slots) "
                                  "— verify with LibreHardwareMonitor")
        else:
            result["mem_mode"] = (f"{n} module{'s' if n!=1 else ''} detected "
                                  "— run LibreHardwareMonitor for channel mode")

    if not result["timings"] and not lhm_found_any:
        result["_source_notes"].append(
            "Memory timings (CL, tRCD, tRP, tRAS, tRC, tRFC …) are not exposed "
            "by the standard OS API.  Start LibreHardwareMonitor and re-open this "
            "panel, or run  decode-dimms  (Linux) to read them from SPD EEPROM.")

    return result


def _smbios_mem_type(code):
    """SMBIOS memory type code → human string."""
    table = {
        1:"Other",2:"Unknown",3:"DRAM",4:"EDRAM",5:"VRAM",6:"SRAM",7:"RAM",
        8:"ROM",9:"FLASH",10:"EEPROM",11:"FEPROM",12:"EPROM",13:"CDRAM",
        14:"3DRAM",15:"SDRAM",16:"SGRAM",17:"RDRAM",18:"DDR",19:"DDR2",
        20:"DDR2 FB-DIMM",24:"DDR3",26:"DDR4",27:"LPDDR",28:"LPDDR2",
        29:"LPDDR3",30:"LPDDR4",31:"Logical non-volatile device",
        32:"HBM",33:"HBM2",34:"DDR5",35:"LPDDR5",
    }
    return table.get(code, f"Type {code}" if code else "Unknown")


def _channel_label(value):
    mapping = {1:"Single channel",2:"Dual channel",
               4:"Quad channel",8:"Octa channel"}
    try:
        return mapping.get(int(value), f"{int(value)}-channel")
    except Exception:
        return str(value)


# ─── System / Motherboard ─────────────────────────────────────────────────────

def _sys_detail():
    """
    Returns a dict with OS + motherboard + chipset info.
    Sources:
      All      : platform module
      Windows  : Win32_OperatingSystem, Win32_BaseBoard, Win32_BIOS,
                 Win32_SystemDriver / PnP for chipset
      Linux    : /etc/os-release, dmidecode -t baseboard, lspci
    """
    info = {"_source_notes": []}

    # ── OS ────────────────────────────────────────────────────────────────────
    info["os_name"]    = platform.system()
    info["os_version"] = platform.version()
    info["os_release"] = platform.release()
    info["machine"]    = platform.machine()
    info["hostname"]   = platform.node()
    info["python"]     = platform.python_version()

    if hw.IS_WINDOWS:
        ok, out = hw.powershell(
            "Get-CimInstance Win32_OperatingSystem | "
            "Select-Object Caption,Version,BuildNumber,OSArchitecture,"
            "ServicePackMajorVersion,InstallDate,LastBootUpTime | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                d = json.loads(out)
                if isinstance(d, list): d = d[0]
                info["os_name"]      = (d.get("Caption") or "").strip()
                info["os_version"]   = (d.get("Version") or "").strip()
                info["os_build"]     = str(d.get("BuildNumber") or "")
                info["os_arch"]      = (d.get("OSArchitecture") or "").strip()
                raw_boot = d.get("LastBootUpTime") or ""
                if raw_boot and len(raw_boot) >= 14:
                    info["last_boot"] = (f"{raw_boot[0:4]}-{raw_boot[4:6]}-{raw_boot[6:8]} "
                                         f"{raw_boot[8:10]}:{raw_boot[10:12]}")
            except Exception:
                pass
    else:
        # /etc/os-release
        try:
            with open("/etc/os-release") as fh:
                for line in fh:
                    if "=" not in line:
                        continue
                    k, v = line.strip().split("=", 1)
                    v = v.strip('"\'')
                    if k == "PRETTY_NAME":
                        info["os_name"] = v
                    elif k == "VERSION":
                        info["os_version"] = v
                    elif k == "BUILD_ID":
                        info["os_build"] = v
        except Exception:
            pass
        info["kernel"] = platform.uname().release

    # ── Motherboard + BIOS ────────────────────────────────────────────────────
    if hw.IS_WINDOWS:
        ok, out = hw.powershell(
            "Get-CimInstance Win32_BaseBoard | "
            "Select-Object Manufacturer,Product,Version,SerialNumber | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                d = json.loads(out)
                if isinstance(d, list): d = d[0]
                info["mb_vendor"]  = (d.get("Manufacturer") or "").strip()
                info["mb_model"]   = (d.get("Product") or "").strip()
                info["mb_version"] = (d.get("Version") or "").strip()
                info["mb_serial"]  = (d.get("SerialNumber") or "").strip()
            except Exception:
                pass

        ok, out = hw.powershell(
            "Get-CimInstance Win32_BIOS | "
            "Select-Object Manufacturer,Name,Version,ReleaseDate,SMBIOSBIOSVersion | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                d = json.loads(out)
                if isinstance(d, list): d = d[0]
                info["bios_vendor"]  = (d.get("Manufacturer") or "").strip()
                info["bios_version"] = (d.get("SMBIOSBIOSVersion") or
                                        d.get("Version") or "").strip()
                rd = d.get("ReleaseDate") or ""
                if rd and len(rd) >= 8:
                    info["bios_date"] = f"{rd[0:4]}-{rd[4:6]}-{rd[6:8]}"
            except Exception:
                pass

        # Chipset — look for known chipset device names in PnP device list
        ok, out = hw.powershell(
            "Get-PnpDevice -Class System -ErrorAction SilentlyContinue | "
            "Where-Object {$_.FriendlyName -match 'chipset|PCH|hub|smbus|mei'} | "
            "Select-Object -First 6 FriendlyName,InstanceId | "
            "ConvertTo-Json -Compress")
        if ok and out.strip()[:1] in ("{", "["):
            try:
                devs = json.loads(out)
                if isinstance(devs, dict): devs = [devs]
                chipset_names = []
                for d in devs:
                    fn = (d.get("FriendlyName") or "").strip()
                    if fn and fn not in chipset_names:
                        chipset_names.append(fn)
                if chipset_names:
                    info["chipset"] = "; ".join(chipset_names[:3])
            except Exception:
                pass

    else:
        # Linux: dmidecode baseboard
        ok, out = hw.run(["dmidecode", "-t", "baseboard"], timeout=10)
        if ok:
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    k, v = k.strip(), v.strip()
                    if k == "Manufacturer":
                        info["mb_vendor"] = v
                    elif k == "Product Name":
                        info["mb_model"] = v
                    elif k == "Version":
                        info["mb_version"] = v

        ok, out = hw.run(["dmidecode", "-t", "bios"], timeout=10)
        if ok:
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    k, v = k.strip(), v.strip()
                    if k == "Vendor":
                        info["bios_vendor"] = v
                    elif k == "Version":
                        info["bios_version"] = v
                    elif k == "Release Date":
                        info["bios_date"] = v

        # Chipset via lspci
        ok, out = hw.run(["lspci"], timeout=10)
        if ok:
            chipsets = []
            for line in out.splitlines():
                low = line.lower()
                if any(t in low for t in ("isa bridge", "pch", "smbus",
                                          "host bridge", "memory controller hub")):
                    # extract the device description after the class
                    parts = line.split(":", 2)
                    if len(parts) >= 3:
                        dev = parts[2].strip()
                        # strip " (rev XX)" suffix
                        dev = re.sub(r"\s*\(rev [0-9a-f]+\)\s*$", "", dev)
                        if dev not in chipsets:
                            chipsets.append(dev)
            if chipsets:
                info["chipset"] = "; ".join(chipsets[:3])

    return info


# ─── Live CPU sample ──────────────────────────────────────────────────────────

def _make_cpu_sampler_fn():
    """Returns a closure that captures the max_mhz after first call."""
    state = {"max_mhz": None}

    def _sample():
        if hw.psutil is None:
            return {"error": "psutil not installed"}
        freq   = None
        max_f  = None
        try:
            f = hw.psutil.cpu_freq()
            if f:
                freq  = round(f.current, 0)
                max_f = round(f.max, 0) if f.max else None
        except Exception:
            pass
        if max_f:
            state["max_mhz"] = max_f
        usage = hw.psutil.cpu_percent(interval=None)
        eff   = None
        if freq is not None:
            eff = freq * (usage / 100.0)
        elif state["max_mhz"]:
            eff = state["max_mhz"] * (usage / 100.0)
        return {
            "active_mhz":    freq,
            "effective_mhz": round(eff, 0) if eff is not None else None,
            "usage_pct":     usage,
            "temp_c":        hw.cpu_temperature(),
            "max_mhz":       state["max_mhz"],
        }
    return _sample


# ─── Main tool ────────────────────────────────────────────────────────────────

