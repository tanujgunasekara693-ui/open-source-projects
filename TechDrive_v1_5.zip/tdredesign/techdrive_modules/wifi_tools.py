#!/usr/bin/env python3
"""
Module: wifi_tools
Generated for TechDrive 500
Category: WiFi Tools
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('WiFi Tools',
  '📶',
  ['WiFi Info', 'Networks', 'Signal Strength', 'Channel Analyzer', 'Security Check'])]


def _netsh(args, timeout=15):
    """Run a netsh wlan command and return stdout/stderr text."""
    r = subprocess.run(["netsh", "wlan"] + args, capture_output=True, text=True, timeout=timeout)
    return (r.stdout or "") + (("\n" + r.stderr) if r.stderr else "")


# ---------------------------------------------------------------------------
# WiFi Info
# ---------------------------------------------------------------------------

def tool_wifi_tools_wifi_info(self, frame):
    """WiFi Info — WiFi Tools"""
    panel = CardPanel(frame, self.theme, "WiFi Info",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            out = _netsh(["show", "interfaces"])
            if not out.strip():
                return "No wireless interfaces found. Make sure a WiFi adapter is installed and enabled."
            drv = _netsh(["show", "drivers"])
            return "=== WiFi Interface ===\n" + out + "\n\n=== WiFi Driver Info ===\n" + drv
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except FileNotFoundError:
            return "'netsh' was not found on this system."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Networks (scan for nearby SSIDs)
# ---------------------------------------------------------------------------

def tool_wifi_tools_networks(self, frame):
    """Networks — WiFi Tools"""
    panel = CardPanel(frame, self.theme, "Networks",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            out = _netsh(["show", "networks", "mode=Bssid"], timeout=25)
            if not out.strip():
                return "No networks found. Ensure WiFi is turned on."
            return out
        except subprocess.TimeoutExpired:
            return "Operation timed out while scanning for networks."
        except FileNotFoundError:
            return "'netsh' was not found on this system."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Connect (to a saved profile, or a new SSID + password)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Disconnect
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Password Viewer (saved profile keys — requires admin privileges)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Signal Strength
# ---------------------------------------------------------------------------

def tool_wifi_tools_signal_strength(self, frame):
    """Signal Strength — WiFi Tools"""
    panel = CardPanel(frame, self.theme, "Signal Strength",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            out = _netsh(["show", "interfaces"])
            if not out.strip():
                return "No wireless interfaces found."
            ssid_match = re.search(r"^\s*SSID\s*:\s*(.+)$", out, re.MULTILINE)
            signal_match = re.search(r"Signal\s*:\s*(\d+)%", out)
            state_match = re.search(r"State\s*:\s*(.+)", out)

            if not signal_match:
                return "Not currently connected to a WiFi network.\n\n" + out

            signal = int(signal_match.group(1))
            ssid = ssid_match.group(1).strip() if ssid_match else "Unknown"
            state = state_match.group(1).strip() if state_match else "Unknown"

            if signal >= 80:
                quality = "Excellent"
            elif signal >= 60:
                quality = "Good"
            elif signal >= 40:
                quality = "Fair"
            elif signal >= 20:
                quality = "Weak"
            else:
                quality = "Very Weak"

            bar = "\u2588" * (signal // 5) + "\u2591" * (20 - signal // 5)

            return (
                f"SSID: {ssid}\n"
                f"State: {state}\n"
                f"Signal Strength: {signal}%  [{bar}]\n"
                f"Quality: {quality}\n\n"
                f"=== Raw Interface Data ===\n{out}"
            )
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except FileNotFoundError:
            return "'netsh' was not found on this system."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Channel Analyzer
# ---------------------------------------------------------------------------

def tool_wifi_tools_channel_analyzer(self, frame):
    """Channel Analyzer — WiFi Tools"""
    panel = CardPanel(frame, self.theme, "Channel Analyzer",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            out = _netsh(["show", "networks", "mode=Bssid"], timeout=25)
            if not out.strip():
                return "No networks found. Ensure WiFi is turned on."

            entries = []
            current_ssid = None
            for line in out.splitlines():
                m_ssid = re.match(r"^SSID\s+\d+\s*:\s*(.*)$", line.strip())
                if m_ssid:
                    current_ssid = m_ssid.group(1).strip() or "(hidden)"
                    continue
                m_chan = re.match(r"^Channel\s*:\s*(\d+)", line.strip())
                if m_chan and current_ssid:
                    entries.append((current_ssid, int(m_chan.group(1))))

            if not entries:
                return "Could not parse channel data.\n\n" + out

            channel_counts = {}
            for ssid, ch in entries:
                channel_counts.setdefault(ch, []).append(ssid)

            lines = ["=== Channel Usage (nearby networks) ===\n"]
            for ch in sorted(channel_counts.keys()):
                ssids = channel_counts[ch]
                congestion = "Congested" if len(ssids) >= 3 else ("Busy" if len(ssids) == 2 else "Clear")
                lines.append(f"Channel {ch:>3}: {len(ssids)} network(s) — {congestion}")
                for s in ssids:
                    lines.append(f"    - {s}")

            best = min(channel_counts.items(), key=lambda kv: len(kv[1]))[0] if channel_counts else None
            if best is not None:
                lines.append(f"\nLeast congested channel detected: {best}")

            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "Operation timed out while scanning for networks."
        except FileNotFoundError:
            return "'netsh' was not found on this system."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Profile (view / manage saved profiles)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Adapter Info
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Security Check
# ---------------------------------------------------------------------------

def tool_wifi_tools_security_check(self, frame):
    """Security Check — WiFi Tools"""
    panel = CardPanel(frame, self.theme, "Security Check",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            iface_out = _netsh(["show", "interfaces"])
            auth_match = re.search(r"Authentication\s*:\s*(.+)", iface_out)
            cipher_match = re.search(r"Cipher\s*:\s*(.+)", iface_out)
            ssid_match = re.search(r"^\s*SSID\s*:\s*(.+)$", iface_out, re.MULTILINE)

            findings = []
            if not auth_match:
                findings.append("Not currently connected to a WiFi network — connect first for a live check.")
            else:
                auth = auth_match.group(1).strip()
                cipher = cipher_match.group(1).strip() if cipher_match else "Unknown"
                ssid = ssid_match.group(1).strip() if ssid_match else "Unknown"

                findings.append(f"Connected SSID: {ssid}")
                findings.append(f"Authentication: {auth}")
                findings.append(f"Cipher: {cipher}")

                auth_upper = auth.upper()
                if "OPEN" in auth_upper or auth_upper == "NONE":
                    findings.append("RISK: Network is OPEN (unencrypted). Avoid sending sensitive data.")
                elif "WEP" in auth_upper:
                    findings.append("RISK: WEP encryption is obsolete and easily broken. Upgrade router security.")
                elif "WPA2" in auth_upper or "WPA3" in auth_upper:
                    findings.append("OK: Using WPA2/WPA3, a currently recommended standard.")
                elif "WPA" in auth_upper:
                    findings.append("WARNING: Plain WPA is outdated; upgrade to WPA2/WPA3 if possible.")
                else:
                    findings.append(f"Unrecognized authentication type: {auth}")

            profiles_out = _netsh(["show", "profiles"])
            names = re.findall(r"All User Profile\s*:\s*(.+)", profiles_out)
            weak_profiles = []
            for name in [n.strip() for n in names]:
                detail = _netsh(["show", "profile", f"name={name}"])
                pauth = re.search(r"Authentication\s*:\s*(.+)", detail)
                if pauth:
                    pa = pauth.group(1).strip().upper()
                    if "OPEN" in pa or "WEP" in pa:
                        weak_profiles.append(f"{name} ({pauth.group(1).strip()})")

            if weak_profiles:
                findings.append("\nSaved profiles using weak/no security:")
                findings.extend(f"  - {p}" for p in weak_profiles)
            else:
                findings.append("\nNo saved profiles found using open/WEP security.")

            return "\n".join(findings)
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except FileNotFoundError:
            return "'netsh' was not found on this system."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)
