#!/usr/bin/env python3
r"""
techdrive_modules/reporting_tools.py - Reporting & Sharing Tools category
============================================================================
Exports a full system snapshot (OS/CPU/RAM/GPU/storage) to a file, and
optionally publishes it as a real public GitHub Gist for a shareable link.

Honest limit: an actual internet-hosted "shareable link" needs somewhere
to host the content. This app has no server of its own and no bundled
API credentials, so Generate Shareable Link uses GitHub's Gist API with
a personal access token you supply yourself (a real, working upload,
not a fake URL) - or, without a token, it just saves the file locally
and tells you so plainly, rather than inventing a link.
"""

import datetime
import json
import platform
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog

from gui.theme import FONT_UI, FONT_MONO
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.partition_tools import bytes_fmt

CATALOGUE = []


def _gather_report_dict():
    cpu = hw.cpu_static()
    ram = hw.ram_sample()
    mods = hw.ram_modules()
    gpus = hw.gpu_list()
    disks = hw.physical_disks()
    mb = hw.motherboard_info()
    bios = hw.bios_info()
    return {
        "generated": datetime.datetime.now().isoformat(timespec="seconds"),
        "os": {"system": platform.system(), "release": platform.release(),
              "version": platform.version(), "machine": platform.machine()},
        "cpu": cpu,
        "ram": {"total": ram.get("total"), "percent": ram.get("percent"),
               "modules": mods},
        "motherboard": mb,
        "bios": bios,
        "gpu": gpus,
        "storage": [{"path": d.get("path"), "model": d.get("model"),
                    "size": d.get("size"), "media": d.get("media")} for d in disks],
    }


def _report_to_text(r):
    lines = [f"TechDrive System Report - generated {r['generated']}", "=" * 60, "",
             "OS", "-" * 20,
             f"{r['os']['system']} {r['os']['release']} ({r['os']['version']})",
             f"Machine: {r['os']['machine']}", "",
             "CPU", "-" * 20,
             f"{r['cpu'].get('model', '?')}",
             f"Physical cores: {r['cpu'].get('physical', '?')}  Logical: {r['cpu'].get('logical', '?')}",
             "", "RAM", "-" * 20,
             f"Total: {bytes_fmt(r['ram'].get('total', 0))}  Used: {r['ram'].get('percent', '?')}%"]
    for m in r["ram"]["modules"]:
        lines.append(f"  Slot {m.get('slot')}: {bytes_fmt(m.get('size', 0))} @ {m.get('speed')} MT/s "
                     f"({m.get('vendor')} {m.get('part')})")
    lines += ["", "Motherboard", "-" * 20,
             f"{r['motherboard'].get('manufacturer', '?')} {r['motherboard'].get('model', '?')}",
             "", "BIOS", "-" * 20,
             f"{r['bios'].get('vendor', '?')} {r['bios'].get('version', '?')} ({r['bios'].get('date', '?')})",
             "", "GPU", "-" * 20]
    for g in r["gpu"]:
        lines.append(f"  {g.get('name', '?')}")
    lines += ["", "Storage", "-" * 20]
    for d in r["storage"]:
        lines.append(f"  {d.get('path')} - {d.get('model', '?')} ({bytes_fmt(d.get('size', 0))})")
    return "\n".join(lines)


def _report_to_html(r):
    def esc(s):
        return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    rows = []
    for section, content in (
        ("OS", f"{r['os']['system']} {r['os']['release']} ({r['os']['version']})"),
        ("CPU", esc(r['cpu'].get('model', '?'))),
        ("RAM", f"{bytes_fmt(r['ram'].get('total', 0))} ({r['ram'].get('percent', '?')}% used)"),
        ("Motherboard", esc(f"{r['motherboard'].get('manufacturer', '?')} {r['motherboard'].get('model', '?')}")),
        ("BIOS", esc(f"{r['bios'].get('vendor', '?')} {r['bios'].get('version', '?')}")),
    ):
        rows.append(f"<tr><th>{section}</th><td>{content}</td></tr>")
    gpu_rows = "".join(f"<li>{esc(g.get('name', '?'))}</li>" for g in r["gpu"]) or "<li>None detected</li>"
    disk_rows = "".join(f"<li>{esc(d.get('path'))} - {esc(d.get('model', '?'))} "
                        f"({bytes_fmt(d.get('size', 0))})</li>" for d in r["storage"]) or "<li>None detected</li>"
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TechDrive System Report</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;background:#1e1e1e;color:#dcdcdc;padding:24px}}
h1{{color:#00e5ff}} table{{border-collapse:collapse;width:100%;margin-bottom:16px}}
th,td{{border:1px solid #454545;padding:8px 12px;text-align:left}}
th{{background:#2b2b2b;width:160px}} ul{{margin:0;padding-left:20px}}
</style></head><body>
<h1>TechDrive System Report</h1>
<p>Generated {esc(r['generated'])}</p>
<table>{"".join(rows)}</table>
<h3>GPU</h3><ul>{gpu_rows}</ul>
<h3>Storage</h3><ul>{disk_rows}</ul>
</body></html>"""


def _report_to_xml(r):
    def esc(s):
        return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<TechDriveReport generated="{esc(r["generated"])}">',
             f'  <OS system="{esc(r["os"]["system"])}" release="{esc(r["os"]["release"])}"/>',
             f'  <CPU model="{esc(r["cpu"].get("model", "?"))}" physical="{r["cpu"].get("physical", "?")}" '
             f'logical="{r["cpu"].get("logical", "?")}"/>',
             f'  <RAM total="{r["ram"].get("total", 0)}" percent="{r["ram"].get("percent", "?")}">']
    for m in r["ram"]["modules"]:
        parts.append(f'    <Module slot="{esc(m.get("slot"))}" size="{m.get("size", 0)}" '
                     f'speed="{esc(str(m.get("speed")))}" vendor="{esc(m.get("vendor"))}"/>')
    parts.append("  </RAM>")
    parts.append(f'  <Motherboard manufacturer="{esc(r["motherboard"].get("manufacturer", "?"))}" '
                 f'model="{esc(r["motherboard"].get("model", "?"))}"/>')
    parts.append(f'  <BIOS vendor="{esc(r["bios"].get("vendor", "?"))}" '
                 f'version="{esc(r["bios"].get("version", "?"))}"/>')
    parts.append("  <GPUs>")
    for g in r["gpu"]:
        parts.append(f'    <GPU name="{esc(g.get("name", "?"))}"/>')
    parts.append("  </GPUs>")
    parts.append("  <Storage>")
    for d in r["storage"]:
        parts.append(f'    <Disk path="{esc(d.get("path"))}" model="{esc(d.get("model", "?"))}" '
                     f'size="{d.get("size", 0)}"/>')
    parts.append("  </Storage>")
    parts.append("</TechDriveReport>")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Export System Report
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Generate Shareable Link
# ---------------------------------------------------------------------------


def _pw_entry(self, parent, label):
    row = tk.Frame(parent, bg=self.theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=self.theme["BG"], fg=self.theme["MUTED"], font=FONT_UI,
             width=22, anchor="w").pack(side="left")
    var = tk.StringVar()
    ttk.Entry(row, textvariable=var, width=44, show="•").pack(side="left")
    return var
