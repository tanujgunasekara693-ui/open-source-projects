#!/usr/bin/env python3
r"""
techdrive_modules/wipe_tools.py - Wipe Tools category
=========================================================
Real, working secure-erase tools. Everything here is genuinely
destructive by design (that is the point of a wipe tool), so every
single action requires an explicit confirmation dialog naming exactly
what will be erased, and disk/partition-level wipes additionally warn
if TechDrive isn't running elevated. Nothing runs automatically on
tab-open.

Implementation notes:
  - File/folder wipes overwrite file contents with random data before
    deleting, so the plaintext isn't trivially recoverable from the
    file's own blocks (full anti-forensic guarantees on SSDs / journaled
    filesystems are out of scope for a shop tool - wear-levelling and
    TRIM mean overwrite-before-delete is best-effort there, which is why
    "Wipe Free Space" (cipher /w) and full-disk "clean all" are offered
    for the stronger guarantee of touching every physical sector).
  - Whole-disk / partition wipes use diskpart, the same mechanism
    Partition Tools and Volume Manager already use.
  - Registry key wipe only allows HKCU/HKLM/HKU roots and always shows
    the exact key before deleting anything.
"""

import os
import platform
import re
import time
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import messagebox, filedialog
from gui.tool_view import CardPanel

from techdrive_modules import hw_sensors as hw
from techdrive_modules.clone_tools import _disk_picker, is_elevated
from techdrive_modules.partition_tools import (
    run_diskpart, _volume_picker, _confirm, _labeled_entry, _elevation_note, IS_WINDOWS,
)

WIPE_CHUNK = 4 * 1024 * 1024


def bytes_fmt(n):
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def _run(args, timeout=60):
    import subprocess
    NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip() or f"(no output, exit code {r.returncode})"
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Operation timed out."
    except Exception as e:
        return f"Error: {e}"


def _powershell(script, timeout=60):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


def _overwrite_file(path, passes=1, log=None):
    """Overwrite a file's contents with random data in place, then delete it."""
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return f"Could not stat {path}: {e}"
    try:
        with open(path, "r+b", buffering=0) as f:
            for p in range(passes):
                f.seek(0)
                remaining = size
                while remaining > 0:
                    block = min(WIPE_CHUNK, remaining)
                    f.write(os.urandom(block))
                    remaining -= block
                f.flush()
                os.fsync(f.fileno())
        os.remove(path)
        if log:
            log(f"Wiped: {path} ({bytes_fmt(size)})")
        return True
    except Exception as e:
        if log:
            log(f"FAILED: {path}: {e}")
        return False


CATALOGUE = []


def _confirm_wipe(desc):
    return messagebox.askyesno(
        "Confirm secure wipe",
        f"This PERMANENTLY destroys data on:\n\n{desc}\n\n"
        "This cannot be undone. Continue?",
        icon="warning")


# ---------------------------------------------------------------------------
# Secure Wipe Drive (whole physical disk, diskpart clean all)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe Partition (delete + zero the partition's own extent)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe File
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe Folder
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe Free Space
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe Recycle Bin
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Wipe Registry Key
# ---------------------------------------------------------------------------
_REG_ROOTS = {
    "HKCU": None, "HKEY_CURRENT_USER": None,
    "HKLM": None, "HKEY_LOCAL_MACHINE": None,
    "HKU": None, "HKEY_USERS": None,
}


def _delete_registry_tree(hive, subkey):
    import winreg
    try:
        with winreg.OpenKey(hive, subkey, 0, winreg.KEY_ALL_ACCESS) as key:
            while True:
                try:
                    child = winreg.EnumKey(key, 0)
                except OSError:
                    break
                _delete_registry_tree(hive, subkey + "\\" + child)
        winreg.DeleteKey(hive, subkey)
        return True
    except FileNotFoundError:
        return False




# ---------------------------------------------------------------------------
# Wipe USB / Wipe SD  (removable physical disks, same mechanism as Secure Wipe Drive)
# ---------------------------------------------------------------------------
def _removable_wipe_panel(self, frame, label_word):
    panel = CardPanel(frame, self.theme, f"Wipe {label_word}",
                       f"Zero-fills a removable ({label_word}) drive with 'diskpart clean all'. "
                       "Only drives TechDrive detects as removable/USB are listed.")
    _elevation_note(self, panel.body)
    disk = _disk_picker(self, panel.body, "Removable drive")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run(d):
        ok, log = run_diskpart([f"select disk {d['id']}", "clean all"], timeout=7200)
        return log

    def go():
        d = disk()
        if not d:
            messagebox.showerror("TechDrive", "Pick a drive first.")
            return
        bus = (d.get("bus") or "").upper()
        media = (d.get("media") or "").upper()
        if "USB" not in bus and "REMOVABLE" not in media and "SD" not in bus:
            if not messagebox.askyesno(
                    "TechDrive",
                    f"{d.get('path')} doesn't look like a removable drive (bus={d.get('bus')}, "
                    f"media={d.get('media')}). Wipe it anyway?", icon="warning"):
                return
        desc = f"{d.get('path')} - {d.get('model')} ({bytes_fmt(d.get('size', 0))})"
        if not _confirm_wipe(desc):
            return
        redraw(f"Zero-filling {desc} ...\n")
        self._run_bg(lambda: run(d), redraw)

    self._button_row(panel.body, [(f"⌁ Wipe {label_word}", go)])






# ---------------------------------------------------------------------------
# Wipe Network Drive
# ---------------------------------------------------------------------------
