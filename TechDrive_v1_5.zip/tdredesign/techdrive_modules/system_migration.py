#!/usr/bin/env python3
"""
techdrive_modules/system_migration.py — OS Migration & Recovery
================================================================
Real tools for OS migration, per-partition backup/restore,
partition-table recovery and file-signature-based file recovery.

Every operation queries actual hardware or the OS. When an external
utility (testdisk, photorec, bcdboot, grub-install) is absent, the panel
says so and shows the install command — it never falls back to fake output.
Raw device access requires Administrator (Windows) or root (Linux).

Tools in this module:
  OS Migration Wizard      – detect boot disk, clone to target, fix bootloader
  Backup Partition         – create raw .img of a single partition
  Restore Partition        – write .img back onto a partition
  Partition Recovery Scanner – scan disk sectors for lost partition signatures
  File Recovery Scanner    – carve files by magic bytes or delegate to photorec
  Quick File Undelete      – Windows Recycle Bin restore / Linux ext4 scan
  Partition Table Viewer   – display current MBR / GPT table
  Migration Health Check   – pre-migration go/no-go checklist
"""

import ctypes
import gzip
import hashlib
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog, messagebox

from gui.live_chart import LiveChart
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell, _Tiles, _controls, _missing
from techdrive_modules.clone_tools import (
    CHUNK, JobUI, copy_stream, device_size, is_elevated,
    _elevation_banner, _confirm_destructive,
)

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0

CATALOGUE = []


# ---------------------------------------------------------------------------
# helpers shared across this module
# ---------------------------------------------------------------------------
def _run(cmd, timeout=30):
    """Run an argv list, return (ok, stdout+stderr). Never raises."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           creationflags=NO_WINDOW)
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except FileNotFoundError:
        return False, f"{cmd[0]}: not found"
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as e:
        return False, str(e)


def _ps(script, timeout=30):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


def _which(name):
    return shutil.which(name)


def _bytes_fmt(n):
    return hw.bytes_fmt(n)


# ---------------------------------------------------------------------------
# Windows-specific helpers
# ---------------------------------------------------------------------------
def _win_partitions_raw():
    """List of dicts with raw partition device paths on Windows via PowerShell."""
    ok, out = _ps(
        "Get-Partition | Select-Object DiskNumber,PartitionNumber,DriveLetter,"
        "Size,Type,Offset,IsSystem,IsBoot,IsHidden | ConvertTo-Json -Compress",
        timeout=20)
    if not ok or not out.strip().startswith(("[", "{")):
        return []
    try:
        data = json.loads(out)
        parts = data if isinstance(data, list) else [data]
        result = []
        for p in parts:
            dl = p.get("DriveLetter") or ""
            dl = dl.strip() if isinstance(dl, str) else ""
            path = (f"\\\\?\\{dl}:" if dl else
                    f"\\\\.\\Harddisk{p.get('DiskNumber')}Partition{p.get('PartitionNumber')}")
            result.append({
                "disk": p.get("DiskNumber"),
                "part": p.get("PartitionNumber"),
                "letter": dl,
                "size": float(p.get("Size") or 0),
                "type": p.get("Type") or "Unknown",
                "offset": int(p.get("Offset") or 0),
                "is_system": bool(p.get("IsSystem")),
                "is_boot": bool(p.get("IsBoot")),
                "path": path,
            })
        return result
    except Exception:
        return []


def _linux_partitions_raw():
    """Partition list on Linux via lsblk."""
    ok, out = _run(["lsblk", "-JpPo", "NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL,TYPE,MAJ:MIN"], timeout=10)
    parts = []
    if ok:
        try:
            data = json.loads(out)

            def walk(dev):
                if dev.get("type") in ("part", "disk"):
                    mount = (dev.get("mountpoint") or "").strip()
                    parts.append({
                        "path": dev.get("name"),
                        "size": hw._size_to_bytes(dev.get("size", "0")),
                        "fs": dev.get("fstype") or "",
                        "mount": mount,
                        "label": dev.get("label") or "",
                        "type": dev.get("type"),
                    })
                for child in dev.get("children") or []:
                    walk(child)

            for d in data.get("blockdevices", []):
                walk(d)
        except Exception:
            pass
    return parts


def _partitions():
    """Unified partition list, always has: path, size, label/type, mount."""
    if IS_WINDOWS:
        raw = _win_partitions_raw()
        if raw:
            return raw
    if not IS_WINDOWS:
        return _linux_partitions_raw()
    # Fallback: psutil
    import psutil
    result = []
    for p in psutil.disk_partitions(all=False):
        try:
            u = psutil.disk_usage(p.mountpoint)
            size = u.total
        except Exception:
            size = 0
        result.append({"path": p.device, "size": size, "mount": p.mountpoint,
                       "fs": p.fstype, "label": "", "type": "part"})
    return result


def _detect_boot_disk():
    """Return the physical disk path containing the current boot/OS partition."""
    if IS_WINDOWS:
        ok, out = _ps(
            "(Get-Partition | Where-Object IsBoot -eq $true | "
            "Get-Disk | Select-Object -ExpandProperty Number)", timeout=15)
        if ok and out.strip().isdigit():
            return f"\\\\.\\PhysicalDrive{out.strip()}"
        # Fallback: look at where C: lives
        ok2, out2 = _ps(
            "(Get-Partition -DriveLetter C -ErrorAction SilentlyContinue | "
            "Select-Object -ExpandProperty DiskNumber)", timeout=15)
        if ok2 and out2.strip().isdigit():
            return f"\\\\.\\PhysicalDrive{out2.strip()}"
        return "\\\\.\\PhysicalDrive0"
    else:
        # Linux: find disk hosting /
        try:
            with open("/proc/mounts") as fh:
                for line in fh:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] == "/":
                        dev = parts[0]
                        # Strip partition number to get disk (sda1 → sda, nvme0n1p1 → nvme0n1)
                        disk = re.sub(r"p?\d+$", "", dev)
                        if os.path.exists(disk):
                            return disk
                        return dev
        except Exception:
            pass
        ok, out = _run(["findmnt", "-n", "-o", "SOURCE", "/"], timeout=5)
        if ok and out.strip():
            dev = out.strip()
            disk = re.sub(r"p?\d+$", "", dev)
            return disk if os.path.exists(disk) else dev
        return "/dev/sda"


# ---------------------------------------------------------------------------
# Partition picker widget
# ---------------------------------------------------------------------------
def _partition_picker(app, parent, label):
    """Dropdown of real partitions. Returns a callable that gives the selected dict."""
    row = tk.Frame(parent, bg=app.theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=app.theme["BG"], fg=app.theme["MUTED"],
             font=FONT_UI, width=16, anchor="w").pack(side="left")
    var = tk.StringVar()
    combo = ttk.Combobox(row, textvariable=var, width=72, state="readonly")
    combo.pack(side="left", fill="x", expand=True)
    mapping = {}

    def refresh():
        parts = _partitions()
        values = []
        mapping.clear()
        for p in parts:
            label_parts = [p.get("path", "?")]
            if p.get("letter"):
                label_parts.append(f"{p['letter']}:")
            if p.get("mount"):
                label_parts.append(p["mount"])
            label_parts.append(_bytes_fmt(p.get("size", 0)))
            if p.get("fs"):
                label_parts.append(p["fs"])
            if p.get("type"):
                label_parts.append(p["type"])
            if p.get("is_boot"):
                label_parts.append("(BOOT)")
            if p.get("is_system"):
                label_parts.append("(SYSTEM)")
            text = "  |  ".join(str(x) for x in label_parts)
            values.append(text)
            mapping[text] = p
        combo["values"] = values
        if values and not var.get():
            var.set(values[0])

    def selected():
        return mapping.get(var.get())

    tk.Button(row, text="⟳", command=refresh, bg=app.theme["BG_LIGHT"], fg=app.theme["FG"],
              relief="flat", padx=8).pack(side="left", padx=6)
    refresh()
    return selected


# ---------------------------------------------------------------------------
# Tool 1 — OS Migration Wizard
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 2 — Backup Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 3 — Restore Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Filesystem signature database used by tools 4 & 5
# ---------------------------------------------------------------------------
FS_SIGS = [
    # (name, offset_in_sector, magic_bytes, typical_sector_alignment)
    ("NTFS",    0,    b"\xEB\x52\x90NTFS",                    63),
    ("NTFS",    0,    b"\xEB\x58\x90NTFS",                    2048),
    ("FAT32",   82,   b"FAT32   ",                              63),
    ("FAT16",   54,   b"FAT16   ",                              63),
    ("exFAT",   0,    b"\xEB\x76\x90EXFAT   ",                 2048),
    ("ext4",    1080, b"\x53\xEF",                              2048),   # ext superblock magic
    ("ext3",    1080, b"\x53\xEF",                              2048),
    ("ext2",    1080, b"\x53\xEF",                              2048),
    ("btrfs",   65600, b"_BHRfS_M",                            2048),
    ("XFS",     0,    b"XFSB",                                  2048),
    ("GPT Header", 512, b"EFI PART",                           1),
    ("MBR Boot", 510,  b"\x55\xAA",                            1),
]

FILE_SIGS = [
    # (ext, magic_bytes, max_size_bytes)
    (".jpg",   b"\xFF\xD8\xFF",                              15 * 1024 * 1024),
    (".png",   b"\x89PNG\r\n\x1a\n",                        50 * 1024 * 1024),
    (".gif",   b"GIF8",                                       5 * 1024 * 1024),
    (".bmp",   b"BM",                                        50 * 1024 * 1024),
    (".pdf",   b"%PDF",                                      50 * 1024 * 1024),
    (".zip",   b"PK\x03\x04",                               500 * 1024 * 1024),
    (".docx",  b"PK\x03\x04",                               100 * 1024 * 1024),
    (".mp4",   b"\x00\x00\x00\x18ftyp",                    2000 * 1024 * 1024),
    (".mp3",   b"\xFF\xFB",                                  30 * 1024 * 1024),
    (".mp3id", b"ID3",                                       30 * 1024 * 1024),
    (".doc",   b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1",        50 * 1024 * 1024),
    (".sqlite", b"SQLite format 3\x00",                      500 * 1024 * 1024),
    (".7z",    b"7z\xBC\xAF'\x1C",                          500 * 1024 * 1024),
    (".rar",   b"Rar!\x1a\x07",                             500 * 1024 * 1024),
]


# ---------------------------------------------------------------------------
# Tool 4 — Partition Recovery Scanner
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 5 — File Recovery Scanner
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 6 — Quick File Undelete
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 7 — Partition Table Viewer
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Tool 8 — Migration Health Check
# ---------------------------------------------------------------------------
