#!/usr/bin/env python3
r"""
techdrive_modules/system_repair.py - System Repair category
=============================================================
Real Windows repair utilities: SFC, DISM, boot config, restore points,
component-store maintenance and crash-event triage. Long-running or
system-modifying actions (SFC scan, DISM restore health, component
cleanup, creating a restore point, fixing the boot sector) sit behind
an explicit button and a confirmation dialog rather than firing on
tab-open. Read-only diagnostics (crash history, boot config, restore
point list, health check) load automatically.

Everything here that touches system files or the boot configuration
needs Administrator on Windows; the panel says so up front instead of
failing halfway through.
"""

import ctypes
import os
import platform
import re
import subprocess
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def is_elevated():
    try:
        if IS_WINDOWS:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return False
    except Exception:
        return False


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities: sfc, DISM, bcdedit)."


def elevation_notice():
    return ("Not running elevated. This action needs Administrator rights.\n"
            "Close TechDrive, right-click it, choose 'Run as administrator', "
            "then try again.")


def _run(args, timeout=60):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                            creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip() or f"(no output, exit code {r.returncode})"
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Operation timed out."
    except Exception as e:
        return f"Error: {e}"


def _powershell(script, timeout=60):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


CATALOGUE = [('System Repair',
  '⚒',
  ['SFC Scan',
   'DISM Restore',
   'BSOD Analyzer',
   'Boot Repair',
   'System Restore',
   'File Checker',
   'Component Store',
   'Health Check'])]


# ---------------------------------------------------------------------------
# SFC Scan
# ---------------------------------------------------------------------------
def tool_system_repair_sfc_scan(self, frame):
    """SFC Scan — verifies and repairs protected system files (sfc /scannow)."""
    panel = CardPanel(frame, self.theme, "SFC Scan",
                       "System File Checker — scans and repairs protected Windows files.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def redraw(r):
        panel.clear()
        panel.report(r)

    if not IS_WINDOWS:
        redraw(windows_only_notice())
    elif not is_elevated():
        redraw(elevation_notice())
    else:
        redraw("Ready. This can take 5-15 minutes and must not be interrupted.")

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        self.after(0, lambda: redraw("Running sfc /scannow — this can take several minutes...\n"))
        return _run(["sfc", "/scannow"], timeout=1800)

    self._button_row(panel.body, [
        ("Run SFC Scan", lambda: self._confirm_then(
            "This runs 'sfc /scannow' to verify and repair protected system files. "
            "It can take several minutes and should not be interrupted. Continue?",
            lambda: self._run_bg(run, redraw))),
    ])


# ---------------------------------------------------------------------------
# DISM Restore
# ---------------------------------------------------------------------------
def tool_system_repair_dism_restore(self, frame):
    """DISM Restore — repairs the Windows component store (DISM /RestoreHealth)."""
    panel = CardPanel(frame, self.theme, "DISM Restore",
                       "Repairs the Windows image/component store using Windows Update as a source.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    if not IS_WINDOWS:
        redraw(windows_only_notice())
    elif not is_elevated():
        redraw(elevation_notice())
    else:
        redraw("Ready. This can take 10-20 minutes and needs an internet connection.")

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        self.after(0, lambda: redraw("Running DISM /RestoreHealth — this can take up to 20 minutes...\n"))
        return _run(["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"], timeout=2400)

    def check_health():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"], timeout=60)

    self._button_row(panel.body, [
        ("Run DISM Restore Health", lambda: self._confirm_then(
            "This runs 'DISM /Online /Cleanup-Image /RestoreHealth' to repair the Windows "
            "component store. It can take up to 20 minutes and needs internet access. Continue?",
            lambda: self._run_bg(run, redraw))),
        ("Check Health Only", lambda: self._run_bg(check_health, redraw)),
    ])


# ---------------------------------------------------------------------------
# BSOD Analyzer
# ---------------------------------------------------------------------------
def tool_system_repair_bsod_analyzer(self, frame):
    """BSOD Analyzer — lists recent crash / unexpected-shutdown events from the System event log."""
    panel = CardPanel(frame, self.theme, "BSOD Analyzer",
                       "Recent crash and unexpected-shutdown events from the Windows System log.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        script = (
            "Get-WinEvent -FilterHashtable @{LogName='System'; Id=1001,41,6008} "
            "-MaxEvents 15 -ErrorAction SilentlyContinue | "
            "Select-Object TimeCreated,Id,ProviderName,"
            "@{N='Message';E={($_.Message -replace \"`r`n\",' ').Substring(0,[Math]::Min(300,$_.Message.Length))}} "
            "| Format-List | Out-String -Width 200"
        )
        out = _powershell(script, timeout=30)
        if not out.strip():
            return ("No BugCheck (1001), Kernel-Power (41) or unexpected-shutdown (6008) events "
                     "found in the recent System log — good sign.")
        return out

    self._button_row(panel.body, [
        ("Refresh", lambda: self._run_bg(run, redraw)),
    ])

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Registry Cleaner
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# DLL Fixer
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Boot Repair
# ---------------------------------------------------------------------------
def tool_system_repair_boot_repair(self, frame):
    """Boot Repair — shows the current boot configuration and can rebuild the boot sector/BCD."""
    panel = CardPanel(frame, self.theme, "Boot Repair",
                       "Current boot configuration (bcdedit) with repair actions.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def show_bcd():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["bcdedit", "/enum"], timeout=20)

    def fixboot():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        return _run(["bootrec", "/fixboot"], timeout=60)

    def fixmbr():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        return _run(["bootrec", "/fixmbr"], timeout=60)

    def rebuildbcd():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        return _run(["bootrec", "/rebuildbcd"], timeout=60)

    self._button_row(panel.body, [
        ("Show Boot Config", lambda: self._run_bg(show_bcd, redraw)),
        ("Fix Boot Sector", lambda: self._confirm_then(
            "Runs 'bootrec /fixboot'. Rewrites the boot sector on the system partition. Continue?",
            lambda: self._run_bg(fixboot, redraw))),
        ("Fix MBR", lambda: self._confirm_then(
            "Runs 'bootrec /fixmbr'. Rewrites the master boot record. Continue?",
            lambda: self._run_bg(fixmbr, redraw))),
        ("Rebuild BCD", lambda: self._confirm_then(
            "Runs 'bootrec /rebuildbcd'. Rescans for Windows installations and rebuilds the "
            "boot configuration data. Continue?",
            lambda: self._run_bg(rebuildbcd, redraw))),
    ])
    self._run_bg(show_bcd, redraw)


# ---------------------------------------------------------------------------
# System Restore
# ---------------------------------------------------------------------------
def tool_system_repair_system_restore(self, frame):
    """System Restore — lists existing restore points and can create a new one."""
    panel = CardPanel(frame, self.theme, "System Restore",
                       "Existing restore points, with the option to create a new one.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def list_points():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-ComputerRestorePoint | Select-Object SequenceNumber,Description,"
            "CreationTime,RestorePointType | Format-Table -AutoSize | Out-String -Width 200",
            timeout=30)
        return out.strip() or "No restore points found (System Restore may be disabled for this drive)."

    def create_point():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        out = _powershell(
            'Checkpoint-Computer -Description "TechDrive manual checkpoint" '
            '-RestorePointType "MODIFY_SETTINGS"', timeout=180)
        return out.strip() or "Restore point created (Windows only allows one automatic checkpoint per 24h by default)."

    self._button_row(panel.body, [
        ("Refresh List", lambda: self._run_bg(list_points, redraw)),
        ("Create Restore Point Now", lambda: self._confirm_then(
            "Create a new System Restore checkpoint now? This can take a minute.",
            lambda: self._run_bg(create_point, redraw))),
    ])
    self._run_bg(list_points, redraw)


# ---------------------------------------------------------------------------
# File Checker
# ---------------------------------------------------------------------------
def tool_system_repair_file_checker(self, frame):
    """File Checker — read-only protected-file integrity check (sfc /verifyonly)."""
    panel = CardPanel(frame, self.theme, "File Checker",
                       "Read-only check of protected system files (sfc /verifyonly) — "
                        "reports corruption without repairing it.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["sfc", "/verifyonly"], timeout=900)

    self._button_row(panel.body, [
        ("Run Check", lambda: self._run_bg(run, redraw)),
    ])
    redraw("Click 'Run Check' to verify protected system files (read-only, no repairs made).")


# ---------------------------------------------------------------------------
# Component Store
# ---------------------------------------------------------------------------
def tool_system_repair_component_store(self, frame):
    """Component Store — analyzes and can clean up the WinSxS component store."""
    panel = CardPanel(frame, self.theme, "Component Store",
                       "Analyzes the WinSxS component store and can reclaim space from "
                        "superseded components.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def analyze():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["DISM", "/Online", "/Cleanup-Image", "/AnalyzeComponentStore"], timeout=180)

    def cleanup():
        if not IS_WINDOWS:
            return windows_only_notice()
        if not is_elevated():
            return elevation_notice()
        return _run(["DISM", "/Online", "/Cleanup-Image", "/StartComponentCleanup"], timeout=1200)

    self._button_row(panel.body, [
        ("Analyze Store", lambda: self._run_bg(analyze, redraw)),
        ("Clean Up Component Store", lambda: self._confirm_then(
            "Runs 'DISM /StartComponentCleanup'. Removes superseded Windows Update components "
            "to reclaim disk space. Cannot be undone (you won't be able to uninstall superseded "
            "updates afterwards). Continue?",
            lambda: self._run_bg(cleanup, redraw))),
    ])
    self._run_bg(analyze, redraw)


# ---------------------------------------------------------------------------
# Health Check
# ---------------------------------------------------------------------------
def tool_system_repair_health_check(self, frame):
    """Health Check — overall disk + system health summary (SMART status, uptime, component store)."""
    panel = CardPanel(frame, self.theme, "Health Check",
                       "Disk health (SMART) and overall system status in one view.")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        parts = []
        disk = _powershell(
            "Get-PhysicalDisk | Select-Object FriendlyName,MediaType,HealthStatus,"
            "OperationalStatus,Size | Format-Table -AutoSize | Out-String -Width 200", timeout=20)
        parts.append("=== Disk Health (SMART / HealthStatus) ===\n" + (disk.strip() or "No disk data found."))
        uptime = _powershell(
            "$u=(Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime; "
            "\"Days=$($u.Days) Hours=$($u.Hours) Minutes=$($u.Minutes)\"", timeout=15)
        parts.append("=== Uptime Since Last Boot ===\n" + (uptime.strip() or "Unavailable."))
        cs = _run(["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"], timeout=60)
        parts.append("=== Component Store Health ===\n" + cs)
        return "\n\n".join(parts)

    self._button_row(panel.body, [
        ("Refresh", lambda: self._run_bg(run, redraw)),
    ])

    self._run_bg(run, redraw)
