#!/usr/bin/env python3
r"""
techdrive_modules/batch_rename.py - Batch Rename category
======================================================================
Real, working batch-rename utilities. Every tool here does a genuine
os.rename() on real files/folders picked via the file dialog, after
showing a real dry-run preview and requiring confirmation. All 9
rename operations share one on-disk undo log
(~/.techdrive/rename_history.json) so "Undo" can genuinely reverse
the most recent batch, from whichever tool ran it.
"""

import json
import os
import platform
import re
import time
import tkinter as tk
from tkinter import ttk
from datetime import datetime
from gui.tool_view import CardPanel
from gui.tk_dialogs import filedialog

IS_WINDOWS = platform.system() == "Windows"
_HISTORY_PATH = os.path.join(os.path.expanduser("~"), ".techdrive", "rename_history.json")


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = [('Batch Rename',
  '✎',
  ['Rename Files', 'Rename Folders', 'Rename Extensions', 'Pattern Rename', 'Preview'])]

# ---------------------------------------------------------------------------
# Shared undo log
# ---------------------------------------------------------------------------

def _load_history():
    try:
        with open(_HISTORY_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return []


def _save_history(batches):
    os.makedirs(os.path.dirname(_HISTORY_PATH), exist_ok=True)
    with open(_HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(batches[-20:], f, indent=2)  # keep last 20 batches


def _push_batch(label, pairs):
    """pairs: list of (old_path, new_path) that were actually renamed."""
    if not pairs:
        return
    batches = _load_history()
    batches.append({
        "label": label,
        "time": datetime.now().isoformat(timespec="seconds"),
        "pairs": pairs,
    })
    _save_history(batches)


def _list_targets(folder, kind):
    """kind: 'files' or 'dirs'. Returns list of full paths, top-level only."""
    try:
        entries = os.scandir(folder)
    except OSError:
        return []
    out = []
    for e in entries:
        try:
            if kind == "files" and e.is_file(follow_symlinks=False):
                out.append(e.path)
            elif kind == "dirs" and e.is_dir(follow_symlinks=False):
                out.append(e.path)
        except OSError:
            continue
    return sorted(out)


def _apply_renames(pairs):
    """pairs: list of (old_path, new_path). Actually renames on disk.
    Returns (done_pairs, errors)."""
    done = []
    errors = []
    for old, new in pairs:
        if old == new:
            continue
        if os.path.exists(new):
            errors.append(f"Skipped '{os.path.basename(old)}': target '{os.path.basename(new)}' already exists.")
            continue
        try:
            os.rename(old, new)
            done.append((old, new))
        except OSError as e:
            errors.append(f"Failed '{os.path.basename(old)}': {e}")
    return done, errors


def _format_preview(pairs, limit=40):
    lines = []
    for old, new in pairs[:limit]:
        if old == new:
            continue
        lines.append(f"  {os.path.basename(old)}  ->  {os.path.basename(new)}")
    if len(pairs) > limit:
        lines.append(f"  ... and {len(pairs) - limit} more")
    return "\n".join(lines) if lines else "(no changes - names already match the rule)"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def tool_batch_rename_rename_files(self, frame):
    """Rename Files — real find/replace on filenames (not extension) for
    every file in a chosen folder."""
    panel = CardPanel(frame, self.theme, "Rename Files",
                       "Find-and-replace text in the names of every file in a folder (keeps "
                       "the extension untouched).")
    find_var = self._entry_row(panel.body, "Find:", "")
    replace_var = self._entry_row(panel.body, "Replace with:", "")
    state = {"folder": None}

    def redraw(r):
        panel.clear()
        panel.report(r)

    def choose():
        folder = filedialog.askdirectory(title="Choose folder")
        if folder:
            state["folder"] = folder
            redraw(f"Selected: {folder}")

    def _pairs():
        folder = state["folder"]
        if not folder:
            return None
        find = find_var.get()
        repl = replace_var.get()
        pairs = []
        for path in _list_targets(folder, "files"):
            name, ext = os.path.splitext(os.path.basename(path))
            new_name = name.replace(find, repl) + ext if find else name + ext
            pairs.append((path, os.path.join(folder, new_name)))
        return pairs

    def preview():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        redraw("Preview:\n" + _format_preview(pairs))

    def go():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        def run():
            done, errors = _apply_renames(pairs)
            _push_batch("Rename Files", done)
            return f"Renamed {len(done)} file(s).\n" + ("\n".join(errors) if errors else "")
        self._confirm_then(
            f"Rename files in:\n{state['folder']}\nreplacing '{find_var.get()}' with "
            f"'{replace_var.get()}'?",
            lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [
        ("Choose Folder", choose),
        ("Preview", preview),
        ("Rename", go),
    ])


def tool_batch_rename_rename_folders(self, frame):
    """Rename Folders — real find/replace on subfolder names within a
    chosen parent folder."""
    panel = CardPanel(frame, self.theme, "Rename Folders",
                       "Find-and-replace text in the names of every subfolder inside a chosen "
                       "parent folder.")
    find_var = self._entry_row(panel.body, "Find:", "")
    replace_var = self._entry_row(panel.body, "Replace with:", "")
    state = {"folder": None}

    def redraw(r):
        panel.clear()
        panel.report(r)

    def choose():
        folder = filedialog.askdirectory(title="Choose parent folder")
        if folder:
            state["folder"] = folder
            redraw(f"Selected: {folder}")

    def _pairs():
        folder = state["folder"]
        if not folder:
            return None
        find = find_var.get()
        repl = replace_var.get()
        pairs = []
        for path in _list_targets(folder, "dirs"):
            name = os.path.basename(path)
            new_name = name.replace(find, repl) if find else name
            pairs.append((path, os.path.join(folder, new_name)))
        return pairs

    def preview():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        redraw("Preview:\n" + _format_preview(pairs))

    def go():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        def run():
            done, errors = _apply_renames(pairs)
            _push_batch("Rename Folders", done)
            return f"Renamed {len(done)} folder(s).\n" + ("\n".join(errors) if errors else "")
        self._confirm_then(
            f"Rename subfolders in:\n{state['folder']}\nreplacing '{find_var.get()}' with "
            f"'{replace_var.get()}'?",
            lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [
        ("Choose Folder", choose),
        ("Preview", preview),
        ("Rename", go),
    ])


def tool_batch_rename_rename_extensions(self, frame):
    """Rename Extensions — real extension swap for matching files in a
    chosen folder (e.g. .jpeg -> .jpg)."""
    panel = CardPanel(frame, self.theme, "Rename Extensions",
                       "Changes the file extension for every file in a folder matching an old "
                       "extension.")
    old_ext_var = self._entry_row(panel.body, "Old extension (e.g. jpeg):", "jpeg")
    new_ext_var = self._entry_row(panel.body, "New extension (e.g. jpg):", "jpg")
    state = {"folder": None}

    def redraw(r):
        panel.clear()
        panel.report(r)

    def choose():
        folder = filedialog.askdirectory(title="Choose folder")
        if folder:
            state["folder"] = folder
            redraw(f"Selected: {folder}")

    def _pairs():
        folder = state["folder"]
        if not folder:
            return None
        old_ext = "." + old_ext_var.get().strip().lstrip(".")
        new_ext = "." + new_ext_var.get().strip().lstrip(".")
        pairs = []
        for path in _list_targets(folder, "files"):
            name, ext = os.path.splitext(os.path.basename(path))
            if ext.lower() == old_ext.lower():
                pairs.append((path, os.path.join(folder, name + new_ext)))
        return pairs

    def preview():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        redraw(f"{len(pairs)} matching file(s):\n" + _format_preview(pairs))

    def go():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        def run():
            done, errors = _apply_renames(pairs)
            _push_batch("Rename Extensions", done)
            return f"Changed extension on {len(done)} file(s).\n" + ("\n".join(errors) if errors else "")
        self._confirm_then(
            f"Change extension .{old_ext_var.get().strip().lstrip('.')} to "
            f".{new_ext_var.get().strip().lstrip('.')} for matching files in:\n{state['folder']}?",
            lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [
        ("Choose Folder", choose),
        ("Preview", preview),
        ("Rename", go),
    ])


def tool_batch_rename_pattern_rename(self, frame):
    """Pattern Rename — real template-based rename using tokens {name},
    {ext}, {n}, {date}."""
    panel = CardPanel(frame, self.theme, "Pattern Rename",
                       "Renames every file in a folder using a template. Tokens: {name} "
                        "(original name), {ext} (extension without dot), {n} (sequence number), "
                        "{date} (file's modified date, YYYY-MM-DD).")

    def redraw(r):
        panel.clear()
        panel.report(r)
    pattern_var = self._entry_row(panel.body, "Pattern:", "{name}_{n}")
    start_var = self._entry_row(panel.body, "Start number:", "1")
    state = {"folder": None}

    def choose():
        folder = filedialog.askdirectory(title="Choose folder")
        if folder:
            state["folder"] = folder
            redraw(f"Selected: {folder}")

    def _pairs():
        folder = state["folder"]
        if not folder:
            return None
        pattern = pattern_var.get() or "{name}_{n}"
        try:
            start = int(start_var.get().strip())
        except ValueError:
            start = 1
        pairs = []
        for i, path in enumerate(_list_targets(folder, "files")):
            name, ext = os.path.splitext(os.path.basename(path))
            mdate = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d")
            new_name = pattern.format(name=name, ext=ext.lstrip("."), n=start + i, date=mdate)
            if not os.path.splitext(new_name)[1] and ext:
                new_name += ext
            pairs.append((path, os.path.join(folder, new_name)))
        return pairs

    def preview():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        redraw("Preview:\n" + _format_preview(pairs))

    def go():
        pairs = _pairs()
        if pairs is None:
            redraw("Choose a folder first.")
            return
        def run():
            done, errors = _apply_renames(pairs)
            _push_batch("Pattern Rename", done)
            return f"Renamed {len(done)} file(s).\n" + ("\n".join(errors) if errors else "")
        self._confirm_then(f"Apply pattern '{pattern_var.get()}' to files in:\n{state['folder']}?",
                           lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [
        ("Choose Folder", choose),
        ("Preview", preview),
        ("Rename", go),
    ])








def tool_batch_rename_preview(self, frame):
    """Preview - real dry-run of a find/replace rule against a chosen
    folder's real filenames, with no changes made to disk.

    The layout fills the whole tool tab: larger input fields and a tall,
    scrollable results area that grows with the window instead of a small
    fixed card."""
    from gui.tool_view import FONT_CARD_TITLE, FONT_UI
    from gui.tool_view import FONT_MONO as _MONO
    th = self.theme
    bg = th["BG"]

    wrap = tk.Frame(frame, bg=bg)
    wrap.pack(fill="both", expand=True, padx=20, pady=(12, 20))

    from gui import fluent as _fl
    header = tk.Frame(wrap, bg=bg)
    header.pack(fill="x")
    tk.Label(header, text="Preview", bg=bg, fg=th["FG"],
             font=_fl.font(22, "bold", display=True)).pack(side="left")
    # Same close behaviour as every other tool panel: closes this tool's
    # notebook tab. CardPanel's helper only needs `parent` to walk up to it.
    from types import SimpleNamespace
    from gui.tool_view import CardPanel
    close_fn = CardPanel._make_default_close(SimpleNamespace(parent=frame))
    if close_fn is not None:
        from gui.widgets import FluentButton
        FluentButton(header, "Close", command=close_fn, theme=th, aero=False,
                     kind="subtle", width=96, height=32,
                     backdrop=bg).pack(side="right")
    tk.Label(wrap,
             text=("Dry-run: shows exactly what a find/replace rule would do to a "
                   "folder's real filenames, without changing anything on disk."),
             bg=bg, fg=th["MUTED"], font=FONT_UI,
             wraplength=980, justify="left").pack(anchor="w", pady=(2, 12))

    form = tk.Frame(wrap, bg=bg)
    form.pack(fill="x")

    def entry_row(label, default=""):
        row = tk.Frame(form, bg=bg)
        row.pack(fill="x", pady=4)
        tk.Label(row, text=label, width=16, anchor="w", bg=bg,
                 fg=th["FG"], font=FONT_UI).pack(side="left")
        var = tk.StringVar(value=default)
        tk.Entry(row, textvariable=var, bg=th["CARD_BG"], fg=th["FG"],
                 insertbackground=th["FG"], relief="flat",
                 font=("Consolas", 12)).pack(side="left", fill="x",
                                             expand=True, ipady=6)
        return var

    find_var = entry_row("Find:")
    replace_var = entry_row("Replace with:")

    out_holder = {}

    def redraw(text):
        box = out_holder["box"]
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", text)
        box.configure(state="disabled")

    def go():
        folder = filedialog.askdirectory(title="Choose folder to preview")
        if not folder:
            return
        find = find_var.get()
        repl = replace_var.get()
        pairs = []
        for path in _list_targets(folder, "files"):
            name, ext = os.path.splitext(os.path.basename(path))
            new_name = (name.replace(find, repl) if find else name) + ext
            pairs.append((path, os.path.join(folder, new_name)))
        redraw(f"{folder}\n\n" + _format_preview(pairs))

    btn_row = tk.Frame(wrap, bg=bg)
    btn_row.pack(fill="x", pady=(10, 0))
    self._button_row(btn_row, [("Choose Folder & Preview", go)])

    out_frame = tk.Frame(wrap, bg=th["CARD_BORDER"])
    out_frame.pack(fill="both", expand=True, pady=(12, 0))
    box = tk.Text(out_frame, bg=th["CARD_BG"], fg=th["FG"],
                  insertbackground=th["FG"], font=("Consolas", 11),
                  wrap="none", relief="flat", bd=0, highlightthickness=0,
                  height=22, padx=14, pady=12)
    yscroll = ttk.Scrollbar(out_frame, orient="vertical", command=box.yview)
    xscroll = ttk.Scrollbar(out_frame, orient="horizontal", command=box.xview)
    box.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
    yscroll.pack(side="right", fill="y")
    xscroll.pack(side="bottom", fill="x")
    box.pack(side="left", fill="both", expand=True)
    out_holder["box"] = box
    redraw("Choose a folder to see what the rule would rename.")
