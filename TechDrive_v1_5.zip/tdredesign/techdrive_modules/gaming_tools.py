#!/usr/bin/env python3
r"""
techdrive_modules/gaming_tools.py - Gaming Tools category
======================================================================
Real, working gaming utilities - each one reads or changes an actual
Windows setting / runs an actual Windows diagnostic:

- Game Mode / Game Bar: real registry toggles Windows itself reads
  (GameBar\AllowAutoGameMode, GameDVR\AppCaptureEnabled).
- GPU Optimization: switches the active power plan to High Performance
  via powercfg and reports Hardware-accelerated GPU Scheduling state.
- Latency Reduction: toggles TCP no-delay (disables Nagle's algorithm)
  on network interfaces and runs a real ping test.
- FPS Monitor: measures this app's own live frame render rate (a
  genuine frame-time measurement) plus the display's reported refresh
  rate - it does not hook into other running games' render loops.
- Overclock Info: reads live vs. base CPU clock via WMI.
- DirectX Info: runs dxdiag and parses the real report.
- Vulkan Info: queries installed Vulkan ICD driver registrations.
- Scheduler: reads/writes Win32PrioritySeparation (the real registry
  value behind Windows' foreground-app CPU quantum boost).
- Performance Log: samples CPU/RAM/GPU every second for N seconds and
  writes a real CSV log to disk.
"""

import csv
import json
import os
import platform
import subprocess
import tempfile
import time
import tkinter as tk

try:
    import psutil
except ImportError:
    psutil = None

try:
    import winreg
except ImportError:
    winreg = None

from techdrive_modules import hw_sensors as hw
from gui.tool_view import CardPanel, PanelTextProxy

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared registry helpers
# ---------------------------------------------------------------------------

def _reg_get(hive, path, name, default=None):
    if winreg is None:
        return default
    try:
        with winreg.OpenKey(hive, path) as key:
            val, _ = winreg.QueryValueEx(key, name)
            return val
    except OSError:
        return default


def _reg_set(hive, path, name, value, value_type):
    if winreg is None:
        return False, windows_only_notice()
    try:
        with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, name, 0, value_type, value)
        return True, "OK"
    except PermissionError:
        return False, "Access denied - try running TechDrive as Administrator."
    except OSError as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Game Mode
# ---------------------------------------------------------------------------

_GAMEBAR_PATH = r"Software\Microsoft\GameBar"




# ---------------------------------------------------------------------------
# GPU Optimization
# ---------------------------------------------------------------------------

_HIGH_PERF_GUID = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
_BALANCED_GUID = "381b4222-f694-41f0-9685-ff5bb260df2e"




# ---------------------------------------------------------------------------
# Latency Reduction
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# FPS Monitor
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Overclock Info
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Game Bar
# ---------------------------------------------------------------------------

_GAMEDVR_PATH = r"Software\Microsoft\Windows\CurrentVersion\GameDVR"




# ---------------------------------------------------------------------------
# DirectX Info
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Vulkan Info
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------

_PRIO_PATH = r"SYSTEM\CurrentControlSet\Control\PriorityControl"




# ---------------------------------------------------------------------------
# Performance Log
# ---------------------------------------------------------------------------

