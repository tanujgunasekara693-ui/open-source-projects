#!/usr/bin/env python3
"""
Module: file_search
Generated for TechDrive 500
Category: File Search

Real, working search tools. Each tool asks (via dialogs) for a root
folder plus whatever criteria it needs, walks the tree with os.walk,
and reports real matches — no placeholder "customize as needed" text.
"""

import os
import re
import time
import hashlib
import fnmatch
import platform
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"

MAX_RESULTS = 500       # cap listed results so the output box stays usable
MAX_SCAN_SECONDS = 60    # soft time cap for a single search


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('File Search',
  '⌕',
  ['Advanced Search',
   'Search by Name',
   'Search by Type',
   'Search by Date',
   'Search by Size',
   'Search Content',
   'Search Hash'])]


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------

def _pick_folder(title="Choose a folder to search"):
    return filedialog.askdirectory(title=title)


def _walk_capped(root):
    """Yield (full_path, filename, dir_entry) for every file under root,
    bailing out after MAX_SCAN_SECONDS so a huge tree can't hang the UI."""
    start = time.time()
    for dirpath, dirnames, filenames in os.walk(root):
        if time.time() - start > MAX_SCAN_SECONDS:
            yield None, None, "TIMEOUT"
            return
        for fn in filenames:
            yield os.path.join(dirpath, fn), fn, None


def _format_hits(hits, header):
    lines = [header, ""]
    if not hits:
        lines.append("No matches found.")
        return "\n".join(lines)
    truncated = len(hits) > MAX_RESULTS
    for h in hits[:MAX_RESULTS]:
        lines.append(h)
    lines.append("")
    lines.append(f"{min(len(hits), MAX_RESULTS)} of {len(hits)} match(es) shown."
                  + (" (truncated — narrow your search for a full list)" if truncated else ""))
    return "\n".join(lines)


def _stat_line(full):
    try:
        st = os.stat(full)
        return full, st
    except OSError:
        return full, None


# ---------------------------------------------------------------------------
# Advanced Search — combine name pattern + extension + min size + content
# ---------------------------------------------------------------------------

def tool_file_search_advanced_search(self, frame):
    """Advanced Search — File Search"""
    panel = CardPanel(frame, self.theme, "Advanced Search",
                       "Combine a name pattern, extension and minimum size in one pass",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        pattern = simpledialog.askstring("Advanced Search", "Name pattern (wildcards * ? allowed, blank = any):") or "*"
        ext = simpledialog.askstring("Advanced Search", "Extension filter, e.g. .txt (blank = any):") or ""
        min_size_s = simpledialog.askstring("Advanced Search", "Minimum size in KB (blank = 0):") or "0"
        try:
            min_size = int(float(min_size_s)) * 1024
        except ValueError:
            min_size = 0

        hits = []
        scanned = 0
        timed_out = False
        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            scanned += 1
            if not fnmatch.fnmatch(fn.lower(), pattern.lower()):
                continue
            if ext and not fn.lower().endswith(ext.lower()):
                continue
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            if size < min_size:
                continue
            hits.append(f"{full}  ({bytes_fmt(size)})")

        header = f"Searched {scanned} files under {folder}\nPattern='{pattern}' ext='{ext or 'any'}' min>={bytes_fmt(min_size)}"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — tree is very large, results are partial)"
        return _format_hits(hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search by Name — substring or wildcard match on filename
# ---------------------------------------------------------------------------

def tool_file_search_search_by_name(self, frame):
    """Search by Name — File Search"""
    panel = CardPanel(frame, self.theme, "Search by Name",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        query = simpledialog.askstring("Search by Name", "Filename contains (or use * ? wildcards):")
        if not query:
            return "Cancelled — no query entered."
        has_wildcard = "*" in query or "?" in query
        q_lower = query.lower()

        hits = []
        scanned = 0
        timed_out = False
        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            scanned += 1
            fn_l = fn.lower()
            matched = fnmatch.fnmatch(fn_l, q_lower) if has_wildcard else q_lower in fn_l
            if matched:
                try:
                    size = os.path.getsize(full)
                    hits.append(f"{full}  ({bytes_fmt(size)})")
                except OSError:
                    hits.append(full)

        header = f"Searched {scanned} files under {folder} for name matching '{query}'"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
        return _format_hits(hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search by Type — group results by extension, or filter to one
# ---------------------------------------------------------------------------

def tool_file_search_search_by_type(self, frame):
    """Search by Type — File Search"""
    panel = CardPanel(frame, self.theme, "Search by Type",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        query = simpledialog.askstring(
            "Search by Type",
            "File type keyword (image, document, audio, video, archive, or a raw extension like .py). Blank = summarize all types:"
        ) or ""

        groups = {
            "image": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp", ".heic", ".svg"},
            "document": {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".odt", ".csv", ".md"},
            "audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"},
            "video": {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".m4v"},
            "archive": {".zip", ".rar", ".7z", ".tar", ".gz", ".iso"},
        }

        wanted_exts = None
        q = query.strip().lower()
        if q in groups:
            wanted_exts = groups[q]
        elif q.startswith("."):
            wanted_exts = {q}
        elif q:
            wanted_exts = {"." + q}

        counts = {}
        hits = []
        scanned = 0
        timed_out = False
        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            scanned += 1
            ext = os.path.splitext(fn)[1].lower()
            counts[ext or "(no ext)"] = counts.get(ext or "(no ext)", 0) + 1
            if wanted_exts is not None and ext in wanted_exts:
                hits.append(full)

        if wanted_exts is not None:
            header = f"Searched {scanned} files under {folder} for type '{query}'"
            if timed_out:
                header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
            return _format_hits(hits, header)

        lines = [f"Scanned {scanned} files under {folder}. Extension breakdown:", ""]
        for ext, n in sorted(counts.items(), key=lambda kv: -kv[1])[:40]:
            lines.append(f"  {ext:<12} {n}")
        if timed_out:
            lines.append(f"\n(stopped after {MAX_SCAN_SECONDS}s — counts are partial)")
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search by Date — modified within the last N days, or between two dates
# ---------------------------------------------------------------------------

def tool_file_search_search_by_date(self, frame):
    """Search by Date — File Search"""
    panel = CardPanel(frame, self.theme, "Search by Date",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        days_s = simpledialog.askstring("Search by Date", "Modified within the last N days (e.g. 7):")
        if not days_s:
            return "Cancelled — no value entered."
        try:
            days = float(days_s)
        except ValueError:
            return f"Not a number: '{days_s}'"
        cutoff = time.time() - days * 86400

        hits = []
        scanned = 0
        timed_out = False
        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            scanned += 1
            try:
                mtime = os.path.getmtime(full)
            except OSError:
                continue
            if mtime >= cutoff:
                ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
                hits.append(f"{ts}  {full}")

        hits.sort(reverse=True)
        header = f"Searched {scanned} files under {folder}, modified within last {days:g} day(s)"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
        return _format_hits(hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search by Size — files at or above / at or below a threshold
# ---------------------------------------------------------------------------

def tool_file_search_search_by_size(self, frame):
    """Search by Size — File Search"""
    panel = CardPanel(frame, self.theme, "Search by Size",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        min_s = simpledialog.askstring("Search by Size", "Minimum size in MB (blank = 0):") or "0"
        max_s = simpledialog.askstring("Search by Size", "Maximum size in MB (blank = no limit):") or ""
        try:
            min_bytes = float(min_s) * 1024 * 1024
        except ValueError:
            min_bytes = 0
        try:
            max_bytes = float(max_s) * 1024 * 1024 if max_s else None
        except ValueError:
            max_bytes = None

        hits = []
        scanned = 0
        timed_out = False
        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            scanned += 1
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            if size < min_bytes:
                continue
            if max_bytes is not None and size > max_bytes:
                continue
            hits.append((size, full))

        hits.sort(reverse=True)
        lines_hits = [f"{bytes_fmt(size):>10}  {full}" for size, full in hits]
        header = f"Searched {scanned} files under {folder}, size between {bytes_fmt(min_bytes)} and {bytes_fmt(max_bytes) if max_bytes else '∞'}"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
        return _format_hits(lines_hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search Content — grep-like text search inside files (text files only)
# ---------------------------------------------------------------------------

TEXT_LIKE_EXT = {".txt", ".md", ".log", ".csv", ".json", ".xml", ".html", ".htm", ".ini",
                  ".cfg", ".py", ".js", ".ts", ".css", ".c", ".cpp", ".h", ".java", ".yaml", ".yml"}


def tool_file_search_search_content(self, frame):
    """Search Content — File Search"""
    panel = CardPanel(frame, self.theme, "Search Content",
                       "Text search inside files (skips binaries)",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        query = simpledialog.askstring("Search Content", "Text to search for inside files:")
        if not query:
            return "Cancelled — no query entered."
        ext_filter = simpledialog.askstring(
            "Search Content", "Limit to extension (e.g. .txt), blank = common text file types:") or ""

        q_lower = query.lower()
        hits = []
        scanned = 0
        matched_files = 0
        timed_out = False
        MAX_FILE_BYTES = 5 * 1024 * 1024  # skip files bigger than 5MB

        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            ext = os.path.splitext(fn)[1].lower()
            if ext_filter:
                if ext != ext_filter.lower():
                    continue
            elif ext not in TEXT_LIKE_EXT:
                continue
            try:
                if os.path.getsize(full) > MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            scanned += 1
            try:
                with open(full, "r", encoding="utf-8", errors="ignore") as f:
                    for lineno, line in enumerate(f, 1):
                        if q_lower in line.lower():
                            hits.append(f"{full}:{lineno}: {line.strip()[:120]}")
                            matched_files += 1
                            break
            except (OSError, PermissionError):
                continue
            if len(hits) >= MAX_RESULTS:
                break

        header = f"Searched {scanned} candidate files under {folder} for '{query}' ({matched_files} matched)"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
        return _format_hits(hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Search Extension — every file with a given extension
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Search Location — find matching folders by name (not files)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Search Attributes — read-only / hidden / system flag search
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Search Hash — find the file(s) matching a given SHA-256 hash
# ---------------------------------------------------------------------------

def _sha256_of(path, chunk=1024 * 1024):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                block = f.read(chunk)
                if not block:
                    break
                h.update(block)
        return h.hexdigest()
    except (OSError, PermissionError):
        return None


def tool_file_search_search_hash(self, frame):
    """Search Hash — File Search"""
    panel = CardPanel(frame, self.theme, "Search Hash",
                       "Find files whose SHA-256 matches a given hash",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        folder = _pick_folder()
        if not folder:
            return "Cancelled."
        target = simpledialog.askstring(
            "Search Hash", "SHA-256 hash to match (leave blank to instead hash one file and show it):")

        if not target:
            single = filedialog.askopenfilename(title="Choose a file to hash")
            if not single:
                return "Cancelled."
            digest = _sha256_of(single)
            if digest is None:
                return f"Could not read {single}."
            return f"SHA-256 of {single}:\n{digest}"

        target = target.strip().lower()
        hits = []
        scanned = 0
        timed_out = False
        MAX_FILE_BYTES = 200 * 1024 * 1024  # skip anything absurdly large

        for full, fn, flag in _walk_capped(folder):
            if flag == "TIMEOUT":
                timed_out = True
                break
            try:
                if os.path.getsize(full) > MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            scanned += 1
            digest = _sha256_of(full)
            if digest and digest == target:
                hits.append(full)

        header = f"Hashed {scanned} files under {folder} looking for {target}"
        if timed_out:
            header += f"\n(stopped after {MAX_SCAN_SECONDS}s — results are partial)"
        return _format_hits(hits, header)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)
