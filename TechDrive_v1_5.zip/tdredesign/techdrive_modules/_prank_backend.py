"""Ported from Prank Tester (prank_tester.py) — backend logic only.

This is a defensive/analysis tool: it statically scans scripts for known
prank/DoS/malware behavior patterns (fork bombs, zip bombs, keyboard/
network/disk/print flood patterns, LOLBin abuse, etc.) and, optionally,
actually runs a selected file in a monitored way \u2014 watching process
count, CPU/memory, network connections, and registry/startup changes \u2014
to catch behavior that only shows up at runtime. It contains no exploit
code; the "attacks" it knows about are regex signatures used purely for
detection and scoring, and running the file under test is the tool's
whole point (same idea as any lightweight malware/prank sandbox).

Like the IDE port, the original GUI (class PrankTesterGUI, further down
in prank_tester.py) is built on PySimpleGUI/FreeSimpleGUI and wasn't
reusable for TechDrive's Tkinter UI regardless of licensing \u2014 so only
the backend (PrankTesterBackend and free-standing helper functions) was
ported, unchanged in logic. TechDrive's own tkinter panels replace the
original window. See PRANK_TESTER_PORT_README.md for the full breakdown,
including what was intentionally left out (50-language i18n, the ML
weight auto-tuning UI, Windows Sandbox launch button \u2014 the backend
functions for these are still here, just not wired into a UI, except
weight loading which the scorer always uses).

Bare `except:` clauses from the original were narrowed to
`except Exception:` for cleanliness; no behavior changes otherwise.
"""

#!/usr/bin/env python3
"""
Prank Tester GUI v1.0 – Ultimate Edition
Fixes: Signature update URL configurable, Cleanup actually removes persistence, 50 languages.
"""

import subprocess, psutil, zipfile, time, sys, json, threading, hashlib, re, os, shutil
import logging
import queue, platform, webbrowser, tempfile, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional

logger = logging.getLogger("TechDrive.PrankTester")

try:
    import winreg
except ImportError:
    winreg = None

try: import rarfile; HAS_RARFILE = True
except Exception as e: HAS_RARFILE = False; logger.debug("rarfile unavailable: %s", e)
try: import py7zr; HAS_PY7ZR = True
except Exception as e: HAS_PY7ZR = False; logger.debug("py7zr unavailable: %s", e)
try: import pycdlib; HAS_PYCDLIB = True
except Exception as e: HAS_PYCDLIB = False; logger.debug("pycdlib unavailable: %s", e)
try: import requests; HAS_REQUESTS = True
except Exception as e: HAS_REQUESTS = False; logger.debug("requests unavailable: %s", e)
try:
    from fpdf import FPDF
    from fpdf.enums import XPos, YPos
    HAS_FPDF = True
except Exception as e: HAS_FPDF = False; logger.debug("fpdf unavailable: %s", e)


# ----------------------------------------------------------------- Constants
DEFAULT_FORK_BOMB_THRESHOLD = 30
ZIP_BOMB_RATIO_THRESHOLD = 100
DEFAULT_EXECUTION_TIMEOUT = 30
MEMORY_WARNING_THRESHOLD = 500
PRANK_DATA_DIR = Path(os.path.expanduser("~")) / ".techdrive_prank_tester"
PRANK_DATA_DIR.mkdir(parents=True, exist_ok=True)
HISTORY_FILE = str(PRANK_DATA_DIR / "test_history.json")
MAX_NET_CONN_BURST = 20
DEFAULT_SIGNATURE_UPDATE_URL = ""   # Added: default empty URL

LOLBIN_DATABASE = {
    'mshta.exe':(25,'MSHTA – fileless execution'),'regsvr32.exe':(25,'Regsvr32 – remote scripts'),
    'rundll32.exe':(20,'Rundll32 – DLL execution'),'certutil.exe':(25,'Certutil – download/decode'),
    'bitsadmin.exe':(25,'Bitsadmin – download'),'wmic.exe':(20,'WMIC – process creation'),
    'msiexec.exe':(20,'Msiexec – silent install'),'cscript.exe':(20,'CScript – VBS/JS host'),
    'wscript.exe':(20,'WScript – VBS/JS host'),'powershell.exe':(15,'PowerShell'),'cmd.exe':(10,'Command Prompt'),
    'schtasks.exe':(25,'Schtasks – scheduled tasks'),'reg.exe':(25,'Reg – registry'),'diskpart.exe':(30,'Diskpart'),
    'format.com':(30,'Format'),'bcdedit.exe':(30,'Bcdedit'),'icacls.exe':(20,'Icacls'),'takeown.exe':(20,'Takeown'),
    'net.exe':(20,'Net'),'net1.exe':(20,'Net1'),'sc.exe':(25,'SC – service control'),'vssadmin.exe':(25,'Vssadmin'),
    'msbuild.exe':(25,'MSBuild'),'csc.exe':(25,'C# compiler'),'cmstp.exe':(25,'CMSTP'),'appvlp.exe':(25,'AppVLP'),
    'regedit.exe':(20,'Regedit'),'taskkill.exe':(15,'Taskkill'),'shutdown.exe':(25,'Shutdown'),
    'logoff.exe':(20,'Logoff'),'tskill.exe':(15,'Tskill'),'pskill.exe':(15,'PSKill'),
    'psshutdown.exe':(25,'PsShutdown'),'cacls.exe':(20,'Cacls'),'subst.exe':(20,'Subst'),'fsutil.exe':(25,'Fsutil')
}

SIGNATURES_FILE = PRANK_DATA_DIR / "signatures.json"

def load_signatures():
    if SIGNATURES_FILE.exists():
        try: return json.load(open(SIGNATURES_FILE))
        except Exception as e: logger.debug("prank operation failed: %s", e); pass
    return {"bad_hashes":[],"bad_patterns":[]}

def save_signatures(data): json.dump(data, open(SIGNATURES_FILE,"w"), indent=2)

def download_updated_signatures(url):
    """Download signatures from given URL. Returns True on success."""
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            save_signatures(data)
            return True
    except Exception:
        return False

# ----------------------------------------------------------------- ML Weight Adjustment
WEIGHTS_FILE = PRANK_DATA_DIR / "weights.json"
DEFAULT_CATEGORY_WEIGHTS = {
    "archive_bomb":1.0,"vbs_dos":1.0,"batch_dos":1.0,"powershell_dos":1.0,
    "hta_dos":1.0,"network_flood":1.0,"diskfill":1.0,"printbomb":1.0,"keyboard_flood":1.0,
    "iso_threats":1.0,"behavioural":1.0,"fileless_persistence":1.0,"fork_bomb":1.0
}
LEARNING_RATE = 0.05

def load_weights():
    if WEIGHTS_FILE.exists():
        try:
            d = json.load(open(WEIGHTS_FILE))
            for k in DEFAULT_CATEGORY_WEIGHTS:
                if k not in d: d[k] = DEFAULT_CATEGORY_WEIGHTS[k]
            return d
        except Exception as e: logger.debug("prank operation failed: %s", e); pass
    return DEFAULT_CATEGORY_WEIGHTS.copy()

def save_weights(w): json.dump(w, open(WEIGHTS_FILE,"w"), indent=2)

def adjust_weights(original_score, verdict, feedback_correct):
    weights = load_weights()
    if not feedback_correct:
        factor = 1.0 - LEARNING_RATE if verdict in ("DANGEROUS","SUSPICIOUS") else 1.0 + LEARNING_RATE
        for k in weights: weights[k] = max(0.1, min(2.0, weights[k] * factor))
        save_weights(weights)

# ----------------------------------------------------------------- Sandbox Helpers
SANDBOX_TEMP = Path(tempfile.gettempdir()) / "prank_tester_sandbox"
def is_windows_sandbox_available():
    try:
        r = subprocess.run(['powershell','-Command','Get-WindowsOptionalFeature -Online -FeatureName "Containers-DisposableClientVM"'],
                           capture_output=True, text=True, timeout=5)
        return "Enabled" in r.stdout
    except Exception as e: logger.debug("prank scan operation failed: %s", e); return False

def launch_in_sandbox(exe_path, timeout):
    SANDBOX_TEMP.mkdir(parents=True,exist_ok=True)
    dest = SANDBOX_TEMP / Path(exe_path).name
    shutil.copy2(exe_path,dest)
    wsb = f"""<Configuration>
  <VGpu>Default</VGpu>
  <Networking>Default</Networking>
  <MappedFolders>
    <MappedFolder>
      <HostFolder>{SANDBOX_TEMP}</HostFolder>
      <SandboxFolder>C:\\Users\\WDAGUtilityAccount\\Desktop\\prank</SandboxFolder>
      <ReadOnly>false</ReadOnly>
    </MappedFolder>
  </MappedFolders>
  <LogonCommand>
    <Command>start C:\\Users\\WDAGUtilityAccount\\Desktop\\prank\\{dest.name}</Command>
  </LogonCommand>
</Configuration>"""
    (SANDBOX_TEMP/"prank.wsb").write_text(wsb)
    os.startfile(str(SANDBOX_TEMP/"prank.wsb"))

# ----------------------------------------------------------------- Deep Archive Recursion
def deep_scan_archive(archive_path, backend):
    findings = []
    tmp = tempfile.mkdtemp(prefix="prank_deep_")
    try:
        if archive_path.suffix.lower()=='.zip': zipfile.ZipFile(archive_path).extractall(tmp)
        elif archive_path.suffix.lower()=='.rar' and HAS_RARFILE: rarfile.RarFile(archive_path).extractall(tmp)
        elif archive_path.suffix.lower()=='.7z' and HAS_PY7ZR: py7zr.SevenZipFile(archive_path).extractall(tmp)
        else: return findings
        for root,_,files in os.walk(tmp):
            for f in files:
                fp = Path(root)/f
                if fp.suffix.lower() in ('.zip','.rar','.7z'): findings += deep_scan_archive(fp,backend)
                if fp.suffix.lower()=='.vbs':
                    orig=backend.executable; backend.executable=fp; backend.check_vbs_dos(); backend.executable=orig
                elif fp.suffix.lower() in ('.bat','.cmd'):
                    orig=backend.executable; backend.executable=fp; backend.check_batch_dos(); backend.executable=orig
                elif fp.suffix.lower()=='.ps1':
                    orig=backend.executable; backend.executable=fp; backend.check_powershell_dos(); backend.executable=orig
                elif fp.suffix.lower()=='.hta':
                    orig=backend.executable; backend.executable=fp; backend.check_hta_dos(); backend.executable=orig
                if any(s in fp.name.lower() for s in ['virus','trojan','malware']):
                    findings.append(f"Nested suspicious file: {fp.name}")
                    backend.results["warnings"].append(f"Deep archive threat: {fp.name}")
                    backend.results["threat_score"]+=15
    except Exception as e: findings.append(f"Deep scan error: {e}")
    finally: shutil.rmtree(tmp,ignore_errors=True)
    return findings

# ----------------------------------------------------------------- PrankTesterBackend (start)
class PrankTesterBackend:
    def __init__(self, exe_path, output_queue, execution_timeout=DEFAULT_EXECUTION_TIMEOUT,
                 fork_bomb_threshold=DEFAULT_FORK_BOMB_THRESHOLD, use_sandbox=False):
        self.executable = Path(exe_path)
        self.output_queue = output_queue
        self.execution_timeout = execution_timeout
        self.fork_bomb_threshold = fork_bomb_threshold
        self.use_sandbox = use_sandbox
        self.weights = load_weights()
        self.results = {
            "timestamp":datetime.now().isoformat(),"executable":str(self.executable),"threat_score":0,"verdict":"SAFE",
            "archive_bomb_detected":False,"fork_bomb_detected":False,"vbs_dos_detected":False,"vbs_details":[],
            "batch_dos_detected":False,"batch_details":[],"powershell_dos_detected":False,"powershell_details":[],
            "hta_dos_detected":False,"hta_details":[],"network_flood_detected":False,"network_details":[],
            "diskfill_detected":False,"diskfill_details":[],"printbomb_detected":False,"printbomb_details":[],
            "keyboard_flood_detected":False,"keyboard_details":[],"iso_threats_detected":False,"iso_details":[],
            "behavioural_threats_detected":False,"behavioural_details":[],
            "fileless_persistence_detected":False,"fileless_details":[],
            "execution_time":0,"peak_memory":0,"avg_memory":0,"peak_cpu":0,"avg_cpu":0,"exit_code":None,
            "process_count_change":0,"warnings":[],"notes":[],"stopped_by_user":False,
            "signature_match":False,"sandbox_used":False,
            "_pre_snapshot": {}   # for cleanup
        }
        self.process = None; self.baseline_process_count = 0; self.max_process_count = 0
        self._lock = threading.Lock(); self.stop_requested = False
        self._prev_cpu_times = {}; self._last_cpu_check_time = None
        self._last_net_check_time = None; self._prev_net_connections = 0
        self._pre_run_registry = {}; self._pre_run_startup_folder = []; self._pre_run_scheduled_tasks = []

    def log(self, msg, level="INFO"): self.output_queue.put((level,msg))

    def request_stop(self):
        with self._lock:
            self.stop_requested = True
            proc = self.process
        if proc is None: return
        try:
            parent = psutil.Process(proc.pid)
            children = parent.children(recursive=True)
            for c in children:
                try: c.terminate()
                except Exception as e: logger.debug("prank operation failed: %s", e); pass
            proc.terminate()
            _, alive = psutil.wait_procs(children+[parent], timeout=2)
            for p in alive:
                try: p.kill()
                except Exception as e: logger.debug("prank operation failed: %s", e); pass
        except Exception as e: logger.debug("prank operation failed: %s", e); pass

    # --- Archive bomb detection ---
    def _get_archive_type(self):
        try:
            with open(self.executable,'rb') as f:
                h = f.read(8)
            if h.startswith(b'PK\x03\x04'): return 'ZIP'
            if h.startswith(b'Rar!\x1a\x07\x00') or h.startswith(b'Rar!\x1a\x07\x01\x00'): return 'RAR'
            if h.startswith(b"7z\xbc\xaf\x27\x1c"): return '7Z'
        except Exception as e: logger.debug("prank operation failed: %s", e); pass
        return None

    def check_archive_bomb(self):
        t = self._get_archive_type()
        if not t: return False
        self.log(f"Checking for archive bomb ({t})...","SCAN")
        susp = 0
        try:
            if t=='ZIP':
                with zipfile.ZipFile(self.executable) as z:
                    for i in z.filelist:
                        if i.compress_size>0 and i.file_size/i.compress_size > ZIP_BOMB_RATIO_THRESHOLD:
                            self.log(f"[!] Suspicious: {i.filename} ({i.file_size/i.compress_size:.1f}:1)","ALERT")
                            susp+=1; self.results["warnings"].append(f"Archive bomb: {i.filename}")
            elif t=='RAR' and HAS_RARFILE:
                with rarfile.RarFile(self.executable) as rf:
                    for i in rf.infolist():
                        if i.compress_size>0 and i.file_size/i.compress_size > ZIP_BOMB_RATIO_THRESHOLD:
                            self.log(f"[!] Suspicious: {i.filename} ({i.file_size/i.compress_size:.1f}:1)","ALERT")
                            susp+=1; self.results["warnings"].append(f"Archive bomb: {i.filename}")
            elif t=='7Z' and HAS_PY7ZR:
                with py7zr.SevenZipFile(self.executable) as sz:
                    for i in sz.list():
                        if i.compressed>0 and i.uncompressed/i.compressed > ZIP_BOMB_RATIO_THRESHOLD:
                            self.log(f"[!] Suspicious: {i.filename} ({i.uncompressed/i.compressed:.1f}:1)","ALERT")
                            susp+=1; self.results["warnings"].append(f"Archive bomb: {i.filename}")
        except Exception as e: self.log(f"Archive scan error: {e}","WARN"); return False
        if susp: self.results["archive_bomb_detected"]=True; return True
        self.log("[OK] No suspicious compression","PASS"); return False

    def check_deep_archive_threats(self):
        if self._get_archive_type() is None: return
        self.log("Performing deep archive scan...","SCAN")
        for f in deep_scan_archive(self.executable,self): self.log(f"[!] {f}","ALERT")

    def check_signatures(self):
        sigs = load_signatures()
        sha = hashlib.sha256()
        try:
            with open(self.executable,'rb') as f:
                while c:=f.read(8192): sha.update(c)
            h = sha.hexdigest()
            if h in sigs.get("bad_hashes",[]):
                self.results["signature_match"]=True
                self.results["threat_score"]+=40
                self.log("[!] Signature match: known malicious file","ALERT")
                self.results["warnings"].append("Signature match (known malicious)")
        except Exception as e: logger.debug("prank operation failed: %s", e); pass

    # --- Static scanners ---
    def check_vbs_dos(self):
        if self.executable.suffix.lower()!='.vbs': return False
        self.log("Scanning VBS...","SCAN")
        try: c = self.executable.read_text(encoding='utf-8',errors='ignore')
        except Exception as e: logger.debug("prank scan operation failed: %s", e); return False
        pats = [
            (r'Do\s*$','Infinite Do...Loop',20),(r'For\s+\w+\s*=\s*\d+\s+To\s+\d{5,}','Large For loop',15),
            (r'WScript\.Shell','Creates WScript.Shell object',10),(r'\.Run\s+','Calls .Run method',15),
            (r'CreateObject\s*\(\s*"WScript\.Shell\s*"','Creates shell object',10),
            (r'Scripting\.FileSystemObject','Access to file system',10),(r'\.DeleteFile\s+','Deletes files',20),
            (r'\.CopyFile\s+','Copies files',10),(r'RegWrite','Writes to Registry',20),
            (r'MsgBox\s+.*\n.*MsgBox','Multiple MsgBox',10),(r'For\s+\w+\s*=\s*\d+\s+To\s+\d+\s*\n\s*MsgBox','Loop with MsgBox spam',20),
            (r'WindowStyle\s*=\s*0','Hidden window',10),(r'SendKeys\s+','Sends keystrokes (keyboard flood)',25),
            (r'\.Run\s+.*cmd\s+/c\s+start\s+','Starts cmd windows',20)
        ]
        det=[]; sc=0
        for p,d,s in pats:
            if re.search(p,c,re.IGNORECASE):
                self.log(f"[!] VBS pattern: {d}","ALERT"); det.append(d); sc+=s*self.weights["vbs_dos"]
                self.results["warnings"].append(f"VBS prank: {d}")
        if re.search(r'Do\s*$',c,re.IGNORECASE) and not re.search(r'WScript\.Sleep\s+\d{3,}',c,re.IGNORECASE):
            self.log("[!] Loop without sufficient sleep","ALERT"); det.append("Tight loop without sleep")
            sc+=20*self.weights["vbs_dos"]; self.results["warnings"].append("VBS: tight loop")
        if det:
            self.results["vbs_dos_detected"]=True; self.results["vbs_details"]=det; self.results["threat_score"]+=sc
            return True
        return False

    def check_batch_dos(self):
        if self.executable.suffix.lower() not in ('.bat','.cmd'): return False
        self.log("Scanning batch file...","SCAN")
        try: c = self.executable.read_text(encoding='utf-8',errors='ignore')
        except Exception as e: logger.debug("prank scan operation failed: %s", e); return False
        pats = [
            (r'%0\s*\|\s*%0','Fork bomb (%0|%0)',30),(r':\w+\s*\n\s*start\s+%0','Recursive start %0',30),
            (r':(\w+)\s*\n([\s\S]*?)goto\s+\1','Infinite goto loop',20),
            (r'for\s+/L\s+\w+\s+IN\s*\(\s*0\s*,\s*0\s*,\s*0\s*\)','Infinite FOR /L loop',20),
            (r'start\s+""\s+%0','Start itself repeatedly',30),(r'start\s+cmd\s+','Spawning many cmd',20),
            (r'start\s+notepad\s+','Notepad spam',15),(r'start\s+calc\s+','Calc spam',15),
            (r'start\s+mspaint\s+','Paint spam',15),(r'start\s+iexplore\s+','IE spam',15),
            (r'del\s+/f\s+/s\s+','Destructive deletion',25),(r'rd\s+/s\s+/q\s+','Recursive removal',25),
            (r'format\s+','Format command',30),(r'msg\s+\*\s+','Global message popup',15),
            (r'echo\s+\.\s*\n\s*goto','Infinite echo spam',15),(r'reg\s+add\s+.*\\Run','Adds to startup registry',20),
            (r'schtasks\s+/create','Scheduled task',20),(r'ping\s+-t\s+','Ping flood',25),
            (r'for\s+/L\s+.*ping\s+-t','Ping flood loop',30),(r'start\s+http','Browser storm',15),
            (r'curl\s+.*-o\s+NUL','cURL flood',20),(r'fsutil\s+file\s+createnew','Disk fill via fsutil',25),
            (r'type\s+NUL\s*>.*\s*for\s+/L','Disk fill via FOR loop',20),(r'print\s+/D:','Print job spam',25)
        ]
        det=[]; sc=0
        for p,d,s in pats:
            if re.search(p,c,re.IGNORECASE|re.MULTILINE):
                self.log(f"[!] Batch pattern: {d}","ALERT"); det.append(d); sc+=s*self.weights["batch_dos"]
                self.results["warnings"].append(f"Batch prank: {d}")
        if det:
            self.results["batch_dos_detected"]=True; self.results["batch_details"]=det; self.results["threat_score"]+=sc
            return True
        return False

    def check_powershell_dos(self):
        if self.executable.suffix.lower()!='.ps1': return False
        self.log("Scanning PowerShell...","SCAN")
        try: c = self.executable.read_text(encoding='utf-8',errors='ignore')
        except Exception as e: logger.debug("prank scan operation failed: %s", e); return False
        pats = [
            (r'Set-Volume\s+100','Sets volume 100%',15),(r'Set-DisplayResolution\s+','Changes resolution',15),
            (r'Rotate\s*\(\s*\)','Screen rotation',15),(r'Add-MpPreference\s+-ExclusionPath','Disables Defender exclusion',20),
            (r'while\s*\(\s*1\s*\)','Infinite while',20),(r'while\s*\(\s*\$true\s*\)','Infinite while ($true)',20),
            (r'for\s*\(\s*;;\s*\)','Infinite for',20),(r'Set-ItemProperty\s+.*\\Run','Adds to startup registry',20),
            (r'New-ItemProperty\s+.*\\Run','Adds to startup registry',20),(r'Remove-Item\s+-Recurse\s+-Force\s+','Force deletion',25),
            (r'Clear-RecycleBin\s+','Clears recycle bin',15),(r'Invoke-WebRequest\s+','Downloads from web',15),
            (r'Invoke-Expression\s+','Executes downloaded content',20),
            (r'\[System\.Windows\.Forms\.SendKeys\]','Simulates keystrokes (keyboard flood)',25),
            (r'-WindowStyle\s+Hidden','Hidden window',10),(r'Test-Connection\s+-Count\s+\d{4,}','Massive ping flood',25),
            (r'Invoke-WebRequest\s+.*-UseBasicParsing','HTTP flood',20),(r'System\.Net\.Sockets\.TCPClient','Socket flood',25),
            (r'New-Object\s+System\.Net\.Sockets\.TCPClient','TCP socket creation',25),
            (r'New-Item\s+-ItemType\s+File\s+.*-Force','Creates files in loop',20),
            (r'while.*New-Item','File creation loop',25),(r'Out-Printer\s+','Sends output to printer',25),
            (r'Start-Process\s+print\s+','Print command',25)
        ]
        det=[]; sc=0
        for p,d,s in pats:
            if re.search(p,c,re.IGNORECASE):
                self.log(f"[!] PowerShell pattern: {d}","ALERT"); det.append(d); sc+=s*self.weights["powershell_dos"]
                self.results["warnings"].append(f"PowerShell prank: {d}")
        if det:
            self.results["powershell_dos_detected"]=True; self.results["powershell_details"]=det; self.results["threat_score"]+=sc
            return True
        return False

    def check_hta_dos(self):
        if self.executable.suffix.lower()!='.hta': return False
        self.log("Scanning HTA...","SCAN")
        try: c = self.executable.read_text(encoding='utf-8',errors='ignore')
        except Exception as e: logger.debug("prank scan operation failed: %s", e); return False
        pats = [
            (r'Do\s*[\r\n]+\s*MsgBox','Infinite MsgBox loop (VBS in HTA)',25),
            (r'While\s+True[\s\S]*?MsgBox','Infinite MsgBox while loop',25),
            (r'window\.alert\s*\(','JavaScript alert',15),
            (r'for\s*\(\s*;\s*;\s*\)\s*\{?\s*alert\s*\(','Infinite JS alert loop',30),
            (r'window\.close\s*=\s*function\s*\(\s*\)\s*{\s*}','Blocks window closing',20),
            (r'onbeforeunload\s*=\s*function','Prevents leaving page',20),
            (r'WScript\.Shell','Creates shell object in HTA',20),
            (r'new\s+ActiveXObject\s*\(\s*"WScript\.Shell','ActiveX shell creation',20)
        ]
        det=[]; sc=0
        for p,d,s in pats:
            if re.search(p,c,re.IGNORECASE):
                self.log(f"[!] HTA pattern: {d}","ALERT"); det.append(d); sc+=s*self.weights["hta_dos"]
                self.results["warnings"].append(f"HTA prank: {d}")
        if det:
            self.results["hta_dos_detected"]=True; self.results["hta_details"]=det; self.results["threat_score"]+=sc
            return True
        return False

    # -----------------------------------------------------------------
    #  Network / Disk / Print / Keyboard static scanners
    # -----------------------------------------------------------------
    def check_network_flood(self):
        if self.executable.suffix.lower() not in ('.bat', '.cmd', '.vbs', '.ps1', '.py', '.js'):
            return False
        self.log("Scanning for network flood patterns...", "SCAN")
        try:
            content = self.executable.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return False

        patterns = [
            (r'ping\s+-t\s+', 'Continuous ping flood', 25),
            (r'Test-Connection\s+-Count\s+\d{4,}', 'Massive ping flood (PS)', 25),
            (r'for\s+.*ping\s+-t', 'Ping flood in loop', 30),
            (r'while.*ping\s+-t', 'Ping flood while loop', 30),
            (r'Invoke-WebRequest\s+.*-UseBasicParsing', 'HTTP flood', 25),
            (r'System\.Net\.Sockets\.TCPClient', 'Raw socket creation', 25),
            (r'curl\s+.*-o\s+NUL', 'cURL flood', 20),
            (r'wget\s+.*-O\s+NUL', 'wget flood', 20),
            (r'start\s+http', 'Browser storm', 15),
            (r'CreateObject\s*\(\s*"MSXML2\.ServerXMLHTTP', 'HTTP request object', 20),
        ]
        detected = []
        score = 0
        for pattern, desc, severity in patterns:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                self.log(f"[!] Network flood: {desc}", "ALERT")
                detected.append(desc)
                score += severity * self.weights["network_flood"]
                self.results["warnings"].append(f"Network flood: {desc}")

        if detected:
            self.results["network_flood_detected"] = True
            self.results["network_details"] = detected
            self.results["threat_score"] += score
            return True
        else:
            self.log("[OK] No network flood patterns found", "PASS")
            return False

    def check_disk_fill(self):
        if self.executable.suffix.lower() not in ('.bat', '.cmd', '.ps1', '.vbs', '.py'):
            return False
        self.log("Scanning for disk‑filling patterns...", "SCAN")
        try:
            content = self.executable.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return False

        patterns = [
            (r'fsutil\s+file\s+createnew', 'fsutil file creation', 25),
            (r'type\s+NUL\s*>', 'Redirect NUL to file in loop', 20),
            (r'for\s+/L\s+.*type\s+NUL\s*>', 'FOR loop file creation', 25),
            (r'New-Item\s+-ItemType\s+File\s+', 'PowerShell file creation', 20),
            (r'while.*New-Item', 'PowerShell file creation loop', 25),
            (r'open\s*\(\s*.*\.txt\s*,\s*[\'"]w[\'"]', 'Python file creation loop', 20),
            (r'CreateTextFile\s+', 'VBS CreateTextFile', 20),
        ]
        detected = []
        score = 0
        for pattern, desc, severity in patterns:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                self.log(f"[!] Disk‑fill: {desc}", "ALERT")
                detected.append(desc)
                score += severity * self.weights["diskfill"]
                self.results["warnings"].append(f"Disk‑fill: {desc}")

        if detected:
            self.results["diskfill_detected"] = True
            self.results["diskfill_details"] = detected
            self.results["threat_score"] += score
            return True
        else:
            self.log("[OK] No disk‑filling patterns found", "PASS")
            return False

    def check_print_bomb(self):
        if self.executable.suffix.lower() not in ('.bat', '.cmd', '.ps1', '.vbs', '.py'):
            return False
        self.log("Scanning for print bomb patterns...", "SCAN")
        try:
            content = self.executable.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return False

        patterns = [
            (r'print\s+/D:', 'Direct print command', 25),
            (r'Out-Printer\s+', 'PowerShell Out-Printer', 25),
            (r'lpr\s+', 'Unix lpr command', 25),
            (r'Start-Process\s+print\s+', 'PowerShell Start-Process print', 25),
            (r'for\s+.*print\s+/D:', 'Print in loop', 30),
            (r'while.*Out-Printer', 'Print in PS loop', 30),
            (r'CreateObject\s*\(\s*"WScript\.Shell"\s*\)\s*\.Run\s+.*print', 'Shell print run', 25),
        ]
        detected = []
        score = 0
        for pattern, desc, severity in patterns:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                self.log(f"[!] Print bomb: {desc}", "ALERT")
                detected.append(desc)
                score += severity * self.weights["printbomb"]
                self.results["warnings"].append(f"Print bomb: {desc}")

        if detected:
            self.results["printbomb_detected"] = True
            self.results["printbomb_details"] = detected
            self.results["threat_score"] += score
            return True
        else:
            self.log("[OK] No print bomb patterns found", "PASS")
            return False

    def check_keyboard_flood(self):
        if self.executable.suffix.lower() not in ('.bat', '.cmd', '.ps1', '.vbs', '.py', '.ahk', '.js'):
            return False
        self.log("Scanning for keyboard flood patterns...", "SCAN")
        try:
            content = self.executable.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return False

        patterns = [
            (r'SendKeys\s+', 'VBS SendKeys', 25),
            (r'\.SendKeys\s*\(', 'VBS SendKeys method', 25),
            (r'\[System\.Windows\.Forms\.SendKeys\]', 'PowerShell SendKeys', 25),
            (r'Send\s+\{', 'AutoHotkey Send command', 25),
            (r'keybd_event', 'C keybd_event API', 30),
            (r'mouse_event', 'C mouse_event API', 30),
            (r'SendInput', 'Windows SendInput API', 30),
            (r'while.*SendKeys', 'SendKeys in loop', 30),
            (r'for.*SendKeys', 'SendKeys in loop', 30),
        ]
        detected = []
        score = 0
        for pattern, desc, severity in patterns:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                self.log(f"[!] Keyboard flood: {desc}", "ALERT")
                detected.append(desc)
                score += severity * self.weights["keyboard_flood"]
                self.results["warnings"].append(f"Keyboard flood: {desc}")

        if detected:
            self.results["keyboard_flood_detected"] = True
            self.results["keyboard_details"] = detected
            self.results["threat_score"] += score
            return True
        else:
            self.log("[OK] No keyboard flood patterns found", "PASS")
            return False

    # -----------------------------------------------------------------
    #  ISO threat scanner
    # -----------------------------------------------------------------
    def check_iso_threats(self):
        if not HAS_PYCDLIB or self.executable.suffix.lower() not in ('.iso', '.img'):
            if self.executable.suffix.lower() == '.iso':
                self.log("pycdlib not installed (pip install pycdlib). Skipping ISO scan.", "WARN")
            return False
        self.log("Scanning ISO contents for threats...", "SCAN")
        try:
            iso = pycdlib.PyCdlib()
            iso.open(str(self.executable))
        except Exception as e:
            self.log(f"Could not open ISO (maybe not valid): {e}", "WARN")
            return False

        suspicious_files = []
        score_add = 0
        dangerous_exts = {'.exe', '.dll', '.scr', '.bat', '.cmd', '.vbs', '.ps1', '.hta', '.msi', '.reg', '.vbe', '.js', '.jse', '.wsf', '.wsh'}
        script_exts = {'.bat', '.cmd', '.vbs', '.ps1', '.hta', '.vbe', '.js', '.jse', '.wsf', '.wsh'}
        suspicious_names = ['virus', 'trojan', 'keygen', 'crack', 'hack', 'malware', 'autorun']

        def walk_directory(dir_record, path='/'):
            nonlocal score_add
            for child in iso.list_children(dir_record):
                if child.is_dot() or child.is_dotdot():
                    continue
                full_path = path + child.file_identifier().decode('utf-8', errors='ignore')
                if child.is_dir():
                    walk_directory(child, full_path + '/')
                else:
                    name = child.file_identifier().decode('utf-8', errors='ignore').lower()
                    for ext in dangerous_exts:
                        if name.endswith(ext):
                            desc = f"Executable/Script in ISO: {full_path}"
                            suspicious_files.append(desc)
                            if ext in script_exts:
                                score_add += 15
                            else:
                                score_add += 10
                            self.log(f"[!] {desc}", "ALERT")
                            break
                    for sname in suspicious_names:
                        if sname in name:
                            desc = f"Suspicious filename: {full_path}"
                            suspicious_files.append(desc)
                            score_add += 15
                            self.log(f"[!] {desc}", "ALERT")
                            break
                    if name == 'autorun.inf':
                        desc = f"autorun.inf found: {full_path}"
                        suspicious_files.append(desc)
                        score_add += 20
                        self.log(f"[!] {desc}", "ALERT")
                    if name.endswith(('.zip', '.rar', '.7z', '.tar', '.gz', '.bz2')):
                        desc = f"Archive inside ISO: {full_path}"
                        suspicious_files.append(desc)
                        score_add += 10
                        self.log(f"[!] {desc}", "ALERT")

        try:
            walk_directory(iso.pvd.root_dir_record)
        except Exception as e:
            self.log(f"Error walking ISO: {e}", "WARN")

        iso.close()

        if suspicious_files:
            self.results["iso_threats_detected"] = True
            self.results["iso_details"] = suspicious_files
            self.results["threat_score"] += min(score_add, 80)
            self.results["warnings"].append("ISO contains suspicious files")
            return True
        else:
            self.log("[OK] No threats found inside ISO", "PASS")
            return False

    # -----------------------------------------------------------------
    #  BEHAVIOUR ENGINE
    # -----------------------------------------------------------------
    def _analyze_process_tree_behaviour(self):
        parent_pid = self.process.pid
        try:
            parent = psutil.Process(parent_pid)
            all_children = parent.children(recursive=True)
            processes_to_check = [parent] + all_children
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return

        behavioural_patterns = [
            (r'\\reg\.exe\b', 'Registry access (reg.exe)', 20),
            (r'\\regedit\.exe\b', 'Registry access (regedit)', 20),
            (r'\\diskpart\.exe\b', 'Disk manipulation (diskpart)', 30),
            (r'\\format\.com\b', 'Disk format attempt', 30),
            (r'\\schtasks\.exe\b', 'Scheduled task creation', 20),
            (r'\\rundll32\.exe\b', 'Rundll32 execution', 15),
            (r'\\mshta\.exe\b', 'MSHTA execution', 15),
            (r'\\cscript\.exe\b', 'VBS via cscript', 15),
            (r'\\wscript\.exe\b', 'VBS via wscript', 15),
            (r'\\powershell\.exe\b', 'PowerShell execution', 10),
            (r'ping\s+-t', 'Ping flood (child process)', 25),
            (r'Test-Connection\s+-Count\s+\d{4,}', 'Massive ping (child)', 25),
            (r'Invoke-WebRequest\s+', 'HTTP request flood', 20),
            (r'curl\s+.*-o\s+NUL', 'cURL flood', 20),
            (r'start\s+http', 'Browser storm', 15),
            (r'fsutil\s+file\s+createnew', 'Disk fill via fsutil', 25),
            (r'type\s+NUL\s*>', 'Disk fill via redirection', 20),
            (r'print\s+/D:', 'Print bomb', 25),
            (r'SendKeys\s+', 'Keyboard flood', 25),
            (re.escape(str(self.executable)), 'Self‑spawning (possible fork bomb)', 20),
        ]

        for proc in processes_to_check:
            try:
                proc_name = proc.name().lower()
                if proc_name in LOLBIN_DATABASE:
                    sev, desc = LOLBIN_DATABASE[proc_name]
                    desc_full = f"LOLBin process: {proc_name} – {desc}"
                    if desc_full not in self.results["behavioural_details"]:
                        self.log(f"[!] Behaviour: {desc_full} (PID {proc.pid})", "ALERT")
                        self.results["behavioural_details"].append(desc_full)
                        self.results["behavioural_threats_detected"] = True
                        self.results["threat_score"] += sev * self.weights["behavioural"]
                        self.results["warnings"].append(f"Behavioural threat: {desc_full}")
                cmdline = proc.cmdline()
                if not cmdline:
                    continue
                cmd_str = ' '.join(cmdline).lower()
                for pattern, desc, severity in behavioural_patterns:
                    if re.search(pattern, cmd_str, re.IGNORECASE):
                        if desc not in self.results["behavioural_details"]:
                            self.log(f"[!] Behaviour: {desc} (PID {proc.pid})", "ALERT")
                            self.results["behavioural_details"].append(desc)
                            self.results["behavioural_threats_detected"] = True
                            self.results["threat_score"] += severity * self.weights["behavioural"]
                            self.results["warnings"].append(f"Behavioural threat: {desc}")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

    def _check_network_connections_burst(self):
        try:
            current_conns = len(psutil.net_connections())
        except (psutil.AccessDenied, Exception):
            return

        now = time.time()
        if self._last_net_check_time is None:
            self._last_net_check_time = now
            self._prev_net_connections = current_conns
            return

        interval = now - self._last_net_check_time
        if interval < 1.0:
            return

        if current_conns > MAX_NET_CONN_BURST and current_conns > self._prev_net_connections * 1.5:
            desc = f"Network connection burst ({current_conns} connections)"
            if desc not in self.results["behavioural_details"]:
                self.log(f"[!] Behaviour: {desc}", "ALERT")
                self.results["behavioural_details"].append(desc)
                self.results["behavioural_threats_detected"] = True
                self.results["threat_score"] += 25 * self.weights["network_flood"]
                self.results["network_flood_detected"] = True
                self.results["network_details"].append(desc)
                self.results["warnings"].append(f"Network flood: {desc}")

        self._last_net_check_time = now
        self._prev_net_connections = current_conns

    # -----------------------------------------------------------------
    #  FILE‑LESS PERSISTENCE DETECTION
    # -----------------------------------------------------------------
    def _get_registry_run_keys(self):
        if winreg is None:
            return {}
        run_keys = {}
        for hkey, label, path in [
            (winreg.HKEY_LOCAL_MACHINE, 'HKLM', r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_CURRENT_USER, 'HKCU', r"Software\Microsoft\Windows\CurrentVersion\Run"),
        ]:
            try:
                with winreg.OpenKey(hkey, path) as key:
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(key, i)
                            run_keys.setdefault(f"{label}\\Run", []).append(f"{name}={value}")
                            i += 1
                        except OSError:
                            break
            except FileNotFoundError:
                pass
        return run_keys

    def _get_startup_folder_items(self):
        startup = Path(os.environ.get('APPDATA', '')) / r'Microsoft\Windows\Start Menu\Programs\Startup'
        if startup.exists():
            return [p.name for p in startup.iterdir()]
        return []

    def _get_scheduled_tasks(self):
        tasks = []
        try:
            output = subprocess.check_output(['schtasks', '/query', '/fo', 'LIST', '/v'], timeout=10,
                                            shell=False).decode('utf-8', errors='ignore')
            for line in output.splitlines():
                if line.startswith('HostName:'):
                    tasks.append(line.strip())
        except Exception:
            pass
        return tasks

    def _take_persistence_snapshot(self):
        if platform.system() != 'Windows':
            return
        self._pre_run_registry = self._get_registry_run_keys()
        self._pre_run_startup_folder = self._get_startup_folder_items()
        self._pre_run_scheduled_tasks = self._get_scheduled_tasks()
        # store in results for cleanup
        self.results["_pre_snapshot"] = {
            "registry": self._pre_run_registry,
            "startup": self._pre_run_startup_folder,
            "tasks": self._pre_run_scheduled_tasks
        }

    def _check_persistence_diff(self):
        if platform.system() != 'Windows':
            return
        new_items = []

        post_reg = self._get_registry_run_keys()
        for key, values in post_reg.items():
            pre_values = self._pre_run_registry.get(key, [])
            for val in values:
                if val not in pre_values:
                    desc = f"New Run key: {key}\\{val}"
                    new_items.append(desc)

        post_startup = self._get_startup_folder_items()
        for item in post_startup:
            if item not in self._pre_run_startup_folder:
                desc = f"New Startup file: {item}"
                new_items.append(desc)

        post_tasks = self._get_scheduled_tasks()
        if len(post_tasks) > len(self._pre_run_scheduled_tasks):
            diff = len(post_tasks) - len(self._pre_run_scheduled_tasks)
            desc = f"{diff} new scheduled task(s) detected"
            new_items.append(desc)

        if new_items:
            self.results["fileless_persistence_detected"] = True
            self.results["fileless_details"] = new_items
            self.results["threat_score"] += 25 * self.weights["fileless_persistence"]
            for item in new_items:
                self.log(f"[!] File‑less persistence: {item}", "ALERT")
                self.results["warnings"].append(f"File‑less persistence: {item}")

    # -----------------------------------------------------------------
    #  SYSTEM‑WIDE SCAN
    # -----------------------------------------------------------------
    def run_system_scan(self):
        self.log("=" * 60, "SYSTEM_SCAN")
        self.log("Starting system‑wide file‑less threat scan...", "SYSTEM_SCAN")
        findings = []

        self.log("Checking running processes for LOLBins...", "SCAN")
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                name = proc.info['name'] or ''
                cmdline = ' '.join(proc.info['cmdline'] or [])
                name_lower = name.lower()
                if name_lower in LOLBIN_DATABASE:
                    sev, desc = LOLBIN_DATABASE[name_lower]
                    findings.append(f"Running LOLBin: {name} (PID {proc.info['pid']}) – {desc}")
                for pattern, desc in [
                    (r'reg\.exe\s+add\s+.*\\Run', 'Registry persistence via reg.exe'),
                    (r'schtasks\s+/create', 'Scheduled task creation'),
                    (r'bitsadmin\s+/transfer', 'BITS file download'),
                    (r'certutil\s+-urlcache\s+-f', 'Certutil file download'),
                ]:
                    if re.search(pattern, cmdline, re.IGNORECASE):
                        findings.append(f"Suspicious command: {desc} (PID {proc.info['pid']})")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        self.log("Checking Registry Run keys...", "SCAN")
        run_entries = self._get_registry_run_keys()
        for key, vals in run_entries.items():
            for v in vals:
                findings.append(f"Registry Run: {key}\\{v}")

        self.log("Checking Startup folder...", "SCAN")
        startup_items = self._get_startup_folder_items()
        for item in startup_items:
            findings.append(f"Startup folder: {item}")

        self.log("Checking Scheduled Tasks...", "SCAN")
        tasks = self._get_scheduled_tasks()
        if tasks:
            findings.append(f"Total scheduled tasks: {len(tasks)} (details omitted)")

        if findings:
            self.log(f"System scan found {len(findings)} items:", "ALERT")
            for f in findings:
                self.log(f"  - {f}", "ALERT")
        else:
            self.log("System scan complete. No obvious threats found.", "PASS")

        self.log("=" * 60, "SYSTEM_SCAN")

    # -----------------------------------------------------------------
    #  Heuristic scoring & verdict
    # -----------------------------------------------------------------
    def _compute_verdict(self):
        score = self.results.get("threat_score", 0)
        if score <= 30:
            verdict = "SAFE"
        elif score <= 60:
            verdict = "SUSPICIOUS"
        else:
            verdict = "DANGEROUS"
        self.results["verdict"] = verdict
        self.log(f"Threat score: {score}/100 → {verdict}", "TEST")

    # -----------------------------------------------------------------
    #  Remaining backend methods
    # -----------------------------------------------------------------
    def get_process_count(self):
        return len(psutil.pids())

    def check_fork_bomb(self, current_count):
        diff = current_count - self.baseline_process_count
        if diff > self.fork_bomb_threshold:
            self.log(f"[!] Fork bomb detected! +{diff} new processes", "ALERT")
            self.results["warnings"].append(f"Fork bomb: +{diff} new processes")
            self.results["fork_bomb_detected"] = True
            self.results["threat_score"] += 30 * self.weights["fork_bomb"]
            return True
        return False

    def _tree_memory_and_cpu(self, ps_process):
        now = time.time()
        if self._last_cpu_check_time is None:
            self._last_cpu_check_time = now
            self._prev_cpu_times = {}
            try:
                procs = [ps_process] + ps_process.children(recursive=True)
            except Exception:
                return 0.0, 0.0
            for p in procs:
                try:
                    self._prev_cpu_times[p.pid] = p.cpu_times()
                except Exception:
                    pass
            return 0.0, 0.0

        interval = now - self._last_cpu_check_time
        self._last_cpu_check_time = now
        if interval <= 0:
            return 0.0, 0.0

        try:
            procs = [ps_process] + ps_process.children(recursive=True)
        except Exception:
            return 0.0, 0.0

        total_mem = 0.0
        delta_user = 0.0
        delta_sys = 0.0

        for p in procs:
            try:
                mem = p.memory_info().rss / 1024 / 1024
                total_mem += mem
                cpu = p.cpu_times()
                if p.pid in self._prev_cpu_times:
                    prev = self._prev_cpu_times[p.pid]
                    delta_user += cpu.user - prev.user
                    delta_sys += cpu.system - prev.system
                self._prev_cpu_times[p.pid] = cpu
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                self._prev_cpu_times.pop(p.pid, None)

        num_cpus = psutil.cpu_count() or 1
        delta_total = delta_user + delta_sys
        cpu_percent = (delta_total / interval) / num_cpus * 100.0
        cpu_percent = max(0.0, min(cpu_percent, 100.0 * num_cpus))
        return total_mem, cpu_percent

    def run_test(self):
        self.log("=" * 60, "TEST")
        self.log(f"Prank Tester v6.1 – {self.executable}", "TEST")
        self.log(f"Timeout: {self.execution_timeout}s | Fork-bomb threshold: +{self.fork_bomb_threshold}", "TEST")
        self.log("=" * 60, "TEST")

        # Phase 1
        self.log("\n[PHASE 1] Pre-execution analysis", "TEST")
        if not self.executable.exists():
            self.log("ERROR: File not found!", "ERROR")
            self.results["exit_code"] = -1
            return self.results

        size_kb = self.executable.stat().st_size / 1024
        self.log(f"File size: {size_kb:.1f} KB", "INFO")

        self.check_signatures()
        self._take_persistence_snapshot()

        self.check_archive_bomb()
        self.check_deep_archive_threats()
        self.check_vbs_dos()
        self.check_batch_dos()
        self.check_powershell_dos()
        self.check_hta_dos()
        self.check_network_flood()
        self.check_disk_fill()
        self.check_print_bomb()
        self.check_keyboard_flood()
        self.check_iso_threats()
        self._compute_verdict()

        self.baseline_process_count = self.get_process_count()
        self.max_process_count = self.baseline_process_count
        self.log(f"Baseline processes: {self.baseline_process_count}", "INFO")

        # Phase 2 (sandbox or execution)
        if self.use_sandbox and platform.system() == 'Windows' and is_windows_sandbox_available():
            self.log("Launching in Windows Sandbox...", "TEST")
            self.results["sandbox_used"] = True
            self.output_queue.put(("SANDBOX", "Launching Windows Sandbox..."))
            launch_in_sandbox(str(self.executable), self.execution_timeout)
            self.results["stopped_by_user"] = True
            return self.results

        self.log("\n[PHASE 2] Executing prank", "TEST")
        start_time = time.time()
        launch_target = str(self.executable)

        if self.executable.is_dir():
            if platform.system() == "Darwin":
                launch_args = ["open", launch_target]
            elif platform.system() == "Windows":
                launch_args = ["explorer.exe", launch_target]
            else:
                launch_args = ["xdg-open", launch_target]
            use_shell = False
        else:
            launch_args = [launch_target]
            use_shell = False

        try:
            self.process = subprocess.Popen(
                launch_args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=use_shell,
            )
            self.log(f"Process spawned (PID: {self.process.pid})", "INFO")
        except Exception as e:
            self.log(f"ERROR: Failed to launch without shell: {e}", "ERROR")
            self.results["exit_code"] = -1
            return self.results

        # Phase 3
        self.log("\n[PHASE 3] Real-time monitoring", "TEST")
        peak_memory = 0.0
        mem_samples = []
        peak_cpu = 0.0
        cpu_samples = []
        last_fork_check = time.time()
        last_behaviour_check = time.time()
        self._prev_cpu_times = {}
        self._last_cpu_check_time = None
        self._last_net_check_time = None
        self._prev_net_connections = 0

        try:
            ps_process = psutil.Process(self.process.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            ps_process = None

        if ps_process is not None:
            while time.time() - start_time < self.execution_timeout:
                with self._lock:
                    if self.stop_requested:
                        self.log("Stopped by user", "WARN")
                        self.results["stopped_by_user"] = True
                        break

                try:
                    if self.process.poll() is not None:
                        break

                    mem_mb, cpu_pct = self._tree_memory_and_cpu(ps_process)
                    if mem_mb:
                        peak_memory = max(peak_memory, mem_mb)
                        mem_samples.append(mem_mb)
                    if cpu_pct is not None:
                        peak_cpu = max(peak_cpu, cpu_pct)
                        cpu_samples.append(cpu_pct)

                    if time.time() - last_fork_check > 2:
                        current = self.get_process_count()
                        self.max_process_count = max(self.max_process_count, current)
                        if self.check_fork_bomb(current):
                            self.log("Terminating due to fork bomb", "ALERT")
                            self.process.terminate()
                            try:
                                self.process.wait(timeout=2)
                            except subprocess.TimeoutExpired:
                                self.process.kill()
                            break
                        last_fork_check = time.time()

                    if time.time() - last_behaviour_check > 2:
                        self._analyze_process_tree_behaviour()
                        self._check_network_connections_burst()
                        last_behaviour_check = time.time()

                    time.sleep(0.5)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    break
                except Exception as e:
                    self.log(f"Monitor error: {e}", "WARN")

        try:
            exit_code = self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.log("Timeout, terminating...", "WARN")
            self.process.kill()
            exit_code = self.process.wait()
        except Exception:
            exit_code = None

        elapsed = time.time() - start_time
        avg_memory = sum(mem_samples) / len(mem_samples) if mem_samples else 0.0
        avg_cpu = sum(cpu_samples) / len(cpu_samples) if cpu_samples else 0.0

        # Phase 4
        self.log("\n[PHASE 4] Results", "TEST")
        self.log(f"Execution time: {elapsed:.2f}s", "INFO")
        self.log(f"Peak memory: {peak_memory:.1f} MB (avg {avg_memory:.1f} MB)", "INFO")
        self.log(f"Peak CPU: {peak_cpu:.1f}% (avg {avg_cpu:.1f}%)", "INFO")
        self.log(f"Exit code: {exit_code}", "INFO")

        process_change = self.max_process_count - self.baseline_process_count
        self.log(f"Process change: +{process_change}", "INFO")

        self.results["execution_time"] = round(elapsed, 2)
        self.results["peak_memory"] = round(peak_memory, 1)
        self.results["avg_memory"] = round(avg_memory, 1)
        self.results["peak_cpu"] = round(peak_cpu, 1)
        self.results["avg_cpu"] = round(avg_cpu, 1)
        self.results["exit_code"] = exit_code
        self.results["process_count_change"] = process_change

        self._check_persistence_diff()
        self._compute_verdict()

        self.log("\n[FINAL REPORT]", "TEST")
        def report_section(label, detected_flag, details_list=None):
            if detected_flag:
                self.log(f"[!] {label}: DETECTED", "FAIL")
                if details_list:
                    for d in details_list:
                        self.log(f"    - {d}", "ALERT")
            else:
                self.log(f"[OK] {label}: CLEAR", "PASS")

        report_section("Archive bomb", self.results["archive_bomb_detected"])
        report_section("VBS DOS / prank", self.results["vbs_dos_detected"], self.results["vbs_details"])
        report_section("Batch DOS / prank", self.results["batch_dos_detected"], self.results["batch_details"])
        report_section("PowerShell DOS / prank", self.results["powershell_dos_detected"], self.results["powershell_details"])
        report_section("HTA DOS / prank", self.results["hta_dos_detected"], self.results["hta_details"])
        report_section("Network flood", self.results["network_flood_detected"], self.results["network_details"])
        report_section("Disk‑fill attack", self.results["diskfill_detected"], self.results["diskfill_details"])
        report_section("Print bomb", self.results["printbomb_detected"], self.results["printbomb_details"])
        report_section("Keyboard flood", self.results["keyboard_flood_detected"], self.results["keyboard_details"])
        report_section("ISO threats", self.results["iso_threats_detected"], self.results["iso_details"])
        report_section("Behavioural threats", self.results["behavioural_threats_detected"], self.results["behavioural_details"])
        report_section("File‑less persistence", self.results["fileless_persistence_detected"], self.results["fileless_details"])
        report_section("Fork bomb (runtime)", self.results["fork_bomb_detected"])

        self.log(f"Final Verdict: {self.results['verdict']} (Score: {self.results['threat_score']}/100)", "TEST")

        if elapsed > 20:
            self.log("[?] Long execution time – possible AV scanning", "WARN")
            self.results["notes"].append("Long execution time")
        if peak_memory > MEMORY_WARNING_THRESHOLD:
            self.log(f"[?] High memory usage ({peak_memory:.1f} MB)", "WARN")
            self.results["notes"].append("High memory usage")
        if peak_cpu > 90:
            self.log(f"[?] High CPU usage ({peak_cpu:.1f}%)", "WARN")
            self.results["notes"].append("High CPU usage")

        self.log("=" * 60, "TEST")
        return self.results



# ----------------------------------------------------------------- Report export (from the original GUI class, refactored to plain functions)
def export_report(results, format="html"):
    ts = results.get("timestamp", "unknown").replace(":", "-").replace(" ", "_")
    filename = f"prank_report_{ts}.{format}"
    if format == "pdf" and HAS_FPDF:
        try:
            _export_pdf(results, filename)
            return
        except Exception:
            format = "html"
            filename = f"prank_report_{ts}.html"
    _export_html(results, filename)

def _export_html(results, filename):
    verdict = results.get("verdict", "SAFE")
    score = results.get("threat_score", 0)
    sections = {
        "Archive Bomb": (results.get("archive_bomb_detected"), []),
        "VBS DOS / Prank": (results.get("vbs_dos_detected"), results.get("vbs_details", [])),
        "Batch DOS / Prank": (results.get("batch_dos_detected"), results.get("batch_details", [])),
        "PowerShell DOS / Prank": (results.get("powershell_dos_detected"), results.get("powershell_details", [])),
        "HTA DOS / Prank": (results.get("hta_dos_detected"), results.get("hta_details", [])),
        "Network Flood": (results.get("network_flood_detected"), results.get("network_details", [])),
        "Disk‑fill Attack": (results.get("diskfill_detected"), results.get("diskfill_details", [])),
        "Print Bomb": (results.get("printbomb_detected"), results.get("printbomb_details", [])),
        "Keyboard Flood": (results.get("keyboard_flood_detected"), results.get("keyboard_details", [])),
        "ISO Threats": (results.get("iso_threats_detected"), results.get("iso_details", [])),
        "Behavioural Threats": (results.get("behavioural_threats_detected"), results.get("behavioural_details", [])),
        "File‑less Persistence": (results.get("fileless_persistence_detected"), results.get("fileless_details", [])),
        "Fork Bomb (Runtime)": (results.get("fork_bomb_detected"), []),
    }
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Prank Threat Report</title>
<style>
    body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
    .container {{ max-width: 800px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
    h1 {{ color: #333; }}
    .verdict {{ font-size: 24px; font-weight: bold; margin: 20px 0; }}
    .safe {{ color: green; }}
    .suspicious {{ color: orange; }}
    .dangerous {{ color: red; }}
    table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
    th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }}
    th {{ background: #f2f2f2; }}
</style>
</head>
<body>
<div class="container">
    <h1>Prank Threat Analysis Report</h1>
    <p><strong>File:</strong> {results.get('executable', '?')}</p>
    <p><strong>Timestamp:</strong> {results.get('timestamp', '?')}</p>
    <p><strong>Threat Score:</strong> {score}/100</p>
    <div class="verdict {verdict.lower()}">Verdict: {verdict}</div>
    <h2>Detection Summary</h2>
    <table>
        <tr><th>Category</th><th>Detected</th><th>Details</th></tr>
"""
    for name, (detected, details) in sections.items():
        html += f"<tr><td>{name}</td><td>{'✅' if detected else '✕'}</td><td>"
        if detected and details:
            html += ", ".join(details)
        html += "</td></tr>"
    html += """
    </table>
    <h2>Resource Usage</h2>
    <table>
        <tr><th>Metric</th><th>Value</th></tr>
"""
    html += f"<tr><td>Execution Time</td><td>{results.get('execution_time', 0):.2f}s</td></tr>"
    html += f"<tr><td>Peak Memory</td><td>{results.get('peak_memory', 0)} MB</td></tr>"
    html += f"<tr><td>Average Memory</td><td>{results.get('avg_memory', 0)} MB</td></tr>"
    html += f"<tr><td>Peak CPU</td><td>{results.get('peak_cpu', 0)}%</td></tr>"
    html += f"<tr><td>Average CPU</td><td>{results.get('avg_cpu', 0)}%</td></tr>"
    html += f"<tr><td>Process Count Change</td><td>+{results.get('process_count_change', 0)}</td></tr>"
    html += f"<tr><td>Exit Code</td><td>{results.get('exit_code', 'N/A')}</td></tr>"
    html += """
    </table>
"""
    if results.get("warnings"):
        html += "<h2>Warnings</h2><ul>"
        for w in results["warnings"]:
            html += f"<li>{w}</li>"
        html += "</ul>"
    html += """
</div>
</body>
</html>
"""
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html)
    webbrowser.open(filename)

def _export_pdf(results, filename):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    def safe_text(s):
        return ''.join(c if ord(c) < 128 else '-' for c in s)

    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "Prank Threat Analysis Report", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
    pdf.ln(5)

    pdf.set_font("Helvetica", "", 12)
    pdf.cell(0, 8, f"File: {results.get('executable', '?')}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 8, f"Timestamp: {results.get('timestamp', '?')}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 8, f"Threat Score: {results.get('threat_score', 0)}/100", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    verdict = results.get("verdict", "SAFE")
    pdf.set_font("Helvetica", "B", 14)
    if verdict == "DANGEROUS":
        pdf.set_text_color(200, 0, 0)
    elif verdict == "SUSPICIOUS":
        pdf.set_text_color(255, 140, 0)
    else:
        pdf.set_text_color(0, 150, 0)
    pdf.cell(0, 10, f"Verdict: {verdict}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(5)

    sections = [
        ("Archive Bomb", results.get("archive_bomb_detected"), []),
        ("VBS DOS", results.get("vbs_dos_detected"), results.get("vbs_details", [])),
        ("Batch DOS", results.get("batch_dos_detected"), results.get("batch_details", [])),
        ("PowerShell DOS", results.get("powershell_dos_detected"), results.get("powershell_details", [])),
        ("HTA DOS", results.get("hta_dos_detected"), results.get("hta_details", [])),
        ("Network Flood", results.get("network_flood_detected"), results.get("network_details", [])),
        ("Disk Fill", results.get("diskfill_detected"), results.get("diskfill_details", [])),
        ("Print Bomb", results.get("printbomb_detected"), results.get("printbomb_details", [])),
        ("Keyboard Flood", results.get("keyboard_flood_detected"), results.get("keyboard_details", [])),
        ("ISO Threats", results.get("iso_threats_detected"), results.get("iso_details", [])),
        ("Behavioural", results.get("behavioural_threats_detected"), results.get("behavioural_details", [])),
        ("File-less Persistence", results.get("fileless_persistence_detected"), results.get("fileless_details", [])),
        ("Fork Bomb", results.get("fork_bomb_detected"), []),
    ]

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Detection Summary", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)
    for name, detected, details in sections:
        status = "DETECTED" if detected else "CLEAR"
        pdf.cell(0, 6, f"{safe_text(name)}: {status}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        if detected and details:
            for d in details[:5]:
                pdf.cell(10)
                pdf.cell(0, 6, f"- {safe_text(d)}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.ln(4)
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Resource Usage", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, f"Execution Time: {results.get('execution_time', 0):.2f}s", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Peak Memory: {results.get('peak_memory', 0)} MB", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Avg Memory: {results.get('avg_memory', 0)} MB", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Peak CPU: {results.get('peak_cpu', 0)}%", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Avg CPU: {results.get('avg_cpu', 0)}%", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Process Change: +{results.get('process_count_change', 0)}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f"Exit Code: {results.get('exit_code', 'N/A')}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    if results.get("warnings"):
        pdf.ln(4)
        pdf.set_font("Helvetica", "B", 12)
        pdf.cell(0, 8, "Warnings", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_font("Helvetica", "", 10)
        for w in results["warnings"][:10]:
            pdf.cell(0, 6, f"- {safe_text(w)}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.output(filename)
    try:
        os.startfile(filename)
    except AttributeError:
        webbrowser.open(filename)


# ----------------------------------------------------------------- Test history (from PrankTesterGUI.load_history/save_history)
def load_history():
    try:
        if Path(HISTORY_FILE).exists():
            with open(HISTORY_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return []


def save_history(history):
    try:
        with open(HISTORY_FILE, 'w') as f:
            json.dump(history, f, indent=2)
    except Exception:
        pass


def append_history(results, max_entries=200):
    history = load_history()
    history.append(results)
    history = history[-max_entries:]
    save_history(history)
    return history


# ----------------------------------------------------------------- VirusTotal hash lookup (from PrankTesterGUI.run_vt_check, made synchronous)
def virustotal_lookup(file_path, api_key):
    """Returns a plain-text result string. Caller runs this off the UI thread."""
    if not HAS_REQUESTS:
        return "The 'requests' library isn't installed."
    if not api_key:
        return "No VirusTotal API key provided."
    try:
        import requests
        sha = hashlib.sha256()
        with open(file_path, 'rb') as f:
            while chunk := f.read(8192):
                sha.update(chunk)
        file_hash = sha.hexdigest()
        headers = {"x-apikey": api_key}
        resp = requests.get(f"https://www.virustotal.com/api/v3/files/{file_hash}", headers=headers, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            stats = data["data"]["attributes"]["last_analysis_stats"]
            return f"{stats['malicious']}/{stats['total']} security vendors flagged this file as malicious."
        elif resp.status_code == 404:
            return "File not previously scanned on VirusTotal."
        else:
            return f"VirusTotal API error {resp.status_code}"
    except Exception as e:
        return f"Lookup failed: {e}"


# ----------------------------------------------------------------- Persistence cleanup (from PrankTesterGUI._cleanup_persistence, sg.popup calls removed)
def cleanup_persistence(results):
    """Remove new Run keys and Startup files added during a test run.
    Returns a plain-text status message; caller displays it however it likes."""
    if platform.system() != 'Windows' or winreg is None:
        return "Cleanup is only supported on Windows."

    pre_snapshot = results.get("_pre_snapshot", {})
    if not pre_snapshot:
        return "No pre-run snapshot available for this result. Cannot clean."

    removed_reg = 0
    tmp_backend = PrankTesterBackend("dummy", queue.Queue())
    post_reg = tmp_backend._get_registry_run_keys()
    pre_reg = pre_snapshot.get("registry", {})
    for key_path, post_values in post_reg.items():
        pre_values = pre_reg.get(key_path, [])
        for entry in post_values:
            if entry not in pre_values:
                name, _, value = entry.partition('=')
                try:
                    hkey = winreg.HKEY_LOCAL_MACHINE if 'HKLM' in key_path else winreg.HKEY_CURRENT_USER
                    subkey = key_path.split('\\', 1)[-1]
                    with winreg.OpenKey(hkey, subkey, 0, winreg.KEY_SET_VALUE) as reg_key:
                        winreg.DeleteValue(reg_key, name)
                    removed_reg += 1
                except Exception:
                    pass

    removed_startup = 0
    pre_startup = set(pre_snapshot.get("startup", []))
    post_startup = set(tmp_backend._get_startup_folder_items())
    for item in post_startup - pre_startup:
        try:
            startup_path = Path(os.environ['APPDATA']) / r'Microsoft\Windows\Start Menu\Programs\Startup' / item
            if startup_path.exists():
                os.remove(startup_path)
                removed_startup += 1
        except Exception:
            pass

    return f"Cleanup done: {removed_reg} registry entries and {removed_startup} startup files removed."
