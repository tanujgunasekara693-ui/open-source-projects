#!/usr/bin/env python3
"""
Module: duplicate_finder
Generated for TechDrive 500
Category: Duplicate Finder

Real duplicate detection: name-collision, size-collision, and true
content-identity (SHA-256, with a fast size+partial-hash prefilter) —
plus category-filtered variants and a real batch delete.
"""

import os
import platform
import hashlib
from collections import defaultdict
from gui.tk_dialogs import filedialog, messagebox
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []

PHOTO_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp", ".heic", ".raw", ".cr2", ".nef"}
DOC_EXT = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".odt", ".csv"}
MUSIC_EXT = {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"}
VIDEO_EXT = {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".m4v"}


# ---------------------------------------------------------------------------
# shared scanning engine
# ---------------------------------------------------------------------------
def _walk_files(folder, exts=None):
    for root, dirs, files in os.walk(folder):
        for fn in files:
            if exts and os.path.splitext(fn)[1].lower() not in exts:
                continue
            full = os.path.join(root, fn)
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            yield full, fn, size


def _hash_file(path, algo="sha256", quick=False, chunk=1024 * 1024):
    h = hashlib.new(algo)
    try:
        with open(path, "rb") as f:
            if quick:
                h.update(f.read(chunk))
            else:
                while True:
                    block = f.read(chunk)
                    if not block:
                        break
                    h.update(block)
        return h.hexdigest()
    except (OSError, PermissionError):
        return None


def _find_by_key(folder, key_fn, exts=None, min_group=2):
    """Group files by key_fn(full,name,size). Return {key: [full,...]} for
    groups with >= min_group members."""
    groups = defaultdict(list)
    scanned = 0
    for full, fn, size in _walk_files(folder, exts):
        scanned += 1
        groups[key_fn(full, fn, size)].append(full)
    return {k: v for k, v in groups.items() if len(v) >= min_group}, scanned


def _find_true_duplicates(folder, exts=None):
    """Real content-identical duplicate detection:
    1) group by size (files of different size can't be duplicates)
    2) within each size group, group by a quick partial hash
    3) within each partial-hash group, confirm with a full SHA-256 hash
    Returns {sha256: [paths]} for confirmed duplicate groups.
    """
    by_size = defaultdict(list)
    scanned = 0
    total_bytes = 0
    for full, fn, size in _walk_files(folder, exts):
        if size == 0:
            continue
        by_size[size].append(full)
        scanned += 1
        total_bytes += size

    dup_groups = {}
    for size, paths in by_size.items():
        if len(paths) < 2:
            continue
        by_quick = defaultdict(list)
        for p in paths:
            qh = _hash_file(p, quick=True)
            if qh:
                by_quick[qh].append(p)
        for qh, qpaths in by_quick.items():
            if len(qpaths) < 2:
                continue
            by_full = defaultdict(list)
            for p in qpaths:
                fh = _hash_file(p, quick=False)
                if fh:
                    by_full[fh].append(p)
            for fh, fpaths in by_full.items():
                if len(fpaths) >= 2:
                    dup_groups[fh] = fpaths
    return dup_groups, scanned, total_bytes


def _report_from_groups(groups, title):
    if not groups:
        return f"{title}: no duplicates found."
    lines = [f"{title}: {len(groups)} duplicate group(s) found."]
    total_wasted = 0
    for i, (key, paths) in enumerate(sorted(groups.items(), key=lambda kv: -len(kv[1]))[:200], 1):
        try:
            size = os.path.getsize(paths[0])
        except OSError:
            size = 0
        wasted = size * (len(paths) - 1)
        total_wasted += wasted
        lines.append(f"\n[{i}] {len(paths)} copies, {bytes_fmt(size)} each (wastes {bytes_fmt(wasted)}):")
        for p in paths:
            lines.append(f"    {p}")
    lines.append(f"\nTotal reclaimable space (top groups shown): {bytes_fmt(total_wasted)}")
    return "\n".join(lines)


def _remember_groups(self, groups):
    """Stash the most recent duplicate groups on the app object so Batch
    Remover can act on exactly what was just found."""
    self._last_duplicate_groups = groups


# ---------------------------------------------------------------------------
# 1. Find Duplicate Files — true content duplicates, all file types.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 2. Duplicate Names — same filename appearing more than once (regardless
#    of content), useful for spotting stray copies like "file (1).txt".
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 3. Duplicate Sizes — same byte size (candidates, not confirmed content).
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 4. Duplicate Hashes — quick partial-hash grouping (fast, one hash per
#    file, first 1MB) — a fast alternative to full-content verification.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 5. Duplicate Content — full SHA-256 over the whole file (slower, exact).
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 6-9: category-filtered true-duplicate scans
# ---------------------------------------------------------------------------
def _category_tool(self, frame, title, exts, subtitle):
    panel = CardPanel(frame, self.theme, title, subtitle)

    def run():
        folder = filedialog.askdirectory(title="Folder to scan")
        if not folder:
            return "Cancelled."
        groups, scanned, total_bytes = _find_true_duplicates(folder, exts=exts)
        _remember_groups(self, groups)
        header = f"Scanned {scanned} matching files ({bytes_fmt(total_bytes)}) in {folder}.\n"
        return header + _report_from_groups(groups, title)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)










# ---------------------------------------------------------------------------
# 10. Batch Remover — deletes duplicates for real, keeping one copy per
#     group. Operates on the most recent scan from this session; if none
#     exists yet it runs a fresh true-duplicate scan first.
# ---------------------------------------------------------------------------
