#!/usr/bin/env python3
r"""
techdrive_modules/gpu_test.py - GPU Test category
===================================================
Real implementation built on hw_sensors.gpu_list(), the same aggregation
layer (NVML -> nvidia-smi -> LibreHardwareMonitor -> Win32_VideoController)
used by nvidia_gpu.py and Live Monitoring — every number here comes from
an actual sensor read, sampled repeatedly over each test's duration.

Honesty note on "load-generating" tests (Stress/Benchmark/FurMark-style/
3DMark-style): TechDrive doesn't bundle a GPU load generator (FurMark,
3DMark, etc. are third-party and not shipped here). Where Windows' own
WinSAT Direct3D assessment (winsat.exe, built into Windows) is present,
these tools use it to generate a real, measurable GPU load while
sampling sensors; where it isn't available, the tool says so plainly and
falls back to monitoring whatever load is currently on the card (useful
if you start a game/benchmark yourself and want temps/clocks logged).
"""

import os
import platform
import subprocess
import time
import tkinter as tk
from tkinter import ttk

from gui.theme import FONT_UI, FONT_MONO
from gui.tool_view import CardPanel
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell

IS_WINDOWS = platform.system() == "Windows"

CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def bytes_fmt(n):
    n = float(n or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def _primary_gpu():
    gpus = hw.gpu_list()
    return (gpus[0] if gpus else None), gpus


def _has_winsat():
    if not IS_WINDOWS:
        return False
    path = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "winsat.exe")
    return os.path.exists(path)


def _run_winsat_d3d(timeout=90):
    """Runs Windows' own built-in Direct3D assessment (winsat d3d) as a
    real, genuine GPU load. Returns (ok, output). Not available on every
    Windows build (removed the GUI in later versions, but the exe/tests
    are still present on many installs) — callers must handle failure."""
    try:
        r = subprocess.run(["winsat", "d3d"], capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out
    except FileNotFoundError:
        return False, "winsat.exe not found."
    except subprocess.TimeoutExpired:
        return False, "winsat timed out."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _sample_loop(seconds, interval=1.0, on_tick=None):
    """Repeatedly calls hw.gpu_list() for `seconds`, returns the raw list
    of per-tick GPU snapshots for the primary GPU (index 0)."""
    samples = []
    ticks = max(1, int(seconds / interval))
    for i in range(ticks):
        gpus = hw.gpu_list()
        g = gpus[0] if gpus else {}
        samples.append(g)
        if on_tick:
            on_tick(i, ticks, g)
        if i < ticks - 1:
            time.sleep(interval)
    return samples


def _agg(samples, key):
    vals = [s.get(key) for s in samples if s.get(key) is not None]
    if not vals:
        return None
    return {"min": min(vals), "max": max(vals), "avg": sum(vals) / len(vals), "n": len(vals)}


def _fmt_agg(label, agg, unit=""):
    if agg is None:
        return f"{label}: not exposed by this GPU's driver/sensor source."
    return f"{label}: min {agg['min']:.1f}{unit}  avg {agg['avg']:.1f}{unit}  max {agg['max']:.1f}{unit}  ({agg['n']} samples)"


def _no_gpu_msg(gpus):
    if not gpus:
        return ("No GPU could be detected through NVML, nvidia-smi, LibreHardwareMonitor, "
                "or Windows' own Win32_VideoController — check that a graphics driver is "
                "installed and (for live sensor data) that LibreHardwareMonitor or the NVIDIA "
                "driver's NVML component is present.")
    return None


def _duration_row(self, frame, default="20"):
    row = tk.Frame(frame, bg=self.theme["BG"])
    row.pack(fill="x", padx=16, pady=(0, 6))
    tk.Label(row, text="Duration (seconds):", bg=self.theme["BG"], fg=self.theme["MUTED"],
             font=FONT_UI).pack(side="left")
    var = tk.StringVar(value=default)
    tk.Entry(row, textvariable=var, width=6).pack(side="left", padx=(6, 0))
    return var


# ---------------------------------------------------------------------------
# tools
# ---------------------------------------------------------------------------


















