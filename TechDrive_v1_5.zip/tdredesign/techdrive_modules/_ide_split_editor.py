import logging
logger = logging.getLogger("TechDrive.IDE")
import tkinter as tk
from tkinter import ttk

class SplitEditor:
    """
    Split editing - view two files side-by-side or split view of same file.
    Can be horizontal or vertical split.
    """
    
    def __init__(self, parent_frame, ide_instance):
        self.parent = parent_frame
        self.ide = ide_instance
        self.split_mode = None  # 'horizontal', 'vertical', or None
        self.left_editor = None
        self.right_editor = None
        self.left_file = None
        self.right_file = None
        self.sash_position = 0.5
    
    def enable_vertical_split(self, left_file=None, right_file=None):
        """
        Split editor vertically (left-right).
        left_file, right_file: filepath or None for current
        """
        self.split_mode = 'vertical'
        
        # Create panedwindow
        paned = ttk.PanedWindow(self.parent, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)
        
        # Left side
        left_frame = tk.Frame(paned)
        paned.add(left_frame, weight=1)
        
        if left_file:
            self.left_file = left_file
            # Create editor for left file
            self.left_editor = self._create_editor_widget(left_frame, left_file)
        else:
            # Use current editor
            self.left_editor = self.ide.get_current_editor_info()['widget']
        
        # Right side
        right_frame = tk.Frame(paned)
        paned.add(right_frame, weight=1)
        
        if right_file:
            self.right_file = right_file
            self.right_editor = self._create_editor_widget(right_frame, right_file)
        else:
            self.right_editor = self._create_empty_editor(right_frame)
        
        return paned
    
    def enable_horizontal_split(self, top_file=None, bottom_file=None):
        """
        Split editor horizontally (top-bottom).
        """
        self.split_mode = 'horizontal'
        
        # Create panedwindow
        paned = ttk.PanedWindow(self.parent, orient=tk.VERTICAL)
        paned.pack(fill=tk.BOTH, expand=True)
        
        # Top side
        top_frame = tk.Frame(paned)
        paned.add(top_frame, weight=1)
        
        if top_file:
            self.left_file = top_file
            self.left_editor = self._create_editor_widget(top_frame, top_file)
        else:
            self.left_editor = self.ide.get_current_editor_info()['widget']
        
        # Bottom side
        bottom_frame = tk.Frame(paned)
        paned.add(bottom_frame, weight=1)
        
        if bottom_file:
            self.right_file = bottom_file
            self.right_editor = self._create_editor_widget(bottom_frame, bottom_file)
        else:
            self.right_editor = self._create_empty_editor(bottom_frame)
        
        return paned
    
    def disable_split(self):
        """Disable split mode and return to single editor."""
        self.split_mode = None
        self.left_editor = None
        self.right_editor = None
        self.left_file = None
        self.right_file = None
    
    def _create_editor_widget(self, parent, filepath):
        """Create a code editor widget for a file."""
        # This would use your existing CodeEditor
        # For now, return a placeholder
        editor = tk.Text(parent, wrap='none')
        editor.pack(fill=tk.BOTH, expand=True)
        
        # Load file content
        try:
            with open(filepath, 'r') as f:
                editor.insert('1.0', f.read())
        except Exception as e:
            editor.insert('1.0', '')
        
        return editor
    
    def _create_empty_editor(self, parent):
        """Create an empty editor widget."""
        editor = tk.Text(parent, wrap='none')
        editor.pack(fill=tk.BOTH, expand=True)
        return editor
    
    def sync_scroll(self):
        """Sync scrolling between left and right editors."""
        if self.left_editor and self.right_editor:
            # Bind scroll events
            self.left_editor.bind('<MouseWheel>', lambda e: self._on_scroll(e, self.right_editor))
            self.right_editor.bind('<MouseWheel>', lambda e: self._on_scroll(e, self.left_editor))
    
    def _on_scroll(self, event, other_editor):
        """Handle synchronized scrolling."""
        delta = -1 * (event.delta // 120) if event.delta else 1
        other_editor.yview_scroll(delta, 'units')
    
    def sync_content(self):
        """Keep both sides in sync (useful for learning/translation)."""
        if self.left_editor and self.right_editor:
            left_text = self.left_editor.get('1.0', 'end-1c')
            self.right_editor.delete('1.0', 'end')
            self.right_editor.insert('1.0', left_text)
    
    def compare_files(self, file1, file2):
        """
        Compare two files side-by-side with diff highlighting.
        Highlights differences.
        """
        try:
            with open(file1, 'r') as f:
                content1 = f.read()
            with open(file2, 'r') as f:
                content2 = f.read()
            
            # Create split view
            paned = self.enable_vertical_split()
            
            # Load content
            self.left_editor.delete('1.0', 'end')
            self.left_editor.insert('1.0', content1)
            self.right_editor.delete('1.0', 'end')
            self.right_editor.insert('1.0', content2)
            
            # Highlight differences
            self._highlight_diffs(content1.split('\n'), content2.split('\n'))
            
            return paned
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            return None
    
    def _highlight_diffs(self, lines1, lines2):
        """Highlight different lines in both editors."""
        import difflib
        
        matcher = difflib.SequenceMatcher(None, lines1, lines2)
        
        for tag_name, (i1, i2, j1, j2) in enumerate(matcher.get_opcodes()):
            if tag_name == 'replace':
                # Highlight changed lines in red
                for i in range(i1, i2):
                    self.left_editor.tag_add('diff_changed', f'{i+1}.0', f'{i+1}.end')
                for j in range(j1, j2):
                    self.right_editor.tag_add('diff_changed', f'{j+1}.0', f'{j+1}.end')
            
            elif tag_name == 'delete':
                # Highlight deleted lines
                for i in range(i1, i2):
                    self.left_editor.tag_add('diff_deleted', f'{i+1}.0', f'{i+1}.end')
            
            elif tag_name == 'insert':
                # Highlight added lines
                for j in range(j1, j2):
                    self.right_editor.tag_add('diff_added', f'{j+1}.0', f'{j+1}.end')
        
        # Configure tags
        self.left_editor.tag_configure('diff_changed', background='#FFA500')
        self.left_editor.tag_configure('diff_deleted', background='#FF6B6B')
        self.right_editor.tag_configure('diff_changed', background='#FFA500')
        self.right_editor.tag_configure('diff_added', background='#90EE90')
    
    def get_left_content(self):
        """Get content from left editor."""
        if self.left_editor:
            return self.left_editor.get('1.0', 'end-1c')
        return ''
    
    def get_right_content(self):
        """Get content from right editor."""
        if self.right_editor:
            return self.right_editor.get('1.0', 'end-1c')
        return ''
    
    def set_left_content(self, content):
        """Set content in left editor."""
        if self.left_editor:
            self.left_editor.delete('1.0', 'end')
            self.left_editor.insert('1.0', content)
    
    def set_right_content(self, content):
        """Set content in right editor."""
        if self.right_editor:
            self.right_editor.delete('1.0', 'end')
            self.right_editor.insert('1.0', content)
    
    def is_split_mode(self):
        """Check if split mode is active."""
        return self.split_mode is not None
    
    def get_split_mode(self):
        """Get current split mode."""
        return self.split_mode