#!/usr/bin/env python3
"""
Module: audio_tools
Generated for TechDrive 500
Category: Audio Tools
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

try:
    import winsound
except ImportError:
    winsound = None

try:
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
except ImportError:
    AudioUtilities = None

try:
    import sounddevice as sd
    import numpy as np
except (ImportError, OSError):  # OSError: PortAudio shared library missing
    sd = None
    np = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def _win_only():
    return "Windows-only feature (this tool relies on Windows audio APIs)."


def _ps(cmd, timeout=15):
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True, text=True, timeout=timeout
        )
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        if r.returncode != 0 and not out:
            return False, err or "Command failed."
        return True, out or "(no output)"
    except FileNotFoundError:
        return False, "PowerShell not found on this system."
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except Exception as e:
        return False, f"Error: {e}"


CATALOGUE = []




















