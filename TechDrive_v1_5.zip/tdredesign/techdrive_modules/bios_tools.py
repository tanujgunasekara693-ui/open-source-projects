#!/usr/bin/env python3
"""
Module: bios_tools
Generated for TechDrive 500
Category: BIOS Tools

Real firmware/BIOS info pulled via WMI (Win32_BIOS / Win32_ComputerSystem
/ Win32_BaseBoard), bcdedit for boot/firmware mode, and PowerShell
(Confirm-SecureBootUEFI / Get-Tpm) for security state. Falls back
gracefully (clear message, no crash) wherever a probe is unavailable.
"""

import platform
import subprocess
from gui.tk_dialogs import simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


def _run(cmd, timeout=15):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _wmic_bios():
    """Query BIOS info, preferring the wmi module, falling back to
    PowerShell's Get-CimInstance (wmic itself is deprecated/removed on
    newer Windows builds)."""
    if wmi_module:
        try:
            c = wmi_module.WMI()
            b = c.Win32_BIOS()[0]
            return {
                "manufacturer": b.Manufacturer,
                "version": b.SMBIOSBIOSVersion or b.Version,
                "release_date": getattr(b, "ReleaseDate", None),
                "serial": b.SerialNumber,
                "name": b.Name,
            }
        except Exception:
            pass
    try:
        r = _run(["powershell", "-NoProfile", "-Command",
                   "Get-CimInstance Win32_BIOS | Select-Object Manufacturer,SMBIOSBIOSVersion,"
                   "ReleaseDate,SerialNumber,Name | Format-List | Out-String -Width 200"])
        text = r.stdout.strip()
        if not text:
            return None
        data = {}
        for line in text.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                data[k.strip().lower()] = v.strip()
        return {
            "manufacturer": data.get("manufacturer"),
            "version": data.get("smbiosbiosversion"),
            "release_date": data.get("releasedate"),
            "serial": data.get("serialnumber"),
            "name": data.get("name"),
        }
    except Exception:
        return None


def _bios_info_tool(self, frame, title, field_key, label):
    panel = CardPanel(frame, self.theme, title, on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on WMI/PowerShell)."
        data = _wmic_bios()
        if not data:
            return "Could not read BIOS info — the WMI service may be unavailable, or this requires the 'wmi' package (pip install wmi)."
        if field_key == "*":
            lines = ["=== BIOS Info ==="]
            for k, v in data.items():
                lines.append(f"{k.replace('_', ' ').title():<15} {v or 'Unknown'}")
            return "\n".join(lines)
        val = data.get(field_key) or "Unknown"
        return f"{label}: {val}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)




















