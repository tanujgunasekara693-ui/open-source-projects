#!/usr/bin/env python3
"""
techdrive_modules/nvidia_gpu.py - NVIDIA GPU category
=====================================================
Deep NVIDIA-specific telemetry: hotspot (GPU junction) and VRAM
temperatures, power, clocks, throttle reasons, fan curve, per-process VRAM
and the raw driver report.

Hotspot note: NVML's public temperature API only returns the GPU edge
sensor. On Ada/Ampere+ the junction reading is derived from the T.Limit
fields (shutdown threshold minus reported slack) - that is what
hw_sensors.nvidia_hotspot() does, with nvidia-smi -q and
LibreHardwareMonitor as fallbacks. If none of them expose it on your
driver the panel says "not exposed" instead of showing a fake number.
"""

import tkinter as tk
from tkinter import ttk

from gui.live_chart import LiveChart, LiveSampler
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell, _Tiles, _controls, _missing

CATALOGUE = []

C_PINK, C_ORANGE, C_BLUE, C_GREEN, C_CYAN, C_YELLOW = (
    "#e84393", "#e67e22", "#00e5ff", "#2ecc71", "#00cec9", "#f1c40f")


def _no_nvidia(self, body):
    _missing(self, body,
             "No NVIDIA GPU detected. This category needs the NVIDIA driver (nvidia-smi) and, for "
             "hotspot readings, NVML - install `pip install nvidia-ml-py` for the richest data.")
















