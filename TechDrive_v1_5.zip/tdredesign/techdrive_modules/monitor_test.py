#!/usr/bin/env python3
"""
Module: monitor_test
Generated for TechDrive 500
Category: Monitor Test

GUI note: the actual tests are inherently full-screen visual patterns
(color swatches, moving bars, checkerboards) — that part was already a
real GUI, not a text dump, and is unchanged. What *was* a plain
_panel_header()/_text_output() text box is now CardPanel chrome
(header, Refresh where relevant, Close) with the instructions as a
proper card and a themed launch button, matching the rest of the app
instead of a bare Tk button below a text box.
"""

import os
import re
import time
import socket
import platform
import subprocess
import tkinter as tk
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog

from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

try:
    import ctypes
except ImportError:
    ctypes = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


def _fullscreen_pattern(self, draw_fn, esc_hint="Press Esc or click to close"):
    """Open a borderless fullscreen Toplevel and hand its canvas to draw_fn(canvas, w, h)."""
    top = tk.Toplevel(self)
    top.attributes("-fullscreen", True)
    top.configure(bg="black")
    canvas = tk.Canvas(top, highlightthickness=0, bd=0, bg="black")
    canvas.pack(fill="both", expand=True)
    top.update_idletasks()
    w, h = top.winfo_screenwidth(), top.winfo_screenheight()

    def close(_e=None):
        top.destroy()

    top.bind("<Escape>", close)
    canvas.bind("<Button-1>", close)
    label = tk.Label(top, text=esc_hint, fg="#888", bg="black", font=("Segoe UI", 10))
    label.place(relx=0.5, rely=0.98, anchor="s")
    draw_fn(canvas, w, h)
    top.focus_force()
    return top


def _swatch_sequence(self, colors, seconds_each=1.5):
    """Cycle a fullscreen window through a list of solid colors."""
    top = tk.Toplevel(self)
    top.attributes("-fullscreen", True)
    top.bind("<Escape>", lambda e: top.destroy())
    top.bind("<Button-1>", lambda e: top.destroy())
    idx = {"i": 0}

    def step():
        if not top.winfo_exists():
            return
        top.configure(bg=colors[idx["i"] % len(colors)])
        idx["i"] += 1
        if idx["i"] <= len(colors):
            top.after(int(seconds_each * 1000), step)
        else:
            top.after(int(seconds_each * 1000), lambda: top.winfo_exists() and top.destroy())

    step()
    return top


def _get_display_settings():
    """Return (width, height, refresh_hz, bpp) for the primary display, via ctypes on Windows."""
    if IS_WINDOWS and ctypes is not None:
        try:
            user32 = ctypes.windll.user32

            class DEVMODE(ctypes.Structure):
                _fields_ = [
                    ("dmDeviceName", ctypes.c_wchar * 32), ("dmSpecVersion", ctypes.c_ushort),
                    ("dmDriverVersion", ctypes.c_ushort), ("dmSize", ctypes.c_ushort),
                    ("dmDriverExtra", ctypes.c_ushort), ("dmFields", ctypes.c_ulong),
                    ("dmOrientation", ctypes.c_short), ("dmPaperSize", ctypes.c_short),
                    ("dmPaperLength", ctypes.c_short), ("dmPaperWidth", ctypes.c_short),
                    ("dmScale", ctypes.c_short), ("dmCopies", ctypes.c_short),
                    ("dmDefaultSource", ctypes.c_short), ("dmPrintQuality", ctypes.c_short),
                    ("dmColor", ctypes.c_short), ("dmDuplex", ctypes.c_short),
                    ("dmYResolution", ctypes.c_short), ("dmTTOption", ctypes.c_short),
                    ("dmCollate", ctypes.c_short), ("dmFormName", ctypes.c_wchar * 32),
                    ("dmLogPixels", ctypes.c_ushort), ("dmBitsPerPel", ctypes.c_ulong),
                    ("dmPelsWidth", ctypes.c_ulong), ("dmPelsHeight", ctypes.c_ulong),
                    ("dmDisplayFlags", ctypes.c_ulong), ("dmDisplayFrequency", ctypes.c_ulong),
                ]

            dm = DEVMODE()
            dm.dmSize = ctypes.sizeof(DEVMODE)
            ENUM_CURRENT_SETTINGS = -1
            if user32.EnumDisplaySettingsW(None, ENUM_CURRENT_SETTINGS, ctypes.byref(dm)):
                return dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency, dm.dmBitsPerPel
        except Exception:
            pass
    return None


def _instructions(panel, text):
    """Instruction copy rendered inside the card body, styled like the rest
    of CardPanel's rows instead of a bare Text widget."""
    tk.Label(panel.body, text=text, bg=panel.theme["CARD_BG"], fg=panel.theme["MUTED"],
              font=("Segoe UI", 9), justify="left", wraplength=640,
              anchor="w").pack(anchor="w", padx=14, pady=(12, 4))


def _launch_button(panel, text, command):
    """Themed launch button living in the card body (replaces the old
    bare _button_row below the text box)."""
    row = tk.Frame(panel.body, bg=panel.theme["CARD_BG"])
    row.pack(anchor="w", padx=14, pady=(4, 14))
    tk.Button(row, text=text, command=command, bg=panel.theme["ACCENT"],
              fg=panel.theme.get("ON_ACCENT", "#ffffff"), relief="flat",
              padx=14, pady=6, font=("Segoe UI", 9, "bold")).pack(side="left")




















