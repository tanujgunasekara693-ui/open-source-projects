import logging
logger = logging.getLogger("TechDrive.IDE")
import tkinter as tk
from tkinter import ttk
import subprocess
import threading
import os
import sys
import platform
import queue
import time

# PTY support for Unix, winpty for Windows
try:
    if platform.system() == 'Windows':
        from winpty import PtyProcess
        HAS_WINPTY = True
    else:
        import pty
        import select
        import termios
        import struct
        import fcntl
        HAS_WINPTY = False
except ImportError:
    HAS_WINPTY = False
    print("Winpty not installed. Install with: pip install pywinpty")


class TerminalWidget(tk.Frame):
    """
    Fully functional embedded terminal emulator.
    - Supports PTY (Unix) and WinPTY (Windows) for real interactive shells.
    - Output streaming with ANSI color support (via text tags).
    - Resize events propagate to the PTY.
    - Command history navigation (Up/Down).
    """
    
    def __init__(self, parent, initial_dir=None, shell=None, **kwargs):
        super().__init__(parent, bg='#1e1e1e', **kwargs)
        
        self.initial_dir = initial_dir or os.path.expanduser('~')
        self.current_dir = self.initial_dir
        
        # Shell selection
        if shell is None:
            if platform.system() == 'Windows':
                self.shell = os.environ.get('COMSPEC', 'cmd.exe')
            else:
                self.shell = os.environ.get('SHELL', '/bin/bash')
        else:
            self.shell = shell
        
        self.process = None
        self.is_running = False
        self.read_thread = None
        self.write_queue = queue.Queue()
        self.output_queue = queue.Queue()
        
        # Command history
        self.history = []
        self.history_index = -1
        self.current_input = ""
        
        # Terminal geometry
        self.rows = 24
        self.cols = 80
        
        # ANSI color mapping
        self.colors = {
            'black': '#000000',
            'red': '#cd0000',
            'green': '#00cd00',
            'yellow': '#cdcd00',
            'blue': '#0000cd',
            'magenta': '#cd00cd',
            'cyan': '#00cdcd',
            'white': '#e5e5e5',
            'bright_black': '#7f7f7f',
            'bright_red': '#ff0000',
            'bright_green': '#00ff00',
            'bright_yellow': '#ffff00',
            'bright_blue': '#5c5cff',
            'bright_magenta': '#ff00ff',
            'bright_cyan': '#00ffff',
            'bright_white': '#ffffff',
        }
        
        self._setup_ui()
        self._start_shell()
    
    def _setup_ui(self):
        """Build the tkinter UI."""
        # Text widget for output (with ANSI color support)
        self.output = tk.Text(
            self,
            wrap='char',
            bg='#1e1e1e',
            fg='#00ff00',
            font=('Consolas', 11),
            insertbackground='#00ff00',
            relief='flat',
            borderwidth=0,
            undo=False,
            maxundo=0
        )
        self.output.pack(side='top', fill='both', expand=True, padx=2, pady=2)
        
        # Prevent user from editing output directly, but allow selection
        self.output.bind('<Key>', self._on_key_press)
        self.output.bind('<Button-1>', lambda e: self.output.focus_set())
        self.output.bind('<MouseWheel>', self._on_scroll)
        self.output.bind('<Configure>', self._on_resize)
        
        # Configure text tags for ANSI colors
        for name, hex_color in self.colors.items():
            self.output.tag_configure(f'fg_{name}', foreground=hex_color)
            self.output.tag_configure(f'bg_{name}', background=hex_color)
        
        # Default tags
        self.output.tag_configure('bold', font=('Consolas', 11, 'bold'))
        self.output.tag_configure('underline', underline=True)
        self.output.tag_configure('inverse', background='#00ff00', foreground='#1e1e1e')
        
        # Scrollbar
        scrollbar = tk.Scrollbar(self, orient='vertical', command=self.output.yview)
        scrollbar.pack(side='right', fill='y')
        self.output.config(yscrollcommand=scrollbar.set)
        
        # Focus on start
        self.output.focus_set()
    
    def _start_shell(self):
        """Start the underlying PTY process."""
        if self.process:
            return
        
        try:
            if platform.system() == 'Windows' and HAS_WINPTY:
                # Windows: use winpty
                self.process = PtyProcess.spawn(
                    self.shell,
                    cwd=self.current_dir,
                    dimensions=(self.rows, self.cols)
                )
                self.is_running = True
                self._read_loop_winpty()
            
            else:
                # Unix/Linux/Mac: use pty + subprocess
                self._start_unix_pty()
            
        except Exception as e:
            self._append_text(f"\r\n[ERROR] Failed to start terminal: {e}\r\n", 'fg_red')
            self.is_running = False
    
    def _start_unix_pty(self):
        """Start PTY on Unix systems."""
        import pty
        import subprocess
        
        # Create master/slave PTY
        master_fd, slave_fd = pty.openpty()
        
        # Set window size
        self._set_pty_size(master_fd)
        
        # Fork and exec
        pid = os.fork()
        if pid == 0:  # Child
            os.setsid()
            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            os.close(master_fd)
            os.chdir(self.current_dir)
            os.execvp(self.shell, [self.shell])
            os._exit(1)
        else:  # Parent
            os.close(slave_fd)
            self.master_fd = master_fd
            self.pid = pid
            self.is_running = True
            self._read_loop_unix()
    
    def _set_pty_size(self, fd):
        """Set terminal size for Unix PTY."""
        try:
            import fcntl
            import termios
            import struct
            
            size = struct.pack('HH', self.rows, self.cols)
            fcntl.ioctl(fd, termios.TIOCSWINSZ, size)
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass
    
    def _on_resize(self, event):
        """Handle widget resize to update PTY dimensions."""
        # Approximate rows/cols based on font size
        try:
            import tkinter.font
            font = tkinter.font.Font(font=self.output.cget('font'))
            char_width = font.measure('W')
            char_height = font.metrics('linespace')
            
            width = self.output.winfo_width()
            height = self.output.winfo_height()
            
            if char_width > 0 and char_height > 0:
                new_cols = max(10, width // char_width)
                new_rows = max(5, height // char_height)
                
                if new_cols != self.cols or new_rows != self.rows:
                    self.cols = new_cols
                    self.rows = new_rows
                    
                    # Update PTY size
                    if hasattr(self, 'master_fd'):
                        self._set_pty_size(self.master_fd)
                    elif hasattr(self, 'process'):
                        try:
                            self.process.setwinsize(self.rows, self.cols)
                        except Exception as e:
                            pass
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass
    
    def _on_scroll(self, event):
        """Handle mouse scroll."""
        if event.delta:
            delta = -1 * (event.delta // 120)
        else:
            delta = 1 if event.num == 5 else -1
        self.output.yview_scroll(delta, 'units')
        return 'break'
    
    # -------------------- Reading Output (Unix) --------------------
    def _read_loop_unix(self):
        """Read from PTY on Unix."""
        def reader():
            import select
            while self.is_running:
                try:
                    rlist, _, _ = select.select([self.master_fd], [], [], 0.1)
                    if self.master_fd in rlist:
                        data = os.read(self.master_fd, 1024)
                        if data:
                            self.output_queue.put(data)
                            self.after(0, self._process_output)
                except Exception as e:
                    break
        
        self.read_thread = threading.Thread(target=reader, daemon=True)
        self.read_thread.start()
    
    # -------------------- Reading Output (Windows) --------------------
    def _read_loop_winpty(self):
        """Read from WinPTY on Windows."""
        def reader():
            while self.is_running and self.process:
                try:
                    data = self.process.read(1024)
                    if data:
                        self.output_queue.put(data.encode('utf-8'))
                        self.after(0, self._process_output)
                    else:
                        time.sleep(0.05)
                except Exception as e:
                    break
        
        self.read_thread = threading.Thread(target=reader, daemon=True)
        self.read_thread.start()
    
    # -------------------- Writing Input --------------------
    def _on_key_press(self, event):
        """Handle keyboard input."""
        if not self.is_running:
            return 'break'
        
        # Handle special keys
        if event.keysym == 'Return':
            self._write_input('\r')
            return 'break'
        
        elif event.keysym == 'BackSpace':
            self._write_input('\x7f')
            return 'break'
        
        elif event.keysym == 'Tab':
            self._write_input('\t')
            return 'break'
        
        elif event.keysym == 'Up':
            self._history_up()
            return 'break'
        
        elif event.keysym == 'Down':
            self._history_down()
            return 'break'
        
        elif event.keysym == 'Left':
            self._write_input('\x1b[D')
            return 'break'
        
        elif event.keysym == 'Right':
            self._write_input('\x1b[C')
            return 'break'
        
        elif event.keysym == 'Home':
            self._write_input('\x1b[H')
            return 'break'
        
        elif event.keysym == 'End':
            self._write_input('\x1b[F')
            return 'break'
        
        elif event.keysym == 'Delete':
            self._write_input('\x1b[3~')
            return 'break'
        
        elif event.keysym in ('Shift_L', 'Shift_R', 'Control_L', 'Control_R', 
                              'Alt_L', 'Alt_R', 'Caps_Lock', 'Num_Lock', 
                              'Scroll_Lock', 'Super_L', 'Super_R'):
            return 'break'
        
        elif event.char:
            self._write_input(event.char)
            return 'break'
        
        return 'break'
    
    def _write_input(self, data):
        """Write data to the PTY."""
        if not self.is_running:
            return
        
        try:
            if hasattr(self, 'master_fd'):
                os.write(self.master_fd, data.encode('utf-8'))
            elif self.process:
                self.process.write(data)
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass
    
    def _process_output(self):
        """Process queued output and display it."""
        while not self.output_queue.empty():
            try:
                data = self.output_queue.get_nowait()
                self._append_text(data.decode('utf-8', errors='replace'))
            except Exception as e:
                pass
        
        # Auto-scroll to bottom
        self.output.see('end')
    
    # -------------------- ANSI Parsing --------------------
    def _append_text(self, text, default_tag=None):
        """
        Append text with ANSI color parsing.
        Simplified parser for common codes (bold, colors, reset).
        """
        if not text:
            return
        
        # Current style state
        current_fg = 'fg_white'
        current_bg = None
        bold = False
        
        i = 0
        while i < len(text):
            if text[i] == '\x1b' and i+1 < len(text) and text[i+1] == '[':
                # Parse ANSI sequence
                j = i + 2
                while j < len(text) and text[j].isdigit() or text[j] == ';':
                    j += 1
                
                if j < len(text):
                    code_str = text[i+2:j]
                    code = text[j] if text[j].isalpha() else ''
                    i = j + 1
                    
                    if code in ('m', ''):  # SGR
                        codes = [int(c) if c else 0 for c in code_str.split(';') if c]
                        for c in codes:
                            if c == 0:  # Reset
                                current_fg = 'fg_white'
                                current_bg = None
                                bold = False
                            elif c == 1:  # Bold
                                bold = True
                            elif 30 <= c <= 37:  # Foreground
                                current_fg = f'fg_{self._ansi_color_name(c - 30)}'
                            elif 40 <= c <= 47:  # Background
                                current_bg = f'bg_{self._ansi_color_name(c - 40)}'
                            elif 90 <= c <= 97:  # Bright foreground
                                current_fg = f'fg_bright_{self._ansi_color_name(c - 90)}'
                            elif 100 <= c <= 107:  # Bright background
                                current_bg = f'bg_bright_{self._ansi_color_name(c - 100)}'
                    continue
                else:
                    i += 1
            
            # Write the character with current tags
            tags = [current_fg] if current_fg else []
            if current_bg:
                tags.append(current_bg)
            if bold:
                tags.append('bold')
            
            self.output.insert('end', text[i], tuple(tags))
            i += 1
    
    @staticmethod
    def _ansi_color_name(index):
        """Map ANSI color index to name."""
        names = ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']
        return names[index % 8] if index < 8 else 'white'
    
    # -------------------- Command History --------------------
    def _history_up(self):
        """Navigate up in command history."""
        if not self.history:
            return
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            cmd = self.history[-(self.history_index + 1)]
            self._replace_current_line(cmd)
    
    def _history_down(self):
        """Navigate down in command history."""
        if self.history_index >= 0:
            self.history_index -= 1
            if self.history_index >= 0:
                cmd = self.history[-(self.history_index + 1)]
            else:
                cmd = self.current_input
            self._replace_current_line(cmd)
    
    def _replace_current_line(self, text):
        """Replace the current input line (simplified)."""
        # This is a simplified version - full implementation would track cursor position.
        # For now, we send a series of backspaces + new text.
        # A better approach is to store the current line and redraw it.
        pass  # Placeholder for full cursor management
    
    # -------------------- Public API --------------------
    def execute_command(self, cmd):
        """Execute a command directly in the terminal."""
        if self.is_running:
            self._write_input(cmd + '\r')
    
    def set_working_directory(self, path):
        """Set the working directory (cd)."""
        self.current_dir = path
        if self.is_running:
            self.execute_command(f'cd "{path}"')
    
    def kill(self):
        """Kill the terminal process."""
        self.is_running = False
        try:
            if hasattr(self, 'master_fd'):
                os.close(self.master_fd)
            if hasattr(self, 'pid'):
                os.kill(self.pid, 9)
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass
    
    def clear(self):
        """Clear the terminal output."""
        self.output.delete('1.0', 'end')


# -------------------- Standalone Test --------------------
if __name__ == '__main__':
    root = tk.Tk()
    root.title("Terminal Widget Test")
    root.geometry("800x500")
    
    term = TerminalWidget(root)
    term.pack(fill='both', expand=True)
    
    # Simple exit button
    btn = tk.Button(root, text="Exit", command=root.destroy)
    btn.pack()
    
    root.mainloop()