#!/usr/bin/env python3
"""
Module: archive_tools
Generated for TechDrive 500
Category: Archive Tools

Real archive creation/extraction. Zip/Unzip/Tar/Untar/Gzip/Gunzip use
Python's stdlib (zipfile/tarfile/gzip) so they work on any OS with no
extra dependency. 7z uses the py7zr package if installed, else shells
out to a 7-Zip install if one is found. RAR/UnRAR require WinRAR/unrar
(proprietary, not bundled) — if not found, this says so plainly instead
of pretending to work.
"""

import os
import shutil
import platform
import subprocess
import zipfile
import tarfile
import gzip
from gui.tk_dialogs import filedialog, messagebox
from gui.tool_view import CardPanel

try:
    import py7zr
except ImportError:
    py7zr = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------

def _pick_source(multiple=False, title="Choose file(s)"):
    if multiple:
        return filedialog.askopenfilenames(title=title)
    return filedialog.askopenfilename(title=title)


def _pick_folder(title="Choose a folder"):
    return filedialog.askdirectory(title=title)


def _pick_save(title, defaultext, filetypes):
    return filedialog.asksaveasfilename(title=title, defaultextension=defaultext, filetypes=filetypes)


def _find_exe(names):
    """Search PATH plus common Windows install locations for the first
    matching executable name; return its full path or None."""
    for name in names:
        found = shutil.which(name)
        if found:
            return found
    if IS_WINDOWS:
        candidates = [
            r"C:\Program Files\7-Zip\7z.exe",
            r"C:\Program Files (x86)\7-Zip\7z.exe",
            r"C:\Program Files\WinRAR\Rar.exe",
            r"C:\Program Files (x86)\WinRAR\Rar.exe",
            r"C:\Program Files\WinRAR\UnRAR.exe",
            r"C:\Program Files (x86)\WinRAR\UnRAR.exe",
        ]
        for c in candidates:
            if any(os.path.basename(c).lower() == os.path.basename(n).lower() for n in names) and os.path.exists(c):
                return c
    return None


def _dir_size_and_count(folder):
    total = 0
    count = 0
    for dirpath, _, filenames in os.walk(folder):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            try:
                total += os.path.getsize(full)
                count += 1
            except OSError:
                continue
    return total, count


# ---------------------------------------------------------------------------
# Zip / Unzip — zipfile (stdlib, cross-platform)
# ---------------------------------------------------------------------------





# ---------------------------------------------------------------------------
# RAR / UnRAR — require WinRAR/unrar (proprietary); use if found
# ---------------------------------------------------------------------------





# ---------------------------------------------------------------------------
# 7z / Un7z — py7zr if installed, else shell out to a 7-Zip install
# ---------------------------------------------------------------------------





# ---------------------------------------------------------------------------
# Tar / Untar — tarfile (stdlib), with optional gzip compression
# ---------------------------------------------------------------------------





# ---------------------------------------------------------------------------
# Gzip / Gunzip — single-file gzip compression (stdlib)
# ---------------------------------------------------------------------------



