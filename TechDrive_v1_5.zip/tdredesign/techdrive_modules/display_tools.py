#!/usr/bin/env python3
r"""
techdrive_modules/display_tools.py - Display Tools category
================================================================
Real display diagnostics/utilities. Resolution and refresh rate are
read (and can be changed) with Win32's EnumDisplaySettings /
ChangeDisplaySettings via ctypes - no external dependency needed.
Screen capture/recording use Pillow's ImageGrab (already a dependency
of this build); wallpaper uses SystemParametersInfoW; night mode
applies a warm gamma ramp directly (no registry hacking needed);
color calibration and DPI settings link out to the matching built-in
Windows tools (dccw.exe / ms-settings) since those are the correct,
supported way to change them.
"""

import ctypes
import os
import platform
import subprocess
import time
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import messagebox, filedialog
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0

ENUM_CURRENT_SETTINGS = -1
CDS_UPDATEREGISTRY = 0x01
DISP_CHANGE_SUCCESSFUL = 0


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows display APIs)."


def _run(args, timeout=20):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip() or f"(no output, exit code {r.returncode})"
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Operation timed out."
    except Exception as e:
        return f"Error: {e}"


def _powershell(script, timeout=20):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


class _DEVMODE(ctypes.Structure):
    _fields_ = [
        ("dmDeviceName", ctypes.c_wchar * 32), ("dmSpecVersion", ctypes.c_ushort),
        ("dmDriverVersion", ctypes.c_ushort), ("dmSize", ctypes.c_ushort),
        ("dmDriverExtra", ctypes.c_ushort), ("dmFields", ctypes.c_ulong),
        ("dmOrientation", ctypes.c_short), ("dmPaperSize", ctypes.c_short),
        ("dmPaperLength", ctypes.c_short), ("dmPaperWidth", ctypes.c_short),
        ("dmScale", ctypes.c_short), ("dmCopies", ctypes.c_short),
        ("dmDefaultSource", ctypes.c_short), ("dmPrintQuality", ctypes.c_short),
        ("dmColor", ctypes.c_short), ("dmDuplex", ctypes.c_short),
        ("dmYResolution", ctypes.c_short), ("dmTTOption", ctypes.c_short),
        ("dmCollate", ctypes.c_short), ("dmFormName", ctypes.c_wchar * 32),
        ("dmLogPixels", ctypes.c_ushort), ("dmBitsPerPel", ctypes.c_ulong),
        ("dmPelsWidth", ctypes.c_ulong), ("dmPelsHeight", ctypes.c_ulong),
        ("dmDisplayFlags", ctypes.c_ulong), ("dmDisplayFrequency", ctypes.c_ulong),
        ("dmICMMethod", ctypes.c_ulong), ("dmICMIntent", ctypes.c_ulong),
        ("dmMediaType", ctypes.c_ulong), ("dmDitherType", ctypes.c_ulong),
        ("dmReserved1", ctypes.c_ulong), ("dmReserved2", ctypes.c_ulong),
        ("dmPanningWidth", ctypes.c_ulong), ("dmPanningHeight", ctypes.c_ulong),
    ]


def _current_devmode():
    dm = _DEVMODE()
    dm.dmSize = ctypes.sizeof(_DEVMODE)
    if not ctypes.windll.user32.EnumDisplaySettingsW(None, ENUM_CURRENT_SETTINGS, ctypes.byref(dm)):
        return None
    return dm


def _enum_modes():
    modes = []
    i = 0
    dm = _DEVMODE()
    dm.dmSize = ctypes.sizeof(_DEVMODE)
    while ctypes.windll.user32.EnumDisplaySettingsW(None, i, ctypes.byref(dm)):
        modes.append((dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency))
        i += 1
    return sorted(set(modes))


CATALOGUE = []


# ---------------------------------------------------------------------------
# Display Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Resolution
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Refresh Rate
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Color Calibration
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Multi-Monitor
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Screen Capture
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Screen Recording
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Night Mode
# ---------------------------------------------------------------------------
_ORIGINAL_GAMMA = None




# ---------------------------------------------------------------------------
# Wallpaper
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# DPI Settings
# ---------------------------------------------------------------------------
