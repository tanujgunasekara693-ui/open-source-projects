#!/usr/bin/env python3
"""
Module: network_monitor
Generated for TechDrive 500
Category: Network Monitor
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel, PanelTextProxy
from gui.live_chart import LiveChart, LiveSampler

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def _needs_psutil():
    return "Requires the 'psutil' package (pip install psutil)."


CATALOGUE = []




















