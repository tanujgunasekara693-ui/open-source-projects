#!/usr/bin/env python3
"""
Module: privacy_tools
Category: Privacy Tools

Every tool below does a real scan of the current machine - actual browser
profile folders, actual temp directories, the actual clipboard, actual
Windows/Linux logs. Nothing here fabricates numbers. Deletion is always a
separate, explicit, confirmed action - scanning only ever reports what it
found.
"""

import os
import glob
import sqlite3
import shutil
import platform
import subprocess
import tempfile
from datetime import datetime
from gui.tk_dialogs import messagebox
from gui.tool_view import CardPanel, PanelTextProxy

try:
    import winreg
except ImportError:
    winreg = None

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"
IS_LINUX = platform.system() == "Linux"


def bytes_fmt(n):
    n = float(n or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _home():
    return os.path.expanduser("~")


def _browser_roots():
    """Real, per-OS browser profile locations for the major Chromium
    browsers plus Firefox. Only paths that actually exist are returned."""
    h = _home()
    candidates = []
    if IS_WINDOWS:
        local = os.environ.get("LOCALAPPDATA", os.path.join(h, "AppData", "Local"))
        roaming = os.environ.get("APPDATA", os.path.join(h, "AppData", "Roaming"))
        candidates += [
            ("Chrome", os.path.join(local, "Google", "Chrome", "User Data")),
            ("Edge", os.path.join(local, "Microsoft", "Edge", "User Data")),
            ("Brave", os.path.join(local, "BraveSoftware", "Brave-Browser", "User Data")),
            ("Firefox", os.path.join(roaming, "Mozilla", "Firefox", "Profiles")),
        ]
    elif IS_MAC:
        ap = os.path.join(h, "Library", "Application Support")
        candidates += [
            ("Chrome", os.path.join(ap, "Google", "Chrome")),
            ("Edge", os.path.join(ap, "Microsoft Edge")),
            ("Brave", os.path.join(ap, "BraveSoftware", "Brave-Browser")),
            ("Firefox", os.path.join(h, "Library", "Application Support", "Firefox", "Profiles")),
        ]
    else:
        candidates += [
            ("Chrome", os.path.join(h, ".config", "google-chrome")),
            ("Chromium", os.path.join(h, ".config", "chromium")),
            ("Edge", os.path.join(h, ".config", "microsoft-edge")),
            ("Brave", os.path.join(h, ".config", "BraveSoftware", "Brave-Browser")),
            ("Firefox", os.path.join(h, ".mozilla", "firefox")),
        ]
    return [(name, path) for name, path in candidates if os.path.isdir(path)]


def _chromium_profiles(user_data_dir):
    """Profile dirs inside a Chromium 'User Data' root (Default, Profile 1...)."""
    out = []
    try:
        for name in os.listdir(user_data_dir):
            p = os.path.join(user_data_dir, name)
            if os.path.isdir(p) and (name == "Default" or name.startswith("Profile ")):
                out.append(p)
    except OSError:
        pass
    return out


def _dir_stats(path):
    """(file_count, total_bytes) for everything under path."""
    count, size = 0, 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                fp = os.path.join(root, f)
                size += os.path.getsize(fp)
                count += 1
            except OSError:
                pass
    return count, size


def _sqlite_row_count(db_path, table):
    """Row count from a sqlite file, copying it first since the browser
    usually has it locked while running."""
    if not os.path.exists(db_path):
        return None
    tmp = None
    try:
        tmp = db_path + f".tdscan{os.getpid()}.tmp"
        shutil.copy2(db_path, tmp)
        con = sqlite3.connect(tmp)
        try:
            # SQLite parameters cannot represent identifiers. `table` is supplied only
            # from this module's fixed internal table list, never from user input.
            cur = con.execute(f"SELECT COUNT(*) FROM {table}")
            return cur.fetchone()[0]
        finally:
            con.close()
    except Exception:
        return None
    finally:
        if tmp and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def _confirm(title, msg):
    try:
        return messagebox.askyesno(title, msg)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 1. Privacy Cleaner - combined overview across every category below
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 2. Browser Cache
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 3. Cookies
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 4. History Cleaner
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 5. Recent Documents
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 6. Run History (Windows Run-dialog MRU)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 7. Temp Files
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 8. Clipboard
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 9. DNS Cache
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 10. Windows Logs (Event Log on Windows, journalctl/syslog elsewhere)
# ---------------------------------------------------------------------------

