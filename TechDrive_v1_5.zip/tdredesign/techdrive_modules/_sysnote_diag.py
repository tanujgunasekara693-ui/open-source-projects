"""Ported from SysNote Corner (sysnote.py) — pure data-gathering functions
only, copied over logic-for-logic (no behavior changes).

These were the only parts of sysnote.py suitable for a direct port: plain
functions that gather info and return it, with no dependency on sysnote's
own global Tk root/widgets/tray/config state. Everything past this point
in the original file (the corner-overlay window, system tray icon, notes
app, alert loop, snapshot diff, benchmark, live/history graphs, process
manager) is built around a single always-running root window and global
mutable state, which doesn't map onto TechDrive's "one panel per click"
plugin model — see SYSNOTE_PORT_README.md for the full breakdown of what
was and wasn't ported and why.

Optional-dependency pattern kept identical to the original: WMI/winreg/
pywin32 are Windows-only and everything here degrades to "N/A" / empty
results rather than raising when they're unavailable.
"""
import os
import platform
import socket
import subprocess
import time

import psutil

try:
    import wmi
    wmi_available = True
except ImportError:
    wmi_available = False

try:
    import winreg
    winreg_available = True
except ImportError:
    winreg_available = False

try:
    import win32com.client
    wu_available = True
except ImportError:
    wu_available = False

try:
    import GPUtil
    gpu_available = True
except ImportError:
    gpu_available = False

STARTUP_RUN_PATH = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
STARTUP_DISABLED_PATH = r"SOFTWARE\SysNote\DisabledStartup"
SYSTEM_DRIVE = os.environ.get("SystemDrive", "C:") or "C:"


def get_cpu_name():
    if wmi_available:
        try:
            c = wmi.WMI()
            return c.Win32_Processor()[0].Name.strip()
        except Exception:
            pass
    return platform.processor() or "Unknown CPU"


def get_cpu_temp():
    try:
        temps = psutil.sensors_temperatures()
        if temps:
            for name, entries in temps.items():
                for entry in entries:
                    if 'cpu' in name.lower() or 'core' in name.lower():
                        return round(entry.current, 1)
    except Exception:
        pass
    if wmi_available:
        try:
            c = wmi.WMI(namespace="root\\wmi")
            t = c.MSAcpi_ThermalZoneTemperature()[0].CurrentTemperature / 10 - 273.15
            if 0 < t < 120:
                return round(t, 1)
        except Exception:
            pass
    return None


def get_gpu_info():
    if gpu_available:
        try:
            g = GPUtil.getGPUs()[0]
            return (g.name, round(g.load * 100, 1), g.temperature)
        except Exception:
            pass
    if wmi_available:
        try:
            c = wmi.WMI()
            for gpu in c.Win32_VideoController():
                if gpu.Name and 'microsoft' not in gpu.Name.lower():
                    return (gpu.Name.strip(), None, None)
        except Exception:
            pass
    return (None, None, None)


def get_os_info():
    if wmi_available:
        try:
            c = wmi.WMI()
            os_obj = c.Win32_OperatingSystem()[0]
            return f"{os_obj.Caption.replace('Microsoft ', '')} (build {os_obj.BuildNumber})"
        except Exception:
            pass
    return f"{platform.system()} {platform.release()}"


def get_motherboard_info():
    if wmi_available:
        try:
            c = wmi.WMI()
            board = c.Win32_BaseBoard()[0]
            return (board.Manufacturer, board.Product)
        except Exception:
            pass
    return ("N/A", "N/A")


def get_bios_version():
    if wmi_available:
        try:
            c = wmi.WMI()
            return c.Win32_BIOS()[0].SMBIOSBIOSVersion or c.Win32_BIOS()[0].Version
        except Exception:
            pass
    return "N/A"


def get_ram_details():
    if wmi_available:
        try:
            c = wmi.WMI()
            total = 0
            used = 0
            speed = None
            mem_type = None
            for mem in c.Win32_PhysicalMemory():
                used += 1
                if speed is None:
                    speed = mem.Speed
                if mem_type is None:
                    type_map = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5"}
                    mem_type = type_map.get(mem.MemoryType, f"Type {mem.MemoryType}")
            for array in c.Win32_PhysicalMemoryArray():
                total = array.MemoryDevices
            return (total, used, speed, mem_type)
        except Exception:
            pass
    return (None, None, None, None)


def get_drive_health(drive=None):
    if drive is None:
        drive = SYSTEM_DRIVE
    if not wmi_available:
        return "N/A"
    try:
        c = wmi.WMI()
        for disk in c.Win32_DiskDrive():
            for part in disk.associators("Win32_DiskDriveToDiskPartition"):
                for logical in part.associators("Win32_LogicalDiskToPartition"):
                    if logical.DeviceID == drive:
                        if disk.Status and "OK" in disk.Status:
                            return "Pass"
                        else:
                            return "Fail"
        return "N/A"
    except Exception:
        return "N/A"


def get_wifi_signal():
    try:
        output = subprocess.check_output(["netsh", "wlan", "show", "interfaces"], shell=False, text=True)
        for line in output.split('\n'):
            if 'Signal' in line:
                return line.split(':')[-1].strip().replace('%', '') + '%'
        return "Not connected"
    except Exception:
        return "N/A"


def get_windows_license():
    if not wmi_available:
        return ("N/A", "N/A")
    try:
        c = wmi.WMI()
        os_info = c.Win32_OperatingSystem()[0]
        activation = "Licensed" if os_info.Status == "OK" else os_info.Status
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
            product_id = winreg.QueryValueEx(key, "ProductId")[0]
            partial = "XXXXX-" + product_id.split("-")[-1]
        except Exception:
            partial = "Unknown"
        return (activation, partial)
    except Exception:
        return ("N/A", "N/A")


def get_bios_mode():
    if winreg_available:
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\SecureBoot\State")
            if winreg.QueryValueEx(key, "UEFISecureBootEnabled")[0] == 1:
                return "UEFI"
            else:
                return "Legacy"
        except Exception:
            pass
    if os.path.isdir(r"C:\Windows\Boot\EFI"):
        return "UEFI"
    return "Legacy (probably)"


def get_secure_boot_status():
    if winreg_available:
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\SecureBoot\State")
            enabled = winreg.QueryValueEx(key, "UEFISecureBootEnabled")[0]
            return "On" if enabled == 1 else "Off"
        except Exception:
            pass
    return "Unavailable"


def get_tpm_version():
    if wmi_available:
        try:
            c = wmi.WMI(namespace="root\\cimv2\\Security\\MicrosoftTpm")
            return c.Win32_Tpm()[0].SpecVersion
        except Exception:
            pass
    return "Not detected"


def get_directx_version():
    if winreg_available:
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\DirectX")
            return winreg.QueryValueEx(key, "Version")[0]
        except Exception:
            pass
    return "N/A"


def get_power_plan():
    try:
        output = subprocess.check_output(["powercfg", "/getactivescheme"], shell=False, text=True)
        if "(" in output and ")" in output:
            return output.split("(")[-1].split(")")[0].strip()
        return output.strip()
    except Exception:
        return "N/A"


def get_installed_software():
    software = []
    if not winreg_available:
        return ["Registry not available"]
    try:
        uninstall_key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, uninstall_key) as key:
            for i in range(winreg.QueryInfoKey(key)[0]):
                try:
                    subkey_name = winreg.EnumKey(key, i)
                    with winreg.OpenKey(key, subkey_name) as subkey:
                        name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                        if name:
                            software.append(name)
                except Exception:
                    continue
        uninstall_key_32 = r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, uninstall_key_32) as key:
            for i in range(winreg.QueryInfoKey(key)[0]):
                try:
                    subkey_name = winreg.EnumKey(key, i)
                    with winreg.OpenKey(key, subkey_name) as subkey:
                        name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                        if name:
                            software.append(name)
                except Exception:
                    continue
        return sorted(set(software))[:50]
    except Exception:
        return ["Registry access failed"]


def get_fan_speeds():
    fans = []
    if wmi_available:
        try:
            c = wmi.WMI()
            for fan in c.Win32_Fan():
                name = fan.Name or "Fan"
                rpm = fan.DesiredSpeed if fan.DesiredSpeed else None
                if rpm:
                    fans.append((name, rpm))
        except Exception:
            pass
    return fans if fans else [("No fan data", "N/A")]


def get_voltages():
    voltages = []
    if wmi_available:
        try:
            c = wmi.WMI()
            for volt in c.Win32_VoltageProbe():
                name = volt.Name or "Voltage"
                val = volt.CurrentReading
                if val:
                    voltages.append((name, val))
        except Exception:
            pass
    return voltages if voltages else [("No voltage data", "N/A")]


def get_network_traffic():
    try:
        total = psutil.net_io_counters()
        return (total.bytes_sent, total.bytes_recv)
    except Exception:
        return (0, 0)


def get_event_log_structured(severities=("Error", "Critical", "Warning", "Information"), limit=100):
    if not wmi_available:
        return []
    try:
        c = wmi.WMI()
        sev_clause = " OR ".join(f"Type='{s}'" for s in severities)
        query = f"SELECT * FROM Win32_NTLogEvent WHERE Logfile='System' AND ({sev_clause})"
        events = c.query(query)
        rows = []
        for ev in sorted(events, key=lambda x: x.TimeGenerated, reverse=True)[:limit]:
            time_str = ev.TimeGenerated.split('.')[0]
            rows.append((time_str, ev.Type, ev.SourceName, ev.Message or ""))
        return rows
    except Exception:
        return []


def get_windows_update_status():
    if not wu_available:
        return ("Install pywin32", "N/A")
    try:
        update_session = win32com.client.Dispatch("Microsoft.Update.Session")
        update_searcher = update_session.CreateUpdateSearcher()
        history = update_searcher.QueryHistory(0, 1)
        last_date = history[0].Date if history else "Never"
        search_result = update_searcher.Search("IsInstalled=0 and Type='Software'")
        pending = search_result.Updates.Count
        return (last_date, pending)
    except Exception:
        return ("Error fetching", "N/A")


def get_gpu_memory():
    if not wmi_available:
        return (None, None)
    try:
        c = wmi.WMI()
        for gpu in c.Win32_VideoController():
            if gpu.AdapterRAM:
                dedicated = round(gpu.AdapterRAM / (1024 ** 2))
            else:
                dedicated = None
            shared = None
            if hasattr(gpu, 'SharedSystemMemory'):
                shared = gpu.SharedSystemMemory
            return (dedicated, shared)
    except Exception:
        return (None, None)


def get_gpu_clocks():
    try:
        nvidia_smi = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=clocks.gr,clocks.mem", "--format=csv,noheader,nounits"],
            shell=False, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
        ).strip()
        if nvidia_smi:
            parts = nvidia_smi.split(',')
            if len(parts) == 2:
                return (parts[0].strip() + " MHz", parts[1].strip() + " MHz")
    except Exception:
        pass
    if wmi_available:
        try:
            c = wmi.WMI()
            for vc in c.Win32_VideoController():
                if hasattr(vc, 'CurrentClockSpeed'):
                    return (str(vc.CurrentClockSpeed) + " MHz", "N/A")
        except Exception:
            pass
    return ("N/A", "N/A")


def get_cpu_tdp():
    if wmi_available:
        try:
            c = wmi.WMI()
            for cpu in c.Win32_Processor():
                if hasattr(cpu, 'Power'):
                    return f"{cpu.Power} W"
        except Exception:
            pass
    return "N/A"


def get_monitor_refresh_depth():
    if not wmi_available:
        return ("N/A", "N/A")
    try:
        c = wmi.WMI()
        for vc in c.Win32_VideoController():
            refresh = vc.CurrentRefreshRate
            bits = vc.CurrentBitsPerPixel
            if refresh and bits:
                return (refresh, bits)
        return ("N/A", "N/A")
    except Exception:
        return ("N/A", "N/A")


def get_display_resolution():
    if wmi_available:
        try:
            c = wmi.WMI()
            for vc in c.Win32_VideoController():
                if vc.CurrentHorizontalResolution and vc.CurrentVerticalResolution:
                    return f"{vc.CurrentHorizontalResolution}x{vc.CurrentVerticalResolution}"
        except Exception:
            pass
    return "N/A"


def get_audio_device():
    if wmi_available:
        try:
            c = wmi.WMI()
            for dev in c.Win32_SoundDevice():
                if dev.Name:
                    return dev.Name.strip()
        except Exception:
            pass
    return "N/A"


def get_virtualization():
    if wmi_available:
        try:
            c = wmi.WMI()
            for cpu in c.Win32_Processor():
                if cpu.VirtualizationFirmwareEnabled:
                    return "Enabled"
        except Exception:
            pass
    return "Unknown"


def get_battery():
    bat = psutil.sensors_battery()
    if bat:
        return f"{bat.percent}% {'(Charging)' if bat.power_plugged else ''}"
    return "No battery"


def get_uptime():
    boot = psutil.boot_time()
    uptime = time.time() - boot
    hours, rem = divmod(int(uptime), 3600)
    minutes, _ = divmod(rem, 60)
    return f"{hours}h {minutes}m"


def get_network_info():
    try:
        for iface, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith("127."):
                    return (iface, addr.address)
    except Exception:
        pass
    return ("Not connected", "N/A")


def list_startup_entries():
    entries = []
    if not winreg_available:
        return entries
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_RUN_PATH) as key:
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                    entries.append(("HKCU", name, value, True))
                    i += 1
                except OSError:
                    break
    except Exception:
        pass
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, STARTUP_RUN_PATH) as key:
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                    entries.append(("HKLM", name, value, True))
                    i += 1
                except OSError:
                    break
    except Exception:
        pass
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_DISABLED_PATH) as key:
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                    entries.append(("HKCU", name, value, False))
                    i += 1
                except OSError:
                    break
    except Exception:
        pass
    return entries


def disable_startup_entry(name, value):
    if not winreg_available:
        return False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_RUN_PATH, 0, winreg.KEY_SET_VALUE) as key:
            try:
                winreg.DeleteValue(key, name)
            except Exception:
                pass
        backup = winreg.CreateKey(winreg.HKEY_CURRENT_USER, STARTUP_DISABLED_PATH)
        winreg.SetValueEx(backup, name, 0, winreg.REG_SZ, value)
        return True
    except Exception:
        return False


def enable_startup_entry(name, value):
    if not winreg_available:
        return False
    try:
        run_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, STARTUP_RUN_PATH)
        winreg.SetValueEx(run_key, name, 0, winreg.REG_SZ, value)
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_DISABLED_PATH, 0, winreg.KEY_SET_VALUE) as backup:
            try:
                winreg.DeleteValue(backup, name)
            except Exception:
                pass
        return True
    except Exception:
        return False


def build_report():
    mem = psutil.virtual_memory()
    # "C:" alone means "current dir on C:" and fails off-Windows; use a real root path.
    _disk_root = (SYSTEM_DRIVE.rstrip("\\/") + "\\") if os.name == "nt" else os.path.abspath(os.sep)
    disk = psutil.disk_usage(_disk_root)
    gpu = get_gpu_info()
    lines = [
        "=" * 50,
        f"SysNote Report - {__import__('datetime').datetime.now()}",
        "=" * 50,
        f"CPU: {get_cpu_name()}",
        f"CPU Usage: {psutil.cpu_percent()}%",
        f"CPU Temp: {get_cpu_temp() or 'N/A'}°C",
        f"RAM: {mem.used // (1024 ** 2)} MB / {mem.total // (1024 ** 2)} MB ({mem.percent}%)",
        f"Disk {SYSTEM_DRIVE}: {disk.used // (1024 ** 3)} GB / {disk.total // (1024 ** 3)} GB ({disk.percent}%)",
        f"GPU: {gpu[0] or 'Not detected'}  Load: {gpu[1] if gpu[1] is not None else 'N/A'}%  "
        f"Temp: {gpu[2] if gpu[2] is not None else 'N/A'}°C",
        f"Network: {get_network_info()[1]}",
        f"OS: {get_os_info()}",
    ]
    return "\n".join(lines)
