#!/usr/bin/env python3
r"""
techdrive_modules/boot_tools.py - Boot Tools category
======================================================================
Real, working boot diagnostics/management built entirely on Windows'
own built-in command-line tools - no simulated output:

- bcdedit: the real Boot Configuration Data editor (boot entries,
  default OS, timeout, detailed loader settings).
- reagentc: the real Windows Recovery Environment status tool.
- PowerShell Get-WinEvent: reads real System/Diagnostics-Performance
  event log entries for shutdown/boot history and measured boot times.
- chkdsk: the real disk-check utility, used read-only unless the user
  explicitly opts into scheduling a repair pass at next restart.
- sfc: the real System File Checker, a standard first step for
  boot-adjacent corruption issues.

Anything that needs elevated/admin rights (most bcdedit writes,
scheduling chkdsk /f, sfc) reports the real Windows error back rather
than silently pretending to succeed.
"""

import platform
import re
import subprocess
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []


def _run(args, timeout=30):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except FileNotFoundError:
        return False, f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except Exception as e:
        return False, str(e)


def _powershell(script, timeout=30):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------



















