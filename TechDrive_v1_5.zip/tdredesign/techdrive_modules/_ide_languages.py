import re
import os

LANG_DEFS = {
    'html': {
        'comments': re.compile(r'<!--.*?-->', re.DOTALL),
        'tags': re.compile(r'</?[\w-]+', re.IGNORECASE),
        'attributes': re.compile(r'\b([\w-]+)\s*=', re.IGNORECASE),
        'strings': re.compile(r'"[^"]*"|\'[^\']*\''),
    },
    'css': {
        'comments': re.compile(r'/\*.*?\*/', re.DOTALL),
        'selectors': re.compile(r'[.#@]?[\w-]+(?=\s*\{)', re.IGNORECASE),
        'properties': re.compile(r'[\w-]+\s*:', re.IGNORECASE),
        'strings': re.compile(r'"[^"]*"|\'[^\']*\''),
        'numbers': re.compile(r'\b\d+(\.\d+)?(px|em|%|vh|vw|rem)?\b'),
        'functions': re.compile(r'\b(url|rgb|rgba|hsl|hsla|var|calc)\s*\(', re.IGNORECASE),
    },
    'javascript': {
        'comments': re.compile(r'//.*|/\*.*?\*/', re.DOTALL),
        'keywords': re.compile(r'\b(var|let|const|function|if|else|for|while|do|switch|case|break|continue|return|new|typeof|this|class|extends|super|import|export|from|async|await|yield|try|catch|finally|throw)\b'),
        'builtins': re.compile(r'\b(console|document|window|Math|Array|Object|String|Number|Boolean|JSON|Promise|fetch|setTimeout|setInterval|addEventListener|querySelector|querySelectorAll|getElementById|createElement|appendChild|removeChild)\b'),
        'strings': re.compile(r'`[^`]*`|"[^"]*"|\'[^\']*\''),
        'numbers': re.compile(r'\b\d+(\.\d+)?\b'),
        'operators': re.compile(r'[+\-*/%=<>!&|^~?:]+'),
    },
    'python': {
        'comments': re.compile(r'#.*'),
        'keywords': re.compile(r'\b(False|None|True|and|as|assert|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b'),
        'builtins': re.compile(r'\b(print|len|range|int|str|float|list|dict|set|tuple|type|super|open|abs|all|any|bin|bool|chr|classmethod|compile|complex|delattr|dir|divmod|enumerate|eval|exec|filter|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|isinstance|issubclass|iter|locals|map|max|memoryview|min|next|object|oct|ord|pow|property|repr|reversed|round|setattr|slice|sorted|staticmethod|sum|vars|zip)\b'),
        'strings': re.compile(r'(\"\"\"[\s\S]*?\"\"\"|\'\'\'[\s\S]*?\'\'\'|"[^"]*"|\'[^\']*\')'),
        'decorators': re.compile(r'@\w+'),
        'numbers': re.compile(r'\b\d+(\.\d+)?(e[+-]?\d+)?j?\b'),
    },
    'java': {
        'comments': re.compile(r'//.*|/\*.*?\*/', re.DOTALL),
        'keywords': re.compile(r'\b(abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|native|new|package|private|protected|public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while|true|false|null)\b'),
        'builtins': re.compile(r'\b(System|String|Math|Object|ArrayList|HashMap)\b'),
        'strings': re.compile(r'"[^"]*"'),
        'numbers': re.compile(r'\b\d+(\.\d+)?(f|d|l)?\b'),
        'annotations': re.compile(r'@\w+'),
    },
    'c': {
        'comments': re.compile(r'//.*|/\*.*?\*/', re.DOTALL),
        'keywords': re.compile(r'\b(auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while)\b'),
        'preprocessor': re.compile(r'#\s*(include|define|ifdef|ifndef|endif|else|pragma)\b'),
        'strings': re.compile(r'"[^"]*"'),
        'numbers': re.compile(r'\b\d+(\.\d+)?(f|l|u|ll)?\b'),
    },
    'cpp': {
        'comments': re.compile(r'//.*|/\*.*?\*/', re.DOTALL),
        'keywords': re.compile(r'\b(alignas|alignof|and|and_eq|asm|auto|bitand|bitor|bool|break|case|catch|char|char8_t|char16_t|char32_t|class|compl|concept|const|consteval|constexpr|constinit|const_cast|continue|co_await|co_return|co_yield|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|false|float|for|friend|goto|if|inline|int|long|mutable|namespace|new|noexcept|not|not_eq|nullptr|operator|or|or_eq|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|true|try|typedef|typeid|typename|union|unsigned|using|virtual|void|volatile|wchar_t|while|xor|xor_eq)\b'),
        'preprocessor': re.compile(r'#\s*(include|define|ifdef|ifndef|endif|else|pragma|error|line)\b'),
        'strings': re.compile(r'"[^"]*"'),
        'numbers': re.compile(r'\b\d+(\.\d+)?(f|l|u|ll)?\b'),
    },
    'powershell': {
        'comments': re.compile(r'#.*'),
        'keywords': re.compile(r'\b(Begin|Break|Catch|Class|Continue|Data|Define|Do|Dynamicparam|Else|Elseif|End|Exit|Filter|Finally|For|ForEach|From|Function|If|In|InlineScript|Parallel|Param|Process|Return|Sequence|Switch|Throw|Trap|Try|Until|Using|Var|While|Workflow)\b'),
        'cmdlets': re.compile(r'\b(Get-|Set-|New-|Remove-|Write-|Out-|Invoke-|Start-|Stop-|Test-|Import-|Export-|ConvertTo-|ConvertFrom-)\w+\b', re.IGNORECASE),
        'strings': re.compile(r'"[^"]*"|\'[^\']*\''),
        'variables': re.compile(r'\$\w+'),
    },
    'json': {
        'strings': re.compile(r'"[^"]*"'),
        'numbers': re.compile(r'\b-?\d+(\.\d+)?([eE][+-]?\d+)?\b'),
        'keywords': re.compile(r'\b(true|false|null)\b'),
    },
    'batch': {
        'comments': re.compile(r'(?:rem |::).*', re.IGNORECASE),
        'keywords': re.compile(r'\b(call|echo|set|if|else|for|goto|pause|exit|start|cd|md|rd|del|copy|move|ren|type|cls|title|color|ver|vol|date|time|path|prompt|pushd|popd|assoc|ftype|shift|errorlevel|choice|find|findstr|more|sort)\b', re.IGNORECASE),
        'strings': re.compile(r'"[^"]*"'),
        'variables': re.compile(r'%[^%]+%'),
    },
    'assembly': {
        'comments': re.compile(r';.*'),
        'keywords': re.compile(r'\b(mov|add|sub|mul|div|inc|dec|and|or|xor|not|shl|shr|jmp|je|jne|jg|jl|call|ret|push|pop|int|nop|db|dw|dd|equ|section|global|extern|lea|cmp|test)\b', re.IGNORECASE),
        'numbers': re.compile(r'\b0[xX][0-9a-fA-F]+\b|\b\d+\b'),
        'strings': re.compile(r'"[^"]*"|\'[^\']*\''),
    },
    'makefile': {
        'comments': re.compile(r'#.*'),
        'targets': re.compile(r'^[\w.-]+:\s', re.MULTILINE),
        'variables': re.compile(r'\$\([\w]+\)|\$\{[\w]+\}|\$[\w]+'),
        'commands': re.compile(r'^\t.+', re.MULTILINE),
    },
    'txt': {}
}

LANG_EXT_MAP = {
    '.html': 'html', '.htm': 'html',
    '.css': 'css',
    '.js': 'javascript', '.mjs': 'javascript',
    '.py': 'python', '.pyw': 'python',
    '.java': 'java',
    '.c': 'c', '.h': 'c',
    '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp',
    '.ps1': 'powershell', '.psm1': 'powershell',
    '.json': 'json',
    '.bat': 'batch', '.cmd': 'batch',
    '.asm': 'assembly', '.s': 'assembly',
    'Makefile': 'makefile', '.mk': 'makefile',
    '.txt': 'txt', '': 'txt'
}

def get_lang_from_filename(filename):
    base = os.path.basename(filename)
    if base == 'Makefile':
        return 'makefile'
    ext = os.path.splitext(filename)[1].lower()
    return LANG_EXT_MAP.get(ext, 'txt')