#!/usr/bin/env python3
"""
Module: encryption_tools
Generated for TechDrive 500
Category: Encryption Tools

Real implementations:
  File/Folder Encryption & Decryption - password-based AES (Fernet, which is
    AES-128-CBC + HMAC-SHA256) with a per-file random salt and PBKDF2-HMAC-SHA256
    key derivation (200k iterations). Output files use a ".tdenc" extension;
    the salt is stored in a small header so decryption doesn't need it typed in.
  Disk Encryption Status / BitLocker Enable / BitLocker Disable / Recovery Key
    - real `manage-bde` calls (Windows' native BitLocker CLI).
  Certificate Check - real certificate store query via PowerShell.
  Audit Log - real Security event log query via PowerShell (Get-WinEvent).
"""

import base64
import os
import platform
import subprocess
from datetime import datetime, timedelta
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False

IS_WINDOWS = platform.system() == "Windows"
MAGIC = b"TDENC1\x00"       # 8-byte header magic
SALT_LEN = 16
KDF_ITERATIONS = 200_000


def bytes_fmt(n):
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Crypto core
# ---------------------------------------------------------------------------
def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=KDF_ITERATIONS)
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def _encrypt_file(path, password):
    """Encrypt `path` -> `path + '.tdenc'`. Returns (ok, message_or_output_path)."""
    if not os.path.isfile(path):
        return False, f"Not a file: {path}"
    salt = os.urandom(SALT_LEN)
    key = _derive_key(password, salt)
    f = Fernet(key)
    with open(path, "rb") as fh:
        data = fh.read()
    token = f.encrypt(data)
    out_path = path + ".tdenc"
    with open(out_path, "wb") as fh:
        fh.write(MAGIC)
        fh.write(salt)
        fh.write(token)
    return True, out_path


def _decrypt_file(path, password):
    """Decrypt a .tdenc file. Returns (ok, message_or_output_path)."""
    if not os.path.isfile(path):
        return False, f"Not a file: {path}"
    with open(path, "rb") as fh:
        raw = fh.read()
    if not raw.startswith(MAGIC):
        return False, "Not a TechDrive-encrypted file (missing header) - wrong file selected?"
    salt = raw[len(MAGIC):len(MAGIC) + SALT_LEN]
    token = raw[len(MAGIC) + SALT_LEN:]
    key = _derive_key(password, salt)
    f = Fernet(key)
    try:
        data = f.decrypt(token)
    except InvalidToken:
        return False, "Wrong password (or the file is corrupted/tampered)."
    out_path = path[:-len(".tdenc")] if path.endswith(".tdenc") else path + ".decrypted"
    if os.path.exists(out_path):
        base, ext = os.path.splitext(out_path)
        out_path = f"{base}.decrypted{ext}"
    with open(out_path, "wb") as fh:
        fh.write(data)
    return True, out_path


def _ask_password(prompt="Password", confirm=False):
    pw = simpledialog.askstring("TechDrive", prompt, show="*")
    if not pw:
        return None
    if confirm:
        pw2 = simpledialog.askstring("TechDrive", "Confirm password", show="*")
        if pw != pw2:
            messagebox.showerror("TechDrive", "Passwords didn't match.")
            return None
    return pw


def _bde(args, timeout=60):
    try:
        r = subprocess.run(["manage-bde"] + args, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode, out.strip()
    except FileNotFoundError:
        return -1, "manage-bde.exe not found (BitLocker isn't available on this edition of Windows)."
    except subprocess.TimeoutExpired:
        return -1, "manage-bde timed out."
    except Exception as e:
        return -1, f"{type(e).__name__}: {e}"


def _ask_drive_letter():
    d = simpledialog.askstring("TechDrive", "Drive letter (e.g. D):")
    if not d:
        return None
    d = d.strip().rstrip("\\").rstrip(":").upper()
    if len(d) != 1 or not d.isalpha():
        messagebox.showerror("TechDrive", "Enter a single drive letter, e.g. D")
        return None
    return d


# ---------------------------------------------------------------------------
# File Encryption / Decryption
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Folder Encryption / Decryption
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Disk Encryption Status
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# BitLocker Enable / Disable
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Recovery Key
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Certificate Check
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Audit Log
# ---------------------------------------------------------------------------
