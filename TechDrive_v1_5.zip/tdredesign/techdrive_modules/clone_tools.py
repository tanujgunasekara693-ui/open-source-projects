#!/usr/bin/env python3
"""
techdrive_modules/clone_tools.py - Cloning & Imaging category
=============================================================
Real sector-level disk cloning and imaging, implemented with direct block
reads/writes (no external imaging tool required):

  Drive to Drive Clone   physical drive -> physical drive, sector by sector
  Create Disk Image      physical drive or volume -> .img (optional gzip)
  Restore Disk Image     .img(.gz) -> physical drive
  Volume File Clone      file-level copy of a mounted volume/folder
  Clone Verify           SHA-256 compare of source vs target

Every job runs on a worker thread with a live MB/s graph, byte counter,
ETA and a working Cancel button. Raw device access requires elevation:
Administrator on Windows, root on Linux. The panel checks that up front
and tells you instead of failing halfway through.
"""

import ctypes
import gzip
import hashlib
import os
import platform
import threading
import time
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog, messagebox

from gui.live_chart import LiveChart
from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell

IS_WINDOWS = platform.system() == "Windows"
CHUNK = 8 * 1024 * 1024

CATALOGUE = []


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def is_elevated():
    try:
        if IS_WINDOWS:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def device_size(path):
    """Size in bytes of a raw device / file."""
    try:
        if os.path.isfile(path):
            return os.path.getsize(path)
        with open(path, "rb") as fh:
            return fh.seek(0, os.SEEK_END) or fh.tell()
    except Exception:
        return 0


class JobUI:
    """Progress graph + counters + cancel, shared by every clone job."""

    def __init__(self, app, parent):
        self.app = app
        self.theme = app.theme
        self.cancel = threading.Event()
        self.chart = LiveChart(parent, self.theme, [("Speed", "#2ecc71")], y_max=None,
                               y_suffix=" MB/s", title="Copy throughput", height=150)
        self.chart.pack(fill="both", expand=True, pady=(8, 4))

        bar_wrap = tk.Frame(parent, bg=self.theme["BG"])
        bar_wrap.pack(fill="x", pady=(4, 2))
        self.track = tk.Frame(bar_wrap, bg=self.theme["BG_LIGHT"], height=18)
        self.track.pack(fill="x")
        self.track.pack_propagate(False)
        self.fill = tk.Frame(self.track, bg=self.theme["ACCENT"])
        self.fill.place(relx=0, rely=0, relwidth=0.0, relheight=1)
        self.pct_lbl = tk.Label(self.track, text="idle", bg=self.theme["BG_LIGHT"],
                                fg=self.theme["FG"], font=FONT_UI_BOLD)
        self.pct_lbl.place(relx=0.5, rely=0.5, anchor="center")

        self.status = tk.StringVar(value="Ready.")
        tk.Label(parent, textvariable=self.status, bg=self.theme["BG"], fg=self.theme["MUTED"],
                 font=FONT_UI, anchor="w", justify="left", wraplength=800).pack(fill="x", pady=(4, 0))

        self.log = tk.Text(parent, bg=self.theme["SURFACE"], fg=self.theme["TEXT_FG"],
                           font=FONT_MONO, height=8, wrap="word")
        self.log.pack(fill="x", pady=(6, 0))

    def cancel_button(self, parent):
        return tk.Button(parent, text="✕ Cancel", command=self.request_cancel,
                         bg=self.theme["BG_LIGHT"], fg=self.theme["FG"], relief="flat",
                         padx=12, pady=4)

    def request_cancel(self):
        self.cancel.set()
        self.write("Cancel requested - finishing the current block…")

    # thread-safe UI updates
    def write(self, msg):
        def go():
            if self.log.winfo_exists():
                self.log.insert("end", msg + "\n")
                self.log.see("end")
        self.app.after(0, go)

    def progress(self, done, total, speed_mbs, eta_s):
        def go():
            if not self.track.winfo_exists():
                self.cancel.set()
                return
            pct = (100.0 * done / total) if total else 0
            self.fill.place_configure(relwidth=max(0.001, min(1.0, pct / 100)))
            self.pct_lbl.config(text=f"{pct:.1f}%")
            self.chart.push({"Speed": speed_mbs})
            eta = "--" if eta_s is None else time.strftime("%H:%M:%S", time.gmtime(max(0, eta_s)))
            self.status.set(f"{hw.bytes_fmt(done)} of {hw.bytes_fmt(total)}  •  "
                            f"{speed_mbs:.1f} MB/s  •  ETA {eta}")
        self.app.after(0, go)

    def finish(self, msg, ok=True):
        def go():
            if not self.track.winfo_exists():
                return
            self.status.set(msg)
            self.pct_lbl.config(text="done" if ok else "stopped")
        self.app.after(0, go)
        self.write(msg)


def copy_stream(src_fh, dst_fh, total, ui, hash_it=False):
    """Block copy with live progress. Returns (bytes_copied, sha256|None)."""
    digest = hashlib.sha256() if hash_it else None
    done = 0
    start = time.time()
    window_bytes, window_start = 0, start
    while True:
        if ui.cancel.is_set():
            return done, (digest.hexdigest() if digest else None)
        block = src_fh.read(CHUNK)
        if not block:
            break
        dst_fh.write(block)
        if digest:
            digest.update(block)
        done += len(block)
        window_bytes += len(block)
        now = time.time()
        if now - window_start >= 0.5:
            speed = window_bytes / (now - window_start) / 1024 ** 2
            remaining = (total - done) if total else 0
            eta = (remaining / (window_bytes / (now - window_start))) if window_bytes else None
            ui.progress(done, total or done, speed, eta)
            window_bytes, window_start = 0, now
    ui.progress(done, total or done, done / max(0.001, time.time() - start) / 1024 ** 2, 0)
    return done, (digest.hexdigest() if digest else None)


def _disk_picker(app, parent, label, on_change=None):
    """Dropdown of real physical drives; returns (StringVar of path, refresh)."""
    row = tk.Frame(parent, bg=app.theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=app.theme["BG"], fg=app.theme["MUTED"], font=FONT_UI,
             width=14, anchor="w").pack(side="left")
    var = tk.StringVar()
    combo = ttk.Combobox(row, textvariable=var, width=76, state="readonly")
    combo.pack(side="left", fill="x", expand=True)
    mapping = {}

    def refresh():
        disks = hw.physical_disks()
        values = []
        mapping.clear()
        for d in disks:
            text = (f"{d.get('path')}  |  {d.get('model') or 'Unknown model'}  |  "
                    f"{hw.bytes_fmt(d.get('size', 0))}  |  {d.get('media','?')}  |  {d.get('bus','?')}")
            values.append(text)
            mapping[text] = d
        combo["values"] = values
        if values and not var.get():
            var.set(values[0])

    def selected():
        return mapping.get(var.get())

    tk.Button(row, text="⟳", command=refresh, bg=app.theme["BG_LIGHT"], fg=app.theme["FG"],
              relief="flat", padx=8).pack(side="left", padx=6)
    refresh()
    if on_change:
        combo.bind("<<ComboboxSelected>>", lambda e: on_change(selected()))
    return selected


def _elevation_banner(app, parent):
    if is_elevated():
        return
    tk.Label(parent,
             text=("⚠ Not running elevated. Raw drive cloning needs Administrator (Windows) or "
                   "root (Linux) - restart TechDrive elevated, otherwise the drive opens read-only "
                   "and the job will stop with a permission error."),
             bg=app.theme["BG"], fg=status_color("warn"), font=FONT_UI_BOLD,
             wraplength=800, justify="left").pack(anchor="w", pady=(2, 6))


def _confirm_destructive(target_desc):
    return messagebox.askyesno(
        "Confirm overwrite",
        f"This permanently overwrites EVERYTHING on:\n\n{target_desc}\n\n"
        "The target's current contents cannot be recovered afterwards.\n\nContinue?",
        icon="warning")


# ---------------------------------------------------------------------------
# Drive to drive
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Image create / restore
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# File-level volume clone
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Verify
# ---------------------------------------------------------------------------
