#!/usr/bin/env python3
r"""
techdrive_modules/virtual_disk_tools.py - Virtual Disk Tools category
========================================================================
Real, working virtual-disk management, entirely native to Windows -
no third-party tools to install, nothing to bundle.

VHD / VHDX (Microsoft's own formats) are handled with diskpart's
`create vdisk` / `attach vdisk` and PowerShell's `Convert-VHD`. That's
the only format supported here on purpose: VMware's VMDK, VirtualBox's
VDI and Parallels' format all need an actual third-party format engine
(qemu-img or the vendor's own tools) that Windows doesn't ship, and
this file deliberately doesn't depend on one - every button here works
out of the box on a stock Windows install.

Shared-VHDX (Load/Share Disks) and boot-mode conversion (mbr2gpt.exe)
need Hyper-V's PowerShell module and Windows' own mbr2gpt.exe
respectively; both checked for and reported on honestly if missing.
"""

import json
import os
import subprocess
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog

from gui.theme import FONT_UI, FONT_MONO
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.clone_tools import _disk_picker, _confirm_destructive
from techdrive_modules.partition_tools import (
    run_diskpart, _volume_picker, _confirm, _labeled_entry,
    _labeled_combo, _elevation_note, IS_WINDOWS,
)

CATALOGUE = []

# format label -> file extension (VHD/VHDX only - both native to Windows)
FORMATS = {
    "VHD (Virtual PC / Hyper-V)": "vhd",
    "VHDX (Virtual PC / Hyper-V)": "vhdx",
}


def hyperv_available():
    if not IS_WINDOWS:
        return False
    ok, out = hw.powershell("Get-Command Get-VM -ErrorAction SilentlyContinue | Select-Object -First 1")
    return ok and "Get-VM" in out


def _vm_picker(app, parent, label):
    row = tk.Frame(parent, bg=app.theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=app.theme["BG"], fg=app.theme["MUTED"], font=FONT_UI,
             width=16, anchor="w").pack(side="left")
    var = tk.StringVar()
    combo = ttk.Combobox(row, textvariable=var, width=40, state="readonly")
    combo.pack(side="left", fill="x", expand=True)

    def refresh():
        if not hyperv_available():
            combo["values"] = []
            return
        ok, out = hw.powershell("Get-VM | Select-Object Name,State | ConvertTo-Json -Compress")
        values = []
        if ok and out.strip().startswith(("[", "{")):
            try:
                data = json.loads(out)
                for v in (data if isinstance(data, list) else [data]):
                    values.append(f"{v.get('Name')}  ({v.get('State')})")
            except Exception:
                pass
        combo["values"] = values
        if values and not var.get():
            var.set(values[0])

    def selected():
        v = var.get()
        return v.split("  (")[0] if v else None

    tk.Button(row, text="⟳", command=refresh, bg=app.theme["BG_LIGHT"], fg=app.theme["FG"],
              relief="flat", padx=8).pack(side="left", padx=6)
    refresh()
    return selected


def _hyperv_missing_msg():
    return ("Hyper-V's PowerShell module isn't available on this machine. Enable the Hyper-V "
            "Windows feature (Control Panel > Programs > Turn Windows features on or off > "
            "Hyper-V) to use shared virtual disks.")


# ---------------------------------------------------------------------------
# Create Virtual Disk
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Open Virtual Disk
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Convert Virtual Disk Format (VHD <-> VHDX, via Hyper-V's own Convert-VHD)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Load Shared Disks (attach an existing shared VHDX to a VM)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Share Disks (mark an already-attached VHDX as shared)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Convert Boot Mode (BIOS/MBR <-> UEFI/GPT)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Reload Current Hard Disk
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Change Device State (enable/disable a disk device)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TRIM Optimization
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Refresh All Disks
# ---------------------------------------------------------------------------
