#!/usr/bin/env python3
"""
Module: ram_tools
Generated for TechDrive 500
Category: RAM Tools

All 10 tools below do real work (no canned/placeholder text):
  - RAM Info            -> wmic memorychip + psutil live totals
  - Benchmark            -> real sequential write/read/copy memory bandwidth test
  - Stress Test          -> allocates real memory, writes a pattern, verifies it
                            in a loop for a chosen duration/size, reports errors
  - Cache Cleaner        -> trims process working sets via the Windows API
                            (EmptyWorkingSet), reports MB reclaimed
  - Speed Test           -> read/write/copy throughput in MB/s, 3-pass average
  - Slot Info            -> physical DIMM slots, populated vs empty, per-slot
                            capacity/speed/manufacturer via WMI
  - Timings              -> real Speed/ConfiguredClockSpeed/Voltage from WMI;
                            explains why true CAS/tRCD/tRP/tRAS needs SPD
                            access that WMI does not expose
  - ECC Check            -> real Win32_PhysicalMemoryArray.MemoryErrorCorrection
  - Page File Manager    -> view current + configured page file(s), resize or
                            switch to system-managed with confirmation
  - Diagnostic Test      -> multi-check pass/warn/fail health report
"""

import os
import re
import ctypes
import time
import socket
import platform
import subprocess
import threading
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _wmic(cls, fields):
    """Run wmic and return a list of dicts, one per instance."""
    r = subprocess.run(["wmic", cls, "get", ",".join(fields), "/format:list"],
                        capture_output=True, text=True, timeout=20)
    rows, cur = [], {}
    for line in r.stdout.splitlines():
        line = line.strip()
        if not line:
            if cur:
                rows.append(cur)
                cur = {}
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            cur[k.strip()] = v.strip()
    if cur:
        rows.append(cur)
    return rows


def _ecc_text(code):
    table = {
        "1": "Other", "2": "Unknown", "3": "None", "4": "Parity",
        "5": "Single-bit ECC", "6": "Multi-bit ECC", "7": "CRC",
    }
    return table.get(str(code).strip(), f"Unknown ({code})")


def _mem_bandwidth_pass(size_mb=64):
    """One real write/read/copy pass over an in-memory buffer. Returns
    (write_MBps, read_MBps, copy_MBps, checksum)."""
    n = size_mb * 1024 * 1024
    src = bytearray(n)

    t0 = time.perf_counter()
    pattern = b"\xA5" * 4096
    mv = memoryview(src)
    for off in range(0, n, 4096):
        mv[off:off + 4096] = pattern
    t1 = time.perf_counter()
    write_mbps = size_mb / max(t1 - t0, 1e-9)

    t0 = time.perf_counter()
    checksum = 0
    for off in range(0, n, 4096):
        checksum = (checksum + mv[off]) & 0xFFFFFFFF
    t1 = time.perf_counter()
    read_mbps = size_mb / max(t1 - t0, 1e-9)

    t0 = time.perf_counter()
    dst = bytearray(n)
    dst[:] = src
    t1 = time.perf_counter()
    copy_mbps = size_mb / max(t1 - t0, 1e-9)

    del dst
    return write_mbps, read_mbps, copy_mbps, checksum


def _empty_working_sets():
    """Trim working sets of accessible processes via the real Windows API
    (psapi EmptyWorkingSet). Returns (ok_count, tried_count, before, after)
    as psutil virtual_memory() percent-used snapshots. Best-effort: most
    processes owned by other users/elevated will fail without admin, and
    that's reported honestly rather than faked."""
    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_SET_QUOTA = 0x0100
    kernel32 = ctypes.windll.kernel32
    psapi = ctypes.windll.psapi

    before = psutil.virtual_memory().percent if psutil else None
    ok, tried = 0, 0
    for p in (psutil.process_iter(["pid"]) if psutil else []):
        pid = p.info["pid"]
        if pid in (0, 4):
            continue
        tried += 1
        handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, False, pid)
        if not handle:
            continue
        try:
            if psapi.EmptyWorkingSet(handle):
                ok += 1
        except Exception:
            pass
        finally:
            kernel32.CloseHandle(handle)

    try:
        kernel32.SetProcessWorkingSetSize(kernel32.GetCurrentProcess(), -1, -1)
    except Exception:
        pass

    time.sleep(0.3)
    after = psutil.virtual_memory().percent if psutil else None
    return ok, tried, before, after


# ---------------------------------------------------------------------------
# 1. RAM Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 2. Benchmark
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 3. Stress Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 4. Cache Cleaner
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 5. Speed Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 6. Slot Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 7. Timings
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 8. ECC Check
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 9. Page File Manager
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 10. Diagnostic Test
# ---------------------------------------------------------------------------
