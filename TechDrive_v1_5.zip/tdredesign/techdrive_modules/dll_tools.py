#!/usr/bin/env python3
"""
Module: dll_tools
Generated for TechDrive 500
Category: DLL Tools
"""

import os
import re
import time
import socket
import struct
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

try:
    import ctypes
    from ctypes import wintypes
except ImportError:
    ctypes = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


def _pick_dll():
    return filedialog.askopenfilename(title="Choose a DLL", filetypes=[("DLL files", "*.dll"), ("All files", "*.*")])


def _get_file_version(path):
    """Read the FileVersion / ProductVersion strings from a PE file's version resource."""
    if not IS_WINDOWS or ctypes is None:
        return None
    try:
        size = ctypes.windll.version.GetFileVersionInfoSizeW(path, None)
        if not size:
            return None
        res = ctypes.create_string_buffer(size)
        ctypes.windll.version.GetFileVersionInfoW(path, 0, size, res)

        r = ctypes.c_void_p()
        l = ctypes.c_uint()
        ctypes.windll.version.VerQueryValueW(res, "\\", ctypes.byref(r), ctypes.byref(l))
        if not l.value:
            return None
        fixed = ctypes.cast(r, ctypes.POINTER(ctypes.c_uint * (l.value // 4))).contents
        ms, ls = fixed[3], fixed[4]  # FileVersionMS, FileVersionLS
        version = f"{ms >> 16}.{ms & 0xFFFF}.{ls >> 16}.{ls & 0xFFFF}"
        return version
    except Exception:
        return None


def _pe_machine_and_imports(path, max_imports=40):
    """Minimal PE header parse: machine type, subsystem, and imported DLL names (no external deps)."""
    try:
        with open(path, "rb") as f:
            data = f.read(4 * 1024 * 1024)  # cap read for very large files

        if data[:2] != b"MZ":
            return {"error": "Not a valid PE (missing MZ header)."}

        e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
        if data[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
            return {"error": "Not a valid PE (missing PE signature)."}

        machine, num_sections = struct.unpack_from("<HH", data, e_lfanew + 4)
        machine_map = {0x14c: "x86 (32-bit)", 0x8664: "x64 (64-bit)", 0xAA64: "ARM64", 0x1c0: "ARM"}
        machine_name = machine_map.get(machine, f"Unknown (0x{machine:x})")

        opt_header_offset = e_lfanew + 24
        magic = struct.unpack_from("<H", data, opt_header_offset)[0]
        is_pe32_plus = (magic == 0x20B)

        # Import table RVA lives in the data directory array within the optional header
        data_dir_offset = opt_header_offset + (112 if is_pe32_plus else 96)
        import_rva, import_size = struct.unpack_from("<II", data, data_dir_offset + 8)

        imports = []
        if import_rva:
            # Locate section containing the import RVA to translate RVA->file offset
            section_table_offset = opt_header_offset + struct.unpack_from("<H", data, e_lfanew + 20)[0]
            file_offset = None
            for i in range(num_sections):
                sec = section_table_offset + i * 40
                virt_size, virt_addr = struct.unpack_from("<II", data, sec + 8)
                raw_size, raw_ptr = struct.unpack_from("<II", data, sec + 16)
                if virt_addr <= import_rva < virt_addr + max(virt_size, raw_size):
                    file_offset = raw_ptr + (import_rva - virt_addr)
                    section_base_rva = virt_addr
                    section_base_ptr = raw_ptr
                    break
            if file_offset is not None:
                entry = file_offset
                count = 0
                while count < max_imports:
                    name_rva = struct.unpack_from("<I", data, entry + 12)[0]
                    if name_rva == 0:
                        break
                    name_off = section_base_ptr + (name_rva - section_base_rva)
                    end = data.find(b"\x00", name_off)
                    if end == -1 or name_off >= len(data):
                        break
                    dll_name = data[name_off:end].decode(errors="replace")
                    if dll_name:
                        imports.append(dll_name)
                    entry += 20
                    count += 1

        return {"machine": machine_name, "imports": imports}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# DLL Info
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Register (regsvr32 /s)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Unregister (regsvr32 /u /s)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Fixer — attempt re-register of a DLL plus sfc guidance
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Search — find DLLs by name pattern under a chosen folder
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Dependency — list DLL's own imports (what it depends on)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Conflict — find same-named DLLs in multiple locations (version conflicts)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Missing Fix — check if a named DLL exists anywhere on common paths / PATH
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Path Check — show DLL search order / PATH and check where a name resolves
# ---------------------------------------------------------------------------

