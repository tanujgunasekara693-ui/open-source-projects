#!/usr/bin/env python3
"""
Module: backup_tools
Generated for TechDrive 500
Category: Backup Tools

Real, working backups (no placeholders). Every tool here actually copies,
zips, exports, or snapshots real data to a destination the user picks.
"""

import os
import re
import time
import socket
import shutil
import zipfile
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('Backup Tools',
  '▥',
  ['System Backup',
   'File Backup',
   'Folder Backup',
   'Registry Backup',
   'Driver Backup',
   'User Data Backup',
   'Settings Backup'])]


def _timestamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _zip_folder(src_folder, dest_zip, progress_cb=None):
    file_count = 0
    total_bytes = 0
    src_folder = os.path.abspath(src_folder)
    with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for root, dirs, files in os.walk(src_folder):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, os.path.dirname(src_folder))
                try:
                    zf.write(full, arc)
                    sz = os.path.getsize(full)
                    total_bytes += sz
                    file_count += 1
                    if progress_cb:
                        progress_cb(file_count, full)
                except (OSError, PermissionError):
                    continue
    return file_count, total_bytes


def _zip_files(paths, dest_zip):
    file_count = 0
    total_bytes = 0
    with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for full in paths:
            if not os.path.isfile(full):
                continue
            try:
                zf.write(full, os.path.basename(full))
                total_bytes += os.path.getsize(full)
                file_count += 1
            except (OSError, PermissionError):
                continue
    return file_count, total_bytes


def _run_capture(cmd, timeout=120):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                            creationflags=subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "Operation timed out."
    except FileNotFoundError:
        return -1, f"Required tool not found: {cmd[0]}"
    except Exception as e:
        return -1, f"Error: {e}"


def tool_backup_tools_system_backup(self, frame):
    """System Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "System Backup",
                       "Bundles systeminfo, installed apps, and driver list into one archive.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        dest_zip = os.path.join(dest_dir, f"TechDrive_SystemBackup_{_timestamp()}.zip")
        tmp_dir = os.path.join(dest_dir, f"_sysbackup_tmp_{_timestamp()}")
        os.makedirs(tmp_dir, exist_ok=True)
        log = []
        try:
            if IS_WINDOWS:
                rc, out = _run_capture(["systeminfo"])
                with open(os.path.join(tmp_dir, "systeminfo.txt"), "w", encoding="utf-8", errors="ignore") as f:
                    f.write(out)
                log.append("systeminfo.txt saved." if rc == 0 else f"systeminfo failed: {out[:200]}")

                rc, out = _run_capture(["powershell", "-Command",
                                         "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName,DisplayVersion | Format-Table -AutoSize"])
                with open(os.path.join(tmp_dir, "installed_apps.txt"), "w", encoding="utf-8", errors="ignore") as f:
                    f.write(out)
                log.append("installed_apps.txt saved.")

                driver_dir = os.path.join(tmp_dir, "drivers")
                os.makedirs(driver_dir, exist_ok=True)
                rc, out = _run_capture(["dism", "/online", "/export-driver", f"/destination:{driver_dir}"], timeout=180)
                log.append("Drivers exported." if rc == 0 else f"Driver export needs admin rights: {out[:200]}")
            else:
                with open(os.path.join(tmp_dir, "systeminfo.txt"), "w") as f:
                    f.write(f"platform={platform.platform()}\nprocessor={platform.processor()}\n")
                log.append("Non-Windows: saved basic platform info only.")

            file_count, total_bytes = _zip_folder(tmp_dir, dest_zip)
            log.append(f"Archive: {dest_zip}")
            log.append(f"{file_count} files, {bytes_fmt(total_bytes)}")
            return "\n".join(log)
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_backup_tools_file_backup(self, frame):
    """File Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "File Backup",
                       "Pick one or more files and zip them to a destination.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        files = filedialog.askopenfilenames(title="Select files to back up")
        if not files:
            return "Cancelled."
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        dest_zip = os.path.join(dest_dir, f"TechDrive_FileBackup_{_timestamp()}.zip")
        count, total = _zip_files(files, dest_zip)
        return f"Backed up {count} file(s), {bytes_fmt(total)} -> {dest_zip}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_backup_tools_folder_backup(self, frame):
    """Folder Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "Folder Backup",
                       "Zips an entire folder tree, preserving structure.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        src = filedialog.askdirectory(title="Folder to back up")
        if not src:
            return "Cancelled."
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        base = os.path.basename(os.path.normpath(src))
        dest_zip = os.path.join(dest_dir, f"TechDrive_{base}_{_timestamp()}.zip")
        count, total = _zip_folder(src, dest_zip)
        return f"Backed up '{src}': {count} files, {bytes_fmt(total)} -> {dest_zip}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_backup_tools_registry_backup(self, frame):
    """Registry Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "Registry Backup",
                       "Exports the Windows registry (or one key) to a .reg file.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            return "Registry Backup is Windows-only (reg.exe is not available on this OS)."
        key = simpledialog.askstring(
            "Registry key",
            "Key to export (e.g. HKLM, HKCU, or HKLM\\SOFTWARE\\MyApp).\nLeave blank for full HKLM+HKCU export.")
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        results = []
        targets = [key] if key else ["HKLM", "HKCU"]
        for k in targets:
            safe = re.sub(r"[^A-Za-z0-9]+", "_", k)
            out_file = os.path.join(dest_dir, f"TechDrive_Registry_{safe}_{_timestamp()}.reg")
            rc, out = _run_capture(["reg", "export", k, out_file, "/y"], timeout=180)
            if rc == 0 and os.path.exists(out_file):
                results.append(f"{k} -> {out_file} ({bytes_fmt(os.path.getsize(out_file))})")
            else:
                results.append(f"{k} FAILED: {out[:300]}")
        return "\n".join(results)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_backup_tools_driver_backup(self, frame):
    """Driver Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "Driver Backup",
                       "Exports all installed third-party drivers via DISM.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            return "Driver Backup is Windows-only (uses DISM)."
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        target = os.path.join(dest_dir, f"TechDrive_Drivers_{_timestamp()}")
        os.makedirs(target, exist_ok=True)
        rc, out = _run_capture(["dism", "/online", "/export-driver", f"/destination:{target}"], timeout=300)
        if rc != 0:
            return f"Driver export failed (try running TechDrive as Administrator):\n{out[:500]}"
        n = sum(len(files) for _, _, files in os.walk(target))
        return f"Exported drivers to {target} ({n} files)."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)




def tool_backup_tools_user_data_backup(self, frame):
    """User Data Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "User Data Backup",
                       "Zips your Documents, Desktop, Pictures, Downloads, and Music folders.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        home = os.path.expanduser("~")
        candidates = ["Documents", "Desktop", "Pictures", "Downloads", "Music", "Videos"]
        folders = [os.path.join(home, c) for c in candidates if os.path.isdir(os.path.join(home, c))]
        if not folders:
            return f"No known user folders found under {home}."
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        dest_zip = os.path.join(dest_dir, f"TechDrive_UserData_{_timestamp()}.zip")
        total_count, total_bytes = 0, 0
        with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
            for folder in folders:
                base = os.path.basename(folder)
                for root, dirs, files in os.walk(folder):
                    for fn in files:
                        full = os.path.join(root, fn)
                        arc = os.path.join(base, os.path.relpath(full, folder))
                        try:
                            zf.write(full, arc)
                            total_bytes += os.path.getsize(full)
                            total_count += 1
                        except (OSError, PermissionError):
                            continue
        return (f"Backed up {len(folders)} folder(s): {', '.join(os.path.basename(f) for f in folders)}\n"
                f"{total_count} files, {bytes_fmt(total_bytes)} -> {dest_zip}")

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_backup_tools_settings_backup(self, frame):
    """Settings Backup — Backup Tools"""
    panel = CardPanel(frame, self.theme, "Settings Backup",
                       "Snapshots environment variables and TechDrive's own settings.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        dest_dir = filedialog.askdirectory(title="Choose backup destination")
        if not dest_dir:
            return "Cancelled."
        out_file = os.path.join(dest_dir, f"TechDrive_Settings_{_timestamp()}.txt")
        lines = [f"# TechDrive settings snapshot — {datetime.now().isoformat()}", "", "## Environment variables"]
        for k in sorted(os.environ.keys()):
            lines.append(f"{k}={os.environ[k]}")
        cfg_path = os.path.join(os.path.expanduser("~"), ".techdrive", "settings.json")
        lines.append("")
        if os.path.exists(cfg_path):
            with open(cfg_path, "r", encoding="utf-8", errors="ignore") as f:
                lines.append("## TechDrive settings.json")
                lines.append(f.read())
        else:
            lines.append(f"(No TechDrive settings.json found at {cfg_path})")
        with open(out_file, "w", encoding="utf-8", errors="ignore") as f:
            f.write("\n".join(lines))
        return f"Settings snapshot saved -> {out_file} ({bytes_fmt(os.path.getsize(out_file))})"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)




