#!/usr/bin/env python3
"""
Module: cpu_monitor
Generated for TechDrive 500
Category: CPU Monitor
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('CPU Monitor',
  '📈',
  ['Usage Graph', 'Temperature', 'Fan Speed', 'Load', 'Core Usage', 'Processes'])]


def _bar(v, width=20):
    return "#" * int(min(v, 100) / 100 * width)


# ---------------------------------------------------------------------------
# Usage Graph — rolling per-second overall CPU usage
# ---------------------------------------------------------------------------

def tool_cpu_monitor_usage_graph(self, frame):
    """Usage Graph — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Usage Graph",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        try:
            if psutil is None:
                return "Requires psutil (pip install psutil)."
            samples = []
            for _ in range(10):
                samples.append(psutil.cpu_percent(interval=0.5))
            lines = [f"{i+1:>2}: {_bar(v):<20} {v:5.1f}%" for i, v in enumerate(samples)]
            avg = sum(samples) / len(samples)
            lines.append(f"\nAverage over sample: {avg:.1f}%   Peak: {max(samples):.1f}%")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Temperature — live repeated readings
# ---------------------------------------------------------------------------

def tool_cpu_monitor_temperature(self, frame):
    """Temperature — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Temperature",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            if wmi_module is None:
                return "Requires the 'wmi' package (pip install wmi) and admin rights."
            w = wmi_module.WMI(namespace="root\\wmi")
            lines = ["=== Temperature (5 readings, 1s apart) ==="]
            for i in range(5):
                try:
                    temps = w.MSAcpi_ThermalZoneTemperature()
                    readings = [f"{(t.CurrentTemperature/10.0)-273.15:.1f}C" for t in temps]
                    lines.append(f"t+{i+1}s: " + (", ".join(readings) if readings else "no sensors reported"))
                except Exception as e:
                    lines.append(f"t+{i+1}s: error ({e})")
                time.sleep(1)
            if len(lines) == 1:
                lines.append("No ACPI thermal zones exposed. Many OEM boards block this via WMI.")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Fan Speed
# ---------------------------------------------------------------------------

def tool_cpu_monitor_fan_speed(self, frame):
    """Fan Speed — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Fan Speed",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            if wmi_module is None:
                return "Requires the 'wmi' package (pip install wmi) and admin rights."
            w = wmi_module.WMI(namespace="root\\cimv2")
            fans = w.Win32_Fan()
            if not fans:
                return "No fan sensors exposed via WMI (common on consumer boards — many don't publish this via ACPI)."
            lines = []
            for f in fans:
                lines.append(f"{f.Name or 'Fan'}: Status={getattr(f,'Status','?')}, "
                              f"DesiredSpeed={getattr(f,'DesiredSpeed','N/A')}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Voltage
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------

def tool_cpu_monitor_load(self, frame):
    """Load — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Load",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        try:
            if psutil is None:
                return "Requires psutil (pip install psutil)."
            lines = []
            pct = psutil.cpu_percent(interval=1)
            lines.append(f"Instant CPU usage: {pct:.1f}%")
            try:
                l1, l5, l15 = psutil.getloadavg()
                lines.append(f"Load average (1/5/15 min): {l1:.2f} / {l5:.2f} / {l15:.2f}")
            except (AttributeError, OSError):
                lines.append("Load average not available on this platform (Windows lacks a native loadavg; this is a psutil emulation on some systems).")
            counts = psutil.cpu_count(logical=False), psutil.cpu_count(logical=True)
            lines.append(f"Cores: {counts[0]} physical / {counts[1]} logical")
            try:
                stats = psutil.cpu_stats()
                lines.append(f"Context switches: {stats.ctx_switches:,}  Interrupts: {stats.interrupts:,}  Syscalls: {stats.syscalls:,}")
            except Exception:
                pass
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Core Usage — per-core breakdown
# ---------------------------------------------------------------------------

def tool_cpu_monitor_core_usage(self, frame):
    """Core Usage — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Core Usage",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        try:
            if psutil is None:
                return "Requires psutil (pip install psutil)."
            per_core = psutil.cpu_percent(interval=1, percpu=True)
            lines = ["=== Per-Core Usage ==="]
            for i, v in enumerate(per_core):
                lines.append(f"Core {i:>2}: {_bar(v):<20} {v:5.1f}%")
            lines.append(f"\nAverage: {sum(per_core)/len(per_core):.1f}%  Max core: {max(per_core):.1f}%  Min core: {min(per_core):.1f}%")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Threads
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Processes — top CPU consumers
# ---------------------------------------------------------------------------

def tool_cpu_monitor_processes(self, frame):
    """Processes — CPU Monitor"""
    panel = CardPanel(frame, self.theme, "Processes",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        try:
            if psutil is None:
                return "Requires psutil (pip install psutil)."
            procs = list(psutil.process_iter(['pid', 'name']))
            for p in procs:
                try:
                    p.cpu_percent(None)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            time.sleep(1.0)
            rows = []
            for p in procs:
                try:
                    cpu = p.cpu_percent(None)
                    mem = p.memory_percent()
                    rows.append((cpu, mem, p.info['pid'], p.info['name']))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            rows.sort(reverse=True)
            lines = ["=== Top 20 Processes by CPU ===", f"{'CPU%':>6} {'MEM%':>6} {'PID':>7}  NAME"]
            for cpu, mem, pid, name in rows[:20]:
                lines.append(f"{cpu:6.1f} {mem:6.1f} {pid:7} {name}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Interrupts
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# C-States
# ---------------------------------------------------------------------------

