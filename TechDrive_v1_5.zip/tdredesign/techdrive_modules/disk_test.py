#!/usr/bin/env python3
"""
Module: disk_test
Generated for TechDrive 500
Category: Disk Test

Real file-based throughput/latency benchmarks against a drive the user
picks, plus real SMART/health data pulled from the OS. Every test
writes/reads an actual temporary test file on the target drive (cleaned
up afterward) and reports measured MB/s or IOPS — no synthetic-CPU-loop
placeholders. Numbers reflect the OS file layer (including some caching),
which is disclosed rather than hidden.
"""

import os
import re
import time
import random
import platform
import subprocess
import threading
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel
from gui import sounds
from gui.disk_block_map import DiskScanProgress, ensure_disk_map

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('Disk Test',
  '⌕',
  ['Read Test', 'Sequential Test', 'Benchmark', 'Performance Test', 'SMART Test'])]

TEST_FILE_NAME = "_techdrive_disktest.tmp"


# ---------------------------------------------------------------------------
# shared benchmarking primitives
# ---------------------------------------------------------------------------

def _pick_test_folder(title="Choose a drive/folder to test"):
    return filedialog.askdirectory(title=title)


def _free_space(folder):
    try:
        if psutil:
            return psutil.disk_usage(folder).free
    except Exception:
        pass
    try:
        st = os.statvfs(folder)
        return st.f_bavail * st.f_frsize
    except Exception:
        return None


def _write_test_file(path, total_bytes, chunk_size):
    """Write total_bytes of random data in chunk_size blocks; return
    (elapsed_seconds, bytes_written). Uses fsync so timing includes an
    actual flush to storage, not just to the OS write cache."""
    written = 0
    block = os.urandom(chunk_size)
    start = time.time()
    with open(path, "wb") as f:
        while written < total_bytes:
            n = min(chunk_size, total_bytes - written)
            f.write(block[:n])
            written += n
        f.flush()
        os.fsync(f.fileno())
    elapsed = time.time() - start
    return elapsed, written


def _read_test_file(path, chunk_size):
    """Sequentially read an existing file; return (elapsed, bytes_read)."""
    read_total = 0
    start = time.time()
    with open(path, "rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            read_total += len(block)
    elapsed = time.time() - start
    return elapsed, read_total


def _random_access_test(path, file_size, block_size, num_ops):
    """Read num_ops randomly-positioned blocks; return (elapsed, ops, iops)."""
    if file_size <= block_size:
        return 0, 0, 0
    max_offset = file_size - block_size
    start = time.time()
    with open(path, "rb") as f:
        for _ in range(num_ops):
            off = random.randint(0, max_offset)
            f.seek(off)
            f.read(block_size)
    elapsed = time.time() - start
    iops = num_ops / elapsed if elapsed > 0 else 0
    return elapsed, num_ops, iops


def _mb_per_s(nbytes, seconds):
    if seconds <= 0:
        return 0.0
    return (nbytes / (1024 * 1024)) / seconds


def _prep(self, test_bytes_needed):
    """Common setup: pick a folder, verify free space, return (folder, path) or None."""
    folder = _pick_test_folder()
    if not folder:
        return None
    free = _free_space(folder)
    if free is not None and free < test_bytes_needed * 1.2:
        return "LOW_SPACE", folder, free
    path = os.path.join(folder, TEST_FILE_NAME)
    if os.path.lexists(path):
        return "FILE_EXISTS", folder, path
    return folder, path


def _cleanup(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Write Test — sequential write throughput
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Read Test — sequential read throughput
# ---------------------------------------------------------------------------

def tool_disk_test_read_test(self, frame):
    """Read Test — Disk Test"""
    panel = CardPanel(frame, self.theme, "Read Test",
                       "Sequential read throughput using a real temp file",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        test_size = 256 * 1024 * 1024
        prep = _prep(self, test_size)
        if prep is None:
            return "Cancelled."
        if prep[0] == "LOW_SPACE":
            _, folder, free = prep
            return f"Not enough free space on {folder} for a {bytes_fmt(test_size)} test (free: {bytes_fmt(free or 0)})."
        if prep[0] == "FILE_EXISTS":
            _, folder, path = prep
            return f"Safety stop: '{path}' already exists. TechDrive will not overwrite or delete an existing file. Choose another test folder or rename that file yourself."
        folder, path = prep
        try:
            w_elapsed, written = _write_test_file(path, test_size, 4 * 1024 * 1024)
            r_elapsed, read = _read_test_file(path, 4 * 1024 * 1024)
            speed = _mb_per_s(read, r_elapsed)
            return (f"=== Read Test: {folder} ===\n"
                    f"Read {bytes_fmt(read)} in {r_elapsed:.2f}s\n"
                    f"Sequential read speed: {speed:.1f} MB/s\n"
                    f"(test file was just written, so some of this may reflect OS page cache "
                    f"rather than pure media speed on drives with lots of free RAM)")
        except OSError as e:
            return f"Read test failed: {e}"
        finally:
            _cleanup(path)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Sequential Test — combined read+write sequential throughput
# ---------------------------------------------------------------------------

def tool_disk_test_sequential_test(self, frame):
    """Sequential Test — Disk Test"""
    panel = CardPanel(frame, self.theme, "Sequential Test",
                       "Combined sequential write + read pass",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        test_size = 256 * 1024 * 1024
        prep = _prep(self, test_size)
        if prep is None:
            return "Cancelled."
        if prep[0] == "LOW_SPACE":
            _, folder, free = prep
            return f"Not enough free space on {folder} for a {bytes_fmt(test_size)} test (free: {bytes_fmt(free or 0)})."
        if prep[0] == "FILE_EXISTS":
            _, folder, path = prep
            return f"Safety stop: '{path}' already exists. TechDrive will not overwrite or delete an existing file. Choose another test folder or rename that file yourself."
        folder, path = prep
        try:
            w_elapsed, written = _write_test_file(path, test_size, 8 * 1024 * 1024)
            w_speed = _mb_per_s(written, w_elapsed)
            r_elapsed, read = _read_test_file(path, 8 * 1024 * 1024)
            r_speed = _mb_per_s(read, r_elapsed)
            return (f"=== Sequential Test: {folder} (8MB blocks) ===\n"
                    f"Write: {w_speed:.1f} MB/s ({bytes_fmt(written)} in {w_elapsed:.2f}s)\n"
                    f"Read:  {r_speed:.1f} MB/s ({bytes_fmt(read)} in {r_elapsed:.2f}s)")
        except OSError as e:
            return f"Sequential test failed: {e}"
        finally:
            _cleanup(path)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# Random Access Test — 4K random-read IOPS
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Benchmark / Performance Test / CrystalDiskMark Style — combined summary
# ---------------------------------------------------------------------------

def _full_benchmark(folder, path):
    test_size = 256 * 1024 * 1024
    lines = [f"=== Benchmark: {folder} ==="]

    w_elapsed, written = _write_test_file(path, test_size, 8 * 1024 * 1024)
    seq_write = _mb_per_s(written, w_elapsed)
    lines.append(f"Sequential Write (8MB):  {seq_write:>8.1f} MB/s")

    r_elapsed, read = _read_test_file(path, 8 * 1024 * 1024)
    seq_read = _mb_per_s(read, r_elapsed)
    lines.append(f"Sequential Read  (8MB):  {seq_read:>8.1f} MB/s")

    ra_elapsed, ra_ops, ra_iops = _random_access_test(path, test_size, 4 * 1024, 3000)
    lines.append(f"Random Read (4K):        {ra_iops:>8.0f} IOPS  ({_mb_per_s(ra_ops * 4096, ra_elapsed):.1f} MB/s)")

    w2_start = time.time()
    with open(path, "r+b") as f:
        max_off = test_size - 4096
        block = os.urandom(4096)
        for _ in range(1500):
            f.seek(random.randint(0, max_off))
            f.write(block)
        f.flush()
        os.fsync(f.fileno())
    w2_elapsed = time.time() - w2_start
    ra_write_iops = 1500 / w2_elapsed if w2_elapsed > 0 else 0
    lines.append(f"Random Write (4K):       {ra_write_iops:>8.0f} IOPS  ({_mb_per_s(1500 * 4096, w2_elapsed):.1f} MB/s)")

    lines.append("\n(File-level benchmark via the OS I/O path — comparable in shape to "
                 "CrystalDiskMark's Seq/4K tests, though absolute numbers can differ from "
                 "tools that bypass the filesystem cache.)")
    return "\n".join(lines)


def _benchmark_tool(self, frame, title, subtitle):
    panel = CardPanel(frame, self.theme, title, subtitle,
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        test_size = 256 * 1024 * 1024
        prep = _prep(self, test_size)
        if prep is None:
            return "Cancelled."
        if prep[0] == "LOW_SPACE":
            _, folder, free = prep
            return f"Not enough free space on {folder} for a {bytes_fmt(test_size)} test (free: {bytes_fmt(free or 0)})."
        if prep[0] == "FILE_EXISTS":
            _, folder, path = prep
            return f"Safety stop: '{path}' already exists. TechDrive will not overwrite or delete an existing file. Choose another test folder or rename that file yourself."
        folder, path = prep
        try:
            return _full_benchmark(folder, path)
        except OSError as e:
            return f"Benchmark failed: {e}"
        finally:
            _cleanup(path)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_disk_test_benchmark(self, frame):
    """Benchmark — Disk Test"""
    _benchmark_tool(self, frame, "Benchmark", "Sequential + random read/write summary")




def tool_disk_test_performance_test(self, frame):
    """Performance Test — Disk Test"""
    _benchmark_tool(self, frame, "Performance Test", "Overall throughput/IOPS snapshot")


# ---------------------------------------------------------------------------
# Stress Test — sustained read/write loop for a fixed duration
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Surface Test — full sequential read of an existing file/volume checking
# for read errors (a safe, non-destructive stand-in for raw sector scanning)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# SMART Test — real SMART/health status from the OS
# ---------------------------------------------------------------------------

def tool_disk_test_smart_test(self, frame):
    """SMART Test — Disk Test"""
    panel = CardPanel(frame, self.theme, "SMART Test",
                       "Drive health status from Windows storage APIs",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            try:
                r = subprocess.run(["smartctl", "-a", "/dev/sda"], capture_output=True, text=True, timeout=15)
                return r.stdout.strip() or r.stderr.strip() or "No output from smartctl."
            except FileNotFoundError:
                return "smartctl not found. Install 'smartmontools' to run real SMART tests on this OS."
            except Exception as e:
                return f"Error: {e}"

        lines = []
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-PhysicalDisk | Select-Object DeviceId,FriendlyName,MediaType,"
                 "HealthStatus,OperationalStatus,Size | Format-Table -AutoSize | Out-String -Width 200"],
                capture_output=True, text=True, timeout=20)
            out = r.stdout.strip()
            if out:
                lines.append("=== Physical Disk Health (Get-PhysicalDisk) ===")
                lines.append(out)
        except Exception as e:
            lines.append(f"Get-PhysicalDisk unavailable: {e}")

        try:
            r2 = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-StorageReliabilityCounter -PhysicalDisk (Get-PhysicalDisk) | "
                 "Select-Object DeviceId,Temperature,Wear,ReadErrorsTotal,WriteErrorsTotal,"
                 "PowerOnHours | Format-Table -AutoSize | Out-String -Width 200"],
                capture_output=True, text=True, timeout=20)
            out2 = r2.stdout.strip()
            if out2:
                lines.append("\n=== Reliability Counters (Get-StorageReliabilityCounter) ===")
                lines.append(out2)
            elif r2.stderr.strip():
                lines.append(f"\n(Reliability counters unavailable: {r2.stderr.strip()[:200]})")
        except Exception:
            pass

        if not lines:
            return ("Could not read SMART/health data from Windows Storage Management APIs. "
                    "For raw SMART attribute IDs, install smartmontools (smartctl) instead.")
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)
