#!/usr/bin/env python3
"""
Module: sync_tools
Generated for TechDrive 500
Category: Sync Tools

Real implementation, built entirely on Windows' own `robocopy` (Robust
File Copy) — no third-party sync engine bundled or required. Every tool
below picks real folders/paths through native dialogs, runs a real
robocopy pass, and shows robocopy's own summary (files copied, skipped,
failed, bytes moved) rather than a canned string.

`robocopy` exit codes are a bitmask, not a simple 0/non-zero pass-fail:
 0  = no files needed copying (already in sync)
 1  = files copied successfully
 2  = extra files/dirs at destination were detected
 4  = mismatched files/dirs were detected
 8  = some files/dirs could not be copied (real error)
 16 = serious error, robocopy didn't copy anything
Codes 0-7 are success/informational; 8+ indicates a real failure.
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def _run_robocopy(src, dst, extra_args=None, timeout=1800):
    """Runs robocopy src -> dst and returns (ok, summary_text)."""
    if not IS_WINDOWS:
        return False, "Windows-only feature (robocopy is a Windows utility)."
    args = ["robocopy", src, dst] + (extra_args or []) + ["/R:2", "/W:2", "/NP", "/NFL"]
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        out = r.stdout or r.stderr or ""
        lines = [l for l in out.splitlines() if l.strip()]
        tail = "\n".join(lines[-16:]) if lines else "(no output)"
        ok = r.returncode < 8
        status = "OK" if ok else f"robocopy reported errors (exit code {r.returncode})"
        return ok, f"{src}\n  -> {dst}\n\n[{status}]\n\n{tail}"
    except subprocess.TimeoutExpired:
        return False, "Sync timed out — the source/destination may be very large or a network path stalled."
    except FileNotFoundError:
        return False, "robocopy.exe not found on this system."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _pick_src_dst(src_title, dst_title, dst_is_path=False, dst_prompt=None):
    src = filedialog.askdirectory(title=src_title)
    if not src:
        return None, None
    if dst_is_path:
        dst = simpledialog.askstring("Destination", dst_prompt or "Destination path:")
        if not dst:
            return None, None
    else:
        dst = filedialog.askdirectory(title=dst_title)
        if not dst:
            return None, None
    return src, dst


def _autodetect_cloud_folders():
    home = os.path.expanduser("~")
    candidates = {
        "OneDrive": os.environ.get("OneDrive") or os.path.join(home, "OneDrive"),
        "Google Drive": os.path.join(home, "Google Drive"),
        "Dropbox": os.path.join(home, "Dropbox"),
    }
    return {name: path for name, path in candidates.items() if path and os.path.isdir(path)}


def _list_removable_drives():
    drives = []
    if IS_WINDOWS and wmi_module:
        try:
            c = wmi_module.WMI()
            for d in c.Win32_LogicalDisk(DriveType=2):
                drives.append(f"{d.DeviceID}\\  ({bytes_fmt(int(d.Size or 0))})")
        except Exception:
            pass
    if not drives and psutil:
        for p in psutil.disk_partitions():
            if "removable" in p.opts.lower() or (IS_WINDOWS and p.device.upper() not in ("C:\\",)):
                drives.append(p.device)
    return drives


# ---------------------------------------------------------------------------
# tools
# ---------------------------------------------------------------------------


















