#!/usr/bin/env python3
"""
Module: storage_health
Generated for TechDrive 500
Category: Storage Health

All 10 tools below read real drive-health data (no canned/placeholder
text). Two real Windows data sources back almost everything here:

  1. WMI namespace root\\wmi:
       - MSStorageDriver_FailurePredictStatus  -> real SMART predictive-
         failure flag + reason code, set by the drive firmware itself
       - MSStorageDriver_FailurePredictData    -> the raw 512-byte ATA
         SMART attribute table (ID/current/worst/raw per attribute),
         parsed here the same way tools like CrystalDiskInfo do
  2. The Storage Management API (PowerShell Get-PhysicalDisk /
     Get-StorageReliabilityCounter) -> HealthStatus, temperature, SSD
     wear percentage, and read/write/uncorrectable error counters,
     tracked by the storage stack itself.

Both need the app to be run elevated (Administrator) on most systems -
that's a genuine Windows permission requirement, reported honestly
rather than worked around.

Self-Test additionally uses smartctl.exe (smartmontools) if it's
present on PATH, since Windows has no built-in API to trigger an ATA
SMART self-test; if it's not installed, the tool says so plainly
instead of pretending to run a test.
"""

import os
import re
import json
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('Storage Health',
  '❤\u200d✚',
  ['SMART Status',
   'Attributes',
   'Self-Test',
   'Error Log',
   'Temperature',
   'Wear Level',
   'Health Report'])]


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

# Standard ATA SMART attribute IDs worth naming; anything else is shown as
# "Vendor-specific (ID n)" rather than guessed at.
_SMART_ATTR_NAMES = {
    1: "Read Error Rate", 3: "Spin-Up Time", 4: "Start/Stop Count",
    5: "Reallocated Sectors Count", 7: "Seek Error Rate", 9: "Power-On Hours",
    10: "Spin Retry Count", 12: "Power Cycle Count", 170: "Reserved Block Count",
    171: "Program Fail Count", 172: "Erase Fail Count", 173: "Wear Leveling Count",
    174: "Unexpected Power Loss Count", 177: "Wear Range Delta",
    179: "Used Reserved Block Count", 180: "Unused Reserved Block Count",
    181: "Program Fail Count Total", 182: "Erase Fail Count Total",
    183: "Runtime Bad Block", 184: "End-to-End Error", 187: "Reported Uncorrectable Errors",
    188: "Command Timeout", 190: "Airflow Temperature", 194: "Temperature",
    195: "Hardware ECC Recovered", 196: "Reallocated Event Count",
    197: "Current Pending Sector Count", 198: "Uncorrectable Sector Count",
    199: "UDMA CRC Error Count", 202: "Percent Lifetime Used",
    231: "SSD Life Left", 232: "Endurance Remaining", 233: "Media Wearout Indicator",
    241: "Total LBAs Written", 242: "Total LBAs Read",
}


def _run_ps(cmd, timeout=25):
    """Run a PowerShell command and return raw stdout text. Raises on
    non-zero/timeouts so callers can report the real failure."""
    r = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
        capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0 and not r.stdout.strip():
        raise RuntimeError(r.stderr.strip() or f"powershell exited {r.returncode}")
    return r.stdout.strip()


def _run_ps_json(cmd, timeout=25):
    """Run a PowerShell command that ends in ConvertTo-Json and return a
    list of dicts (normalizes PowerShell's single-object vs array output)."""
    out = _run_ps(cmd, timeout=timeout)
    if not out:
        return []
    data = json.loads(out)
    if isinstance(data, dict):
        return [data]
    return data


def _get_physical_disks():
    """Real per-disk identity + health via the Storage Management API."""
    return _run_ps_json(
        "Get-PhysicalDisk | Select-Object DeviceId,FriendlyName,SerialNumber,MediaType,"
        "BusType,HealthStatus,OperationalStatus,Size | ConvertTo-Json -Depth 3")


def _get_reliability_counters():
    """Real per-disk reliability counters (temperature, wear, error
    counts) tracked by the storage stack — MSFT_StorageReliabilityCounter.
    Must be piped in (Get-PhysicalDisk | Get-StorageReliabilityCounter) -
    passing the array directly via -PhysicalDisk fails to bind since that
    parameter only accepts one CimInstance at a time positionally."""
    return _run_ps_json(
        "Get-PhysicalDisk | Get-StorageReliabilityCounter | "
        "Select-Object DeviceId,Temperature,TemperatureMax,Wear,ReadErrorsTotal,"
        "ReadErrorsUncorrected,WriteErrorsTotal,WriteErrorsUncorrected,"
        "PowerOnHours,StartStopCount,LoadUnloadCycleCount | ConvertTo-Json -Depth 3")


def _access_denied_hint(err):
    """root\\wmi sometimes blocks access via DCOM/namespace security even
    when the process is already elevated — that's a separate, narrower
    permission from 'Administrator' and needs an explicit grant."""
    if "access is denied" in str(err).lower() or "access denied" in str(err).lower():
        return (f"{err}\n\nThis is a WMI *namespace* permission, separate from being "
                "Administrator: root\\wmi sometimes has its own DCOM/namespace security "
                "that blocks even elevated processes by default. To fix it: run "
                "wmimgmt.msc -> right-click WMI Control (Local) -> Properties -> Security "
                "tab -> select the WMI folder -> Security... -> grant your account (or "
                "Administrators) Enable Account + Remote Enable on root\\wmi and its "
                "sub-namespaces, then restart TechDrive.")
    return str(err)


def _get_failure_predict_status():
    """Real SMART predictive-failure flag, straight from drive firmware."""
    try:
        return _run_ps_json(
            "Get-WmiObject -Namespace root\\wmi -Class MSStorageDriver_FailurePredictStatus | "
            "Select-Object InstanceName,PredictFailure,Reason | ConvertTo-Json -Depth 3")
    except Exception as e:
        raise RuntimeError(_access_denied_hint(e))


def _parse_smart_attributes(vendor_specific_bytes):
    """Parse the raw 512-byte ATA SMART attribute table (as returned by
    MSStorageDriver_FailurePredictData.VendorSpecific) into structured
    attribute rows: [{id, name, current, worst, raw}, ...]. Layout: 2-byte
    header, then up to 30 x 12-byte entries starting at offset 2."""
    b = bytes(vendor_specific_bytes)
    attrs = []
    for i in range(30):
        off = 2 + i * 12
        if off + 12 > len(b):
            break
        attr_id = b[off]
        if attr_id == 0:
            continue
        current = b[off + 3]
        worst = b[off + 4]
        raw = int.from_bytes(b[off + 5:off + 11], byteorder="little")
        attrs.append({
            "id": attr_id,
            "name": _SMART_ATTR_NAMES.get(attr_id, f"Vendor-specific (ID {attr_id})"),
            "current": current,
            "worst": worst,
            "raw": raw,
        })
    return attrs


def _get_smart_attribute_tables():
    """Real per-disk SMART attribute tables via MSStorageDriver_FailurePredictData.
    Returns {instance_name: [attr, ...]}. Requires admin rights."""
    try:
        out = _run_ps(
            "Get-WmiObject -Namespace root\\wmi -Class MSStorageDriver_FailurePredictData | "
            "ForEach-Object { $_.InstanceName + '|' + "
            "([System.Convert]::ToBase64String($_.VendorSpecific)) }")
    except Exception as e:
        raise RuntimeError(_access_denied_hint(e))
    tables = {}
    for line in out.splitlines():
        line = line.strip()
        if "|" not in line:
            continue
        name, b64 = line.split("|", 1)
        try:
            import base64
            raw = base64.b64decode(b64)
            tables[name.strip()] = _parse_smart_attributes(raw)
        except Exception:
            continue
    return tables


def _find_smartctl():
    for candidate in ("smartctl", "smartctl.exe"):
        try:
            r = subprocess.run([candidate, "--version"], capture_output=True,
                                text=True, timeout=5)
            if r.returncode == 0:
                return candidate
        except Exception:
            continue
    return None


def _health_color(status):
    return {"Healthy": "ok", "Warning": "warn", "Unhealthy": "fail"}.get(str(status), "warn")


# ---------------------------------------------------------------------------
# 1. SMART Status
# ---------------------------------------------------------------------------
def tool_storage_health_smart_status(self, frame):
    """SMART Status — Storage Health"""
    panel = CardPanel(frame, self.theme, "SMART Status", "Real per-disk health via the Storage Management API",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            disks = _get_physical_disks()
            if not disks:
                return "No physical disks reported. Try running TechDrive as Administrator."
            lines = []
            for d in disks:
                lines.append(f"{d.get('FriendlyName', '?')}  "
                             f"({bytes_fmt(int(d.get('Size', 0) or 0))}, {d.get('MediaType', '?')}, "
                             f"{d.get('BusType', '?')})")
                lines.append(f"    HealthStatus:      {d.get('HealthStatus', '?')}")
                lines.append(f"    OperationalStatus: {d.get('OperationalStatus', '?')}")
                lines.append(f"    Serial:            {d.get('SerialNumber', '?')}")
                lines.append("")
            return "\n".join(lines)
        except json.JSONDecodeError:
            return "No disk data returned (empty result from Storage Management API)."
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}\n\nThis usually means TechDrive needs to be run as Administrator " \
                   f"for the Storage Management API to return data."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 2. Attributes
# ---------------------------------------------------------------------------
def tool_storage_health_attributes(self, frame):
    """Attributes — Storage Health"""
    panel = CardPanel(frame, self.theme, "Attributes", "Real raw ATA SMART attribute table, parsed per-disk",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            tables = _get_smart_attribute_tables()
            if not tables:
                return "No SMART attribute data returned. This needs Administrator rights " \
                       "and a drive whose driver exposes MSStorageDriver_FailurePredictData " \
                       "(most internal SATA/NVMe-via-SATA-passthrough drives do; some NVMe " \
                       "and USB/RAID-controller drives don't expose it at all)."
            lines = []
            for instance, attrs in tables.items():
                lines.append(f"=== {instance} ===")
                if not attrs:
                    lines.append("  No attribute entries decoded.")
                    continue
                lines.append(f"  {'ID':<4}{'Attribute':<32}{'Cur':<5}{'Worst':<7}{'Raw':<12}")
                for a in attrs:
                    lines.append(f"  {a['id']:<4}{a['name']:<32}{a['current']:<5}"
                                 f"{a['worst']:<7}{a['raw']:<12}")
                lines.append("")
            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 3. Self-Test
# ---------------------------------------------------------------------------
def tool_storage_health_self_test(self, frame):
    """Self-Test — Storage Health"""
    panel = CardPanel(frame, self.theme, "Self-Test", "Runs a real ATA SMART short self-test via smartctl, if installed",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        smartctl = _find_smartctl()
        if not smartctl:
            return ("smartctl.exe (from smartmontools) was not found on PATH, and Windows has "
                     "no built-in API to trigger a real ATA SMART self-test — WMI can only "
                     "read predictive-failure status, not command a self-test. Install "
                     "smartmontools (https://www.smartmontools.org) and make sure smartctl.exe "
                     "is on PATH to enable this tool for real, rather than faking a result.")
        try:
            scan = subprocess.run([smartctl, "--scan"], capture_output=True, text=True, timeout=15)
            devices = [ln.split()[0] for ln in scan.stdout.splitlines() if ln.strip()]
            if not devices:
                return "smartctl found no scannable devices."
            lines = []
            for dev in devices:
                lines.append(f"=== {dev} ===")
                start = subprocess.run([smartctl, "-t", "short", dev],
                                        capture_output=True, text=True, timeout=20)
                lines.append(start.stdout.strip() or start.stderr.strip())
                lines.append("(Short self-test runs in the background on the drive itself, "
                             "typically 1-2 minutes; re-run this tool or check "
                             "`smartctl -l selftest` shortly to see the result.)")
                lines.append("")
            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "smartctl timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 4. Error Log
# ---------------------------------------------------------------------------
def tool_storage_health_error_log(self, frame):
    """Error Log — Storage Health"""
    panel = CardPanel(frame, self.theme, "Error Log", "Real disk-related entries from the Windows System event log",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            # Event IDs 7/9/11/15/51/153 are the standard Windows disk/controller
            # error and I/O-retry warnings logged by the storage/disk drivers.
            cmd = (
                "Get-WinEvent -FilterHashtable @{LogName='System';"
                "ProviderName=('disk','Microsoft-Windows-Storage-ClassPnP','Microsoft-Windows-StorAHCI');"
                "Id=7,9,11,15,51,153} -MaxEvents 50 -ErrorAction SilentlyContinue | "
                "Select-Object TimeCreated,Id,LevelDisplayName,Message | ConvertTo-Json -Depth 3"
            )
            events = _run_ps_json(cmd)
            if not events:
                return "No disk error/warning events found in the System log (checked event " \
                       "IDs 7, 9, 11, 15, 51, 153 from the disk/storage providers) — that's " \
                       "a genuinely good sign, not an empty placeholder."
            lines = [f"{len(events)} disk-related event(s) found:", ""]
            for e in events:
                ts = e.get("TimeCreated", "")
                if isinstance(ts, dict) and "DateTime" in ts:
                    ts = ts["DateTime"]
                msg = (e.get("Message") or "").splitlines()[0][:200]
                lines.append(f"[{e.get('LevelDisplayName', '?')}] {ts}  (Event {e.get('Id')}): {msg}")
            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 5. Temperature
# ---------------------------------------------------------------------------
def tool_storage_health_temperature(self, frame):
    """Temperature — Storage Health"""
    panel = CardPanel(frame, self.theme, "Temperature", "Real per-disk temperature from the storage stack",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            counters = _get_reliability_counters()
            if not counters:
                return "No reliability counters returned (needs Administrator rights, and " \
                       "not every controller/driver reports temperature)."
            lines = []
            for c in counters:
                temp = c.get("Temperature")
                tmax = c.get("TemperatureMax")
                if temp in (None, 0):
                    lines.append(f"{c.get('DeviceId', '?')}: temperature not reported by this drive/driver.")
                else:
                    lines.append(f"{c.get('DeviceId', '?')}: {temp}\u00b0C "
                                 f"(max recorded: {tmax if tmax else '?'}\u00b0C)")
            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 6. Predictive Failure
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 7. Wear Level
# ---------------------------------------------------------------------------
def tool_storage_health_wear_level(self, frame):
    """Wear Level — Storage Health"""
    panel = CardPanel(frame, self.theme, "Wear Level", "Real SSD wear percentage from the storage stack",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        try:
            counters = _get_reliability_counters()
            disks = {d.get("DeviceId"): d for d in _get_physical_disks()}
            if not counters:
                return "No reliability counters returned (needs Administrator rights)."
            lines = []
            any_ssd = False
            for c in counters:
                dev = disks.get(c.get("DeviceId"), {})
                media = dev.get("MediaType", "?")
                wear = c.get("Wear")
                name = dev.get("FriendlyName", c.get("DeviceId", "?"))
                if media == "SSD":
                    any_ssd = True
                if wear is None:
                    lines.append(f"{name} ({media}): wear not reported by this drive/driver.")
                else:
                    lines.append(f"{name} ({media}): {wear}% of rated write endurance used.")
            if not any_ssd:
                lines.append("")
                lines.append("Note: wear-level tracking is an SSD/NVMe concept (NAND write "
                             "endurance); mechanical HDDs don't report it, which is expected, "
                             "not a bug.")
            return "\n".join(lines)
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


# ---------------------------------------------------------------------------
# 8. Reallocated Sectors
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 9. Uncorrectable Sectors
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 10. Health Report
# ---------------------------------------------------------------------------
def tool_storage_health_health_report(self, frame):
    """Health Report — Storage Health"""
    panel = CardPanel(frame, self.theme, "Health Report", "Aggregated real-data PASS/WARN/FAIL summary",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on Windows utilities)."
        results = []

        def check(name, level, detail):
            label = {"ok": "PASS", "warn": "WARN", "fail": "FAIL"}[level]
            results.append(f"[{label}] {name}: {detail}")

        try:
            disks = _get_physical_disks()
        except Exception as e:
            disks = []
            check("Storage Management API", "warn", f"unavailable ({e}) — run as Administrator")

        for d in disks:
            name = d.get("FriendlyName", d.get("DeviceId", "?"))
            health = d.get("HealthStatus", "Unknown")
            check(f"{name} HealthStatus", _health_color(health), str(health))

        try:
            statuses = _get_failure_predict_status()
            for s in statuses:
                predict = s.get("PredictFailure")
                check(f"{s.get('InstanceName', '?')} predictive failure",
                      "fail" if predict else "ok",
                      "firmware predicts failure" if predict else "no failure predicted")
        except Exception as e:
            check("SMART predictive failure", "warn", f"unavailable ({e})")

        try:
            tables = _get_smart_attribute_tables()
            for instance, attrs in tables.items():
                by_id = {a["id"]: a for a in attrs}
                a5 = by_id.get(5)
                a197 = by_id.get(197)
                a198 = by_id.get(198)
                if a5:
                    check(f"{instance} reallocated sectors", "ok" if a5["raw"] == 0 else "warn",
                          f"raw={a5['raw']}")
                if a198:
                    check(f"{instance} uncorrectable sectors", "ok" if a198["raw"] == 0 else "fail",
                          f"raw={a198['raw']}")
                if a197:
                    check(f"{instance} pending sectors", "ok" if a197["raw"] == 0 else "warn",
                          f"raw={a197['raw']}")
        except Exception as e:
            check("SMART attribute table", "warn", f"unavailable ({e})")

        try:
            counters = _get_reliability_counters()
            disk_by_id = {d.get("DeviceId"): d for d in disks}
            for c in counters:
                name = disk_by_id.get(c.get("DeviceId"), {}).get("FriendlyName", c.get("DeviceId"))
                wear = c.get("Wear")
                if wear is not None:
                    check(f"{name} wear level", "ok" if wear < 80 else ("warn" if wear < 95 else "fail"),
                          f"{wear}% used")
                temp = c.get("Temperature")
                if temp:
                    check(f"{name} temperature", "ok" if temp < 55 else ("warn" if temp < 65 else "fail"),
                          f"{temp}\u00b0C")
        except Exception as e:
            check("Reliability counters", "warn", f"unavailable ({e})")

        if not results:
            return "No data could be collected at all. Run TechDrive as Administrator and try again."

        fails = sum(1 for r in results if r.startswith("[FAIL]"))
        warns = sum(1 for r in results if r.startswith("[WARN]"))
        overall = "FAIL" if fails else ("WARN" if warns else "PASS")

        return "\n".join([f"Overall: {overall}", ""] + results)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)
