#!/usr/bin/env python3
"""
Module: registry_tools
Generated for TechDrive 500
Category: Registry Tools

Real registry operations via winreg + reg.exe. Distinct from the
Registry Advanced module: this one focuses on backup/restore/export/
import workflows, a startup-key oriented cleaner, key search, a live
value-change monitor, and a two-snapshot comparator.
"""

import os
import re
import time
import json
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel, PanelTextProxy

try:
    import winreg
except ImportError:
    winreg = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []

_HIVE_MAP = {
    "HKCU": winreg.HKEY_CURRENT_USER if winreg else None,
    "HKLM": winreg.HKEY_LOCAL_MACHINE if winreg else None,
    "HKCR": winreg.HKEY_CLASSES_ROOT if winreg else None,
    "HKU": winreg.HKEY_USERS if winreg else None,
    "HKCC": winreg.HKEY_CURRENT_CONFIG if winreg else None,
}

STARTUP_KEYS = [
    (winreg.HKEY_CURRENT_USER if winreg else None, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU\\...\\Run"),
    (winreg.HKEY_LOCAL_MACHINE if winreg else None, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM\\...\\Run"),
]


def _parse_full_path(full_path):
    parts = full_path.strip().split("\\", 1)
    hive_name = parts[0].upper()
    if hive_name not in _HIVE_MAP:
        raise ValueError(f"Unknown hive '{hive_name}'. Use HKCU, HKLM, HKCR, HKU, or HKCC.")
    subpath = parts[1] if len(parts) > 1 else ""
    return _HIVE_MAP[hive_name], subpath, hive_name


def _run(cmd, timeout=30):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


# ---------------------------------------------------------------------------
# Backup — export a whole hive (HKCU/HKLM/...) to a .reg file
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Restore — import a .reg backup file
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Cleaner — scan the Run/RunOnce startup keys for entries pointing to
# files that no longer exist (scan-only, reports; deletion needs confirm)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Compactor — report hive file sizes on disk
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Key Search — find subkeys under a hive whose name contains a query
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Export — same mechanism as Backup, framed as a general-purpose export
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Import — same mechanism as Restore, framed as general-purpose import
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Monitor — poll a key's values for changes over a short window
# ---------------------------------------------------------------------------

def _snapshot_values(hive, subpath):
    values = {}
    try:
        with winreg.OpenKey(hive, subpath) as key:
            i = 0
            while True:
                try:
                    name, val, _ = winreg.EnumValue(key, i)
                except OSError:
                    break
                values[name] = val
                i += 1
    except OSError:
        pass
    return values




# ---------------------------------------------------------------------------
# Defrag — explain + report, same honest framing as Compactor
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Compare — diff two previously-saved JSON snapshots (see Registry
# Advanced > Snapshot) or two .reg files
# ---------------------------------------------------------------------------

