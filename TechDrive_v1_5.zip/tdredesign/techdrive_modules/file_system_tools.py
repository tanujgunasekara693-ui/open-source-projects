#!/usr/bin/env python3
"""
Module: file_system_tools
Generated for TechDrive 500
Category: File System Tools

Real filesystem-level tools built on fsutil, chkdsk, compact, mountvol,
and convert.exe. Every tool asks for the drive/volume/folder it needs
and reports the actual command output.
"""

import os
import re
import platform
import subprocess
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


def _ask_drive(title="Drive letter", initial="C:"):
    d = simpledialog.askstring(title, "Drive letter (e.g. C: or D:):", initialvalue=initial)
    if not d:
        return None
    d = d.strip().rstrip("\\")
    if not d.endswith(":"):
        d += ":"
    return d


def _list_volumes():
    if psutil:
        try:
            return [p.device for p in psutil.disk_partitions(all=False)]
        except Exception:
            pass
    return []


def _run(cmd, timeout=30):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _fs_type(drive):
    """Return the filesystem type of a drive via fsutil fsinfo volumeinfo."""
    try:
        r = _run(["fsutil", "fsinfo", "volumeinfo", drive + "\\"], timeout=15)
        m = re.search(r"File System Name\s*:\s*(\S+)", r.stdout)
        return m.group(1) if m else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# FAT32 / NTFS / exFAT Info — pull real volume info via fsutil, verify type
# ---------------------------------------------------------------------------

def _volume_info_tool(self, frame, label, expected_fs):
    panel = CardPanel(frame, self.theme, label)

    def run():
        if not IS_WINDOWS:
            return "Windows-only feature (this tool relies on fsutil)."
        drive = _ask_drive(label)
        if not drive:
            return "Cancelled."
        try:
            r = _run(["fsutil", "fsinfo", "volumeinfo", drive + "\\"])
            out = r.stdout.strip() or r.stderr.strip()
            if r.returncode != 0:
                return f"fsutil failed for {drive}:\n{out}"
            actual = _fs_type(drive)
            header = f"=== {label}: {drive} ===\n"
            if actual and expected_fs.lower() not in actual.lower():
                header += f"(Note: {drive} is actually formatted as {actual}, not {expected_fs})\n\n"
            return header + out
        except FileNotFoundError:
            return "fsutil.exe not found on this system."
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)








# ---------------------------------------------------------------------------
# Check — read-only chkdsk scan (no repair, no dismount needed)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Repair — schedule chkdsk /f (needs dismount or reboot for system volume)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Convert — FAT32/exFAT -> NTFS via convert.exe (one-way, no data loss)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Mount — assign a drive letter (or mount to a folder) via mountvol
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Unmount — remove a drive letter's mount point via mountvol /D
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Journal — NTFS USN change journal info via fsutil
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Compression — NTFS compression status/toggle via compact.exe
# ---------------------------------------------------------------------------

