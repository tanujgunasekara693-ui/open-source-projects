#!/usr/bin/env python3
r"""
techdrive_modules/ethernet_tools.py - Ethernet Tools category
======================================================================
Real, working wired-adapter diagnostics via Windows' own NetAdapter
PowerShell cmdlets (Get-NetAdapter, Get-NetAdapterAdvancedProperty,
Get-NetAdapterHardwareInfo, Get-NetIPAddress) plus a genuine
Wake-on-LAN magic-packet sender. Honest scope: Windows doesn't expose
a generic cable-fault/length tester without vendor-specific software
(Intel PROSet, Realtek diagnostics, etc.) - Cable Test here reports
the real link/media-connection-state Windows itself tracks, and says
so rather than pretending to measure cable length or wire pairs.
"""

import platform
import re
import socket
import subprocess
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []


def _powershell(script, timeout=25):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                           capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except FileNotFoundError:
        return False, "PowerShell not found on this system."
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except Exception as e:
        return False, str(e)


_WIRED_FILTER = "Get-NetAdapter | Where-Object { $_.PhysicalMediaType -match 'Ethernet|802.3|Unspecified' -or $_.InterfaceDescription -match 'Ethernet' }"




















