#!/usr/bin/env python3
r"""
techdrive_modules/internet_tools.py - Internet Tools category
======================================================================
Real, working network diagnostics built on Python's stdlib (urllib,
socket, subprocess) plus Windows' own ipconfig/netsh/Test-NetConnection.
Honest scope:

- Bandwidth/Speed Test: streams real bytes to/from Cloudflare's public,
  no-signup speed-test backend (the same endpoints the cloudflare.com
  speed test page itself calls) and times the transfer - a genuine
  throughput measurement, not a fake number.
- Geolocation/ISP Info: queries ip-api.com's free JSON endpoint for
  this machine's public IP - real third-party lookup, no key needed.
- Stability/Latency Check: real ICMP pings via the system ping command.
- Website Checker/Port Forwarding: real HTTP requests / TCP connection
  attempts, not simulated.
"""

import json
import platform
import socket
import statistics
import subprocess
import time
import urllib.error
import urllib.request
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = []

_PING_HOSTS = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]


def _ping(host, count=4, timeout_s=2):
    """Runs a real ping and returns (sent, received, rtts_ms list)."""
    try:
        if IS_WINDOWS:
            args = ["ping", "-n", str(count), "-w", str(int(timeout_s * 1000)), host]
        else:
            args = ["ping", "-c", str(count), "-W", str(timeout_s), host]
        r = subprocess.run(args, capture_output=True, text=True, timeout=count * timeout_s + 10,
                           creationflags=NO_WINDOW)
        out = r.stdout
    except Exception as e:
        return count, 0, [], str(e)
    rtts = [float(x) for x in __import__("re").findall(r"time[=<]([\d.]+)\s*ms", out)]
    received = len(rtts) if rtts else out.lower().count("reply from") or out.count("bytes from")
    return count, received, rtts, out


def _http_get_timed(url, max_bytes=None, timeout=15):
    """Streams a URL and returns (elapsed_seconds, bytes_read, error_or_None)."""
    req = urllib.request.Request(url, headers={"User-Agent": "TechDrive500/1.0"})
    t0 = time.time()
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            while True:
                chunk = resp.read(256 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if max_bytes and total >= max_bytes:
                    break
        return time.time() - t0, total, None
    except Exception as e:
        return time.time() - t0, total, str(e)


def _ip_api_lookup():
    """Real, free, no-key JSON geolocation/ISP lookup for this machine's public IP."""
    try:
        req = urllib.request.Request(
            "http://ip-api.com/json/?fields=status,message,query,country,regionName,city,zip,"
            "lat,lon,isp,org,as,timezone",
            headers={"User-Agent": "TechDrive500/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data, None
    except Exception as e:
        return None, str(e)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------



















