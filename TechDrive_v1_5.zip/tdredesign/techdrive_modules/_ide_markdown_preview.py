import tkinter as tk
from tkinter import ttk
import markdown
import re

class MarkdownPreview:
    """
    Live markdown preview - renders markdown to HTML in real-time.
    Shows in split pane as you type.
    """
    
    def __init__(self, editor_widget):
        self.editor = editor_widget
        self.preview_widget = None
        self.last_content = ''
        self.auto_update = True
        self.sync_scroll = True
    
    def create_preview_pane(self, parent):
        """Create and return preview pane widget."""
        # Create a text widget that displays HTML (simplified)
        self.preview_widget = tk.Text(parent, wrap='word', bg='#f0f0f0',
                                     fg='#333333', font=('Arial', 11),
                                     relief='flat', borderwidth=0)
        return self.preview_widget
    
    def update_preview(self):
        """Update preview from editor content."""
        if not self.preview_widget or not self.auto_update:
            return
        
        content = self.editor.text.get('1.0', 'end-1c')
        
        if content == self.last_content:
            return  # No change
        
        self.last_content = content
        
        try:
            # Convert markdown to HTML
            html = markdown.markdown(content, extensions=['extra', 'codehilite', 'toc'])
            
            # Simple HTML to text rendering (for tkinter text widget)
            rendered = self._render_html_to_text(html)
            
            # Update preview
            self.preview_widget.delete('1.0', 'end')
            self.preview_widget.insert('1.0', rendered)
            
            # Apply formatting tags
            self._apply_formatting_tags()
        
        except Exception as e:
            self.preview_widget.delete('1.0', 'end')
            self.preview_widget.insert('1.0', f'Error rendering markdown:\n{e}')
    
    def _render_html_to_text(self, html):
        """Convert HTML to plain text with formatting."""
        # Remove HTML tags but keep content
        text = re.sub(r'<[^>]+>', '', html)
        
        # Decode HTML entities
        text = text.replace('&nbsp;', ' ')
        text = text.replace('&lt;', '<')
        text = text.replace('&gt;', '>')
        text = text.replace('&amp;', '&')
        text = text.replace('<br>', '\n')
        
        return text
    
    def _apply_formatting_tags(self):
        """Apply text formatting tags for headings, code, etc."""
        content = self.preview_widget.get('1.0', 'end-1c')
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            line_idx = f'{i+1}.0'
            
            # Detect headings (H1-H6)
            if line.startswith('# '):
                self.preview_widget.tag_add('h1', line_idx, f'{i+1}.end')
            elif line.startswith('## '):
                self.preview_widget.tag_add('h2', line_idx, f'{i+1}.end')
            elif line.startswith('### '):
                self.preview_widget.tag_add('h3', line_idx, f'{i+1}.end')
            
            # Detect code blocks
            if line.startswith('    ') or line.startswith('\t'):
                self.preview_widget.tag_add('code', line_idx, f'{i+1}.end')
        
        # Configure tags
        self.preview_widget.tag_configure('h1', font=('Arial', 18, 'bold'), 
                                         foreground='#1a1a1a')
        self.preview_widget.tag_configure('h2', font=('Arial', 16, 'bold'), 
                                         foreground='#333333')
        self.preview_widget.tag_configure('h3', font=('Arial', 14, 'bold'), 
                                         foreground='#555555')
        self.preview_widget.tag_configure('code', font=('Courier New', 10, 'italic'), 
                                         background='#e0e0e0', foreground='#d32f2f')
    
    def enable_auto_update(self, enabled=True):
        """Enable/disable auto-update."""
        self.auto_update = enabled
    
    def export_to_html(self, output_file):
        """Export markdown as HTML file."""
        content = self.editor.text.get('1.0', 'end-1c')
        
        try:
            html = markdown.markdown(content, extensions=['extra', 'codehilite', 'toc'])
            
            full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Markdown Export</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        h1, h2, h3, h4, h5, h6 {{
            margin-top: 20px;
            margin-bottom: 10px;
        }}
        code {{
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }}
        pre {{
            background: #282c34;
            color: #abb2bf;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }}
        blockquote {{
            border-left: 4px solid #0078d4;
            padding-left: 15px;
            color: #666;
        }}
    </style>
</head>
<body>
{html}
</body>
</html>"""
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(full_html)
            
            return True
        
        except Exception as e:
            print(f"Error exporting to HTML: {e}")
            return False
    
    def get_preview_text(self):
        """Get current preview text."""
        if self.preview_widget:
            return self.preview_widget.get('1.0', 'end-1c')
        return ''
    
    def get_table_of_contents(self):
        """Extract table of contents from markdown."""
        content = self.editor.text.get('1.0', 'end-1c')
        lines = content.split('\n')
        
        toc = []
        for line in lines:
            if line.startswith('# '):
                toc.append(('h1', line[2:].strip()))
            elif line.startswith('## '):
                toc.append(('h2', line[3:].strip()))
            elif line.startswith('### '):
                toc.append(('h3', line[4:].strip()))
        
        return toc


class MarkdownTOCWidget:
    """Table of Contents widget for markdown."""
    
    def __init__(self, parent, markdown_preview):
        self.markdown = markdown_preview
        self.widget = tk.Listbox(parent, width=30, height=20)
        self.refresh()
    
    def refresh(self):
        """Refresh TOC from markdown."""
        self.widget.delete(0, 'end')
        
        toc = self.markdown.get_table_of_contents()
        
        for level, title in toc:
            indent = '  ' * (int(level[1]) - 1)
            self.widget.insert('end', f'{indent}{title}')
    
    def get_widget(self):
        """Get the listbox widget."""
        return self.widget


class MarkdownStyler:
    """Syntax highlighting for markdown editing."""
    
    def __init__(self, editor_widget):
        self.editor = editor_widget
    
    def apply_markdown_highlighting(self):
        """Apply syntax highlighting for markdown."""
        content = self.editor.text.get('1.0', 'end-1c')
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            line_idx = f'{i+1}.0'
            
            # Headings
            if line.startswith('#'):
                count = len(line) - len(line.lstrip('#'))
                self.editor.text.tag_add('md_heading', line_idx, f'{i+1}.{count}')
            
            # Bold
            for match in re.finditer(r'\*\*(.+?)\*\*', line):
                start = f'{i+1}.{match.start()}'
                end = f'{i+1}.{match.end()}'
                self.editor.text.tag_add('md_bold', start, end)
            
            # Italic
            for match in re.finditer(r'\*(.+?)\*', line):
                start = f'{i+1}.{match.start()}'
                end = f'{i+1}.{match.end()}'
                self.editor.text.tag_add('md_italic', start, end)
            
            # Code
            for match in re.finditer(r'`(.+?)`', line):
                start = f'{i+1}.{match.start()}'
                end = f'{i+1}.{match.end()}'
                self.editor.text.tag_add('md_code', start, end)
            
            # Links
            for match in re.finditer(r'\[(.+?)\]\((.+?)\)', line):
                start = f'{i+1}.{match.start()}'
                end = f'{i+1}.{match.end()}'
                self.editor.text.tag_add('md_link', start, end)
        
        # Configure tags
        self.editor.text.tag_configure('md_heading', foreground='#0066cc', font=('Arial', 11, 'bold'))
        self.editor.text.tag_configure('md_bold', font=('Arial', 11, 'bold'))
        self.editor.text.tag_configure('md_italic', font=('Arial', 11, 'italic'))
        self.editor.text.tag_configure('md_code', background='#f0f0f0', foreground='#c0392b')
        self.editor.text.tag_configure('md_link', foreground='#0066cc', underline=True)