#!/usr/bin/env python3
r"""
techdrive_modules/partition_tools.py - Partition Tools category
=================================================================
Real, working partition/disk-table management, built on the same
raw-device access as clone_tools.py (no external tools required for the
image/sector work) plus diskpart/PowerShell for the operations Windows
only exposes through its own partition manager.

NOTE ON A PRE-EXISTING BUG (fixed here): every other auto-generated
bonus module defines its tool functions as tool_<category>_<name>
(e.g. tool_partition_tools_table_backup), but TechDriveApp.open_tool()
only ever looks up tool_<name> (see techdrive.py's `"tool_" +
slugify(tool_name)`). That mismatch means those ~51 modules' tools were
never reachable - clicking them would hit "Tool implementation missing"
before _trim_catalogue_to_implemented() even had a chance to run, and
that trim function silently drops them from the sidebar entirely. This
file uses the naming convention open_tool() actually looks up
(tool_<slugified tool name>, no category prefix) so every entry below
is real and clickable. The same fix would need to be applied to the
other bonus modules for their tools to work too.

Everything that touches a physical disk (\\.\PhysicalDriveN) requires
Administrator on Windows. Every destructive action asks for explicit
confirmation before it does anything irreversible.
"""

import os
import platform
import struct
import subprocess
import tempfile
import time
import json
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog, messagebox

from gui.theme import FONT_UI, FONT_UI_BOLD, FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.clone_tools import (
    _disk_picker, _elevation_banner, _confirm_destructive,
    JobUI, copy_stream, is_elevated, device_size,
)

IS_WINDOWS = platform.system() == "Windows"
SECTOR = 512

CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def bytes_fmt(n):
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def run_diskpart(commands, timeout=90):
    """Write `commands` (list of diskpart script lines) to a temp .txt
    script and run `diskpart /s`. Returns (ok, output). diskpart's own
    error text (e.g. "Extend is only allowed if..." ) is passed straight
    through, since it's the most accurate explanation of *why* an
    operation didn't apply."""
    if not IS_WINDOWS:
        return False, "diskpart is a Windows-only tool."
    fd, path = tempfile.mkstemp(suffix=".txt", prefix="techdrive_dp_")
    try:
        with os.fdopen(fd, "w") as f:
            f.write("\n".join(commands) + "\n")
        r = subprocess.run(["diskpart", "/s", path], capture_output=True,
                           text=True, timeout=timeout)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "diskpart timed out (it may be waiting on a locked volume)."
    except FileNotFoundError:
        return False, "diskpart.exe not found on this system."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def list_volumes():
    """Real mounted volumes with a drive letter, via Get-Partition/Get-Volume."""
    if not IS_WINDOWS:
        return []
    ok, out = hw.powershell(
        "Get-Partition | Where-Object DriveLetter | ForEach-Object {"
        "$v = Get-Volume -Partition $_ -ErrorAction SilentlyContinue;"
        "[PSCustomObject]@{DiskNumber=$_.DiskNumber;PartitionNumber=$_.PartitionNumber;"
        "DriveLetter=$_.DriveLetter;Size=$_.Size;"
        "FileSystem=$v.FileSystem;SizeRemaining=$v.SizeRemaining}"
        "} | ConvertTo-Json -Compress")
    vols = []
    if ok and out.strip().startswith(("[", "{")):
        try:
            data = json.loads(out)
            for v in (data if isinstance(data, list) else [data]):
                vols.append({
                    "disk": v.get("DiskNumber"), "part": v.get("PartitionNumber"),
                    "letter": v.get("DriveLetter"), "size": float(v.get("Size") or 0),
                    "fs": v.get("FileSystem") or "?",
                    "free": float(v.get("SizeRemaining") or 0),
                })
        except Exception:
            pass
    return vols


def _volume_picker(app, parent, label):
    row = tk.Frame(parent, bg=app.theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=app.theme["BG"], fg=app.theme["MUTED"], font=FONT_UI,
             width=14, anchor="w").pack(side="left")
    var = tk.StringVar()
    combo = ttk.Combobox(row, textvariable=var, width=70, state="readonly")
    combo.pack(side="left", fill="x", expand=True)
    mapping = {}

    def refresh():
        mapping.clear()
        values = []
        for v in list_volumes():
            text = (f"{v['letter']}:  |  {v['fs']}  |  {bytes_fmt(v['size'])} total, "
                    f"{bytes_fmt(v['free'])} free  |  Disk {v['disk']} Part {v['part']}")
            values.append(text)
            mapping[text] = v
        combo["values"] = values
        if values and not var.get():
            var.set(values[0])

    def selected():
        return mapping.get(var.get())

    tk.Button(row, text="⟳", command=refresh, bg=app.theme["BG_LIGHT"], fg=app.theme["FG"],
              relief="flat", padx=8).pack(side="left", padx=6)
    refresh()
    return selected


def _confirm(msg):
    return messagebox.askyesno("Confirm", msg, icon="warning")


def _labeled_entry(parent, theme, label, default=""):
    row = tk.Frame(parent, bg=theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI,
             width=16, anchor="w").pack(side="left")
    var = tk.StringVar(value=default)
    ttk.Entry(row, textvariable=var, width=30).pack(side="left")
    return var


def _labeled_combo(parent, theme, label, values, default=None):
    row = tk.Frame(parent, bg=theme["BG"])
    row.pack(fill="x", pady=3)
    tk.Label(row, text=label, bg=theme["BG"], fg=theme["MUTED"], font=FONT_UI,
             width=16, anchor="w").pack(side="left")
    var = tk.StringVar(value=default or (values[0] if values else ""))
    ttk.Combobox(row, textvariable=var, values=values, width=27, state="readonly").pack(side="left")
    return var


def _elevation_note(self, body):
    if not is_elevated():
        tk.Label(body, text=("⚠ Not running elevated — diskpart/raw-disk operations need "
                              "Administrator. Restart TechDrive elevated or this will fail "
                              "partway through."),
                 bg=self.theme["BG"], fg=status_color("warn"), font=FONT_UI_BOLD,
                 wraplength=780, justify="left").pack(anchor="w", pady=(2, 6))


# ---------------------------------------------------------------------------
# Partition Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Resize
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Delete (single partition)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Format
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Merge (delete one volume, extend the adjacent one into its space)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Split (shrink, then create a new partition in the freed space)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Move (file-level relocation - Windows has no native sector-level move)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Recovery (signature-based file carving on a raw device)
# ---------------------------------------------------------------------------
_SIGNATURES = [
    ("jpg", b"\xff\xd8\xff", 12 * 1024 * 1024),
    ("png", b"\x89PNG\r\n\x1a\n", 12 * 1024 * 1024),
    ("pdf", b"%PDF-", 30 * 1024 * 1024),
    ("zip", b"PK\x03\x04", 30 * 1024 * 1024),
    ("gif", b"GIF8", 8 * 1024 * 1024),
]




# ---------------------------------------------------------------------------
# Partition table backup / restore (raw MBR + GPT header/table sectors)
# ---------------------------------------------------------------------------
_TABLE_MAGIC = b"TDPTBL01"






# ---------------------------------------------------------------------------
# Convert to MBR
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Disk Geometry
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Modify MBR signature / GPT Disk GUID
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# SMART Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Speed Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Bad Sector Scan (verify / repair via chkdsk)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Delete All Partitions
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Disk Image Backup / Restore (whole-disk raw image, mirrors clone_tools)
# ---------------------------------------------------------------------------


