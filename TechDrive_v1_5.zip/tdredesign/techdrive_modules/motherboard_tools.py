#!/usr/bin/env python3
"""
Module: motherboard_tools
Generated for TechDrive 500
Category: Motherboard Tools

All 10 tools below query real Windows CIM/WMI classes via PowerShell
(Get-CimInstance / Get-PnpDevice) — the same data source tools like
HWiNFO, Speccy, and dmidecode-for-Windows read from. No systeminfo
placeholder text.

  - Motherboard Info   -> Win32_BaseBoard + Win32_BIOS
  - Chipset Info       -> PCI System/SMBus-bridge PnP devices (the real
                          way chipset identity is exposed - there's no
                          single "chipset name" WMI field, so this reads
                          the actual PCI VEN/DEV-identified bridge devices)
  - PCI Devices        -> every PnP device with a PCI\\ hardware ID
  - USB Controllers    -> Win32_USBController
  - SATA Controllers   -> Win32_IDEController + AHCI/SATA PnP devices
  - NVMe Controllers   -> PnP storage adapters using the stornvme driver
  - Slot Information   -> Win32_SystemSlot (real physical expansion slots)
  - System Serial      -> Win32_BIOS + Win32_BaseBoard + Win32_ComputerSystemProduct
  - Hardware Inventory  -> consolidated real counts across CPU/RAM/disks/
                          GPU/board/BIOS
  - DMI Table Info     -> Win32_ComputerSystemProduct + Win32_SystemEnclosure
                          + Win32_BIOS SMBIOS fields (Windows' DMI table)

Needs Administrator for a few classes (Win32_SystemSlot in particular);
that's reported honestly rather than faked when access is denied.
"""

import os
import re
import json
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _run_ps(cmd, timeout=25):
    r = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
        capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0 and not r.stdout.strip():
        raise RuntimeError(r.stderr.strip() or f"powershell exited {r.returncode}")
    return r.stdout.strip()


def _run_ps_json(cmd, timeout=25):
    out = _run_ps(cmd, timeout=timeout)
    if not out:
        return []
    data = json.loads(out)
    if isinstance(data, dict):
        return [data]
    return data


def _access_denied_hint(err):
    if "access is denied" in str(err).lower():
        return (f"{err}\n\nTry running TechDrive as Administrator — this class needs "
                "elevated access.")
    return str(err)


def _cim(class_name, props=None, extra_where=""):
    """Real Get-CimInstance query -> list of dicts."""
    select = f" | Select-Object {','.join(props)}" if props else ""
    where = f" | Where-Object {{{extra_where}}}" if extra_where else ""
    try:
        return _run_ps_json(f"Get-CimInstance -ClassName {class_name}{where}{select} | "
                             "ConvertTo-Json -Depth 4")
    except Exception as e:
        raise RuntimeError(_access_denied_hint(e))


def _pnp(cls_filter=None, name_regex=None):
    """Real Get-PnpDevice query -> list of dicts (Class, FriendlyName,
    InstanceId, Status, Manufacturer, Service)."""
    where_parts = []
    if cls_filter:
        classes = ",".join(f"'{c}'" for c in cls_filter)
        where_parts.append(f"$_.Class -in @({classes})")
    if name_regex:
        where_parts.append(f"$_.FriendlyName -match '{name_regex}'")
    where = f" | Where-Object {{{' -and '.join(where_parts)}}}" if where_parts else ""
    try:
        return _run_ps_json(
            f"Get-PnpDevice{where} | "
            "Select-Object FriendlyName,Class,InstanceId,Status,Manufacturer,Service | "
            "ConvertTo-Json -Depth 4")
    except Exception as e:
        raise RuntimeError(_access_denied_hint(e))


# ---------------------------------------------------------------------------
# 1. Motherboard Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 2. Chipset Info
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 3. PCI Devices
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 4. USB Controllers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 5. SATA Controllers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 6. NVMe Controllers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 7. Slot Information
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 8. System Serial
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 9. Hardware Inventory
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 10. DMI Table Info
# ---------------------------------------------------------------------------
