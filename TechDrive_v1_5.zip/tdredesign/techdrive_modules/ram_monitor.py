#!/usr/bin/env python3
r"""
techdrive_modules/ram_monitor.py - RAM Monitor category
======================================================================
Real, working memory diagnostics via psutil and Windows' own Storage/
Memory-related WMI classes (Win32_PhysicalMemory, Win32_PageFileUsage,
Win32_PerfFormattedData_PerfOS_Memory). Nothing here is simulated.
"""

import platform
import subprocess
import time
import tkinter as tk
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = [('RAM Monitor', '▥', ['Usage Graph', 'Available', 'Used', 'Cache', 'Page File', 'Process Usage'])]


def _powershell(script, timeout=25):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                           capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip()
    except Exception as e:
        return f"Error: {e}"


def _need_psutil():
    return "psutil is not available - install it (pip install psutil) for this tool."


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def tool_ram_monitor_usage_graph(self, frame):
    """Usage Graph — live real RAM usage percentage, sampled repeatedly."""
    panel = CardPanel(frame, self.theme, "Usage Graph", "Live real RAM usage percentage, sampled once a second.")
    label = tk.Label(panel.body, text="RAM: -- ", font=("Consolas", 22, "bold"),
                     bg=self.theme.get("BG", "#111"), fg="#2ecc71")
    label.pack(anchor="w", padx=16, pady=(8, 4))
    state = {"running": False, "history": []}

    def redraw(r):
        panel.clear()
        panel.report(r)

    def tick():
        if not state["running"]:
            return
        if psutil is None:
            redraw(_need_psutil())
            return
        pct = psutil.virtual_memory().percent
        state["history"].append(pct)
        state["history"] = state["history"][-40:]
        label.config(text=f"RAM: {pct:5.1f}%")
        graph = " ".join(f"{v:.0f}" for v in state["history"][-20:])
        redraw("Last 20 samples (%):\n" + graph)
        frame.after(1000, tick)

    def start():
        state["running"] = True
        state["history"] = []
        tick()

    def stop():
        state["running"] = False
        label.config(text="RAM: -- ")

    self._button_row(panel.body, [("Start", start), ("Stop", stop)])


def tool_ram_monitor_available(self, frame):
    """Available — real currently-available (immediately usable) memory."""
    panel = CardPanel(frame, self.theme, "Available",
                       "Real amount of memory immediately available to new processes.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if psutil is None:
            return _need_psutil()
        m = psutil.virtual_memory()
        return f"Available: {bytes_fmt(m.available)}  ({100 - m.percent:.1f}% of {bytes_fmt(m.total)} total)"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_ram_monitor_used(self, frame):
    """Used — real currently-used memory."""
    panel = CardPanel(frame, self.theme, "Used",
                       "Real amount of memory currently in use.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if psutil is None:
            return _need_psutil()
        m = psutil.virtual_memory()
        return f"Used: {bytes_fmt(m.used)}  ({m.percent:.1f}% of {bytes_fmt(m.total)} total)"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_ram_monitor_cache(self, frame):
    """Cache — real standby/cached memory Windows is holding (reclaimable
    on demand), via the OS's own Memory performance counters."""
    panel = CardPanel(frame, self.theme, "Cache",
                       "Real file-system cache/standby memory Windows is currently holding - "
                       "this is reclaimed automatically when other programs need it, so it's "
                       "not 'wasted' RAM.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory | "
            "Select-Object CacheBytes,StandbyCacheNormalPriorityBytes,StandbyCacheReserveBytes,"
            "ModifiedPageListBytes | Format-List | Out-String -Width 150")
        return out or "No cache counter data found."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_ram_monitor_page_file(self, frame):
    """Page File — real page file size and current usage."""
    panel = CardPanel(frame, self.theme, "Page File",
                       "Real page file (virtual memory swap) size and current usage.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-CimInstance Win32_PageFileUsage | "
            "Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage | Format-List | Out-String -Width 150")
        return out or "No page file usage data found (system-managed page file may report differently)."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)






def tool_ram_monitor_process_usage(self, frame):
    """Process Usage — real top processes by RAM (RSS) usage."""
    panel = CardPanel(frame, self.theme, "Process Usage",
                       "Real top processes ranked by actual memory usage (working set).",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if psutil is None:
            return _need_psutil()
        rows = []
        for p in psutil.process_iter(["pid", "name", "memory_info"]):
            try:
                mi = p.info["memory_info"]
                if mi:
                    rows.append((p.info["name"] or "?", p.info["pid"], mi.rss))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        rows.sort(key=lambda r: r[2], reverse=True)
        lines = [f"{'PID':>7}  {'RAM':>10}  Process"]
        for name, pid, rss in rows[:25]:
            lines.append(f"{pid:>7}  {bytes_fmt(rss):>10}  {name}")
        return "\n".join(lines)

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)




