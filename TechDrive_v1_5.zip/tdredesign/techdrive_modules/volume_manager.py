#!/usr/bin/env python3
r"""
techdrive_modules/volume_manager.py - Volume Manager category
=================================================================
A second, distinctly-named set of partition/volume tools, built the
same way as Partition Tools: diskpart, PowerShell's Storage/BitLocker
modules, and the same raw-device access clone_tools.py already uses
for whole-disk imaging - here applied to a single partition's byte
range instead of an entire disk.

Everything that touches a physical disk or a live volume needs
Administrator on Windows. Every destructive action confirms first.
"""

import json
import os
import struct
import tkinter as tk
from tkinter import ttk
from gui.tk_dialogs import filedialog

from gui.theme import FONT_UI, FONT_MONO
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.clone_tools import (
    _disk_picker, _confirm_destructive, JobUI, copy_stream,
)
from techdrive_modules.partition_tools import (
    bytes_fmt, run_diskpart, _volume_picker, _confirm, _labeled_entry,
    _labeled_combo, _elevation_note, IS_WINDOWS,
)

CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers local to this module
# ---------------------------------------------------------------------------
def get_partition_extent(disk_id, part_num):
    """Returns (offset_bytes, size_bytes) for a disk+partition number, or
    (None, None) if it can't be found."""
    ok, out = hw.powershell(
        f"Get-Partition -DiskNumber {disk_id} -PartitionNumber {part_num} "
        "| Select-Object Offset,Size | ConvertTo-Json -Compress")
    if not ok or not out.strip().startswith("{"):
        return None, None
    try:
        d = json.loads(out)
        return int(d["Offset"]), int(d["Size"])
    except Exception:
        return None, None


def _disk_partnum_row(self, parent):
    """Disk picker + a plain partition-number entry beside it - simpler
    than building a full partition dropdown, and Partition Info already
    shows the numbers if you need a reminder."""
    disk = _disk_picker(self, parent, "Disk")
    partnum = _labeled_entry(parent, self.theme, "Partition number", "1")
    return disk, partnum


# ---------------------------------------------------------------------------
# New Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Format Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Delete Current Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Hide / Unhide Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Modify Partition Parameters (raw type ID / GUID change)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Resize Volume
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Extend Partition (grow-only, shows max first)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Split Volume
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Clone Partition to Image / Restore Partition from Image
# ---------------------------------------------------------------------------




# ---------------------------------------------------------------------------
# Remove Drive Letter
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Set Volume Label
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Change Volume Serial (raw boot-sector VSN patch)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Optimize Partition (TRIM)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# BitLocker Manager
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Reload Partition
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Smart Mount Partition
# ---------------------------------------------------------------------------
_SYSTEM_GUIDS = {
    "e3c9e316-0b5c-4db8-817d-f92df00215ae",  # Microsoft Reserved (MSR)
    "c12a7328-f81f-11d2-ba4b-00a0c93ec93b",  # EFI System Partition
    "de94bba4-06d1-4d40-a16a-bfd50179d6ac",  # Windows Recovery
}


