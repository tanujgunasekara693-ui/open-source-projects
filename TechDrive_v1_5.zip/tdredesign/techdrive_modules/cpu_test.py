#!/usr/bin/env python3
"""
Module: cpu_test
Generated for TechDrive 500
Category: CPU Test

All 10 tools below run real CPU workloads via multiprocessing (genuine
100% load across real cores/processes, not a canned number). Where a
tool is named after a well-known benchmark, the docstring is upfront
about what it approximates and why (this app can't bundle Prime95's
FFT engine or Cinebench's actual renderer, so each one uses an honestly
comparable real workload instead of faking that tool's exact output).

  - Stress Test        -> sustained FPU/cache load across all logical
                          cores, Start/Stop, live temperature
  - Benchmark           -> SHA-256 hashing, single-core vs multi-core
                          throughput (ops/sec)
  - Stability Test      -> stress load + a deterministic checksum
                          re-verified every pass on every worker, to
                          catch real silent computation errors (the
                          kind an unstable overclock produces)
  - Prime95 Style       -> real trial-division prime search across all
                          cores (same "find primes, burn the FPU,
                          verify correctness" idea Prime95 uses, without
                          its proprietary FFT/Lucas-Lehmer engine)
  - Linpack Style       -> real dense NxN matrix-multiply, timed and
                          converted to GFLOPS (same FLOP-counting idea
                          as Linpack, using multiply instead of an LU solve)
  - Cinebench Style     -> real per-pixel Mandelbrot escape-time render,
                          single-core vs multi-core (same "render tiles
                          across all cores" idea Cinebench uses)
  - Geekbench Style     -> a small real mixed-workload suite (integer,
                          floating point, and crypto hashing), each timed
                          and combined into a single-core/multi-core score
  - Thermal Test        -> sustained full load while sampling real CPU
                          temperature + clock speed every second, with
                          the same automatic safety cutoff as Stress Test
  - Core Test           -> pins a worker to each logical core in turn
                          (real Windows CPU affinity) and times an
                          identical workload on each, to flag any one
                          core that's measurably slower than the rest
  - Thread Test         -> runs the same workload at 1, 2, 4... up to
                          all logical cores and reports real throughput
                          and scaling efficiency at each thread count
"""

import os
import re
import time
import math
import random
import hashlib
import socket
import platform
import subprocess
import multiprocessing
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"
_SAFETY_TEMP_C = 95


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers / top-level worker functions
# (must be module-level so multiprocessing's spawn method on Windows can
# pickle and import them in child processes)
# ---------------------------------------------------------------------------

def _cpu_temperature():
    """Real CPU temperature via WMI's ACPI thermal zone, best-effort."""
    if not IS_WINDOWS or wmi_module is None:
        if not IS_WINDOWS:
            return None
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-CimInstance -Namespace root/WMI -ClassName MSAcpi_ThermalZoneTemperature "
                 "-ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty CurrentTemperature"],
                capture_output=True, text=True, timeout=8)
            v = r.stdout.strip()
            return round(int(v) / 10.0 - 273.15, 1) if v.isdigit() else None
        except Exception:
            return None
    try:
        w = wmi_module.WMI(namespace="root\\wmi")
        temps = w.MSAcpi_ThermalZoneTemperature()
        if temps:
            return round((temps[0].CurrentTemperature / 10.0) - 273.15, 1)
    except Exception:
        pass
    return None


def _hash_worker(duration_s):
    """SHA-256 hashing throughput for duration_s seconds. Returns hash count."""
    end = time.time() + duration_s
    count = 0
    block = os.urandom(64)
    h = hashlib.sha256
    while time.time() < end:
        for _ in range(2000):
            h(block).digest()
        count += 2000
    return count


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _prime_worker(args):
    """Trial-division prime search starting at a per-worker offset, for
    duration_s seconds. Returns (numbers_tested, primes_found, highest_n)."""
    start_n, duration_s = args
    end = time.time() + duration_s
    n = start_n | 1  # ensure odd
    tested = 0
    primes = 0
    while time.time() < end:
        if _is_prime(n):
            primes += 1
        tested += 1
        n += 2
    return tested, primes, n


def _matrix_multiply_worker(n):
    """Dense NxN matrix multiply (pure Python), returns (elapsed_seconds, n)."""
    random.seed(42)
    a = [[random.random() for _ in range(n)] for _ in range(n)]
    b = [[random.random() for _ in range(n)] for _ in range(n)]
    b_t = list(zip(*b))
    t0 = time.perf_counter()
    result = [[sum(x * y for x, y in zip(row, col)) for col in b_t] for row in a]
    elapsed = time.perf_counter() - t0
    checksum = sum(result[0]) if result else 0.0
    return elapsed, n, checksum


def _mandelbrot_worker(duration_s):
    """Per-pixel Mandelbrot escape-time computation for duration_s seconds.
    Returns (pixels_computed, iteration_checksum) — a real render-style
    per-tile workload, same shape as Cinebench's tile rendering."""
    end = time.time() + duration_s
    max_iter = 100
    pixels = 0
    checksum = 0
    x, y = -0.5, 0.0
    w = h = 400
    while time.time() < end:
        for py in range(h):
            if time.time() >= end:
                break
            for px in range(w):
                cx = (px - w / 2) / (w / 4) + x
                cy = (py - h / 2) / (h / 4) + y
                zr = zi = 0.0
                it = 0
                while zr * zr + zi * zi <= 4.0 and it < max_iter:
                    zr, zi = zr * zr - zi * zi + cx, 2 * zr * zi + cy
                    it += 1
                pixels += 1
                checksum = (checksum + it) & 0xFFFFFFFF
    return pixels, checksum


def _mixed_subtest(kind_and_iters):
    kind, iters = kind_and_iters
    t0 = time.perf_counter()
    if kind == "integer":
        x = 0
        for i in range(iters):
            x = (x * 1103515245 + 12345) & 0x7FFFFFFF
        result = x
    elif kind == "float":
        x = 1.0
        for i in range(iters):
            x = math.sqrt(abs(math.sin(x) * math.cos(x * 1.0001))) + 1.0
        result = x
    elif kind == "crypto":
        block = os.urandom(64)
        h = hashlib.sha256
        for i in range(iters):
            block = h(block).digest()
        result = block[0]
    else:
        result = None
    elapsed = time.perf_counter() - t0
    return kind, elapsed, result


def _stability_worker(stop_flag, duration_s, result_array, idx):
    """Repeats a deterministic SHA-256 chain and checks the result against
    a known-correct reference value every pass — a genuine silent-error
    detector (the kind of miscalculation an unstable overclock produces).
    Writes (passes_completed, errors_found) into result_array at idx*2."""
    seed = b"techdrive-cpu-stability-reference-seed"
    expected = hashlib.sha256(seed)
    for _ in range(2000):
        expected = hashlib.sha256(expected.digest())
    expected_digest = expected.digest()

    end = time.time() + duration_s
    passes = 0
    errors = 0
    while time.time() < end and not stop_flag.value:
        h = hashlib.sha256(seed)
        for _ in range(2000):
            h = hashlib.sha256(h.digest())
        if h.digest() != expected_digest:
            errors += 1
        passes += 1
    result_array[idx * 2] = passes
    result_array[idx * 2 + 1] = errors


def _fpu_load_worker(stop_flag, duration_s):
    """FPU/cache pressure workload used by Stress Test / Thermal Test —
    trig/sqrt math over a buffer too large for most L2 caches."""
    import array
    end = time.time() + duration_s
    buf = array.array("d", [float(i) for i in range(2_000_000)])
    n = len(buf)
    i = 0
    while time.time() < end and not stop_flag.value:
        x = buf[i % n]
        buf[i % n] = math.sqrt(abs(math.sin(x) * math.cos(x) * 1234.5678)) + 1.0
        i += 1


def _core_pin_worker(args):
    """Pins this process to one logical core (real Windows CPU affinity)
    and runs the hash workload, so throughput can be compared core-by-core."""
    core_id, duration_s = args
    if psutil is not None:
        try:
            psutil.Process().cpu_affinity([core_id])
        except Exception:
            pass
    count = _hash_worker(duration_s)
    return core_id, count


# ---------------------------------------------------------------------------
# 1. Stress Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 2. Benchmark
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 3. Stability Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 4. Prime95 Style
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 5. Linpack Style
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 6. Cinebench Style
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 7. Geekbench Style
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 8. Thermal Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 9. Core Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 10. Thread Test
# ---------------------------------------------------------------------------
