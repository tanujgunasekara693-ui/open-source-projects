import logging
logger = logging.getLogger("TechDrive.IDE")
import tkinter as tk
import re
from ._ide_themes import THEMES
from ._ide_languages import LANG_DEFS

class CodeEditor(tk.Frame):
    def __init__(self, parent, language='txt', theme_name='dark'):
        super().__init__(parent, bg=THEMES[theme_name]['bg'])
        self.language = language
        self.theme_name = theme_name
        self.colors = THEMES[theme_name]

        self.text = tk.Text(self, wrap='none', undo=True,
                            bg=self.colors['bg'], fg=self.colors['fg'],
                            insertbackground=self.colors['insertbackground'],
                            selectbackground=self.colors['select_bg'],
                            font=('Consolas', 11), padx=5, pady=5,
                            relief='flat', borderwidth=0)
        self.linenumbers = tk.Canvas(self, width=40, bg=self.colors['lineno_bg'],
                                     highlightthickness=0, relief='flat')
        self.linenumbers.pack(side='left', fill='y')
        self.text.pack(side='right', expand=True, fill='both')

        # Bindings
        self.text.bind('<KeyRelease>', self.on_key_release)
        self.text.bind('<Return>', lambda e: None)
        self.text.bind('<KeyRelease-Return>', self.auto_indent_after)
        self.text.bind('<Tab>', self.handle_tab)
        self.text.bind('<MouseWheel>', self.on_scroll)
        self.text.bind('<Button-4>', self.on_scroll)
        self.text.bind('<Button-5>', self.on_scroll)
        self.text.bind('<<Modified>>', self.on_modified)
        self.linenumbers.bind('<MouseWheel>', self.on_scroll)
        self.linenumbers.bind('<Button-4>', self.on_scroll)
        self.linenumbers.bind('<Button-5>', self.on_scroll)

        self.update_line_numbers()
        self.highlight()

    def on_key_release(self, event=None):
        self.highlight()
        self.update_line_numbers()

    def auto_indent_after(self, event):
        current_line = self.text.index('insert').split('.')[0]
        prev_line_num = int(current_line) - 1
        if prev_line_num < 1:
            return
        prev_line = self.text.get(f'{prev_line_num}.0', f'{prev_line_num}.0 lineend')
        match = re.match(r'^(\s*)', prev_line)
        indent = match.group(1) if match else ''
        if re.search(r'[:\{]\s*$', prev_line):
            indent += '    '
        self.text.insert(f'{current_line}.0', indent)
        self.text.mark_set('insert', f'{current_line}.0+{len(indent)}c')
        return 'break'

    def handle_tab(self, event):
        self.text.insert('insert', '    ')
        return 'break'

    def on_modified(self, event=None):
        self.update_line_numbers()
        self.text.edit_modified(False)

    def on_scroll(self, event):
        if event.delta:
            delta = -1 * (event.delta // 120)
        else:
            delta = 1 if event.num == 5 else -1
        self.text.yview_scroll(delta, 'units')
        self.update_line_numbers()
        return 'break'

    def update_line_numbers(self):
        self.linenumbers.delete('all')
        first = self.text.index('@0,0')
        last = self.text.index(f'@0,{self.text.winfo_height()}')
        first_lineno = int(first.split('.')[0])
        last_lineno = int(last.split('.')[0])
        if last_lineno < first_lineno:
            last_lineno = first_lineno
        for i in range(first_lineno, last_lineno + 1):
            dline = self.text.dlineinfo(f'{i}.0')
            if dline:
                y = dline[1]
                self.linenumbers.create_text(2, y, anchor='nw',
                                             text=str(i),
                                             fill=self.colors['lineno_fg'],
                                             font=('Consolas', 10))

    def highlight(self):
        for tag in list(self.text.tag_names()):
            if tag not in ('sel', 'bracket_match'):
                self.text.tag_delete(tag)

        color_map = {
            'keyword': self.colors['keyword'],
            'string': self.colors['string'],
            'comment': self.colors['comment'],
            'number': self.colors['number'],
            'tag': self.colors['tag'],
            'attribute': self.colors['attribute'],
            'operator': self.colors['operator'],
            'builtin': self.colors['builtin'],
            'function': self.colors['function'],
            'class': self.colors['class'],
            'regex': self.colors['regex'],
            'css_prop': self.colors['css_prop'],
            'css_value': self.colors['css_value'],
            'preprocessor': self.colors['keyword'],
            'annotations': self.colors['function'],
            'cmdlets': self.colors['builtin'],
            'variables': self.colors['attribute'],
            'targets': self.colors['tag'],
            'commands': self.colors['string'],
        }
        for tag, color in color_map.items():
            self.text.tag_configure(tag, foreground=color)

        lang_patterns = {
            'html': [
                ('comment', LANG_DEFS['html']['comments']),
                ('tag', LANG_DEFS['html']['tags']),
                ('attribute', LANG_DEFS['html']['attributes']),
                ('string', LANG_DEFS['html']['strings']),
            ],
            'css': [
                ('comment', LANG_DEFS['css']['comments']),
                ('tag', LANG_DEFS['css']['selectors']),
                ('css_prop', LANG_DEFS['css']['properties']),
                ('string', LANG_DEFS['css']['strings']),
                ('number', LANG_DEFS['css']['numbers']),
                ('function', LANG_DEFS['css']['functions']),
            ],
            'javascript': [
                ('comment', LANG_DEFS['javascript']['comments']),
                ('keyword', LANG_DEFS['javascript']['keywords']),
                ('builtin', LANG_DEFS['javascript']['builtins']),
                ('string', LANG_DEFS['javascript']['strings']),
                ('number', LANG_DEFS['javascript']['numbers']),
                ('operator', LANG_DEFS['javascript']['operators']),
            ],
            'python': [
                ('comment', LANG_DEFS['python']['comments']),
                ('keyword', LANG_DEFS['python']['keywords']),
                ('builtin', LANG_DEFS['python']['builtins']),
                ('string', LANG_DEFS['python']['strings']),
                ('number', LANG_DEFS['python']['numbers']),
                ('decorator', LANG_DEFS['python']['decorators']),
            ],
            'java': [
                ('comment', LANG_DEFS['java']['comments']),
                ('keyword', LANG_DEFS['java']['keywords']),
                ('builtin', LANG_DEFS['java']['builtins']),
                ('string', LANG_DEFS['java']['strings']),
                ('number', LANG_DEFS['java']['numbers']),
                ('annotations', LANG_DEFS['java']['annotations']),
            ],
            'c': [
                ('comment', LANG_DEFS['c']['comments']),
                ('keyword', LANG_DEFS['c']['keywords']),
                ('preprocessor', LANG_DEFS['c']['preprocessor']),
                ('string', LANG_DEFS['c']['strings']),
                ('number', LANG_DEFS['c']['numbers']),
            ],
            'cpp': [
                ('comment', LANG_DEFS['cpp']['comments']),
                ('keyword', LANG_DEFS['cpp']['keywords']),
                ('preprocessor', LANG_DEFS['cpp']['preprocessor']),
                ('string', LANG_DEFS['cpp']['strings']),
                ('number', LANG_DEFS['cpp']['numbers']),
            ],
            'powershell': [
                ('comment', LANG_DEFS['powershell']['comments']),
                ('keyword', LANG_DEFS['powershell']['keywords']),
                ('cmdlets', LANG_DEFS['powershell']['cmdlets']),
                ('string', LANG_DEFS['powershell']['strings']),
                ('variables', LANG_DEFS['powershell']['variables']),
            ],
            'json': [
                ('string', LANG_DEFS['json']['strings']),
                ('number', LANG_DEFS['json']['numbers']),
                ('keyword', LANG_DEFS['json']['keywords']),
            ],
            'batch': [
                ('comment', LANG_DEFS['batch']['comments']),
                ('keyword', LANG_DEFS['batch']['keywords']),
                ('string', LANG_DEFS['batch']['strings']),
                ('variables', LANG_DEFS['batch']['variables']),
            ],
            'assembly': [
                ('comment', LANG_DEFS['assembly']['comments']),
                ('keyword', LANG_DEFS['assembly']['keywords']),
                ('number', LANG_DEFS['assembly']['numbers']),
                ('string', LANG_DEFS['assembly']['strings']),
            ],
            'makefile': [
                ('comment', LANG_DEFS['makefile']['comments']),
                ('targets', LANG_DEFS['makefile']['targets']),
                ('variables', LANG_DEFS['makefile']['variables']),
                ('commands', LANG_DEFS['makefile']['commands']),
            ],
            'txt': []
        }

        patterns = lang_patterns.get(self.language, [])
        content = self.text.get('1.0', 'end-1c')
        for tag, pattern in patterns:
            for match in pattern.finditer(content):
                start = f'1.0+{match.start()}c'
                end = f'1.0+{match.end()}c'
                self.text.tag_add(tag, start, end)

    def set_language(self, lang):
        self.language = lang
        self.highlight()

    def apply_theme(self, theme_name):
        self.theme_name = theme_name
        self.colors = THEMES[theme_name]
        self.text.configure(bg=self.colors['bg'], fg=self.colors['fg'],
                            insertbackground=self.colors['insertbackground'],
                            selectbackground=self.colors['select_bg'])
        self.linenumbers.configure(bg=self.colors['lineno_bg'])
        self.update_line_numbers()
        self.highlight()

    def get_text(self):
        return self.text.get('1.0', 'end-1c')

    def set_text(self, content):
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', content)

    def undo(self):
        try:
            self.text.edit_undo()
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass

    def redo(self):
        try:
            self.text.edit_redo()
        except Exception as e:
            logger.debug("IDE operation failed: %s", e)
            pass