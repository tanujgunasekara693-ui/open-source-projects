#!/usr/bin/env python3
r"""
techdrive_modules/network_tools.py - Network Tools category
======================================================================
Real, working network diagnostics via Windows' own command-line tools
(ipconfig, ping, tracert, netstat, arp, route) plus a live psutil-based
bandwidth monitor. Nothing here is simulated output.
"""

import platform
import socket
import subprocess
import time
import tkinter as tk
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


CATALOGUE = [('Network Tools',
  '◎',
  ['Network Info',
   'Adapters',
   'IP Config',
   'Ping',
   'Traceroute',
   'DNS Lookup',
   'Routing Table',
   'Monitor'])]


def _run(args, timeout=30):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        return (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Operation timed out."
    except Exception as e:
        return f"Error: {e}"


def _powershell(script, timeout=25):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def tool_network_tools_network_info(self, frame):
    """Network Info — full real output of `ipconfig /all`."""
    panel = CardPanel(frame, self.theme, "Network Info", "Full network configuration for every adapter (ipconfig /all).",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["ipconfig", "/all"]) or "No output."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_network_tools_adapters(self, frame):
    """Adapters — real adapter list (name, status, link speed, MAC) via Get-NetAdapter."""
    panel = CardPanel(frame, self.theme, "Adapters", "Every network adapter on this system with its real status and link speed.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-NetAdapter | Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress | "
            "Format-Table -AutoSize | Out-String -Width 200")
        return out.strip() or "No adapters found."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_network_tools_ip_config(self, frame):
    """IP Config — quick real output of plain `ipconfig` (summary form)."""
    panel = CardPanel(frame, self.theme, "IP Config", "Quick summary of IP addresses per adapter (plain ipconfig).",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["ipconfig"]) or "No output."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_network_tools_ping(self, frame):
    """Ping — real ICMP ping to a host of the user's choosing."""
    panel = CardPanel(frame, self.theme, "Ping", "Sends real ICMP pings to a host and reports the results.")
    host_var = self._entry_row(panel.body, "Host to ping:", "8.8.8.8")

    def run():
        host = host_var.get().strip() or "8.8.8.8"
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["ping", "-n", "4", host], timeout=20) or "No output."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._button_row(panel.body, [("Run Ping", lambda: self._run_bg(run, redraw))])


def tool_network_tools_traceroute(self, frame):
    """Traceroute — real hop-by-hop route trace via tracert."""
    panel = CardPanel(frame, self.theme, "Traceroute", "Traces the real network hops to a host (tracert).")
    host_var = self._entry_row(panel.body, "Host to trace:", "8.8.8.8")

    def run():
        host = host_var.get().strip() or "8.8.8.8"
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["tracert", "-d", host], timeout=60) or "No output."

    def redraw(r):
        panel.clear()
        panel.report(r)

    def go():
        panel.clear()
        panel.stat("Status", "Tracing route (can take up to a minute)...")
        self._run_bg(run, redraw)

    self._button_row(panel.body, [("Run Traceroute", go)])


def tool_network_tools_dns_lookup(self, frame):
    """DNS Lookup — real forward (and reverse, if it's an IP) DNS resolution."""
    panel = CardPanel(frame, self.theme, "DNS Lookup", "Resolves a real hostname to its IP address(es), or an IP back to a hostname.")
    host_var = self._entry_row(panel.body, "Hostname or IP:", "example.com")

    def run():
        target = host_var.get().strip()
        if not target:
            return "Enter a hostname or IP address."
        try:
            socket.inet_aton(target)
            is_ip = True
        except OSError:
            is_ip = False
        try:
            if is_ip:
                name, aliases, addrs = socket.gethostbyaddr(target)
                return f"{target} -> {name}\nAliases: {aliases or 'none'}"
            else:
                name, aliases, addrs = socket.gethostbyname_ex(target)
                return f"{target} -> {', '.join(addrs)}\nCanonical name: {name}\nAliases: {aliases or 'none'}"
        except Exception as e:
            return f"Lookup failed: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._button_row(panel.body, [("Lookup", lambda: self._run_bg(run, redraw))])






def tool_network_tools_routing_table(self, frame):
    """Routing Table — real IPv4/IPv6 routing table via `route print`."""
    panel = CardPanel(frame, self.theme, "Routing Table", "The real current IPv4/IPv6 routing table (route print).",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        return _run(["route", "print"]) or "No output."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_network_tools_monitor(self, frame):
    """Monitor — live real-time upload/download rate, sampled from the
    OS's actual network byte counters (psutil.net_io_counters)."""
    panel = CardPanel(frame, self.theme, "Monitor",
                       "Live upload/download speed, computed from real byte counters the OS "
                       "tracks for all network interfaces combined.")

    state = {"running": False, "last": None, "last_t": None}

    def render(down_text="-- ", up_text="-- "):
        panel.clear()
        panel.stat("↓ Download", down_text)
        panel.stat("↑ Upload", up_text)

    def tick():
        if not state["running"]:
            return
        if psutil is None:
            render("psutil not available", "psutil not available")
            return
        now = time.time()
        counters = psutil.net_io_counters()
        if state["last"] is not None:
            dt = now - state["last_t"]
            if dt > 0:
                down_bps = (counters.bytes_recv - state["last"].bytes_recv) / dt
                up_bps = (counters.bytes_sent - state["last"].bytes_sent) / dt
                render(f"{bytes_fmt(down_bps)}/s", f"{bytes_fmt(up_bps)}/s")
        state["last"] = counters
        state["last_t"] = now
        frame.after(1000, tick)

    def start():
        if psutil is None:
            render("psutil not available", "psutil not available")
            return
        state["running"] = True
        state["last"] = None
        tick()

    def stop():
        state["running"] = False
        render()

    render()
    self._button_row(panel.body, [
        ("Start Monitoring", start),
        ("Stop", stop),
    ])
