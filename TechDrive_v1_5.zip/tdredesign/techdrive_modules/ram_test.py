#!/usr/bin/env python3
"""
Module: ram_test
Generated for TechDrive 500
Category: RAM Test

Real implementations. Every test below actually allocates memory and does
real reads/writes/timing - nothing here calls `systeminfo` as a placeholder.
Sizes are chosen conservatively (tens to a few hundred MB, a few seconds)
so a panel click doesn't lock up or OOM someone's machine; "Error Scan" is
the one long/large test and asks for confirmation first.
"""

import platform
import time
from gui.tk_dialogs import simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import psutil
except ImportError:
    psutil = None

try:
    from techdrive_modules import hw_sensors as hw
except ImportError:
    hw = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
def _available_bytes():
    if psutil:
        try:
            return psutil.virtual_memory().available
        except Exception:
            pass
    return 2 * 1024 ** 3  # conservative fallback guess


def _safe_test_size(requested_mb, cap_fraction=0.35, hard_cap_mb=2048):
    """Never try to allocate more than a fraction of free RAM, or more than
    hard_cap_mb, whichever is smaller."""
    avail = _available_bytes()
    cap_mb = min(hard_cap_mb, int((avail * cap_fraction) / (1024 * 1024)))
    return max(16, min(requested_mb, cap_mb))


def _fill(buf, byte_val):
    buf[:] = bytes([byte_val]) * len(buf)


def _verify_fast(buf, byte_val):
    """Fast pass/fail + first-mismatch-offset check using bytes.count."""
    mv = bytes(buf)
    expected = bytes([byte_val]) * len(mv)
    if mv == expected:
        return 0, None
    # find first mismatch for a useful error message
    for i, (a, b) in enumerate(zip(mv, expected)):
        if a != b:
            return 1, i
    return 1, None


# ---------------------------------------------------------------------------
# Stress Test - sustained read/write for a few seconds, checked for corruption
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Benchmark - raw sequential write/read throughput
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# MemTest86 style - classic pattern sweep
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Memory Test - single quick pass
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Cache Test - latency at increasing working-set sizes (L1/L2/L3/RAM)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Speed Test - bandwidth across a range of block sizes
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# ECC Test - real ECC capability/status via WMI, plus WHEA corrected-error log
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Stability Test - sustained combined CPU+memory load with integrity checks
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Error Scan - larger pattern scan across more of free RAM
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Diagnostic Test - aggregate summary
# ---------------------------------------------------------------------------
