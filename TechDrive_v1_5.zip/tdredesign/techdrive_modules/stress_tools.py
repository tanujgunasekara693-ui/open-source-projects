#!/usr/bin/env python3
r"""
techdrive_modules/stress_tools.py - Stress & Stability Tools category
========================================================================
System Stability Test pushes CPU/FPU/cache/memory with real multiprocess
math workloads (genuinely 100% CPU across all cores) and watches
temperature live, aborting automatically if things get dangerously hot -
a real safety cutoff, not a decoration.

Full GPU load-testing (FurMark-style) needs an actual rendering/compute
workload (DirectX/OpenGL/CUDA) that a Tkinter app can't generate without
bundling a separate compute engine, so this is honestly scoped to
CPU/cache/memory; GPU Performance Test (Benchmarking Tools) and the
NVIDIA GPU category cover the GPU side with real tools that already
exist on the machine.

Timers Test checks ACPI/QPC/RTC agreement using Windows' own w32tm and
Python's own perf_counter (QPC-backed on Windows) against the system
clock.
"""

import multiprocessing
import time
import tkinter as tk

from gui.theme import FONT_MONO, status_color
from techdrive_modules import hw_sensors as hw
from techdrive_modules.live_monitor import _shell
from techdrive_modules.partition_tools import IS_WINDOWS, _labeled_entry

CATALOGUE = []

_SAFETY_TEMP_C = 95


def _stress_worker(stop_flag, duration_s):
    """CPU + FPU + cache + memory pressure: trig/sqrt math (FPU) over a
    large array that doesn't fit in most L2/L3 caches (cache + memory
    bandwidth), run until stop_flag is set or duration elapses."""
    import math
    import array
    end = time.time() + duration_s
    buf = array.array("d", [float(i) for i in range(2_000_000)])  # ~16MB, exceeds most L2
    n = len(buf)
    i = 0
    while time.time() < end and not stop_flag.value:
        x = buf[i % n]
        buf[i % n] = math.sqrt(abs(math.sin(x) * math.cos(x) * 1234.5678)) + 1.0
        i += 1


# ---------------------------------------------------------------------------
# System Stability Test
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Timers Test
# ---------------------------------------------------------------------------
