THEMES = {
    'dark': {
        'bg': '#1e1e1e', 'fg': '#d4d4d4',
        'lineno_bg': '#2d2d2d', 'lineno_fg': '#858585',
        'insertbackground': '#ffffff', 'select_bg': '#264f78',
        'keyword': '#569cd6', 'string': '#ce9178',
        'comment': '#6a9955', 'number': '#b5cea8',
        'tag': '#569cd6', 'attribute': '#9cdcfe',
        'operator': '#d4d4d4', 'builtin': '#c586c0',
        'function': '#dcdcaa', 'class': '#4ec9b0',
        'regex': '#d16969', 'css_prop': '#9cdcfe',
        'css_value': '#ce9178'
    },
    'light': {
        'bg': '#ffffff', 'fg': '#000000',
        'lineno_bg': '#f0f0f0', 'lineno_fg': '#808080',
        'insertbackground': '#000000', 'select_bg': '#add6ff',
        'keyword': '#0000ff', 'string': '#a31515',
        'comment': '#008000', 'number': '#098658',
        'tag': '#800000', 'attribute': '#ff0000',
        'operator': '#000000', 'builtin': '#0000ff',
        'function': '#795e26', 'class': '#267f99',
        'regex': '#811f3f', 'css_prop': '#ff0000',
        'css_value': '#0451a5'
    }
}