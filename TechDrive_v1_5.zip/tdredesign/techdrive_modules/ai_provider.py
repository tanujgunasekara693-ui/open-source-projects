#!/usr/bin/env python3
"""
techdrive_modules/ai_provider.py — AI Assistant backend
=========================================================
Optional online fallback for the Duck Assistant. The local knowledge base
in gui/duck_assistant.py is checked first and answers everything it can
entirely offline; this module is only used when there's no local match
AND the user has configured their own API key in Settings -> AI Assistant.

IMPORTANT: This module never contains, ships with, or falls back to any
built-in API key. Every request uses a key the user typed into Settings
themselves (stored locally via shared.database, same place every other
TechDrive preference lives). If no key is configured, `is_configured()`
returns False and callers should not attempt a network call.

Supported providers (chosen by the user in Settings):
  - "openrouter" -> https://openrouter.ai/api/v1/chat/completions
  - "groq"       -> https://api.groq.com/openai/v1/chat/completions

Both use an OpenAI-style chat/completions payload, so one small function
covers both.
"""

from shared import database as db

try:
    import requests
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False

PROVIDERS = {
    "openrouter": {
        "label": "OpenRouter",
        "url": "https://openrouter.ai/api/v1/chat/completions",
        "default_model": "openai/gpt-4o-mini",
    },
    "groq": {
        "label": "Groq",
        "url": "https://api.groq.com/openai/v1/chat/completions",
        "default_model": "llama-3.1-8b-instant",
    },
}

SYSTEM_PROMPT = (
    "You are the TechDrive Duck Assistant, a friendly PC-repair helper built "
    "into the TechDrive utility app. Answer the user's computer/PC question "
    "clearly and concisely (a few sentences). If the question isn't about "
    "computers or TechDrive, politely redirect to PC-related topics."
)


def guess_provider_from_key(key):
    """Groq and OpenRouter keys have distinct, well-known prefixes,
    so the provider can be auto-detected from the key itself. This
    exists so pasting a key from the 'wrong' provider selected in the
    UI (an easy mistake - the radio button doesn't change itself when
    you paste a new key) doesn't silently send it to the wrong API and
    produce a confusing 401."""
    key = (key or "").strip()
    if key.startswith("gsk_"):
        return "groq"
    if key.startswith("sk-or-"):
        return "openrouter"
    return None


def get_api_key():
    """Reads the user's own key from local settings. Empty string if unset."""
    return (db.get_setting("ai_api_key", "") or "").strip()


def get_provider():
    return db.get_setting("ai_provider", "openrouter")


def is_configured():
    """True only if the user has both a provider and a non-empty key saved."""
    return HAVE_REQUESTS and bool(get_api_key()) and get_provider() in PROVIDERS


def set_api_key(key):
    key = (key or "").strip()
    db.set_setting("ai_api_key", key)
    # Auto-correct the provider to match the key's own prefix, so a key
    # pasted while the "wrong" provider radio button is still selected
    # doesn't silently get sent to the wrong API (that always fails with
    # a confusing 401 instead of an obvious "wrong provider" message).
    guessed = guess_provider_from_key(key)
    if guessed:
        set_provider(guessed)


def set_provider(provider):
    if provider in PROVIDERS:
        db.set_setting("ai_provider", provider)


def clear_api_key():
    db.set_setting("ai_api_key", "")


def _list_models(cfg, key):
    """Best-effort GET of the provider's /models list. Returns a list of
    model id strings, or [] on any failure (never raises) - callers should
    fall back to the hardcoded default_model if this comes back empty."""
    models_url = cfg["url"].replace("/chat/completions", "/models")
    try:
        resp = requests.get(
            models_url,
            headers={"Authorization": f"Bearer {key}"},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json().get("data", [])
        return [m["id"] for m in data if "id" in m]
    except Exception:
        return []


def _pick_model(cfg, key):
    """Prefer the hardcoded default if the provider still confirms it's
    live; otherwise fall back to the first model /models actually lists,
    since providers retire model IDs and 'default_model' can go stale."""
    available = _list_models(cfg, key)
    if not available:
        return cfg["default_model"]
    if cfg["default_model"] in available:
        return cfg["default_model"]
    return available[0]


def diagnose(question="Say 'ready' if you can read this."):
    """Like ask(), but returns full raw diagnostic detail as a single text
    block instead of a one-line summary - for the Settings 'Diagnose' button
    so failures are actually debuggable from the GUI instead of guessed at.
    Never raises. Always returns a string, whether it succeeds or fails."""
    lines = []
    if not HAVE_REQUESTS:
        return "ERROR: the 'requests' package isn't installed."

    key = get_api_key()
    if not key:
        return "ERROR: no API key saved. Paste one above and click Save Key first."

    provider = get_provider()
    cfg = PROVIDERS.get(provider)
    if not cfg:
        return "ERROR: unknown provider selected."

    lines.append(f"Provider: {cfg['label']}")
    lines.append(f"Key length: {len(key)} chars, starts '{key[:8]}...', ends '...{key[-4:]}'")
    if key != key.strip():
        lines.append("WARNING: key has leading/trailing whitespace.")

    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    models_url = cfg["url"].replace("/chat/completions", "/models")

    lines.append(f"\n--- Step 1: GET {models_url} ---")
    available_models = []
    try:
        resp = requests.get(models_url, headers=headers, timeout=15)
        lines.append(f"HTTP status: {resp.status_code}")
        lines.append(f"Response body (first 800 chars):\n{resp.text[:800]}")
        if resp.status_code == 200:
            try:
                data = resp.json().get("data", [])
                available_models = [m["id"] for m in data if "id" in m]
                lines.append(f"\nModels available to this key ({len(available_models)}):")
                lines.extend(f"  - {m}" for m in available_models[:20])
            except Exception as e:
                lines.append(f"Could not parse model list: {e}")
    except requests.exceptions.ConnectionError as e:
        lines.append(f"CONNECTION ERROR - could not reach {cfg['label']} at all.")
        lines.append("This usually means a firewall/proxy is blocking outbound access "
                      "from this machine/network, not a bad key.")
        lines.append(f"Raw error: {e}")
        return "\n".join(lines)
    except requests.exceptions.Timeout:
        lines.append("TIMEOUT - no response within 15 seconds.")
        return "\n".join(lines)
    except Exception as e:
        lines.append(f"UNEXPECTED ERROR: {type(e).__name__}: {e}")
        return "\n".join(lines)

    model = cfg["default_model"] if cfg["default_model"] in available_models else (
        available_models[0] if available_models else cfg["default_model"]
    )
    lines.append(f"\n--- Step 2: POST {cfg['url']} using model '{model}' ---")

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": question}],
        "max_tokens": 40,
    }
    post_headers = dict(headers)
    if provider == "openrouter":
        post_headers["X-Title"] = "TechDrive Duck Assistant"

    try:
        resp2 = requests.post(cfg["url"], headers=post_headers, json=payload, timeout=20)
        lines.append(f"HTTP status: {resp2.status_code}")
        lines.append(f"Response body (first 1200 chars):\n{resp2.text[:1200]}")
        if resp2.status_code == 200:
            try:
                content = resp2.json()["choices"][0]["message"]["content"]
                lines.append(f"\n\u2713 SUCCESS - model replied: {content!r}")
            except Exception as e:
                lines.append(f"\nGot HTTP 200 but couldn't parse the reply: {e}")
        else:
            lines.append(f"\n\u2717 FAILED - see raw body above for the provider's own reason.")
    except Exception as e:
        lines.append(f"REQUEST FAILED: {type(e).__name__}: {e}")

    return "\n".join(lines)


def ask(question, timeout=20):
    """Sends `question` to the configured provider using the user's own key.

    Returns (ok: bool, text: str). Never raises - all failure paths (missing
    requests lib, no key configured, network error, bad response shape) are
    caught and turned into a friendly ok=False message so the calling UI
    thread can just display whatever comes back.
    """
    if not HAVE_REQUESTS:
        return False, "The 'requests' package isn't installed, so the online AI assistant is unavailable."

    key = get_api_key()
    if not key:
        return False, "No AI API key is configured. Add your own key in Settings -> AI Assistant."

    provider = get_provider()
    cfg = PROVIDERS.get(provider)
    if not cfg:
        return False, "Unknown AI provider configured."

    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    # OpenRouter asks integrators to identify the calling app; harmless to
    # omit on other providers so it's only added for that one.
    if provider == "openrouter":
        headers["X-Title"] = "TechDrive Duck Assistant"

    payload = {
        "model": _pick_model(cfg, key),
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": question},
        ],
        "max_tokens": 400,
    }

    try:
        resp = requests.post(cfg["url"], headers=headers, json=payload, timeout=timeout)
    except requests.exceptions.RequestException as e:
        return False, f"Couldn't reach {cfg['label']}: {e}"

    if resp.status_code == 401:
        return False, f"{cfg['label']} rejected the API key (401). Check the key in Settings -> AI Assistant."
    if resp.status_code == 404:
        return False, (
            f"{cfg['label']} returned 404 - the model '{cfg['default_model']}' isn't "
            f"available for this key (providers retire model IDs over time). "
            f"Try Test Key again - it now auto-detects a working model."
        )
    if resp.status_code == 429:
        return False, f"{cfg['label']} rate-limited this request (429). Try again shortly."
    if resp.status_code >= 400:
        return False, f"{cfg['label']} returned an error ({resp.status_code})."

    try:
        data = resp.json()
        text = data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError):
        return False, f"{cfg['label']} returned an unexpected response."

    return True, text
