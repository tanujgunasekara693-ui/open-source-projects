#!/usr/bin/env python3
"""
Module: recovery_advanced
Generated for TechDrive 500
Category: Recovery Advanced

Real implementation built entirely on what Windows itself already
tracks, with no bundled carving engine:
 - the Recycle Bin, queried and restored through the real Shell.Application
   COM object (the same API Explorer's own Recycle Bin uses)
 - System Restore points (Get-ComputerRestorePoint / Restore-Computer)
 - Volume Shadow Copies (vssadmin) for previous-version file recovery
 - Office's own AutoRecover/UnsavedFiles folders
 - reagentc.exe / the Windows Recovery Environment for full-system repair

Recovering data that's gone from all of the above (e.g. a formatted
drive, or files permanently deleted past the Recycle Bin) needs
low-level unallocated-space carving, which genuinely requires a
dedicated engine such as TestDisk/PhotoRec integrated at the C/C++
level — that's out of scope for a Python/Tk tool talking to raw
sectors safely, so those specific cases are reported honestly rather
than faked.
"""

import os
import re
import time
import glob
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel, PanelTextProxy

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def _ps(script, timeout=30):
    if not IS_WINDOWS:
        return False, "Windows-only feature."
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except FileNotFoundError:
        return False, "powershell.exe not found on this system."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


RECYCLE_BIN_LIST_SCRIPT = r"""
$sh = New-Object -ComObject Shell.Application
$rb = $sh.Namespace(0xA)
$items = $rb.Items()
$results = @()
for ($i = 0; $i -lt $items.Count; $i++) {
    $it = $items.Item($i)
    $results += [PSCustomObject]@{
        Index = $i
        Name = $it.Name
        Original = $rb.GetDetailsOf($it, 1)
        Deleted = $rb.GetDetailsOf($it, 2)
        Size = $rb.GetDetailsOf($it, 3)
    }
}
$results | ConvertTo-Json -Compress
"""


def _list_recycle_bin():
    """Returns (ok, list_of_dicts_or_error_string)."""
    ok, out = _ps(RECYCLE_BIN_LIST_SCRIPT, timeout=40)
    if not ok:
        return False, out
    import json
    try:
        data = json.loads(out) if out.strip() else []
        if isinstance(data, dict):
            data = [data]
        return True, data
    except Exception:
        return False, f"Could not parse Recycle Bin contents:\n{out}"


def _restore_recycle_bin(name_filter=None, exts=None):
    """Restores items from the Recycle Bin whose name matches
    name_filter (substring, case-insensitive) and/or whose extension is
    in exts, using the real Explorer 'Restore' verb (InvokeVerb undelete)."""
    filt_parts = []
    if name_filter:
        filt_parts.append(f"$it.Name -like '*{name_filter}*'")
    if exts:
        ext_check = " -or ".join([f"$it.Name.ToLower().EndsWith('{e}')" for e in exts])
        filt_parts.append(f"({ext_check})")
    condition = " -and ".join(filt_parts) if filt_parts else "$true"
    script = f"""
$sh = New-Object -ComObject Shell.Application
$rb = $sh.Namespace(0xA)
$items = $rb.Items()
$restored = 0
for ($i = 0; $i -lt $items.Count; $i++) {{
    $it = $items.Item($i)
    if ({condition}) {{
        $it.InvokeVerb("undelete")
        $restored++
    }}
}}
"Restored: $restored"
"""
    return _ps(script, timeout=60)


IMAGE_EXTS = ["jpg", "jpeg", "png", "gif", "bmp", "tif", "tiff", "heic", "webp", "raw", "cr2", "nef"]
VIDEO_EXTS = ["mp4", "mov", "avi", "mkv", "wmv", "flv", "m4v", "mpg", "mpeg"]
DOC_EXTS = ["doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf", "txt", "rtf", "odt"]


def _format_bin_listing(items, header):
    if not items:
        return f"{header}\n\nRecycle Bin is empty (or nothing matched the filter)."
    lines = [header, ""]
    for it in items:
        lines.append(f"  [{it.get('Index')}] {it.get('Name')}  "
                      f"({it.get('Size', '?')})  deleted {it.get('Deleted', '?')}  "
                      f"from {it.get('Original', '?')}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# tools
# ---------------------------------------------------------------------------


















