#!/usr/bin/env python3
"""
Module: disk_monitor
Category: Disk Monitor

Real disk telemetry: partition usage from psutil, throughput/IOPS sampled
live from psutil.disk_io_counters(), and queue-depth / busy-time read
straight from the kernel's own per-disk counters (/sys/block/*/stat on
Linux, WMI perf counters on Windows) - never simulated numbers.
"""

import os
import glob
import time
import platform

try:
    import psutil
except ImportError:
    psutil = None

from techdrive_modules import hw_sensors as hw
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"


def bytes_fmt(n):
    n = float(n or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _partitions():
    try:
        return hw.partitions()
    except Exception:
        return []


def _linux_block_devices():
    """Real block device names from /sys/block (skips loop/ram devices)."""
    out = []
    try:
        for name in sorted(os.listdir("/sys/block")):
            if name.startswith(("loop", "ram", "zram")):
                continue
            out.append(name)
    except OSError:
        pass
    return out


def _linux_diskstat(dev):
    """Parsed /sys/block/<dev>/stat - kernel's own counters, no sampling needed
    for the instantaneous 'in progress' field."""
    path = f"/sys/block/{dev}/stat"
    try:
        with open(path) as f:
            fields = f.read().split()
        # Standard /proc/diskstats field layout (11+ fields):
        # 0 reads 1 reads_merged 2 sectors_read 3 ms_reading
        # 4 writes 5 writes_merged 6 sectors_written 7 ms_writing
        # 8 ios_in_progress 9 ms_doing_io 10 weighted_ms_doing_io
        nums = [int(x) for x in fields]
        return {
            "reads": nums[0], "sectors_read": nums[2], "ms_reading": nums[3],
            "writes": nums[4], "sectors_written": nums[6], "ms_writing": nums[7],
            "ios_in_progress": nums[8] if len(nums) > 8 else None,
            "ms_doing_io": nums[9] if len(nums) > 9 else None,
        }
    except Exception:
        return None


def _windows_queue_length():
    """Current Disk Queue Length per physical disk via WMI perf counters."""
    ok, out = hw.powershell(
        "Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk | "
        "Where-Object { $_.Name -ne '_Total' } | "
        "Select-Object Name,CurrentDiskQueueLength,PercentDiskTime,AvgDiskSecPerTransfer | "
        "ConvertTo-Json -Compress")
    if not ok or not out.strip().startswith(("[", "{")):
        return None
    import json
    try:
        data = json.loads(out)
        return data if isinstance(data, list) else [data]
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 1. Usage Graph - per-partition usage as a bar
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 2. Read Speed
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 3. Write Speed
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 4. I/O (combined read+write throughput and IOPS)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 5. Queue Length
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 6. Response Time (avg service time per I/O, from real counters)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 7. Active Time (% of the sample window the disk was busy)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 8. Heatmap (usage-percent grid across all partitions)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 9. Partition Usage (detailed table)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 10. Performance Log (rolling I/O log)
# ---------------------------------------------------------------------------

