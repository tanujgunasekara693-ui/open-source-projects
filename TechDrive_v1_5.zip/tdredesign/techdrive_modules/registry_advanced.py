#!/usr/bin/env python3
"""
Module: registry_advanced
Generated for TechDrive 500
Category: Registry Advanced
"""

import os
import re
import time
import socket
import platform
import subprocess
import json
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel

try:
    import winreg
except ImportError:
    winreg = None

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []

_HIVE_MAP = {
    "HKCU": winreg.HKEY_CURRENT_USER if winreg else None,
    "HKLM": winreg.HKEY_LOCAL_MACHINE if winreg else None,
    "HKCR": winreg.HKEY_CLASSES_ROOT if winreg else None,
    "HKU": winreg.HKEY_USERS if winreg else None,
    "HKCC": winreg.HKEY_CURRENT_CONFIG if winreg else None,
}


def _parse_full_path(full_path):
    """Split 'HKCU\\Software\\Foo' into (hive_const, subpath)."""
    parts = full_path.strip().split("\\", 1)
    hive_name = parts[0].upper()
    if hive_name not in _HIVE_MAP:
        raise ValueError(f"Unknown hive '{hive_name}'. Use HKCU, HKLM, HKCR, HKU, or HKCC.")
    subpath = parts[1] if len(parts) > 1 else ""
    return _HIVE_MAP[hive_name], subpath, hive_name


# ---------------------------------------------------------------------------
# Editor — open regedit, or jump directly to a key via LastKey trick
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Backup — export a hive/key to a .reg file via reg.exe
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Restore — import a .reg file via reg.exe
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Cleaner — find obviously-broken entries (MUICache/Uninstall pointing to
# nonexistent files) — scan only, no destructive action without confirmation
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Compactor — report hive file sizes (Windows compacts automatically; this
# tool reports current sizes and can trigger a save via reg save)
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Monitor — poll a key's values over a short window and report changes
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Key Finder — recursive search for a key/value name under a chosen hive root
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Value Editor — read / set / delete a single registry value
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Permission Editor — view (and launch native ACL editor for) key permissions
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# Snapshot — dump a key tree (names + values) to a JSON file for later diff
# ---------------------------------------------------------------------------

