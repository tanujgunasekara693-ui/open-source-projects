#!/usr/bin/env python3
"""
Module: security_tools
Generated for TechDrive 500
Category: Security Tools

Real implementation. Every tool queries (and where it makes sense, lets
the user toggle) the actual state of a native Windows security feature —
Security Center via WMI, Defender/AppLocker/BitLocker/TPM via their own
PowerShell modules, the firewall via netsh, UAC/Secure Boot via the
registry and Confirm-SecureBootUEFI, Windows Update via UsoClient, and
the Security event log via Get-WinEvent. Nothing here is offensive
tooling — every action reads or hardens the machine's own settings and
requires the same Administrator elevation the native tools do.
"""

import os
import re
import time
import socket
import platform
import subprocess
from datetime import datetime
from gui.tk_dialogs import filedialog, simpledialog, messagebox
from gui.tool_view import CardPanel, PanelTextProxy

try:
    import psutil
except ImportError:
    psutil = None

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = [('Security Tools',
  '◆',
  ['Windows Security', 'Firewall', 'Defender', 'UAC', 'BitLocker', 'TPM', 'Windows Update'])]


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def _ps(script, timeout=30):
    """Runs a PowerShell script and returns (ok, stdout+stderr)."""
    if not IS_WINDOWS:
        return False, "Windows-only feature."
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, "Operation timed out."
    except FileNotFoundError:
        return False, "powershell.exe not found on this system."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _is_elevated():
    if not IS_WINDOWS:
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _elevation_note():
    if IS_WINDOWS and not _is_elevated():
        return "\n⚠ Not running as Administrator — some of these queries/changes need elevation to fully succeed.\n"
    return ""


# ---------------------------------------------------------------------------
# tools
# ---------------------------------------------------------------------------
def tool_security_tools_windows_security(self, frame):
    """Windows Security — real overall status pulled from the Security
    Center (antivirus, firewall, and auto-update state as Windows itself
    reports them), the same data the Windows Security app shows."""
    panel = CardPanel(frame, self.theme, "Windows Security",
                       "Overall protection status from the Windows Security Center.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            return "Windows-only feature."
        ok, out = _ps(
            "Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct | "
            "Select-Object displayName,productState | Format-List | Out-String -Width 200;"
            "Get-CimInstance -Namespace root/SecurityCenter2 -ClassName FirewallProduct | "
            "Select-Object displayName,productState | Format-List | Out-String -Width 200")
        header = "== Windows Security Center ==\n"
        body = out if out.strip() else "No Security Center data returned (some builds only expose this to signed-in sessions)."
        return header + body + _elevation_note() + \
            "\nOpen the full app any time: Start > Windows Security, or run: start windowsdefender:"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_security_tools_firewall(self, frame):
    """Firewall — real per-profile (Domain/Private/Public) state via
    netsh advfirewall, with buttons to turn each profile on or off."""
    panel = CardPanel(frame, self.theme, "Firewall",
                       "Windows Firewall status per network profile, with on/off control.",
                       on_refresh=lambda: self._run_bg(run, redraw))
    box = PanelTextProxy(panel)


    def gather():
        try:
            r = subprocess.run(["netsh", "advfirewall", "show", "allprofiles"],
                               capture_output=True, text=True, timeout=15)
            return (r.stdout or r.stderr or "No data.") + _elevation_note()
        except Exception as e:
            return f"Error: {e}"

    def set_state(state):
        def run():
            try:
                r = subprocess.run(["netsh", "advfirewall", "set", "allprofiles", "state", state],
                                   capture_output=True, text=True, timeout=15)
                return (r.stdout or r.stderr or "") + "\n\n" + gather()
            except Exception as e:
                return f"Error: {e}"
        self._run_bg(run, redraw)

    def redraw(r):
        panel.clear()
        panel.report(r)

    run = gather
    self._run_bg(run, redraw)

    self._run_bg(gather, lambda r: self._set_text(box, r))
    self._button_row(panel.body, [
        ("Refresh", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
        ("Turn ON (all profiles)", lambda: set_state("on")),
        ("Turn OFF (all profiles)", lambda: set_state("off")),
    ])


def tool_security_tools_defender(self, frame):
    """Defender — real Windows Defender status (Get-MpComputerStatus)
    plus a button to kick off a real quick scan (Start-MpScan)."""
    panel = CardPanel(frame, self.theme, "Defender",
                       "Windows Defender status, definitions age, and a real quick scan.",
                       on_refresh=lambda: self._run_bg(run, redraw))
    box = PanelTextProxy(panel)


    def gather():
        ok, out = _ps(
            "Get-MpComputerStatus | Select-Object AMServiceEnabled,AntispywareEnabled,"
            "AntivirusEnabled,RealTimeProtectionEnabled,IsTamperProtected,"
            "AntivirusSignatureLastUpdated,QuickScanAge,FullScanAge | Format-List | Out-String -Width 200")
        return (out if ok else f"Could not query Defender:\n{out}") + _elevation_note()

    def quick_scan():
        def run():
            ok, out = _ps("Start-MpScan -ScanType QuickScan", timeout=600)
            prefix = "Quick scan finished." if ok else "Quick scan reported an error."
            return f"{prefix}\n\n{out or '(no output)'}\n\n{gather()}"
        self._run_bg(run, redraw)

    def redraw(r):
        panel.clear()
        panel.report(r)

    run = gather
    self._run_bg(run, redraw)

    self._run_bg(gather, lambda r: self._set_text(box, r))
    self._button_row(panel.body, [
        ("Refresh status", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
        ("Run quick scan (can take a few minutes)", quick_scan),
    ])


def tool_security_tools_uac(self, frame):
    """UAC — reads the real EnableLUA / ConsentPromptBehaviorAdmin
    registry values that drive User Account Control, with a slider-style
    set of buttons for the standard notification levels."""
    panel = CardPanel(frame, self.theme, "UAC",
                       "User Account Control status and notification level.",
                       on_refresh=lambda: self._run_bg(run, redraw))
    box = PanelTextProxy(panel)

    KEY = r"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"

    def gather():
        ok, out = _ps(f"Get-ItemProperty -Path '{KEY}' | "
                       f"Select-Object EnableLUA,ConsentPromptBehaviorAdmin,PromptOnSecureDesktop | "
                       f"Format-List | Out-String -Width 200")
        levels = ("EnableLUA: 0=off, 1=on.  ConsentPromptBehaviorAdmin: 0=never notify, "
                  "2=notify (dim desktop off), 5=notify and dim desktop (Windows default).")
        return (out if ok else f"Could not read UAC settings:\n{out}") + "\n" + levels + _elevation_note()

    def set_level(consent, secure_desktop):
        def run():
            ok, out = _ps(f"Set-ItemProperty -Path '{KEY}' -Name ConsentPromptBehaviorAdmin -Value {consent}; "
                           f"Set-ItemProperty -Path '{KEY}' -Name PromptOnSecureDesktop -Value {secure_desktop}")
            return ("UAC level updated (sign out/in or restart Explorer to fully apply).\n\n" if ok
                    else f"Failed to update:\n{out}\n\n") + gather()
        self._run_bg(run, redraw)

    def redraw(r):
        panel.clear()
        panel.report(r)

    run = gather
    self._run_bg(run, redraw)

    self._run_bg(gather, lambda r: self._set_text(box, r))
    self._button_row(panel.body, [
        ("Refresh", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
        ("Always notify (max)", lambda: set_level(5, 1)),
        ("Notify, no dim (default-ish)", lambda: set_level(2, 0)),
        ("Never notify (not recommended)", lambda: set_level(0, 0)),
    ])


def tool_security_tools_bitlocker(self, frame):
    """BitLocker — real per-volume encryption status via manage-bde."""
    panel = CardPanel(frame, self.theme, "BitLocker",
                       "Drive encryption status for every volume, via manage-bde.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        if not IS_WINDOWS:
            return "Windows-only feature."
        try:
            r = subprocess.run(["manage-bde", "-status"], capture_output=True, text=True, timeout=20)
            out = r.stdout or r.stderr or "No data returned."
            return out + _elevation_note()
        except FileNotFoundError:
            return "manage-bde.exe not found — BitLocker isn't available on this Windows edition."
        except subprocess.TimeoutExpired:
            return "Operation timed out."
        except Exception as e:
            return f"Error: {e}"

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)


def tool_security_tools_tpm(self, frame):
    """TPM — real chip presence, version, and readiness via Get-Tpm."""
    panel = CardPanel(frame, self.theme, "TPM",
                       "Trusted Platform Module presence, version, and readiness.",
                       on_refresh=lambda: self._run_bg(run, redraw))


    def run():
        ok, out = _ps("Get-Tpm | Format-List | Out-String -Width 200")
        return (out if ok else f"Could not query TPM:\n{out}") + _elevation_note()

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)






def tool_security_tools_windows_update(self, frame):
    """Windows Update — real pending-update count via the Update Agent
    COM API, plus a button to trigger a real scan through UsoClient."""
    panel = CardPanel(frame, self.theme, "Windows Update",
                       "Checks for real pending updates and can trigger a scan.",
                       on_refresh=lambda: self._run_bg(run, redraw))
    box = PanelTextProxy(panel)


    def gather():
        ok, out = _ps(
            "$s = New-Object -ComObject Microsoft.Update.Session; "
            "$searcher = $s.CreateUpdateSearcher(); "
            "$result = $searcher.Search(\"IsInstalled=0 and Type='Software'\"); "
            "$result.Updates | Select-Object Title,IsMandatory | Format-Table -AutoSize | Out-String -Width 200",
            timeout=90)
        return (out if ok and out.strip() else "No pending updates found (or the search failed):\n" + out) + _elevation_note()

    def trigger_scan():
        def run():
            try:
                r = subprocess.run(["UsoClient", "StartScan"], capture_output=True, text=True, timeout=30)
                msg = "Update scan triggered via UsoClient (runs in the background)." if r.returncode == 0 \
                    else f"UsoClient returned code {r.returncode}: {r.stdout or r.stderr}"
            except FileNotFoundError:
                msg = "UsoClient.exe not found on this system."
            except Exception as e:
                msg = f"Error: {e}"
            return msg + "\n\n" + gather()
        self._run_bg(run, redraw)

    def redraw(r):
        panel.clear()
        panel.report(r)

    run = gather
    self._run_bg(run, redraw)

    self._run_bg(gather, lambda r: self._set_text(box, r))
    self._button_row(panel.body, [
        ("Refresh", lambda: self._run_bg(gather, lambda r: self._set_text(box, r))),
        ("Trigger update scan", trigger_scan),
        ("Open Windows Update settings", lambda: subprocess.Popen(["cmd", "/c", "start", "ms-settings:windowsupdate"])),
    ])


