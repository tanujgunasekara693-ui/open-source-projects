#!/usr/bin/env python3
r"""
techdrive_modules/disk_tools.py - Disk Tools category
======================================================================
Real, working quick-action disk utilities. These are lighter-weight
counterparts to the dedicated Partition Tools / Clone / Storage Health
categories elsewhere in the app - each one still does a genuine
operation, just scoped to a quick single-panel action:

- Disk Info / Volume Capacity: physical-disk inventory and mounted-volume
  capacity via PowerShell Storage cmdlets.
- Cleanup: genuinely deletes real temp files and empties the Recycle
  Bin, reporting actual space freed - not a launch-and-hope stub.
- Defrag: real `defrag` invocation.
- Partition Manager: real, read-only `Get-Partition`/`Get-Volume`
  listing (edits belong in the dedicated Partition Tools category).
- Secure Erase: real multi-pass free-space overwrite (same honest
  scope/limits as the Shredder Tools disk wipers).
- Clone: real file-level copy of one drive's contents to another.
- Free Space Check: read-only capacity check before large file operations.
  The dedicated Disk Test category owns the benchmark entry point.
- Space Analyzer: real recursive folder-size scan, sorted largest first.
- Format Tool: real `diskpart`-scripted quick format, gated behind a
  strong confirmation since it is destructive.
"""

import os
import platform
import subprocess
import time
import threading
import shutil
import re
import ctypes
from gui.tool_view import CardPanel
from gui.tk_dialogs import filedialog
from gui import sounds
from gui import achievements
from gui.disk_block_map import DiskScanProgress, ensure_disk_map

IS_WINDOWS = platform.system() == "Windows"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS and hasattr(subprocess, "CREATE_NO_WINDOW") else 0
_CHUNK = 4 * 1024 * 1024


def bytes_fmt(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


def windows_only_notice():
    return "Windows-only feature (this tool relies on Windows utilities)."


def _is_elevated():
    if not IS_WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _is_boot_or_system_volume(drive_letter):
    """Best-effort guard for boot/system volumes before formatting."""
    if not IS_WINDOWS:
        return True
    script = (f"$p = Get-Partition -DriveLetter '{drive_letter}' -ErrorAction SilentlyContinue; "
              "if ($p | Where-Object { $_.IsBoot -or $_.IsSystem }) { 'PROTECTED' } else { 'OK' }")
    result = _powershell(script, timeout=12).strip()
    # Fail closed when the safety check itself could not be completed.
    return result != "OK"


CATALOGUE = [('Disk Tools',
  '▤',
  ['Disk Info',
   'Cleanup',
   'Volume Capacity',
   'Partition Manager',
   'Clone',
   'Free Space Check',
   'Space Analyzer',
   'Format Tool'])]


def _run(args, timeout=30):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        return (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return f"{args[0]} not found on this system."
    except subprocess.TimeoutExpired:
        return "Operation timed out."
    except Exception as e:
        return f"Error: {e}"


def _powershell(script, timeout=25):
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def tool_disk_tools_disk_info(self, frame):
    """Disk Info — responsive, readable physical disk inventory."""
    panel = CardPanel(frame, self.theme, "Disk Info",
                       "Physical drives detected by Windows. Missing sensor data is shown as unavailable.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return {"error": windows_only_notice()}
        script = (
            "$ErrorActionPreference='Stop'; "
            "$d=@(Get-PhysicalDisk | Select-Object DeviceId,FriendlyName,MediaType,BusType,"
            "Size,HealthStatus,OperationalStatus); "
            "$d | ConvertTo-Json -Depth 3 -Compress"
        )
        out = _powershell(script, timeout=25).strip()
        if out and not out.lower().startswith(('get-physicaldisk', 'the term')):
            try:
                import json
                data = json.loads(out)
                if isinstance(data, dict):
                    data = [data]
                if data:
                    return {"disks": data}
            except (ValueError, TypeError):
                pass
        # Older Windows editions may not expose the Storage module cmdlet.
        fallback = _run(["wmic", "diskdrive", "get", "Model,Size,Status,InterfaceType", "/format:csv"], timeout=15)
        rows = []
        for line in fallback.splitlines():
            cols = [c.strip() for c in line.split(',')]
            if len(cols) >= 5 and cols[-1] and cols[-1].lower() != 'model':
                rows.append({"FriendlyName": cols[2], "Size": cols[3], "HealthStatus": cols[4], "BusType": "Unavailable", "MediaType": "Unknown", "OperationalStatus": "Unknown"})
        if rows:
            return {"disks": rows, "note": "Some details are unavailable on this Windows version."}
        return {"error": fallback.strip() or "Windows did not return any physical disk information."}

    def redraw(data):
        panel.clear()
        if not isinstance(data, dict) or data.get("error"):
            panel.empty_state((data or {}).get("error", "Disk information is unavailable."))
            return
        disks = data.get("disks", [])
        if not disks:
            panel.empty_state("No physical disks were reported by Windows.")
            return
        panel.stat("Physical drives", len(disks))
        for index, disk in enumerate(disks, 1):
            section = panel.card(f"Drive {disk.get('DeviceId', index)} · {disk.get('FriendlyName') or 'Unknown model'}")
            size = disk.get("Size")
            try:
                size_text = bytes_fmt(float(size)) if size not in (None, "") else "Unavailable"
            except (ValueError, TypeError):
                size_text = str(size)
            health = str(disk.get("HealthStatus") or "Unavailable")
            health_l = health.lower()
            health_status = "good" if health_l in ("healthy", "ok") else ("warn" if health_l in ("warning", "unknown", "unavailable") else "bad")
            # Long model names wrap within the available panel width instead of
            # forcing the tool view to scroll horizontally or clipping columns.
            panel.stat("Model", disk.get("FriendlyName") or "Unavailable", container=section)
            panel.stat("Capacity", size_text, container=section)
            panel.stat("Media", disk.get("MediaType") or "Unavailable", container=section)
            panel.stat("Connection", disk.get("BusType") or "Unavailable", container=section)
            panel.stat("Health", health, status=health_status, container=section)
            op = disk.get("OperationalStatus") or "Unavailable"
            if isinstance(op, list):
                op = ", ".join(map(str, op))
            panel.stat("Operational status", op, container=section)
        if data.get("note"):
            panel.empty_state(data["note"])

    self._run_bg(run, redraw)


def tool_disk_tools_cleanup(self, frame):
    """Cleanup — genuinely deletes real temp files (user + Windows Temp)
    and empties the Recycle Bin, reporting actual bytes freed."""
    panel = CardPanel(frame, self.theme, "Cleanup",
                       "Deletes real leftover files from your Temp folders and empties the "
                       "Recycle Bin, then reports the actual space freed. Files currently in "
                       "use are skipped automatically.")

    def _purge_dir(path):
        freed = 0
        errors = 0
        if not path or not os.path.isdir(path):
            return 0, 0
        for root, dirs, files in os.walk(path, topdown=False):
            for fname in files:
                fp = os.path.join(root, fname)
                try:
                    size = os.path.getsize(fp)
                    os.remove(fp)
                    freed += size
                except OSError:
                    errors += 1
            for dname in dirs:
                try:
                    os.rmdir(os.path.join(root, dname))
                except OSError:
                    pass
        return freed, errors

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        total_freed = 0
        total_errors = 0
        for env_var in ("TEMP", "TMP"):
            p = os.environ.get(env_var)
            f, e = _purge_dir(p)
            total_freed += f
            total_errors += e
        win_temp = r"C:\Windows\Temp"
        f, e = _purge_dir(win_temp)
        total_freed += f
        total_errors += e
        import ctypes
        try:
            ctypes.windll.shell32.SHEmptyRecycleBinW(
                None, None, 0x00000001 | 0x00000002 | 0x00000004)
            bin_msg = "Recycle Bin emptied."
        except Exception as e:
            bin_msg = f"Could not empty Recycle Bin: {e}"
        skip_note = f" ({total_errors} file(s) skipped - in use)" if total_errors else ""
        return {
            "message": f"Freed {bytes_fmt(total_freed)} from temp files{skip_note}.\n{bin_msg}",
            "bytes_freed": total_freed,
        }

    def go():
        self._confirm_then(
            "Delete temp files and empty the Recycle Bin? Files currently open in another "
            "program will be skipped automatically. This cannot be undone.",
            lambda: self._run_bg(run, redraw))

    def redraw(r):
        panel.clear()
        if isinstance(r, dict):
            try:
                achievements.record_cleanup(r.get("bytes_freed", 0), self)
            except Exception:
                pass
            r = r.get("message", "")
        panel.report(r)

    self._button_row(panel.body, [("Run Cleanup", go)])




def tool_disk_tools_volume_capacity(self, frame):
    """Volume Capacity — list mounted volumes and their capacity, not SMART health."""
    panel = CardPanel(frame, self.theme, "Volume Capacity",
                      "Lists mounted volumes, filesystem, total capacity, free space, and health where Windows exposes it.",
                      on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-Volume | Select-Object DriveLetter,FileSystemLabel,FileSystem,"
            "@{N='SizeGB';E={[math]::Round($_.Size/1GB,2)}},"
            "@{N='FreeGB';E={[math]::Round($_.SizeRemaining/1GB,2)}},HealthStatus | "
            "Format-Table -AutoSize | Out-String -Width 180")
        return out.strip() or "No mounted-volume capacity data was returned. Some removable or virtual volumes may not expose all fields."

    def redraw(result):
        panel.clear()
        panel.report(result)

    self._run_bg(run, redraw)


def tool_disk_tools_partition_manager(self, frame):
    """Partition Manager — real, read-only listing of partitions/volumes.
    For editing (resize/create/delete), use the dedicated Partition
    Tools category, which has the full confirmation/safety flow for that."""
    panel = CardPanel(frame, self.theme, "Partition Manager",
                       "Real, read-only list of partitions and volumes on this system. To "
                       "resize, create, or delete partitions, use the dedicated Partition "
                       "Tools category, which has the full safety/confirmation flow for that.",
                       on_refresh=lambda: self._run_bg(run, redraw))

    def run():
        if not IS_WINDOWS:
            return windows_only_notice()
        out = _powershell(
            "Get-Partition | Select-Object DiskNumber,PartitionNumber,DriveLetter,Size,Type | "
            "Format-Table -AutoSize | Out-String -Width 180")
        return out.strip() or "No partition data found."

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(run, redraw)




def tool_disk_tools_clone(self, frame):
    """Clone — real file-level copy of every file/folder from a source
    drive to a destination drive/folder, preserving directory structure."""
    panel = CardPanel(frame, self.theme, "Clone",
                       "Copies every real file and folder from a source drive to a "
                       "destination, preserving structure. For a full raw disk/partition "
                       "image (sector-level clone), use the dedicated Clone Tools category.")
    src_var = self._entry_row(panel.body, "Source drive/folder:", "D:\\")
    dst_var = self._entry_row(panel.body, "Destination folder:", "E:\\Backup")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        src = src_var.get().strip()
        dst = dst_var.get().strip()
        if not os.path.isdir(src):
            return f"Source '{src}' not found."
        if not dst:
            return "Choose a destination folder."
        src_real = os.path.normcase(os.path.realpath(src))
        dst_real = os.path.normcase(os.path.realpath(dst))
        try:
            common = os.path.normcase(os.path.commonpath([src_real, dst_real]))
        except ValueError:
            common = None  # Different Windows drives cannot contain one another.
        if src_real == dst_real or common == src_real or common == dst_real:
            return ("Refusing to copy between identical or nested source/destination paths. "
                    "Choose separate, non-overlapping folders/drives to prevent recursive copies or source damage.")
        os.makedirs(dst, exist_ok=True)
        copied = 0
        skipped = 0
        bytes_copied = 0
        t0 = time.time()
        import shutil as sh
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            target_dir = os.path.join(dst, rel) if rel != "." else dst
            os.makedirs(target_dir, exist_ok=True)
            for fname in files:
                sp = os.path.join(root, fname)
                dp = os.path.join(target_dir, fname)
                try:
                    sh.copy2(sp, dp)
                    bytes_copied += os.path.getsize(dp)
                    copied += 1
                except OSError:
                    skipped += 1
        elapsed = time.time() - t0
        return (f"Cloned {copied} file(s) ({bytes_fmt(bytes_copied)}) from {src} to {dst} "
                f"in {elapsed:.1f}s. {skipped} file(s) skipped (in use/permission denied).")

    def go():
        src = src_var.get().strip() or "D:\\"
        dst = dst_var.get().strip() or "E:\\Backup"
        if not os.path.isdir(src):
            redraw(f"Source '{src}' is not a reachable directory.")
            return
        try:
            sr = os.path.normcase(os.path.realpath(src))
            dr = os.path.normcase(os.path.realpath(dst))
            common = os.path.normcase(os.path.commonpath([sr, dr]))
        except ValueError:
            common = None
        if sr == dr or common in (sr, dr):
            redraw("Source and destination must be separate, non-overlapping paths. Nothing was copied.")
            return
        self._confirm_then(
            f"Copy files from:\n{src}\nto:\n{dst}\nExisting files with the same names will be overwritten. "
            "This is a file-level copy, not a bootable sector-by-sector clone. Verify the destination and keep a separate backup. Continue?",
            lambda: (redraw("Copying files - this can take a while for large drives..."),
                     self._run_bg(run, redraw)))

    self._button_row(panel.body, [("Start Clone", go)])


def tool_disk_tools_free_space_check(self, frame):
    """Free Space Check — quick, read-only capacity check for a selected path."""
    panel = CardPanel(frame, self.theme, "Free Space Check",
                      "Checks free, used, and total bytes on the selected drive/folder. This is a quick preflight before backups or large file operations.")
    path_var = self._entry_row(panel.body, "Drive/folder to check:", "C:\\")

    def run():
        path = path_var.get().strip() or "C:\\"
        if not os.path.isdir(path):
            return f"'{path}' is not a reachable directory or mounted drive."
        try:
            usage = shutil.disk_usage(path)
            used_pct = (usage.used / usage.total * 100) if usage.total else 0
            return (f"Path: {os.path.abspath(path)}\n"
                    f"Total: {bytes_fmt(usage.total)}\n"
                    f"Used: {bytes_fmt(usage.used)} ({used_pct:.1f}%)\n"
                    f"Free: {bytes_fmt(usage.free)}\n\n"
                    "Read-only check; reported free space can change while other apps are running.")
        except OSError as exc:
            return f"Could not read free space for '{path}': {exc}"

    def redraw(result):
        panel.clear()
        panel.report(result)

    self._button_row(panel.body, [("Check Free Space", lambda: self._run_bg(run, redraw))])
    self._run_bg(run, redraw)


def tool_disk_tools_space_analyzer(self, frame):
    """Space Analyzer — real recursive folder-size scan of a chosen
    folder/drive, sorted largest first."""
    panel = CardPanel(
        frame, self.theme, "Space Analyzer",
        "Scans a real folder or drive and reports the largest top-level "
        "subfolders by actual size on disk.",
        on_refresh=lambda: go(),
    )
    path_var = self._entry_row(panel.body, "Folder/drive to scan:", "C:\\Users")
    map_holder = {"widget": None}

    def go():
        block_map = ensure_disk_map(
            panel, self.theme, map_holder, "Space Analyzer scan map",
        )
        progress = DiskScanProgress(self, block_map, "Space analyzer")
        scan_started = threading.Event()

        def run():
            root_path = path_var.get().strip() or "C:\\Users"
            if not os.path.isdir(root_path):
                return f"'{root_path}' not found."
            sizes = {}
            try:
                entries = [
                    e for e in os.scandir(root_path)
                    if e.is_dir(follow_symlinks=False)
                ]
            except OSError as e:
                return f"Could not list {root_path}: {e}"

            files_checked = 0
            bytes_counted = 0
            progress.start()
            scan_started.set()
            try:
                for entry in entries:
                    total = 0
                    try:
                        for dirpath, dirnames, filenames in os.walk(
                            entry.path, onerror=lambda _e: None,
                        ):
                            for fname in filenames:
                                fp = os.path.join(dirpath, fname)
                                file_index = files_checked
                                files_checked += 1
                                progress.update(
                                    file_index, "scanning", files_checked,
                                    bytes_counted, fp,
                                )
                                try:
                                    size = os.path.getsize(fp)
                                    total += size
                                    bytes_counted += size
                                    progress.update(
                                        file_index, "checked", files_checked,
                                        bytes_counted, fp,
                                    )
                                except OSError:
                                    progress.update(
                                        file_index, "issue", files_checked,
                                        bytes_counted, fp,
                                    )
                    except OSError:
                        pass
                    sizes[entry.name] = total
            finally:
                progress.finish()

            ranked = sorted(sizes.items(), key=lambda kv: kv[1], reverse=True)
            lines = [f"Largest subfolders of {root_path}:"]
            for name, size in ranked[:25]:
                lines.append(f"  {bytes_fmt(size):>10}   {name}")
            return "\n".join(lines) if ranked else "No subfolders found (or all inaccessible)."

        def redraw(result):
            if scan_started.is_set() and not hasattr(result, "traceback_text"):
                sounds.play("scan_complete")
            panel.clear()
            panel.report(result)

        self._run_bg(run, redraw)

    self._button_row(panel.body, [("Scan", go)])


def tool_disk_tools_format_tool(self, frame):
    """Format Tool — real diskpart-scripted quick format of a chosen
    volume. Highly destructive; requires typing the drive letter to
    confirm on top of the usual confirm dialog."""
    panel = CardPanel(frame, self.theme, "Format Tool",
                       "Runs a real diskpart-scripted quick format on a chosen volume. This "
                       "permanently erases everything on that volume and cannot be undone.")
    drive_var = self._entry_row(panel.body, "Drive letter to format (e.g. E:):", "E:")
    label_var = self._entry_row(panel.body, "New volume label (optional):", "")
    fs_var = self._entry_row(panel.body, "Filesystem (NTFS/FAT32/exFAT):", "NTFS")
    confirm_var = self._entry_row(panel.body, "Type the drive letter again to confirm:", "")

    def redraw(r):
        panel.clear()
        panel.report(r)

    def run():
        drive = drive_var.get().strip().rstrip(":").upper()
        fs = (fs_var.get().strip() or "NTFS").upper()
        label = label_var.get().strip()
        if not re.fullmatch(r"[A-Z]", drive):
            return "Invalid drive letter. Enter one letter such as E:."
        if fs not in {"NTFS", "FAT32", "EXFAT"}:
            return "Unsupported filesystem. Choose NTFS, FAT32, or exFAT."
        if len(label) > 32 or not re.fullmatch(r"[A-Za-z0-9 _-]*", label):
            return "Volume label must be 32 characters or fewer and use only letters, numbers, spaces, underscores, or hyphens."
        if not _is_elevated():
            return "Formatting requires Administrator privileges. Nothing was changed."
        if drive == os.environ.get("SystemDrive", "C:").rstrip(":\\").upper():
            return "Refusing to format the Windows system drive."
        if not os.path.isdir(f"{drive}:\\"):
            return f"Drive {drive}: is not mounted or does not exist. Nothing was changed."
        if _is_boot_or_system_volume(drive):
            return "Safety stop: the volume is a boot/system volume or Windows could not verify that it is safe to format. Nothing was changed."
        script_lines = [f"select volume {drive}", f"format fs={fs} quick" + (f' label="{label}"' if label else ""), "exit"]
        script = "\r\n".join(script_lines)
        try:
            proc = subprocess.run(["diskpart"], input=script, capture_output=True, text=True,
                                  timeout=300, creationflags=NO_WINDOW)
            output = ((proc.stdout or "") + (proc.stderr or "")).strip()
            if proc.returncode != 0 or re.search(r"(Virtual Disk Service error|DiskPart has encountered an error|Access is denied)", output, re.I):
                return f"Format did not complete successfully (exit {proc.returncode}).\n{output or 'No diagnostic output was returned.'}"
            return output or f"diskpart exited with code {proc.returncode} and no output; verify the volume before assuming it was formatted."
        except FileNotFoundError:
            return "diskpart not found on this system."
        except subprocess.TimeoutExpired:
            return "Format timed out."
        except Exception as e:
            return f"Error: {e}"

    def go():
        if not IS_WINDOWS:
            redraw(windows_only_notice())
            return
        drive = drive_var.get().strip().rstrip(":").upper()
        confirm = confirm_var.get().strip().rstrip(":").upper()
        if not drive:
            redraw("Enter a drive letter first.")
            return
        if not re.fullmatch(r"[A-Z]", drive):
            redraw("Invalid drive letter. Enter a single letter such as E:. Nothing was done.")
            return
        if drive != confirm:
            redraw(f"Confirmation drive letter doesn't match '{drive}'. Nothing was done.")
            return
        fs = (fs_var.get().strip() or "NTFS").upper()
        label = label_var.get().strip()
        if fs not in {"NTFS", "FAT32", "EXFAT"}:
            redraw("Choose NTFS, FAT32, or exFAT. Nothing was done.")
            return
        if len(label) > 32 or not re.fullmatch(r"[A-Za-z0-9 _-]*", label):
            redraw("Volume label must be 32 characters or fewer and use only letters, numbers, spaces, underscores, or hyphens.")
            return
        if drive == os.environ.get("SystemDrive", "C:").rstrip(":\\").upper():
            redraw("Refusing to format the Windows system drive. Nothing was done.")
            return
        if not os.path.isdir(f"{drive}:\\"):
            redraw(f"Drive {drive}: is not mounted or does not exist. Nothing was done.")
            return
        if not _is_elevated():
            redraw("Formatting requires Administrator privileges. Nothing was done.")
            return
        if _is_boot_or_system_volume(drive):
            redraw("Safety stop: the volume is a boot/system volume or Windows could not verify that it is safe to format. Nothing was done.")
            return
        self._confirm_then(
            f"PERMANENTLY ERASE everything on drive {drive}: and quick-format it? This cannot "
            "be undone.",
            lambda: self._run_bg(run, redraw))

    self._button_row(panel.body, [("Format Drive", go)])
