#!/usr/bin/env python3
"""
Module: data_recovery
Category: Data Recovery

Real recovery tools: the actual Recycle Bin / freedesktop Trash, real
SMART health data, real per-disk/partition enumeration, and genuine
signature-based file carving (reading raw bytes off a chosen source and
matching real file magic numbers) for the categories where a full
filesystem-level undelete isn't realistic from a Python GUI without a
kernel-level driver. Nothing here prints a fabricated result - every
branch either does the real operation or says plainly what's missing
(smartctl, admin rights, etc).
"""

import os
import re
import time
import json
import platform
from datetime import datetime
from gui.tk_dialogs import filedialog

try:
    import psutil
except ImportError:
    psutil = None

from techdrive_modules import hw_sensors as hw
from gui.tool_view import CardPanel

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"
IS_MAC = platform.system() == "Darwin"


def bytes_fmt(n):
    n = float(n or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}PB"


CATALOGUE = []

_SIGNATURES = {
    "Photos": [("jpg", b"\xff\xd8\xff", 12 * 1024 * 1024), ("png", b"\x89PNG\r\n\x1a\n", 12 * 1024 * 1024),
               ("gif", b"GIF8", 8 * 1024 * 1024), ("bmp", b"BM", 4 * 1024 * 1024)],
    "Documents": [("pdf", b"%PDF-", 30 * 1024 * 1024), ("docx/zip", b"PK\x03\x04", 30 * 1024 * 1024)],
}


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _linux_trash_dirs():
    home_trash = os.path.join(os.path.expanduser("~"), ".local", "share", "Trash")
    return [home_trash] if os.path.isdir(home_trash) else []


def _linux_trash_items(trash_dir):
    files_dir = os.path.join(trash_dir, "files")
    info_dir = os.path.join(trash_dir, "info")
    items = []
    if not os.path.isdir(files_dir):
        return items
    for name in os.listdir(files_dir):
        fp = os.path.join(files_dir, name)
        info = {}
        info_path = os.path.join(info_dir, name + ".trashinfo")
        if os.path.exists(info_path):
            try:
                for line in open(info_path, encoding="utf-8", errors="ignore"):
                    if "=" in line:
                        k, v = line.strip().split("=", 1)
                        info[k] = v
            except OSError:
                pass
        try:
            size = os.path.getsize(fp) if os.path.isfile(fp) else \
                sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(fp) for f in fs)
        except OSError:
            size = 0
        items.append({"name": name, "path": fp, "size": size,
                      "original": info.get("Path", "?"), "deleted": info.get("DeletionDate", "?")})
    return items


def _windows_recycle_bin():
    ok, out = hw.powershell(
        "$sh = New-Object -ComObject Shell.Application; "
        "$rb = $sh.Namespace(10); "
        "$rb.Items() | ForEach-Object { "
        "[PSCustomObject]@{Name=$_.Name; OriginalLocation=$rb.GetDetailsOf($_,1); "
        "Size=$rb.GetDetailsOf($_,2); DateDeleted=$rb.GetDetailsOf($_,3)} } | ConvertTo-Json -Compress")
    if ok and out.strip().startswith(("[", "{")):
        try:
            data = json.loads(out)
            return data if isinstance(data, list) else [data]
        except Exception:
            return []
    return []


def _removable_partitions():
    """Real removable-media partitions - Windows via WMI DriveType, else psutil opts."""
    out = []
    if IS_WINDOWS:
        ok, res = hw.powershell(
            "Get-CimInstance Win32_LogicalDisk | Where-Object {$_.DriveType -eq 2} | "
            "Select-Object DeviceID,VolumeName,Size,FreeSpace,FileSystem | ConvertTo-Json -Compress")
        if ok and res.strip().startswith(("[", "{")):
            try:
                data = json.loads(res)
                for d in (data if isinstance(data, list) else [data]):
                    out.append({"device": d.get("DeviceID"), "label": d.get("VolumeName") or "(no label)",
                               "fs": d.get("FileSystem"), "total": float(d.get("Size") or 0),
                               "free": float(d.get("FreeSpace") or 0)})
            except Exception:
                pass
        return out
    if psutil:
        for p in psutil.disk_partitions(all=True):
            opts = p.opts or ""
            if "removable" in opts.lower() or "/media/" in p.mountpoint or "/run/media/" in p.mountpoint:
                try:
                    u = psutil.disk_usage(p.mountpoint)
                except Exception:
                    continue
                out.append({"device": p.device, "label": p.mountpoint, "fs": p.fstype,
                           "total": u.total, "free": u.free})
    return out


def _carve(source_path, out_dir, category, limit, on_progress=None):
    """Real byte-level signature scan of source_path. Returns (found, log_lines)."""
    sigs = _SIGNATURES[category]
    os.makedirs(out_dir, exist_ok=True)
    CHUNK = 8 * 1024 * 1024
    found = 0
    log = []
    total = os.path.getsize(source_path) if os.path.isfile(source_path) else None
    if total is None:
        try:
            total = os.path.getsize(source_path)
        except OSError:
            total = 0
    with open(source_path, "rb", buffering=0) as f:
        offset = 0
        tail = b""
        while found < limit:
            block = f.read(CHUNK)
            if not block:
                break
            buf = tail + block
            for ext, sig, carve_len in sigs:
                idx = buf.find(sig)
                while idx != -1 and found < limit:
                    abs_off = offset - len(tail) + idx
                    try:
                        with open(source_path, "rb", buffering=0) as f2:
                            f2.seek(abs_off)
                            remaining = (total - abs_off) if total else carve_len
                            payload = f2.read(min(carve_len, max(1, remaining)))
                        out_path = os.path.join(out_dir, f"recovered_{found:04d}.{ext.split('/')[0]}")
                        with open(out_path, "wb") as outf:
                            outf.write(payload)
                        found += 1
                        log.append(f"Carved {out_path} @ offset {abs_off}")
                    except Exception as e:
                        log.append(f"Skip @ {abs_off}: {e}")
                    idx = buf.find(sig, idx + 1)
            tail = buf[-16:]
            offset += len(block)
            if on_progress:
                on_progress(offset, total)
    return found, log


# ---------------------------------------------------------------------------
# 1. Recover Deleted - real Recycle Bin / Trash listing + restore
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 2. Recover Formatted
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 3. Recover Partitions
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 4. Recover Photos - real signature carving
# ---------------------------------------------------------------------------

def _carve_tool(self, frame, title, category, help_text):
    panel = CardPanel(frame, self.theme, title, help_text)
    source = self._entry_row(panel.body, "Source (drive path or disk image)", "")
    out_dir = self._entry_row(panel.body, "Output folder", os.path.join(os.path.expanduser("~"), "TechDrive_Recovered"))
    limit = self._entry_row(panel.body, "Max files to carve", "200")

    def redraw(r):
        panel.clear()
        panel.report(str(r))

    def pick_source():
        p = filedialog.askopenfilename(title="Select a disk image (or Cancel to type a raw device path)")
        if p:
            source.set(p)

    def pick_out():
        p = filedialog.askdirectory(title="Select output folder")
        if p:
            out_dir.set(p)

    def run():
        src = source.get().strip()
        if not src:
            return "Enter a source path first (a raw device like \\\\.\\PhysicalDrive1 or /dev/sdb1, or a disk-image file)."
        if not os.path.exists(src) and not (IS_WINDOWS and src.startswith("\\\\")):
            return f"Source not found: {src}"
        try:
            lim = int(limit.get().strip())
        except ValueError:
            lim = 200
        try:
            found, log = _carve(src, out_dir.get(), category, lim)
        except PermissionError:
            return "Permission denied reading that source. Raw-device access needs administrator/root."
        except Exception as e:
            return f"Scan failed: {type(e).__name__}: {e}"
        tail = "\n".join(log[-40:])
        return f"Carved {found} file(s) into {out_dir.get()}.\n\n{tail}"

    self._button_row(panel.body, [("□ Browse source", pick_source), ("□ Browse output", pick_out),
                              ("▶ Start scan", lambda: self._run_bg(run, redraw))])




# ---------------------------------------------------------------------------
# 5. Recover Documents - real signature carving + Trash filter
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 6. Recover Emails - real filesystem search for local mail stores
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 7. Recover Crashed Drive - real SMART health + read test
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 8. Recover USB
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 9. Recover SD
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 10. Deep Scan - orphaned/leftover recovery artifacts across a folder
# ---------------------------------------------------------------------------

