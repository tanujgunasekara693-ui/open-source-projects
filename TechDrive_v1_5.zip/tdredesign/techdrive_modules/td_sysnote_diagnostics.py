#!/usr/bin/env python3
"""
Module: td_sysnote_diagnostics
Ported from: SysNote Corner (sysnote.py), Author: You (per its own About
dialog — no third-party licensing question here, unlike the earlier
IDE port).

Only sysnote.py's plain data-gathering functions were ported (~35 of
them, listed in _sysnote_diag.py). The rest of that file — the always-on
desktop corner overlay, system tray icon, notes app, alert loop, snapshot
diff, benchmark, live/history graphs, process manager — is all built
around a single persistent root window and global mutable state, which
doesn't fit TechDrive's "one panel per click" plugin model. None of that
was ported. See SYSNOTE_PORT_README.md for the full breakdown.

GUI note: every panel below uses the CardPanel framework (gui/tool_view.py)
instead of the old plain _panel_header()/_text_output() text dump, so each
reading gets its own labeled stat row (with ✅/⚠/✕ status coloring where a
reading has a clear good/bad meaning) or a progress bar, plus the standard
Refresh/Close header for free.

Category: SysNote: Extended Diagnostics
"""
import tkinter as tk
import os
import platform
import shutil
import subprocess
import importlib.util
from gui.tk_dialogs import messagebox

from gui.tool_view import CardPanel
from . import _sysnote_diag as diag

CATALOGUE = [('SysNote: Extended Diagnostics',
  '✚',
  ['Full System Report',
   'CPU Name & Temp',
   'Sensor Availability',
   'Motherboard Info',
   'BIOS Version & Mode',
   'Secure Boot Status',
   'TPM Version',
   'RAM Details',
   'Drive Health',
   'System Uptime'])]


# ---------------------------------------------------------------------------
# Full System Report — inherently a multi-section dump; CardPanel.report()
# is the right fit here (auto-parses the "=== Section ===" / "Key: value"
# text build_report() already returns into cards + stat rows).
# ---------------------------------------------------------------------------

def tool_sysnote_full_system_report(self, frame):
    panel = CardPanel(frame, self.theme, "Full System Report",
                       "CPU / RAM / disk / GPU / network / OS in one snapshot",
                       icon="✚", on_refresh=lambda: self._run_bg(diag.build_report, redraw))

    def redraw(r):
        panel.clear()
        panel.report(r)

    self._run_bg(diag.build_report, redraw)


def tool_sysnote_cpu_name_temp(self, frame):
    panel = CardPanel(frame, self.theme, "CPU Name & Temp", icon="▣",
                       on_refresh=lambda: self._run_bg(gather, redraw))

    def gather():
        return diag.get_cpu_name(), diag.get_cpu_temp()

    def redraw(data):
        name, temp = data
        panel.clear()
        panel.stat("Name", name or "Unknown")
        if temp is None:
            panel.stat("Temperature", "N/A")
        else:
            status = "good" if temp < 70 else "warn" if temp < 85 else "bad"
            panel.stat("Temperature", f"{temp}°C", status=status)

    self._run_bg(gather, redraw)




def tool_sysnote_sensor_availability(self, frame):
    """Sensor Availability — reports actual sensor backends/dependencies."""
    panel = CardPanel(frame, self.theme, "Sensor Availability",
                      "Checks which optional sensor providers are available. Missing readings are reported as unavailable, never fabricated.",
                      icon="◉", on_refresh=lambda: self._run_bg(gather, redraw))

    def gather():
        rows = []
        for package in ("psutil", "wmi", "pynvml", "win32com"):
            try:
                available = importlib.util.find_spec(package) is not None
            except (ImportError, ValueError):
                available = False
            rows.append(f"Python package {package}: {'available' if available else 'not installed'}")
        for command in ("powershell", "nvidia-smi", "smartctl", "wmic"):
            rows.append(f"Command {command}: {'available' if shutil.which(command) else 'not found on PATH'}")
        rows.append(f"Platform: {platform.platform()}")
        rows.append("Note: a provider being present does not guarantee that every sensor is exposed by the hardware/driver.")
        return "\n".join(rows)

    def redraw(result):
        panel.clear()
        panel.report(result)

    self._run_bg(gather, redraw)






def tool_sysnote_motherboard_info(self, frame):
    panel = CardPanel(frame, self.theme, "Motherboard Info", icon="⚒",
                       on_refresh=lambda: self._run_bg(diag.get_motherboard_info, redraw))

    def redraw(data):
        mfr, product = data
        panel.clear()
        panel.stat("Manufacturer", mfr)
        panel.stat("Product", product)

    self._run_bg(diag.get_motherboard_info, redraw)


def tool_sysnote_bios_version_mode(self, frame):
    panel = CardPanel(frame, self.theme, "BIOS Version & Mode", icon="⚒",
                       on_refresh=lambda: self._run_bg(gather, redraw))

    def gather():
        return diag.get_bios_version(), diag.get_bios_mode()

    def redraw(data):
        version, mode = data
        panel.clear()
        panel.stat("Version", version)
        panel.stat("Mode", mode)

    self._run_bg(gather, redraw)


def tool_sysnote_secure_boot_status(self, frame):
    panel = CardPanel(frame, self.theme, "Secure Boot Status", icon="◆",
                       on_refresh=lambda: self._run_bg(diag.get_secure_boot_status, redraw))

    def redraw(r):
        panel.clear()
        rl = str(r).lower()
        status = "good" if "on" in rl or "enabled" in rl else "warn" if "off" in rl or "disabled" in rl else None
        panel.stat("Secure Boot", r, status=status)

    self._run_bg(diag.get_secure_boot_status, redraw)


def tool_sysnote_tpm_version(self, frame):
    panel = CardPanel(frame, self.theme, "TPM Version", icon="◆",
                       on_refresh=lambda: self._run_bg(diag.get_tpm_version, redraw))

    def redraw(r):
        panel.clear()
        rl = str(r).lower()
        status = "good" if "2.0" in rl else "warn" if "not" in rl or "n/a" in rl else None
        panel.stat("TPM spec version", r, status=status)

    self._run_bg(diag.get_tpm_version, redraw)




def tool_sysnote_ram_details(self, frame):
    panel = CardPanel(frame, self.theme, "RAM Details", icon="◉",
                       on_refresh=lambda: self._run_bg(diag.get_ram_details, redraw))

    def redraw(data):
        total, sticks, speed, mem_type = data
        panel.clear()
        panel.stat("Slots populated", sticks if sticks is not None else "N/A")
        panel.stat("Total slots", total if total is not None else "N/A")
        panel.stat("Speed", f"{speed} MHz" if speed is not None else "N/A")
        panel.stat("Type", mem_type or "N/A")

    self._run_bg(diag.get_ram_details, redraw)


def tool_sysnote_drive_health(self, frame):
    panel = CardPanel(frame, self.theme, "Drive Health", f"System drive: {diag.SYSTEM_DRIVE}",
                       icon="▣", on_refresh=lambda: self._run_bg(diag.get_drive_health, redraw))

    def redraw(r):
        panel.clear()
        status = "good" if r == "Pass" else "bad" if r == "Fail" else None
        panel.stat("SMART status", r, status=status)

    self._run_bg(diag.get_drive_health, redraw)


























def tool_sysnote_system_uptime(self, frame):
    """System Uptime — read-only Windows last-boot time and uptime."""
    panel = CardPanel(frame, self.theme, "System Uptime",
                      "Shows the last Windows boot time and elapsed uptime, useful when troubleshooting restarts or long-running sessions.",
                      icon="◷", on_refresh=lambda: self._run_bg(gather, redraw))

    def gather():
        if platform.system() != "Windows":
            return "Windows-only reading."
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "$os = Get-CimInstance Win32_OperatingSystem; "
                 "$boot = $os.LastBootUpTime; "
                 "$up = (Get-Date) - $boot; "
                 "'Last boot: ' + $boot.ToString('yyyy-MM-dd HH:mm:ss') + "
                 "'`nUptime: ' + [int]$up.TotalDays + ' days, ' + $up.Hours + ' hours, ' + $up.Minutes + ' minutes'"],
                capture_output=True, text=True, timeout=15,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            output = (result.stdout or result.stderr or "").strip()
            return output if result.returncode == 0 and output else f"Could not read uptime (exit {result.returncode}): {output or 'no output'}"
        except Exception as exc:
            return f"Could not read uptime: {exc}"

    def redraw(result):
        panel.clear()
        panel.report(result)

    self._run_bg(gather, redraw)






