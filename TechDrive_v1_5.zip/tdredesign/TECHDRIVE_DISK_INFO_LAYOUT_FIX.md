# TechDrive v1.1 — Disk Info Layout Fix

## Changes
- Disk Info now requests structured JSON from PowerShell instead of rendering a wide `Format-Table` dump.
- Each physical disk is shown as a readable card with model, capacity, media type, bus, health, and operational status.
- Unknown sensor/provider values are displayed as unavailable rather than fabricated.
- Added a WMIC fallback for older Windows installations where the Storage cmdlet is unavailable.
- Removed the repeated BETA badge from every tool panel to free horizontal space and reduce visual noise.
- Shared CardPanel stat values and legacy report text now adapt wrapping to the available width, reducing clipping in narrow tool views.

## Validation
- Python syntax compilation passed for the modified modules.
- This is a source-level fix. A real Windows GUI run is still required to verify appearance across display scaling, window sizes, and different disk-provider output.
