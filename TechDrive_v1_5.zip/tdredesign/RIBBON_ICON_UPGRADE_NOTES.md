# TechDrive Ribbon + Tool Icon Upgrade

This revision makes the Ribbon resolve its visible diagnostic commands from the live `CATALOGUE` at runtime.

- Ribbon diagnostic buttons use `app.open_tool(category, tool)` with exact catalogue pairs.
- No diagnostic tool implementations were rewritten.
- Each Ribbon category exposes a small, useful set of real tools plus **More tools** to the existing group gallery.
- Shell commands (Quick Scan, Fix My PC, themes, Ribbon modes, Settings, etc.) use code-generated TechDrive icon assets instead of emoji.
- Tool buttons use the existing per-tool 24x24 PNG icon assets generated from the SVG masters.
- The Ribbon remains native Tkinter/ttk and contains no web UI.
- Full / Compact / Collapsed modes remain available.
