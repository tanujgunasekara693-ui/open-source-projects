"""Static regression checks for the curated 100-tool catalogue and safety guards."""
import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_NAMES = [
    "backup_tools", "batch_rename", "cpu_monitor", "disk_test", "disk_tools",
    "file_search", "gpu_monitor", "network_tools", "ram_monitor", "restore_tools",
    "security_tools", "storage_health", "system_repair", "td_sysnote_diagnostics",
    "wifi_tools",
]


def module_catalogue(name):
    tree = ast.parse((ROOT / "techdrive_modules" / f"{name}.py").read_text(encoding="utf-8"))
    catalogue = []
    functions = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name.startswith("tool_"):
            functions.append(node.name)
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "CATALOGUE" for target in node.targets
        ):
            catalogue = ast.literal_eval(node.value)
    return catalogue, functions


class CuratedCatalogueTests(unittest.TestCase):
    def test_exactly_100_tools_and_catalogue_function_pairing(self):
        total = 0
        for module in MODULE_NAMES:
            catalogue, functions = module_catalogue(module)
            count = sum(len(tools) for _category, _icon, tools in catalogue)
            self.assertEqual(count, len(functions), module)
            total += count
        self.assertEqual(total, 100)

    def test_named_overlaps_are_removed(self):
        names = []
        for module in MODULE_NAMES:
            catalogue, _functions = module_catalogue(module)
            names.extend(name for _category, _icon, tools in catalogue for name in tools)
        self.assertEqual(names.count("GPU Info"), 1)
        self.assertEqual(names.count("SMART Status"), 1)
        self.assertNotIn("SMART Health", names)
        self.assertEqual(names.count("Benchmark"), 1)
        self.assertEqual(names.count("Windows Update"), 1)
        self.assertNotIn("Windows Update Status", names)
        for replacement in ("Sensor Availability", "Volume Capacity", "Free Space Check", "System Uptime"):
            self.assertEqual(names.count(replacement), 1)

    def test_destructive_operations_have_safety_guards(self):
        disk = (ROOT / "techdrive_modules" / "disk_tools.py").read_text(encoding="utf-8")
        disk_test = (ROOT / "techdrive_modules" / "disk_test.py").read_text(encoding="utf-8")
        restore = (ROOT / "techdrive_modules" / "restore_tools.py").read_text(encoding="utf-8")
        repair = (ROOT / "techdrive_modules" / "system_repair.py").read_text(encoding="utf-8")
        self.assertIn("non-overlapping paths", disk)
        self.assertIn("_is_boot_or_system_volume", disk)
        self.assertIn("FILE_EXISTS", disk_test)
        self.assertIn("different drive from Windows", restore)
        self.assertIn("valid_ids", restore)
        self.assertIn("is_elevated()", repair)
        self.assertIn("self._confirm_then", repair)


if __name__ == "__main__":
    unittest.main()
