"""Interactive regression tests; run with xvfb-run on headless Linux."""
import tkinter as tk
import unittest

from gui.closable_notebook import ClosableNotebook


class ClosableNotebookGuiTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.geometry("700x300")
        self.notebook = ClosableNotebook(
            self.root, protected_titles={"Dashboard", "Settings"}
        )
        self.notebook.pack(fill="both", expand=True)
        for title in ("Dashboard", "Ping", "Advanced Search", "Settings"):
            frame = tk.Frame(self.notebook)
            self.notebook.add_closable(frame, text=title)
        self.root.update()

    def tearDown(self):
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def titles(self):
        return [
            self.notebook._display_title(self.notebook.tab(tab, "text"))
            for tab in self.notebook.tabs()
        ]

    def test_close_glyph_works_when_tk_bbox_is_zero(self):
        # Some Tk/ttk builds report (0, 0, 0, 0) for every tab. Exercise
        # that fallback when present, and use the native bbox otherwise.
        bbox = self.notebook.bbox(1)
        if bbox and bbox[2] > 0 and bbox[3] > 0:
            x = bbox[0] + bbox[2] - 4
            y = bbox[1] + min(10, bbox[3] // 2)
        else:
            y = 10
            tab_pixels = []
            for px in range(self.notebook.winfo_width()):
                try:
                    if self.notebook.index(f"@{px},{y}") == 1:
                        tab_pixels.append(px)
                except tk.TclError:
                    continue
            x = max(tab_pixels) - 4
        self.notebook.event_generate("<ButtonPress-1>", x=x, y=y)
        self.notebook.event_generate("<ButtonRelease-1>", x=x, y=y)
        self.root.update()
        self.assertNotIn("Ping", self.titles())
        self.assertIn("Dashboard", self.titles())

    def test_middle_click_closes_unprotected_tab(self):
        self.notebook.event_generate("<Button-2>", x=110, y=10)
        self.root.update()
        self.assertNotIn("Ping", self.titles())

    def test_protected_tab_cannot_be_closed(self):
        dashboard = next(
            tab for tab in self.notebook.tabs()
            if self.notebook._display_title(self.notebook.tab(tab, "text")) == "Dashboard"
        )
        self.assertFalse(self.notebook.close_tab(dashboard))
        self.assertIn("Dashboard", self.titles())

    def test_callback_error_does_not_block_closing(self):
        self.notebook.on_close = lambda _title: (_ for _ in ()).throw(RuntimeError("test"))
        ping = next(
            tab for tab in self.notebook.tabs()
            if self.notebook._display_title(self.notebook.tab(tab, "text")) == "Ping"
        )
        self.assertTrue(self.notebook.close_tab(ping))
        self.assertNotIn("Ping", self.titles())


if __name__ == "__main__":
    unittest.main()
