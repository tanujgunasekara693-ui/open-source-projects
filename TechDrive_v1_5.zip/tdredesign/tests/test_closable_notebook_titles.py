import unittest
from gui.closable_notebook import ClosableNotebook


class DisplayTitleTests(unittest.TestCase):
    def test_removes_close_glyph(self):
        self.assertEqual(ClosableNotebook._display_title("Ping  ×"), "Ping")

    def test_removes_leading_icon_token(self):
        self.assertEqual(ClosableNotebook._display_title("◈ Core Module Manager  ×"), "Core Module Manager")

    def test_preserves_regular_multiword_title(self):
        self.assertEqual(ClosableNotebook._display_title("Health Center  ×"), "Health Center")

    def test_plain_title_matches_closable_title(self):
        self.assertEqual(
            ClosableNotebook._display_title("Advanced Search"),
            ClosableNotebook._display_title("Advanced Search  ×"),
        )


if __name__ == "__main__":
    unittest.main()
