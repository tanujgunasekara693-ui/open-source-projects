import techdrive
root=techdrive.TechDriveApp()
# Prevent beta nag from interrupting automated smoke.
try:
    if root._trial_job: root.after_cancel(root._trial_job)
except Exception: pass
samples=[]
for cat, icon, tools in techdrive.CATALOGUE:
    if tools:
        samples.append((cat, tools[0]))
    if len(samples)>=5: break
for i,(cat,tool) in enumerate(samples):
    root.open_tool(cat,tool)
    root.update_idletasks(); root.update()
root.after(300, root.destroy)
root.mainloop()
print('GUI navigation smoke PASS:', len(samples), 'tool tabs')
