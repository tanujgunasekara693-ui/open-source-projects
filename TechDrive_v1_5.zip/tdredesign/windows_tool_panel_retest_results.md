# TechDrive Windows Tool Panel Smoke Test

**Host:** Windows-10-10.0.19045-SP0 / Python 3.14.5 / Tk 8.6.15
**Started:** 2026-09-29T18:02:55+05:30
**Finished:** 2026-09-29T18:02:57+05:30

Retest of 70 tools previously marked FAIL or GUARDED in windows_tool_panel_smoke_results.json.
Each panel constructor and Tk idle layout were exercised without clicking tool controls. Automatic `_run_bg` refreshes were deferred. Direct processes, threads, browsers, and modal/file dialogs were blocked before execution.

- Total panels: **70**
- Built without exception: **0**
- Layout/constructor exceptions: **15**
- Guarded before completion: **55**
- Initial refresh workers deferred: **3**

## Hardware Testing: 0/2 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Display Tools | Multi-Monitor | GUARDED | Blocked before execution: subprocess.run |
| System Summary | System Overview | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |

## OS and Utilities: 0/1 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Terminal Tools | Multiplexer | FAIL | TclError: cannot use geometry manager pack inside .!frame5 which already has slaves managed by grid |

## Network and Cloud: 0/1 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Network Monitor | Usage Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |

## Security and Privacy: 0/1 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Password Tools | Strength Checker | FAIL | TclError: cannot use geometry manager pack inside .!frame7 which already has slaves managed by grid |

## Disk and Storage Management: 0/49 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Cloning & Imaging | Drive to Drive Clone | GUARDED | Blocked before execution: subprocess.run |
| Cloning & Imaging | Create Disk Image | GUARDED | Blocked before execution: subprocess.run |
| Cloning & Imaging | Restore Disk Image | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Resize | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Create | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Delete | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Format | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Merge | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Split | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Move | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Recovery | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Table Backup | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Table Restore | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Convert to MBR | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Geometry | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Modify MBR/GUID | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | SMART Info | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Speed Test | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Bad Sector Scan | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Delete All Partitions | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Image Backup | GUARDED | Blocked before execution: subprocess.run |
| Partition Tools | Disk Image Restore | GUARDED | Blocked before execution: subprocess.run |
| Data Recovery | Recover Photos | FAIL | TclError: cannot use geometry manager pack inside .!frame30 which already has slaves managed by grid |
| Data Recovery | Recover Documents | FAIL | TclError: cannot use geometry manager pack inside .!frame31 which already has slaves managed by grid |
| Shredder Tools | Disk Wipe 1-Pass | FAIL | TclError: cannot use geometry manager pack inside .!frame32 which already has slaves managed by grid |
| Shredder Tools | Disk Wipe 3-Pass | FAIL | TclError: cannot use geometry manager pack inside .!frame33 which already has slaves managed by grid |
| Shredder Tools | Disk Wipe 7-Pass | FAIL | TclError: cannot use geometry manager pack inside .!frame34 which already has slaves managed by grid |
| Shredder Tools | Disk Wipe DoD | FAIL | TclError: cannot use geometry manager pack inside .!frame35 which already has slaves managed by grid |
| Wipe Tools | Secure Wipe Drive | FAIL | TclError: cannot use geometry manager pack inside .!frame36 which already has slaves managed by grid |
| Wipe Tools | Wipe Partition | FAIL | TclError: cannot use geometry manager pack inside .!frame37 which already has slaves managed by grid |
| Wipe Tools | Wipe File | FAIL | TclError: cannot use geometry manager pack inside .!frame38 which already has slaves managed by grid |
| Wipe Tools | Wipe Folder | FAIL | TclError: cannot use geometry manager pack inside .!frame39 which already has slaves managed by grid |
| Wipe Tools | Wipe USB | FAIL | TclError: cannot use geometry manager pack inside .!frame40 which already has slaves managed by grid |
| Wipe Tools | Wipe SD | FAIL | TclError: cannot use geometry manager pack inside .!frame41 which already has slaves managed by grid |
| Archive Tools | Zip | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.messagebox.askyesno |
| Archive Tools | Unzip | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| Archive Tools | RAR | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askdirectory |
| Archive Tools | UnRAR | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| Archive Tools | 7z | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askdirectory |
| Archive Tools | Un7z | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| Archive Tools | Tar | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askdirectory |
| Archive Tools | Untar | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| Archive Tools | Gzip | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| Archive Tools | Gunzip | GUARDED | RuntimeError: Blocked during panel-only test: tkinter.filedialog.askopenfilename |
| OS Migration & Recovery | OS Migration Wizard | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Backup Partition | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Restore Partition | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | Partition Recovery Scanner | GUARDED | Blocked before execution: subprocess.run |
| OS Migration & Recovery | File Recovery Scanner | GUARDED | Blocked before execution: subprocess.run |

## System and Diagnostics: 0/16 built

| Category | Tool | Result | Details |
|---|---|---|---|
| Live Monitor | CPU Live Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | RAM Live Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | GPU Live Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | Disk Activity Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | Network Live Graph | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | Drive Temperatures | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | Drive Space Map | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | All Sensors Dashboard | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| Live Monitor | Sensor Log Export | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| RAM Monitor | Usage Graph | FAIL | TclError: cannot use geometry manager pack inside .!frame66 which already has slaves managed by grid |
| NVIDIA GPU | Hotspot Temperature | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| NVIDIA GPU | GPU Power & Clocks | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| NVIDIA GPU | VRAM Monitor | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| NVIDIA GPU | Fan & Cooling | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| NVIDIA GPU | Throttle Reasons | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |
| NVIDIA GPU | GPU Process List | GUARDED | RuntimeError: Blocked during panel-only test: Thread.start |

## Blocked Operations

These APIs were intercepted before execution. Some panels intentionally start with a chooser or confirmation; others attempt direct background work. A guarded result is unverified, not necessarily a product defect.

- Hardware Testing / Display Tools / Multi-Monitor: `subprocess.run`
- Hardware Testing / System Summary / System Overview: `Thread.start`
- Network and Cloud / Network Monitor / Usage Graph: `Thread.start`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Drive to Drive Clone: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Create Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Create Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Restore Disk Image: `subprocess.run`
- Disk and Storage Management / Cloning & Imaging / Restore Disk Image: `subprocess.run`
- Disk and Storage Management / Partition Tools / Resize: `subprocess.run`
- Disk and Storage Management / Partition Tools / Create: `subprocess.run`
- Disk and Storage Management / Partition Tools / Create: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete: `subprocess.run`
- Disk and Storage Management / Partition Tools / Format: `subprocess.run`
- Disk and Storage Management / Partition Tools / Merge: `subprocess.run`
- Disk and Storage Management / Partition Tools / Merge: `subprocess.run`
- Disk and Storage Management / Partition Tools / Split: `subprocess.run`
- Disk and Storage Management / Partition Tools / Move: `subprocess.run`
- Disk and Storage Management / Partition Tools / Move: `subprocess.run`
- Disk and Storage Management / Partition Tools / Recovery: `subprocess.run`
- Disk and Storage Management / Partition Tools / Recovery: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Table Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Convert to MBR: `subprocess.run`
- Disk and Storage Management / Partition Tools / Convert to MBR: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Geometry: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Geometry: `subprocess.run`
- Disk and Storage Management / Partition Tools / Modify MBR/GUID: `subprocess.run`
- Disk and Storage Management / Partition Tools / Modify MBR/GUID: `subprocess.run`
- Disk and Storage Management / Partition Tools / SMART Info: `subprocess.run`
- Disk and Storage Management / Partition Tools / SMART Info: `subprocess.run`
- Disk and Storage Management / Partition Tools / Speed Test: `subprocess.run`
- Disk and Storage Management / Partition Tools / Bad Sector Scan: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete All Partitions: `subprocess.run`
- Disk and Storage Management / Partition Tools / Delete All Partitions: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Backup: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Restore: `subprocess.run`
- Disk and Storage Management / Partition Tools / Disk Image Restore: `subprocess.run`
- Disk and Storage Management / Archive Tools / Zip: `tkinter.messagebox.askyesno`
- Disk and Storage Management / Archive Tools / Unzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / RAR: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / UnRAR: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / 7z: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / Un7z: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Tar: `tkinter.filedialog.askdirectory`
- Disk and Storage Management / Archive Tools / Untar: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Gzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / Archive Tools / Gunzip: `tkinter.filedialog.askopenfilename`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / OS Migration Wizard: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Backup Partition: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Restore Partition: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Partition Recovery Scanner: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / Partition Recovery Scanner: `subprocess.run`
- Disk and Storage Management / OS Migration & Recovery / File Recovery Scanner: `subprocess.run`
- System and Diagnostics / Live Monitor / CPU Live Graph: `subprocess.run`
- System and Diagnostics / Live Monitor / CPU Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / RAM Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / GPU Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Disk Activity Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Network Live Graph: `Thread.start`
- System and Diagnostics / Live Monitor / Drive Temperatures: `Thread.start`
- System and Diagnostics / Live Monitor / Drive Space Map: `Thread.start`
- System and Diagnostics / Live Monitor / All Sensors Dashboard: `Thread.start`
- System and Diagnostics / Live Monitor / Sensor Log Export: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Hotspot Temperature: `Thread.start`
- System and Diagnostics / NVIDIA GPU / GPU Power & Clocks: `Thread.start`
- System and Diagnostics / NVIDIA GPU / VRAM Monitor: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Fan & Cooling: `Thread.start`
- System and Diagnostics / NVIDIA GPU / Throttle Reasons: `Thread.start`
- System and Diagnostics / NVIDIA GPU / GPU Process List: `Thread.start`
