"""Generate TechDrive's original, built-in XP and Vista/7 sound cues.

Run from the TechDrive directory with the standard-library Python runtime:
    python scripts/generate_theme_sounds.py
"""

import math
import struct
import wave
from pathlib import Path


SAMPLE_RATE = 22050
OUTPUT_DIR = Path(__file__).resolve().parents[1] / "gui" / "assets" / "sounds"

# Each event is a list of (frequency, duration, silence-after) tuples.
# These are original short cues inspired by the broad character of each era;
# no Windows system audio is copied or embedded.
SOUNDS = {
    "xp": {
        "startup": [(392, .16, .025), (523, .16, .025), (659, .22, .02), (784, .36, .03)],
        "shutdown": [(784, .16, .02), (659, .16, .02), (523, .2, .02), (392, .32, .03)],
        "error": [(311, .12, .035), (233, .20, .02)],
        "click": [(1047, .035, 0)],
        "notification": [(659, .10, .03), (880, .18, .02)],
        "scan_complete": [(523, .10, .025), (659, .10, .025), (784, .12, .025), (1047, .28, .03)],
    },
    "vista7": {
        "startup": [(523, .18, .04), (659, .18, .04), (784, .22, .04), (1047, .32, .04)],
        "shutdown": [(880, .16, .04), (698, .18, .04), (587, .24, .04), (440, .30, .02)],
        "error": [(440, .10, .045), (370, .16, .03)],
        "click": [(1318, .032, 0)],
        "notification": [(784, .12, .04), (1047, .20, .03)],
        "scan_complete": [(659, .12, .04), (784, .12, .04), (988, .16, .04), (1318, .32, .03)],
    },
    "dark": {
        "click": [(880, .028, 0)],
        "notification": [(587, .10, .035), (784, .18, .03)],
        "scan_complete": [(440, .10, .035), (587, .10, .035), (784, .14, .04), (988, .28, .03)],
    },
}


def _write_tone(path, notes, airy=False):
    samples = []
    for frequency, duration, silence in notes:
        count = max(1, int(SAMPLE_RATE * duration))
        for index in range(count):
            position = index / SAMPLE_RATE
            envelope = min(1.0, index / max(1, SAMPLE_RATE * .012))
            envelope *= max(0.0, min(1.0, (count - index) / max(1, SAMPLE_RATE * .06)))
            fundamental = math.sin(math.tau * frequency * position)
            harmonics = .18 * math.sin(math.tau * frequency * 2 * position)
            if airy:
                harmonics += .12 * math.sin(math.tau * frequency * 3 * position)
            sample = int(32767 * .27 * envelope * (fundamental + harmonics))
            samples.append(max(-32767, min(32767, sample)))
        samples.extend([0] * int(SAMPLE_RATE * silence))

    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(b"".join(struct.pack("<h", sample) for sample in samples))


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    for scheme, events in SOUNDS.items():
        for event, notes in events.items():
            path = OUTPUT_DIR / f"{scheme}_{event}.wav"
            _write_tone(path, notes, airy=(scheme == "vista7"))
            print(f"Wrote {path.name}")


if __name__ == "__main__":
    main()