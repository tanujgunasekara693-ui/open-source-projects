# SysNote Corner → TechDrive: Extended Diagnostics plugin

## Licensing
No third-party licensing question here (unlike the PySimpleGUI situation
in the IDE port) — sysnote.py's own About dialog credits "Author: You",
and all its dependencies (psutil, WMI, pywin32, GPUtil) are permissively
licensed and already fine to bundle.

## Scope
sysnote.py (2683 lines) is a single always-on-top "corner" desktop widget
built around one persistent root Tk window: a system-tray icon, a live-
updating overlay, a notes app, an alert loop, snapshot diffing, a
benchmark tool, live/history graphs, and a process manager, all sharing
global state (`config`, a SQLite history DB, the tray icon, etc.).
That architecture doesn't fit TechDrive's plugin model, where each tool
gets a fresh frame on demand and nothing persists between clicks or
survives a suite of concurrent plugins — porting it as-is wasn't
attempted, since a real port would mean rebuilding the always-on overlay
and tray, not translating this file.

What *did* port cleanly: sysnote.py has ~35 plain functions
(`get_cpu_temp()`, `get_gpu_info()`, `list_startup_entries()`, etc.) that
just gather data and return it — no GUI coupling, no global state beyond
a couple of registry path constants. Those became the **"SysNote:
Extended Diagnostics"** category, 29 tools.

**Not ported** (all require the persistent-overlay architecture, out of
scope): the corner overlay itself, system tray/minimize-to-tray, the
notes app, alert thresholds/history, scheduled reports, snapshot
manager/diff, benchmark, live graph / history graph, process manager,
command palette, appearance/general settings, hotkeys, autostart toggle,
update checker, uninstall helper.

## What was added
- `techdrive_modules/_sysnote_diag.py` — the ~35 data-gathering functions,
  copied over logic-for-logic (bare `except:` narrowed to `except
  Exception:`, otherwise unchanged). Underscore-prefixed support module,
  skipped by the plugin scanner.
- `techdrive_modules/td_sysnote_diagnostics.py` — the plugin itself.
  28 tools are thin `_run_bg` + `_text_output` wrappers using TechDrive's
  own panel helpers (matching the style of e.g. `audio_tools.py`). One,
  **Startup Manager**, is a small custom list UI: it lists per-user Run-key
  startup entries and lets you Enable/Disable each — new capability vs.
  TechDrive's existing read-only startup viewer. Disabling moves the
  value to a backup registry key rather than deleting it, so it can be
  re-enabled later (same behavior as the original).

## Platform notes
Most of these tools are Windows-only in practice (WMI/winreg/pywin32),
same as in the original — they degrade to "N/A" / empty results on
other platforms rather than erroring, which was already how sysnote.py
behaved and is unchanged here. GPU Info falls back to WMI if GPUtil
isn't installed; GPU Clocks tries `nvidia-smi` first, then WMI.

## Dependencies added to requirements.txt
- `GPUtil` — GPU Info tool.
- `pywin32` (Windows only) — Windows Update Status tool
  (`win32com.client`); `WMI` was already a requirement from the base app.

## Not verified
Static port, syntax-checked, and smoke-tested headless (Xvfb): all 29
tools render without error and pair correctly with TechDrive's real
`scan_plugins()`/`install_plugin()`. Not tested on a real Windows desktop
— most of the interesting values (WMI/registry-backed) will only show up
there; on this Linux test box they correctly fall back to "N/A" instead
of crashing.
