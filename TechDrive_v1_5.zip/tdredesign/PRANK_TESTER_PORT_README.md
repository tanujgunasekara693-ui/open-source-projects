# Prank Tester → TechDrive: Prank / Threat Tester plugin

## What this tool actually is
This is a defensive analysis tool, not an attack tool. It scans scripts/
archives for known prank/DoS/malware behavior patterns (fork bombs, zip
bombs, keyboard/network/disk/print flood patterns, LOLBin abuse) and,
optionally, actually runs a selected file in a monitored way — watching
process count, CPU/memory, network connections, and Registry Run-key /
Startup-folder changes — to catch behavior that only shows up at
runtime. Same idea as any lightweight malware/prank sandbox. It contains
no exploit code; the "attacks" it recognizes are regex signatures used
purely for detection and scoring.

## PySimpleGUI
Yes, the original uses it (`import PySimpleGUI as sg`, falling back to
FreeSimpleGUI). Same situation as the earlier IDE port: the GUI class
(`PrankTesterGUI`, ~650 lines) couldn't be reused for TechDrive regardless
of licensing, since TechDrive is Tkinter-based, not PySimpleGUI-based —
a framework mismatch, not just a license one. The backend
(`PrankTesterBackend` + free-standing helper functions), on the other
hand, has zero PySimpleGUI dependency and ported over unchanged.

## What was added
- `techdrive_modules/_prank_backend.py` — the backend, ported logic-for-
  logic: `PrankTesterBackend` (all detection + monitored-execution logic),
  the LOLBin database, signature loading, category-weight scoring, deep
  archive scanning, Windows Sandbox helpers, plus the report-export
  functions (`export_report`/`_export_html`/`_export_pdf`) and the
  cleanup/VirusTotal/history helpers, refactored from `PrankTesterGUI`
  methods into plain functions (no `sg.popup` calls, they return plain
  strings/status now — the caller decides how to show them). Bare
  `except:` narrowed to `except Exception:`, otherwise unchanged.
- `techdrive_modules/td_prank_tester.py` — the plugin itself. New
  category **"Prank / Threat Tester"**, 5 tools:
  - **Test File** — the main tool: pick a file, set timeout/fork-bomb
    threshold, Run/Stop, live streaming log, verdict badge, then Export
    HTML/PDF Report and Clean Up Persistence Changes once a run finishes.
  - **System-Wide Fileless Scan** — checks running processes, Registry
    Run keys, Startup folder, and scheduled tasks for LOLBin/persistence
    patterns.
  - **Signature Database** — shows loaded known-bad-hash count, lets you
    set an update URL (empty by default — nothing is fetched unless you
    set one, same as the original).
  - **VirusTotal Hash Lookup** — needs your own API key, not bundled;
    the tool disables itself with a message if `requests` isn't
    installed.
  - **Test History** — browse/clear past run results.

Streaming output (Test File, System-Wide Scan) uses a background thread
+ queue + `frame.after` polling loop, since these are long-running with
live log lines — different from TechDrive's `_run_bg` helper, which is
built for single-shot "run once, get final result" tools.

## Data files
The original wrote `signatures.json`/`weights.json`/`test_history.json`
next to the script — not writable/appropriate inside TechDrive's
(shared, potentially read-only) `techdrive_modules/` install dir. Redirected
to `~/.techdrive_prank_tester/`, matching TechDrive's own convention of
per-user files under the home directory (e.g. `~/.techdrive_license.json`).

## Not ported
- The 50-language i18n system — the whole English string table only,
  no `lang/*.json` loading. TechDrive doesn't have an i18n system of its
  own to hook into, and this wasn't worth building fresh.
- The ML-ish per-category weight auto-tuning UI (thumbs up/down feedback
  on each verdict) — `adjust_weights()` still exists in the backend and
  the scorer still reads `weights.json`, just nothing in the new UI
  calls `adjust_weights()` yet.
- The Windows Sandbox launch path (`launch_in_sandbox`/
  `is_windows_sandbox_available`) — still in the backend, just not
  wired into the Test File tool's UI (no sandbox checkbox). Would be a
  small follow-up if wanted.
- Drag-and-drop file selection — Browse… dialog only.

## Not verified
Static port, syntax-checked, and smoke-tested headless (Xvfb): all 5
tools render, pair correctly with `scan_plugins()`/`install_plugin()`,
and — for Test File — an actual run was exercised end-to-end (launched
`/bin/true`, monitored it, produced a SAFE verdict, and the result
round-tripped through `~/.techdrive_prank_tester/test_history.json`).
Not tested against a real prank/malware sample or on Windows — most of
the interesting detections (registry/WMI/LOLBin-path checks) are
Windows-specific and will only really exercise on that platform.
