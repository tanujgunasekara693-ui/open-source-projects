#!/usr/bin/env python3
"""
Backward-compatibility shim. TechDrive's LicenseManager was originally
written against `techdrive_protection`; the actual implementation now
lives in fortknox_license.py so it can be shared with TechGov too. This
file just re-exports everything under the old name, pinned to
APP_NAME = "techdrive" so file paths (~/.techdrive_integrity.json etc.)
stay exactly where they were.

New code should `import fortknox_license` directly and set
fortknox_license.APP_NAME itself; this shim exists purely so
techdrive.py doesn't need to change its imports.
"""

import fortknox_license as _fortknox

_fortknox.APP_NAME = "techdrive"
APP_NAME = "techdrive"

# Backward-compatible aliases used by techdrive.py for the encrypted trial
# store.  The implementation was moved to fortknox_license.py, but the
# compatibility shim must expose these names too or first-run/trial checks
# break when Settings reads the license section.
save_encrypted_license = _fortknox.save_encrypted_license
load_encrypted_license = _fortknox.load_encrypted_license
