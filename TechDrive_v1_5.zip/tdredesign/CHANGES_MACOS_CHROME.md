# TechDrive — macOS-style chrome pass (first step)

## Changed
- gui/cpu_label.py (new): formats CPU names like About This Mac,
  e.g. "3.1 GHz Quad-Core Intel Core i5". Used by TechDrive.get_cpu_name().
- techdrive.py get_cpu_name(): uses the formatter; physical core count
  from psutil, base clock from the brand string (max clock as fallback).
- gui/dashboard.py MetricCard: removed the "• LIVE" and "• STEADY" badges.
  Only real changes show a small ▲/▼ arrow.
- gui/topbar.py: new TrafficLights class (red / yellow / green dots with
  hover glyphs) pinned to the far left. Replaces the right-hand
  minimise / maximise / close buttons. Same commands as before.

## Not changed in this pass (needs design decisions and on-device testing)
- Sidebar grouping with expandable chevrons (NavRail rework)
- Replacing the tab strip with a toolbar of icon+label buttons
- Real vibrancy / blur: Tk cannot blur the desktop behind a window.
  The existing optional Aero/DWM backdrop is unchanged.
- SF Pro: the font chain already lists SF Pro first. On Windows it is not
  installed, so text falls back to Segoe UI. Bundling SF Pro is an Apple
  licensing question.
- Replacing the per-card line graphs with a ring or sparkline: a sparkline
  already exists in each card, so the separate graphs need a decision.

## Validation
- py_compile passes for all changed files.
- cpu_label formatter: 9 test cases pass (Intel Core / Core Ultra / Xeon,
  AMD Ryzen, unknown vendor, missing core count, missing clock).
- Not run: GUI. Tkinter is not installed in the build sandbox, so the
  traffic lights and card text must be checked on Windows at 100/125/150%.
