# TechDrive v1.1 — Apple-inspired polish & tab reliability patch

## Changes in this patch

- Updated the ttk notebook chrome to use restrained, macOS-inspired active-tab styling: a quiet card surface, blue accent text, calmer hover state, and more generous tab padding.
- Kept the existing TechDrive identity, current theme system, and legacy tool widgets. This is an Apple-inspired treatment, not a macOS clone or a complete rewrite of every legacy panel.
- Fixed tool-tab duplicate detection: `open_tool()` now compares normalized display titles, accounting for the close glyph that `ClosableNotebook` appends. Reopening a tool should focus its existing tab instead of opening a duplicate.
- Made tab closure resilient to optional callback/bookkeeping errors: the page is forgotten first, and callback failures no longer prevent the tab from closing.
- Increased the close-glyph hit target and corrected the fallback tab-position estimate for Tk builds where tab bounding boxes are unavailable.
- Added middle-click-to-close as an additional gesture. Existing right-click context menu and Ctrl+W behavior remain. Protected Dashboard and Settings tabs remain protected.

## Validation performed

- `python -m compileall -q .` completed successfully.
- Static source checks confirm the normalized title comparison and the new tab close paths are present.
- Archive integrity was checked after packaging.

## Validation limits

This environment does not provide a Windows desktop session for interactive GUI testing. Therefore, mouse-coordinate behavior, visual rendering at Windows DPI scales, and the full tool workflows still need an on-device smoke test. This patch does not claim those GUI runtime tests have passed.

## Suggested Windows smoke test

1. Open one tool, then open the same tool again; it should focus the existing tab.
2. Open three different tools and close the middle tab using its ×.
3. Close a tab using middle-click and Ctrl+W.
4. Right-click a tool tab and test Close Tab / Close Other Tabs / Close All Tabs.
5. Confirm Dashboard and Settings cannot be closed.
6. Switch light/dark themes and confirm active tabs remain legible.
7. Repeat on the lowest supported display resolution and at 125% / 150% Windows scaling.
