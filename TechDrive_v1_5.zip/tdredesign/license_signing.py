"""TechDrive license signing/verification helpers.

The shipped application contains ONLY the Ed25519 public key. The private
signing key must remain on the vendor/developer side and is loaded by the
offline key generator from an environment variable or a local PEM file.
"""
import base64
import json
from datetime import datetime

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

# Public verification key only. It is safe to ship in the application.
# The matching private key is NEVER stored in this module or the product.
TECHDRIVE_PUBLIC_KEY_PEM = b'-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAPx2fCAuxqeUAK80LxU2ZNUv8b93X7u1tWeJLyVkAG70=\n-----END PUBLIC KEY-----\n'


KEY_PREFIX = "TD2"
PRODUCT_CODE = "D"


def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def canonical_payload(tier: str, expires: str, machine_tag: str = "FFFF") -> bytes:
    obj = {
        "v": 2,
        "product": PRODUCT_CODE,
        "tier": tier,
        "expires": expires,
        "machine": machine_tag.upper(),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def encode_license(payload: bytes, signature: bytes) -> str:
    return f"{KEY_PREFIX}.{_b64e(payload)}.{_b64e(signature)}"


def decode_license(key: str):
    parts = (key or "").strip().split(".")
    if len(parts) != 3 or parts[0].upper() != KEY_PREFIX:
        raise ValueError("Unsupported license format. TechDrive requires a TD2 signed license key.")
    payload = _b64d(parts[1])
    signature = _b64d(parts[2])
    obj = json.loads(payload.decode("utf-8"))
    return obj, payload, signature


def verify_license(key: str):
    obj, payload, signature = decode_license(key)
    if obj.get("v") != 2 or obj.get("product") != PRODUCT_CODE:
        raise ValueError("This license was not issued for TechDrive.")
    if obj.get("tier") not in ("P", "B"):
        raise ValueError("Unknown TechDrive license tier.")
    expires = datetime.strptime(obj["expires"], "%Y-%m-%d")
    machine = str(obj.get("machine", "FFFF")).upper()
    if len(machine) != 4 or any(c not in "0123456789ABCDEF" for c in machine):
        raise ValueError("Invalid machine binding in license.")
    public = serialization.load_pem_public_key(TECHDRIVE_PUBLIC_KEY_PEM)
    if not isinstance(public, Ed25519PublicKey):
        raise ValueError("Invalid TechDrive verification key.")
    public.verify(signature, payload)
    return obj, expires
