#!/usr/bin/env python3
"""
Fort Knox License Protection Layer (shared by TechDrive & TechGov)
=====================================================================
Four layers of offline, client-side license/anti-tamper protection,
usable by any app that imports this module and calls its functions -
set APP_NAME once at startup so TechDrive and TechGov don't collide if
both are installed on the same PC (it only namespaces on-disk file paths):
  1. Hardware fingerprinting (HWID)
  2. HWID-encrypted license storage (Fernet, key derived from HWID)
  3. Runtime integrity check (hash of the running exe/script)
  4. Anti-debug / anti-VM environment checks

HONEST LIMITS - please read before relying on this:
  Any protection that runs entirely on a device the attacker controls can,
  in principle, be patched out by someone willing to reverse-engineer it -
  that's true of every offline DRM scheme, not just this one ("unbreakable
  offline protection doesn't really exist; the realistic goal is "raises
  the cost of cracking enough that casual piracy isn't worth it," not
  "impossible"). What this module gives you:
    - A real barrier against casual key-sharing (HWID binding means a
      leaked key/license file won't just work on someone else's PC).
    - Tamper-evidence (a patched exe won't validate against its recorded
      hash) rather than tamper-*proofing*.
    - Anti-debug/anti-VM signal you can use as one input into a licensing
      decision, not as a hard guarantee no one is watching.
  For anything higher-stakes than "deter casual piracy," pair this with
  server-side validation (a call home, even an occasional one) - that's
  the one thing an attacker can't patch out locally.

INTEGRATION NOTE ON UX: by default this module *downgrades to the Free
tier* rather than crashing/exiting when something looks wrong (tampering,
debugger attached). That's deliberate - a hard crash is easy to blame on
"your software is buggy" and burns support time on false positives (a
customer running under a debugger for an unrelated reason, antivirus
tooling that looks VM-like, etc). Silently falling back to Free tier is
both harder to work around blindly and much less disruptive if it's ever
wrong. Flip STRICT_MODE below if you want harder enforcement instead.

USAGE FROM EACH APP:
    import fortknox_license as fortknox
    fortknox.APP_NAME = "techgov"   # or "techdrive" - set once at startup
    safe, report = fortknox.evaluate_environment()
"""

import base64
import hashlib
import json
import os
import platform
import sys
import uuid

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None
    InvalidToken = Exception

try:
    import wmi as wmi_module
except ImportError:
    wmi_module = None

IS_WINDOWS = platform.system() == "Windows"

# Set this once at startup from each app ("techdrive" or "techgov") so the
# two apps don't clobber each other's integrity-reference file on a shared
# machine. Both EXPECTED_EXE_HASH values below should also be set
# per-app (e.g. techdrive.py and techgov.py each hardcode their own
# expected hash after building their release exe - see
# write_integrity_reference()).
APP_NAME = "app"

# If True, tampering/debugger detection raises instead of silently
# downgrading to Free tier. See the UX note above before enabling.
STRICT_MODE = False

# Filled in once, after you build the final .exe with PyInstaller - see
# write_integrity_reference() below. Left as None means "skip the check"
# (e.g. during development, before you've built a release exe). Each app
# should set this from its own code, e.g.:
#   import fortknox_license as fortknox
#   fortknox.APP_NAME = "techdrive"
#   fortknox.EXPECTED_EXE_HASH = "abc123..."
EXPECTED_EXE_HASH = None


def _integrity_reference_file():
    return os.path.join(os.path.expanduser("~"), f".{APP_NAME}_integrity.json")


# ---------------------------------------------------------------------------
# Layer 1: Hardware fingerprinting
# ---------------------------------------------------------------------------
def get_hwid():
    """SHA-256 hash of CPU ID + motherboard serial + disk serial + MAC.
    Falls back gracefully piece-by-piece if any single source is
    unavailable (non-Windows, missing `wmi`, sandboxed VM without those
    fields exposed, etc.) rather than crashing - a HWID that's slightly
    less unique beats an app that won't start."""
    parts = []

    if IS_WINDOWS and wmi_module is not None:
        try:
            c = wmi_module.WMI()
            try:
                parts.append(c.Win32_Processor()[0].ProcessorId.strip())
            except Exception:
                pass
            try:
                parts.append(c.Win32_BaseBoard()[0].SerialNumber.strip())
            except Exception:
                pass
            try:
                parts.append(c.Win32_DiskDrive()[0].SerialNumber.strip())
            except Exception:
                pass
            try:
                parts.append(c.Win32_LogicalDisk(DeviceID="C:")[0].VolumeSerialNumber.strip())
            except Exception:
                pass
        except Exception:
            pass

    try:
        mac = ":".join(f"{(uuid.getnode() >> i) & 0xff:02x}" for i in range(0, 8 * 6, 8))
        parts.append(mac)
    except Exception:
        pass

    if not parts:
        # Last-resort fallback so the app can still run (unbound / less
        # secure) instead of failing outright on an unsupported platform.
        parts.append(platform.node())

    raw = "".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()


def get_hwid_short():
    """Short form for display to the customer (e.g. in the activation
    dialog, so they can send it to you when requesting a HWID-locked
    license)."""
    return get_hwid()[:12].upper()


# ---------------------------------------------------------------------------
# Layer 2: HWID-encrypted license storage
# ---------------------------------------------------------------------------
def get_machine_key(hwid=None):
    if Fernet is None:
        raise RuntimeError("The 'cryptography' package is required (pip install cryptography).")
    hwid = hwid or get_hwid()
    # Fernet keys must be 32 url-safe base64 bytes; take the first 32 hex
    # chars of the HWID (128 bits) as raw key material.
    return base64.urlsafe_b64encode(hwid[:32].encode())


def save_encrypted_license(license_data, path, hwid=None):
    """Encrypt license_data (a dict) with a key derived from this
    machine's HWID and write it to `path`. A license saved this way will
    only decrypt correctly on the machine it was encrypted for (or one
    the vendor deliberately encrypted it for, using that machine's HWID -
    see techdrive_keygen.py)."""
    key = get_machine_key(hwid)
    f = Fernet(key)
    encrypted = f.encrypt(json.dumps(license_data).encode())
    with open(path, "wb") as fh:
        fh.write(encrypted)


def load_encrypted_license(path, hwid=None):
    """Returns the decrypted dict, or None if the file is missing,
    corrupt, or was encrypted for a different machine's HWID."""
    if not os.path.exists(path):
        return None
    key = get_machine_key(hwid)
    f = Fernet(key)
    try:
        with open(path, "rb") as fh:
            encrypted = fh.read()
        return json.loads(f.decrypt(encrypted).decode())
    except InvalidToken:
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Layer 3: Runtime integrity check
# ---------------------------------------------------------------------------
def _current_binary_path():
    """Path to hash: the frozen .exe when packaged with PyInstaller,
    otherwise this script itself (dev mode)."""
    if getattr(sys, "frozen", False):
        return sys.executable
    return os.path.abspath(__file__)


def compute_current_hash():
    path = _current_binary_path()
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return None


def write_integrity_reference():
    """Run this ONCE per app, after building that app's final release .exe
    with PyInstaller, e.g.:
        python fortknox_license.py --app techdrive --write-integrity-reference
    It records the exe's current hash so future runs can detect tampering.
    Re-run it every time you release a new build."""
    h = compute_current_hash()
    if h is None:
        print("Could not hash the current binary.")
        return False
    with open(_integrity_reference_file(), "w") as f:
        json.dump({"hash": h, "path": _current_binary_path()}, f)
    print(f"Integrity reference written: {h}")
    print(f"Also paste this into EXPECTED_EXE_HASH from your app (after setting fortknox.APP_NAME):\n{h!r}")
    return True


def check_integrity():
    """Returns True if the running binary matches the recorded hash, or
    if no reference hash is configured (dev mode / not yet built as an
    exe). Prefers EXPECTED_EXE_HASH (baked into the source, so it ships
    inside the exe itself) over the on-disk reference file, since a local
    file is trivially editable by whoever is trying to bypass this."""
    if EXPECTED_EXE_HASH:
        current = compute_current_hash()
        return current is not None and current == EXPECTED_EXE_HASH

    if os.path.exists(_integrity_reference_file()):
        try:
            with open(_integrity_reference_file()) as f:
                ref = json.load(f)
            current = compute_current_hash()
            return current is not None and current == ref.get("hash")
        except Exception:
            return True  # don't punish the user for a corrupt reference file

    return True  # no reference configured yet - skip rather than false-flag


# ---------------------------------------------------------------------------
# Layer 4: Anti-debug / anti-VM checks
# ---------------------------------------------------------------------------
def detect_debugger():
    """Best-effort, not foolproof (nothing client-side is) - catches an
    attached `sys.settrace`-style debugger (pdb, most Python debuggers)."""
    try:
        if hasattr(sys, "gettrace") and sys.gettrace() is not None:
            return True
    except Exception:
        pass
    return False


def detect_vm():
    """Best-effort VM/sandbox signal via WMI system model/manufacturer.
    Remember VMs are also completely normal for legitimate users (IT
    departments, testers, people who just run their whole desktop
    virtualized) - treat this as a soft signal, not proof of piracy."""
    if not (IS_WINDOWS and wmi_module is not None):
        return False
    try:
        c = wmi_module.WMI()
        for item in c.Win32_ComputerSystem():
            model = (item.Model or "")
            manufacturer = (item.Manufacturer or "")
            markers = ("virtual", "vmware", "qemu", "kvm", "xen", "virtualbox")
            if any(m in model.lower() for m in markers) or any(m in manufacturer.lower() for m in markers):
                return True
    except Exception:
        return False
    return False


# ---------------------------------------------------------------------------
# Combined policy hook
# ---------------------------------------------------------------------------
def evaluate_environment():
    """Call this once at startup. Returns (safe_to_trust_license, report)
    where report is a dict of the individual signals for logging/support
    purposes. `safe_to_trust_license=False` means the caller should treat
    the license as Free-tier regardless of what's on disk."""
    report = {
        "hwid": get_hwid_short(),
        "integrity_ok": check_integrity(),
        "debugger_detected": detect_debugger(),
        "vm_detected": detect_vm(),
    }

    unsafe = (not report["integrity_ok"]) or report["debugger_detected"]

    if unsafe and STRICT_MODE:
        raise RuntimeError(
            f"{APP_NAME} integrity check failed "
            f"(integrity_ok={report['integrity_ok']}, debugger={report['debugger_detected']}). "
            "Refusing to start."
        )

    return (not unsafe), report


if __name__ == "__main__":
    if "--app" in sys.argv:
        APP_NAME = sys.argv[sys.argv.index("--app") + 1]

    if "--write-integrity-reference" in sys.argv:
        write_integrity_reference()
    else:
        print(f"App: {APP_NAME}")
        print("HWID:", get_hwid())
        print("HWID (short, for customer support):", get_hwid_short())
        safe, report = evaluate_environment()
        print("Environment report:", report)
        print("Safe to trust stored license:", safe)
