# TechDrive License Tools

This package was extracted/reconstructed from the supplied TechDrive source
and prepared as a separate vendor-side licensing toolkit.

## Included

- `techdrive_license_generator.py` — Tkinter GUI that creates TD2 Ed25519 license keys.
- `license_signing.py` — the same TD2 signing/verification format used by TechDrive.
- `verify_license.py` — simple command-line verifier.
- `fortknox_license.py` — TechDrive's existing trial/integrity/HWID support module.
- `LICENSE_SECURITY.md` — security notes.
- `requirements.txt` — runtime dependency.

## Private key

The private PEM you uploaded was NOT copied into this ZIP.

Keep the private key offline/private. In the GUI, click Browse and select the
private PEM when issuing a customer license.

Do not put the private key into the TechDrive application or a customer ZIP.

## Generate a license

On Windows:

```powershell
python -m pip install -r requirements.txt
python techdrive_license_generator.py
```

Then:

1. Select the TechDrive Ed25519 private PEM.
2. Choose `P` (Personal Pro) or `B` (Business).
3. Set the expiry date.
4. Leave machine tag as `FFFF` for an unbound key, or enter the customer's
   4-character hexadecimal TechDrive machine tag.
5. Enter the customer's name/label.
6. Generate the key and send only the generated license key to the customer.

## Important compatibility note

The supplied TechDrive source already contains the matching `license_signing.py`
public key and TD2 verification logic. The private PEM you supplied was checked
against that public key and matches it.

The generated key format is:

`TD2.<payload>.<Ed25519 signature>`

The private key is never required by the customer application.

## Security

The client-side license system is not a perfect anti-tamper system. A determined
attacker with control of the client machine can reverse engineer a Python/PyInstaller
application. Keep the signing key off the client and generate a fresh production
keypair if this development key has ever been exposed outside your trusted machine.
