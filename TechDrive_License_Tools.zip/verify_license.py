"""Small command-line verifier for a TechDrive TD2 license key."""
import sys
from license_signing import verify_license

if len(sys.argv) != 2:
    print("Usage: python verify_license.py \"TD2....\"")
    raise SystemExit(2)

try:
    obj, expires = verify_license(sys.argv[1])
    print("VALID")
    print("Tier:", obj["tier"])
    print("Expires:", expires.date().isoformat())
    print("Machine:", obj["machine"])
except Exception as exc:
    print("INVALID:", exc)
    raise SystemExit(1)
