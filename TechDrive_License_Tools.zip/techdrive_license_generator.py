"""
TechDrive TD2 License Generator
Vendor-side tool. Keep your Ed25519 private PEM outside this folder.

This GUI matches TechDrive's current license_signing.py format:
    TD2.<base64url payload>.<base64url Ed25519 signature>

Tiers:
    P = Personal Pro
    B = Business

Machine:
    FFFF = unbound
    4 hexadecimal characters = first 4 characters of TechDrive's HWID

Requires:
    pip install cryptography
"""

import base64
import json
import os
from datetime import date, timedelta
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

KEY_PREFIX = "TD2"
PRODUCT_CODE = "D"
DEFAULT_DAYS = {"P": 30, "B": 365}


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def canonical_payload(tier: str, expires: str, machine_tag: str = "FFFF") -> bytes:
    obj = {
        "v": 2,
        "product": PRODUCT_CODE,
        "tier": tier,
        "expires": expires,
        "machine": machine_tag.upper(),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def encode_license(payload: bytes, signature: bytes) -> str:
    return f"{KEY_PREFIX}.{b64e(payload)}.{b64e(signature)}"


def load_private_key(path: str) -> Ed25519PrivateKey:
    with open(path, "rb") as f:
        key = serialization.load_pem_private_key(f.read(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("The selected PEM is not an Ed25519 private key.")
    return key


def generate_license(private_key_path: str, tier: str, expires: str, machine: str) -> str:
    if tier not in ("P", "B"):
        raise ValueError("Tier must be P or B.")
    machine = machine.strip().upper() or "FFFF"
    if len(machine) != 4 or any(c not in "0123456789ABCDEF" for c in machine):
        raise ValueError("Machine tag must be FFFF or exactly 4 hexadecimal characters.")

    # Validate date format.
    date.fromisoformat(expires)

    payload = canonical_payload(tier, expires, machine)
    private_key = load_private_key(private_key_path)
    signature = private_key.sign(payload)
    return encode_license(payload, signature)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TechDrive License Generator")
        self.geometry("760x540")
        self.minsize(700, 500)

        self.key_path = tk.StringVar()
        self.tier = tk.StringVar(value="P")
        self.expires = tk.StringVar(
            value=(date.today() + timedelta(days=30)).isoformat()
        )
        self.machine = tk.StringVar(value="FFFF")
        self.licensed_to = tk.StringVar(value="Licensed User")
        self.output = tk.StringVar(value="")

        self._build()

    def _build(self):
        pad = {"padx": 14, "pady": 7}
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="TechDrive TD2 License Generator",
                  font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(
            frame,
            text="Vendor-side tool. Never distribute your private PEM with the customer app.",
            foreground="#9b2c2c"
        ).pack(anchor="w", pady=(0, 14))

        keyrow = ttk.Frame(frame)
        keyrow.pack(fill="x", **pad)
        ttk.Label(keyrow, text="Private PEM:", width=14).pack(side="left")
        ttk.Entry(keyrow, textvariable=self.key_path).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(keyrow, text="Browse...", command=self.browse_key).pack(
            side="left", padx=(8, 0)
        )

        row = ttk.Frame(frame)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="Tier:", width=14).pack(side="left")
        tierbox = ttk.Combobox(
            row, textvariable=self.tier,
            values=("P", "B"), state="readonly", width=10
        )
        tierbox.pack(side="left")
        tierbox.bind("<<ComboboxSelected>>", self.tier_changed)
        ttk.Label(
            row,
            text="P = Personal Pro (30 days), B = Business (365 days)"
        ).pack(side="left", padx=12)

        row = ttk.Frame(frame)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="Expires:", width=14).pack(side="left")
        ttk.Entry(row, textvariable=self.expires, width=18).pack(side="left")
        ttk.Label(row, text="YYYY-MM-DD").pack(side="left", padx=12)

        row = ttk.Frame(frame)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="Machine tag:", width=14).pack(side="left")
        ttk.Entry(row, textvariable=self.machine, width=18).pack(side="left")
        ttk.Label(row, text="FFFF = unbound; otherwise 4 hex chars").pack(
            side="left", padx=12
        )

        row = ttk.Frame(frame)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="Licensed to:", width=14).pack(side="left")
        ttk.Entry(row, textvariable=self.licensed_to).pack(
            side="left", fill="x", expand=True
        )

        ttk.Button(
            frame, text="Generate License Key",
            command=self.generate
        ).pack(anchor="w", pady=(14, 8))

        ttk.Label(frame, text="Generated key:").pack(anchor="w")
        self.text = tk.Text(frame, height=7, wrap="word")
        self.text.pack(fill="both", expand=True, pady=(4, 8))

        btns = ttk.Frame(frame)
        btns.pack(fill="x")
        ttk.Button(btns, text="Copy Key", command=self.copy_key).pack(side="left")
        ttk.Button(btns, text="Save Key to .txt", command=self.save_key).pack(
            side="left", padx=8
        )

    def browse_key(self):
        path = filedialog.askopenfilename(
            title="Select TechDrive private PEM",
            filetypes=[("PEM files", "*.pem"), ("All files", "*.*")]
        )
        if path:
            self.key_path.set(path)

    def tier_changed(self, _event=None):
        days = DEFAULT_DAYS[self.tier.get()]
        self.expires.set((date.today() + timedelta(days=days)).isoformat())

    def generate(self):
        try:
            key = generate_license(
                self.key_path.get().strip(),
                self.tier.get(),
                self.expires.get().strip(),
                self.machine.get().strip(),
            )
        except Exception as e:
            messagebox.showerror("Generation failed", str(e))
            return

        self.output.set(key)
        self.text.delete("1.0", "end")
        self.text.insert("1.0", key)
        messagebox.showinfo("Success", "TechDrive TD2 license generated.")

    def copy_key(self):
        key = self.text.get("1.0", "end").strip()
        if not key:
            messagebox.showwarning("No key", "Generate a license first.")
            return
        self.clipboard_clear()
        self.clipboard_append(key)
        self.update()
        messagebox.showinfo("Copied", "License key copied to the clipboard.")

    def save_key(self):
        key = self.text.get("1.0", "end").strip()
        if not key:
            messagebox.showwarning("No key", "Generate a license first.")
            return
        path = filedialog.asksaveasfilename(
            title="Save TechDrive license key",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if path:
            Path(path).write_text(key + "\n", encoding="utf-8")
            messagebox.showinfo("Saved", f"Saved to:\n{path}")


if __name__ == "__main__":
    App().mainloop()
