@echo off
REM ============================================================
REM  TechDrive 95 Edition  -  Tribute / Classic Command Menu
REM  For Windows 95 and higher (nostalgia tribute edition)
REM ============================================================
REM  No Python. No PowerShell. No modern packages.
REM  Just the commands that actually existed in the late 90s.
REM ============================================================

title TechDrive 95 Edition
color 1F
mode con cols=80 lines=40

:NAG
cls
echo.
echo   ========================================================
echo      TechDrive 95 Edition
echo   ========================================================
echo.
echo    Thanks for running TechDrive 95 Edition!
echo.
echo    This is a free tribute menu for Windows 95 (and later).
echo    Nothing here is locked or time-limited - every command
echo    works exactly the same every time you run this menu.
echo.
echo    Owned and published by TechDrive - not a community or
echo    third-party build. This is the first and final release
echo    of this edition; no further updates or support are
echo    planned. Made as a small, free contribution to the
echo    retro computing community - no payment needed, ever.
echo.
echo    This reminder just shows up once each time you launch it.
echo   ========================================================
echo.
pause
goto MAIN

:MAIN
cls
echo.
echo   ========================================================
echo      TechDrive 95 Edition  -  Classic Repair Menu
echo   ========================================================
echo      Target: Windows 95 (and later)
echo      (Tribute edition - see README_95.txt)
echo   ========================================================
echo.
echo      1.  System version          (ver)
echo      2.  Memory summary          (mem)
echo      3.  Drive space             (dir /s summary)
echo      4.  Directory tree          (tree)
echo      5.  Scandisk (drive C)      (scandisk)
echo      6.  Defrag (drive C)        (defrag)
echo      7.  Network status          (net /? / netstat if present)
echo      8.  IP config (if available)
echo      9.  Running tasks           (tasklist if present / else note)
echo     10.  Environment             (set)
echo     11.  Date / Time
echo     12.  Help - what works on 95
echo     13.  About
echo      0.  Exit
echo.
echo   --------------------------------------------------------
set /p CHOICE=  Choose [0-13]: 

if "%CHOICE%"=="1" goto VER
if "%CHOICE%"=="2" goto MEM
if "%CHOICE%"=="3" goto SPACE
if "%CHOICE%"=="4" goto TREE
if "%CHOICE%"=="5" goto SCANDISK
if "%CHOICE%"=="6" goto DEFRAG
if "%CHOICE%"=="7" goto NET
if "%CHOICE%"=="8" goto IP
if "%CHOICE%"=="9" goto TASKS
if "%CHOICE%"=="10" goto ENV
if "%CHOICE%"=="11" goto DATETIME
if "%CHOICE%"=="12" goto HELP
if "%CHOICE%"=="13" goto ABOUT
if "%CHOICE%"=="0" goto END
goto MAIN

:VER
cls
echo === System version ===
ver
echo.
pause
goto MAIN

:MEM
cls
echo === Memory summary ===
mem
echo.
pause
goto MAIN

:SPACE
cls
echo === Drive C: space (dir summary) ===
dir C:\ /-c | find "bytes"
echo.
echo (Full free-space tools were limited on 95; check My Computer too.)
echo.
pause
goto MAIN

:TREE
cls
echo === Directory tree (C:\ - may be slow) ===
echo Press Ctrl+C to stop if it runs too long.
tree C:\ /A
echo.
pause
goto MAIN

:SCANDISK
cls
echo === Scandisk ===
echo This will launch the real Scandisk tool if present.
echo On pure DOS/95 this is the classic surface check.
echo.
pause
scandisk C:
goto MAIN

:DEFRAG
cls
echo === Defrag ===
echo This will launch Disk Defragmenter if present.
echo.
pause
defrag C:
goto MAIN

:NET
cls
echo === Network help / status ===
net /?
echo.
echo --- netstat (if the TCP/IP tools are installed) ---
netstat -an 2>nul
if errorlevel 1 echo netstat not available on this install.
echo.
pause
goto MAIN

:IP
cls
echo === IP configuration ===
echo winipcfg is the GUI tool on Windows 95 (if TCP/IP networking is installed).
echo Trying command-line fallbacks...
echo.
winipcfg 2>nul
if errorlevel 1 (
  ipconfig 2>nul
  if errorlevel 1 echo No winipcfg/ipconfig found. Use Start - Run - winipcfg
)
echo.
pause
goto MAIN

:TASKS
cls
echo === Running programs ===
echo Windows 95 does not have tasklist.
echo Use Ctrl+Alt+Del for the Close Program dialog,
echo or look in Task Manager if you installed a later shell.
echo.
echo Listing some system info instead:
ver
mem
echo.
pause
goto MAIN

:ENV
cls
echo === Environment variables ===
set
echo.
pause
goto MAIN

:DATETIME
cls
echo === Date / Time ===
date /t
time /t
echo.
pause
goto MAIN

:HELP
cls
echo ========================================================
echo  What actually works on Windows 95
echo ========================================================
echo.
echo  [OK]  ver, mem, dir, tree, set, date, time
echo  [OK]  scandisk, defrag (if installed)
echo  [OK]  net commands (basic), winipcfg (GUI)
echo  [OK]  Classic Control Panel applets
echo.
echo  [X]   PowerShell, WMI, wmic, modern netsh
echo  [X]   Python 3.x (does not run on Windows 95)
echo  [X]   Tkinter modern GUI, psutil, cryptography, etc.
echo  [X]   BitLocker, Defender, TPM, DISM, SFC /scannow
echo  [X]   Anything from the modern TechDrive catalogue
echo.
echo  This edition is a tribute menu of era-correct commands.
echo  For real diagnostics use TechDrive XP / Win7 / modern
echo  editions on supported Windows versions.
echo.
pause
goto MAIN

:ABOUT
cls
echo ========================================================
echo  TechDrive 95 Edition
echo ========================================================
echo.
echo  A nostalgic, honest command menu for Windows 95 and higher.
echo.
echo  Why no full Python app?
echo    - Python 3 never supported Windows 95.
echo    - Even late Python 2.x support for 95 is abandoned
echo      and unsafe to recommend in 2026.
echo    - No modern packages, no Tk, no WMI stack.
echo.
echo  Sister editions:
echo    - TechDrive 98 Edition   (batch tribute, Win 98/Me)
echo    - TechDrive XP Edition   (Python 3.4.4)
echo    - TechDrive Win7 Edition (Python 3.8.10)
echo    - Main TechDrive         (Windows 10/11)
echo.
echo  ------------------------------------------------------
echo  Official notice
echo  ------------------------------------------------------
echo  TechDrive 95 Edition is owned and published by TechDrive.
echo  It is NOT a community-made or third-party build.
echo.
echo  This is the first and final release of this edition.
echo  No further updates, changes, or support are planned or
echo  provided for it.
echo.
echo  It was made simply as a small, goodwill contribution to
echo  the retro computing community. It is completely free,
echo  no payment is required, and it always will be.
echo.
echo  Have fun, keep the old boxes running safely.
echo.
pause
goto MAIN

:END
cls
echo.
echo  Thanks for using TechDrive 95 Edition.
echo  Exit.
echo.
exit /b 0
